package com.signal.bot;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Research file for one coin (what a good "X analyst" checks before calling a multi-day move), all from free public data:
 *  • use case + categories (CoinGecko description)
 *  • size: market cap, FDV, circulating vs total supply (unlock pressure), distance from all-time high
 *  • developments: GitHub commits in the last 4 weeks, stars · community: watchlist users, sentiment votes
 *  • token unlocks / listings / delistings / events (Catalyst Radar: DefiLlama emissions, exchange announcements, CoinMarketCal)
 *  • news + X / social posts about the coin (News radar, 46+ sources)
 * Nothing here is "secret insider" data — it is the public footprint that informed traders read early.
 */
public final class CoinIntel {
    private CoinIntel() {}

    public static final class Intel {
        public String base = "", id = "", name = "", useCase = "", categories = "", twitter = "";
        public double mcap, fdv, circ, total, maxSupply, athChg, commits4w = -1, stars = -1, upVotes = -1, watchers = -1;
        public int rank;
        public final List<String> unlocks = new ArrayList<>(), events = new ArrayList<>(), news = new ArrayList<>(), plus = new ArrayList<>(), minus = new ArrayList<>();
        public int newsBull, newsBear, bias;   // bias: −30..+30 adjustment for the hunt
        public String potential = "";
        public boolean blocker;                // big unlock / delisting right ahead
        public long at;

        public JSONObject toJson() {
            JSONObject o = new JSONObject();
            try {
                o.put("name", name); o.put("use", useCase); o.put("cat", categories); o.put("mcap", mcap); o.put("fdv", fdv); o.put("rank", rank);
                o.put("pot", potential); o.put("bias", bias);
                o.put("unl", arr(unlocks)); o.put("ev", arr(events)); o.put("news", arr(news)); o.put("plus", arr(plus)); o.put("minus", arr(minus));
            } catch (Exception ignored) {
            }
            return o;
        }
    }

    static JSONArray arr(List<String> l) { JSONArray a = new JSONArray(); for (String s : l) a.put(s); return a; }

    private static final Map<String, Intel> CACHE = new HashMap<>();

    public static synchronized Intel get(Context ctx, String base) {
        Intel c = CACHE.get(base);
        if (c != null && System.currentTimeMillis() - c.at < 6 * 3600_000L) return c;
        Intel in = build(ctx, base);
        CACHE.put(base, in);
        return in;
    }

    static String clean(String html) {
        String s = html.replaceAll("(?s)<[^>]+>", " ").replaceAll("\\s+", " ").trim();
        // first two sentences = what the project does
        int cut = -1, dots = 0;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) == '.' && i + 1 < s.length() && s.charAt(i + 1) == ' ' && ++dots == 2) { cut = i + 1; break; }
        if (cut > 0) s = s.substring(0, cut);
        return s.length() > 420 ? s.substring(0, 420) + "…" : s;
    }

    static Intel build(Context ctx, String base) {
        Intel in = new Intel();
        in.base = base;
        in.at = System.currentTimeMillis();
        // ---- CoinGecko: find the coin by symbol (highest market cap wins), then the full profile
        try {
            JSONArray coins = new JSONObject(Scanner.getAbsolute("https://api.coingecko.com/api/v3/search?query=" + base)).optJSONArray("coins");
            int best = Integer.MAX_VALUE;
            if (coins != null) for (int i = 0; i < coins.length(); i++) {
                JSONObject o = coins.getJSONObject(i);
                if (!base.equalsIgnoreCase(o.optString("symbol"))) continue;
                int r = o.optInt("market_cap_rank", 0);
                int rr = r > 0 ? r : 100_000 + i;
                if (rr < best) { best = rr; in.id = o.optString("id"); }
            }
            if (!in.id.isEmpty()) {
                JSONObject d = new JSONObject(Scanner.getAbsolute("https://api.coingecko.com/api/v3/coins/" + in.id
                        + "?localization=false&tickers=false&market_data=true&community_data=true&developer_data=true&sparkline=false"));
                in.name = d.optString("name");
                JSONObject desc = d.optJSONObject("description");
                if (desc != null) in.useCase = clean(desc.optString("en"));
                JSONArray cat = d.optJSONArray("categories");
                StringBuilder cb = new StringBuilder();
                if (cat != null) for (int i = 0; i < cat.length() && i < 4; i++) { if (cat.isNull(i)) continue; if (cb.length() > 0) cb.append(", "); cb.append(cat.optString(i)); }
                in.categories = cb.toString();
                in.rank = d.optInt("market_cap_rank", 0);
                in.upVotes = d.optDouble("sentiment_votes_up_percentage", -1);
                in.watchers = d.optDouble("watchlist_portfolio_users", -1);
                JSONObject links = d.optJSONObject("links");
                if (links != null) in.twitter = links.optString("twitter_screen_name");
                JSONObject md = d.optJSONObject("market_data");
                if (md != null) {
                    in.mcap = usd(md, "market_cap");
                    in.fdv = usd(md, "fully_diluted_valuation");
                    in.circ = md.optDouble("circulating_supply", 0);
                    in.total = md.optDouble("total_supply", 0);
                    in.maxSupply = md.optDouble("max_supply", 0);
                    JSONObject ath = md.optJSONObject("ath_change_percentage");
                    if (ath != null) in.athChg = ath.optDouble("usd", 0);
                }
                JSONObject dev = d.optJSONObject("developer_data");
                if (dev != null) {
                    in.commits4w = dev.optDouble("commit_count_4_weeks", -1);
                    in.stars = dev.optDouble("stars", -1);
                }
            }
        } catch (Exception ignored) {
        }
        // ---- unlocks / listings / events (next 30 days + fresh)
        try {
            CatalystEngine.fetch(ctx, 30 * 60_000L);
            long now = System.currentTimeMillis();
            for (CatalystEngine.Event e : CatalystEngine.forCoin(base, 30L * 86_400_000L)) {
                String when = e.time > now ? "in " + Math.max(1, Math.round((e.time - now) / 86_400_000.0)) + " din" : "abhi";
                String line = e.icon() + " " + CatalystEngine.label(e) + " (" + when + "): " + e.title;
                if (CatalystEngine.UNLOCK.equals(e.type)) in.unlocks.add(line + (e.pctMcap > 0 ? String.format(Locale.US, " · %.1f%% market cap", e.pctMcap) : ""));
                else in.events.add(line);
            }
            in.blocker = CatalystEngine.buyBlocker(base) != null;
        } catch (Exception ignored) {
        }
        // ---- news + X / social (last 3 days)
        try {
            for (NewsEngine.Item it : NewsEngine.about(base, 72 * 3600_000L, 8)) {
                if (it.dir > 0) in.newsBull++; else if (it.dir < 0) in.newsBear++;
                in.news.add((it.dir > 0 ? "🟢 " : it.dir < 0 ? "🔴 " : "⚪ ") + (it.social ? "𝕏/social · " : "") + it.title + (it.source.isEmpty() ? "" : " — " + it.source));
            }
        } catch (Exception ignored) {
        }
        judge(in);
        return in;
    }

    static double usd(JSONObject md, String k) {
        JSONObject o = md.optJSONObject(k);
        return o == null ? 0 : o.optDouble("usd", 0);
    }

    /** Footprints that big multi-day moves usually share (and the red flags), turned into a small score adjustment. */
    static void judge(Intel in) {
        int b = 0;
        if (in.mcap > 0 && in.mcap < 150e6) { b += 5; in.plus.add("Chhota market cap " + Fmt.usd(in.mcap) + " — chhote paise se bhi price tez hilti hai (multi-x ki gunjaish, magar risk bhi)"); }
        else if (in.mcap > 5e9) in.minus.add("Bara market cap " + Fmt.usd(in.mcap) + " — 2x/3x ke liye bahut paisa chahiye, moves dheemay");
        if (in.fdv > 0 && in.mcap > 0) {
            double r = in.fdv / in.mcap;
            if (r > 3) { b -= 6; in.minus.add(String.format(Locale.US, "FDV market cap ka %.1fx — bahut se tokens abhi lock hain, aage unlocks ka dabao", r)); }
            else if (r < 1.4) { b += 3; in.plus.add("Zyada tar supply pehle se market mein (FDV ≈ market cap) — unlock ka dar kam"); }
        }
        if (in.commits4w >= 30) { b += 4; in.plus.add("Development jaari: pichle 4 hafte mein " + (int) in.commits4w + " GitHub commits"); }
        else if (in.commits4w == 0) in.minus.add("Pichle 4 hafte mein GitHub par koi commit nahi (development dheemi / band)");
        if (in.athChg < -80) { b += 2; in.plus.add(String.format(Locale.US, "All-time high se %.0f%% neeche — purani bulandi tak kaafi jagah", in.athChg)); }
        else if (in.athChg > -10 && in.athChg != 0) in.minus.add("All-time high ke bilkul qareeb — upar naya price discovery, bechne wale bhi zyada");
        if (in.upVotes >= 75) { b += 2; in.plus.add(String.format(Locale.US, "CoinGecko community %.0f%% bullish", in.upVotes)); }
        if (!in.unlocks.isEmpty()) { b -= 6; in.minus.add("Aane wala token unlock — naye tokens market mein aa kar price daba sakte hain"); }
        if (in.blocker) { b -= 15; in.minus.add("⛔ Bara unlock / delisting 3 din ke andar"); }
        for (String e : in.events) if (e.contains("🆕") || e.contains("🚀") || e.contains("🎁")) { b += 4; in.plus.add("Event / listing / launch aage: " + e); break; }
        if (in.newsBull > in.newsBear) { b += Math.min(6, (in.newsBull - in.newsBear) * 2); in.plus.add(in.newsBull + " achhi khabrein / posts pichle 3 din mein"); }
        else if (in.newsBear > in.newsBull) { b -= Math.min(6, (in.newsBear - in.newsBull) * 2); in.minus.add(in.newsBear + " buri khabrein pichle 3 din mein"); }
        in.bias = Math.max(-30, Math.min(30, b));
        in.potential = b >= 10 ? "🟢 ZYADA — kai multi-day footprints mojood" : b >= 3 ? "🟡 DARMIYANA" : b <= -6 ? "🔴 KAM — red flags zyada" : "⚪ AAM";
    }

    public static List<String> lines(Intel in) {
        List<String> l = new ArrayList<>();
        if (!in.name.isEmpty()) l.add("🪪 " + in.name + (in.rank > 0 ? " · rank #" + in.rank : "") + (in.categories.isEmpty() ? "" : " · " + in.categories));
        if (!in.useCase.isEmpty()) l.add("🛠️ Use case: " + in.useCase);
        if (in.mcap > 0) l.add("💰 Market cap " + Fmt.usd(in.mcap) + (in.fdv > 0 ? " · FDV " + Fmt.usd(in.fdv) : "")
                + (in.total > 0 && in.circ > 0 ? String.format(Locale.US, " · market mein supply %.0f%%", in.circ * 100 / in.total) : ""));
        if (in.commits4w >= 0) l.add("👨‍💻 Developments: " + (int) in.commits4w + " commits / 4 hafte" + (in.stars > 0 ? " · " + (int) in.stars + " GitHub stars" : ""));
        if (in.watchers > 0) l.add("👀 " + Fmt.num(in.watchers) + " log CoinGecko watchlist mein rakhte hain" + (in.twitter.isEmpty() ? "" : " · 𝕏 @" + in.twitter));
        return l;
    }
}
