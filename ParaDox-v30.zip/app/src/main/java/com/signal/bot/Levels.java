package com.signal.bot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Support / resistance from real swing pivots (clustered), plus a structure-based stop / target:
 *  • a WIN needs the price to break the next resistance (BUY) / support (SELL), not just move 1%
 *  • the stop sits beyond the nearest support (BUY) / resistance (SELL), not 0.3% away
 */
public final class Levels {
    private Levels() {}

    /** Clustered pivot levels: {price, touches}. */
    public static List<double[]> pivots(Candles c, int k, boolean highs, double merge) {
        List<double[]> raw = new ArrayList<>();
        int n = c.n;
        for (int i = k; i < n - k; i++) {
            boolean ok = true;
            for (int j = i - k; j <= i + k && ok; j++) {
                if (j == i) continue;
                if (highs ? c.high[j] > c.high[i] : c.low[j] < c.low[i]) ok = false;
            }
            if (ok) raw.add(new double[]{highs ? c.high[i] : c.low[i], 1});
        }
        Collections.sort(raw, (a, b) -> Double.compare(a[0], b[0]));
        List<double[]> out = new ArrayList<>();
        for (double[] p : raw) {
            double[] last = out.isEmpty() ? null : out.get(out.size() - 1);
            if (last != null && Math.abs(p[0] - last[0] / last[1]) <= merge) {   // same zone as the running cluster average
                last[0] += p[0];
                last[1] += 1;
            } else out.add(new double[]{p[0], 1});
        }
        for (double[] o : out) o[0] /= o[1];   // average price of the cluster
        return out;
    }

    /** All levels (supports + resistances) from one or more candle sets, sorted ascending. */
    public static List<Double> all(double atr, Candles... sets) {
        List<double[]> m = new ArrayList<>();
        for (Candles c : sets) {
            if (c == null || c.n < 20) continue;
            m.addAll(pivots(c, 3, true, atr * 0.5));
            m.addAll(pivots(c, 3, false, atr * 0.5));
        }
        Collections.sort(m, (a, b) -> Double.compare(a[0], b[0]));
        List<Double> out = new ArrayList<>();
        for (double[] p : m) {
            if (!out.isEmpty() && p[0] - out.get(out.size() - 1) < atr * 0.4) continue;   // merge near levels
            out.add(p[0]);
        }
        return out;
    }

    public static final class Structure {
        public double sl, tp1, tp2, tp3, support, resistance, rr, atr;
        public boolean ok;
        public String why = "";
    }

    /**
     * Stop beyond the nearest support/resistance, targets just beyond the next levels (a break).
     * minRR: the first target must pay at least this many times the risk.
     */
    public static Structure plan(Candles c, Candles higher, double price, boolean buy, double minRR) {
        Structure s = new Structure();
        double atr = Indicators.atr(c.high, c.low, c.close, 14);
        if (atr <= 0) atr = price * 0.01;
        s.atr = atr;
        List<Double> lv = all(atr, c, higher);
        double sup = 0, res = 0;
        List<Double> beyond = new ArrayList<>();
        for (double l : lv) {
            if (buy) {
                if (l < price - atr * 0.2) sup = l;                 // highest level below
                else if (l > price + atr * 0.3) beyond.add(l);      // ascending
            } else {
                if (l > price + atr * 0.2 && res == 0) res = l;     // lowest level above
                else if (l < price - atr * 0.3) beyond.add(0, l);   // descending
            }
        }
        if (buy) {
            if (sup <= 0) sup = price - 2 * atr;
            s.support = sup;
            s.sl = sup - atr * 0.35;
            double minD = atr * 0.8, maxD = atr * 4;
            if (price - s.sl < minD) s.sl = price - minD;
            if (price - s.sl > maxD) s.sl = price - maxD;
            double r = price - s.sl;
            List<Double> tps = new ArrayList<>();
            for (double l : beyond) {
                double t = l + atr * 0.25;   // a close beyond the level = the level is BROKEN
                if (tps.isEmpty() || t - tps.get(tps.size() - 1) > atr * 0.5) tps.add(t);   // TP1 = the NEXT resistance broken (no skipping)
            }
            if (!beyond.isEmpty()) s.resistance = beyond.get(0);
            while (tps.size() < 3) tps.add((tps.isEmpty() ? price : tps.get(tps.size() - 1)) + r * (tps.isEmpty() ? Math.max(minRR, 1.5) : 1.2));
            s.tp1 = tps.get(0); s.tp2 = tps.get(1); s.tp3 = tps.get(2);
            s.rr = (s.tp1 - price) / r;
            s.ok = s.rr >= minRR - 0.01;
            s.why = "Stop support $" + Fmt.price(sup) + " ke neeche · TP1 resistance " + (beyond.isEmpty() ? "(upar koi purani resistance nahi — ATR target)" : "$" + Fmt.price(beyond.get(0)) + " TOOTNE ke baad");
        } else {
            if (res <= 0) res = price + 2 * atr;
            s.resistance = res;
            s.sl = res + atr * 0.35;
            double minD = atr * 0.8, maxD = atr * 4;
            if (s.sl - price < minD) s.sl = price + minD;
            if (s.sl - price > maxD) s.sl = price + maxD;
            double r = s.sl - price;
            List<Double> tps = new ArrayList<>();
            for (double l : beyond) {
                double t = l - atr * 0.25;
                if (tps.isEmpty() || tps.get(tps.size() - 1) - t > atr * 0.5) tps.add(t);
            }
            if (!beyond.isEmpty()) s.support = beyond.get(0);
            while (tps.size() < 3) tps.add((tps.isEmpty() ? price : tps.get(tps.size() - 1)) - r * (tps.isEmpty() ? Math.max(minRR, 1.5) : 1.2));
            for (int i = 0; i < 3; i++) if (tps.get(i) <= 0) tps.set(i, price * (0.9 - 0.05 * i));
            s.tp1 = tps.get(0); s.tp2 = tps.get(1); s.tp3 = tps.get(2);
            s.rr = (price - s.tp1) / r;
            s.ok = s.rr >= minRR - 0.01;
            s.why = "Stop resistance $" + Fmt.price(res) + " ke upar · TP1 support " + (beyond.isEmpty() ? "(neeche koi purana support nahi — ATR target)" : "$" + Fmt.price(beyond.get(0)) + " TOOTNE ke baad");
        }
        return s;
    }

    /**
     * This coin's own history: of all days in the past (optionally only volume-spike days), how often did the price reach
     * +tpPct before −slPct within `days` days? Stop checked first on the same day (conservative). Returns {probability %, samples, avg days}.
     */
    public static double[] hitRate(Candles d, double slPct, double tpPct, int days, boolean buy, boolean spikeOnly) {
        int hits = 0, tot = 0;
        double dsum = 0;
        for (int i = 25; i < d.n - days; i++) {
            if (spikeOnly) {
                double avg = 0;
                for (int j = i - 20; j < i; j++) avg += d.quoteVol[j];
                avg /= 20;
                if (avg <= 0 || d.quoteVol[i] < avg * 2) continue;
            }
            double e = d.close[i];
            boolean hit = false;
            int when = 0;
            for (int t = i + 1; t <= i + days; t++) {
                boolean stop = buy ? d.low[t] <= e * (1 - slPct / 100) : d.high[t] >= e * (1 + slPct / 100);
                if (stop) break;
                boolean tp = buy ? d.high[t] >= e * (1 + tpPct / 100) : d.low[t] <= e * (1 - tpPct / 100);
                if (tp) { hit = true; when = t - i; break; }
            }
            tot++;
            if (hit) { hits++; dsum += when; }
        }
        return new double[]{tot > 0 ? hits * 100.0 / tot : 0, tot, hits > 0 ? dsum / hits : 0};
    }
}
