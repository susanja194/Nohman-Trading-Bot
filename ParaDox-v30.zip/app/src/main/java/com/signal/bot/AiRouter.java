package com.signal.bot;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

/**
 * One AI "analyst" with two FREE providers (the paid Claude API option was removed in v27):
 *  • Google Gemini — has a FREE tier (key from aistudio.google.com)
 *  • Groq (Llama / Qwen / GPT-OSS) — FREE tier, very fast (key from console.groq.com)
 * The AI never sees the market by itself: ParaDox sends it the live data it collected, the AI reads and explains it.
 */
public final class AiRouter {
    private AiRouter() {}

    public static final String GEMINI = "gemini", GROQ = "groq";

    public static final String SYSTEM = "You are an expert crypto, gold (commodities) and forex trader and market analyst inside the 'ParaDox' "
            + "Android app. The user is a Pakistani trader. Always reply in simple Roman Urdu (Urdu written in English letters), "
            + "short and clear, using bullet points. You receive a LIVE data report (Binance price, multi-timeframe technicals, "
            + "chart patterns, money flow, whale trades, order book, futures positioning, news, sentiment) and must base "
            + "your answer ONLY on that data. Give one clear direction (BUY or SELL / long or short), entry zone, stop-loss, "
            + "2 targets, what would invalidate the idea, and the main risks. If the data conflicts, say which side is "
            + "stronger and why. Never promise profit; end with one short line that this is not financial advice.";


    public static String provider(Context c) {
        String p = Prefs.getStr(c, "aiprov", "");
        if (GEMINI.equals(p) || GROQ.equals(p)) return p;
        // nothing chosen yet (or the removed Claude option): pick whichever free key exists
        if (!Prefs.getStr(c, "geminikey", "").isEmpty()) return GEMINI;
        if (!Prefs.getStr(c, "groqkey", "").isEmpty()) return GROQ;
        return GEMINI;
    }

    public static String key(Context c) {
        String p = provider(c);
        return p.equals(GROQ) ? Prefs.getStr(c, "groqkey", "") : Prefs.getStr(c, "geminikey", "");
    }

    public static String label(Context c) {
        String p = provider(c);
        return p.equals(GROQ) ? "Groq Llama (free)" : "Gemini (free)";
    }

    public static boolean ready(Context c) { return !key(c).trim().isEmpty(); }

    public static String ask(Context c, List<String[]> history) throws Exception {
        String p = provider(c), k = key(c).trim();
        if (k.isEmpty()) throw new Exception("Settings → AI mein key daalein (Gemini / Groq free hain)");
        if (p.equals(GEMINI)) {
            Exception last = null;
            for (String m : new String[]{"gemini-2.5-flash", "gemini-flash-latest", "gemini-2.0-flash", "gemini-2.0-flash-lite"}) {
                try { return gemini(k, m, history); } catch (Exception e) { last = e; if (e.getMessage() != null && e.getMessage().contains("key")) break; }
            }
            throw last;
        }
        {
            Exception last = null;
            for (String m : new String[]{"llama-3.3-70b-versatile", "openai/gpt-oss-120b", "llama-3.1-8b-instant"}) {
                try { return groq(k, m, history); } catch (Exception e) { last = e; if (e.getMessage() != null && e.getMessage().contains("key")) break; }
            }
            throw last;
        }
    }

    static String gemini(String key, String model, List<String[]> history) throws Exception {
        JSONObject body = new JSONObject();
        JSONObject sys = new JSONObject();
        sys.put("parts", new JSONArray().put(new JSONObject().put("text", SYSTEM)));
        body.put("systemInstruction", sys);
        JSONArray contents = new JSONArray();
        for (String[] h : history) {
            JSONObject m = new JSONObject();
            m.put("role", "assistant".equals(h[0]) ? "model" : "user");
            m.put("parts", new JSONArray().put(new JSONObject().put("text", h[1])));
            contents.put(m);
        }
        body.put("contents", contents);
        String resp = post("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent", body, "x-goog-api-key", key, null);
        JSONArray cand = new JSONObject(resp).getJSONArray("candidates");
        JSONArray parts = cand.getJSONObject(0).getJSONObject("content").getJSONArray("parts");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.length(); i++) sb.append(parts.getJSONObject(i).optString("text"));
        return sb.toString().trim();
    }

    static String groq(String key, String model, List<String[]> history) throws Exception {
        JSONObject body = new JSONObject();
        body.put("model", model);
        body.put("max_tokens", 1500);
        JSONArray msgs = new JSONArray();
        msgs.put(new JSONObject().put("role", "system").put("content", SYSTEM));
        for (String[] h : history) msgs.put(new JSONObject().put("role", h[0]).put("content", h[1]));
        body.put("messages", msgs);
        String resp = post("https://api.groq.com/openai/v1/chat/completions", body, "Authorization", "Bearer " + key, null);
        return new JSONObject(resp).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content").trim();
    }

    static String post(String url, JSONObject body, String hName, String hVal, String unused) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setRequestMethod("POST");
            c.setConnectTimeout(20000);
            c.setReadTimeout(90000);
            c.setDoOutput(true);
            c.setRequestProperty("content-type", "application/json");
            c.setRequestProperty(hName, hVal);
            try (OutputStream os = c.getOutputStream()) {
                os.write(body.toString().getBytes("UTF-8"));
            }
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            StringBuilder sb = new StringBuilder();
            if (in != null) try (BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
                String l;
                while ((l = br.readLine()) != null) sb.append(l).append('\n');
            }
            if (code != 200) {
                String msg = sb.toString();
                try {
                    JSONObject e = new JSONObject(msg).optJSONObject("error");
                    if (e != null) msg = e.optString("message", msg);
                } catch (Exception ignored) {
                }
                if (code == 401 || code == 403) msg = "API key ghalat hai — Settings mein sahi key daalein";
                else if (code == 429) msg = "Free limit poori — thori der baad try karein";
                throw new Exception(msg.length() > 200 ? msg.substring(0, 200) : msg);
            }
            return sb.toString();
        } finally {
            c.disconnect();
        }
    }
}
