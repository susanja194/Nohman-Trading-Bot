package com.signal.bot;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Settings, watchlist and saved signal history. */
public final class Prefs {
    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("signalbot", Context.MODE_PRIVATE);
    }

    public static boolean enabled(Context c) { return sp(c).getBoolean("enabled", false); }
    public static void setEnabled(Context c, boolean v) { sp(c).edit().putBoolean("enabled", v).apply(); }

    public static int intervalMin(Context c) { return sp(c).getInt("interval", 5); }
    public static String timeframe(Context c) { return sp(c).getString("tf", "15m"); }
    public static int topCoins(Context c) { return sp(c).getInt("top", 100); }
    public static int minVolMillion(Context c) { return sp(c).getInt("minvol", 5); }
    public static int buyThreshold(Context c) { return sp(c).getInt("buyth", 7); }
    public static int sellThreshold(Context c) { return sp(c).getInt("sellth", 5); }
    public static float volMult(Context c) { return sp(c).getFloat("volmult", 2.0f); }
    public static boolean btcFilter(Context c) { return sp(c).getBoolean("btcfilter", true); }
    public static int cooldownMin(Context c) { return sp(c).getInt("cooldown", 120); }
    public static boolean smartMoney(Context c) { return sp(c).getBoolean("smart", true); }
    public static int whaleUsd(Context c) { return sp(c).getInt("whaleusd", 50000); }
    public static boolean strongConfirm(Context c) { return sp(c).getBoolean("strong", true); }
    public static String glassKey(Context c) { return sp(c).getString("glass", ""); }
    public static String lastCoin(Context c) { return sp(c).getString("lastcoin", "BTCUSDT"); }
    public static void setLastCoin(Context c, String s) { sp(c).edit().putString("lastcoin", s).apply(); }

    public static void saveSettings(Context c, int interval, String tf, int top, int minVol,
                                    int buyTh, int sellTh, float volMult, boolean btc, int cooldown) {
        sp(c).edit()
                .putInt("interval", Math.max(1, interval))
                .putString("tf", tf)
                .putInt("top", Math.max(5, Math.min(400, top)))
                .putInt("minvol", Math.max(0, minVol))
                .putInt("buyth", Math.max(1, buyTh))
                .putInt("sellth", Math.max(1, sellTh))
                .putFloat("volmult", Math.max(1.1f, volMult))
                .putBoolean("btcfilter", btc)
                .putInt("cooldown", Math.max(0, cooldown))
                .apply();
    }

    public static void saveSmart(Context c, boolean smart, int whaleUsd) {
        sp(c).edit().putBoolean("smart", smart).putInt("whaleusd", Math.max(1000, whaleUsd)).apply();
    }

    public static void saveExtra(Context c, boolean strong, String glassKey) {
        sp(c).edit().putBoolean("strong", strong).putString("glass", glassKey == null ? "" : glassKey.trim()).apply();
    }

    // ---------------- watchlist
    public static List<String> watchlist(Context c) {
        List<String> out = new ArrayList<>();
        for (String s : sp(c).getString("watch", "BTCUSDT,ETHUSDT,SOLUSDT").split(",")) {
            s = s.trim();
            if (!s.isEmpty() && !out.contains(s)) out.add(s);
        }
        return out;
    }

    public static boolean inWatchlist(Context c, String sym) { return watchlist(c).contains(sym); }

    /** Adds or removes. Returns true if the coin is now in the watchlist. */
    public static boolean toggleWatch(Context c, String sym) {
        List<String> l = watchlist(c);
        boolean now;
        if (l.contains(sym)) { l.remove(sym); now = false; } else { l.add(0, sym); now = true; }
        StringBuilder sb = new StringBuilder();
        for (String s : l) { if (sb.length() > 0) sb.append(','); sb.append(s); }
        sp(c).edit().putString("watch", sb.toString()).apply();
        return now;
    }

    // ---------------- status + cooldown
    public static String status(Context c) { return sp(c).getString("status", "Bot abhi band hai"); }
    public static void setStatus(Context c, String s) { sp(c).edit().putString("status", s).apply(); }

    public static boolean cooldownOk(Context c, String symbol, String side) {
        long last = sp(c).getLong("cd_" + symbol + "_" + side, 0);
        return System.currentTimeMillis() - last >= cooldownMin(c) * 60_000L;
    }

    public static void markCooldown(Context c, String symbol, String side) {
        sp(c).edit().putLong("cd_" + symbol + "_" + side, System.currentTimeMillis()).apply();
    }

    // ---------------- signals
    public static synchronized void addSignal(Context c, String side, String symbol, double price,
                                              int score, String reasons) {
        try {
            JSONArray old = new JSONArray(sp(c).getString("signals", "[]"));
            JSONArray arr = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("t", System.currentTimeMillis());
            o.put("side", side);
            o.put("sym", symbol);
            o.put("price", price);
            o.put("score", score);
            o.put("why", reasons);
            arr.put(o);
            for (int i = 0; i < old.length() && i < 199; i++) arr.put(old.get(i));
            sp(c).edit().putString("signals", arr.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    public static JSONArray signals(Context c) {
        try {
            return new JSONArray(sp(c).getString("signals", "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    public static void clearSignals(Context c) { sp(c).edit().putString("signals", "[]").apply(); }
}
