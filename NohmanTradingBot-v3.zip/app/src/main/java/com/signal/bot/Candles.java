package com.signal.bot;

import org.json.JSONArray;

/** OHLCV candles from Binance klines, oldest first. */
public final class Candles {
    public final int n;
    public final long[] time;
    public final double[] open, high, low, close, vol, takerBuy;

    private Candles(int n) {
        this.n = n;
        time = new long[n];
        open = new double[n];
        high = new double[n];
        low = new double[n];
        close = new double[n];
        vol = new double[n];
        takerBuy = new double[n];
    }

    public static Candles parse(String json, boolean closedOnly) throws Exception {
        JSONArray arr = new JSONArray(json);
        int n = closedOnly ? Math.max(0, arr.length() - 1) : arr.length();
        Candles c = new Candles(n);
        for (int i = 0; i < n; i++) {
            JSONArray k = arr.getJSONArray(i);
            c.time[i] = k.getLong(0);
            c.open[i] = Double.parseDouble(k.getString(1));
            c.high[i] = Double.parseDouble(k.getString(2));
            c.low[i] = Double.parseDouble(k.getString(3));
            c.close[i] = Double.parseDouble(k.getString(4));
            c.vol[i] = Double.parseDouble(k.getString(5));
            c.takerBuy[i] = k.length() > 9 ? Double.parseDouble(k.getString(9)) : c.vol[i] / 2;
        }
        return c;
    }

    /** closedOnly = drop the still-forming candle (for analysis). */
    public static Candles fetch(String symbol, String tf, int limit, boolean closedOnly) throws Exception {
        return parse(Scanner.get("/api/v3/klines?symbol=" + symbol + "&interval=" + tf + "&limit=" + limit), closedOnly);
    }
}
