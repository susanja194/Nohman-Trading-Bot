package com.signal.bot;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    static final int BG = 0xFF0A0E17, BG2 = 0xFF101828, CARD = 0xFF141B2B, CHIP = 0xFF1C2638, STROKE = 0xFF22304A,
            TEXT = 0xFFE8EAED, SOFT = 0xFFC9D1DC, MUTED = 0xFF8B95A7, GOLD = 0xFFF0B90B, CYAN = 0xFF22D3EE,
            GREEN = 0xFF0ECB81, RED = 0xFFF6465D, YELLOW = 0xFFFFC94D;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final View[] pages = new View[4];
    private final TextView[] tabs = new TextView[4];
    private int currentTab = -1;
    private TextView liveDot;

    // Market
    private GaugeView fgGauge;
    private TextView btcView, globalView;
    private LinearLayout marketList;
    private final TextView[] modeChips = new TextView[4];
    private int marketMode = 0;
    private JSONArray tickerCache;

    // Analyze
    private EditText searchEt;
    private TextView starBtn, chartTitle;
    private final TextView[] tfChips = new TextView[4];
    private static final String[] CHART_TFS = {"15m", "1h", "4h", "1d"};
    private String chartTf = "1h";
    private String currentSym = "BTCUSDT";
    private ChartView chart;
    private LinearLayout watchRow, resultBox;

    // Signals
    private TextView statusView;
    private Button toggleBtn;
    private LinearLayout signalList;
    private String signalKey = "";

    // Settings
    private EditText intervalEt, topEt, minVolEt, buyEt, sellEt, volMultEt, cooldownEt, whaleEt, glassEt;
    private Spinner tfSpinner;
    private CheckBox btcCb, smartCb, strongCb;
    private static final String[] TFS = {"5m", "15m", "30m", "1h", "4h"};

    private final Runnable refresher = new Runnable() {
        @Override
        public void run() {
            refreshStatus();
            handler.postDelayed(this, 5000);
        }
    };

    // ============================================================ lifecycle
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScannerService.createChannels(this);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(CARD);
        currentSym = Prefs.lastCoin(this);

        LinearLayout root = column();
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{BG, BG2}));
        root.addView(header());
        FrameLayout content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));
        buildMarket();
        buildAnalyze();
        buildSignals();
        buildSettings();
        for (View p : pages) content.addView(p, new FrameLayout.LayoutParams(-1, -1));
        root.addView(bottomNav());
        setContentView(root);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        if (!handleIntent(getIntent())) showTab(0);
        loadChart();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private boolean handleIntent(Intent i) {
        if (i == null) return false;
        String coin = i.getStringExtra("coin");
        if (coin == null || coin.isEmpty()) return false;
        i.removeExtra("coin");
        openAnalyze(coin);
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(refresher);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(refresher);
    }

    @Override
    protected void onDestroy() {
        pool.shutdownNow();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (currentTab != 0) showTab(0);
        else super.onBackPressed();
    }

    // ============================================================ ui helpers
    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable round(int color, float radiusDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) g.setStroke(dp(1), strokeColor);
        return g;
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setPadding(0, dp(2), 0, dp(2));
        return t;
    }

    private TextView bold(String s, float sp, int color) {
        TextView t = text(s, sp, color);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout c = column();
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        c.setBackground(round(CARD, 18, STROKE));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        parent.addView(c, lp);
        return c;
    }

    private LinearLayout pageColumn(int idx) {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout col = column();
        col.setPadding(dp(14), 0, dp(14), dp(28));
        sv.addView(col);
        pages[idx] = sv;
        return col;
    }

    private TextView chip(String s, boolean on) {
        TextView t = bold(s, 13, TEXT);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(8), dp(14), dp(8));
        styleChip(t, on);
        return t;
    }

    private void styleChip(TextView t, boolean on) {
        t.setTextColor(on ? BG : TEXT);
        t.setBackground(round(on ? GOLD : CHIP, 20, on ? GOLD : STROKE));
    }

    private LinearLayout.LayoutParams chipLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dp(8);
        return lp;
    }

    private Button button(String s, int bg, int fg, int stroke) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(fg);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(round(bg, 14, stroke));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(50));
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    /** Two-colour horizontal bar; leftPct = 0..100. */
    private View bar(double leftPct, int leftColor, int rightColor) {
        LinearLayout b = row();
        b.setBackground(round(rightColor, 6, 0));
        float l = (float) Math.max(0, Math.min(100, leftPct));
        View a = new View(this);
        a.setBackground(round(leftColor, 6, 0));
        b.addView(a, new LinearLayout.LayoutParams(0, -1, l));
        b.addView(new View(this), new LinearLayout.LayoutParams(0, -1, 100 - l));
        return b;
    }

    private View divider() {
        View d = new View(this);
        d.setBackgroundColor(STROKE);
        d.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1)));
        return d;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void openUrl(String url) {
        if (url == null || url.isEmpty()) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            toast("Link nahi khula");
        }
    }

    private static String base(String sym) {
        return sym.endsWith("USDT") ? sym.substring(0, sym.length() - 4) : sym;
    }

    private static int scoreColor(int v) {
        return v >= 58 ? GREEN : v <= 42 ? RED : YELLOW;
    }

    // ============================================================ frame
    private View header() {
        LinearLayout h = row();
        h.setPadding(dp(16), dp(14), dp(16), dp(6));
        TextView a = bold("NOHMAN", 20, GOLD);
        a.setLetterSpacing(0.08f);
        TextView b = bold(" TRADING BOT", 20, CYAN);
        b.setLetterSpacing(0.08f);
        h.addView(a);
        h.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
        liveDot = bold("○ OFF", 12, MUTED);
        liveDot.setPadding(dp(10), dp(4), dp(10), dp(4));
        liveDot.setBackground(round(CHIP, 12, STROKE));
        liveDot.setOnClickListener(v -> showTab(2));
        h.addView(liveDot);
        return h;
    }

    private View bottomNav() {
        LinearLayout nav = row();
        nav.setBackground(round(CARD, 0, STROKE));
        nav.setPadding(0, dp(6), 0, dp(6));
        String[] labels = {"📊\nMarket", "🔍\nAnalyze", "🔔\nSignals", "⚙️\nSettings"};
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            TextView t = text(labels[i], 12, MUTED);
            t.setGravity(Gravity.CENTER);
            t.setOnClickListener(v -> showTab(idx));
            tabs[i] = t;
            nav.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        }
        return nav;
    }

    private void showTab(int i) {
        currentTab = i;
        for (int k = 0; k < 4; k++) {
            pages[k].setVisibility(k == i ? View.VISIBLE : View.GONE);
            tabs[k].setTextColor(k == i ? GOLD : MUTED);
            tabs[k].setTypeface(k == i ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        }
        if (i == 0 && tickerCache == null) loadMarket();
        if (i == 2) renderSignals(true);
        refreshStatus();
    }

    // ============================================================ MARKET tab
    private void buildMarket() {
        LinearLayout col = pageColumn(0);
        LinearLayout top = card(col);
        LinearLayout tr = row();
        tr.addView(bold("Market Overview", 18, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView rf = chip("↻ Refresh", false);
        rf.setOnClickListener(v -> loadMarket());
        tr.addView(rf);
        top.addView(tr);
        fgGauge = new GaugeView(this);
        fgGauge.set(-1, "Fear & Greed", "load ho raha hai...");
        top.addView(fgGauge, new LinearLayout.LayoutParams(-1, dp(170)));
        btcView = bold("BTC —", 16, TEXT);
        top.addView(btcView);
        globalView = text("", 13, MUTED);
        top.addView(globalView);

        LinearLayout lc = card(col);
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout modes = row();
        hs.addView(modes);
        String[] names = {"🚀 Gainers", "📉 Losers", "🔥 Volume", "⭐ Watchlist"};
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            modeChips[i] = chip(names[i], i == marketMode);
            modeChips[i].setOnClickListener(v -> {
                marketMode = idx;
                for (int k = 0; k < 4; k++) styleChip(modeChips[k], k == marketMode);
                renderMarket();
            });
            modes.addView(modeChips[i], chipLp());
        }
        lc.addView(hs);
        lc.addView(text("Kisi bhi coin par tap karein — poora analysis khulega", 12, MUTED));
        marketList = column();
        lc.addView(marketList);
    }

    private void loadMarket() {
        btcView.setText("Load ho raha hai...");
        btcView.setTextColor(TEXT);
        pool.execute(() -> {
            try {
                final JSONArray tick = new JSONArray(Scanner.get("/api/v3/ticker/24hr?type=MINI"));
                final String[] fg = SmartMoney.fearGreed();
                final JSONObject global = fetchGlobal();
                runOnUiThread(() -> {
                    tickerCache = tick;
                    renderOverview(fg, global);
                    renderMarket();
                });
            } catch (Exception e) {
                final String msg = e.getMessage();
                runOnUiThread(() -> btcView.setText("Market load nahi hua: " + msg + "\nInternet check karke Refresh dabayen"));
            }
        });
    }

    private static JSONObject fetchGlobal() {
        try {
            return new JSONObject(Scanner.getAbsolute("https://api.coingecko.com/api/v3/global")).getJSONObject("data");
        } catch (Exception e) {
            return null;
        }
    }

    private static double change(JSONObject t) {
        double o = t.optDouble("openPrice", 0), l = t.optDouble("lastPrice", 0);
        return o > 0 ? (l / o - 1) * 100 : 0;
    }

    private JSONObject findTicker(String sym) {
        if (tickerCache == null) return null;
        for (int i = 0; i < tickerCache.length(); i++) {
            JSONObject o = tickerCache.optJSONObject(i);
            if (o != null && sym.equals(o.optString("symbol"))) return o;
        }
        return null;
    }

    private void renderOverview(String[] fg, JSONObject g) {
        if (fg != null) {
            int v = -1;
            try { v = Integer.parseInt(fg[0]); } catch (Exception ignored) { }
            fgGauge.set(v, fg[1], "Fear & Greed Index (poori market ka mood)");
        } else {
            fgGauge.set(-1, "Fear & Greed", "data nahi mila");
        }
        JSONObject btc = findTicker("BTCUSDT");
        if (btc != null) {
            double ch = change(btc);
            btcView.setText("₿ BTC  $" + Fmt.price(btc.optDouble("lastPrice", 0)) + "   " + Fmt.pct(ch) + " (24h)");
            btcView.setTextColor(ch >= 0 ? GREEN : RED);
        }
        if (g != null) {
            StringBuilder s = new StringBuilder();
            JSONObject tm = g.optJSONObject("total_market_cap");
            if (tm != null) s.append("Total market cap: ").append(Fmt.usd(tm.optDouble("usd", 0)));
            s.append(String.format(Locale.US, " (%+.2f%% 24h)", g.optDouble("market_cap_change_percentage_24h_usd", 0)));
            JSONObject mcp = g.optJSONObject("market_cap_percentage");
            if (mcp != null) s.append(String.format(Locale.US, "\nBTC dominance: %.1f%% · ETH: %.1f%%",
                    mcp.optDouble("btc", 0), mcp.optDouble("eth", 0)));
            globalView.setText(s.toString());
        } else {
            globalView.setText("CoinGecko global data abhi nahi mila");
        }
    }

    private void renderMarket() {
        marketList.removeAllViews();
        if (tickerCache == null) return;
        List<JSONObject> list = new ArrayList<>();
        if (marketMode == 3) {
            for (String s : Prefs.watchlist(this)) {
                JSONObject o = findTicker(s);
                if (o != null) list.add(o);
            }
        } else {
            for (int i = 0; i < tickerCache.length(); i++) {
                JSONObject o = tickerCache.optJSONObject(i);
                if (o == null) continue;
                if (!Scanner.isTradable(o.optString("symbol"))) continue;
                if (o.optDouble("quoteVolume", 0) < 2_000_000 || o.optDouble("lastPrice", 0) <= 0) continue;
                list.add(o);
            }
            if (marketMode == 0) Collections.sort(list, (a, b) -> Double.compare(change(b), change(a)));
            else if (marketMode == 1) Collections.sort(list, (a, b) -> Double.compare(change(a), change(b)));
            else Collections.sort(list, (a, b) -> Double.compare(b.optDouble("quoteVolume", 0), a.optDouble("quoteVolume", 0)));
        }
        if (list.isEmpty()) {
            marketList.addView(text(marketMode == 3 ? "Watchlist khali hai — Analyze tab mein ☆ dabayen" : "Koi coin nahi mila", 13, MUTED));
            return;
        }
        for (int i = 0; i < list.size() && i < 25; i++) marketList.addView(coinRow(list.get(i), i + 1));
    }

    private View coinRow(JSONObject o, int rank) {
        final String sym = o.optString("symbol");
        double ch = change(o);
        LinearLayout r = row();
        r.setPadding(0, dp(10), 0, dp(10));
        r.addView(text(String.valueOf(rank), 12, MUTED), new LinearLayout.LayoutParams(dp(26), -2));
        LinearLayout nm = column();
        nm.addView(bold(base(sym), 15, TEXT));
        nm.addView(text("Vol " + Fmt.usd(o.optDouble("quoteVolume", 0)), 11, MUTED));
        r.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
        TextView pr = text("$" + Fmt.price(o.optDouble("lastPrice", 0)), 14, TEXT);
        pr.setPadding(0, 0, dp(10), 0);
        r.addView(pr);
        TextView pc = bold(Fmt.pct(ch), 13, 0xFFFFFFFF);
        pc.setGravity(Gravity.CENTER);
        pc.setPadding(dp(6), dp(5), dp(6), dp(5));
        pc.setBackground(round(ch >= 0 ? GREEN : RED, 8, 0));
        r.addView(pc, new LinearLayout.LayoutParams(dp(84), -2));
        r.setOnClickListener(v -> openAnalyze(sym));
        LinearLayout wrap = column();
        wrap.addView(r);
        wrap.addView(divider());
        return wrap;
    }

    // ============================================================ ANALYZE tab
    private void buildAnalyze() {
        LinearLayout col = pageColumn(1);
        LinearLayout sc = card(col);
        sc.addView(bold("🔍 Apna coin analyze karein", 17, TEXT));
        LinearLayout sr = row();
        searchEt = new EditText(this);
        searchEt.setHint("SOL, PEPE, BTC...");
        searchEt.setHintTextColor(MUTED);
        searchEt.setTextColor(TEXT);
        searchEt.setSingleLine(true);
        searchEt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        searchEt.setText(base(currentSym));
        sr.addView(searchEt, new LinearLayout.LayoutParams(0, -2, 1));
        TextView go = chip("Analyze", true);
        go.setOnClickListener(v -> {
            String s = searchEt.getText().toString().trim();
            if (s.isEmpty()) return;
            hideKeyboard();
            runAnalysis(CoinReport.normalize(s));
        });
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(-2, -2);
        glp.leftMargin = dp(8);
        sr.addView(go, glp);
        starBtn = chip("☆", false);
        starBtn.setOnClickListener(v -> {
            boolean on = Prefs.toggleWatch(this, currentSym);
            updateStar();
            renderWatchRow();
            toast(on ? "Watchlist mein add — bot isay hamesha scan karega" : "Watchlist se hata diya");
        });
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-2, -2);
        slp.leftMargin = dp(8);
        sr.addView(starBtn, slp);
        sc.addView(sr);
        sc.addView(text("⭐ Watchlist (tap = analysis):", 12, MUTED));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        watchRow = row();
        hs.addView(watchRow);
        sc.addView(hs);

        LinearLayout cc = card(col);
        chartTitle = bold(base(currentSym) + "/USDT", 16, TEXT);
        cc.addView(chartTitle);
        LinearLayout tr = row();
        tr.setPadding(0, dp(6), 0, dp(6));
        for (int i = 0; i < CHART_TFS.length; i++) {
            final String tf = CHART_TFS[i];
            tfChips[i] = chip(tf, tf.equals(chartTf));
            tfChips[i].setOnClickListener(v -> {
                chartTf = tf;
                for (int k = 0; k < CHART_TFS.length; k++) styleChip(tfChips[k], CHART_TFS[k].equals(chartTf));
                loadChart();
            });
            tr.addView(tfChips[i], chipLp());
        }
        cc.addView(tr);
        chart = new ChartView(this);
        cc.addView(chart, new LinearLayout.LayoutParams(-1, dp(320)));
        cc.addView(text("Chart ko chhoo kar candle ki detail dekhen · Cyan = EMA20 · Purple = EMA50 · "
                + "neeche volume (green = buyers zyada, red = sellers zyada)", 11, MUTED));

        resultBox = column();
        col.addView(resultBox);
        LinearLayout hint = card(resultBox);
        hint.addView(bold("Kya milega?", 15, TEXT));
        hint.addView(text("Coin likh kar Analyze dabayen. Bot yeh sab mila kar 1 final score (0–100) banata hai:\n"
                + "• Technical: 15m, 1h, 4h, 1d (EMA, RSI, MACD, volume)\n"
                + "• Paisa aa raha ya nikal raha (buyers vs sellers, CVD, OBV)\n"
                + "• Whales ke bade orders + order book walls\n"
                + "• Futures ke top traders, open interest, funding\n"
                + "• News, CoinGecko community, Fear & Greed\n"
                + "• Glassnode on-chain (agar API key ho)", 13, SOFT));
        updateStar();
        renderWatchRow();
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(searchEt.getWindowToken(), 0);
        } catch (Exception ignored) {
        }
    }

    private void updateStar() {
        boolean on = Prefs.inWatchlist(this, currentSym);
        starBtn.setText(on ? "★" : "☆");
        styleChip(starBtn, on);
    }

    private void renderWatchRow() {
        watchRow.removeAllViews();
        for (String s : Prefs.watchlist(this)) {
            final String sym = s;
            TextView c = chip(base(s), false);
            c.setOnClickListener(v -> openAnalyze(sym));
            watchRow.addView(c, chipLp());
        }
    }

    private void openAnalyze(String sym) {
        showTab(1);
        searchEt.setText(base(sym));
        pages[1].scrollTo(0, 0);
        runAnalysis(sym);
    }

    private void loadChart() {
        final String sym = currentSym, tf = chartTf;
        chart.setMessage("Chart load ho raha hai...");
        pool.execute(() -> {
            try {
                final Candles c = Candles.fetch(sym, tf, 150, false);
                runOnUiThread(() -> {
                    if (sym.equals(currentSym) && tf.equals(chartTf)) chart.setData(c);
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> chart.setMessage("Chart nahi mila: " + m));
            }
        });
    }

    private void runAnalysis(String sym) {
        currentSym = sym;
        Prefs.setLastCoin(this, sym);
        updateStar();
        chartTitle.setText(base(sym) + "/USDT");
        loadChart();
        resultBox.removeAllViews();
        LinearLayout wait = card(resultBox);
        wait.addView(bold("⏳ " + base(sym) + " ka analysis ho raha hai...", 15, GOLD));
        wait.addView(text("Binance (4 timeframes), whales, order book, futures, news, CoinGecko aur Fear & Greed "
                + "se data jama ho raha hai. 10–20 second lag sakte hain.", 13, MUTED));
        final String key = Prefs.glassKey(this);
        final double wu = Prefs.whaleUsd(this);
        pool.execute(() -> {
            try {
                final CoinReport r = CoinReport.build(sym, key, wu, true);
                runOnUiThread(() -> {
                    if (sym.equals(currentSym)) showReport(r);
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> {
                    if (!sym.equals(currentSym)) return;
                    resultBox.removeAllViews();
                    LinearLayout c = card(resultBox);
                    c.addView(bold("❌ Analysis nahi ho saka", 15, RED));
                    c.addView(text(m == null ? "Internet check karein" : m, 13, SOFT));
                    c.addView(text("Coin ka naam sahi likhein (jaise SOL, PEPE, WIF). Sirf Binance par USDT ke saath list coins chalte hain.", 12, MUTED));
                });
            }
        });
    }

    private String pctFrom(double v, double p) {
        return p > 0 ? String.format(Locale.US, "  (%+.1f%%)", (v / p - 1) * 100) : "";
    }

    private void showReport(final CoinReport r) {
        resultBox.removeAllViews();
        chartTitle.setText(r.name + " · " + r.base + "/USDT   $" + Fmt.price(r.price) + "  " + Fmt.pct(r.change24h));

        LinearLayout h = card(resultBox);
        h.addView(bold("🎯 Final signal (sab sources mila kar)", 16, TEXT));
        GaugeView g = new GaugeView(this);
        g.set(r.total, r.verdict, r.base + " · score / 100");
        h.addView(g, new LinearLayout.LayoutParams(-1, dp(175)));
        TextView vt = bold(r.verdictText, 14, scoreColor(r.total));
        vt.setGravity(Gravity.CENTER);
        h.addView(vt);
        TextView rg = text("24h range: $" + Fmt.price(r.low24h) + " – $" + Fmt.price(r.high24h)
                + " · Volume " + Fmt.usd(r.quoteVol24h), 12, MUTED);
        rg.setGravity(Gravity.CENTER);
        h.addView(rg);

        LinearLayout f = card(resultBox);
        f.addView(bold("💰 Paisa aa raha ya nikal raha? (24h)", 16, TEXT));
        f.addView(bold(r.flowLabel, 17, r.flowSign > 0 ? GREEN : r.flowSign < 0 ? RED : YELLOW));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, dp(14));
        blp.topMargin = dp(8);
        f.addView(bar(r.buyPct, GREEN, RED), blp);
        LinearLayout lr = row();
        lr.addView(text(String.format(Locale.US, "Buyers %.0f%%", r.buyPct), 12, GREEN), new LinearLayout.LayoutParams(0, -2, 1));
        lr.addView(text(String.format(Locale.US, "Sellers %.0f%%", 100 - r.buyPct), 12, RED));
        f.addView(lr);

        for (CoinReport.Section s : r.sections) sectionCard(s);

        LinearLayout p = card(resultBox);
        p.addView(bold("🧭 Trade plan (andaza)", 16, TEXT));
        p.addView(text("Support: $" + Fmt.price(r.support) + "   ·   Resistance: $" + Fmt.price(r.resistance), 13, SOFT));
        if (r.total >= 58 && r.atr > 0) {
            p.addView(text("Entry: ~$" + Fmt.price(r.price), 14, TEXT));
            p.addView(text("Stop-loss: $" + Fmt.price(r.stop) + pctFrom(r.stop, r.price), 14, RED));
            p.addView(text("Target 1: $" + Fmt.price(r.target1) + pctFrom(r.target1, r.price), 14, GREEN));
            p.addView(text("Target 2: $" + Fmt.price(r.target2) + pctFrom(r.target2, r.price), 14, GREEN));
            p.addView(text("Target 1 par aadha profit le lein aur stop ko entry par le aayen.", 12, MUTED));
        } else if (r.total <= 42) {
            p.addView(text("Abhi BUY ka setup nahi. Agar aap ke paas hai to support $" + Fmt.price(r.support)
                    + " ke neeche stop rakhen ya profit bacha lein.", 13, YELLOW));
        } else {
            p.addView(text("Intezar karein: resistance $" + Fmt.price(r.resistance)
                    + " ke upar volume ke saath candle close ho to BUY strong hoga.", 13, YELLOW));
        }

        if (!r.news.isEmpty()) {
            LinearLayout n = card(resultBox);
            n.addView(bold("📰 Taaza khabrein — " + r.name, 16, TEXT));
            for (String[] it : r.news) {
                String tone = "+".equals(it[3]) ? "🟢 " : "-".equals(it[3]) ? "🔴 " : "⚪ ";
                TextView t = text(tone + it[0], 13, TEXT);
                t.setPadding(0, dp(6), 0, 0);
                final String link = it[1];
                t.setOnClickListener(v -> openUrl(link));
                n.addView(t);
                n.addView(text(it[2] + " · tap karke parhen", 11, MUTED));
            }
        }

        LinearLayout act = card(resultBox);
        Button bin = button("Binance par " + r.base + " kholen", GOLD, BG, 0);
        bin.setOnClickListener(v -> openUrl("https://www.binance.com/en/trade/" + r.base + "_USDT?type=spot"));
        act.addView(bin);
        act.addView(text("⚠️ Yeh analysis maloomat ke liye hai, financial advice nahi. 'Market ki raaye' CoinGecko community "
                + "votes, news aur sentiment se banti hai — kisi asal expert ki guarantee nahi. Hamesha stop-loss lagayen.", 12, MUTED));
    }

    private void sectionCard(CoinReport.Section s) {
        LinearLayout c = card(resultBox);
        LinearLayout hr = row();
        hr.addView(bold(s.icon + "  " + s.title, 15, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        int col = !s.available ? MUTED : s.score > 15 ? GREEN : s.score < -15 ? RED : YELLOW;
        hr.addView(bold(s.available ? String.format(Locale.US, "%+d", s.score) : "N/A", 14, col));
        c.addView(hr);
        if (s.available) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(6));
            lp.topMargin = dp(6);
            lp.bottomMargin = dp(4);
            c.addView(bar((s.score + 100) / 2.0, col, 0xFF243049), lp);
        }
        for (String l : s.lines) c.addView(text("• " + l, 13, SOFT));
    }

    // ============================================================ SIGNALS tab
    private void buildSignals() {
        LinearLayout col = pageColumn(2);
        LinearLayout st = card(col);
        st.addView(bold("🤖 24/7 Signal Bot", 17, TEXT));
        statusView = text("", 13, MUTED);
        st.addView(statusView);
        toggleBtn = button("", GOLD, BG, 0);
        toggleBtn.setOnClickListener(v -> toggle());
        st.addView(toggleBtn);
        Button bat = button("🔋 Battery restriction hatayen (zaroori)", CARD, GOLD, GOLD);
        bat.setOnClickListener(v -> askBattery());
        st.addView(bat);

        LinearLayout sc = card(col);
        LinearLayout hr = row();
        hr.addView(bold("🔔 Signals", 17, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView clr = chip("Clear", false);
        clr.setOnClickListener(v -> {
            Prefs.clearSignals(this);
            renderSignals(true);
        });
        hr.addView(clr);
        sc.addView(hr);
        sc.addView(text("Signal par tap karein — us coin ka poora analysis khulega", 12, MUTED));
        signalList = column();
        sc.addView(signalList);
    }

    private void renderSignals(boolean force) {
        JSONArray arr = Prefs.signals(this);
        JSONObject first = arr.optJSONObject(0);
        String key = arr.length() + ":" + (first == null ? 0 : first.optLong("t"));
        if (!force && key.equals(signalKey)) return;
        signalKey = key;
        signalList.removeAllViews();
        if (arr.length() == 0) {
            signalList.addView(text("Abhi koi signal nahi. Bot ON karein — signal aate hi notification aa jayegi.", 13, MUTED));
            return;
        }
        SimpleDateFormat f = new SimpleDateFormat("dd MMM HH:mm", Locale.US);
        for (int i = 0; i < arr.length() && i < 60; i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            final boolean buy = "BUY".equals(o.optString("side"));
            final String sym = o.optString("sym");
            LinearLayout item = column();
            item.setPadding(dp(12), dp(10), dp(12), dp(10));
            item.setBackground(round(buy ? 0x1A0ECB81 : 0x1AF6465D, 12, buy ? 0x550ECB81 : 0x55F6465D));
            LinearLayout hr = row();
            hr.addView(bold((buy ? "🟢 BUY  " : "🔴 SELL  ") + base(sym) + "/USDT", 15, buy ? GREEN : RED),
                    new LinearLayout.LayoutParams(0, -2, 1));
            hr.addView(bold("score " + o.optInt("score"), 12, TEXT));
            item.addView(hr);
            item.addView(text("$" + Fmt.price(o.optDouble("price")) + " · " + f.format(new Date(o.optLong("t"))), 12, MUTED));
            item.addView(text(o.optString("why"), 12, SOFT));
            item.setOnClickListener(v -> openAnalyze(sym));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(8);
            signalList.addView(item, lp);
        }
    }

    private void refreshStatus() {
        boolean on = Prefs.enabled(this);
        liveDot.setText(on ? "● LIVE" : "○ OFF");
        liveDot.setTextColor(on ? GREEN : MUTED);
        statusView.setText(Prefs.status(this));
        toggleBtn.setText(on ? "⏹  Stop bot" : "▶  Start bot (24/7)");
        if (currentTab == 2) renderSignals(false);
    }

    private void toggle() {
        if (Prefs.enabled(this)) {
            startService(new Intent(this, ScannerService.class).setAction(ScannerService.ACTION_STOP));
            Prefs.setEnabled(this, false);
        } else {
            Prefs.setEnabled(this, true);
            startForegroundService(new Intent(this, ScannerService.class));
        }
        handler.postDelayed(this::refreshStatus, 300);
    }

    private void askBattery() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm.isIgnoringBatteryOptimizations(getPackageName())) {
                toast("Pehle se unrestricted hai ✅");
                return;
            }
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception ignored) {
            }
        }
    }

    // ============================================================ SETTINGS tab
    private EditText field(LinearLayout parent, String label, String value, int inputType) {
        parent.addView(text(label, 13, MUTED));
        EditText e = new EditText(this);
        e.setInputType(inputType);
        e.setTextColor(TEXT);
        e.setSingleLine(true);
        e.setText(value);
        parent.addView(e);
        return e;
    }

    private EditText numField(LinearLayout parent, String label, int value) {
        return field(parent, label, String.valueOf(value), InputType.TYPE_CLASS_NUMBER);
    }

    private CheckBox check(LinearLayout parent, String label, boolean on) {
        CheckBox cb = new CheckBox(this);
        cb.setText(label);
        cb.setTextColor(TEXT);
        cb.setChecked(on);
        parent.addView(cb);
        return cb;
    }

    private void buildSettings() {
        LinearLayout col = pageColumn(3);
        LinearLayout set = card(col);
        set.addView(bold("⚙️ Bot settings", 17, TEXT));
        intervalEt = numField(set, "Har kitne minute baad scan", Prefs.intervalMin(this));
        set.addView(text("Candle timeframe", 13, MUTED));
        tfSpinner = new Spinner(this);
        tfSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, TFS));
        for (int i = 0; i < TFS.length; i++) if (TFS[i].equals(Prefs.timeframe(this))) tfSpinner.setSelection(i);
        set.addView(tfSpinner);
        topEt = numField(set, "Kitne top coins scan karein (volume ke hisaab se, max 400)", Prefs.topCoins(this));
        minVolEt = numField(set, "Kam az kam 24h volume (million USDT)", Prefs.minVolMillion(this));
        buyEt = numField(set, "BUY score threshold (zyada = kam magar strong signal)", Prefs.buyThreshold(this));
        sellEt = numField(set, "SELL score threshold", Prefs.sellThreshold(this));
        volMultEt = field(set, "Volume spike = average ka kitna guna (e.g. 2.0)", String.valueOf(Prefs.volMult(this)),
                InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        cooldownEt = numField(set, "Ek coin ka dobara signal kitne minute baad", Prefs.cooldownMin(this));
        btcCb = check(set, "BTC filter: jab BTC bearish ho to BUY signal na do", Prefs.btcFilter(this));
        smartCb = check(set, "🐋 Smart money: whale trades, top traders, open interest", Prefs.smartMoney(this));
        strongCb = check(set, "🎯 Strong signal: notification se pehle SAB sources se confirm karo (kam magar pakke signal)",
                Prefs.strongConfirm(this));
        whaleEt = numField(set, "Whale trade kitne USD se bada ho (e.g. 50000)", Prefs.whaleUsd(this));
        glassEt = field(set, "Glassnode API key (optional — sirf paid plan par milti hai)", Prefs.glassKey(this),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        Button save = button("💾 Save settings", GOLD, BG, 0);
        save.setOnClickListener(v -> saveSettings());
        set.addView(save);

        LinearLayout info = card(col);
        info.addView(bold("📡 Data sources (sab free)", 15, TEXT));
        info.addView(text("• Binance spot: price, candles, buyers/sellers volume, whale trades, order book\n"
                + "• Binance Futures: open interest, top traders, retail long/short, funding\n"
                + "• CoinGecko: market cap, community sentiment, BTC dominance\n"
                + "• Alternative.me: Fear & Greed Index\n"
                + "• News: Cointelegraph, CoinDesk, Decrypt\n"
                + "• Glassnode: exchange flows (sirf API key ke saath)", 13, SOFT));
        info.addView(text("⚠️ Signals sirf maloomat ke liye hain, financial advice nahi. Koi bhi indicator 100% sahi nahi "
                + "hota — hamesha stop-loss lagayen. Bot khud koi trade nahi karta.", 12, MUTED));
    }

    private int num(EditText e, int def) {
        try {
            return Integer.parseInt(e.getText().toString().trim());
        } catch (Exception x) {
            return def;
        }
    }

    private void saveSettings() {
        float vm;
        try {
            vm = Float.parseFloat(volMultEt.getText().toString().trim());
        } catch (Exception x) {
            vm = 2.0f;
        }
        Prefs.saveSettings(this, num(intervalEt, 5), TFS[tfSpinner.getSelectedItemPosition()],
                num(topEt, 100), num(minVolEt, 5), num(buyEt, 7), num(sellEt, 5), vm,
                btcCb.isChecked(), num(cooldownEt, 120));
        Prefs.saveSmart(this, smartCb.isChecked(), num(whaleEt, 50000));
        Prefs.saveExtra(this, strongCb.isChecked(), glassEt.getText().toString());
        toast("Saved ✅ — agla scan naye settings se hoga");
    }
}
