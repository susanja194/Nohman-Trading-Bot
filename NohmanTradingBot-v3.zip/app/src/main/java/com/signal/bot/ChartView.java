package com.signal.bot;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Candlestick chart with EMA20 / EMA50 and buy/sell coloured volume. Touch to inspect a candle. */
public class ChartView extends View {
    private static final int UP = 0xFF0ECB81, DOWN = 0xFFF6465D, GRID = 0xFF1E2840, TXT = 0xFF8B95A7,
            EMA20 = 0xFF22D3EE, EMA50 = 0xFF8B5CF6, LAST = 0xFFF0B90B;
    private static final int VISIBLE = 80;

    private Candles data;
    private double[] ema20, ema50;
    private int touchIdx = -1;
    private final float d;
    private final Paint upP = new Paint(Paint.ANTI_ALIAS_FLAG), downP = new Paint(Paint.ANTI_ALIAS_FLAG),
            volUp = new Paint(), volDown = new Paint(), grid = new Paint(), text = new Paint(Paint.ANTI_ALIAS_FLAG),
            e20 = new Paint(Paint.ANTI_ALIAS_FLAG), e50 = new Paint(Paint.ANTI_ALIAS_FLAG),
            last = new Paint(Paint.ANTI_ALIAS_FLAG), info = new Paint(Paint.ANTI_ALIAS_FLAG),
            labelBg = new Paint(Paint.ANTI_ALIAS_FLAG), cross = new Paint();
    private String message = "Chart load ho raha hai...";

    public ChartView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        upP.setColor(UP);
        upP.setStrokeWidth(1.2f * d);
        downP.setColor(DOWN);
        downP.setStrokeWidth(1.2f * d);
        volUp.setColor(0x660ECB81);
        volDown.setColor(0x66F6465D);
        grid.setColor(GRID);
        grid.setStrokeWidth(1);
        text.setColor(TXT);
        text.setTextSize(10 * d);
        e20.setColor(EMA20);
        e20.setStyle(Paint.Style.STROKE);
        e20.setStrokeWidth(1.5f * d);
        e50.setColor(EMA50);
        e50.setStyle(Paint.Style.STROKE);
        e50.setStrokeWidth(1.5f * d);
        last.setColor(LAST);
        last.setStrokeWidth(1);
        info.setColor(0xFFE8EAED);
        info.setTextSize(10.5f * d);
        labelBg.setColor(LAST);
        cross.setColor(0x88FFFFFF);
        cross.setStrokeWidth(1);
    }

    public void setMessage(String m) {
        message = m;
        data = null;
        invalidate();
    }

    public void setData(Candles c) {
        data = c;
        ema20 = Indicators.ema(c.close, 20);
        ema50 = Indicators.ema(c.close, 50);
        touchIdx = -1;
        invalidate();
    }

    private float rightPad() { return 62 * d; }

    @Override
    protected void onDraw(Canvas cv) {
        super.onDraw(cv);
        float w = getWidth(), h = getHeight();
        if (data == null || data.n == 0) {
            cv.drawText(message, 12 * d, h / 2, text);
            return;
        }
        int count = Math.min(VISIBLE, data.n);
        int start = data.n - count;
        float top = 22 * d;
        float volH = h * 0.18f;
        float priceBottom = h - volH - 10 * d;
        float plotW = w - rightPad();
        float cw = plotW / count;

        double max = -Double.MAX_VALUE, min = Double.MAX_VALUE, maxVol = 0;
        for (int i = start; i < data.n; i++) {
            max = Math.max(max, data.high[i]);
            min = Math.min(min, data.low[i]);
            maxVol = Math.max(maxVol, data.vol[i]);
        }
        double range = max - min;
        if (range <= 0) range = Math.max(max * 0.01, 1e-12);
        max += range * 0.04;
        min -= range * 0.04;
        range = max - min;

        for (int g = 0; g <= 4; g++) {
            float y = top + (priceBottom - top) * g / 4f;
            cv.drawLine(0, y, plotW, y, grid);
            cv.drawText(Fmt.price(max - range * g / 4.0), plotW + 4 * d, y + 4 * d, text);
        }

        for (int i = start; i < data.n; i++) {
            float x = (i - start) * cw + cw / 2;
            boolean up = data.close[i] >= data.open[i];
            Paint p = up ? upP : downP;
            float yH = y(data.high[i], max, range, top, priceBottom);
            float yL = y(data.low[i], max, range, top, priceBottom);
            float yO = y(data.open[i], max, range, top, priceBottom);
            float yC = y(data.close[i], max, range, top, priceBottom);
            cv.drawLine(x, yH, x, yL, p);
            float bt = Math.min(yO, yC), bb = Math.max(Math.max(yO, yC), bt + 1.2f * d);
            float half = Math.max(1, cw * 0.36f);
            cv.drawRect(x - half, bt, x + half, bb, p);
            if (maxVol > 0) {
                float vh = (float) (data.vol[i] / maxVol * volH);
                boolean buyers = data.takerBuy[i] >= data.vol[i] / 2;
                cv.drawRect(x - half, h - vh, x + half, h, buyers ? volUp : volDown);
            }
        }

        drawLine(cv, ema20, start, cw, max, range, top, priceBottom, e20);
        drawLine(cv, ema50, start, cw, max, range, top, priceBottom, e50);

        double lp = data.close[data.n - 1];
        float ly = y(lp, max, range, top, priceBottom);
        cv.drawLine(0, ly, plotW, ly, last);
        cv.drawRect(plotW, ly - 8 * d, w, ly + 8 * d, labelBg);
        Paint lt = new Paint(info);
        lt.setColor(0xFF0A0E17);
        lt.setFakeBoldText(true);
        cv.drawText(Fmt.price(lp), plotW + 3 * d, ly + 4 * d, lt);

        Paint le = new Paint(info);
        le.setColor(EMA20);
        cv.drawText("EMA20", 4 * d, 12 * d, le);
        le.setColor(EMA50);
        cv.drawText("EMA50", 48 * d, 12 * d, le);

        if (touchIdx >= start && touchIdx < data.n) {
            int i = touchIdx;
            float x = (i - start) * cw + cw / 2;
            cv.drawLine(x, top, x, h, cross);
            double chg = data.open[i] > 0 ? (data.close[i] / data.open[i] - 1) * 100 : 0;
            double bp = data.vol[i] > 0 ? data.takerBuy[i] / data.vol[i] * 100 : 50;
            String when = new SimpleDateFormat("dd MMM HH:mm", Locale.US).format(new Date(data.time[i]));
            String s = when + "  O " + Fmt.price(data.open[i]) + "  H " + Fmt.price(data.high[i])
                    + "  L " + Fmt.price(data.low[i]) + "  C " + Fmt.price(data.close[i])
                    + String.format(Locale.US, "  %+.2f%%  Buy %.0f%%", chg, bp);
            Paint bg = new Paint();
            bg.setColor(0xEE141B2B);
            cv.drawRect(0, 0, w, 18 * d, bg);
            cv.drawText(s, 4 * d, 12.5f * d, info);
        }
    }

    private static float y(double v, double max, double range, float top, float bottom) {
        return (float) (top + (max - v) / range * (bottom - top));
    }

    private void drawLine(Canvas cv, double[] e, int start, float cw, double max, double range,
                          float top, float bottom, Paint p) {
        if (e == null || data.n < 2) return;
        Path path = new Path();
        boolean first = true;
        for (int i = start; i < data.n; i++) {
            float x = (i - start) * cw + cw / 2;
            float yy = y(e[i], max, range, top, bottom);
            if (yy < top || yy > bottom) { first = true; continue; }
            if (first) { path.moveTo(x, yy); first = false; } else path.lineTo(x, yy);
        }
        cv.drawPath(path, p);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (data == null || data.n == 0) return false;
        int count = Math.min(VISIBLE, data.n);
        float cw = (getWidth() - rightPad()) / count;
        int idx = data.n - count + (int) (e.getX() / cw);
        idx = Math.max(data.n - count, Math.min(data.n - 1, idx));
        int a = e.getAction();
        boolean end = a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL;
        touchIdx = end ? -1 : idx;
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(!end);
        invalidate();
        return true;
    }
}
