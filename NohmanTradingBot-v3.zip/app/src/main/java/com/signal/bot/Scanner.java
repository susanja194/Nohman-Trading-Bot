package com.signal.bot;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Network helpers + one full background scan of Binance spot USDT coins (public data, no API key). */
public final class Scanner {
    private Scanner() {}

    public static final String CH_SIGNALS = "signals";

    private static final String[] HOSTS = {
            "https://data-api.binance.vision",
            "https://api.binance.com",
            "https://api1.binance.com",
            "https://api2.binance.com",
            "https://api-gcp.binance.com"
    };
    private static volatile int hostIdx = 0;

    /** Errors that should not be retried on another host. */
    static final class HardFail extends IOException {
        HardFail(String m) { super(m); }
    }

    private static final Set<String> SKIP = new HashSet<>();
    static {
        String[] s = {"USDCUSDT", "FDUSDUSDT", "TUSDUSDT", "BUSDUSDT", "USDPUSDT", "DAIUSDT",
                "EURUSDT", "EURIUSDT", "AEURUSDT", "USDEUSDT", "XUSDUSDT", "PAXGUSDT", "BFUSDUSDT",
                "GBPUSDT", "TRYUSDT", "BRLUSDT", "USD1USDT", "RLUSDUSDT", "PYUSDUSDT"};
        Collections.addAll(SKIP, s);
    }

    static boolean isTradable(String s) {
        return s != null && s.endsWith("USDT") && s.length() > 4 && !SKIP.contains(s);
    }

    private static String read(HttpURLConnection conn) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    /** Fetch any full URL (futures, CoinGecko, news, Glassnode...). */
    static String getAbsolute(String url) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        try {
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) NohmanTradingBot/3.0");
            conn.setRequestProperty("Accept", "*/*");
            int code = conn.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code);
            return read(conn);
        } finally {
            conn.disconnect();
        }
    }

    /** Binance spot REST with automatic fallback between mirrors. */
    static String get(String path) throws IOException {
        IOException last = new IOException("Binance tak pohanch nahi ho rahi");
        for (int a = 0; a < HOSTS.length; a++) {
            int idx = (hostIdx + a) % HOSTS.length;
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(HOSTS[idx] + path).openConnection();
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(30000);
                conn.setRequestProperty("User-Agent", "NohmanTradingBot/3.0");
                int code = conn.getResponseCode();
                if (code == 200) {
                    String s = read(conn);
                    hostIdx = idx;
                    return s;
                }
                if (code == 429 || code == 418) throw new HardFail("Binance rate limit (" + code + "), thora wait");
                if (code == 400) throw new HardFail("Yeh coin Binance spot (USDT) par nahi mila");
                last = new IOException("HTTP " + code);
            } catch (HardFail e) {
                throw e;
            } catch (IOException e) {
                last = e;
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
        throw last;
    }

    /** Runs one scan. Returns a short status line. */
    public static String runOnce(Context ctx) throws Exception {
        String tf = Prefs.timeframe(ctx);
        int top = Prefs.topCoins(ctx);
        double minVol = Prefs.minVolMillion(ctx) * 1_000_000.0;
        int buyTh = Prefs.buyThreshold(ctx);
        int sellTh = Prefs.sellThreshold(ctx);
        double volMult = Prefs.volMult(ctx);
        boolean smart = Prefs.smartMoney(ctx);
        boolean strong = Prefs.strongConfirm(ctx);
        double whaleUsd = Prefs.whaleUsd(ctx);

        String[] fg = SmartMoney.fearGreed();
        int fgVal = -1;
        if (fg != null) {
            try { fgVal = Integer.parseInt(fg[0]); } catch (Exception ignored) { }
        }

        boolean btcBull = true;
        try {
            Candles b = Candles.fetch("BTCUSDT", "1h", 120, true);
            btcBull = Analyzer.isBullish(b.close);
        } catch (Exception ignored) {
        }

        JSONArray tick = new JSONArray(get("/api/v3/ticker/24hr?type=MINI"));
        List<JSONObject> coins = new ArrayList<>();
        Map<String, JSONObject> all = new HashMap<>();
        for (int i = 0; i < tick.length(); i++) {
            JSONObject t = tick.getJSONObject(i);
            String s = t.optString("symbol");
            if (!isTradable(s) || t.optDouble("lastPrice", 0) <= 0) continue;
            all.put(s, t);
            if (t.optDouble("quoteVolume", 0) < minVol) continue;
            coins.add(t);
        }
        Collections.sort(coins, (a, b2) -> Double.compare(b2.optDouble("quoteVolume", 0), a.optDouble("quoteVolume", 0)));
        if (coins.size() > top) coins = new ArrayList<>(coins.subList(0, top));
        Set<String> have = new HashSet<>();
        for (JSONObject t : coins) have.add(t.optString("symbol"));
        for (String w : Prefs.watchlist(ctx)) {
            if (!have.contains(w) && all.containsKey(w)) coins.add(all.get(w));
        }

        int scanned = 0, alerts = 0;
        for (JSONObject t : coins) {
            if (!ScannerService.running) break;
            String sym = t.optString("symbol");
            try {
                Candles k = Candles.fetch(sym, tf, 200, true);
                Analyzer.Result r = Analyzer.analyze(k.open, k.close, k.vol, k.takerBuy, volMult);
                scanned++;
                if (smart && (r.buyScore >= buyTh - 3 || r.sellScore >= sellTh - 3)) {
                    SmartMoney.enrich(sym, r, whaleUsd, true);
                }
                if (fgVal >= 80) {
                    r.buyScore -= 1;
                    r.buyReasons.add("Market Extreme Greed (" + fgVal + ") — ehtiyat");
                } else if (fgVal >= 0 && fgVal <= 20 && r.buyScore > 0) {
                    r.buyReasons.add("Market Extreme Fear (" + fgVal + ") — aksar achha entry time");
                }
                boolean buyCand = r.buyScore >= buyTh && (btcBull || !Prefs.btcFilter(ctx) || sym.equals("BTCUSDT"));
                boolean sellCand = !buyCand && r.sellScore >= sellTh && r.volumeOutflow;
                if (buyCand || sellCand) {
                    String side = buyCand ? "BUY" : "SELL";
                    if (Prefs.cooldownOk(ctx, sym, side)) {
                        int score = buyCand ? r.buyScore : r.sellScore;
                        String why = join(buyCand ? r.buyReasons : r.sellReasons);
                        boolean confirmed = false, reject = false;
                        if (strong) {
                            try {
                                CoinReport rep = CoinReport.build(sym, "", whaleUsd, false);
                                if (buyCand && rep.total < 60) reject = true;
                                if (sellCand && rep.total > 42) reject = true;
                                if (!reject) {
                                    score = rep.total;
                                    confirmed = true;
                                    why = "✅ Strong score " + rep.total + "/100 (" + rep.verdict + ") · " + rep.flowLabel + "\n" + why;
                                }
                            } catch (HardFail e) {
                                throw e;
                            } catch (Exception ignored) {
                                // all-source check failed -> fall back to the basic signal
                            }
                        }
                        if (!reject) {
                            Prefs.markCooldown(ctx, sym, side);
                            alert(ctx, side, sym, r.price, score, why, tf, confirmed);
                            alerts++;
                        }
                    }
                }
            } catch (InterruptedException e) {
                throw e;
            } catch (HardFail e) {
                if (e.getMessage() != null && e.getMessage().startsWith("Binance rate limit")) Thread.sleep(60_000);
            } catch (Exception ignored) {
            }
            Thread.sleep(120);
        }

        String time = new SimpleDateFormat("HH:mm", Locale.US).format(new Date());
        return "Last scan " + time + " · " + scanned + " coins (" + tf + ") · " + alerts
                + " naye signal · BTC " + (btcBull ? "bullish ✅" : "bearish ⚠️")
                + (fg != null ? " · Fear&Greed " + fg[0] + " (" + fg[1] + ")" : "");
    }

    private static String join(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (String s : l) {
            if (sb.length() > 0) sb.append("\n");
            sb.append("• ").append(s);
        }
        return sb.toString();
    }

    static String fmtPrice(double p) {
        if (p >= 100) return String.format(Locale.US, "%.2f", p);
        if (p >= 1) return String.format(Locale.US, "%.4f", p);
        if (p >= 0.01) return String.format(Locale.US, "%.5f", p);
        return String.format(Locale.US, "%.8f", p);
    }

    private static void alert(Context ctx, String side, String sym, double price, int score, String why,
                              String tf, boolean strong) {
        Prefs.addSignal(ctx, side, sym, price, score, why);
        String base = sym.substring(0, sym.length() - 4);

        Intent open = new Intent(ctx, MainActivity.class);
        open.putExtra("coin", sym);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(ctx, (sym + side).hashCode(), open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.binance.com/en/trade/" + base + "_USDT?type=spot"));
        PendingIntent wpi = PendingIntent.getActivity(ctx, (sym + "web").hashCode(), web,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        String title;
        if ("BUY".equals(side)) title = (strong ? "🚀 STRONG BUY: " : "🟢 BUY signal: ") + base + "/USDT";
        else title = (strong ? "🚨 STRONG SELL: " : "🔴 SELL (paisa nikal raha): ") + base + "/USDT";
        String text = "Price " + fmtPrice(price) + " · Score " + score + (strong ? "/100" : "") + " · " + tf;

        Notification n = new Notification.Builder(ctx, CH_SIGNALS)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text + "\n" + why))
                .setContentIntent(pi)
                .addAction(new Notification.Action.Builder(null, "Binance kholen", wpi).build())
                .setAutoCancel(true)
                .build();
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify((sym + side).hashCode(), n);
    }
}
