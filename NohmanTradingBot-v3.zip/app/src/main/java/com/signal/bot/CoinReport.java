package com.signal.bot;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Full analysis of ONE coin. Combines every free source into one 0-100 score:
 *  1. Technical on 4 timeframes (Binance klines)            weight 30
 *  2. Money flow: taker buy/sell, CVD, OBV, volume change     weight 20
 *  3. Whales: big trades + order book walls                   weight 20
 *  4. Futures smart money: OI, top traders, funding, retail   weight 15
 *  5. Sentiment: Fear&Greed, CoinGecko votes, news tone       weight 10
 *  6. On-chain: Glassnode exchange flow (only with API key)   weight 10
 * Sections that fail or are not available are left out of the average.
 */
public final class CoinReport {

    public static final class Section {
        public final String icon, title;
        public final int weight;
        public int score;               // -100 .. +100
        public boolean available = true;
        public final List<String> lines = new ArrayList<>();

        Section(String icon, String title, int weight) {
            this.icon = icon;
            this.title = title;
            this.weight = weight;
        }

        void add(String s) { lines.add(s); }
    }

    public String symbol, base, name;
    public double price, change24h, quoteVol24h, high24h, low24h;
    public int total = 50;
    public String verdict = "WAIT", verdictText = "";
    public double buyPct = 50;
    public String flowLabel = "⚖️ Mixed";
    public int flowSign = 0;
    public double support, resistance, atr, stop, target1, target2;
    public final List<Section> sections = new ArrayList<>();
    /** {title, link, source, tone(+,-,"")} */
    public final List<String[]> news = new ArrayList<>();
    private int newsPos, newsNeg;

    private CoinReport() {}

    /** "sol", "SOL/USDT", "solusdt" -> "SOLUSDT" */
    public static String normalize(String in) {
        String s = in == null ? "" : in.toUpperCase(Locale.US).replaceAll("[^A-Z0-9]", "");
        if (s.endsWith("USDT") && s.length() > 4) return s;
        return s + "USDT";
    }

    /** full = also CoinGecko, news, Glassnode (slower; used when the user analyses a coin). */
    public static CoinReport build(String symbol, String glassKey, double whaleUsd, boolean full) throws Exception {
        CoinReport r = new CoinReport();
        r.symbol = symbol;
        r.base = symbol.substring(0, symbol.length() - 4);
        r.name = r.base;

        JSONObject t = new JSONObject(Scanner.get("/api/v3/ticker/24hr?symbol=" + symbol));
        r.price = t.optDouble("lastPrice", 0);
        r.change24h = t.optDouble("priceChangePercent", 0);
        r.quoteVol24h = t.optDouble("quoteVolume", 0);
        r.high24h = t.optDouble("highPrice", 0);
        r.low24h = t.optDouble("lowPrice", 0);

        Candles c15 = Candles.fetch(symbol, "15m", 200, true);
        Candles c1h = Candles.fetch(symbol, "1h", 200, true);
        Candles c4h = Candles.fetch(symbol, "4h", 200, true);
        Candles c1d = Candles.fetch(symbol, "1d", 200, true);

        r.technical(new Candles[]{c15, c1h, c4h, c1d});
        r.moneyFlow(c1h);
        r.whales(whaleUsd);
        r.futures();
        r.sentiment(full);
        if (full) r.onChain(glassKey);
        r.levels(c1h, c4h);
        r.finish();
        return r;
    }

    // ------------------------------------------------------------------ 1. technical
    private void technical(Candles[] cs) {
        Section s = new Section("📈", "Technical (15m · 1h · 4h · 1d)", 30);
        String[] tfs = {"15m", "1h", "4h", "1d"};
        int[] w = {1, 2, 3, 2};
        double sum = 0, ws = 0;
        Analyzer.Result main = null;
        for (int i = 0; i < cs.length; i++) {
            Candles c = cs[i];
            if (c.n < 60) {
                s.add(tfs[i] + ": data kam hai (naya coin)");
                continue;
            }
            Analyzer.Result a = Analyzer.analyze(c.open, c.close, c.vol, c.takerBuy, 2.0);
            int net = a.buyScore - a.sellScore;
            boolean up = Analyzer.isBullish(c.close);
            s.add(String.format(Locale.US, "%s: %s · RSI %.0f · net %+d", tfs[i],
                    up ? "Uptrend ⬆️" : "Downtrend ⬇️", a.rsi, net));
            double v = Fmt.clamp(net / 6.0 + (up ? 0.2 : -0.2), -1, 1);
            sum += v * w[i];
            ws += w[i];
            if (i == 1) main = a;
        }
        if (main != null) {
            List<String> rs = main.buyScore >= main.sellScore ? main.buyReasons : main.sellReasons;
            for (int k = 0; k < rs.size() && k < 4; k++) s.add("1h: " + rs.get(k));
        }
        s.available = ws > 0;
        s.score = ws > 0 ? (int) Math.round(sum / ws * 100) : 0;
        sections.add(s);
    }

    // ------------------------------------------------------------------ 2. money flow
    private void moneyFlow(Candles c) {
        Section s = new Section("💰", "Money flow — paisa aa raha / nikal raha", 20);
        int n = c.n;
        if (n < 30) {
            s.available = false;
            s.add("Data kam hai");
            sections.add(s);
            return;
        }
        int from = n - 24;
        double v = 0, b = 0, cvd = 0, prev = 0, v4 = 0, b4 = 0;
        for (int i = from; i < n; i++) {
            v += c.vol[i];
            b += c.takerBuy[i];
            cvd += (2 * c.takerBuy[i] - c.vol[i]) * c.close[i];
        }
        for (int i = Math.max(0, n - 48); i < from; i++) prev += c.vol[i];
        for (int i = n - 4; i < n; i++) {
            v4 += c.vol[i];
            b4 += c.takerBuy[i];
        }
        buyPct = v > 0 ? b / v * 100 : 50;
        double buy4 = v4 > 0 ? b4 / v4 * 100 : 50;
        double volChg = prev > 0 ? (v / prev - 1) * 100 : 0;
        double[] obv = Indicators.obv(c.close, c.vol);
        boolean obvUp = obv[n - 1] > obv[from];

        double sc = Fmt.clamp((buyPct - 50) / 6.0, -1, 1) * 0.5
                + Fmt.clamp((buy4 - 50) / 8.0, -1, 1) * 0.25
                + (obvUp ? 0.25 : -0.25);
        if (volChg > 30) sc *= 1.2;
        s.score = (int) Math.round(Fmt.clamp(sc, -1, 1) * 100);

        if (buyPct >= 52.5 && obvUp) {
            flowLabel = "💰 Paisa AA raha hai (accumulation)";
            flowSign = 1;
        } else if (buyPct <= 47.5 && !obvUp) {
            flowLabel = "🚨 Paisa NIKAL raha hai (distribution)";
            flowSign = -1;
        } else {
            flowLabel = "⚖️ Mixed — abhi saaf direction nahi";
            flowSign = 0;
        }
        s.add(String.format(Locale.US, "24h: Buyers %.0f%% · Sellers %.0f%%", buyPct, 100 - buyPct));
        s.add(String.format(Locale.US, "Pichhle 4 ghante: Buyers %.0f%%", buy4));
        s.add("Net buy − sell (CVD 24h): " + (cvd >= 0 ? "+" : "") + Fmt.usd(cvd));
        s.add(String.format(Locale.US, "Volume 24h vs pichhle 24h: %+.0f%%", volChg));
        s.add("OBV: " + (obvUp ? "upar ja raha (accumulation)" : "neeche ja raha (distribution)"));
        sections.add(s);
    }

    // ------------------------------------------------------------------ 3. whales
    private void whales(double whaleUsd) {
        Section s = new Section("🐋", "Whales & order book", 20);
        double thr = Math.min(whaleUsd, Math.max(5000, quoteVol24h / 2000));
        double part1 = 0, part2 = 0;
        boolean got1 = false, got2 = false;
        try {
            JSONArray tr = new JSONArray(Scanner.get("/api/v3/aggTrades?symbol=" + symbol + "&limit=1000"));
            double wb = 0, wsl = 0;
            int cb = 0, csl = 0;
            long t0 = Long.MAX_VALUE, t1 = 0;
            for (int i = 0; i < tr.length(); i++) {
                JSONObject o = tr.getJSONObject(i);
                double usd = Double.parseDouble(o.getString("p")) * Double.parseDouble(o.getString("q"));
                long tt = o.optLong("T");
                t0 = Math.min(t0, tt);
                t1 = Math.max(t1, tt);
                if (usd < thr) continue;
                if (o.optBoolean("m")) { wsl += usd; csl++; } else { wb += usd; cb++; }
            }
            long mins = tr.length() > 1 ? Math.max(1, (t1 - t0) / 60000) : 0;
            s.add("Pichhle ~" + mins + " min ke " + tr.length() + " trades mein " + Fmt.usd(thr) + "+ ke orders:");
            s.add("🟢 Whale BUY: " + cb + " orders · " + Fmt.usd(wb));
            s.add("🔴 Whale SELL: " + csl + " orders · " + Fmt.usd(wsl));
            if (wb + wsl > 0) {
                part1 = (wb - wsl) / (wb + wsl);
                got1 = true;
            } else {
                s.add("Is waqt koi bada whale order nahi");
            }
        } catch (Exception e) {
            s.add("Whale trades load nahi huay");
        }
        try {
            JSONObject d = new JSONObject(Scanner.get("/api/v3/depth?symbol=" + symbol + "&limit=500"));
            JSONArray bids = d.getJSONArray("bids"), asks = d.getJSONArray("asks");
            double lo = price * 0.98, hi = price * 1.02;
            double bidUsd = 0, askUsd = 0, bw = 0, bwp = 0, aw = 0, awp = 0;
            for (int i = 0; i < bids.length(); i++) {
                JSONArray x = bids.getJSONArray(i);
                double p = Double.parseDouble(x.getString(0)), q = Double.parseDouble(x.getString(1));
                if (p < lo) break;
                double u = p * q;
                bidUsd += u;
                if (u > bw) { bw = u; bwp = p; }
            }
            for (int i = 0; i < asks.length(); i++) {
                JSONArray x = asks.getJSONArray(i);
                double p = Double.parseDouble(x.getString(0)), q = Double.parseDouble(x.getString(1));
                if (p > hi) break;
                double u = p * q;
                askUsd += u;
                if (u > aw) { aw = u; awp = p; }
            }
            s.add("Order book ±2%: Buy side " + Fmt.usd(bidUsd) + " · Sell side " + Fmt.usd(askUsd));
            if (bw > 0) s.add("Sab se bada BUY wall: " + Fmt.usd(bw) + " @ $" + Fmt.price(bwp));
            if (aw > 0) s.add("Sab se bada SELL wall: " + Fmt.usd(aw) + " @ $" + Fmt.price(awp));
            if (bidUsd + askUsd > 0) {
                part2 = (bidUsd - askUsd) / (bidUsd + askUsd);
                got2 = true;
            }
        } catch (Exception e) {
            s.add("Order book load nahi hua");
        }
        double sc = 0, w = 0;
        if (got1) { sc += part1 * 0.6; w += 0.6; }
        if (got2) { sc += part2 * 0.4; w += 0.4; }
        s.available = w > 0;
        s.score = w > 0 ? (int) Math.round(Fmt.clamp(sc / w, -1, 1) * 100) : 0;
        sections.add(s);
    }

    // ------------------------------------------------------------------ 4. futures
    private void futures() {
        Section s = new Section("👑", "Futures smart money (bade traders)", 15);
        final String F = "https://fapi.binance.com";
        double sc = 0, w = 0;
        try {
            JSONObject p = new JSONObject(Scanner.getAbsolute(F + "/fapi/v1/premiumIndex?symbol=" + symbol));
            double fr = p.optDouble("lastFundingRate", 0) * 100;
            s.add(String.format(Locale.US, "Funding rate: %.4f%% %s", fr,
                    fr > 0.05 ? "(longs bahut zyada — khatra)" : fr < -0.01 ? "(shorts zyada — short squeeze ho sakta)" : "(normal)"));
            sc += -Fmt.clamp(fr / 0.05, -1, 1) * 0.15;
            w += 0.15;
        } catch (Exception e) {
            s.available = false;
            s.add("Is coin ka Binance Futures market nahi — yeh hissa skip");
            sections.add(s);
            return;
        }
        try {
            JSONArray a = new JSONArray(Scanner.getAbsolute(F + "/futures/data/openInterestHist?symbol=" + symbol + "&period=1h&limit=25"));
            if (a.length() >= 2) {
                double first = a.getJSONObject(0).optDouble("sumOpenInterestValue", 0);
                double last = a.getJSONObject(a.length() - 1).optDouble("sumOpenInterestValue", 0);
                if (first > 0) {
                    double ch = (last / first - 1) * 100;
                    double v;
                    String m;
                    if (ch >= 2 && change24h > 0) { v = 1; m = "naya paisa LONG mein aa raha ✅"; }
                    else if (ch >= 2 && change24h < 0) { v = -1; m = "naye SHORTS aa rahe ⚠️"; }
                    else if (ch <= -2 && change24h < 0) { v = -0.5; m = "paisa futures se nikal raha"; }
                    else if (ch <= -2 && change24h > 0) { v = 0.3; m = "shorts band ho rahe (short squeeze)"; }
                    else { v = 0; m = "koi bada farq nahi"; }
                    s.add(String.format(Locale.US, "Open interest 24h: %+.1f%% (%s) — %s", ch, Fmt.usd(last), m));
                    sc += v * 0.3;
                    w += 0.3;
                }
            }
        } catch (Exception ignored) {
        }
        try {
            JSONArray a = new JSONArray(Scanner.getAbsolute(F + "/futures/data/topLongShortPositionRatio?symbol=" + symbol + "&period=1h&limit=24"));
            if (a.length() >= 2) {
                double first = a.getJSONObject(0).optDouble("longShortRatio", 0);
                double last = a.getJSONObject(a.length() - 1).optDouble("longShortRatio", 0);
                if (first > 0) {
                    s.add(String.format(Locale.US, "Top traders long/short: %.2f → %.2f %s", first, last,
                            last > first * 1.03 ? "(long badha rahe ✅)" : last < first * 0.97 ? "(long kam kar rahe ⚠️)" : "(same)"));
                    double v = Fmt.clamp((last - first) / first / 0.08, -1, 1) * 0.7 + (last > 1.2 ? 0.3 : last < 0.9 ? -0.3 : 0);
                    sc += v * 0.3;
                    w += 0.3;
                }
            }
        } catch (Exception ignored) {
        }
        try {
            JSONArray a = new JSONArray(Scanner.getAbsolute(F + "/futures/data/globalLongShortAccountRatio?symbol=" + symbol + "&period=1h&limit=1"));
            if (a.length() > 0) {
                double g = a.getJSONObject(0).optDouble("longShortRatio", 1);
                s.add(String.format(Locale.US, "Aam traders (retail) long/short: %.2f %s", g,
                        g > 2.5 ? "(sab long — aksar ulta hota hai)" : g < 0.8 ? "(sab short — squeeze mumkin)" : ""));
                sc += (g > 2.5 ? -0.5 : g < 0.8 ? 0.5 : 0) * 0.1;
                w += 0.1;
            }
        } catch (Exception ignored) {
        }
        try {
            JSONArray a = new JSONArray(Scanner.getAbsolute(F + "/futures/data/takerlongshortRatio?symbol=" + symbol + "&period=1h&limit=6"));
            if (a.length() > 0) {
                double sum = 0;
                for (int i = 0; i < a.length(); i++) sum += a.getJSONObject(i).optDouble("buySellRatio", 1);
                double avg = sum / a.length();
                s.add(String.format(Locale.US, "Futures taker buy/sell (6h): %.2f %s", avg,
                        avg > 1.05 ? "(buyers aggressive)" : avg < 0.95 ? "(sellers aggressive)" : ""));
                sc += Fmt.clamp((avg - 1) / 0.15, -1, 1) * 0.15;
                w += 0.15;
            }
        } catch (Exception ignored) {
        }
        s.score = w > 0 ? (int) Math.round(Fmt.clamp(sc / w, -1, 1) * 100) : 0;
        sections.add(s);
    }

    // ------------------------------------------------------------------ 5. sentiment
    private void sentiment(boolean full) {
        Section s = new Section("🧠", "Market ki raaye (sentiment · news · community)", 10);
        double sc = 0, w = 0;
        String[] fg = SmartMoney.fearGreed();
        if (fg != null) {
            int v = 50;
            try { v = Integer.parseInt(fg[0]); } catch (Exception ignored) { }
            s.add("Fear & Greed: " + v + " (" + fg[1] + ")"
                    + (v <= 25 ? " — dar ka mahol, smart money aksar yahan khareedti hai"
                    : v >= 75 ? " — lalach zyada, correction ka khatra" : ""));
            sc += (v <= 25 ? 0.4 : v >= 75 ? -0.4 : 0) * 0.3;
            w += 0.3;
        }
        if (full) {
            try {
                JSONObject sr = new JSONObject(Scanner.getAbsolute(
                        "https://api.coingecko.com/api/v3/search?query=" + URLEncoder.encode(base, "UTF-8")));
                JSONArray coins = sr.getJSONArray("coins");
                String id = null;
                int best = Integer.MAX_VALUE;
                for (int i = 0; i < coins.length(); i++) {
                    JSONObject o = coins.getJSONObject(i);
                    if (!base.equalsIgnoreCase(o.optString("symbol"))) continue;
                    int rank = o.optInt("market_cap_rank", 0);
                    if (rank <= 0) rank = 100000;
                    if (rank < best) {
                        best = rank;
                        id = o.optString("id");
                        name = o.optString("name", base);
                    }
                }
                if (id != null) {
                    JSONObject cg = new JSONObject(Scanner.getAbsolute("https://api.coingecko.com/api/v3/coins/" + id
                            + "?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false&sparkline=false"));
                    double up = cg.optDouble("sentiment_votes_up_percentage", -1);
                    int rank = cg.optInt("market_cap_rank", 0);
                    if (rank > 0) s.add("Market cap rank: #" + rank);
                    if (up >= 0) {
                        s.add(String.format(Locale.US, "CoinGecko community: %.0f%% bullish · %.0f%% bearish", up, 100 - up));
                        sc += Fmt.clamp((up - 50) / 30, -1, 1) * 0.3;
                        w += 0.3;
                    }
                    JSONObject md = cg.optJSONObject("market_data");
                    if (md != null) {
                        s.add(String.format(Locale.US, "7 din: %+.1f%% · 30 din: %+.1f%%",
                                md.optDouble("price_change_percentage_7d", 0), md.optDouble("price_change_percentage_30d", 0)));
                        JSONObject ath = md.optJSONObject("ath_change_percentage");
                        if (ath != null) s.add(String.format(Locale.US, "All-time high se: %.0f%%", ath.optDouble("usd", 0)));
                    }
                }
            } catch (Exception e) {
                s.add("CoinGecko abhi busy hai (thori der baad dobara try karein)");
            }
            fetchNews();
            if (!news.isEmpty()) {
                s.add("News: " + news.size() + " khabrein · " + newsPos + " positive · " + newsNeg + " negative");
                if (newsPos + newsNeg > 0) {
                    sc += Fmt.clamp((newsPos - newsNeg) / (double) (newsPos + newsNeg), -1, 1) * 0.4;
                    w += 0.4;
                }
            } else {
                s.add("Is coin ki koi taaza khabar nahi mili");
            }
        }
        s.available = w > 0;
        s.score = w > 0 ? (int) Math.round(Fmt.clamp(sc / w, -1, 1) * 100) : 0;
        sections.add(s);
    }

    private static final String[] FEEDS = {
            "https://cointelegraph.com/rss",
            "https://www.coindesk.com/arc/outboundfeeds/rss/",
            "https://decrypt.co/feed"
    };
    private static final String[] POS = {"surge", "soar", "rally", "jump", "gain", "bull", "record", "approv",
            "partnership", "launch", "upgrade", "adopt", "inflow", "breakout", "listing", "etf", "rebound", "climb"};
    private static final String[] NEG = {"drop", "plunge", "crash", "fall", "bear", "hack", "exploit", "lawsuit",
            "delist", "outflow", "dump", "sell-off", "selloff", "banned", "fraud", "slump", "liquidat", "warn", "decline"};

    private void fetchNews() {
        List<Pattern> pats = new ArrayList<>();
        if (name != null && name.length() >= 3)
            pats.add(Pattern.compile("\\b" + Pattern.quote(name) + "\\b", Pattern.CASE_INSENSITIVE));
        if (base.length() >= 3) pats.add(Pattern.compile("\\b" + Pattern.quote(base) + "\\b"));
        if (pats.isEmpty()) return;
        Pattern item = Pattern.compile("<item>(.*?)</item>", Pattern.DOTALL);
        Pattern title = Pattern.compile("<title>(?:<!\\[CDATA\\[)?(.*?)(?:\\]\\]>)?</title>", Pattern.DOTALL);
        Pattern link = Pattern.compile("<link>(?:<!\\[CDATA\\[)?(.*?)(?:\\]\\]>)?</link>", Pattern.DOTALL);
        for (String f : FEEDS) {
            if (news.size() >= 8) break;
            try {
                String xml = Scanner.getAbsolute(f);
                String src = f.contains("cointelegraph") ? "Cointelegraph" : f.contains("coindesk") ? "CoinDesk" : "Decrypt";
                Matcher m = item.matcher(xml);
                while (m.find() && news.size() < 8) {
                    String it = m.group(1);
                    Matcher tm = title.matcher(it);
                    if (!tm.find()) continue;
                    String tt = unescape(tm.group(1).trim());
                    boolean hit = false;
                    for (Pattern p : pats) if (p.matcher(tt).find()) { hit = true; break; }
                    if (!hit) continue;
                    Matcher lm = link.matcher(it);
                    String ln = lm.find() ? lm.group(1).trim() : "";
                    String low = tt.toLowerCase(Locale.US);
                    int p = 0, q = 0;
                    for (String k : POS) if (low.contains(k)) p++;
                    for (String k : NEG) if (low.contains(k)) q++;
                    String tone = p > q ? "+" : q > p ? "-" : "";
                    if (p > q) newsPos++;
                    else if (q > p) newsNeg++;
                    news.add(new String[]{tt, ln, src, tone});
                }
            } catch (Exception ignored) {
            }
        }
    }

    private static String unescape(String s) {
        return s.replace("&amp;", "&").replace("&#039;", "'").replace("&#39;", "'").replace("&quot;", "\"")
                .replace("&lt;", "<").replace("&gt;", ">").replace("&#8217;", "'").replace("&#8216;", "'")
                .replace("&#8220;", "\"").replace("&#8221;", "\"").replace("&#8211;", "–");
    }

    // ------------------------------------------------------------------ 6. on-chain
    private void onChain(String key) {
        Section s = new Section("⛓️", "On-chain (Glassnode)", 10);
        if (key == null || key.trim().isEmpty()) {
            s.available = false;
            s.add("Glassnode API key Settings mein daalein. Note: Glassnode ki API sirf paid plan par milti hai.");
            sections.add(s);
            return;
        }
        double sc = 0, w = 0;
        long since = System.currentTimeMillis() / 1000 - 8 * 86400L;
        String k;
        try { k = URLEncoder.encode(key.trim(), "UTF-8"); } catch (Exception e) { k = key.trim(); }
        String q = "?a=" + base + "&i=24h&s=" + since + "&api_key=" + k;
        try {
            JSONArray arr = new JSONArray(Scanner.getAbsolute("https://api.glassnode.com/v1/metrics/transactions/transfers_volume_exchanges_net" + q));
            if (arr.length() > 0) {
                double sum = 0, last = 0;
                for (int i = 0; i < arr.length(); i++) {
                    last = arr.getJSONObject(i).optDouble("v", 0);
                    sum += last;
                }
                s.add("Exchange net flow 7d: " + Fmt.num(sum) + " " + base
                        + (sum < 0 ? " — coins exchanges se NIKAL rahe (holding, bullish) ✅" : " — coins exchanges par AA rahe (bechne ki tayyari?) ⚠️"));
                s.add("Kal ka net flow: " + Fmt.num(last) + " " + base);
                sc += (sum < 0 ? 0.6 : -0.6) + (last < 0 ? 0.4 : -0.4);
                w += 1;
            }
        } catch (Exception e) {
            s.add("Exchange flow nahi mila (" + e.getMessage() + ")");
        }
        try {
            JSONArray arr = new JSONArray(Scanner.getAbsolute("https://api.glassnode.com/v1/metrics/addresses/active_count" + q));
            if (arr.length() >= 2) {
                double first = arr.getJSONObject(0).optDouble("v", 0);
                double last = arr.getJSONObject(arr.length() - 1).optDouble("v", 0);
                if (first > 0) {
                    double ch = (last / first - 1) * 100;
                    s.add(String.format(Locale.US, "Active addresses 7d: %+.1f%%", ch));
                    sc += Fmt.clamp(ch / 10, -1, 1) * 0.5;
                    w += 0.5;
                }
            }
        } catch (Exception ignored) {
        }
        if (w == 0) {
            s.available = false;
            s.add("Glassnode ne data nahi diya — key/plan check karein, ya yeh coin Glassnode par nahi");
        }
        s.score = w > 0 ? (int) Math.round(Fmt.clamp(sc / w, -1, 1) * 100) : 0;
        sections.add(s);
    }

    // ------------------------------------------------------------------ levels + final
    private void levels(Candles c1h, Candles c4h) {
        atr = Indicators.atr(c1h.high, c1h.low, c1h.close, 14);
        double lo = Double.MAX_VALUE, hi = 0;
        for (int i = Math.max(0, c4h.n - 30); i < c4h.n; i++) {
            lo = Math.min(lo, c4h.low[i]);
            hi = Math.max(hi, c4h.high[i]);
        }
        support = lo == Double.MAX_VALUE ? low24h : lo;
        resistance = hi == 0 ? high24h : hi;
    }

    private void finish() {
        double s = 0, w = 0;
        for (Section sec : sections) {
            if (!sec.available) continue;
            s += sec.score * sec.weight;
            w += sec.weight;
        }
        double avg = w > 0 ? s / w : 0;
        total = (int) Math.round(Fmt.clamp(50 + avg / 2, 0, 100));
        if (total >= 72) {
            verdict = "STRONG BUY";
            verdictText = "Zyada tar sources upar jaane ka ishara de rahe hain — volume aur smart money saath hain.";
        } else if (total >= 58) {
            verdict = "BUY";
            verdictText = "Halka bullish. Chhoti entry, stop-loss ke saath.";
        } else if (total > 42) {
            verdict = "WAIT";
            verdictText = "Saaf direction nahi — intezar behtar hai.";
        } else if (total > 28) {
            verdict = "SELL";
            verdictText = "Kamzori — naya khareedna theek nahi; holding ho to stop tight karein.";
        } else {
            verdict = "STRONG SELL";
            verdictText = "Paisa nikal raha hai aur trend neeche — door rahein / profit bacha lein.";
        }
        if (atr > 0) {
            stop = Math.max(price - 1.5 * atr, price * 0.5);
            target1 = price + 2.25 * atr;
            target2 = price + 4.5 * atr;
        }
    }
}
