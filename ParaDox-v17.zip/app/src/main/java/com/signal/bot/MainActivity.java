package com.signal.bot;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    static final int CARD = 0xFF141B2B, CHIP = 0xFF1C2638, STROKE = 0xFF263352,
            TEXT = 0xFFE8EAED, SOFT = 0xFFC9D1DC, MUTED = 0xFF8B95A7,
            GREEN = 0xFF0ECB81, RED = 0xFFF6465D, YELLOW = 0xFFFFC94D, INK = 0xFF0A0E17, CLAUDE = 0xFFD97757,
            CYAN_TXT = 0xFF22D3EE;

    private int uiMode;
    private int ACC, ACC2;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private final View[] pages = new View[9];
    static final int TAB_MARKET = 0, TAB_ANALYZE = 1, TAB_SIGNALS = 2, TAB_WALLET = 3, TAB_BIG = 4, TAB_LISTINGS = 5, TAB_SETTINGS = 6,
            TAB_HOME = 7, TAB_MORE = 8;
    static final String[] PAGE_TITLE = {"Markets", "Analysis", "Signals", "Portfolio", "Institutions", "News & Calendar", "Settings", "Dashboard", "More"};
    // bottom navigation: Home · Markets · Analysis · Signals · More
    private static final int[] NAV_PAGE = {TAB_HOME, TAB_MARKET, TAB_ANALYZE, TAB_SIGNALS, TAB_MORE};
    private final LinearLayout[] navItems = new LinearLayout[5];
    private final TextView[] navIcon = new TextView[5], navLabel = new TextView[5];
    private TextView pageTitle, backBtn;

    // Home dashboard
    private LinearLayout homeBox;
    private String[] lastFg;
    private MacroEngine.Pulse homePulse;
    private List<MacroEngine.Event> homeEvents;

    // generic full-page overlay (wallet details etc.)
    private LinearLayout infoOverlay;

    // full-screen chart
    private ChartView fsChart;
    private boolean fsTfSwitch;
    static final String[] IND = {"MA Ribbon", "ParaDox", "Crosses", "EMA", "EMA200", "VWAP", "BB", "Volume", "RSI", "MACD", "Fib", "Patterns", "Zones", "VolProfile", "Whales", "Retail"};
    private String fsTitle = "Chart";

    // v11: three markets (crypto · gold & commodities · forex)
    private int mktSeg = 0;
    private final TextView[] mktSegChips = new TextView[3];
    private LinearLayout cryptoWrap, assetWrap, assetList;
    private TextView assetStatus, assetHead;
    private final Map<String, YahooData.Quote> assetQ = new HashMap<>();
    private long assetLoadedAt;
    private int assetLoadedSeg = -1;
    private int sigSeg = 0;
    private final TextView[] sigSegChips = new TextView[3];
    private LinearLayout cryptoBotBox, assetBotBox;
    private Button assetBotBtn;
    private TextView assetBotStatus;
    private CheckBox accCb;
    private EditText minWrEt, cpEt, spotSellEt, scalpHeavyEt, cmEt;
    private LinearLayout newsList, newsOverlayRef;
    private TextView newsStatus;
    private int newsFilter = 0;
    private String newsQuery = "";

    // Wallet tracker
    private LinearLayout walletList;
    private TextView walletTotal, walletNet;
    private EditText walLabelEt, walAddrEt;
    private long walletsLoadedAt;

    // Big players
    private LinearLayout bigBox, bigMovesBox;
    private TextView bigStatus;
    private long bigLoadedAt;
    private final TextView[] bigMinChips = new TextView[5];
    private static final long[] BIG_MINS = {10_000_000L, 50_000_000L, 100_000_000L, 500_000_000L, 1_000_000_000L};

    // Settings extras
    private EditText minConfEt, quietFromEt, quietToEt;
    private CheckBox quietCb;

    // Macro / economic news
    private LinearLayout macroCol, listCol, macroBox, pulseBox;
    private TextView macroLine;
    private boolean macroHighOnly = true, showMacro = true;
    private long macroLoadedAt;
    private TextView[] newsSeg = new TextView[2];

    // Listings
    private LinearLayout listingBox;
    private TextView listingStatus;
    private long listingsLoadedAt;

    // Signal screen (live chart for one signal)
    private LinearLayout sigOverlay;
    private LiveChart sigLive;
    private int currentTab = -1;
    private TextView liveDot;
    private FrameLayout rootFrame;
    private boolean resumed;

    // in-app update
    private LinearLayout updateBanner;
    private TextView updStatus;
    private EditText repoEt;
    private volatile boolean installing;

    // Market
    private GaugeView fgGauge;
    private TextView btcView, globalView, marketCount;
    private EditText marketSearch;
    private LinearLayout marketList;
    private final TextView[] modeChips = new TextView[5];
    private int marketMode = 0, marketLimit = 50;
    private final Map<String, double[]> mk = new HashMap<>();          // sym -> {last, open, quoteVol}
    private final Map<String, TextView[]> rowViews = new HashMap<>();  // sym -> {price, pct}
    private WsStream marketWs;
    private final Map<String, double[]> pendingMini = new HashMap<>();
    private long marketLoadedAt;

    // Analyze
    private EditText searchEt;
    private TextView starBtn, chartTitle, livePrice;
    private String[] chartTfs;
    private TextView[] tfChips;
    private String chartTf;
    private String currentSym = "BTCUSDT";
    private ChartView chart;
    private BookView book;
    private TapeView tape;
    private LinearLayout watchRow, resultBox, fsOverlay;
    private ViewGroup chartParent;
    private int chartIndex;
    private ViewGroup.LayoutParams chartLp;
    private static final String[] LAYERS = {"Fib", "Lines", "Zones", "VolProfile", "Whales", "RSI"};
    private final TextView[] layerChips = new TextView[LAYERS.length];
    private CoinReport lastReport;

    // live coin stream
    private WsStream coinWs;
    private final Object liveLock = new Object();
    private double[] pendingKline;
    private final List<double[]> pendingTrades = new ArrayList<>();
    private double[][] pendingBids, pendingAsks;
    private boolean candleClosed;
    private volatile boolean coinLive;
    private String liveSym = "", liveTf = "";
    private double chartWhaleThr = 50000;
    private double dayOpen;

    // Signals
    private TextView statusView, statsView;
    private Button scalpBtn, spotBtn;
    private LinearLayout signalList, alertList;
    private String signalKey = "";

    // Settings
    private final EditText[][] modeFields = new EditText[2][];
    private final Spinner[] tfSpinners = new Spinner[2];
    private CheckBox btcCb, smartCb, strongCb;
    private EditText whaleEt, glassEt, claudeEt;
    private Spinner modelSpinner;

    private final Runnable refresher = new Runnable() {
        @Override
        public void run() {
            refreshStatus();
            if (currentTab == 0 && mktSeg != 0 && infoOverlay == null && System.currentTimeMillis() - assetLoadedAt > 15_000) loadAssets();
            handler.postDelayed(this, 5000);
        }
    };

    private final Runnable liveTick = new Runnable() {
        @Override
        public void run() {
            applyLive();
            applyMarketLive();
            handler.postDelayed(this, 400);
        }
    };

    // ============================================================ lifecycle
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        uiMode = Prefs.uiMode(this);
        ACC = Mode.accent(uiMode);
        ACC2 = Mode.accent2(uiMode);
        {
            List<String> tl = new ArrayList<>(java.util.Arrays.asList(Mode.chartTfs(uiMode)));
            for (String x : new String[]{"1d", "1w", "1M", "1Y", "5Y", "ALL"}) if (!tl.contains(x)) tl.add(x);
            chartTfs = tl.toArray(new String[0]);
        }
        chartTf = Mode.defaultChartTf(uiMode);
        tfChips = new TextView[chartTfs.length];
        ScannerService.createChannels(this);
        getWindow().setStatusBarColor(Mode.bgTop(uiMode));
        getWindow().setNavigationBarColor(CARD);
        currentSym = Prefs.lastCoin(this);

        rootFrame = new FrameLayout(this);
        LinearLayout root = column();
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Mode.bgTop(uiMode), Mode.bgBottom(uiMode)}));
        root.addView(header());
        FrameLayout content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));
        buildMarket();
        buildAnalyze();
        buildSignals();
        buildWallet();
        buildBig();
        buildListings();
        buildSettings();
        buildHome();
        buildMore();
        for (View p : pages) content.addView(p, new FrameLayout.LayoutParams(-1, -1));
        root.addView(bottomNav());
        rootFrame.addView(root, new FrameLayout.LayoutParams(-1, -1));
        setContentView(rootFrame);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        int startTab = savedInstanceState != null ? savedInstanceState.getInt("tab", TAB_HOME) : TAB_HOME;
        if (!handleIntent(getIntent())) showTab(startTab);
        loadChart();
        if (System.currentTimeMillis() - Prefs.lastUpdateCheck(this) > 3 * 3600_000L) checkForUpdate(false);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt("tab", currentTab);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private boolean handleIntent(Intent i) {
        if (i == null) return false;
        int tabX = i.getIntExtra("tab", -1);
        if (tabX >= 0 && tabX < pages.length) {
            i.removeExtra("tab");
            showTab(tabX);
            if (tabX == TAB_SIGNALS) {
                JSONObject first = Prefs.signals(this).optJSONObject(0);
                String mk0 = first == null ? Assets.CRYPTO : first.optString("mkt", Assets.CRYPTO);
                setSigSeg(Assets.FOREX.equals(mk0) ? 2 : Assets.COMMODITY.equals(mk0) ? 1 : 0);
            }
            return true;
        }
        if (i.getBooleanExtra("update", false)) {
            i.removeExtra("update");
            showTab(TAB_SETTINGS);
            checkForUpdate(true);
            return true;
        }
        String op = i.getStringExtra("open");
        if ("catalyst".equals(op)) {
            i.removeExtra("open");
            showTab(TAB_MORE);
            openCatalysts();
            return true;
        }
        String nt = i.getStringExtra("news");
        if (nt != null) {
            i.removeExtra("news");
            showTab(TAB_MORE);
            NewsEngine.Item hit = null;
            for (NewsEngine.Item it : NewsEngine.cached()) if (it.title.equals(nt)) { hit = it; break; }
            if (hit != null) openNewsDetail(hit);
            else openNews();
            return true;
        }
        String coin = i.getStringExtra("coin");
        if (coin == null || coin.isEmpty()) return false;
        i.removeExtra("coin");
        openAnalyze(coin);
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        handler.post(refresher);
        handler.post(liveTick);
        if (chart.getData() != null) startCoinFeed();
        if ((currentTab == 0 && mktSeg == 0) || currentTab == TAB_HOME) startMarketFeed();
        if (sigOverlay != null && sigOverlay.getTag() instanceof JSONObject) openSignalView((JSONObject) sigOverlay.getTag());
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumed = false;
        handler.removeCallbacks(refresher);
        handler.removeCallbacks(liveTick);
        stopCoinFeed();
        stopMarketFeed();
        if (sigLive != null) sigLive.stop();
    }

    @Override
    protected void onDestroy() {
        stopCoinFeed();
        stopMarketFeed();
        pool.shutdownNow();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (fsOverlay != null) closeFullscreen();
        else if (infoOverlay != null) infoBackPressed();
        else if (sigOverlay != null) closeSignalView();
        else if (isSubPage(currentTab)) showTab(TAB_MORE);
        else if (currentTab != TAB_HOME) showTab(TAB_HOME);
        else super.onBackPressed();
    }

    private void switchMode(int m) {
        if (m == uiMode) return;
        Prefs.setUiMode(this, m);
        recreate();
    }

    // ============================================================ ui helpers
    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable round(int color, float radiusDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) g.setStroke(dp(1), strokeColor);
        return g;
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setPadding(0, dp(2), 0, dp(2));
        return t;
    }

    private TextView bold(String s, float sp, int color) {
        TextView t = text(s, sp, color);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private LinearLayout card(LinearLayout parent) {
        return card(parent, STROKE);
    }

    private LinearLayout card(LinearLayout parent, int border) {
        LinearLayout c = column();
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        c.setBackground(round(CARD, 18, border));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        parent.addView(c, lp);
        return c;
    }

    private LinearLayout pageColumn(int idx) {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout col = column();
        col.setPadding(dp(12), 0, dp(12), dp(28));
        sv.addView(col);
        pages[idx] = sv;
        return col;
    }

    private TextView chip(String s, boolean on) {
        TextView t = bold(s, 13, TEXT);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(13), dp(8), dp(13), dp(8));
        styleChip(t, on);
        return t;
    }

    private void styleChip(TextView t, boolean on) {
        t.setTextColor(on ? INK : TEXT);
        t.setBackground(round(on ? ACC : CHIP, 20, on ? ACC : STROKE));
    }

    private LinearLayout.LayoutParams chipLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dp(8);
        return lp;
    }

    private HorizontalScrollView hscroll(LinearLayout inner) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(inner);
        return hs;
    }

    private Button button(String s, int bg, int fg, int stroke) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(fg);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(round(bg, 14, stroke));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(50));
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    private View bar(double leftPct, int leftColor, int rightColor) {
        LinearLayout b = row();
        b.setBackground(round(rightColor, 6, 0));
        float l = (float) Math.max(0, Math.min(100, leftPct));
        View a = new View(this);
        a.setBackground(round(leftColor, 6, 0));
        b.addView(a, new LinearLayout.LayoutParams(0, -1, l));
        b.addView(new View(this), new LinearLayout.LayoutParams(0, -1, 100 - l));
        return b;
    }

    private View divider() {
        View d = new View(this);
        d.setBackgroundColor(STROKE);
        d.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1)));
        return d;
    }

    private EditText input(String hint, String value, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(MUTED);
        e.setTextColor(TEXT);
        e.setSingleLine(true);
        e.setInputType(type);
        e.setText(value);
        return e;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void openUrl(String url) {
        if (url == null || url.isEmpty()) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            toast("Link nahi khula");
        }
    }

    private static String base(String sym) {
        return sym.endsWith("USDT") ? sym.substring(0, sym.length() - 4) : sym;
    }

    private static double parse(EditText e, double def) {
        try {
            return Double.parseDouble(e.getText().toString().trim().replace(",", ""));
        } catch (Exception x) {
            return def;
        }
    }

    private static double num(JSONObject o, String k) {
        try {
            return Double.parseDouble(o.optString(k, "0"));
        } catch (Exception e) {
            return 0;
        }
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null && getCurrentFocus() != null) imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        } catch (Exception ignored) {
        }
    }

    // ============================================================ frame
    private static boolean isSubPage(int t) {
        return t == TAB_WALLET || t == TAB_BIG || t == TAB_LISTINGS || t == TAB_SETTINGS;
    }

    /** App bar: back (on sub pages) · page title · mode · bot status. */
    private View header() {
        LinearLayout h = row();
        h.setPadding(dp(12), dp(12), dp(14), dp(8));
        backBtn = bold("‹", 28, TEXT);
        backBtn.setPadding(dp(4), 0, dp(10), dp(4));
        backBtn.setVisibility(View.GONE);
        backBtn.setOnClickListener(v -> onBackPressed());
        h.addView(backBtn);
        LinearLayout tt = column();
        TextView brand = bold("PARADOX", 10, ACC);
        brand.setLetterSpacing(0.15f);
        tt.addView(brand);
        pageTitle = bold("Dashboard", 22, TEXT);
        tt.addView(pageTitle);
        h.addView(tt, new LinearLayout.LayoutParams(0, -2, 1));
        TextView mode = bold(Mode.label(uiMode), 11, INK);
        mode.setPadding(dp(9), dp(5), dp(9), dp(5));
        mode.setBackground(round(ACC, 12, 0));
        mode.setOnClickListener(v -> switchMode(uiMode == Mode.SCALP ? Mode.SPOT : Mode.SCALP));
        h.addView(mode);
        liveDot = bold("○ OFF", 11, MUTED);
        liveDot.setPadding(dp(9), dp(5), dp(9), dp(5));
        liveDot.setBackground(round(CHIP, 12, STROKE));
        liveDot.setOnClickListener(v -> showTab(TAB_SIGNALS));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = dp(6);
        h.addView(liveDot, lp);
        return h;
    }

    /** Bottom navigation with 5 large items (professional app style). */
    private View bottomNav() {
        LinearLayout nav = row();
        nav.setBackground(round(CARD, 0, STROKE));
        nav.setPadding(dp(4), dp(6), dp(4), dp(8));
        String[] icons = {"🏠", "📈", "🔍", "🔔", "☰"};
        String[] labels = {"Home", "Markets", "Analysis", "Signals", "More"};
        for (int i = 0; i < 5; i++) {
            final int idx = i;
            LinearLayout it = column();
            it.setGravity(Gravity.CENTER);
            it.setPadding(0, dp(4), 0, dp(4));
            navIcon[i] = text(icons[i], 22, MUTED);
            navIcon[i].setGravity(Gravity.CENTER);
            navLabel[i] = text(labels[i], 11, MUTED);
            navLabel[i].setGravity(Gravity.CENTER);
            it.addView(navIcon[i]);
            it.addView(navLabel[i]);
            it.setOnClickListener(v -> showTab(NAV_PAGE[idx]));
            navItems[i] = it;
            nav.addView(it, new LinearLayout.LayoutParams(0, -2, 1));
        }
        return nav;
    }

    private void showTab(int i) {
        currentTab = i;
        for (int k = 0; k < pages.length; k++) pages[k].setVisibility(k == i ? View.VISIBLE : View.GONE);
        int navSel = 4;
        for (int k = 0; k < 5; k++) if (NAV_PAGE[k] == i) navSel = k;
        for (int k = 0; k < 5; k++) {
            boolean on = k == navSel;
            navLabel[k].setTextColor(on ? ACC : MUTED);
            navLabel[k].setTypeface(on ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            navItems[k].setBackground(on ? round((ACC & 0x00FFFFFF) | 0x26000000, 14, 0) : null);
        }
        pageTitle.setText(PAGE_TITLE[i]);
        backBtn.setVisibility(isSubPage(i) ? View.VISIBLE : View.GONE);
        if (i == 0 && mktSeg != 0) {
            stopMarketFeed();
            if (assetLoadedSeg != mktSeg || System.currentTimeMillis() - assetLoadedAt > 60_000) loadAssets();
        } else if (i == 0) {
            if (mk.isEmpty() || System.currentTimeMillis() - marketLoadedAt > 10 * 60_000) loadMarket();
            if (resumed) startMarketFeed();
        } else if (i == TAB_HOME) {
            if (resumed) startMarketFeed();   // live BTC / ETH prices on the dashboard
        } else {
            stopMarketFeed();
        }
        if (i == 2) {
            renderSignals(true);
            renderAlerts();
        }
        if (i == TAB_LISTINGS) {
            if (showMacro && System.currentTimeMillis() - macroLoadedAt > 5 * 60_000L) loadMacro(false);
            if (!showMacro && System.currentTimeMillis() - listingsLoadedAt > 10 * 60_000L) loadListings();
        }
        if (i == TAB_WALLET && System.currentTimeMillis() - walletsLoadedAt > 2 * 60_000L) loadWallets();
        if (i == TAB_BIG) {
            renderBigMoves();
            if (System.currentTimeMillis() - bigLoadedAt > 15 * 60_000L) loadBig();
        }
        if (i == TAB_HOME) loadHome();
        refreshStatus();
    }

    // ============================================================ HOME (dashboard)
    private void buildHome() {
        LinearLayout col = pageColumn(TAB_HOME);
        homeBox = column();
        col.addView(homeBox);
    }

    private TextView tileValue;
    private final Map<String, TextView> homePx = new HashMap<>();

    /** Small stat tile used on the dashboard. */
    private LinearLayout tile(LinearLayout parent, String label, String value, String sub, int color, Runnable click) {
        LinearLayout t = column();
        t.setPadding(dp(12), dp(10), dp(12), dp(10));
        t.setBackground(round(CARD, 16, STROKE));
        t.addView(text(label, 11, MUTED));
        tileValue = bold(value, 18, color);
        t.addView(tileValue);
        if (sub != null) t.addView(text(sub, 11, color == TEXT ? SOFT : color));
        if (click != null) t.setOnClickListener(v -> click.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.rightMargin = dp(6);
        lp.leftMargin = dp(6);
        parent.addView(t, lp);
        return t;
    }

    private LinearLayout tileRow(LinearLayout parent) {
        LinearLayout r = row();
        r.setPadding(0, dp(10), 0, 0);
        parent.addView(r, new LinearLayout.LayoutParams(-1, -2));
        return r;
    }

    private void loadHome() {
        renderHome();
        pool.execute(() -> {
            try {
                if (mk.isEmpty() || System.currentTimeMillis() - marketLoadedAt > 5 * 60_000) {
                    final JSONArray tick = new JSONArray(Scanner.get("/api/v3/ticker/24hr?type=MINI"));
                    final String[] fg = SmartMoney.fearGreed();
                    runOnUiThread(() -> {
                        for (int i = 0; i < tick.length(); i++) {
                            JSONObject o = tick.optJSONObject(i);
                            if (o == null) continue;
                            String sy = o.optString("symbol");
                            if (!Scanner.isTradable(sy) || o.optDouble("lastPrice", 0) <= 0) continue;
                            mk.put(sy, new double[]{o.optDouble("lastPrice", 0), o.optDouble("openPrice", 0), o.optDouble("quoteVolume", 0)});
                        }
                        lastFg = fg;
                        marketLoadedAt = System.currentTimeMillis();
                        if (currentTab == TAB_HOME) renderHome();
                    });
                }
                for (String ys : new String[]{"GC=F", "EURUSD=X"}) {
                    try {
                        YahooData.Quote q = YahooData.quote(ys);
                        synchronized (assetQ) { assetQ.put(ys, q); }
                    } catch (Exception ignored) {
                    }
                }
                NewsEngine.fetch(this, 5 * 60_000L);
                CatalystEngine.fetch(this, 30 * 60_000L);
                final List<MacroEngine.Event> evs = MacroEngine.calendar(this, false);
                final MacroEngine.Pulse p = MacroEngine.pulse(false);
                runOnUiThread(() -> {
                    homeEvents = evs;
                    homePulse = p;
                    if (currentTab == TAB_HOME) renderHome();
                });
            } catch (Exception ignored) {
            }
        });
    }

    private void renderHome() {
        homeBox.removeAllViews();
        homePx.clear();
        int h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY);
        LinearLayout g = card(homeBox, ACC);
        g.addView(bold((h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening") + " 👋", 20, TEXT));
        g.addView(text(new SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.US).format(new Date()) + " · " + Mode.label(uiMode) + " mode", 12, MUTED));
        boolean sc = Prefs.modeOn(this, Mode.SCALP), sp = Prefs.modeOn(this, Mode.SPOT);
        LinearLayout br = row();
        br.setPadding(0, dp(10), 0, 0);
        for (int m = 0; m < 2; m++) {
            final int mm = m;
            boolean on = m == 0 ? sc : sp;
            TextView b = bold((on ? "● " : "○ ") + Mode.label(m) + (on ? " ON" : " OFF"), 13, on ? INK : Mode.accent(m));
            b.setGravity(Gravity.CENTER);
            b.setPadding(dp(8), dp(10), dp(8), dp(10));
            b.setBackground(round(on ? Mode.accent(m) : CHIP, 14, Mode.accent(m)));
            b.setOnClickListener(v -> { toggleMode(mm); handler.postDelayed(this::renderHome, 400); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            lp.rightMargin = dp(6);
            br.addView(b, lp);
        }
        g.addView(br);
        boolean co = Prefs.mktOn(this, Assets.COMMODITY), fo = Prefs.mktOn(this, Assets.FOREX);
        TextView mb2 = text((co ? "🟢" : "⚪") + " Gold bot " + (co ? "ON" : "OFF") + "   ·   " + (fo ? "🟢" : "⚪") + " Forex bot " + (fo ? "ON" : "OFF")
                + (Prefs.accuracyMode(this) ? "   ·   🎯 Accuracy mode" : ""), 12, SOFT);
        mb2.setPadding(0, dp(8), 0, 0);
        mb2.setOnClickListener(v -> { showTab(TAB_SIGNALS); setSigSeg(co || !fo ? 1 : 2); });
        g.addView(mb2);

        // market snapshot
        TextView sh = bold("MARKET SNAPSHOT", 11, MUTED);
        sh.setLetterSpacing(0.12f);
        sh.setPadding(dp(4), dp(16), 0, 0);
        homeBox.addView(sh);
        LinearLayout r1 = tileRow(homeBox);
        for (String sy : new String[]{"BTCUSDT", "ETHUSDT"}) {
            double[] v = mk.get(sy);
            double ch = v == null ? 0 : change(v);
            final String s2 = sy;
            tile(r1, base(sy) + "/USDT  ● live", v == null ? "—" : "$" + Fmt.price(v[0]), v == null ? "load ho raha hai" : Fmt.pct(ch) + " · 24h",
                    v == null ? TEXT : ch >= 0 ? GREEN : RED, () -> openAnalyze(s2));
            homePx.put(sy, tileValue);
        }
        LinearLayout rg = tileRow(homeBox);
        for (String ys : new String[]{"GC=F", "EURUSD=X"}) {
            final Assets.Asset as = Assets.find(ys);
            YahooData.Quote q;
            synchronized (assetQ) { q = assetQ.get(ys); }
            tile(rg, as.icon + " " + as.short_, q == null ? "—" : Assets.fmt(as, q.price), q == null ? "load ho raha hai" : Fmt.pct(q.change) + " · aaj",
                    q == null ? TEXT : q.change >= 0 ? GREEN : RED, () -> openAssetAnalysis(as));
        }
        LinearLayout r2 = tileRow(homeBox);
        int fgv = -1;
        try { if (lastFg != null) fgv = Integer.parseInt(lastFg[0]); } catch (Exception ignored) { }
        tile(r2, "Fear & Greed", fgv < 0 ? "—" : String.valueOf(fgv), lastFg == null ? "" : lastFg[1], GaugeView.colorFor(fgv), () -> showTab(TAB_MARKET));
        tile(r2, "Macro mood", homePulse == null ? "—" : homePulse.score >= 20 ? "Risk-ON" : homePulse.score <= -20 ? "Risk-OFF" : "Neutral",
                homePulse == null || Double.isNaN(homePulse.fedRate) ? "Fed · yields · dollar" : String.format(Locale.US, "Fed rate %.2f%%", homePulse.fedRate),
                homePulse == null ? TEXT : homePulse.score >= 20 ? GREEN : homePulse.score <= -20 ? RED : YELLOW,
                () -> { showTab(TAB_LISTINGS); setNewsSeg(true); });

        // next macro event
        if (homeEvents != null) {
            long now = System.currentTimeMillis();
            for (MacroEngine.Event e : homeEvents) {
                if (!"High".equals(e.impact) || e.time < now - 30 * 60_000L) continue;
                long dt = e.time - now;
                LinearLayout ec = card(homeBox, dt < 2 * 3600_000L ? RED : YELLOW);
                ec.addView(text("NEXT HIGH-IMPACT EVENT", 10, MUTED));
                ec.addView(bold(e.title, 16, TEXT));
                ec.addView(text(MacroEngine.pkt(e.time) + (dt > 0 ? " · " + MacroEngine.mins(dt) + " baad" : " · abhi"), 12, dt < 2 * 3600_000L ? RED : YELLOW));
                ec.addView(text(e.expectation, 12, SOFT));
                ec.setOnClickListener(v -> { showTab(TAB_LISTINGS); setNewsSeg(true); });
                break;
            }
        }

        // top news (critical / important, last 6h)
        {
            long nowT = System.currentTimeMillis();
            NewsEngine.Item top = null;
            for (NewsEngine.Item it : NewsEngine.cached()) {
                if (nowT - it.time > 6 * 3600_000L) break;
                if (it.severity >= 2 && (top == null || it.severity > top.severity)) top = it;
            }
            if (top != null) {
                final NewsEngine.Item tn = top;
                LinearLayout nc = card(homeBox, top.dir < 0 ? RED : top.dir > 0 ? GREEN : YELLOW);
                nc.addView(text("TOP NEWS · " + NewsEngine.sevLabel(top) + " · " + ago(top.time), 10, MUTED));
                nc.addView(bold(top.title, 15, TEXT));
                nc.addView(text(top.category + " · " + NewsEngine.dirLabel(top) + (top.coins.isEmpty() ? "" : " · " + String.join(", ", top.coins)), 12,
                        top.dir < 0 ? RED : top.dir > 0 ? GREEN : YELLOW));
                nc.setOnClickListener(v -> openNewsDetail(tn));
            }
        }

        // upcoming catalysts (next 3 days)
        {
            long nowT = System.currentTimeMillis();
            List<CatalystEngine.Event> up = new ArrayList<>();
            for (CatalystEngine.Event e : CatalystEngine.cached()) {
                boolean det = e.type.equals(CatalystEngine.ODDS) || e.type.equals(CatalystEngine.OI);
                if (e.severity >= 2 && (det || (e.time > nowT && e.time - nowT < 3L * 86_400_000L))) up.add(e);
                if (up.size() >= 3) break;
            }
            if (!up.isEmpty()) {
                LinearLayout cc = card(homeBox, YELLOW);
                cc.addView(text("📆 AANE WALE CATALYSTS", 10, MUTED));
                for (final CatalystEngine.Event e : up) {
                    TextView t = text(e.icon() + " " + e.title + " · " + ((e.type.equals(CatalystEngine.ODDS) || e.type.equals(CatalystEngine.OI)) ? ago(e.time) : until(e.time)), 13,
                            e.dir > 0 ? GREEN : e.dir < 0 ? RED : TEXT);
                    t.setPadding(0, dp(4), 0, dp(4));
                    t.setOnClickListener(v -> openCatalystDetail(e));
                    cc.addView(t);
                }
                cc.setOnClickListener(v -> openCatalysts());
            }
        }

        // latest signals
        TextView ss = bold("LATEST SIGNALS", 11, MUTED);
        ss.setLetterSpacing(0.12f);
        ss.setPadding(dp(4), dp(16), 0, 0);
        homeBox.addView(ss);
        JSONArray sig = Prefs.signals(this);
        LinearLayout sc2 = card(homeBox);
        if (sig.length() == 0) sc2.addView(text("Abhi koi signal nahi — upar se bot ON karein.", 13, MUTED));
        for (int i = 0; i < sig.length() && i < 3; i++) {
            final JSONObject o = sig.optJSONObject(i);
            if (o == null) continue;
            boolean buy = "BUY".equals(o.optString("side"));
            LinearLayout rr = row();
            rr.setPadding(0, dp(6), 0, dp(6));
            Assets.Asset sa = Assets.find(o.optString("asset", ""));
            rr.addView(bold((buy ? "🟢 BUY " : "🔴 SELL ") + (sa != null ? sa.icon + " " + sa.short_ : base(o.optString("sym"))), 14, buy ? GREEN : RED), new LinearLayout.LayoutParams(0, -2, 1));
            String st = o.optString("st", "");
            rr.addView(text(st.equals("win") ? "✅ WIN" : st.equals("loss") ? "❌ LOSS" : st.equals("open") ? "⏳ open" : "", 12, SOFT));
            rr.setOnClickListener(v -> openSignalView(o));
            sc2.addView(rr);
        }
        int[] stt = Scanner.signalStats(sig);
        if (stt[0] + stt[1] > 0) sc2.addView(text(String.format(Locale.US, "🏆 Win rate %.0f%% (%d trades)", stt[0] * 100.0 / (stt[0] + stt[1]), stt[0] + stt[1]), 12, ACC2));
        sc2.setOnClickListener(v -> showTab(TAB_SIGNALS));

        // portfolio + institutions
        TextView ps = bold("PORTFOLIO & SMART MONEY", 11, MUTED);
        ps.setLetterSpacing(0.12f);
        ps.setPadding(dp(4), dp(16), 0, 0);
        homeBox.addView(ps);
        LinearLayout r3 = tileRow(homeBox);
        double tot = 0;
        JSONArray ws = Prefs.wallets(this);
        for (int i = 0; i < ws.length(); i++) tot += ws.optJSONObject(i) == null ? 0 : ws.optJSONObject(i).optDouble("usd", 0);
        tile(r3, "My portfolio", ws.length() == 0 ? "Add wallet" : Fmt.usd(tot), ws.length() + " wallets · watch-only", ws.length() == 0 ? ACC : TEXT, () -> showTab(TAB_WALLET));
        JSONArray mv = Prefs.bigMoves(this);
        JSONObject m0 = mv.optJSONObject(0);
        tile(r3, "Institutions", m0 == null ? "Track" : (m0.optBoolean("buy") ? "🟢 Buying" : "🔴 Selling"),
                m0 == null ? "BlackRock · Strategy · WLFI" : m0.optString("text"), m0 == null ? ACC : m0.optBoolean("buy") ? GREEN : RED, () -> showTab(TAB_BIG));

        // quick actions
        TextView qa = bold("QUICK ACTIONS", 11, MUTED);
        qa.setLetterSpacing(0.12f);
        qa.setPadding(dp(4), dp(16), 0, 0);
        homeBox.addView(qa);
        LinearLayout r4 = tileRow(homeBox);
        tile(r4, "🔍", "Analyze", "Kisi bhi coin ka", ACC, () -> showTab(TAB_ANALYZE));
        tile(r4, "📅", "Calendar", "Fed · CPI · NFP", YELLOW, () -> { showTab(TAB_LISTINGS); setNewsSeg(true); });
        LinearLayout r5 = tileRow(homeBox);
        tile(r5, "🆕", "Listings", "Naye coins", ACC2, () -> { showTab(TAB_LISTINGS); setNewsSeg(false); });
        tile(r5, "⚙️", "Settings", "Bots · alerts", SOFT, () -> showTab(TAB_SETTINGS));
        LinearLayout r6 = tileRow(homeBox);
        tile(r6, "📚", "Academy", "Trading seekhein", CYAN_TXT, this::openAcademy);
        tile(r6, "🧮", "Tools", "SL/TP · Average", GREEN, this::openTools);
        LinearLayout r7 = tileRow(homeBox);
        tile(r7, "📰", "Live News", Prefs.newsOn(this) ? "● radar ON" : "Hack · listing · ETF", Prefs.newsOn(this) ? GREEN : YELLOW, this::openNews);
        tile(r7, "📈", "Markets", "Crypto · Gold · Forex", ACC, () -> showTab(TAB_MARKET));
        homeBox.addView(text("\n⚠️ Signals maloomat ke liye hain, financial advice nahi.", 11, MUTED));
    }

    // ============================================================ MORE (menu hub)
    private void buildMore() {
        LinearLayout col = pageColumn(TAB_MORE);
        String[][] items = {
                {"📰", "Crypto News · LIVE", "Hack, listing, ETF, SEC, whales, X posts — asar ke saath", "news"},
                {"📆", "Catalyst Radar", "Aane wale unlocks, listings, delistings, airdrops, ETF, Polymarket odds", "catalyst"},
                {"💼", "Portfolio", "Apne wallets — watch-only, 100% safe", String.valueOf(TAB_WALLET)},
                {"🏛️", "Institutions", "BlackRock, ETFs, companies, governments, whale wallets", String.valueOf(TAB_BIG)},
                {"📅", "Economic Calendar", "Fed, CPI, PCE, NFP, GDP — asar aur alerts", "cal"},
                {"🆕", "New Listings", "Binance, Bybit, OKX, KuCoin — listing se pehle", "list"},
                {"📚", "ParaDox Academy", "Trading seekhein — basics se pro tak (" + Academy.LESSONS.length + " sabaq)", "academy"},
                {"🧮", "Trading Tools", "SL/TP · Average price (DCA) · Position size · R:R · P/L", "tools"},
                {"⚙️", "Settings", "Bots, notifications, AI, data & privacy", String.valueOf(TAB_SETTINGS)},
                {"ℹ️", "About ParaDox", "Developer: Nohman Arshid · version, data sources, privacy", "about"}};
        for (String[] it : items) {
            final String target = it[3];
            LinearLayout c = card(col);
            LinearLayout r = row();
            TextView ic = text(it[0], 24, TEXT);
            ic.setGravity(Gravity.CENTER);
            ic.setBackground(round((ACC & 0x00FFFFFF) | 0x22000000, 14, 0));
            r.addView(ic, new LinearLayout.LayoutParams(dp(50), dp(50)));
            LinearLayout t = column();
            t.setPadding(dp(14), 0, 0, 0);
            t.addView(bold(it[1], 16, TEXT));
            t.addView(text(it[2], 12, MUTED));
            r.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
            r.addView(bold("›", 24, MUTED));
            c.addView(r);
            c.setOnClickListener(v -> {
                if (target.equals("cal")) { showTab(TAB_LISTINGS); setNewsSeg(true); }
                else if (target.equals("list")) { showTab(TAB_LISTINGS); setNewsSeg(false); }
                else if (target.equals("academy")) openAcademy();
                else if (target.equals("news")) openNews();
                else if (target.equals("catalyst")) openCatalysts();
                else if (target.equals("about")) openAbout();
                else if (target.equals("tools")) openTools();
                else showTab(Integer.parseInt(target));
            });
        }
        String ver = "?";
        try {
            ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
        }
        TextView f = text("ParaDox · v" + ver + "\nCrypto · Gold · Forex\nDeveloped by Nohman Arshid 🇵🇰", 11, MUTED);
        f.setGravity(Gravity.CENTER);
        f.setPadding(0, dp(24), 0, 0);
        col.addView(f);
    }

    // ============================================================ generic full page (overlay)
    private Runnable infoBack;

    private void infoBackPressed() {
        Runnable r = infoBack;
        if (r != null) r.run();
        else closeInfo();
    }

    /** Page whose ‹ / back button goes to `back` (e.g. the list it was opened from). */
    private LinearLayout openPage(String title, Runnable back) {
        LinearLayout c = openPage(title);
        infoBack = back;
        return c;
    }

    private LinearLayout openPage(String title) {
        closeInfo();
        infoBack = null;
        infoOverlay = column();
        infoOverlay.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Mode.bgTop(uiMode), Mode.bgBottom(uiMode)}));
        LinearLayout h = row();
        h.setPadding(dp(12), dp(12), dp(14), dp(8));
        TextView b = bold("‹", 28, TEXT);
        b.setPadding(dp(4), 0, dp(12), dp(4));
        b.setOnClickListener(v -> infoBackPressed());
        h.addView(b);
        h.addView(bold(title, 20, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        infoOverlay.addView(h);
        ScrollView sv = new ScrollView(this);
        LinearLayout c = column();
        c.setPadding(dp(12), 0, dp(12), dp(28));
        sv.addView(c);
        infoOverlay.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        rootFrame.addView(infoOverlay, new FrameLayout.LayoutParams(-1, -1));
        return c;
    }

    private void closeInfo() {
        if (infoOverlay != null) rootFrame.removeView(infoOverlay);
        infoOverlay = null;
    }

    // ============================================================ v11: GOLD & COMMODITIES · FOREX markets
    private void setMktSeg(int i) {
        mktSeg = i;
        for (int k = 0; k < 3; k++) styleChip(mktSegChips[k], k == i);
        cryptoWrap.setVisibility(i == 0 ? View.VISIBLE : View.GONE);
        assetWrap.setVisibility(i == 0 ? View.GONE : View.VISIBLE);
        if (i == 0) {
            if (mk.isEmpty()) loadMarket();
            if (resumed) startMarketFeed();
        } else {
            stopMarketFeed();
            assetHead.setText(i == 1 ? "🥇 Gold & Commodities" : "💱 Forex");
            renderAssets();
            if (assetLoadedSeg != i || System.currentTimeMillis() - assetLoadedAt > 60_000) loadAssets();
        }
    }

    private void buildAssetMarket(LinearLayout wrap) {
        LinearLayout c = card(wrap, YELLOW);
        LinearLayout hr = row();
        assetHead = bold("🥇 Gold & Commodities", 18, TEXT);
        hr.addView(assetHead, new LinearLayout.LayoutParams(0, -2, 1));
        TextView rf = chip("↻ Refresh", false);
        rf.setOnClickListener(v -> loadAssets());
        hr.addView(rf);
        c.addView(hr);
        assetStatus = text("", 12, MUTED);
        c.addView(assetStatus);
        assetList = column();
        c.addView(assetList);
        LinearLayout info = card(wrap);
        info.addView(bold("ℹ️ Is market ke baare mein", 14, TEXT));
        info.addView(text("Prices Yahoo Finance (futures / spot FX) se aati hain, har minute taaza hoti hain. Kisi bhi asset par tap karein — "
                + "poora analysis: multi-timeframe trend, moving averages (EMA 9·21·50·100·200), golden/death cross, chart patterns, "
                + "ParaDox rule ka backtest, US dollar index (DXY), yields aur is hafte ki bari news.\n"
                + "Market timings: Sunday raat ~3 baje (PKT) se Saturday subah ~3 baje tak. Weekend par band.", 12, MUTED));
    }

    private void loadAssets() {
        if (mktSeg == 0) return;
        final int seg = mktSeg;
        final Assets.Asset[] list = Assets.list(segMarket(seg));
        assetLoadedAt = System.currentTimeMillis();
        assetLoadedSeg = seg;
        if (assetQ.isEmpty()) assetStatus.setText("Prices load ho rahi hain...");
        pool.execute(() -> {
            int ok = 0;
            for (Assets.Asset a : list) {
                try {
                    YahooData.Quote q = YahooData.quote(a.sym);
                    synchronized (assetQ) { assetQ.put(a.sym, q); }
                    ok++;
                } catch (Exception ignored) {
                }
            }
            final int fok = ok;
            runOnUiThread(() -> {
                if (mktSeg != seg) return;
                renderAssets();
                boolean open = Assets.marketOpen(System.currentTimeMillis());
                String t = new SimpleDateFormat("HH:mm", Locale.US).format(new Date());
                assetStatus.setText(fok == 0 ? "❌ Data nahi mila — internet check karke Refresh dabayen"
                        : (open ? "🟢 Market khuli hai" : "🔴 Market band (weekend) — aakhri prices") + " · updated " + t + " · tap = analysis");
            });
        });
    }

    private void renderAssets() {
        if (assetList == null || mktSeg == 0) return;
        assetList.removeAllViews();
        for (final Assets.Asset a : Assets.list(segMarket(mktSeg))) {
            YahooData.Quote q;
            synchronized (assetQ) { q = assetQ.get(a.sym); }
            LinearLayout r = row();
            r.setPadding(0, dp(11), 0, dp(11));
            TextView ic = text(a.icon, 22, TEXT);
            ic.setGravity(Gravity.CENTER);
            r.addView(ic, new LinearLayout.LayoutParams(dp(40), -2));
            LinearLayout nm = column();
            nm.addView(bold(a.short_, 15, TEXT));
            nm.addView(text(a.name, 11, MUTED));
            r.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
            LinearLayout pr = column();
            pr.setGravity(Gravity.END);
            TextView pv = bold(q != null ? Assets.fmt(a, q.price) : "—", 15, TEXT);
            pv.setGravity(Gravity.END);
            pr.addView(pv);
            if (q != null) {
                TextView ch = bold(Fmt.pct(q.change), 12, q.change >= 0 ? GREEN : RED);
                ch.setGravity(Gravity.END);
                ch.setPadding(dp(8), dp(2), dp(8), dp(2));
                ch.setBackground(round(q.change >= 0 ? 0x220ECB81 : 0x22F6465D, 8, 0));
                pr.addView(ch);
            }
            r.addView(pr);
            r.setOnClickListener(v -> openAssetAnalysis(a));
            assetList.addView(r);
            assetList.addView(divider());
        }
    }

    /** Full analysis page for a gold / commodity / forex asset. */
    private void openAssetAnalysis(final Assets.Asset a) {
        final LinearLayout col = openPage(a.icon + " " + a.short_ + " · analysis");
        LinearLayout w = card(col, YELLOW);
        w.addView(bold("⏳ " + a.name + " ka analysis ho raha hai...", 15, YELLOW));
        w.addView(text("15m · 1h · 4h · 1d candles, moving averages, patterns, backtest, dollar index, yields aur news jama ho rahe hain. 10–20 second.", 12, MUTED));
        final LinearLayout overlay = infoOverlay;
        pool.execute(() -> {
            try {
                final AssetReport r = AssetReport.build(this, a);
                runOnUiThread(() -> {
                    if (infoOverlay != overlay) return;
                    col.removeAllViews();
                    showAssetReport(col, r);
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> {
                    if (infoOverlay != overlay) return;
                    col.removeAllViews();
                    LinearLayout c = card(col, RED);
                    c.addView(bold("❌ Analysis nahi ho saka", 15, RED));
                    c.addView(text(m == null ? "Internet check karein" : m, 13, SOFT));
                    TextView again = chip("↻ Dobara koshish", true);
                    again.setOnClickListener(v -> openAssetAnalysis(a));
                    c.addView(again);
                });
            }
        });
    }

    private void showAssetReport(final LinearLayout col, final AssetReport r) {
        final Assets.Asset a = r.asset;
        int vc = r.isBuy ? GREEN : RED;
        LinearLayout h = card(col, vc);
        LinearLayout hr = row();
        LinearLayout nm = column();
        nm.addView(bold(a.icon + " " + a.name, 16, TEXT));
        nm.addView(text(a.short_ + " · " + (Assets.FOREX.equals(a.market) ? "Forex" : "Commodity"), 11, MUTED));
        hr.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout pc = column();
        pc.setGravity(Gravity.END);
        final TextView pv = bold(Assets.fmt(a, r.price), 18, TEXT);
        pv.setGravity(Gravity.END);
        pc.addView(pv);
        TextView cv0 = bold(String.format(Locale.US, "%+.2f%% aaj · %+.2f%% hafta", r.change, r.weekChange), 11, r.change >= 0 ? GREEN : RED);
        cv0.setGravity(Gravity.END);
        pc.addView(cv0);
        hr.addView(pc);
        h.addView(hr);
        TextView big = bold((r.isBuy ? "▲ " : "▼ ") + r.verdict, 30, vc);
        big.setGravity(Gravity.CENTER);
        h.addView(big);
        TextView conf = bold("Confidence " + r.confidence + "%  ·  Score " + r.total + "/100", 13, TEXT);
        conf.setGravity(Gravity.CENTER);
        h.addView(conf);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, dp(10));
        clp.topMargin = dp(6);
        clp.bottomMargin = dp(6);
        h.addView(bar(r.confidence, vc, 0xFF243049), clp);
        TextView vt = text(r.verdictText, 14, SOFT);
        vt.setGravity(Gravity.CENTER);
        h.addView(vt);
        TextView rf = chip("↻ Dobara analysis (taaza data)", false);
        rf.setOnClickListener(v -> openAssetAnalysis(a));
        h.addView(rf);

        // ---- chart
        LinearLayout cc = card(col, ACC);
        cc.addView(bold("📈 Chart · " + a.short_, 15, TEXT));
        final ChartView cv = new ChartView(this);
        cv.setAccent(YELLOW);
        cv.setCompact(true);
        final String[] tfs = {"15m", "1h", "4h", "1d", "1w", "1M", "1Y", "2Y", "5Y", "ALL"};
        final TextView[] tc = new TextView[tfs.length];
        LinearLayout tr = row();
        tr.setPadding(0, dp(6), 0, dp(4));
        for (int i = 0; i < tfs.length; i++) {
            final int ti = i;
            tc[i] = chip(tfs[i], tfs[i].equals("1h"));
            tc[i].setOnClickListener(v -> {
                for (int k = 0; k < tfs.length; k++) styleChip(tc[k], k == ti);
                cv.setMessage(tfs[ti] + " chart load ho raha hai...");
                pool.execute(() -> {
                    try {
                        final Candles c = YahooData.fetch(a.sym, tfs[ti], false);
                        final PatternEngine.Result p = PatternEngine.analyze(c.closedOnly(), Math.min(150, c.n));
                        runOnUiThread(() -> setAssetChart(cv, r, c, p, tfs[ti]));
                    } catch (Exception e) {
                        final String m = e.getMessage();
                        runOnUiThread(() -> cv.setMessage("Chart nahi mila: " + m));
                    }
                });
            });
            tr.addView(tc[i], chipLp());
        }
        TextView fs = chip("⛶ Full screen", true);
        fs.setOnClickListener(v -> openChartFullscreen(cv, a.short_ + " · " + a.name, false));
        tr.addView(fs, chipLp());
        cc.addView(hscroll(tr));
        final String title = a.short_ + " · " + a.name;
        cv.setOnTap(() -> openChartFullscreen(cv, title, false));
        cc.addView(cv, new LinearLayout.LayoutParams(-1, dp(430)));
        cc.addView(text("〰️ EMA ribbon: 🟡9 🔵21 🟣50 🟠100 ⚪200 · ▲▼ = ParaDox rule ke purane signals · ✨ golden / ☠ death cross · "
                + "tap = full screen (indicators, drawing, crosshair)", 11, MUTED));
        if (r.chart != null && r.chart.n > 1) setAssetChart(cv, r, r.chart, r.patterns, "1h");
        // live price: refresh every 15 s while this page is open (Yahoo quote) and move the last candle
        final LinearLayout page = infoOverlay;
        final double[] lastPx = {r.price};
        final Runnable[] tick = new Runnable[1];
        tick[0] = () -> {
            if (infoOverlay != page || page == null) return;
            pool.execute(() -> {
                try {
                    final YahooData.Quote q = YahooData.quote(a.sym);
                    runOnUiThread(() -> {
                        if (infoOverlay != page || q.price <= 0) return;
                        pv.setText(Assets.fmt(a, q.price) + " ●");
                        pv.setTextColor(q.price > lastPx[0] ? GREEN : q.price < lastPx[0] ? RED : TEXT);
                        lastPx[0] = q.price;
                        Candles cd = cv.getData();
                        if (cd != null && cd.n > 0) {
                            int li = cd.n - 1;
                            cd.close[li] = q.price;
                            cd.high[li] = Math.max(cd.high[li], q.price);
                            cd.low[li] = Math.min(cd.low[li], q.price);
                            cv.liveCandles(cd);
                        }
                    });
                } catch (Exception ignored) {
                }
            });
            handler.postDelayed(tick[0], 15_000);
        };
        handler.postDelayed(tick[0], 15_000);

        // ---- plan
        assetPlanCard(col, r);
        paradoxCard(col, r.ma, r.bt, r.bt2, r.ruleSide, r.ruleChecks, r.mtfAgree, "1h", 4);
        for (CoinReport.Section s : r.sections) sectionCard(col, s);
        scoreBuildCard(col, r.sections, r.total, r.confidence);

        // ---- AI
        LinearLayout ai = card(col, CLAUDE);
        ai.addView(bold("🤖 Claude AI se poochen", 15, TEXT));
        final LinearLayout chat = column();
        ai.addView(chat);
        final List<String[]> history = new ArrayList<>();
        TextView full = chip("✨ Claude se " + a.short_ + " ka trade plan likhwayen", true);
        full.setBackground(round(CLAUDE, 20, CLAUDE));
        full.setOnClickListener(v -> askClaudeText(r.toText(), chat, history,
                "Is asset ka poora analysis karo: direction, entry, stop-loss, 2 targets, dollar/news ka asar, aur kis cheez se idea ghalat hoga."));
        ai.addView(full);

        LinearLayout act = card(col);
        act.addView(text("⚠️ Yeh analysis maloomat ke liye hai, financial advice nahi. Forex/commodities mein leverage bahut khatarnak ho sakta hai — "
                + "har trade mein stop-loss lagayen aur 1–2% se zyada risk na karein.", 12, MUTED));
    }

    private void setAssetChart(ChartView cv, AssetReport r, Candles c, PatternEngine.Result p, String tf) {
        cv.setTitle(r.asset.short_);
        cv.setData(c, p, new double[c.n], new double[c.n], ChartRange.interval(tf), false);
        cv.setVisible(ChartRange.visible(tf, c.n));
        analysisLayers(cv);
        setScenario(cv, r.advice, r.price);
        cv.setInd("Whales", false);
        cv.setInd("Retail", false);
        cv.setInd("VolProfile", false);
        if (!Assets.COMMODITY.equals(r.asset.market)) cv.setInd("Volume", false);
        if (!cv.ind("MA Ribbon") && !cv.ind("EMA")) cv.setInd("MA Ribbon", true);
        double entry = r.advice != null && r.advice.entry > 0 ? r.advice.entry : r.price;
        cv.setPlan(r.stop > 0, r.isBuy, entry, r.stop, r.target1, r.target2);
        if (r.advice != null && r.advice.zoneHi > 0) cv.setZone(r.advice.zoneLo, r.advice.zoneHi, r.isBuy ? "BUY ZONE" : "SELL ZONE", r.isBuy ? GREEN : RED);
    }

    private void assetPlanCard(LinearLayout col, AssetReport r) {
        Assets.Asset a = r.asset;
        LinearLayout p = card(col, r.isBuy ? GREEN : RED);
        p.addView(bold("🧭 Position plan — " + (r.isBuy ? "BUY (long)" : "SELL (short)"), 16, TEXT));
        if (r.advice != null) {
            p.addView(bold(r.advice.title, 14, r.isBuy ? GREEN : RED));
            p.addView(text(r.advice.why, 13, SOFT));
            if (r.advice.zoneHi > 0) p.addView(text("Entry zone: " + Assets.fmt(a, r.advice.zoneLo) + " – " + Assets.fmt(a, r.advice.zoneHi), 14, TEXT));
        }
        p.addView(text("Support: " + Assets.fmt(a, r.support) + "   ·   Resistance: " + Assets.fmt(a, r.resistance), 13, SOFT));
        if (r.stop > 0) {
            double e = r.advice != null && r.advice.entry > 0 ? r.advice.entry : r.price;
            double pip = Assets.pip(a);
            String pips1 = pip > 0 ? String.format(Locale.US, "  (%.0f pips)", Math.abs(e - r.stop) / pip) : "";
            p.addView(text("🛑 Stop-loss: " + Assets.fmt(a, r.stop) + pctFrom(r.stop, e) + pips1, 14, RED));
            p.addView(text("🎯 TP1: " + Assets.fmt(a, r.target1) + pctFrom(r.target1, e)
                    + (pip > 0 ? String.format(Locale.US, "  (%.0f pips)", Math.abs(r.target1 - e) / pip) : ""), 14, GREEN));
            p.addView(text("🎯 TP2: " + Assets.fmt(a, r.target2) + pctFrom(r.target2, e)
                    + (pip > 0 ? String.format(Locale.US, "  (%.0f pips)", Math.abs(r.target2 - e) / pip) : ""), 14, GREEN));
            p.addView(text("ATR (1h ki ausat harkat): " + Assets.fmt(a, r.atr) + " · stop = 1.5×ATR taa ke aam shor se stop na lage.", 12, MUTED));
        }
        if (!r.events.isEmpty()) {
            p.addView(divider());
            p.addView(bold("📅 Is hafte ki bari news", 13, YELLOW));
            for (String ev : r.events) p.addView(text(ev, 12, SOFT));
        }
        learnToggle(p, "Entry zone = jahan risk kam aur reward zyada ho (support ke paas buy / resistance ke paas sell). "
                + "Stop-loss woh jagah hai jahan aap ka idea ghalat sabit ho jata hai. TP1 par aadha profit lein aur stop entry par le aayen — "
                + "phir trade 'free' ho jata hai. Forex mein pips naapte hain: EURUSD mein 0.0001 = 1 pip.");
    }

    /** Moving-average system + ParaDox rule + backtest, with teaching notes. */
    private void paradoxCard(LinearLayout col, MaSystem.Result ma, ParadoxRule.Backtest bt, ParadoxRule.Backtest bt2, int ruleSide,
                             List<String> checks, int mtf, String tf, int tfCount) {
        if (ma == null) return;
        LinearLayout c = card(col, ruleSide > 0 ? GREEN : ruleSide < 0 ? RED : ACC2);
        c.addView(bold("⚡ ParaDox rule · Moving averages (" + tf + ")", 16, TEXT));
        c.addView(bold(ruleSide > 0 ? "▲ BUY setup abhi bana hai" : ruleSide < 0 ? "▼ SELL setup abhi bana hai" : "Abhi koi taaza setup nahi — intezar behtar",
                14, ruleSide > 0 ? GREEN : ruleSide < 0 ? RED : YELLOW));
        for (String l : ma.lines) c.addView(text("• " + l, 13, SOFT));
        c.addView(divider());
        c.addView(bold("Checklist (aakhri band candle):", 13, TEXT));
        for (String l : checks) c.addView(text(l, 13, l.startsWith("✅") ? GREEN : l.startsWith("❌") ? RED : SOFT));
        c.addView(text("Timeframes agreement: " + (mtf > 0 ? "+" : "") + mtf + " / " + tfCount + (mtf == tfCount ? " — sab bullish ✅" : mtf == -tfCount ? " — sab bearish ✅" : ""), 13, SOFT));
        if (bt != null) {
            c.addView(divider());
            c.addView(bold("📊 Backtest — yahi rule isi chart par pehle", 13, TEXT));
            if (bt.trades == 0) c.addView(text("Is chart par pichle data mein rule ka koi mukammal trade nahi bana.", 12, MUTED));
            else {
                int wc = bt.winRate >= 60 ? GREEN : bt.winRate >= 50 ? YELLOW : RED;
                c.addView(bold(String.format(Locale.US, "TP 1R: %d trades · ✅ %d · ❌ %d · win rate %.0f%% · avg %+.2fR",
                        bt.trades, bt.wins, bt.losses, bt.winRate, bt.avgR), 13, wc));
                if (bt2 != null && bt2.trades > 0)
                    c.addView(text(String.format(Locale.US, "TP 2R: %d trades · win rate %.0f%% · avg %+.2fR", bt2.trades, bt2.winRate, bt2.avgR), 12, SOFT));
                if (!bt.enough()) c.addView(text("⚠️ 5 se kam trades — natija pakka nahi", 12, YELLOW));
            }
        }
        learnToggle(c, "Rule: (1) EMA21 > EMA50 aur price EMA50/200 ke upar = uptrend, (2) EMA9 ne EMA21 ko upar kata ya price EMA21 se uchhli = trigger, "
                + "(3) RSI 50–72 aur MACD positive = momentum, (4) volume average ke barabar ya zyada. SELL is ka ulta.\n\n"
                + "Backtest: bot ne yahi rule pichli candles par chala kar dekha — har trade mein stop 1.5×ATR aur target 1R (ya 2R). "
                + "Agar target pehle laga to WIN, stop pehle to LOSS (ek hi candle mein dono = LOSS, ehtiyatan). "
                + "1R par 50% se zyada aur 2R par 34% se zyada win rate = rule ka faida. Accuracy mode mein kam win rate wale setups ke signal nahi aate.");
    }

    /** "How the final score was built": weighted average of every section. */
    private void scoreBuildCard(LinearLayout col, List<CoinReport.Section> secs, int total, int confidence) {
        LinearLayout c = card(col, ACC);
        c.addView(bold("🧠 Final score kaise bana?", 15, TEXT));
        double ws = 0;
        for (CoinReport.Section s : secs) if (s.available) ws += s.weight;
        for (CoinReport.Section s : secs) {
            if (!s.available || ws <= 0) continue;
            double share = s.score * s.weight / ws / 2;
            LinearLayout r = row();
            r.addView(text(s.icon + " " + s.title, 12, SOFT), new LinearLayout.LayoutParams(0, -2, 1));
            r.addView(bold(String.format(Locale.US, "%+d × %d%% = %+.1f", s.score, Math.round(s.weight * 100 / ws), share), 12,
                    share > 0.5 ? GREEN : share < -0.5 ? RED : MUTED));
            c.addView(r);
        }
        c.addView(divider());
        c.addView(bold("50 + sab ka jor = " + total + "/100 → " + (total >= 50 ? "BUY" : "SELL") + " · confidence " + confidence + "%", 13, total >= 50 ? GREEN : RED));
        learnToggle(c, "Har section −100 (poora bearish) se +100 (poora bullish) score deta hai. Har ek ka wazan (weight) alag hai — "
                + "technical aur volume zyada ahem, sentiment kam. Wazni ausat ko aadha karke 50 mein jora jata hai: 50 se upar BUY, neeche SELL. "
                + "Confidence = 50 se kitna door (×2.5). Signal tabhi bhejta hai jab score 62+ (BUY) ya 38− (SELL) ho.");
    }

    /** Expandable "📖 Seekhein" teaching note. */
    private void learnToggle(LinearLayout parent, final String tip) {
        final TextView body = text(tip, 12, 0xFFB8C2D3);
        body.setPadding(dp(10), dp(8), dp(10), dp(8));
        body.setBackground(round(0x1422D3EE, 10, 0x3322D3EE));
        body.setVisibility(View.GONE);
        final TextView t = bold("📖 Seekhein ▾", 12, CYAN_TXT);
        t.setPadding(0, dp(8), 0, dp(4));
        t.setOnClickListener(v -> {
            boolean open = body.getVisibility() != View.VISIBLE;
            body.setVisibility(open ? View.VISIBLE : View.GONE);
            t.setText(open ? "📖 Seekhein ▴" : "📖 Seekhein ▾");
        });
        parent.addView(t);
        parent.addView(body);
    }

    /** Signal screen: "how this signal was built" step by step. */
    private void signalLearnCard(LinearLayout c, JSONObject o, boolean buy) {
        JSONArray ch = o.optJSONArray("checks");
        LinearLayout k = card(c, CYAN_TXT);
        k.addView(bold("🧠 Yeh signal kaise bana?", 16, TEXT));
        if (ch == null || ch.length() == 0) {
            k.addView(text("Yeh purane version ka signal hai — tafseel mehfooz nahi. Naye signals mein har check dikhega.", 12, MUTED));
            return;
        }
        k.addView(text("Bot ne yeh sab cheezein check kin — ✅ = " + (buy ? "BUY" : "SELL") + " ke haq mein, ❌ = khilaf, ➖ = neutral:", 12, MUTED));
        for (int i = 0; i < ch.length(); i++) {
            String l = ch.optString(i);
            k.addView(text(l, 13, l.startsWith("✅") ? GREEN : l.startsWith("❌") ? RED : l.trim().startsWith("✅") ? GREEN : l.trim().startsWith("❌") ? RED : SOFT));
        }
        if (o.has("wr")) k.addView(bold("📊 Is rule ka backtest win rate: " + o.optInt("wr") + "% (" + o.optInt("bt") + " trades)", 13, ACC2));
        JSONArray secs = o.optJSONArray("secs");
        if (secs != null && secs.length() > 0) {
            k.addView(divider());
            k.addView(bold("Score mein har source ka hissa:", 12, TEXT));
            for (int i = 0; i < secs.length(); i++) {
                JSONObject s = secs.optJSONObject(i);
                if (s == null) continue;
                int sc = s.optInt("s");
                LinearLayout r = row();
                r.addView(text(s.optString("i") + " " + s.optString("t"), 12, SOFT), new LinearLayout.LayoutParams(0, -2, 1));
                r.addView(bold((sc > 0 ? "+" : "") + sc, 12, sc > 15 ? GREEN : sc < -15 ? RED : YELLOW));
                k.addView(r);
            }
        }
        learnToggle(k, "Signal 3 marhalon mein banta hai: (1) tez scan — volume, RSI, MACD aur whales ka basic score; "
                + "(2) all-source confirmation — 10 exchanges ka volume, futures, ETF, news, patterns, moving averages sab ka wazni score 62+ (BUY) / 38− (SELL); "
                + "(3) accuracy mode — ParaDox rule ka backtest win rate, timeframes aur MA trend ek taraf. Teeno paas hon to hi notification aati hai.");
    }

    private void askClaudeText(final String data, final LinearLayout chat, final List<String[]> history, String question) {
        final String key = Prefs.claudeKey(this);
        if (key.isEmpty()) {
            chat.addView(bubble("🔑 Pehle ⚙️ Settings mein apni Claude API key daalein (console.anthropic.com).", false));
            return;
        }
        history.add(new String[]{"user", "LIVE DATA REPORT:\n" + data + "\n\nSAWAL: " + question});
        chat.addView(bubble("🙋 " + question, true));
        final TextView thinking = bubble("🤖 Claude soch raha hai...", false);
        chat.addView(thinking);
        final String model = Prefs.claudeModel(this);
        final List<String[]> snap = new ArrayList<>(history);
        pool.execute(() -> {
            try {
                final String ans = ClaudeAI.ask(key, model, snap);
                runOnUiThread(() -> { history.add(new String[]{"assistant", ans}); thinking.setText("🤖 " + ans); });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> { thinking.setText("❌ Claude se jawab nahi aaya: " + m); thinking.setTextColor(RED); });
            }
        });
    }

    // ============================================================ v12: LIVE CRYPTO NEWS
    private static String ago(long t) {
        long s = Math.max(0, (System.currentTimeMillis() - t) / 1000);
        if (s < 60) return s + " sec pehle";
        if (s < 3600) return (s / 60) + " min pehle";
        if (s < 86400) return (s / 3600) + " ghante pehle";
        return (s / 86400) + " din pehle";
    }

    private final Runnable newsTick = new Runnable() {
        @Override
        public void run() {
            if (infoOverlay == null || infoOverlay != newsOverlayRef) return;
            loadNews(false);
            handler.postDelayed(this, 20_000);
        }
    };

    private void openNews() {
        LinearLayout col = openPage("📰 Crypto News · LIVE");
        newsOverlayRef = infoOverlay;

        LinearLayout top = card(col, ACC);
        LinearLayout tr = row();
        tr.addView(bold("🛰️ News radar", 16, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        final TextView rf = chip("↻", false);
        rf.setOnClickListener(v -> loadNews(true));
        tr.addView(rf);
        top.addView(tr);
        top.addView(text(NewsEngine.sourceCount() + " sources: Cointelegraph, CoinDesk, The Block, Decrypt, Blockworks, Watcher.Guru, BNO News, AMBCrypto, "
                + "Blockchain.News, CryptoTicker, FinanceFeeds, investingLive, FXStreet, Cyber Kendra, DL News, Protos, BeInCrypto… · Google News se Reuters, "
                + "Bloomberg, CNBC, Yahoo Finance, TradingView, Bloomingbit, StreetInsider, Hindustan Times · Binance listing/delisting · "
                + "X (Twitter) ki ahem posts · CryptoPanic (Settings mein free token). Tez sources har 15 sec, baqi har 4 min. "
                + "Ek hi khabar kayi jagah ho to ek saath '+N sources'.", 11, MUTED));
        toggle(top, "🔔 Background radar + notifications", "Har 1 minute mein sab sources check · bari khabar par foran notification",
                Prefs.newsOn(this), (b, on) -> {
                    Prefs.setNewsOn(this, on);
                    if (on) startForegroundService(new Intent(this, ScannerService.class));
                    else if (!Prefs.enabled(this)) startService(new Intent(this, ScannerService.class).setAction(ScannerService.ACTION_STOP));
                    toast(on ? "News radar ON ✅" : "News radar OFF");
                });
        LinearLayout sv = row();
        sv.addView(text("Notification:", 12, SOFT), chipLp());
        final String[] sn = {"Sab", "Important+", "Sirf Critical"};
        final TextView[] sc = new TextView[3];
        for (int i = 0; i < 3; i++) {
            final int lv = i + 1;
            sc[i] = chip(sn[i], Prefs.newsMinSev(this) == lv);
            sc[i].setTextSize(11);
            sc[i].setOnClickListener(v -> {
                Prefs.setNewsMinSev(this, lv);
                for (int k = 0; k < 3; k++) styleChip(sc[k], k == lv - 1);
            });
            sv.addView(sc[i], chipLp());
        }
        top.addView(hscroll(sv));
        newsStatus = text("Load ho raha hai...", 11, ACC2);
        top.addView(newsStatus);

        LinearLayout fc = card(col);
        final EditText q = input("🔎 Coin ya lafz (BTC, Binance, hack, ETF...)", newsQuery, InputType.TYPE_CLASS_TEXT);
        q.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { newsQuery = s.toString().trim(); renderNews(); }
        });
        fc.addView(q);
        LinearLayout fr = row();
        final String[] fn = {"Sab", "🚨 Critical", "🟢 Bullish", "🔴 Bearish", "🐦 X / Social", "🏛️ Macro", "🆕 Listing/Delist", "🚨 Hacks"};
        final TextView[] fcs = new TextView[fn.length];
        for (int i = 0; i < fn.length; i++) {
            final int fi = i;
            fcs[i] = chip(fn[i], i == newsFilter);
            fcs[i].setTextSize(11);
            fcs[i].setOnClickListener(v -> {
                newsFilter = fi;
                for (int k = 0; k < fn.length; k++) styleChip(fcs[k], k == fi);
                renderNews();
            });
            fr.addView(fcs[i], chipLp());
        }
        fc.addView(hscroll(fr));
        newsList = column();
        col.addView(newsList);
        renderNews();
        loadNews(false);
        handler.removeCallbacks(newsTick);
        handler.postDelayed(newsTick, 20_000);
    }

    private void loadNews(final boolean force) {
        if (newsStatus != null) newsStatus.setText("⏳ Sab sources check ho rahe hain...");
        pool.execute(() -> {
            NewsEngine.fetch(this, force ? 0 : 15_000L);
            runOnUiThread(() -> {
                if (newsStatus != null) newsStatus.setText("● LIVE · " + NewsEngine.status() + " · har 20 sec auto-refresh");
                renderNews();
            });
        });
    }

    private boolean newsMatch(NewsEngine.Item it) {
        switch (newsFilter) {
            case 1: if (it.severity < 3) return false; break;
            case 2: if (it.dir <= 0) return false; break;
            case 3: if (it.dir >= 0) return false; break;
            case 4: if (!it.social) return false; break;
            case 5: if (!it.macro) return false; break;
            case 6: if (!it.catKey.equals("list") && !it.catKey.equals("delist")) return false; break;
            case 7: if (!it.catKey.equals("hack") && !it.catKey.equals("halt")) return false; break;
            default: break;
        }
        if (!newsQuery.isEmpty()) {
            String ql = newsQuery.toLowerCase(Locale.US);
            if (!it.title.toLowerCase(Locale.US).contains(ql) && !it.coins.contains(newsQuery.toUpperCase(Locale.US))) return false;
        }
        return true;
    }

    private void renderNews() {
        if (newsList == null) return;
        newsList.removeAllViews();
        List<NewsEngine.Item> l = NewsEngine.cached();
        int shown = 0;
        for (final NewsEngine.Item it : l) {
            if (!newsMatch(it)) continue;
            if (shown++ >= 80) break;
            int col = it.dir > 0 ? GREEN : it.dir < 0 ? RED : (it.severity >= 2 ? YELLOW : STROKE);
            LinearLayout c = card(newsList, it.severity >= 3 ? col : STROKE);
            LinearLayout h = row();
            TextView cat = bold(it.category, 10, INK);
            cat.setPadding(dp(6), dp(2), dp(6), dp(2));
            cat.setBackground(round(it.dir > 0 ? GREEN : it.dir < 0 ? RED : (it.severity >= 2 ? YELLOW : 0xFF8B95A7), 8, 0));
            h.addView(cat);
            TextView tm = text("  " + ago(it.time) + " · " + it.source + (it.sources.size() > 1 ? " +" + (it.sources.size() - 1) : ""), 10, MUTED);
            h.addView(tm, new LinearLayout.LayoutParams(0, -2, 1));
            if (it.severity >= 3) h.addView(bold("🚨", 13, RED));
            c.addView(h);
            TextView t = bold(it.title, 14, TEXT);
            t.setPadding(0, dp(4), 0, dp(2));
            c.addView(t);
            c.addView(text(NewsEngine.dirLabel(it) + " · " + NewsEngine.trim(it.impact, 130), 12, it.dir > 0 ? GREEN : it.dir < 0 ? RED : SOFT));
            if (!it.coins.isEmpty() || !it.exchanges.isEmpty()) {
                LinearLayout cr = row();
                for (final String co : it.coins) {
                    TextView cc = chip(co, false);
                    cc.setTextSize(10);
                    cc.setPadding(dp(8), dp(3), dp(8), dp(3));
                    cc.setOnClickListener(v -> { closeInfo(); openAnalyze(co + "USDT"); });
                    cr.addView(cc, chipLp());
                }
                for (String ex : it.exchanges) cr.addView(text("🏦 " + ex + "  ", 10, MUTED));
                c.addView(hscroll(cr));
            }
            c.setOnClickListener(v -> openNewsDetail(it));
        }
        if (shown == 0) newsList.addView(text(l.isEmpty() ? "\nKhabrein load ho rahi hain... (internet check karein)" : "\nIs filter mein koi khabar nahi", 13, MUTED));
    }

    private void openNewsDetail(final NewsEngine.Item it) {
        handler.removeCallbacks(newsTick);
        LinearLayout col = openPage("📰 Khabar", this::openNews);
        int dc = it.dir > 0 ? GREEN : it.dir < 0 ? RED : YELLOW;
        LinearLayout h = card(col, dc);
        LinearLayout br = row();
        TextView cat = bold(it.category, 11, INK);
        cat.setPadding(dp(7), dp(3), dp(7), dp(3));
        cat.setBackground(round(dc, 8, 0));
        br.addView(cat, chipLp());
        br.addView(bold(NewsEngine.sevLabel(it), 12, it.severity >= 3 ? RED : it.severity == 2 ? YELLOW : MUTED));
        h.addView(br);
        TextView t = bold(it.title, 17, TEXT);
        t.setTextIsSelectable(true);
        t.setPadding(0, dp(6), 0, dp(4));
        h.addView(t);
        h.addView(text(MacroEngine.pkt(it.time) + " PKT · " + ago(it.time) + " · " + it.source, 11, MUTED));
        if (!it.summary.isEmpty()) h.addView(text(it.summary, 13, SOFT));

        LinearLayout a = card(col, CYAN_TXT);
        a.addView(bold("🧠 Bot ka analysis", 16, TEXT));
        a.addView(bold("Asar: " + NewsEngine.dirLabel(it) + " · " + NewsEngine.sevLabel(it), 14, dc));
        if (!it.coins.isEmpty()) a.addView(text("🪙 Coins: " + String.join(", ", it.coins), 13, TEXT));
        if (!it.exchanges.isEmpty()) a.addView(text("🏦 Exchanges: " + String.join(", ", it.exchanges), 13, TEXT));
        a.addView(bold("📌 Is se kya ho sakta hai?", 13, YELLOW));
        a.addView(text(it.impact, 13, SOFT));
        a.addView(bold("👉 Kya karein?", 13, GREEN));
        a.addView(text(it.action, 13, SOFT));
        learnToggle(a, "Khabar parhne ka tareeqa: (1) Source kitne hain? Kayi bare outlets = sachi bari khabar; sirf ek X post = afwah bhi ho sakti hai. "
                + "(2) Khabar kab aayi aur price pehle hi kitna hil chuki? Neeche 'asal asar' dekhein. (3) 'Buy the rumor, sell the news' — achhi khabar ke din bhi "
                + "price gir sakti hai. (4) Hack, delisting, depeg sab se khatarnak — inhein kabhi nazar-andaz na karein. "
                + "Bot ki raaye keywords par mabni hai — hamesha asal khabar khud parhein.");

        LinearLayout s = card(col);
        s.addView(bold("📡 Kahan kahan report hui (" + it.sources.size() + ")", 15, TEXT));
        for (final String[] so : it.sources) {
            TextView st = text("🔗 " + so[0], 13, CYAN_TXT);
            st.setPadding(0, dp(5), 0, dp(5));
            st.setOnClickListener(v -> openUrl(so[1]));
            s.addView(st);
        }

        // ---- price reaction + chart around the news time
        String coin = null;
        for (String c0 : it.coins) if (!c0.equals("USDT") && !c0.equals("USDC") && (NewsEngine.KNOWN.isEmpty() || NewsEngine.KNOWN.contains(c0))) { coin = c0; break; }
        if (coin == null && it.exchanges.contains("Binance")) coin = "BNB";
        if (coin == null) coin = "BTC";
        final String fc = coin;
        LinearLayout r = card(col, ACC);
        r.addView(bold("📊 Asal asar — " + fc + " ki price khabar ke baad", 15, TEXT));
        final TextView rt = text("Load ho raha hai...", 13, SOFT);
        r.addView(rt);
        final ChartView cv = new ChartView(this);
        cv.setAccent(ACC);
        cv.setCompact(true);
        cv.setMessage("Chart load ho raha hai...");
        cv.setOnTap(() -> openChartFullscreen(cv, fc + "/USDT · news", false));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, dp(340));
        cl.topMargin = dp(8);
        r.addView(cv, cl);
        r.addView(text("Peeli line = khabar ka waqt · tap = full screen", 11, MUTED));
        Button an = button("📈 " + fc + " ka poora analysis", ACC, INK, 0);
        an.setOnClickListener(v -> { closeInfo(); openAnalyze(fc + "USDT"); });
        r.addView(an);
        pool.execute(() -> {
            try {
                final double[] re = NewsEngine.reaction(fc, it.time);
                long age = System.currentTimeMillis() - it.time;
                String iv = age < 4 * 3600_000L ? "1m" : age < 20 * 3600_000L ? "5m" : age < 3 * 86_400_000L ? "15m" : "1h";
                long step = ChartView.tfMillis(iv);
                final Candles c = Candles.parse(Scanner.get("/api/v3/klines?symbol=" + fc + "USDT&interval=" + iv
                        + "&startTime=" + (it.time - 60 * step) + "&limit=1000"), false);
                final String fiv = iv;
                runOnUiThread(() -> {
                    StringBuilder b = new StringBuilder();
                    b.append("Khabar ke waqt price: $").append(Fmt.price(re[0])).append('\n');
                    String[] lb = {"5 min baad", "15 min baad", "1 ghanta baad", "Ab tak"};
                    for (int k = 0; k < 4; k++)
                        b.append(lb[k]).append(": ").append(Double.isNaN(re[k + 1]) ? "abhi waqt nahi guzra" : Fmt.pct(re[k + 1])).append('\n');
                    double now = re[4];
                    b.append(Double.isNaN(now) ? "" : (it.dir != 0 && Math.signum(now) == it.dir && Math.abs(now) > 0.5
                            ? "✅ Market ne khabar ke mutabiq react kiya" : Math.abs(now) <= 0.5 ? "➖ Market par abhi khaas asar nahi"
                            : "⚠️ Market ne khabar ke ulat react kiya (pehle se price mein shamil thi?)"));
                    rt.setText(b.toString().trim());
                    if (c.n > 1) {
                        cv.setTitle(fc + "/USDT");
                        cv.setData(c, null, new double[c.n], new double[c.n], fiv, false);
                        for (String k2 : new String[]{"Fib", "Zones", "VolProfile", "Whales", "Retail", "RSI", "MACD", "BB", "EMA200", "VWAP", "Patterns", "ParaDox"}) cv.setInd(k2, false);
                        cv.setInd("EMA", true);
                        cv.setInd("Volume", true);
                        cv.setVisible(c.n);
                        cv.setEvent(it.time, "📰 News");
                    }
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> {
                    rt.setText(fc + " ka Binance data nahi mila (" + m + ")");
                    cv.setMessage("Chart nahi mila");
                });
            }
        });
        TextView o = chip("🌐 Poori khabar parhein", true);
        o.setOnClickListener(v -> openUrl(it.link));
        LinearLayout.LayoutParams ol = new LinearLayout.LayoutParams(-1, -2);
        ol.topMargin = dp(12);
        col.addView(o, ol);
    }

    // ============================================================ v16: CATALYST RADAR
    private int catFilter = 0;
    private LinearLayout catList;
    private TextView catStatus;

    private static String until(long t) {
        long d = t - System.currentTimeMillis();
        if (d <= 0) return "abhi / ho chuka";
        long m = d / 60_000L;
        if (m < 60) return m + " min baad";
        if (m < 48 * 60) return (m / 60) + " ghante baad";
        return (m / 1440) + " din baad";
    }

    private void openCatalysts() {
        LinearLayout col = openPage("📆 Catalyst Radar");
        LinearLayout top = card(col, ACC);
        top.addView(bold("Aane wale events — pehle se pata, pehle se tayyar", 15, TEXT));
        top.addView(text("Sirf PUBLIC aur legal sources: DefiLlama (token unlocks), Binance (listing · delisting · Launchpool · airdrop), "
                + "news mein di gayi tareekhein (mainnet, TGE, ETF deadline), US macro calendar, Polymarket ke odds (log asal paisa laga kar kya "
                + "umeed rakh rahe hain), Binance futures mein positions ka jama hona. CoinMarketCal ka free key Settings mein daalein to aur events.\n"
                + "⚠️ Asal 'insider' maloomat koi free/legal jagah nahi deti — aise dawe aksar scam hote hain.", 11, MUTED));
        toggle(top, "🔔 Event reminders", "Bare event se 24 ghante aur 1 ghanta pehle notification", Prefs.notifOn(this, Prefs.N_CATALYST),
                (b, on) -> Prefs.setNotif(this, Prefs.N_CATALYST, on));
        catStatus = text("Load ho raha hai...", 11, ACC2);
        top.addView(catStatus);
        LinearLayout fr = row();
        final String[] fn = {"Sab", "🔓 Unlocks", "🆕 Listings", "📤 Delist", "🚀 Launch/Airdrop", "🏛️ Macro/ETF", "🎲 Polymarket", "📊 Futures"};
        final TextView[] fc = new TextView[fn.length];
        for (int i = 0; i < fn.length; i++) {
            final int fi = i;
            fc[i] = chip(fn[i], i == catFilter);
            fc[i].setTextSize(11);
            fc[i].setOnClickListener(v -> {
                catFilter = fi;
                for (int k = 0; k < fn.length; k++) styleChip(fc[k], k == fi);
                renderCatalysts();
            });
            fr.addView(fc[i], chipLp());
        }
        LinearLayout fcCard = card(col);
        fcCard.addView(hscroll(fr));
        catList = column();
        col.addView(catList);
        renderCatalysts();
        pool.execute(() -> {
            CatalystEngine.fetch(this, 10 * 60_000L);
            runOnUiThread(() -> {
                if (catStatus != null) catStatus.setText("● " + CatalystEngine.status());
                renderCatalysts();
            });
        });
    }

    private boolean catMatch(CatalystEngine.Event e) {
        switch (catFilter) {
            case 1: return e.type.equals(CatalystEngine.UNLOCK);
            case 2: return e.type.equals(CatalystEngine.LISTING);
            case 3: return e.type.equals(CatalystEngine.DELIST);
            case 4: return e.type.equals(CatalystEngine.LAUNCH) || e.type.equals(CatalystEngine.AIRDROP) || e.type.equals(CatalystEngine.EVENT);
            case 5: return e.type.equals(CatalystEngine.MACRO) || e.type.equals(CatalystEngine.ETF);
            case 6: return e.type.equals(CatalystEngine.ODDS);
            case 7: return e.type.equals(CatalystEngine.OI);
            default: return true;
        }
    }

    private void renderCatalysts() {
        if (catList == null) return;
        catList.removeAllViews();
        List<CatalystEngine.Event> l = CatalystEngine.cached();
        // live signals (odds / futures) first, then by date
        List<CatalystEngine.Event> live = new ArrayList<>(), sched = new ArrayList<>();
        for (CatalystEngine.Event e : l) {
            if (!catMatch(e)) continue;
            if (e.type.equals(CatalystEngine.ODDS) || e.type.equals(CatalystEngine.OI)) live.add(e); else sched.add(e);
        }
        if (!live.isEmpty()) {
            TextView h = bold("⚡ ABHI KE ISHARE", 11, MUTED);
            h.setLetterSpacing(0.12f);
            h.setPadding(dp(4), dp(14), 0, 0);
            catList.addView(h);
            for (CatalystEngine.Event e : live) catalystRow(e);
        }
        String lastDay = "";
        SimpleDateFormat df = new SimpleDateFormat("EEEE, dd MMM", Locale.US);
        df.setTimeZone(java.util.TimeZone.getTimeZone("Asia/Karachi"));
        for (CatalystEngine.Event e : sched) {
            String day = df.format(new Date(e.time));
            if (!day.equals(lastDay)) {
                lastDay = day;
                TextView h = bold(day.toUpperCase(Locale.US), 11, MUTED);
                h.setLetterSpacing(0.12f);
                h.setPadding(dp(4), dp(14), 0, 0);
                catList.addView(h);
            }
            catalystRow(e);
        }
        if (live.isEmpty() && sched.isEmpty())
            catList.addView(text(l.isEmpty() ? "\nEvents load ho rahe hain..." : "\nIs filter mein koi event nahi", 13, MUTED));
    }

    private void catalystRow(final CatalystEngine.Event e) {
        int col = e.dir > 0 ? GREEN : e.dir < 0 ? RED : YELLOW;
        LinearLayout c = card(catList, e.severity >= 3 ? col : STROKE);
        LinearLayout h = row();
        TextView b = bold(e.icon() + " " + CatalystEngine.label(e), 10, INK);
        b.setPadding(dp(6), dp(2), dp(6), dp(2));
        b.setBackground(round(col, 8, 0));
        h.addView(b);
        boolean detected = e.type.equals(CatalystEngine.ODDS) || e.type.equals(CatalystEngine.OI);
        h.addView(text("  " + (detected ? ago(e.time) : MacroEngine.pkt(e.time) + " · " + until(e.time)) + (e.estimated ? " · andaza" : ""), 10, MUTED),
                new LinearLayout.LayoutParams(0, -2, 1));
        if (e.severity >= 3) h.addView(bold("🔥", 12, col));
        c.addView(h);
        TextView t = bold(e.title, 14, TEXT);
        t.setPadding(0, dp(4), 0, dp(2));
        c.addView(t);
        c.addView(text((e.dir > 0 ? "🟢 BULLISH · " : e.dir < 0 ? "🔴 BEARISH · " : "⚪ ") + NewsEngine.trim(e.impact, 140), 12, e.dir > 0 ? GREEN : e.dir < 0 ? RED : SOFT));
        if (!e.coins.isEmpty()) {
            LinearLayout cr = row();
            for (final String co : e.coins) {
                TextView cc = chip(co, false);
                cc.setTextSize(10);
                cc.setPadding(dp(8), dp(3), dp(8), dp(3));
                cc.setOnClickListener(v -> { closeInfo(); openAnalyze(co + "USDT"); });
                cr.addView(cc, chipLp());
            }
            c.addView(hscroll(cr));
        }
        c.setOnClickListener(v -> openCatalystDetail(e));
    }

    private void openCatalystDetail(final CatalystEngine.Event e) {
        LinearLayout col = openPage(e.icon() + " " + CatalystEngine.label(e), this::openCatalysts);
        int dc = e.dir > 0 ? GREEN : e.dir < 0 ? RED : YELLOW;
        LinearLayout h = card(col, dc);
        TextView t = bold(e.title, 17, TEXT);
        t.setTextIsSelectable(true);
        h.addView(t);
        boolean detected = e.type.equals(CatalystEngine.ODDS) || e.type.equals(CatalystEngine.OI);
        h.addView(bold(detected ? "Pata chala: " + ago(e.time) : "📅 " + MacroEngine.pkt(e.time) + " PKT · " + until(e.time)
                + (e.estimated ? " (tareekh andaza — asal source dekhein)" : ""), 13, YELLOW));
        h.addView(text("Source: " + e.source, 12, MUTED));
        if (e.usd > 0) h.addView(text("Size: " + Fmt.usd(e.usd) + (e.pctMcap > 0 ? String.format(Locale.US, " (%.2f%% market cap)", e.pctMcap) : ""), 13, TEXT));
        LinearLayout a = card(col, CYAN_TXT);
        a.addView(bold("🧠 Bot ka analysis", 16, TEXT));
        a.addView(bold("Asar: " + (e.dir > 0 ? "🟢 BULLISH" : e.dir < 0 ? "🔴 BEARISH" : "⚪ Direction pakki nahi") + " · " + (e.severity >= 3 ? "🔥 Bara" : e.severity == 2 ? "Darmiyana" : "Chhota"), 14, dc));
        a.addView(bold("📌 Kya ho sakta hai?", 13, YELLOW));
        a.addView(text(e.impact, 13, SOFT));
        a.addView(bold("👉 Kya karein?", 13, GREEN));
        a.addView(text(e.action, 13, SOFT));
        if (!e.coins.isEmpty()) {
            for (final String co : e.coins) {
                Button an = button("📈 " + co + " ka analysis", ACC, INK, 0);
                an.setOnClickListener(v -> { closeInfo(); openAnalyze(co + "USDT"); });
                a.addView(an);
            }
        }
        learnToggle(a, "Bade traders 'catalyst' (aane wala waqia) ke hisaab se pehle position lete hain: unlock se pehle bechna, listing se pehle khareedna, "
                + "event ke din profit lena ('buy the rumor, sell the news'). Tareekh jitni qareeb aur event jitna bara, asar utna zyada. "
                + "Event ke din volatility barhti hai — stop-loss zaroor lagayen.");
        if (!e.link.isEmpty()) {
            TextView o = chip("🌐 Source kholen", true);
            o.setOnClickListener(v -> openUrl(e.link));
            LinearLayout.LayoutParams ol = new LinearLayout.LayoutParams(-1, -2);
            ol.topMargin = dp(12);
            col.addView(o, ol);
        }
    }

    // ============================================================ v14: ABOUT
    private void openAbout() {
        LinearLayout col = openPage("ℹ️ About");
        String ver = "?";
        try {
            ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
        }
        LinearLayout h = card(col, ACC);
        h.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView logo = bold("P", 40, INK);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(round(ACC, 24, 0));
        h.addView(logo, new LinearLayout.LayoutParams(dp(84), dp(84)));
        TextView nm = bold("ParaDox", 26, TEXT);
        nm.setGravity(Gravity.CENTER);
        nm.setLetterSpacing(0.08f);
        h.addView(nm);
        TextView tg = text("Smart Trading Signals · Crypto · Gold · Forex", 13, ACC2);
        tg.setGravity(Gravity.CENTER);
        h.addView(tg);
        TextView vv = text("Version " + ver, 12, MUTED);
        vv.setGravity(Gravity.CENTER);
        h.addView(vv);

        LinearLayout d = card(col, YELLOW);
        d.addView(text("DEVELOPER & OWNER", 11, MUTED));
        d.addView(bold("Nohman Arshid", 22, TEXT));
        d.addView(text("Founder · Product design · Trading strategy", 13, SOFT));
        d.addView(text("🇵🇰 Pakistan", 13, SOFT));
        d.addView(text("ParaDox ka idea, design aur trading logic Nohman Arshid ka hai — maqsad: aam trader ko bade players jaisa data, "
                + "saaf signals aur seekhne ka mauqa ek hi app mein dena.", 12, MUTED));

        LinearLayout ho = card(col);
        ho.addView(bold("☁️ Hosting & updates", 15, TEXT));
        ho.addView(text("• Source code: GitHub (" + Prefs.updateRepo(this) + ")\n"
                + "• Har naya version GitHub Actions par khud build hota hai aur Releases par publish hota hai\n"
                + "• App ke andar se update: Settings → App updates (fixed signing key — data mehfooz rehta hai)\n"
                + "• Signals 24/7 aap ke phone par chalne wali background service banati hai — koi beech ka server nahi", 13, SOFT));
        TextView gh = chip("🔗 GitHub Releases", true);
        gh.setOnClickListener(v -> openUrl("https://github.com/" + Prefs.updateRepo(this) + "/releases/latest"));
        LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(-2, -2);
        gl.topMargin = dp(8);
        ho.addView(gh, gl);

        LinearLayout f = card(col);
        f.addView(bold("⭐ Kya kya hai", 15, TEXT));
        f.addView(text("• Live charts 1 minute se ALL-time tak — simple chart, aur analysis par khud patterns + poora plan\n"
                + "• Scalp bot (heavy buying/selling) · Spot bot (achhi entry, 1 hafta – 1 mahina) · Gold & Forex bots\n"
                + "• ParaDox rule + backtest + accuracy mode · Moving averages · Chart patterns\n"
                + "• 10 exchanges ka volume · whales · futures · ETF · institutions · on-chain\n"
                + "• Live news radar (46 sources) · Catalyst radar (unlocks, listings, Polymarket) · Fed / CPI / NFP calendar\n"
                + "• Watch-only portfolio · Claude AI analyst · Academy (22 sabaq) · Trading tools", 13, SOFT));

        LinearLayout pr = card(col, GREEN);
        pr.addView(bold("🔒 Privacy", 15, TEXT));
        pr.addView(text("Aap ki API keys aur wallets sirf aap ke phone mein rehte hain. Wallet tracker sirf public address dekhta hai — "
                + "seed phrase / private key kabhi nahi maangta. Koi account ya login nahi.", 13, SOFT));

        LinearLayout ds = card(col);
        ds.addView(bold("📡 Data sources", 15, TEXT));
        ds.addView(text("Binance (spot + futures + WebSocket), Bybit, OKX, Coinbase, Kraken, KuCoin, Gate, Bitget, Farside (ETF), DefiLlama, "
                + "CoinGecko, Coin Metrics, Blockchain.com, mempool.space, Yahoo Finance (gold/forex), FRED & ForexFactory (macro), "
                + "46 news sources, Anthropic Claude (AI).", 12, MUTED));

        LinearLayout dc = card(col, RED);
        dc.addView(bold("⚠️ Disclaimer", 15, TEXT));
        dc.addView(text("ParaDox maloomat aur taleem ke liye hai, financial advice nahi. Koi bhi signal 100% sahi nahi hota. "
                + "Hamesha stop-loss lagayen aur utna hi lagayen jitna khona bardasht ho.", 12, SOFT));
        TextView cp = text("© 2026 Nohman Arshid · All rights reserved", 11, MUTED);
        cp.setGravity(Gravity.CENTER);
        cp.setPadding(0, dp(16), 0, 0);
        col.addView(cp);
    }

    // ============================================================ v11: ACADEMY
    private void openAcademy() {
        LinearLayout col = openPage("📚 ParaDox Academy");
        LinearLayout in = card(col, ACC);
        in.addView(bold("Trading seekhein — qadam ba qadam", 16, TEXT));
        in.addView(text("Har sabaq asaan Roman Urdu mein hai. Tarteeb se parhein: Beginner → Intermediate → Advanced. "
                + "'Essential' wale sabaq (risk, SL/TP, psychology) sab se zaroori hain — inhein zaroor parhein. "
                + "Analysis aur signals mein bhi har jagah '📖 Seekhein' daba kar wahi baat wahan seekh sakte hain.", 12, MUTED));
        for (int i = 0; i < Academy.LESSONS.length; i++) {
            final String[] l = Academy.LESSONS[i];
            final int num = i + 1;
            LinearLayout c = card(col);
            LinearLayout r = row();
            TextView ic = text(l[0], 22, TEXT);
            ic.setGravity(Gravity.CENTER);
            ic.setBackground(round((ACC & 0x00FFFFFF) | 0x22000000, 12, 0));
            r.addView(ic, new LinearLayout.LayoutParams(dp(44), dp(44)));
            LinearLayout t = column();
            t.setPadding(dp(12), 0, 0, 0);
            t.addView(bold(num + ". " + l[1], 14, TEXT));
            int lc = l[2].equals("Essential") ? RED : l[2].equals("Beginner") ? GREEN : l[2].equals("Advanced") ? CLAUDE : YELLOW;
            t.addView(bold(l[2], 11, lc));
            r.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
            r.addView(bold("›", 22, MUTED));
            c.addView(r);
            c.setOnClickListener(v -> openLesson(num - 1));
        }
    }

    private void openLesson(final int i) {
        final String[] l = Academy.LESSONS[i];
        LinearLayout col = openPage(l[0] + " Sabaq " + (i + 1), this::openAcademy);
        LinearLayout c = card(col, ACC);
        c.addView(bold(l[1], 18, TEXT));
        c.addView(bold(l[2], 12, ACC2));
        TextView body = text(l[3], 14, SOFT);
        body.setLineSpacing(dp(3), 1f);
        body.setTextIsSelectable(true);
        body.setPadding(0, dp(8), 0, 0);
        c.addView(body);
        LinearLayout nav = row();
        nav.setPadding(0, dp(12), 0, 0);
        if (i > 0) {
            TextView pv = chip("‹ Pichla", false);
            pv.setOnClickListener(v -> openLesson(i - 1));
            nav.addView(pv, chipLp());
        }
        nav.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
        TextView all = chip("☰ Sab sabaq", false);
        all.setOnClickListener(v -> openAcademy());
        nav.addView(all, chipLp());
        if (i < Academy.LESSONS.length - 1) {
            TextView nx = chip("Agla ›", true);
            nx.setOnClickListener(v -> openLesson(i + 1));
            nav.addView(nx);
        }
        col.addView(nav);
    }

    // ============================================================ v11: TRADING TOOLS (calculators)
    private EditText calcField(LinearLayout parent, String label, String value) {
        LinearLayout c = column();
        c.addView(text(label, 11, MUTED));
        EditText e = input("", value, InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        c.addView(e);
        parent.addView(c, new LinearLayout.LayoutParams(0, -2, 1));
        return e;
    }

    private LinearLayout calcRow(LinearLayout parent) {
        LinearLayout r = row();
        parent.addView(r);
        return r;
    }

    private static String n(double v) {
        if (Math.abs(v) >= 1000) return String.format(Locale.US, "%,.2f", v);
        if (Math.abs(v) >= 1) return String.format(Locale.US, "%.4f", v);
        return String.format(Locale.US, "%.8f", v);
    }

    private void openTools() {
        LinearLayout col = openPage("🧮 Trading Tools");

        // ---- 1. SL / TP calculator
        LinearLayout a = card(col, ACC);
        a.addView(bold("🎯 Stop Loss & Take Profit calculator", 16, TEXT));
        a.addView(text("Entry aur stop (price ya %) daalein — TP levels R:R ke hisaab se ban jayenge.", 12, MUTED));
        final boolean[] isLong = {true};
        LinearLayout sd = row();
        final TextView lg = chip("🟢 LONG / BUY", true), sh = chip("🔴 SHORT / SELL", false);
        sd.addView(lg, chipLp());
        sd.addView(sh, chipLp());
        a.addView(sd);
        LinearLayout r1 = calcRow(a);
        final EditText en = calcField(r1, "Entry price", "");
        r1.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        final EditText slp = calcField(r1, "Stop price (ya khali)", "");
        LinearLayout r2 = calcRow(a);
        final EditText slPct = calcField(r2, "Ya stop % door", "2");
        r2.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        final EditText rrEt = calcField(r2, "R:R targets (jaise 1,2,3)", "");
        rrEt.setInputType(InputType.TYPE_CLASS_TEXT);
        rrEt.setText("1,2,3");
        LinearLayout r3 = calcRow(a);
        final EditText amt = calcField(r3, "Position size (USDT)", "100");
        r3.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        final EditText lev = calcField(r3, "Leverage (spot = 1)", "1");
        final TextView outA = text("", 13, TEXT);
        final Runnable calcA = () -> {
            double e = parse(en, 0), s = parse(slp, 0), pct = parse(slPct, 2), size = parse(amt, 0), L = Math.max(1, parse(lev, 1));
            if (e <= 0) { outA.setText("Entry price likhen"); return; }
            if (s <= 0) s = isLong[0] ? e * (1 - pct / 100) : e * (1 + pct / 100);
            double risk = Math.abs(e - s);
            if ((isLong[0] && s >= e) || (!isLong[0] && s <= e)) { outA.setText("⚠️ " + (isLong[0] ? "LONG mein stop entry se NEECHE" : "SHORT mein stop entry se UPAR") + " hona chahiye"); return; }
            StringBuilder b = new StringBuilder();
            double qty = size * L / e;
            double lossUsd = qty * risk;
            b.append("🛑 Stop: ").append(n(s)).append(String.format(Locale.US, "  (%.2f%% · nuksan ≈ $%.2f)%n", risk / e * 100, lossUsd));
            for (String t : rrEt.getText().toString().split("[,\\s]+")) {
                double rr;
                try { rr = Double.parseDouble(t); } catch (Exception x) { continue; }
                if (rr <= 0) continue;
                double tp = isLong[0] ? e + rr * risk : e - rr * risk;
                if (tp <= 0) continue;
                b.append(String.format(Locale.US, "🎯 TP %.1fR: %s  (%+.2f%% · faida ≈ $%.2f)%n", rr, n(tp), (tp / e - 1) * 100, qty * Math.abs(tp - e)));
            }
            if (L > 1) {
                double liq = isLong[0] ? e * (1 - 1 / L * 0.95) : e * (1 + 1 / L * 0.95);
                b.append(String.format(Locale.US, "⚠️ Takreeban liquidation: %s (%.0fx) — stop is se pehle hona lazmi%n", n(liq), L));
                if (isLong[0] ? liq >= s : liq <= s) b.append("❌ Stop liquidation ke BAAD hai — leverage kam karein!\n");
            }
            b.append(String.format(Locale.US, "Coins: %s · position value $%.2f", n(qty), qty * e));
            outA.setText(b.toString());
        };
        lg.setOnClickListener(v -> { isLong[0] = true; styleChip(lg, true); styleChip(sh, false); calcA.run(); });
        sh.setOnClickListener(v -> { isLong[0] = false; styleChip(lg, false); styleChip(sh, true); calcA.run(); });
        TextView ca = chip("Calculate", true);
        ca.setOnClickListener(v -> { hideKeyboard(); calcA.run(); });
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-2, -2);
        cl.topMargin = dp(6);
        a.addView(ca, cl);
        a.addView(outA);
        learnToggle(a, "R = entry aur stop ka farq (aap ka khatra). 2R target ka matlab: jitna khatra, us ka do guna faida. "
                + "1:2 R:R par sirf 34% trades jeet kar bhi faida hota hai. Stop hamesha us jagah rakhen jahan aap ka idea ghalat ho jaye "
                + "(support ke neeche / resistance ke upar), sirf % se nahi.");

        // ---- 2. Average price / DCA calculator
        LinearLayout b = card(col, ACC2);
        b.addView(bold("➗ Average price (DCA) calculator", 16, TEXT));
        b.addView(text("Har khareed ki price aur kitne USDT lagaye (ya kitne coins) — average, breakeven aur abhi ka P/L.", 12, MUTED));
        final boolean[] byCoins = {false};
        LinearLayout md = row();
        final TextView mU = chip("USDT amount", true), mC = chip("Coins quantity", false);
        md.addView(mU, chipLp());
        md.addView(mC, chipLp());
        b.addView(md);
        final LinearLayout rows = column();
        b.addView(rows);
        final List<EditText[]> buys = new ArrayList<>();
        final Runnable addRow = () -> {
            LinearLayout r = row();
            EditText p = calcField(r, "Buy #" + (buys.size() + 1) + " price", "");
            r.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
            EditText q = calcField(r, byCoins[0] ? "Coins" : "USDT", "");
            rows.addView(r);
            buys.add(new EditText[]{p, q});
        };
        addRow.run();
        addRow.run();
        LinearLayout br = row();
        TextView add = chip("＋ Aur buy", false);
        add.setOnClickListener(v -> addRow.run());
        br.addView(add, chipLp());
        TextView rm = chip("− Aakhri hatao", false);
        rm.setOnClickListener(v -> {
            if (buys.size() <= 1) return;
            buys.remove(buys.size() - 1);
            rows.removeViewAt(rows.getChildCount() - 1);
        });
        br.addView(rm, chipLp());
        b.addView(br);
        LinearLayout r4 = calcRow(b);
        final EditText now = calcField(r4, "Abhi ki price (P/L ke liye)", "");
        r4.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        final EditText fee = calcField(r4, "Fee % (har taraf)", "0.1");
        LinearLayout r5 = calcRow(b);
        final EditText tgt = calcField(r5, "Target average (ya khali)", "");
        r5.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        final EditText nxt = calcField(r5, "Agli buy ki price", "");
        final TextView outB = text("", 13, TEXT);
        final Runnable calcB = () -> {
            double cost = 0, coins = 0;
            int cnt = 0;
            for (EditText[] e : buys) {
                double p = parse(e[0], 0), q = parse(e[1], 0);
                if (p <= 0 || q <= 0) continue;
                double c = byCoins[0] ? q : q / p;
                coins += c;
                cost += c * p;
                cnt++;
            }
            if (coins <= 0) { outB.setText("Kam az kam ek buy ki price aur amount likhen"); return; }
            double avg = cost / coins, f = parse(fee, 0.1) / 100;
            double be = avg * (1 + f) / (1 - f);
            StringBuilder s = new StringBuilder();
            s.append(String.format(Locale.US, "📍 Average price: %s%n", n(avg)));
            s.append(String.format(Locale.US, "Kul lagaya: $%.2f · kul coins: %s · %d buys%n", cost, n(coins), cnt));
            s.append(String.format(Locale.US, "⚖️ Breakeven (fees ke saath): %s%n", n(be)));
            double px = parse(now, 0);
            if (px > 0) {
                double val = coins * px * (1 - f);
                double pl = val - cost;
                s.append(String.format(Locale.US, "%s Abhi: $%.2f · P/L %+.2f$ (%+.2f%%)%n", pl >= 0 ? "🟢" : "🔴", val, pl, pl / cost * 100));
            }
            double ta = parse(tgt, 0), np = parse(nxt, 0);
            if (ta > 0 && np > 0) {
                if ((np < ta && ta < avg) || (np > ta && ta > avg)) {
                    double needCoins = coins * (avg - ta) / (ta - np);
                    s.append(String.format(Locale.US, "🎯 Average %s tak laane ke liye %s par %s coins (≈ $%.2f) aur khareedne honge%n",
                            n(ta), n(np), n(needCoins), needCoins * np));
                } else s.append("Target average agli buy ki price aur abhi ke average ke darmiyan hona chahiye\n");
            }
            outB.setText(s.toString().trim());
        };
        mU.setOnClickListener(v -> { byCoins[0] = false; styleChip(mU, true); styleChip(mC, false); toast("Ab doosre khane mein USDT likhen"); });
        mC.setOnClickListener(v -> { byCoins[0] = true; styleChip(mU, false); styleChip(mC, true); toast("Ab doosre khane mein coins likhen"); });
        TextView cb = chip("Calculate", true);
        cb.setOnClickListener(v -> { hideKeyboard(); calcB.run(); });
        LinearLayout.LayoutParams cbl = new LinearLayout.LayoutParams(-2, -2);
        cbl.topMargin = dp(6);
        b.addView(cb, cbl);
        b.addView(outB);
        learnToggle(b, "Average = kul paisa ÷ kul coins. Neeche khareedne se average neeche aata hai, magar paisa bhi zyada phans jata hai. "
                + "Sirf mazboot coins mein aur pehle se tay plan ke saath DCA karein. Futures mein harte trade mein average karna liquidation ki taraf le jata hai.");

        // ---- 3. Position size
        LinearLayout c = card(col, GREEN);
        c.addView(bold("🛡️ Position size (risk %) calculator", 16, TEXT));
        LinearLayout r6 = calcRow(c);
        final EditText bal = calcField(r6, "Balance (USDT)", String.valueOf(Prefs.balance(this)));
        r6.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        final EditText rk = calcField(r6, "Risk per trade %", String.valueOf(Prefs.riskPct(this)));
        LinearLayout r7 = calcRow(c);
        final EditText e2 = calcField(r7, "Entry", "");
        r7.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        final EditText s2 = calcField(r7, "Stop-loss", "");
        final TextView outC = text("", 13, TEXT);
        TextView cc = chip("Calculate", true);
        cc.setOnClickListener(v -> {
            hideKeyboard();
            double bb = parse(bal, 0), pct = parse(rk, 1), e = parse(e2, 0), st = parse(s2, 0);
            if (bb <= 0 || e <= 0 || st <= 0 || e == st) { outC.setText("Balance, entry aur stop likhen"); return; }
            Prefs.saveRisk(this, (float) bb, (float) pct);
            double riskUsd = bb * pct / 100, per = Math.abs(e - st), qty = riskUsd / per, pos = qty * e;
            outC.setText(String.format(Locale.US, "Risk: $%.2f (%.1f%%)\nKhareedain: %s coins ≈ $%.2f\nStop door: %.2f%%%s",
                    riskUsd, pct, n(qty), pos, per / e * 100,
                    pos > bb ? String.format(Locale.US, "\n⚠️ Position balance se badi — %.1fx leverage chahiye", pos / bb) : ""));
        });
        LinearLayout.LayoutParams ccl = new LinearLayout.LayoutParams(-2, -2);
        ccl.topMargin = dp(6);
        c.addView(cc, ccl);
        c.addView(outC);
        learnToggle(c, "Professional usool: ek trade mein balance ka 1–2% se zyada risk nahi. Position size stop ki doori se tay hota hai — "
                + "stop door ho to position chhoti, qareeb ho to bari. Is tarah har trade mein nuksan barabar rehta hai.");

        // ---- 4. Profit / loss
        LinearLayout d = card(col, YELLOW);
        d.addView(bold("💵 Profit / Loss calculator", 16, TEXT));
        LinearLayout r8 = calcRow(d);
        final EditText pe = calcField(r8, "Entry", "");
        r8.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        final EditText px = calcField(r8, "Exit", "");
        LinearLayout r9 = calcRow(d);
        final EditText pa = calcField(r9, "Amount (USDT)", "100");
        r9.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        final EditText pl = calcField(r9, "Leverage", "1");
        final TextView outD = text("", 13, TEXT);
        TextView cd = chip("LONG P/L", true), cs = chip("SHORT P/L", false);
        final java.util.function.Consumer<Boolean> calcD = lng -> {
            hideKeyboard();
            double e = parse(pe, 0), x = parse(px, 0), am = parse(pa, 0), L = Math.max(1, parse(pl, 1));
            if (e <= 0 || x <= 0 || am <= 0) { outD.setText("Entry, exit aur amount likhen"); return; }
            double move = (lng ? x / e - 1 : 1 - x / e);
            double res = am * L * move;
            outD.setText(String.format(Locale.US, "%s %s: %+.2f$ · %+.2f%% apne paise par (price move %+.2f%%)",
                    res >= 0 ? "🟢" : "🔴", lng ? "LONG" : "SHORT", res, move * L * 100, (x / e - 1) * 100));
        };
        cd.setOnClickListener(v -> calcD.accept(true));
        cs.setOnClickListener(v -> calcD.accept(false));
        LinearLayout pr = row();
        pr.setPadding(0, dp(6), 0, 0);
        pr.addView(cd, chipLp());
        pr.addView(cs, chipLp());
        d.addView(pr);
        d.addView(outD);
    }

    // ============================================================ MARKET tab
    private void buildMarket() {
        LinearLayout col = pageColumn(0);
        updateBanner = card(col, GREEN);
        updateBanner.setVisibility(View.GONE);
        LinearLayout seg = row();
        seg.setPadding(dp(4), dp(4), dp(4), dp(4));
        seg.setBackground(round(CARD, 16, STROKE));
        String[] segN = {"🪙 Crypto", "🥇 Gold & Comm.", "💱 Forex"};
        for (int i = 0; i < 3; i++) {
            final int si = i;
            mktSegChips[i] = chip(segN[i], i == 0);
            mktSegChips[i].setTextSize(12);
            mktSegChips[i].setOnClickListener(v -> setMktSeg(si));
            seg.addView(mktSegChips[i], new LinearLayout.LayoutParams(0, -2, 1));
        }
        LinearLayout.LayoutParams segLp = new LinearLayout.LayoutParams(-1, -2);
        segLp.topMargin = dp(10);
        col.addView(seg, segLp);
        cryptoWrap = column();
        col.addView(cryptoWrap);
        assetWrap = column();
        assetWrap.setVisibility(View.GONE);
        col.addView(assetWrap);
        buildAssetMarket(assetWrap);
        LinearLayout top = card(cryptoWrap);
        LinearLayout tr = row();
        tr.addView(bold("Market Overview", 18, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView rf = chip("↻ Refresh", false);
        rf.setOnClickListener(v -> loadMarket());
        tr.addView(rf);
        top.addView(tr);
        fgGauge = new GaugeView(this);
        fgGauge.set(-1, "Fear & Greed", "load ho raha hai...");
        top.addView(fgGauge, new LinearLayout.LayoutParams(-1, dp(170)));
        btcView = bold("BTC —", 16, TEXT);
        top.addView(btcView);
        macroLine = bold("📅 Agla bada US event: load ho raha hai...", 13, YELLOW);
        macroLine.setOnClickListener(v -> { showTab(TAB_LISTINGS); setNewsSeg(true); });
        top.addView(macroLine);
        globalView = text("", 13, MUTED);
        top.addView(globalView);

        LinearLayout lc = card(cryptoWrap);
        marketSearch = input("🔎 Coin search karein (jaise PEPE, SUI, WIF)", "",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        marketSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) {
                marketLimit = 50;
                renderMarket();
            }
        });
        lc.addView(marketSearch);
        LinearLayout modes = row();
        String[] names = {"🚀 Gainers", "📉 Losers", "🔥 Volume", "🔤 A–Z", "⭐ Watchlist"};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            modeChips[i] = chip(names[i], i == marketMode);
            modeChips[i].setOnClickListener(v -> {
                marketMode = idx;
                marketLimit = 50;
                for (int k = 0; k < names.length; k++) styleChip(modeChips[k], k == marketMode);
                renderMarket();
            });
            modes.addView(modeChips[i], chipLp());
        }
        lc.addView(hscroll(modes));
        marketCount = text("", 12, MUTED);
        lc.addView(marketCount);
        marketList = column();
        lc.addView(marketList);
    }

    private void loadMarket() {
        btcView.setText("Load ho raha hai...");
        btcView.setTextColor(TEXT);
        pool.execute(() -> {
            try {
                final JSONArray tick = new JSONArray(Scanner.get("/api/v3/ticker/24hr?type=MINI"));
                final String[] fg = SmartMoney.fearGreed();
                final JSONObject global = fetchGlobal();
                final List<MacroEngine.Event> evs = MacroEngine.calendar(this, false);
                runOnUiThread(() -> {
                    updateMacroLine(evs);
                    mk.clear();
                    for (int i = 0; i < tick.length(); i++) {
                        JSONObject o = tick.optJSONObject(i);
                        if (o == null) continue;
                        String s = o.optString("symbol");
                        if (!Scanner.isTradable(s) || o.optDouble("lastPrice", 0) <= 0) continue;
                        mk.put(s, new double[]{o.optDouble("lastPrice", 0), o.optDouble("openPrice", 0), o.optDouble("quoteVolume", 0)});
                        NewsEngine.KNOWN.add(base(s));
                    }
                    marketLoadedAt = System.currentTimeMillis();
                    renderOverview(fg, global);
                    renderMarket();
                });
            } catch (Exception e) {
                final String msg = e.getMessage();
                runOnUiThread(() -> btcView.setText("Market load nahi hua: " + msg + "\nInternet check karke Refresh dabayen"));
            }
        });
    }

    private static JSONObject fetchGlobal() {
        try {
            return new JSONObject(Scanner.getAbsolute("https://api.coingecko.com/api/v3/global")).getJSONObject("data");
        } catch (Exception e) {
            return null;
        }
    }

    private static double change(double[] v) {
        return v[1] > 0 ? (v[0] / v[1] - 1) * 100 : 0;
    }

    private void renderOverview(String[] fg, JSONObject g) {
        if (fg != null) {
            int v = -1;
            try { v = Integer.parseInt(fg[0]); } catch (Exception ignored) { }
            fgGauge.set(v, fg[1], "Fear & Greed Index (poori market ka mood)");
        } else {
            fgGauge.set(-1, "Fear & Greed", "data nahi mila");
        }
        updateBtcLine();
        if (g != null) {
            StringBuilder s = new StringBuilder();
            JSONObject tm = g.optJSONObject("total_market_cap");
            if (tm != null) s.append("Total market cap: ").append(Fmt.usd(tm.optDouble("usd", 0)));
            s.append(String.format(Locale.US, " (%+.2f%% 24h)", g.optDouble("market_cap_change_percentage_24h_usd", 0)));
            JSONObject mcp = g.optJSONObject("market_cap_percentage");
            if (mcp != null) s.append(String.format(Locale.US, "\nBTC dominance: %.1f%% · ETH: %.1f%%",
                    mcp.optDouble("btc", 0), mcp.optDouble("eth", 0)));
            globalView.setText(s.toString());
        } else {
            globalView.setText("CoinGecko global data abhi nahi mila");
        }
    }

    private void updateBtcLine() {
        double[] btc = mk.get("BTCUSDT");
        if (btc == null) return;
        double ch = change(btc);
        btcView.setText("₿ BTC  $" + Fmt.price(btc[0]) + "   " + Fmt.pct(ch) + " (24h)  ● live");
        btcView.setTextColor(ch >= 0 ? GREEN : RED);
    }

    private void renderMarket() {
        marketList.removeAllViews();
        rowViews.clear();
        if (mk.isEmpty()) return;
        String q = marketSearch.getText().toString().trim().toUpperCase(Locale.US).replace("/", "").replace("USDT", "");
        List<String> list = new ArrayList<>();
        if (marketMode == 4) {
            for (String s : Prefs.watchlist(this)) if (mk.containsKey(s)) list.add(s);
        } else {
            for (Map.Entry<String, double[]> e : mk.entrySet()) {
                String s = e.getKey();
                if (!q.isEmpty()) {
                    if (!base(s).contains(q)) continue;
                } else if (marketMode != 3 && e.getValue()[2] < 1_000_000) continue;
                list.add(s);
            }
            if (marketMode == 0) Collections.sort(list, (a, b) -> Double.compare(change(mk.get(b)), change(mk.get(a))));
            else if (marketMode == 1) Collections.sort(list, (a, b) -> Double.compare(change(mk.get(a)), change(mk.get(b))));
            else if (marketMode == 2) Collections.sort(list, (a, b) -> Double.compare(mk.get(b)[2], mk.get(a)[2]));
            else Collections.sort(list);
            if (!q.isEmpty()) {
                // exact match first
                final String qq = q;
                Collections.sort(list, (a, b) -> Boolean.compare(!base(a).equals(qq), !base(b).equals(qq)));
            }
        }
        marketCount.setText(list.size() + " coins Binance par" + (q.isEmpty() ? "" : " · search: " + q)
                + " · prices live update hoti hain");
        if (list.isEmpty()) {
            marketList.addView(text(marketMode == 4 ? "Watchlist khali hai — Analyze tab mein ☆ dabayen" : "Koi coin nahi mila", 13, MUTED));
            return;
        }
        for (int i = 0; i < list.size() && i < marketLimit; i++) marketList.addView(coinRow(list.get(i), i + 1));
        if (list.size() > marketLimit) {
            TextView more = chip("⬇ Aur coins dikhayen (" + (list.size() - marketLimit) + " baqi)", false);
            more.setOnClickListener(v -> {
                marketLimit += 50;
                renderMarket();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(10);
            marketList.addView(more, lp);
        }
    }

    private View coinRow(final String sym, int rank) {
        double[] v = mk.get(sym);
        double ch = change(v);
        LinearLayout r = row();
        r.setPadding(0, dp(10), 0, dp(10));
        r.addView(text(String.valueOf(rank), 12, MUTED), new LinearLayout.LayoutParams(dp(30), -2));
        LinearLayout nm = column();
        nm.addView(bold(base(sym), 15, TEXT));
        nm.addView(text("Vol " + Fmt.usd(v[2]), 11, MUTED));
        r.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
        TextView pr = text("$" + Fmt.price(v[0]), 14, TEXT);
        pr.setPadding(dp(6), dp(3), dp(6), dp(3));
        r.addView(pr);
        TextView pc = bold(Fmt.pct(ch), 13, 0xFFFFFFFF);
        pc.setGravity(Gravity.CENTER);
        pc.setPadding(dp(6), dp(5), dp(6), dp(5));
        pc.setBackground(round(ch >= 0 ? GREEN : RED, 8, 0));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(dp(84), -2);
        plp.leftMargin = dp(4);
        r.addView(pc, plp);
        r.setOnClickListener(x -> openAnalyze(sym));
        rowViews.put(sym, new TextView[]{pr, pc});
        LinearLayout wrap = column();
        wrap.addView(r);
        wrap.addView(divider());
        return wrap;
    }

    private void startMarketFeed() {
        if (marketWs != null) return;
        marketWs = new WsStream("/ws/!miniTicker@arr", new WsStream.Callback() {
            @Override
            public void onText(String text) {
                try {
                    JSONArray a = new JSONArray(text);
                    synchronized (pendingMini) {
                        for (int i = 0; i < a.length(); i++) {
                            JSONObject o = a.getJSONObject(i);
                            String s = o.optString("s");
                            if (!s.endsWith("USDT")) continue;
                            pendingMini.put(s, new double[]{num(o, "c"), num(o, "o"), num(o, "q")});
                        }
                    }
                } catch (Exception ignored) {
                }
            }

            @Override
            public void onStatus(boolean live) { }
        }).start();
    }

    private void stopMarketFeed() {
        if (marketWs != null) marketWs.stop();
        marketWs = null;
    }

    /** Pushes live mini-ticker prices into the market list (flash green/red on change). */
    private void applyMarketLive() {
        Map<String, double[]> upd;
        synchronized (pendingMini) {
            if (pendingMini.isEmpty()) return;
            upd = new HashMap<>(pendingMini);
            pendingMini.clear();
        }
        for (Map.Entry<String, double[]> e : upd.entrySet()) {
            String s = e.getKey();
            double[] nv = e.getValue();
            double[] old = mk.get(s);
            if (old == null) {
                if (Scanner.isTradable(s) && nv[0] > 0) mk.put(s, nv);
                continue;
            }
            double prev = old[0];
            mk.put(s, nv);
            TextView hp = homePx.get(s);
            if (hp != null && nv[0] != prev) {
                hp.setText("$" + Fmt.price(nv[0]));
                hp.setTextColor(change(nv) >= 0 ? GREEN : RED);
            }
            TextView[] tv = rowViews.get(s);
            if (tv != null && nv[0] != prev) {
                final TextView pr = tv[0];
                pr.setText("$" + Fmt.price(nv[0]));
                pr.setBackground(round(nv[0] > prev ? 0x550ECB81 : 0x55F6465D, 6, 0));
                handler.postDelayed(() -> pr.setBackground(null), 350);
                double ch = change(nv);
                tv[1].setText(Fmt.pct(ch));
                tv[1].setBackground(round(ch >= 0 ? GREEN : RED, 8, 0));
            }
        }
        updateBtcLine();
    }

    // ============================================================ ANALYZE tab
    private void buildAnalyze() {
        LinearLayout col = pageColumn(1);

        LinearLayout mc = card(col, ACC);
        LinearLayout mr = row();
        for (int m = 0; m < 2; m++) {
            final int mm = m;
            TextView t = chip(Mode.label(m), m == uiMode);
            if (m == uiMode) t.setBackground(round(Mode.accent(m), 20, Mode.accent(m)));
            t.setOnClickListener(v -> switchMode(mm));
            mr.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
            if (m == 0) mr.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        }
        mc.addView(mr);
        mc.addView(text(Mode.desc(uiMode), 12, ACC2));

        LinearLayout sc = card(col);
        sc.addView(bold("🔍 Apna coin analyze karein", 17, TEXT));
        LinearLayout sr = row();
        searchEt = input("SOL, PEPE, BTC...", base(currentSym), InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        sr.addView(searchEt, new LinearLayout.LayoutParams(0, -2, 1));
        TextView go = chip("Analyze", true);
        go.setOnClickListener(v -> {
            String s = searchEt.getText().toString().trim();
            if (s.isEmpty()) return;
            hideKeyboard();
            runAnalysis(CoinReport.normalize(s));
        });
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(-2, -2);
        glp.leftMargin = dp(8);
        sr.addView(go, glp);
        starBtn = chip("☆", false);
        starBtn.setOnClickListener(v -> {
            boolean on = Prefs.toggleWatch(this, currentSym);
            updateStar();
            renderWatchRow();
            toast(on ? "Watchlist mein add — bot isay hamesha scan karega" : "Watchlist se hata diya");
        });
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-2, -2);
        slp.leftMargin = dp(8);
        sr.addView(starBtn, slp);
        sc.addView(sr);
        sc.addView(text("⭐ Watchlist (tap = analysis):", 12, MUTED));
        watchRow = row();
        sc.addView(hscroll(watchRow));

        // ---- live chart card
        LinearLayout cc = card(col, ACC);
        LinearLayout th = row();
        chartTitle = bold(base(currentSym) + "/USDT", 16, TEXT);
        th.addView(chartTitle, new LinearLayout.LayoutParams(0, -2, 1));
        livePrice = bold("", 16, TEXT);
        th.addView(livePrice);
        cc.addView(th);
        LinearLayout tr = row();
        tr.setPadding(0, dp(6), 0, dp(4));
        for (int i = 0; i < chartTfs.length; i++) {
            final String tf = chartTfs[i];
            tfChips[i] = chip(tf, tf.equals(chartTf));
            tfChips[i].setOnClickListener(v -> selectTf(tf));
            tr.addView(tfChips[i], chipLp());
        }
        TextView fs = chip("⛶ Full screen", true);
        fs.setOnClickListener(v -> openFullscreen());
        TextView lv = chip("⏩ Live", false);
        lv.setOnClickListener(v -> chart.goLive());
        TextView zo = chip("−", false);
        zo.setOnClickListener(v -> chart.zoom(30));
        TextView zi = chip("+", false);
        zi.setOnClickListener(v -> chart.zoom(-30));
        TextView cl = chip("🧹 Simple / 🧠 Analysis", false);
        cl.setOnClickListener(v -> {
            if (chart.ind("Patterns") || chart.ind("MA Ribbon")) { cleanChart(chart); toast("Simple chart — sirf candles"); }
            else if (lastReport != null && lastReport.symbol.equals(currentSym)) { applyPlan(lastReport); toast("Analysis lines + plan"); }
            else { analysisLayers(chart); toast("Pattern lines · poora plan ke liye Analyze dabayen"); }
        });
        tr.addView(fs, chipLp());
        tr.addView(cl, chipLp());
        tr.addView(lv, chipLp());
        tr.addView(zo, chipLp());
        tr.addView(zi, chipLp());
        cc.addView(hscroll(tr));
        chart = new ChartView(this);
        chart.setAccent(ACC);
        chart.setCompact(true);
        chart.setOnTap(this::openFullscreen);
        cleanChart(chart);
        // adaptive height: ~55% of the screen (TradingView-like on any phone)
        int ch = Math.max(dp(380), Math.min(dp(640), (int) (getResources().getDisplayMetrics().heightPixels * 0.55f)));
        cc.addView(chart, new LinearLayout.LayoutParams(-1, ch));
        cc.addView(text("Pehle simple chart · 'Analyze' dabane par bot patterns, S/R, Fibonacci, moving averages aur poora plan (kahan BUY, retest, "
                + "target range) chart par khud draw karta hai · tap = full screen", 11, MUTED));

        // ---- live order flow card
        LinearLayout oc = card(col, ACC2);
        oc.addView(bold("⚡ Live order flow — whales vs retail", 16, TEXT));
        oc.addView(text("Har order usi waqt dikhta hai. 🐋 = whale, 🐬 = bada trader, 🐟 = retail. "
                + "Order book mein sunehri line = bada wall (🐋).", 12, MUTED));
        tape = new TapeView(this);
        oc.addView(tape, new LinearLayout.LayoutParams(-1, dp(250)));
        oc.addView(divider());
        book = new BookView(this);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, dp(240));
        blp.topMargin = dp(8);
        oc.addView(book, blp);

        resultBox = column();
        col.addView(resultBox);
        LinearLayout hint = card(resultBox);
        hint.addView(bold("Kya milega?", 15, TEXT));
        hint.addView(text("Coin likh kar Analyze dabayen. Bot sab mila kar hamesha ek saaf faisla deta hai — BUY ya SELL "
                + "(confidence % ke saath):\n"
                + "• Technical: " + String.join(", ", Mode.tfs(uiMode)) + "\n"
                + "• Chart patterns: triangle, wedge, channel, double top/bottom, breakout, Fibonacci, RSI divergence\n"
                + "• Paisa aa raha ya nikal raha: 10 exchanges ka volume + ETF inflow/outflow + on-chain\n"
                + "• Whales vs retail, order book walls\n"
                + "• Futures ke top traders, open interest, funding\n"
                + "• News, CoinGecko community, Fear & Greed\n"
                + "• 🤖 Claude AI se Roman Urdu mein trade plan aur sawal-jawab", 13, SOFT));
        updateStar();
        renderWatchRow();
    }

    private void selectTf(String tf) {
        chartTf = tf;
        for (int k = 0; k < chartTfs.length; k++) styleChip(tfChips[k], chartTfs[k].equals(chartTf));
        loadChart();
    }

    private void applyLayers() {
        applyLayers(chart);
    }

    /** Default indicator set (clean chart): the noisy ones start OFF. */
    static boolean indDefault(String k) {
        return !(k.equals("EMA") || k.equals("EMA200") || k.equals("VWAP") || k.equals("BB") || k.equals("MACD") || k.equals("VolProfile") || k.equals("Retail"));
    }

    private void applyLayers(ChartView cv) {
        for (String k : IND) cv.setInd(k, Prefs.layer(this, k, indDefault(k)));
        if (!Prefs.layer(this, "RSI", true) && Prefs.layer(this, "MACD", false)) cv.setInd("MACD", true);
        cv.setType(Prefs.chartType(this));
    }

    private void openFullscreen() {
        openChartFullscreen(chart, base(currentSym) + "/USDT", true);
    }

    /** TradingView-style full screen chart with indicators, chart types and drawing tools. */
    private void openChartFullscreen(final ChartView cv, final String title, final boolean tfSwitch) {
        if (fsOverlay != null) return;
        fsChart = cv;
        fsTfSwitch = tfSwitch;
        fsTitle = title;
        chartParent = (ViewGroup) cv.getParent();
        chartIndex = chartParent.indexOfChild(cv);
        chartLp = cv.getLayoutParams();
        chartParent.removeView(cv);
        cv.setCompact(false);
        cv.setOnTap(null);

        fsOverlay = column();
        fsOverlay.setBackgroundColor(Mode.bgTop(uiMode));
        fsOverlay.setPadding(dp(6), dp(6), dp(6), dp(4));

        LinearLayout bar = row();
        TextView x = chip("✕", true);
        x.setOnClickListener(v -> closeFullscreen());
        bar.addView(x, chipLp());
        bar.addView(bold(title, 15, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView rot = chip("⟳ Rotate", false);
        rot.setOnClickListener(v -> setRequestedOrientation(
                getResources().getDisplayMetrics().widthPixels > getResources().getDisplayMetrics().heightPixels
                        ? ActivityInfo.SCREEN_ORIENTATION_PORTRAIT : ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE));
        bar.addView(rot, chipLp());
        TextView lv = chip("⏩ Live", false);
        lv.setOnClickListener(v -> cv.goLive());
        bar.addView(lv, chipLp());
        TextView rs = chip("⟲ Reset", false);
        rs.setOnClickListener(v -> cv.resetView());
        bar.addView(rs, chipLp());
        fsOverlay.addView(bar);

        if (tfSwitch) {
            LinearLayout tr = row();
            tr.setPadding(0, dp(4), 0, 0);
            for (final String tf : ChartRange.ALL_TFS) {
                TextView c = chip(tf, tf.equals(chartTf));
                c.setTextSize(12);
                c.setOnClickListener(v -> {
                    selectTf(tf);
                    closeFullscreen();
                    openFullscreen();
                });
                tr.addView(c, chipLp());
            }
            fsOverlay.addView(hscroll(tr));
        }

        // indicators
        LinearLayout ir = row();
        ir.setPadding(0, dp(4), 0, 0);
        final TextView[] ic = new TextView[IND.length];
        for (int i = 0; i < IND.length; i++) {
            final int idx = i;
            ic[i] = chip(IND[i], cv.ind(IND[i]));
            ic[i].setTextSize(11);
            ic[i].setOnClickListener(v -> {
                boolean on = !cv.ind(IND[idx]);
                cv.setInd(IND[idx], on);
                Prefs.setLayer(this, IND[idx], on);
                if (on && IND[idx].equals("RSI")) Prefs.setLayer(this, "MACD", false);
                if (on && IND[idx].equals("MACD")) Prefs.setLayer(this, "RSI", false);
                for (int k = 0; k < IND.length; k++) styleChip(ic[k], cv.ind(IND[k]));
            });
            ir.addView(ic[i], chipLp());
        }
        fsOverlay.addView(hscroll(ir));

        // chart type + drawing tools
        LinearLayout dr = row();
        dr.setPadding(0, dp(4), 0, dp(4));
        final TextView type = chip("📊 " + ChartView.TYPES[cv.getType()], false);
        type.setTextSize(11);
        type.setOnClickListener(v -> {
            type.setText("📊 " + cv.cycleType());
            Prefs.setChartType(this, cv.getType());
        });
        dr.addView(type, chipLp());
        final TextView tl = chip("／ Trendline", false), hl = chip("— H-Line", false);
        tl.setTextSize(11);
        hl.setTextSize(11);
        tl.setOnClickListener(v -> { cv.setDrawMode(cv.getDrawMode() == 2 ? 0 : 2); styleChip(tl, cv.getDrawMode() == 2); styleChip(hl, false); });
        hl.setOnClickListener(v -> { cv.setDrawMode(cv.getDrawMode() == 1 ? 0 : 1); styleChip(hl, cv.getDrawMode() == 1); styleChip(tl, false); });
        dr.addView(tl, chipLp());
        dr.addView(hl, chipLp());
        TextView clr = chip("🗑 Clear", false);
        clr.setTextSize(11);
        clr.setOnClickListener(v -> cv.clearDrawings());
        dr.addView(clr, chipLp());
        TextView zo = chip("−", false), zi = chip("+", false);
        zo.setOnClickListener(v -> cv.zoom(30));
        zi.setOnClickListener(v -> cv.zoom(-30));
        dr.addView(zo, chipLp());
        dr.addView(zi, chipLp());
        fsOverlay.addView(hscroll(dr));

        fsOverlay.addView(cv, new LinearLayout.LayoutParams(-1, 0, 1));
        fsOverlay.addView(text("Khiskayen = time · price patti par upar/neeche = scale · 2 ungli = zoom · daba kar rakhen = crosshair · 2x tap = reset", 10, MUTED));
        rootFrame.addView(fsOverlay, new FrameLayout.LayoutParams(-1, -1));
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);
    }

    private void closeFullscreen() {
        if (fsOverlay == null) return;
        ChartView cv = fsChart;
        fsOverlay.removeView(cv);
        rootFrame.removeView(fsOverlay);
        fsOverlay = null;
        cv.setDrawMode(0);
        cv.setCompact(true);
        if (cv == chart) cv.setOnTap(this::openFullscreen);
        else {
            final ChartView c2 = cv;
            final String t2 = fsTitle;
            cv.setOnTap(() -> openChartFullscreen(c2, t2, false));
        }
        chartParent.addView(cv, chartIndex, chartLp);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }

    private void updateStar() {
        boolean on = Prefs.inWatchlist(this, currentSym);
        starBtn.setText(on ? "★" : "☆");
        styleChip(starBtn, on);
    }

    private void renderWatchRow() {
        watchRow.removeAllViews();
        for (String s : Prefs.watchlist(this)) {
            final String sym = s;
            TextView c = chip(base(s), false);
            c.setOnClickListener(v -> openAnalyze(sym));
            watchRow.addView(c, chipLp());
        }
    }

    private void openAnalyze(String sym) {
        showTab(1);
        searchEt.setText(base(sym));
        pages[1].scrollTo(0, 0);
        runAnalysis(sym);
    }

    /** Loads candles + recent whale trades, runs the pattern engine, then switches the chart to LIVE. */
    private void loadChart() {
        final String sym = currentSym, tf = chartTf;
        final double whaleUsd = Prefs.whaleUsd(this);
        stopCoinFeed();
        chart.setMessage("Chart aur patterns load ho rahe hain...");
        chart.setPlan(false, true, 0, 0, 0, 0);
        tape.clear();
        book.set(new double[0][], new double[0][]);
        livePrice.setText("");
        pool.execute(() -> {
            try {
                final Candles c = Candles.fetch(sym, ChartRange.interval(tf), ChartRange.limit(tf), false);
                final PatternEngine.Result p = PatternEngine.analyze(c.closedOnly(), Math.min(150, c.n));
                final double[] wb = new double[c.n], ws = new double[c.n];
                final double thr = fillWhales(sym, c, wb, ws, whaleUsd, tf.endsWith("m") ? 3 : 1);
                double open24 = 0;
                try {
                    open24 = new JSONObject(Scanner.get("/api/v3/ticker/24hr?symbol=" + sym)).optDouble("openPrice", 0);
                } catch (Exception ignored) {
                }
                final double o24 = open24;
                runOnUiThread(() -> {
                    if (!sym.equals(currentSym) || !tf.equals(chartTf)) return;
                    chartWhaleThr = thr;
                    dayOpen = o24;
                    tape.setWhaleThreshold(thr);
                    chart.setTitle(base(sym) + "/USDT");
                    chart.setData(c, p, wb, ws, ChartRange.interval(tf), false);
                    chart.setVisible(ChartRange.visible(tf, c.n));
                    if (lastReport != null && lastReport.symbol.equals(sym)) applyPlan(lastReport);
                    else cleanChart(chart);
                    if (resumed) startCoinFeed();
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> chart.setMessage("Chart nahi mila: " + m));
            }
        });
    }

    /** Puts big trades (>= threshold) from the latest aggTrades pages onto their candles. Returns the threshold. */
    private static double fillWhales(String sym, Candles c, double[] wb, double[] ws, double whaleUsd, int pages) {
        double qv = 0;
        for (int i = Math.max(0, c.n - 24); i < c.n; i++) qv += c.quoteVol[i];
        double thr = Math.min(whaleUsd, Math.max(5000, qv / Math.max(1, Math.min(24, c.n)) / 40));
        try {
            long fromId = -1;
            for (int pg = 0; pg < pages; pg++) {
                String q = "/api/v3/aggTrades?symbol=" + sym + "&limit=1000" + (fromId >= 0 ? "&fromId=" + fromId : "");
                JSONArray tr = new JSONArray(Scanner.get(q));
                if (tr.length() == 0) break;
                long firstId = Long.MAX_VALUE;
                for (int i = 0; i < tr.length(); i++) {
                    JSONObject o = tr.getJSONObject(i);
                    firstId = Math.min(firstId, o.optLong("a"));
                    double usd = Double.parseDouble(o.getString("p")) * Double.parseDouble(o.getString("q"));
                    if (usd < thr) continue;
                    int idx = c.indexOf(o.optLong("T"));
                    if (idx < 0) continue;
                    if (o.optBoolean("m")) ws[idx] += usd; else wb[idx] += usd;
                }
                fromId = firstId - 1000;
                if (fromId < 0) break;
            }
        } catch (Exception ignored) {
        }
        return thr;
    }

    // ------------------------------------------------------------ live coin stream
    private void startCoinFeed() {
        stopCoinFeed();
        final String sym = currentSym, tf = chartTf;
        liveSym = sym;
        liveTf = tf;
        synchronized (liveLock) {
            pendingKline = null;
            pendingTrades.clear();
            pendingBids = pendingAsks = null;
            candleClosed = false;
        }
        String s = sym.toLowerCase(Locale.US);
        coinWs = new WsStream("/stream?streams=" + s + "@kline_" + ChartRange.interval(tf) + "/" + s + "@aggTrade/" + s + "@depth20",
                new WsStream.Callback() {
                    @Override
                    public void onText(String text) { parseCoin(text); }

                    @Override
                    public void onStatus(boolean live) { coinLive = live; }
                }).start();
    }

    private void stopCoinFeed() {
        if (coinWs != null) coinWs.stop();
        coinWs = null;
        coinLive = false;
    }

    /** Runs on the WebSocket thread: just parse and park the data; the UI applies it every 400 ms. */
    private void parseCoin(String text) {
        try {
            JSONObject o = new JSONObject(text);
            String st = o.optString("stream");
            JSONObject d = o.optJSONObject("data");
            if (d == null) return;
            if (st.contains("@kline")) {
                JSONObject k = d.optJSONObject("k");
                if (k == null) return;
                double[] kl = {k.optLong("t"), num(k, "o"), num(k, "h"), num(k, "l"), num(k, "c"), num(k, "v"),
                        num(k, "q"), num(k, "V"), num(k, "Q"), k.optLong("n"), k.optBoolean("x") ? 1 : 0};
                synchronized (liveLock) {
                    pendingKline = kl;
                    if (kl[10] == 1) candleClosed = true;
                }
            } else if (st.contains("@aggTrade")) {
                double p = num(d, "p"), q = num(d, "q");
                synchronized (liveLock) {
                    if (pendingTrades.size() < 4000) pendingTrades.add(new double[]{d.optLong("T"), p, p * q, d.optBoolean("m") ? 1 : 0});
                }
            } else if (st.contains("@depth")) {
                JSONArray b = d.optJSONArray("bids"), a = d.optJSONArray("asks");
                if (b == null || a == null) return;
                double[][] bb = new double[b.length()][], aa = new double[a.length()][];
                for (int i = 0; i < b.length(); i++) {
                    JSONArray x = b.getJSONArray(i);
                    bb[i] = new double[]{Double.parseDouble(x.getString(0)), Double.parseDouble(x.getString(1))};
                }
                for (int i = 0; i < a.length(); i++) {
                    JSONArray x = a.getJSONArray(i);
                    aa[i] = new double[]{Double.parseDouble(x.getString(0)), Double.parseDouble(x.getString(1))};
                }
                synchronized (liveLock) {
                    pendingBids = bb;
                    pendingAsks = aa;
                }
            }
        } catch (Exception ignored) {
        }
    }

    /** UI thread, every 400 ms: move live candles / trades / order book onto the screen. */
    private void applyLive() {
        double[] kl;
        List<double[]> trs;
        double[][] b, a;
        boolean closed;
        synchronized (liveLock) {
            kl = pendingKline;
            pendingKline = null;
            trs = new ArrayList<>(pendingTrades);
            pendingTrades.clear();
            b = pendingBids;
            a = pendingAsks;
            pendingBids = pendingAsks = null;
            closed = candleClosed;
            candleClosed = false;
        }
        if (coinWs == null || !currentSym.equals(liveSym) || !chartTf.equals(liveTf)) return;
        Candles cur = chart.getData();
        if (kl != null && cur != null) {
            Candles nc = cur.live((long) kl[0], kl[1], kl[2], kl[3], kl[4], kl[5], kl[6], kl[7], kl[8], kl[9]);
            if (nc != null) chart.liveCandles(nc);
            double p = kl[4];
            String ch = dayOpen > 0 ? "  " + Fmt.pct((p / dayOpen - 1) * 100) : "";
            livePrice.setText("$" + Fmt.price(p) + ch);
            livePrice.setTextColor(dayOpen > 0 && p < dayOpen ? RED : GREEN);
        }
        for (double[] t : trs) {
            boolean sell = t[3] == 1;
            if (t[2] >= chartWhaleThr) chart.liveTrade((long) t[0], t[2], sell);
            tape.add(TapeView.trade((long) t[0], t[1], t[2], sell));
        }
        tape.invalidate();
        if (b != null) book.set(b, a);
        chart.setLiveText(coinLive ? "● LIVE" : "○ connect ho raha hai...");
        if (closed && chart.getData() != null) {
            final Candles snap = chart.getData().closedOnly();
            final String sym = currentSym, tf = chartTf;
            pool.execute(() -> {
                final PatternEngine.Result p = PatternEngine.analyze(snap, Math.min(150, snap.n));
                runOnUiThread(() -> {
                    if (sym.equals(currentSym) && tf.equals(chartTf)) chart.setPatterns(p);
                });
            });
        }
    }

    // ------------------------------------------------------------ full analysis
    private void runAnalysis(String sym) {
        boolean newCoin = !sym.equals(currentSym) || chart.getData() == null;
        currentSym = sym;
        lastReport = null;
        Prefs.setLastCoin(this, sym);
        updateStar();
        chartTitle.setText(base(sym) + "/USDT");
        if (newCoin) loadChart();
        else chart.setPlan(false, true, 0, 0, 0, 0);
        resultBox.removeAllViews();
        LinearLayout wait = card(resultBox, ACC);
        wait.addView(bold("⏳ " + base(sym) + " ka " + Mode.label(uiMode) + " analysis ho raha hai...", 15, ACC));
        wait.addView(text("Binance (" + String.join(", ", Mode.tfs(uiMode)) + "), 10 exchanges ka volume, ETF flows, on-chain, "
                + "chart patterns, whales, futures, news aur sentiment se data jama ho raha hai. 15–30 second lag sakte hain.", 13, MUTED));
        final String key = Prefs.glassKey(this);
        final double wu = Prefs.whaleUsd(this);
        final int mode = uiMode;
        pool.execute(() -> {
            try {
                final CoinReport r = CoinReport.build(sym, mode, key, wu, true);
                runOnUiThread(() -> {
                    if (sym.equals(currentSym)) showReport(r);
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> {
                    if (!sym.equals(currentSym)) return;
                    resultBox.removeAllViews();
                    LinearLayout c = card(resultBox, RED);
                    c.addView(bold("❌ Analysis nahi ho saka", 15, RED));
                    c.addView(text(m == null ? "Internet check karein" : m, 13, SOFT));
                    c.addView(text("Coin ka naam sahi likhein (jaise SOL, PEPE, WIF). Market tab mein search karke bhi dhoond sakte hain.", 12, MUTED));
                });
            }
        });
    }

    private String pctFrom(double v, double p) {
        return p > 0 ? String.format(Locale.US, "  (%+.1f%%)", (v / p - 1) * 100) : "";
    }

    private void applyPlan(CoinReport r) {
        analysisLayers(chart);
        boolean showPlan = r.isBuy || r.mode == Mode.SCALP;
        double entry = r.advice != null ? r.advice.entry : r.price;
        chart.setPlan(showPlan && r.atr > 0, r.isBuy, entry, r.stop, r.target1, r.target2);
        if (r.advice != null) chart.setZone(r.advice.zoneLo, r.advice.zoneHi, (r.isBuy ? "BUY ZONE" : "SELL ZONE"), r.isBuy ? GREEN : RED);
        else chart.setZone(0, 0, "", 0);
        setScenario(chart, r.advice, r.price);
    }

    /** Plain chart: only candles + volume (no lines) — used before the user runs an analysis. */
    private void cleanChart(ChartView cv) {
        for (String k : IND) cv.setInd(k, false);
        cv.setInd("Volume", true);
        cv.setType(Prefs.chartType(this));
        cv.setPlan(false, true, 0, 0, 0, 0);
        cv.setZone(0, 0, "", 0);
        cv.setScenario(false, "", true, 0, 0, 0, 0);
    }

    /** After an analysis: draw the patterns, S/R zones, Fibonacci, MA ribbon, crosses and ParaDox signals. */
    private void analysisLayers(ChartView cv) {
        for (String k : IND) cv.setInd(k, false);
        for (String k : new String[]{"Patterns", "Zones", "Fib", "MA Ribbon", "Crosses", "ParaDox", "Volume", "RSI"}) cv.setInd(k, true);
        cv.setType(Prefs.chartType(this));
    }

    /** "Where to buy and how far it can go" drawn into the chart. */
    private void setScenario(ChartView cv, Position.Advice a, double price) {
        if (a == null) { cv.setScenario(false, "", true, 0, 0, 0, 0); return; }
        double level = Position.BREAKOUT.equals(a.type) ? (a.buy ? a.zoneLo : a.zoneHi) : a.entry;
        cv.setScenario(true, a.type, a.buy, price, Position.NOW.equals(a.type) ? 0 : level, a.tp1, a.tp2);
    }

    private void showReport(final CoinReport r) {
        lastReport = r;
        resultBox.removeAllViews();
        chartTitle.setText(r.name + " · " + r.base + "/USDT");
        boolean scalp = r.mode == Mode.SCALP;
        boolean showPlan = r.isBuy || scalp;
        applyPlan(r);
        int vc = r.isBuy ? GREEN : RED;

        LinearLayout h = card(resultBox, vc);
        LinearLayout hr = row();
        hr.addView(bold("🎯 Final signal", 16, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView mb = bold(Mode.label(r.mode), 11, INK);
        mb.setPadding(dp(8), dp(3), dp(8), dp(3));
        mb.setBackground(round(ACC, 10, 0));
        hr.addView(mb);
        h.addView(hr);
        TextView big = bold((r.isBuy ? "▲ " : "▼ ") + r.verdict, 30, vc);
        big.setGravity(Gravity.CENTER);
        big.setLetterSpacing(0.05f);
        h.addView(big);
        TextView conf = bold("Confidence " + r.confidence + "%  ·  Score " + r.total + "/100", 13, TEXT);
        conf.setGravity(Gravity.CENTER);
        h.addView(conf);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, dp(10));
        clp.topMargin = dp(6);
        clp.bottomMargin = dp(6);
        h.addView(bar(r.confidence, vc, 0xFF243049), clp);
        TextView vt = text(r.verdictText, 14, SOFT);
        vt.setGravity(Gravity.CENTER);
        h.addView(vt);
        GaugeView g = new GaugeView(this);
        g.set(r.total, r.isBuy ? "BUY side" : "SELL side", "0 = full sell · 100 = full buy");
        h.addView(g, new LinearLayout.LayoutParams(-1, dp(165)));
        TextView rf = chip("↻ Dobara analysis (taaza data)", false);
        rf.setOnClickListener(v -> runAnalysis(r.symbol));
        h.addView(rf);

        positionCard(r);
        liveFlowCard(r);
        flowCard(r);

        // ---- Claude AI
        aiCard(r);

        LinearLayout f = card(resultBox);
        f.addView(bold("💰 Paisa aa raha ya nikal raha? (" + Mode.flowSpan(r.mode) + ")", 16, TEXT));
        f.addView(bold(r.flowLabel, 17, r.flowSign > 0 ? GREEN : r.flowSign < 0 ? RED : YELLOW));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, dp(14));
        blp.topMargin = dp(8);
        f.addView(bar(r.buyPct, GREEN, RED), blp);
        LinearLayout lr = row();
        lr.addView(text(String.format(Locale.US, "Buyers %.0f%%", r.buyPct), 12, GREEN), new LinearLayout.LayoutParams(0, -2, 1));
        lr.addView(text(String.format(Locale.US, "Sellers %.0f%%", 100 - r.buyPct), 12, RED));
        f.addView(lr);
        f.addView(text("Live 60 second ka hisaab upar 'Live order flow' card mein har waqt update hota hai.", 12, MUTED));

        tradePlan(r, showPlan);

        paradoxCard(resultBox, r.ma, r.bt, r.bt2, r.ruleSide, r.ruleChecks, r.mtfAgree, r.patternTf, Mode.tfs(r.mode).length);
        for (CoinReport.Section s : r.sections) sectionCard(resultBox, s);
        scoreBuildCard(resultBox, r.sections, r.total, r.confidence);

        if (!r.news.isEmpty()) {
            LinearLayout n = card(resultBox);
            n.addView(bold("📰 Taaza khabrein — " + r.name, 16, TEXT));
            for (String[] it : r.news) {
                String tone = "+".equals(it[3]) ? "🟢 " : "-".equals(it[3]) ? "🔴 " : "⚪ ";
                TextView t = text(tone + it[0], 13, TEXT);
                t.setPadding(0, dp(6), 0, 0);
                final String link = it[1];
                t.setOnClickListener(v -> openUrl(link));
                n.addView(t);
                n.addView(text(it[2] + " · tap karke parhen", 11, MUTED));
            }
        }

        LinearLayout al = card(resultBox, ACC2);
        al.addView(bold("🔔 Price alert lagayen", 16, TEXT));
        al.addView(text("Price is level ko cross kare to notification aayegi (koi bhi bot ON hona chahiye).", 12, MUTED));
        LinearLayout ar = row();
        final EditText ap = input("Price", Fmt.price(r.isBuy ? r.target1 : r.stop), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        ar.addView(ap, new LinearLayout.LayoutParams(0, -2, 1));
        TextView ab = chip("Alert lagao", true);
        ab.setOnClickListener(v -> {
            double p = parse(ap, 0);
            if (p <= 0) { toast("Sahi price likhen"); return; }
            Prefs.addAlert(this, r.symbol, p, p > r.price);
            toast("Alert laga diya: " + r.base + (p > r.price ? " upar " : " neeche ") + "$" + Fmt.price(p));
            if (!Prefs.enabled(this)) toast("Yaad rahe: Signals tab se Scalp ya Spot bot ON karein");
        });
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-2, -2);
        alp.leftMargin = dp(8);
        ar.addView(ab, alp);
        al.addView(ar);

        LinearLayout act = card(resultBox);
        Button bin = button("🟡 Binance app mein " + r.base + " kholen (Spot)", 0xFFF0B90B, INK, 0);
        bin.setOnClickListener(v -> BinanceLink.open(this, r.base, false));
        act.addView(bin);
        Button binF = button("🟡 Binance Futures mein kholen", CHIP, 0xFFF0B90B, 0xFFF0B90B);
        binF.setOnClickListener(v -> BinanceLink.open(this, r.base, true));
        act.addView(binF);
        act.addView(text("⚠️ Yeh analysis maloomat ke liye hai, financial advice nahi. Chart patterns aur whale markers "
                + "computer ka andaza hain — 100% sahi nahi hote. Hamesha stop-loss lagayen aur utna hi lagayen jitna "
                + "khona bardasht ho.", 12, MUTED));
    }

    // ------------------------------------------------------------ Claude AI
    private String liveExtras() {
        StringBuilder sb = new StringBuilder("\n[LIVE ORDER FLOW right now]\n");
        double[] p = tape.pressure();
        sb.append("- Last 60s aggressive buy ").append(Fmt.usd(p[0])).append(" vs sell ").append(Fmt.usd(p[1])).append('\n');
        sb.append("- Last 5min whale buy ").append(Fmt.usd(p[4])).append(" vs whale sell ").append(Fmt.usd(p[5]))
                .append(" (whale = trade >= ").append(Fmt.usd(chartWhaleThr)).append(")\n");
        double[] s = book.sums();
        sb.append("- Order book top 10: bids ").append(Fmt.usd(s[0])).append(" vs asks ").append(Fmt.usd(s[1])).append('\n');
        Candles c = chart.getData();
        if (c != null && c.n > 0) sb.append("- Live price ").append(Fmt.price(c.close[c.n - 1])).append(" on ").append(chartTf).append(" chart\n");
        return sb.toString();
    }

    private void aiCard(final CoinReport r) {
        LinearLayout ai = card(resultBox, CLAUDE);
        LinearLayout hr = row();
        hr.addView(bold("🤖 Claude AI Analyst", 16, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView m = bold(Prefs.claudeModel(this).replace("claude-", ""), 10, INK);
        m.setPadding(dp(6), dp(2), dp(6), dp(2));
        m.setBackground(round(CLAUDE, 8, 0));
        hr.addView(m);
        ai.addView(hr);
        ai.addView(text("Claude upar ka saara live data parh kar Roman Urdu mein trade plan likhega. Aap apne sawal bhi pooch sakte hain.", 12, MUTED));
        final LinearLayout chat = column();
        ai.addView(chat);
        final List<String[]> history = new ArrayList<>();
        TextView full = chip("✨ Claude se poora analysis likhwayen", true);
        full.setBackground(round(CLAUDE, 20, CLAUDE));
        full.setOnClickListener(v -> askClaude(r, chat, history,
                "Is coin ka poora analysis karo: direction (BUY/SELL), entry, stop-loss, 2 targets, risk, aur kis cheez se idea ghalat sabit hoga.", true));
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(-1, -2);
        flp.topMargin = dp(8);
        ai.addView(full, flp);
        LinearLayout qr = row();
        final EditText q = input("Sawal likhen (jaise: kya abhi entry lun?)", "", InputType.TYPE_CLASS_TEXT);
        qr.addView(q, new LinearLayout.LayoutParams(0, -2, 1));
        TextView ask = chip("Poochen", false);
        ask.setOnClickListener(v -> {
            String s = q.getText().toString().trim();
            if (s.isEmpty()) return;
            q.setText("");
            hideKeyboard();
            askClaude(r, chat, history, s, history.isEmpty());
        });
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-2, -2);
        alp.leftMargin = dp(8);
        qr.addView(ask, alp);
        ai.addView(qr);
    }

    private TextView bubble(String s, boolean user) {
        TextView t = text(s, 13, user ? TEXT : SOFT);
        t.setPadding(dp(10), dp(8), dp(10), dp(8));
        t.setBackground(round(user ? 0xFF243049 : 0x22D97757, 12, user ? 0 : 0x66D97757));
        t.setTextIsSelectable(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(8);
        t.setLayoutParams(lp);
        return t;
    }

    private void askClaude(final CoinReport r, final LinearLayout chat, final List<String[]> history, String question, boolean withData) {
        final String key = Prefs.claudeKey(this);
        if (key.isEmpty()) {
            chat.addView(bubble("🔑 Pehle ⚙️ Settings mein apni Claude API key daalein.\nKey console.anthropic.com se milti hai "
                    + "(Anthropic ka developer account — is ka kharcha alag se lagta hai, har sawal par thore cents).", false));
            return;
        }
        String content = withData || history.isEmpty()
                ? "LIVE DATA REPORT:\n" + r.toText() + liveExtras() + "\n\nSAWAL: " + question
                : question;
        history.add(new String[]{"user", content});
        chat.addView(bubble("🙋 " + question, true));
        final TextView thinking = bubble("🤖 Claude soch raha hai...", false);
        chat.addView(thinking);
        final String model = Prefs.claudeModel(this);
        final List<String[]> snap = new ArrayList<>(history);
        pool.execute(() -> {
            try {
                final String ans = ClaudeAI.ask(key, model, snap);
                runOnUiThread(() -> {
                    history.add(new String[]{"assistant", ans});
                    thinking.setText("🤖 " + ans);
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> {
                    if (!history.isEmpty()) history.remove(history.size() - 1);
                    thinking.setText("❌ Claude se jawab nahi aaya: " + m);
                    thinking.setTextColor(RED);
                });
            }
        });
    }

    private void tradePlan(final CoinReport r, boolean showPlan) {
        boolean scalp = r.mode == Mode.SCALP;
        LinearLayout p = card(resultBox, ACC);
        p.addView(bold("🧭 Trade plan — " + (r.isBuy ? (scalp ? "LONG scalp" : "Spot BUY") : (scalp ? "SHORT scalp (futures)" : "Spot: bechne / exit ka waqt")), 16, TEXT));
        p.addView(text("Support: $" + Fmt.price(r.support) + "   ·   Resistance: $" + Fmt.price(r.resistance), 13, SOFT));
        if (r.patterns != null && r.patterns.keyLevel > 0)
            p.addView(text("📐 Key level: $" + Fmt.price(r.patterns.keyLevel) + " · pattern target: $" + Fmt.price(r.patterns.target), 13, SOFT));
        if (!showPlan || r.atr <= 0) {
            p.addView(text("Spot mein SELL ka matlab: naya na khareedain. Holding ho to $" + Fmt.price(r.support)
                    + " ke neeche stop rakhen ya profit bacha lein. Wapas BUY tab jab score 50+ ho jaye.", 13, YELLOW));
            return;
        }
        p.addView(text("Entry: ~$" + Fmt.price(r.price), 14, TEXT));
        p.addView(text("Stop-loss: $" + Fmt.price(r.stop) + pctFrom(r.stop, r.price), 14, RED));
        p.addView(text("Target 1: $" + Fmt.price(r.target1) + pctFrom(r.target1, r.price) + "  (1 : 1.5)", 14, GREEN));
        p.addView(text("Target 2: $" + Fmt.price(r.target2) + pctFrom(r.target2, r.price) + "  (1 : 3)", 14, GREEN));
        p.addView(text("TP1 par aadha profit lein aur stop ko entry par le aayen. Yeh lines chart par bhi bani hain.", 12, MUTED));

        p.addView(divider());
        p.addView(bold("🧮 Position size calculator", 15, ACC2));
        LinearLayout rr = row();
        final EditText bal = input("Balance USDT", String.valueOf(Prefs.balance(this)), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        final EditText rp = input("Risk %", String.valueOf(Prefs.riskPct(this)), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        LinearLayout c1 = column();
        c1.addView(text("Balance (USDT)", 11, MUTED));
        c1.addView(bal);
        LinearLayout c2 = column();
        c2.addView(text("Risk per trade %", 11, MUTED));
        c2.addView(rp);
        rr.addView(c1, new LinearLayout.LayoutParams(0, -2, 1));
        rr.addView(new View(this), new LinearLayout.LayoutParams(dp(10), 1));
        rr.addView(c2, new LinearLayout.LayoutParams(0, -2, 1));
        p.addView(rr);
        final TextView out = text("", 13, TEXT);
        Runnable calc = () -> {
            double b = parse(bal, 0), pct = parse(rp, 1);
            Prefs.saveRisk(this, (float) b, (float) pct);
            double riskUsd = b * pct / 100;
            double perUnit = Math.abs(r.price - r.stop);
            if (perUnit <= 0 || b <= 0) { out.setText("Balance likhen"); return; }
            double qty = riskUsd / perUnit;
            double pos = qty * r.price;
            String lev = pos > b ? String.format(Locale.US, "\n⚠️ Position balance se badi hai — %.1fx leverage chahiye. Risk kam karein.", pos / b) : "";
            out.setText(String.format(Locale.US, "Agar stop lage to nuksan: $%.2f (%.1f%%)\nKhareedain: %s %s  ≈  $%.2f\nTP1 par faida ≈ $%.2f · TP2 par ≈ $%.2f%s",
                    riskUsd, pct, qty >= 1 ? String.format(Locale.US, "%.2f", qty) : String.format(Locale.US, "%.6f", qty), r.base, pos,
                    qty * Math.abs(r.target1 - r.price), qty * Math.abs(r.target2 - r.price), lev));
        };
        TextView cb = chip("Calculate", true);
        cb.setOnClickListener(v -> { hideKeyboard(); calc.run(); });
        LinearLayout.LayoutParams cblp = new LinearLayout.LayoutParams(-2, -2);
        cblp.topMargin = dp(6);
        p.addView(cb, cblp);
        p.addView(out);
        calc.run();
    }

    private void sectionCard(LinearLayout parent, CoinReport.Section s) {
        boolean pat = s.icon.equals("📐");
        LinearLayout c = card(parent, pat ? ACC2 : STROKE);
        LinearLayout hr = row();
        hr.addView(bold(s.icon + "  " + s.title, 15, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        int col = !s.available ? MUTED : s.score > 15 ? GREEN : s.score < -15 ? RED : YELLOW;
        hr.addView(bold(s.available ? String.format(Locale.US, "%+d", s.score) : "N/A", 14, col));
        c.addView(hr);
        if (s.available) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(6));
            lp.topMargin = dp(6);
            lp.bottomMargin = dp(4);
            c.addView(bar((s.score + 100) / 2.0, col, 0xFF243049), lp);
        }
        for (String l : s.lines) c.addView(text("• " + l, 13, SOFT));
        if (pat) c.addView(text("👆 Yeh sab upar chart par lines, zones aur 🎯 arrow ki shakal mein bana hai.", 12, ACC2));
        if (s.learn != null && !s.learn.isEmpty()) learnToggle(c, s.learn);
    }

    // ============================================================ in-app update
    private void checkForUpdate(final boolean manual) {
        if (manual && updStatus != null) updStatus.setText("Check ho raha hai...");
        pool.execute(() -> {
            try {
                final UpdateManager.Info in = UpdateManager.check(this);
                runOnUiThread(() -> {
                    if (in != null) {
                        showUpdate(in);
                        if (updStatus != null) updStatus.setText("🆕 Naya version available: " + in.title);
                    } else {
                        updateBanner.setVisibility(View.GONE);
                        if (updStatus != null) updStatus.setText("✅ Aap ke paas latest version hai");
                        if (manual) toast("App up to date hai ✅");
                    }
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> {
                    if (updStatus != null) updStatus.setText("Update check nahi hua: " + m + " (repo naam check karein)");
                });
            }
        });
    }

    private void showUpdate(final UpdateManager.Info in) {
        updateBanner.removeAllViews();
        updateBanner.setVisibility(View.VISIBLE);
        updateBanner.addView(bold("🆕 Naya update available!", 16, GREEN));
        String when = new SimpleDateFormat("dd MMM HH:mm", Locale.US).format(new Date(in.time));
        updateBanner.addView(text(in.title + " · " + when + " · " + Fmt.num(in.size / 1024.0) + " KB", 12, MUTED));
        final TextView prog = text("", 12, SOFT);
        updateBanner.addView(prog);
        Button b = button("⬇ Abhi install karein", GREEN, INK, 0);
        b.setOnClickListener(v -> startInstall(in, prog));
        updateBanner.addView(b);
        if (currentTab == TAB_SETTINGS) toast("🆕 Naya update — Market tab ke upar Install dabayen");
    }

    private void startInstall(final UpdateManager.Info in, final TextView prog) {
        if (installing) return;
        if (!UpdateManager.canInstall(this)) {
            prog.setText("Pehli dafa: agli screen par 'Allow from this source' ON karein, phir wapas aa kar dobara Install dabayen.");
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) {
            }
            return;
        }
        installing = true;
        prog.setText("Download ho raha hai... 0%");
        pool.execute(() -> {
            try {
                UpdateManager.install(this, in, pct -> runOnUiThread(() -> prog.setText("Download ho raha hai... " + pct + "%")));
                runOnUiThread(() -> prog.setText("✅ Download mukammal — ab Android ki screen par 'Update' dabayen"));
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> prog.setText("❌ Update nahi hua: " + m));
            } finally {
                installing = false;
            }
        });
    }

    // ============================================================ position + volume windows (analysis)
    /** Spot: multi-horizon plan with 4 targets + money in/out on ALL exchanges. Scalp: heavy-flow meter for this coin. */
    private void liveFlowCard(final CoinReport r) {
        final boolean spot = r.mode == Mode.SPOT;
        final LinearLayout c = card(resultBox, spot ? Mode.accent(Mode.SPOT) : Mode.accent(Mode.SCALP));
        c.addView(bold(spot ? "💎 Spot plan — 1 din se 2 mahine tak" : "⚡ Scalp — heavy buying / selling meter", 16, TEXT));
        final TextView wait = text("Sab exchanges se data aa raha hai...", 12, MUTED);
        c.addView(wait);
        final String sym = r.symbol;
        final double sellUsd = Prefs.spotSellUsd(this) * 1_000_000.0, minHeavy = Prefs.scalpHeavyUsd(this) * 1000.0;
        pool.execute(() -> {
            try {
                final HeavyFlow.Result hf = HeavyFlow.fetch(sym);
                final MarketFlow.Result mf = MarketFlow.fetch(r.base, hf);
                final SpotPlan.Plan sp = spot ? SpotPlan.build(sym, r.price, mf, sellUsd) : null;
                runOnUiThread(() -> {
                    if (lastReport != r) return;
                    c.removeView(wait);
                    // money flow, all exchanges
                    c.addView(bold("🌐 Paisa IN / OUT — " + mf.venues.size() + " exchanges", 14, ACC2));
                    String[] w = {"15 min", "1 ghanta", "4 ghante", "24 ghante"};
                    for (int k = 0; k < 4; k++) {
                        double n = mf.net[k];
                        c.addView(bold(String.format(Locale.US, "%s:  %s%s  %s", w[k], n >= 0 ? "+" : "−", Fmt.usd(Math.abs(n)), n >= 0 ? "🟢 IN" : "🔴 OUT"), 13, n >= 0 ? GREEN : RED));
                    }
                    StringBuilder vs = new StringBuilder();
                    for (MarketFlow.Venue v : mf.venues)
                        vs.append(v.buyPct >= 52 ? "🟢 " : v.buyPct <= 48 ? "🔴 " : "⚪ ").append(v.name).append(v.exact ? "" : "*")
                                .append(String.format(Locale.US, " %.0f%%", v.buyPct)).append("   ");
                    c.addView(text(vs.toString().trim(), 11, SOFT));
                    c.addView(text("* = taaza trades se andaza · baqi asal (Binance, OKX)", 10, MUTED));
                    c.addView(divider());
                    if (spot && sp != null) {
                        c.addView(bold(sp.ok ? "✅ Achhi spot entry ABHI — " + sp.horizon : "⏳ Abhi spot BUY nahi", 15, sp.ok ? GREEN : YELLOW));
                        c.addView(text(sp.why, 13, SOFT));
                        String[] hz = {"1–2 din", "1–2 hafte", "1–2 mahine"};
                        boolean[] ok = {sp.shortOk, sp.weekOk, sp.monthOk};
                        StringBuilder hb = new StringBuilder();
                        for (int k = 0; k < 3; k++) hb.append(ok[k] ? "✅ " : "❌ ").append(hz[k]).append("   ");
                        c.addView(bold(hb.toString().trim(), 13, TEXT));
                        c.addView(text("Entry zone: $" + Fmt.price(sp.zoneLo) + " – $" + Fmt.price(sp.zoneHi) + (sp.ok ? "" : "  ·  pullback level: $" + Fmt.price(sp.waitLevel)), 13, TEXT));
                        c.addView(text("🛑 Stop-loss: $" + Fmt.price(sp.sl) + pctFrom(sp.sl, r.price), 14, RED));
                        for (int k = 0; k < 4; k++)
                            c.addView(text("🎯 TP" + (k + 1) + " (" + sp.tpLbl[k] + "): $" + Fmt.price(sp.tp[k]) + pctFrom(sp.tp[k], r.price), 14, GREEN));
                        learnToggle(c, "Spot ke 4 targets waqt ke hisaab se hain: jitna lamba waqt, utna bara target (daily ATR × √din, aur raaste ki "
                                + "resistance se thora neeche). Har TP par 25% bech kar stop upar le aayen. Horizon bot khud chunta hai: weekly trend bhi upar ho "
                                + "to 1–2 mahine, daily upar ho to 1–2 hafte, sirf 4h upar ho to 1–2 din.\n\nChecks:\n" + String.join("\n", sp.checks));
                        if (sp.ok) {
                            chart.setPlan(true, true, r.price, sp.sl, sp.tp[0], sp.tp[1]);
                            chart.setMoreTargets(sp.tp[2], sp.tp[3], sp.tpLbl);
                            chart.setZone(sp.zoneLo, sp.zoneHi, "SPOT BUY ZONE", GREEN);
                            chart.setScenario(true, Position.NOW, true, r.price, 0, sp.tp[0], sp.tp[3]);
                        } else if (sp.waitLevel > 0 && sp.waitLevel < r.price) {
                            chart.setScenario(true, Position.RETEST, true, r.price, sp.waitLevel, sp.tp[0], sp.tp[2]);
                        }
                    } else {
                        double heavy = HeavyFlow.scalpThreshold(minHeavy, hf.gross[0]), enough = HeavyFlow.scalpEnough(hf, heavy);
                        double n15 = hf.net15();
                        c.addView(bold(String.format(Locale.US, "Binance 15 min: %s%s", n15 >= 0 ? "+" : "−", Fmt.usd(Math.abs(n15))), 15, n15 >= 0 ? GREEN : RED));
                        c.addView(text("Is coin ko hilane ke liye kaafi: " + Fmt.usd(enough) + " · Heavy (foran signal): " + Fmt.usd(heavy), 13, SOFT));
                        double pct = Math.min(100, Math.abs(n15) / Math.max(1, heavy) * 100);
                        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, dp(10));
                        bl.topMargin = dp(4);
                        c.addView(bar(pct, n15 >= 0 ? GREEN : RED, 0xFF243049), bl);
                        c.addView(bold(Math.abs(n15) >= heavy ? (n15 > 0 ? "⚡ HEAVY BUYING — scalp BUY zone" : "⚡ HEAVY SELLING — scalp SELL zone")
                                : Math.abs(n15) >= enough ? (n15 > 0 ? "🟢 Kaafi buying — price upar ja sakti hai" : "🔴 Kaafi selling — price neeche ja sakti hai")
                                : "⚪ Flow kam — abhi koi tez move ka ishara nahi", 14, Math.abs(n15) >= enough ? (n15 > 0 ? GREEN : RED) : MUTED));
                        c.addView(text(String.format(Locale.US, "Price impact: $1M net ≈ %.2f%% move · 5m ATR %.2f%% · 15 min price %+.2f%%",
                                hf.impactPerM, hf.atr5Pct, hf.move15Pct), 12, MUTED));
                        learnToggle(c, "Bot ne pichle 24 ghante se seekha ke is coin ki price kitne net paise se kitna hilti hai (price impact). "
                                + "Bare coin ko hilane ke liye bara volume chahiye, chhote coin ko kam. 'Kaafi' wala flow + candles saath hon to signal; "
                                + "'Heavy' flow par bot bina intezar foran FAST signal bhejta hai.");
                    }
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> wait.setText("Data nahi mila: " + m));
            }
        });
    }

    private void positionCard(final CoinReport r) {
        Position.Advice a = r.advice;
        if (a == null || r.atr <= 0) return;
        boolean spotSell = !r.isBuy && r.mode == Mode.SPOT;
        int col = a.buy ? GREEN : RED;
        LinearLayout c = card(resultBox, col);
        c.addView(bold("📍 Position — kahan aur kab " + (a.buy ? "BUY" : spotSell ? "SELL / EXIT" : "SELL"), 16, TEXT));
        TextView t = bold(a.title, 17, col);
        c.addView(t);
        c.addView(text(a.why, 13, SOFT));
        String kind = Position.NOW.equals(a.type) ? "Abhi entry — volume saath hai"
                : Position.RETEST.equals(a.type) ? "Retest ka intezar — chase na karein"
                : Position.BREAKOUT.equals(a.type) ? "Breakout/breakdown confirm hone ka intezar"
                : "Behtar qeemat ka intezar (zone mein limit order)";
        TextView k = bold("➡ " + kind, 13, YELLOW);
        k.setPadding(0, dp(6), 0, dp(4));
        c.addView(k);
        c.addView(text((a.buy ? "BUY" : "SELL") + " zone: $" + Fmt.price(a.zoneLo) + " – $" + Fmt.price(a.zoneHi)
                + "   (entry ~$" + Fmt.price(a.entry) + ")", 14, TEXT));
        c.addView(text("🛑 Stop-loss: $" + Fmt.price(a.sl) + pctFrom(a.sl, a.entry), 14, RED));
        c.addView(text("🎯 TP1: $" + Fmt.price(a.tp1) + pctFrom(a.tp1, a.entry) + "  ·  TP2: $" + Fmt.price(a.tp2) + pctFrom(a.tp2, a.entry), 14, GREEN));
        c.addView(bold((a.buy ? "📈 Coin yahan se yahan tak ja sakta hai: $" : "📉 Coin yahan tak gir sakta hai: $") + Fmt.price(Math.min(a.tp1, a.tp2))
                + " – $" + Fmt.price(Math.max(a.tp1, a.tp2)), 14, a.buy ? GREEN : RED));
        String steps = Position.NOW.equals(a.type) ? "1️⃣ Abhi zone mein " + (a.buy ? "BUY" : "SELL") + " → 2️⃣ SL lagayen → 3️⃣ TP1 par aadha profit, stop entry par → 4️⃣ TP2"
                : Position.BREAKOUT.equals(a.type) ? "1️⃣ Abhi intezar → 2️⃣ $" + Fmt.price(a.buy ? a.zoneLo : a.zoneHi) + (a.buy ? " ke UPAR" : " ke NEECHE")
                + " candle close + volume → 3️⃣ " + (a.buy ? "BUY" : "SELL") + " → 4️⃣ TP1 / TP2"
                : "1️⃣ Abhi chase na karein → 2️⃣ Price $" + Fmt.price(a.zoneLo) + " – $" + Fmt.price(a.zoneHi) + " tak aaye (retest) → 3️⃣ wahan "
                + (a.buy ? "BUY" : "SELL") + " (limit order) → 4️⃣ TP1 / TP2";
        c.addView(text(steps, 13, YELLOW));
        c.addView(text("👆 Yeh poora raasta chart par bana hai: peeli line = intezar wali qeemat, teer = mumkina raasta, rangeen dabba = target range.", 12, MUTED));
        TextView bin = chip("🟡 Binance app mein kholen", true);
        bin.setBackground(round(0xFFF0B90B, 20, 0));
        bin.setOnClickListener(v -> BinanceLink.open(this, r.base, r.mode == Mode.SCALP && !r.isBuy));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = dp(8);
        c.addView(bin, lp);
    }

    private void flowCard(CoinReport r) {
        FlowWindows.Result f = r.flows;
        if (f == null || f.venues.isEmpty()) return;
        LinearLayout c = card(resultBox, ACC2);
        c.addView(bold("⏱️ Volume IN vs OUT — 1 · 5 · 15 minute", 16, TEXT));
        c.addView(text(f.venues.size() + " exchanges: " + String.join(", ", f.venues), 11, MUTED));
        String[] lbl = {"1 min", "5 min", "15 min"};
        for (int k = 0; k < 3; k++) {
            double net = f.net(k);
            LinearLayout rr = row();
            rr.setPadding(0, dp(6), 0, 0);
            rr.addView(bold(lbl[k], 13, TEXT), new LinearLayout.LayoutParams(dp(56), -2));
            rr.addView(text("IN " + Fmt.usd(f.in[k]), 12, GREEN), new LinearLayout.LayoutParams(0, -2, 1));
            rr.addView(text("OUT " + Fmt.usd(f.out[k]), 12, RED), new LinearLayout.LayoutParams(0, -2, 1));
            rr.addView(bold((net >= 0 ? "+" : "") + Fmt.usd(net), 13, net >= 0 ? GREEN : RED));
            c.addView(rr);
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, dp(8));
            bl.topMargin = dp(2);
            c.addView(bar(f.buyPct(k), GREEN, RED), bl);
        }
        double b5 = f.buyPct(1);
        c.addView(bold(b5 >= 55 ? "💰 Volume AA raha hai — upar ja sakta hai" : b5 <= 45 ? "🚨 Volume NIKAL raha hai — neeche ja sakta hai"
                : "⚖️ Barabar — abhi faisla nahi", 14, b5 >= 55 ? GREEN : b5 <= 45 ? RED : YELLOW));
        if (!f.partial.isEmpty()) c.addView(text("Note: " + String.join(", ", f.partial) + " ki taaza trades sirf chhote window cover karti hain.", 11, MUTED));
    }

    // ============================================================ PORTFOLIO (watch-only wallets)
    private LinearLayout walAddCard;

    private void buildWallet() {
        LinearLayout col = pageColumn(TAB_WALLET);

        LinearLayout tot = card(col, ACC);
        LinearLayout tr = row();
        tr.addView(text("TOTAL BALANCE", 11, MUTED), new LinearLayout.LayoutParams(0, -2, 1));
        TextView rf = chip("↻ Refresh", false);
        rf.setOnClickListener(v -> loadWallets());
        tr.addView(rf);
        tot.addView(tr);
        walletTotal = bold("$0", 30, TEXT);
        tot.addView(walletTotal);
        walletNet = text("", 12, MUTED);
        tot.addView(walletNet);
        Button addBtn = button("➕ Add new wallet", ACC, INK, 0);
        addBtn.setOnClickListener(v -> {
            boolean show = walAddCard.getVisibility() != View.VISIBLE;
            walAddCard.setVisibility(show ? View.VISIBLE : View.GONE);
        });
        tot.addView(addBtn);

        walAddCard = card(col, ACC2);
        walAddCard.addView(bold("➕ New wallet", 16, TEXT));
        walLabelEt = input("Wallet name (e.g. Trust Wallet BTC)", "", InputType.TYPE_CLASS_TEXT);
        walAddCard.addView(walLabelEt);
        walAddrEt = input("Paste PUBLIC address", "", InputType.TYPE_CLASS_TEXT);
        walAddCard.addView(walAddrEt);
        final TextView det = text("Supported: Bitcoin · Ethereum (+ ERC20) · BNB Chain (BNB, USDT) · TRON (TRX, USDT TRC20) · Solana · Litecoin · Dogecoin", 11, MUTED);
        walAddCard.addView(det);
        walAddrEt.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence q, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence q, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) {
                String t = e.toString().trim();
                String bad = WalletTracker.securityCheck(t);
                if (bad != null) { det.setText(bad); det.setTextColor(RED); return; }
                String ch = t.isEmpty() ? null : WalletTracker.detect(t);
                det.setText(ch == null ? (t.isEmpty() ? "" : "Address not recognised") : "✅ Network: " + WalletTracker.chainName(ch));
                det.setTextColor(ch == null ? MUTED : GREEN);
            }
        });
        Button b = button("Save wallet", ACC, INK, 0);
        b.setOnClickListener(v -> addWallet());
        walAddCard.addView(b);
        walAddCard.addView(text("🔒 Watch-only: sirf PUBLIC address. Seed phrase / private key kabhi na daalein — app inhein khud rok deti hai. "
                + "Trust Wallet: coin → Receive → Copy address.", 11, MUTED));
        walAddCard.setVisibility(Prefs.wallets(this).length() == 0 ? View.VISIBLE : View.GONE);

        TextView mh = bold("MY WALLETS", 11, MUTED);
        mh.setLetterSpacing(0.12f);
        mh.setPadding(dp(4), dp(16), 0, 0);
        col.addView(mh);
        walletList = column();
        col.addView(walletList);

        TextView ih = bold("INSTITUTIONAL WALLETS (PUBLIC)", 11, MUTED);
        ih.setLetterSpacing(0.12f);
        ih.setPadding(dp(4), dp(18), 0, 0);
        col.addView(ih);
        LinearLayout inst = card(col);
        inst.addView(text("Publicly labelled addresses (mempool.space / Arkham / The Block). Tap View for live holdings.", 11, MUTED));
        for (final String[] k : BigPlayers.KNOWN) {
            LinearLayout r = row();
            r.setPadding(0, dp(8), 0, dp(8));
            LinearLayout t = column();
            t.addView(bold(k[0], 14, TEXT));
            String ch = WalletTracker.detect(k[1]);
            t.addView(text((ch == null ? "" : WalletTracker.chainName(ch) + " · ") + WalletTracker.shortAddr(k[1]), 11, MUTED));
            r.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
            TextView vw = chip("👁 View", false);
            vw.setOnClickListener(v -> openWalletDetail(k[0], k[1]));
            r.addView(vw);
            inst.addView(r);
            inst.addView(divider());
        }
    }

    private void addWallet() {
        String a = walAddrEt.getText().toString().trim();
        String bad = WalletTracker.securityCheck(a);
        if (bad != null) {
            walAddrEt.setText("");
            toast("⛔ Secret data! Mita diya gaya. Sirf public address daalein.");
            return;
        }
        String ch = WalletTracker.detect(a);
        if (ch == null) { toast("Valid public address daalein"); return; }
        JSONArray ws = Prefs.wallets(this);
        for (int i = 0; i < ws.length(); i++) {
            JSONObject o = ws.optJSONObject(i);
            if (o != null && a.equalsIgnoreCase(o.optString("addr"))) { toast("Yeh wallet pehle se list mein hai"); return; }
        }
        try {
            JSONObject o = new JSONObject();
            String lbl = walLabelEt.getText().toString().trim();
            o.put("label", lbl.isEmpty() ? WalletTracker.chainName(ch) + " " + WalletTracker.shortAddr(a) : lbl);
            o.put("addr", a);
            o.put("chain", ch);
            ws.put(o);
            Prefs.saveWallets(this, ws);
        } catch (Exception ignored) {
        }
        walAddrEt.setText("");
        walLabelEt.setText("");
        walAddCard.setVisibility(View.GONE);
        hideKeyboard();
        toast("Wallet added ✅");
        loadWallets();
    }

    private void loadWallets() {
        walletsLoadedAt = System.currentTimeMillis();
        renderWalletList(null);
        if (Prefs.wallets(this).length() == 0) return;
        walletNet.setText("Blockchain se balances aa rahe hain...");
        pool.execute(() -> {
            final List<WalletTracker.Result> rs = WalletWatch.check(this);
            runOnUiThread(() -> renderWalletList(rs));
        });
    }

    /** Compact list: name · network · balance with View / Edit / Delete. rs = null shows saved balances. */
    private void renderWalletList(List<WalletTracker.Result> rs) {
        walletList.removeAllViews();
        JSONArray ws = Prefs.wallets(this);
        if (ws.length() == 0) {
            walletTotal.setText("$0");
            walletNet.setText("Abhi koi wallet nahi — '➕ Add new wallet' dabayen");
            LinearLayout c = card(walletList);
            c.addView(text("Koi wallet add nahi hua. Jitne chahein wallets add kar sakte hain — BTC, ETH, USDT (TRC20/BEP20), SOL...", 13, MUTED));
            return;
        }
        double total = 0;
        for (int i = 0; i < ws.length(); i++) {
            final JSONObject w = ws.optJSONObject(i);
            if (w == null) continue;
            final int idx = i;
            WalletTracker.Result r = rs != null && i < rs.size() ? rs.get(i) : null;
            double usd = r != null ? r.totalUsd : w.optDouble("usd", 0);
            total += usd;
            final String addr = w.optString("addr"), label = w.optString("label");
            String ch = WalletTracker.detect(addr);
            LinearLayout c = card(walletList, r != null && r.error != null && r.holdings.isEmpty() ? YELLOW : STROKE);
            LinearLayout hr = row();
            TextView ic = bold(ch == null ? "?" : ch.equals(WalletTracker.EVM) ? "Ξ" : ch.equals(WalletTracker.BTC) ? "₿" : ch.substring(0, 1), 18, INK);
            ic.setGravity(Gravity.CENTER);
            ic.setBackground(round(ACC, 20, 0));
            hr.addView(ic, new LinearLayout.LayoutParams(dp(40), dp(40)));
            LinearLayout ht = column();
            ht.setPadding(dp(12), 0, 0, 0);
            ht.addView(bold(label, 15, TEXT));
            ht.addView(text((ch == null ? "?" : WalletTracker.chainName(ch)) + " · " + WalletTracker.shortAddr(addr), 11, MUTED));
            hr.addView(ht, new LinearLayout.LayoutParams(0, -2, 1));
            hr.addView(bold(Fmt.usd(usd), 16, GREEN));
            c.addView(hr);
            if (r != null && !r.holdings.isEmpty()) {
                StringBuilder sb = new StringBuilder();
                for (int k = 0; k < r.holdings.size() && k < 4; k++) {
                    if (sb.length() > 0) sb.append(" · ");
                    sb.append(r.holdings.get(k).asset);
                }
                if (r.holdings.size() > 4) sb.append(" +").append(r.holdings.size() - 4);
                c.addView(text(sb.toString(), 12, SOFT));
            } else if (r != null && r.error != null) {
                c.addView(text("⚠️ " + r.error + " — thori der baad Refresh", 11, YELLOW));
            }
            final LinearLayout edit = column();
            edit.setVisibility(View.GONE);
            c.addView(edit);
            LinearLayout br = row();
            TextView vw = chip("👁 View", true);
            vw.setOnClickListener(v -> openWalletDetail(label, addr));
            br.addView(vw, chipLp());
            TextView ed = chip("✏ Edit", false);
            ed.setOnClickListener(v -> toggleWalletEdit(edit, idx, w));
            br.addView(ed, chipLp());
            final TextView del = chip("🗑 Delete", false);
            final long[] armed = {0};
            del.setOnClickListener(v -> {
                long now = System.currentTimeMillis();
                if (now - armed[0] < 3000) {
                    JSONArray cur = Prefs.wallets(this), out = new JSONArray();
                    for (int k = 0; k < cur.length(); k++) if (k != idx) out.put(cur.opt(k));
                    Prefs.saveWallets(this, out);
                    toast("Wallet removed");
                    loadWallets();
                } else {
                    armed[0] = now;
                    del.setText("Confirm?");
                }
            });
            br.addView(del, chipLp());
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-2, -2);
            bl.topMargin = dp(8);
            c.addView(hscroll(br), bl);
        }
        walletTotal.setText(Fmt.usd(total));
        walletNet.setText(ws.length() + " wallets · " + (rs == null ? "saved balances" : "updated " + new SimpleDateFormat("HH:mm", Locale.US).format(new Date()))
                + " · alerts jab paisa aaye/jaye");
    }

    private void toggleWalletEdit(final LinearLayout edit, final int idx, final JSONObject w) {
        if (edit.getVisibility() == View.VISIBLE) {
            edit.setVisibility(View.GONE);
            return;
        }
        edit.removeAllViews();
        edit.setVisibility(View.VISIBLE);
        edit.addView(divider());
        final EditText l = input("Wallet name", w.optString("label"), InputType.TYPE_CLASS_TEXT);
        final EditText a = input("Public address", w.optString("addr"), InputType.TYPE_CLASS_TEXT);
        edit.addView(text("Name", 11, MUTED));
        edit.addView(l);
        edit.addView(text("Address", 11, MUTED));
        edit.addView(a);
        LinearLayout r = row();
        TextView save = chip("💾 Save", true);
        save.setOnClickListener(v -> {
            String na = a.getText().toString().trim();
            if (WalletTracker.securityCheck(na) != null) { a.setText(""); toast("⛔ Secret data! Sirf public address."); return; }
            String ch = WalletTracker.detect(na);
            if (ch == null) { toast("Valid public address daalein"); return; }
            try {
                JSONArray cur = Prefs.wallets(this);
                JSONObject o = cur.getJSONObject(idx);
                if (!na.equalsIgnoreCase(o.optString("addr"))) {
                    o.put("addr", na);
                    o.put("chain", ch);
                    o.remove("snap");
                    o.put("usd", 0);
                }
                String nl = l.getText().toString().trim();
                o.put("label", nl.isEmpty() ? WalletTracker.chainName(ch) + " " + WalletTracker.shortAddr(na) : nl);
                Prefs.saveWallets(this, cur);
            } catch (Exception ignored) {
            }
            hideKeyboard();
            toast("Saved ✅");
            loadWallets();
        });
        TextView cancel = chip("Cancel", false);
        cancel.setOnClickListener(v -> edit.setVisibility(View.GONE));
        r.addView(save, chipLp());
        r.addView(cancel, chipLp());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = dp(6);
        edit.addView(r, lp);
    }

    /** Full page with everything inside one wallet. */
    private void openWalletDetail(final String label, final String addr) {
        final LinearLayout c = openPage(label);
        final TextView tot = bold("…", 30, TEXT);
        String ch = WalletTracker.detect(addr);
        LinearLayout h = card(c, ACC);
        h.addView(text("TOTAL VALUE", 11, MUTED));
        h.addView(tot);
        h.addView(text((ch == null ? "" : WalletTracker.chainName(ch)) + "\n" + addr, 11, SOFT));
        LinearLayout br = row();
        TextView cp = chip("📋 Copy address", false);
        cp.setOnClickListener(v -> {
            try {
                android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(android.content.ClipData.newPlainText("address", addr));
                toast("Address copied");
            } catch (Exception ignored) {
            }
        });
        br.addView(cp, chipLp());
        final TextView ex = chip("🔗 Explorer", false);
        br.addView(ex, chipLp());
        TextView rf = chip("↻ Refresh", false);
        rf.setOnClickListener(v -> openWalletDetail(label, addr));
        br.addView(rf, chipLp());
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-2, -2);
        bl.topMargin = dp(8);
        h.addView(hscroll(br), bl);
        final LinearLayout body = column();
        c.addView(body);
        body.addView(text("⏳ Blockchain se data aa raha hai...", 13, MUTED));
        pool.execute(() -> {
            final WalletTracker.Result r = WalletTracker.fetch(addr);
            runOnUiThread(() -> {
                body.removeAllViews();
                tot.setText(Fmt.usd(r.totalUsd));
                if (r.explorer != null) ex.setOnClickListener(v -> openUrl(r.explorer));
                LinearLayout hc = card(body);
                hc.addView(bold("Assets (" + r.holdings.size() + ")", 16, TEXT));
                if (r.holdings.isEmpty()) hc.addView(text(r.error != null ? "⚠️ " + r.error : "Is wallet mein balance 0 hai", 13, r.error != null ? YELLOW : MUTED));
                List<WalletTracker.Holding> hs = new ArrayList<>(r.holdings);
                Collections.sort(hs, (a, b) -> Double.compare(b.usd, a.usd));
                for (WalletTracker.Holding x : hs) {
                    LinearLayout rr = row();
                    rr.setPadding(0, dp(8), 0, dp(4));
                    LinearLayout l = column();
                    l.addView(bold(x.asset, 15, TEXT));
                    l.addView(text(x.network, 11, MUTED));
                    rr.addView(l, new LinearLayout.LayoutParams(0, -2, 1));
                    LinearLayout rt = column();
                    String amt = x.amount >= 1000 ? Fmt.num(x.amount) : String.format(Locale.US, x.amount >= 1 ? "%.4f" : "%.8f", x.amount);
                    rt.addView(bold(Fmt.usd(x.usd), 14, TEXT));
                    rt.addView(text(amt + " " + x.asset, 11, SOFT));
                    rr.addView(rt);
                    hc.addView(rr);
                    double pct = r.totalUsd > 0 ? x.usd / r.totalUsd * 100 : 0;
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(5));
                    lp.bottomMargin = dp(4);
                    hc.addView(bar(pct, ACC, 0xFF243049), lp);
                }
                if (!r.txs.isEmpty()) {
                    LinearLayout tc = card(body);
                    tc.addView(bold("Recent activity", 16, TEXT));
                    for (String t : r.txs) {
                        TextView tv = text(t, 12, t.contains("🟢") ? GREEN : t.contains("🔴") ? RED : SOFT);
                        tv.setPadding(0, dp(4), 0, dp(4));
                        tc.addView(tv);
                    }
                }
                body.addView(text("🔒 Watch-only — yeh app is wallet se kuch bhej ya sign nahi kar sakti.", 11, MUTED));
            });
        });
    }

    // ============================================================ BIG PLAYERS tab
    private void buildBig() {
        LinearLayout col = pageColumn(TAB_BIG);
        LinearLayout h = card(col, ACC);
        LinearLayout hr = row();
        hr.addView(bold("🏛 Institutional Flow Tracker", 17, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView rf = chip("↻ Refresh", false);
        rf.setOnClickListener(v -> loadBig());
        hr.addView(rf);
        h.addView(hr);
        h.addView(text("Spot ETFs (BlackRock, Fidelity, Grayscale) · corporate treasuries (Strategy, Trump Media) · sovereign holdings · "
                + "exchange & custody wallets (Binance, Robinhood, Tether, WLFI). Accumulation ya distribution par alert.", 12, MUTED));
        toggle(h, "🔔 Buy / sell alerts", null, Prefs.notifOn(this, Prefs.N_BIG), (b, on) -> Prefs.setNotif(this, Prefs.N_BIG, on));
        h.addView(text("Minimum transaction size for alerts:", 12, SOFT));
        LinearLayout mr = row();
        String[] ml = {"$10M", "$50M", "$100M", "$500M", "$1B"};
        for (int i = 0; i < 5; i++) {
            final int idx = i;
            bigMinChips[i] = chip(ml[i], Prefs.bigMinUsd(this) == BIG_MINS[i]);
            bigMinChips[i].setOnClickListener(v -> {
                Prefs.setBigMinUsd(this, BIG_MINS[idx]);
                for (int k = 0; k < 5; k++) styleChip(bigMinChips[k], k == idx);
            });
            mr.addView(bigMinChips[i], chipLp());
        }
        h.addView(hscroll(mr));
        bigStatus = text("", 12, SOFT);
        h.addView(bigStatus);

        LinearLayout mv = card(col, ACC2);
        mv.addView(bold("⚡ Recent institutional activity", 16, TEXT));
        bigMovesBox = column();
        mv.addView(bigMovesBox);

        bigBox = column();
        col.addView(bigBox);

        LinearLayout add = card(col);
        add.addView(bold("➕ Track a custom wallet", 15, TEXT));
        add.addView(text("Arkham / Etherscan se kisi whale, fund ya company ka public address le kar yahan daalein.", 12, MUTED));
        final EditText lbl = input("Naam (jaise: Whale #1)", "", InputType.TYPE_CLASS_TEXT);
        final EditText adr = input("Public address", "", InputType.TYPE_CLASS_TEXT);
        add.addView(lbl);
        add.addView(adr);
        Button ab = button("➕ Track karein", ACC, INK, 0);
        ab.setOnClickListener(v -> {
            String a = adr.getText().toString().trim();
            if (WalletTracker.securityCheck(a) != null || WalletTracker.detect(a) == null) { toast("Sahi public address daalein"); return; }
            try {
                JSONArray arr = Prefs.bigWallets(this);
                JSONObject o = new JSONObject();
                o.put("label", lbl.getText().toString().trim().isEmpty() ? WalletTracker.shortAddr(a) : lbl.getText().toString().trim());
                o.put("addr", a);
                arr.put(o);
                Prefs.saveBigWallets(this, arr);
            } catch (Exception ignored) {
            }
            adr.setText("");
            lbl.setText("");
            toast("Track ho raha hai ✅");
            loadBig();
        });
        add.addView(ab);
        TextView ark = chip("🔎 Arkham par bade wallets dhoondein", false);
        ark.setOnClickListener(v -> openUrl("https://intel.arkm.com/"));
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(-2, -2);
        al.topMargin = dp(6);
        add.addView(ark, al);
    }

    private void renderBigMoves() {
        bigMovesBox.removeAllViews();
        JSONArray a = Prefs.bigMoves(this);
        if (a.length() == 0) {
            bigMovesBox.addView(text("Abhi koi harkat record nahi hui. Pehli dafa data save hota hai — agli dafa se jo bhi khareede/beche woh yahan aur notification mein aayega.", 12, MUTED));
            return;
        }
        SimpleDateFormat f = new SimpleDateFormat("dd MMM HH:mm", Locale.US);
        for (int i = 0; i < a.length() && i < 25; i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            boolean buy = o.optBoolean("buy");
            bigMovesBox.addView(text((buy ? "🟢 " : "🔴 ") + o.optString("text"), 13, buy ? GREEN : RED));
            bigMovesBox.addView(text(f.format(new Date(o.optLong("t"))), 10, MUTED));
        }
    }

    private void loadBig() {
        bigLoadedAt = System.currentTimeMillis();
        bigStatus.setText("ETF, companies, governments aur wallets ka data aa raha hai...");
        pool.execute(() -> {
            final BigPlayers.Report r = BigPlayers.fetch(this, true);
            runOnUiThread(() -> renderBig(r));
        });
    }

    private String mUsd(double millions) {
        return BigPlayers.m(millions);
    }

    private void etfCard(String title, String date, double total, double day, List<BigPlayers.Row> rows) {
        if (rows.isEmpty()) return;
        LinearLayout c = card(bigBox, day >= 0 ? GREEN : RED);
        c.addView(bold(title, 16, TEXT));
        c.addView(text("Taaza din: " + date + " · sab ka total: " + mUsd(day)
                + (Double.isNaN(total) ? "" : " · launch se ab tak: " + mUsd(total)), 12, SOFT));
        LinearLayout hd = row();
        hd.addView(text("Fund", 11, MUTED), new LinearLayout.LayoutParams(0, -2, 1));
        hd.addView(text("Taaza din", 11, MUTED), new LinearLayout.LayoutParams(dp(90), -2));
        hd.addView(text("Launch se", 11, MUTED), new LinearLayout.LayoutParams(dp(90), -2));
        c.addView(hd);
        for (BigPlayers.Row r : rows) {
            LinearLayout rr = row();
            rr.setPadding(0, dp(4), 0, dp(4));
            LinearLayout nm = column();
            nm.addView(bold(r.name, 13, r.name.equals("BlackRock") ? 0xFFF0B90B : TEXT));
            nm.addView(text(r.sub, 10, MUTED));
            rr.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
            rr.addView(bold(r.change == 0 ? "—" : mUsd(r.change), 12, r.change > 0 ? GREEN : r.change < 0 ? RED : MUTED), new LinearLayout.LayoutParams(dp(90), -2));
            rr.addView(text(Double.isNaN(r.value) ? "—" : mUsd(r.value), 12, r.value >= 0 ? SOFT : RED), new LinearLayout.LayoutParams(dp(90), -2));
            c.addView(rr);
        }
    }

    private void holdersCard(String title, String sym, double total, List<BigPlayers.Row> rows, int max) {
        if (rows.isEmpty()) return;
        LinearLayout c = card(bigBox);
        c.addView(bold(title, 16, TEXT));
        c.addView(text("Kul: " + Fmt.num(total) + " " + sym + " · (+/−) = pichhli check se farq", 12, SOFT));
        for (int i = 0; i < rows.size() && i < max; i++) {
            BigPlayers.Row r = rows.get(i);
            LinearLayout rr = row();
            rr.setPadding(0, dp(4), 0, dp(4));
            LinearLayout nm = column();
            nm.addView(bold(r.name, 13, r.name.toLowerCase(Locale.US).contains("trump") ? 0xFFF0B90B : TEXT));
            nm.addView(text(r.sub, 10, MUTED));
            rr.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
            LinearLayout v = column();
            v.addView(text(Fmt.num(r.value) + " " + sym, 12, TEXT));
            v.addView(text(Fmt.usd(r.usd) + (r.change != 0 ? (r.change > 0 ? "  🟢 +" : "  🔴 −") + Fmt.num(Math.abs(r.change)) : ""), 10,
                    r.change > 0 ? GREEN : r.change < 0 ? RED : MUTED));
            rr.addView(v);
            c.addView(rr);
        }
    }

    private void renderBig(BigPlayers.Report r) {
        bigBox.removeAllViews();
        bigStatus.setText("Update: " + new SimpleDateFormat("HH:mm", Locale.US).format(new Date())
                + (r.events.isEmpty() ? " · koi nayi bari harkat nahi" : " · " + r.events.size() + " nayi harkat!"));
        renderBigMoves();
        etfCard("🏦 Spot Bitcoin ETFs — net flows", r.etfBtcDate, r.etfBtcTotal, r.etfBtcDay, r.etfBtc);
        etfCard("🏦 Spot Ethereum ETFs — net flows", r.etfEthDate, r.etfEthTotal, r.etfEthDay, r.etfEth);
        etfCard("🏦 Spot Solana ETFs — net flows", r.etfSolDate, r.etfSolTotal, r.etfSolDay, r.etfSol);
        holdersCard("🏢 Corporate treasuries — BTC", "BTC", r.coBtcTotal, r.coBtc, 20);
        holdersCard("🏢 Corporate treasuries — ETH", "ETH", r.coEthTotal, r.coEth, 12);
        holdersCard("🏛️ Sovereign (government) holdings — BTC", "BTC", r.govTotal, r.gov, 12);
        if (!r.wallets.isEmpty()) {
            LinearLayout c = card(bigBox, ACC2);
            c.addView(bold("🐋 Exchange & custody wallets (on-chain)", 16, TEXT));
            for (BigPlayers.Row w : r.wallets) {
                LinearLayout rr = row();
                rr.setPadding(0, dp(4), 0, dp(4));
                LinearLayout nm = column();
                nm.addView(bold(w.name, 13, TEXT));
                nm.addView(text(w.sub, 10, MUTED));
                rr.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
                LinearLayout v = column();
                v.addView(text(Fmt.usd(w.usd), 13, TEXT));
                if (w.change != 0) v.addView(text((w.change > 0 ? "🟢 +" : "🔴 −") + Fmt.usd(Math.abs(w.change)), 10, w.change > 0 ? GREEN : RED));
                rr.addView(v);
                c.addView(rr);
            }
        }
        if (bigBox.getChildCount() == 0) {
            LinearLayout c = card(bigBox, RED);
            c.addView(text("Data nahi mila — internet check karke Refresh dabayen (CoinGecko kabhi busy hota hai).", 13, YELLOW));
        }
    }

    // ============================================================ ECONOMIC CALENDAR (macro)
    private void setNewsSeg(boolean macro) {
        showMacro = macro;
        styleChip(newsSeg[0], macro);
        styleChip(newsSeg[1], !macro);
        macroCol.setVisibility(macro ? View.VISIBLE : View.GONE);
        listCol.setVisibility(macro ? View.GONE : View.VISIBLE);
        if (macro && System.currentTimeMillis() - macroLoadedAt > 5 * 60_000L) loadMacro(false);
        if (!macro && System.currentTimeMillis() - listingsLoadedAt > 10 * 60_000L) loadListings();
    }

    private void updateMacroLine(List<MacroEngine.Event> evs) {
        if (macroLine == null) return;
        long now = System.currentTimeMillis();
        for (MacroEngine.Event e : evs) {
            if (!"High".equals(e.impact) || e.time < now - 30 * 60_000L) continue;
            long dt = e.time - now;
            macroLine.setText((dt <= 0 ? "📢 Abhi release: " : "📅 Agla bada US event: ") + e.title + (dt > 0 ? " · " + MacroEngine.mins(dt) + " baad" : "")
                    + "  (tap = detail)");
            macroLine.setTextColor(dt < 2 * 3600_000L ? RED : YELLOW);
            return;
        }
        macroLine.setText("📅 Is hafte koi bada US event baqi nahi (tap = calendar)");
        macroLine.setTextColor(MUTED);
    }

    private void buildMacro(LinearLayout col) {
        LinearLayout h = card(col, ACC);
        LinearLayout hr = row();
        hr.addView(bold("🏦 US Macro — market kya karegi?", 17, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView rf = chip("↻", false);
        rf.setOnClickListener(v -> loadMacro(true));
        hr.addView(rf);
        h.addView(hr);
        h.addView(text("Fed, mehngai (CPI/PCE), jobs (NFP) jaisi US khabrein crypto ko sab se zyada hilati hain. Yahan har event ka "
                + "waqt (aap ke time zone mein), forecast, pichli figure, asal figure aur crypto par asar milta hai.", 12, MUTED));
        pulseBox = column();
        h.addView(pulseBox);

        LinearLayout nt = card(col, YELLOW);
        nt.addView(bold("🔔 News alerts", 15, TEXT));
        toggle(nt, "Economic news notifications", "Pehle reminder · release ke baad asal figure + BUY/SELL asar · BTC ka reaction",
                Prefs.notifOn(this, Prefs.N_MACRO), (b, on) -> Prefs.setNotif(this, Prefs.N_MACRO, on));
        toggle(nt, "🛑 Bade news ke waqt signals roko (±30 min)", "Is waqt nakli moves aur stop-hunt zyada hote hain",
                Prefs.newsPause(this), (b, on) -> Prefs.setNewsPause(this, on));
        toggle(nt, "🟠 Medium events bhi (claims, ISM, sentiment...)", null, Prefs.macroMedium(this), (b, on) -> Prefs.setMacroMedium(this, on));
        nt.addView(text("Kitna pehle batayen:", 12, SOFT));
        LinearLayout lr = row();
        final int[] leads = {15, 30, 60, 120, 240};
        final TextView[] lc = new TextView[leads.length];
        for (int i = 0; i < leads.length; i++) {
            final int idx = i;
            lc[i] = chip(leads[i] >= 60 ? (leads[i] / 60) + " ghanta" : leads[i] + " min", Prefs.macroLeadMin(this) == leads[i]);
            lc[i].setOnClickListener(v -> {
                Prefs.setMacroLeadMin(this, leads[idx]);
                for (int k = 0; k < leads.length; k++) styleChip(lc[k], k == idx);
            });
            lr.addView(lc[i], chipLp());
        }
        nt.addView(hscroll(lr));

        LinearLayout fr = row();
        fr.setPadding(0, dp(10), 0, 0);
        final TextView hi = chip("🔴 Sirf bade events", macroHighOnly), all = chip("🔴🟠 Sab events", !macroHighOnly);
        hi.setOnClickListener(v -> { macroHighOnly = true; styleChip(hi, true); styleChip(all, false); loadMacro(false); });
        all.setOnClickListener(v -> { macroHighOnly = false; styleChip(hi, false); styleChip(all, true); loadMacro(false); });
        fr.addView(hi, chipLp());
        fr.addView(all, chipLp());
        col.addView(fr);
        macroBox = column();
        col.addView(macroBox);

        // knowledge table (what each release means)
        LinearLayout kn = section(col, "📘 Kaun sa data kya batata hai?", "Tap karke parhen", ACC2, false);
        String[][] k = {
                {"Fed Chair ki speech", "Agay rate cut hoga ya hike?", "Hawkish = pressure 🔴 · dovish = support 🟢"},
                {"FOMC rate decision", "Fed rates ka asal faisla", "Cut = 🟢 · hike = 🔴 · hold = speech par depend"},
                {"CPI inflation", "Mehngai kitni hai?", "Inflation kam = positive 🟢 · zyada = 🔴"},
                {"PCE / Core PCE", "Fed ka pasandeeda inflation measure", "Kam inflation = rate cuts ki umeed 🟢"},
                {"NFP / Jobs Report", "US mein kitni jobs add hui?", "Bohat strong jobs = inflation/rates ka risk 🔴"},
                {"Unemployment Rate", "Jobs market mazboot ya kamzor?", "Context ke mutabiq mixed reaction"},
                {"GDP", "US economy kitni grow kar rahi?", "Growth aur inflation dono dekhne hote hain"},
                {"FOMC Minutes", "Fed members ki andarooni discussion", "Future policy ka signal mil sakta hai"},
                {"Retail Sales", "Consumers kitna kharch kar rahe?", "Strong spending = rates high rehne ka risk 🔴"},
                {"PPI", "Factory / producer mehngai", "Zyada = aage CPI barhne ka dar 🔴"},
                {"Jobless Claims", "Har hafte berozgari claims", "Zyada claims = cut ki umeed 🟢"},
                {"JOLTS", "Khaali jobs kitni hain", "Zyada = jobs garam = rates risk 🔴"},
                {"ISM PMI", "Factories / services ki sehat (50 line)", "Mixed — growth vs mehngai"},
                {"Consumer sentiment", "Log kitne pur-umeed hain", "Zyada = risk-on 🟢"},
                {"US 10Y yield / Dollar (DXY)", "Paisa kitna mehnga / dollar kitna mazboot", "Neeche = crypto 🟢 · upar = 🔴"}};
        for (String[] r : k) {
            kn.addView(bold(r[0], 14, TEXT));
            kn.addView(text(r[1] + "\n➡ " + r[2], 12, SOFT));
            kn.addView(divider());
        }
    }

    private void loadMacro(final boolean force) {
        macroLoadedAt = System.currentTimeMillis();
        macroBox.removeAllViews();
        macroBox.addView(text("⏳ Calendar aur Fed data load ho raha hai...", 12, MUTED));
        pool.execute(() -> {
            final List<MacroEngine.Event> evs = MacroEngine.calendar(this, force);
            final MacroEngine.Pulse p = MacroEngine.pulse(force);
            // live BTC reaction for released high events (shown in the list)
            long now = System.currentTimeMillis();
            for (MacroEngine.Event e : evs) {
                if (Double.isNaN(e.reaction) && e.time < now - 5 * 60_000L && e.time > now - 3 * 86_400_000L && "High".equals(e.impact))
                    e.reaction = MacroEngine.btcReaction(e.time);
            }
            runOnUiThread(() -> renderMacro(evs, p));
        });
    }

    private void renderMacro(List<MacroEngine.Event> evs, MacroEngine.Pulse p) {
        updateMacroLine(evs);
        pulseBox.removeAllViews();
        pulseBox.addView(bold(p.mood, 16, p.score >= 20 ? GREEN : p.score <= -20 ? RED : YELLOW));
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, dp(8));
        bl.topMargin = dp(4);
        bl.bottomMargin = dp(4);
        pulseBox.addView(bar((p.score + 100) / 2.0, GREEN, RED), bl);
        for (String l : p.lines) pulseBox.addView(text("• " + l, 12, SOFT));
        if (!p.speeches.isEmpty()) {
            pulseBox.addView(text("🎤 Fed ki taaza taqreerein (official):", 12, MUTED));
            for (int i = 0; i < p.speeches.size() && i < 3; i++) {
                final String[] sp = p.speeches.get(i);
                TextView t = text("   " + sp[0], 12, CYAN_TXT);
                t.setOnClickListener(v -> openUrl(sp[1]));
                pulseBox.addView(t);
            }
        }

        macroBox.removeAllViews();
        if (evs.isEmpty()) {
            macroBox.addView(text("Calendar nahi mila — internet check karke ↻ dabayen.", 13, YELLOW));
            return;
        }
        long now = System.currentTimeMillis();
        SimpleDateFormat day = new SimpleDateFormat("EEEE, dd MMM", Locale.US), hm = new SimpleDateFormat("hh:mm a", Locale.US);
        String lastDay = "";
        int shown = 0;
        for (final MacroEngine.Event e : evs) {
            if (macroHighOnly && !"High".equals(e.impact)) continue;
            if (e.time < now - 4 * 86_400_000L) continue;
            String d = day.format(new Date(e.time));
            if (!d.equals(lastDay)) {
                lastDay = d;
                TextView dh = bold("📆 " + d, 14, ACC2);
                dh.setPadding(dp(4), dp(12), 0, 0);
                macroBox.addView(dh);
            }
            boolean high = "High".equals(e.impact);
            long dt = e.time - now;
            int border = !e.verdict.isEmpty() ? (e.verdictSign > 0 ? GREEN : e.verdictSign < 0 ? RED : YELLOW) : high ? RED : 0xFFFF8A3D;
            LinearLayout c = card(macroBox, border);
            LinearLayout hr = row();
            TextView tm = bold(hm.format(new Date(e.time)), 13, TEXT);
            hr.addView(tm, new LinearLayout.LayoutParams(dp(78), -2));
            LinearLayout tt = column();
            tt.addView(bold((high ? "🔴 " : "🟠 ") + e.title, 14, TEXT));
            tt.addView(text(e.info.urdu, 11, MUTED));
            hr.addView(tt, new LinearLayout.LayoutParams(0, -2, 1));
            String st = dt > 0 ? "⏰ " + MacroEngine.mins(dt) : !e.actual.isEmpty() ? "✅ aa gaya" : dt > -3600_000L ? "📢 abhi" : "✔ ho gaya";
            hr.addView(bold(st, 11, dt > 0 && dt < 2 * 3600_000L ? RED : dt > 0 ? YELLOW : GREEN));
            c.addView(hr);
            if (!e.forecast.isEmpty() || !e.previous.isEmpty() || !e.actual.isEmpty()) {
                LinearLayout nr = row();
                nr.setPadding(0, dp(6), 0, 0);
                nr.addView(text("Forecast\n" + (e.forecast.isEmpty() ? "—" : e.forecast), 12, SOFT), new LinearLayout.LayoutParams(0, -2, 1));
                nr.addView(text("Pichla\n" + (e.previous.isEmpty() ? "—" : e.previous), 12, SOFT), new LinearLayout.LayoutParams(0, -2, 1));
                nr.addView(bold("Asal\n" + (e.actual.isEmpty() ? (dt > 0 ? "—" : "intezar") : e.actual), 13,
                        e.verdictSign > 0 ? GREEN : e.verdictSign < 0 ? RED : TEXT), new LinearLayout.LayoutParams(0, -2, 1));
                c.addView(nr);
            }
            if (!e.verdict.isEmpty()) {
                c.addView(bold(e.verdict, 13, e.verdictSign > 0 ? GREEN : e.verdictSign < 0 ? RED : YELLOW));
            } else if (dt > 0) {
                c.addView(text("🔮 " + e.expectation, 12, YELLOW));
            }
            if (!Double.isNaN(e.reaction)) {
                c.addView(bold(String.format(Locale.US, "📊 Release ke 5 min mein BTC: %+.2f%%", e.reaction), 12, e.reaction >= 0 ? GREEN : RED));
            }
            final LinearLayout more = column();
            more.setVisibility(View.GONE);
            more.addView(text("ℹ️ " + e.info.what, 12, SOFT));
            more.addView(text("⬆ Agar zyada aaya: " + e.info.ifHigher, 12, SOFT));
            more.addView(text("⬇ Agar kam aaya: " + e.info.ifLower, 12, SOFT));
            more.addView(text(e.official ? "Source: Federal Reserve official schedule" : "Source: ForexFactory calendar · asal figure: FRED (St. Louis Fed)", 10, MUTED));
            c.addView(more);
            c.setOnClickListener(v -> more.setVisibility(more.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
            shown++;
        }
        if (shown == 0) macroBox.addView(text("Is filter mein koi event nahi.", 12, MUTED));
        macroBox.addView(text("Waqt aap ke phone ke time zone (Pakistan) mein hain. Card par tap = detail. Asal figure release ke 10–60 min "
                + "baad FRED se aati hai; BTC ka reaction 5 min baad.", 11, MUTED));
    }

    // ============================================================ LISTINGS tab
    private void buildListings() {
        LinearLayout page = pageColumn(TAB_LISTINGS);
        LinearLayout seg = row();
        seg.setPadding(0, dp(8), 0, 0);
        String[] sn = {"📅 Economic calendar (Fed, CPI, NFP)", "🆕 Nayi listings"};
        for (int i = 0; i < 2; i++) {
            final int idx = i;
            newsSeg[i] = chip(sn[i], (i == 0) == showMacro);
            newsSeg[i].setOnClickListener(v -> setNewsSeg(idx == 0));
            seg.addView(newsSeg[i], chipLp());
        }
        page.addView(hscroll(seg));
        macroCol = column();
        listCol = column();
        page.addView(macroCol);
        page.addView(listCol);
        buildMacro(macroCol);
        listCol.setVisibility(View.GONE);
        LinearLayout col = listCol;
        LinearLayout h = card(col, ACC);
        LinearLayout hr = row();
        hr.addView(bold("🆕 Nayi listings", 18, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView rf = chip("↻ Refresh", false);
        rf.setOnClickListener(v -> loadListings());
        hr.addView(rf);
        h.addView(hr);
        h.addView(text("Binance, Bybit, OKX aur KuCoin ke taaza listing announcements. Coin par tap karein: listing ka waqt, "
                + "listing se pehle ka volume, aur abhi kahan (DEX / doosre exchange) khareeda ja sakta hai.", 12, MUTED));
        listingStatus = text("", 12, SOFT);
        h.addView(listingStatus);
        listingBox = column();
        col.addView(listingBox);
        LinearLayout w = card(col);
        w.addView(text("⚠️ Nayi listing par price bahut tez upar neeche hoti hai. Listing se pehle DEX par khareedna khatarnak ho "
                + "sakta hai (nakli token, kam liquidity). Hamesha contract address exchange ke official announcement se milayen.", 12, MUTED));
    }

    private void loadListings() {
        listingStatus.setText("Load ho raha hai...");
        pool.execute(() -> {
            final List<Listings.Item> items = Listings.fetchAll();
            runOnUiThread(() -> renderListings(items));
        });
    }

    private static final int[] EX_COL = {0xFFF0B90B, 0xFFF7A600, 0xFFFFFFFF, 0xFF23AF91};

    private int exColor(String ex) {
        switch (ex) {
            case "Binance": return EX_COL[0];
            case "Bybit": return EX_COL[1];
            case "OKX": return EX_COL[2];
            default: return EX_COL[3];
        }
    }

    private void renderListings(List<Listings.Item> items) {
        listingsLoadedAt = System.currentTimeMillis();
        listingBox.removeAllViews();
        if (items.isEmpty()) {
            listingStatus.setText("Announcements nahi mile — internet check karke Refresh dabayen");
            return;
        }
        listingStatus.setText(items.size() + " announcements · " + new SimpleDateFormat("HH:mm", Locale.US).format(new Date()));
        SimpleDateFormat f = new SimpleDateFormat("dd MMM HH:mm", Locale.US);
        long now = System.currentTimeMillis();
        for (final Listings.Item it : items) {
            LinearLayout c = card(listingBox, exColor(it.exchange));
            LinearLayout hr = row();
            TextView ex = bold(it.exchange, 11, INK);
            ex.setPadding(dp(7), dp(2), dp(7), dp(2));
            ex.setBackground(round(exColor(it.exchange), 8, 0));
            hr.addView(ex);
            TextView coin = bold("  " + (it.coin.isEmpty() ? "" : it.coin), 17, TEXT);
            hr.addView(coin, new LinearLayout.LayoutParams(0, -2, 1));
            if (it.listTime > 0) {
                long left = it.listTime - now;
                String when = left > 0 ? "⏰ " + countdown(left) + " baad" : "✅ list ho chuka";
                hr.addView(bold(when, 12, left > 0 ? YELLOW : GREEN));
            }
            c.addView(hr);
            c.addView(text(it.title, 13, SOFT));
            String meta = "Announce: " + (it.announced > 0 ? f.format(new Date(it.announced)) : "?");
            if (it.listTime > 0) meta += " · Listing: " + f.format(new Date(it.listTime)) + " (aap ka waqt)";
            c.addView(text(meta, 11, MUTED));
            final LinearLayout detail = column();
            c.addView(detail);
            LinearLayout br = row();
            if (!it.coin.isEmpty()) {
                TextView d = chip("🔎 Kahan se khareedain / volume", true);
                d.setOnClickListener(v -> listingDetail(it, detail));
                br.addView(d, chipLp());
            }
            TextView an = chip("📄 Announcement", false);
            an.setOnClickListener(v -> openUrl(it.url));
            br.addView(an, chipLp());
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-2, -2);
            bl.topMargin = dp(6);
            c.addView(hscroll(br), bl);
        }
    }

    private static String countdown(long ms) {
        long m = ms / 60000;
        if (m >= 1440) return (m / 1440) + "d " + (m % 1440) / 60 + "h";
        if (m >= 60) return (m / 60) + "h " + (m % 60) + "m";
        return m + "m";
    }

    private void listingDetail(final Listings.Item it, final LinearLayout box) {
        box.removeAllViews();
        box.addView(text("⏳ " + it.coin + " ke markets dhoond raha hoon (DexScreener + CoinGecko)...", 12, MUTED));
        pool.execute(() -> {
            final List<Listings.Market> ms = Listings.markets(it.coin);
            boolean onBinance = false;
            try {
                Scanner.get("/api/v3/ticker/price?symbol=" + it.coin + "USDT");
                onBinance = true;
            } catch (Exception ignored) {
            }
            final boolean bn = onBinance;
            runOnUiThread(() -> {
                box.removeAllViews();
                double tot = 0, dexTot = 0;
                for (Listings.Market m : ms) {
                    tot += m.vol24;
                    if (m.dex) dexTot += m.vol24;
                }
                box.addView(bold(it.coin + " — abhi kahan trade ho raha hai", 14, TEXT));
                if (ms.isEmpty()) {
                    box.addView(text("Abhi kisi DEX ya exchange par nahi mila — shayad pehli dafa list ho raha hai.", 12, YELLOW));
                } else {
                    box.addView(text("24h total volume (listing se pehle/abhi): " + Fmt.usd(tot) + " · DEX par " + Fmt.usd(dexTot), 12, SOFT));
                }
                for (final Listings.Market m : ms) {
                    LinearLayout r = row();
                    r.setPadding(0, dp(6), 0, dp(6));
                    LinearLayout l = column();
                    l.addView(bold((m.dex ? "🦄 " : "🏦 ") + m.venue, 13, TEXT));
                    l.addView(text(m.pair + (m.liquidity > 0 ? " · liquidity " + Fmt.usd(m.liquidity) : ""), 11, MUTED));
                    r.addView(l, new LinearLayout.LayoutParams(0, -2, 1));
                    LinearLayout rt = column();
                    rt.addView(text(m.priceUsd > 0 ? "$" + Fmt.price(m.priceUsd) : "-", 12, TEXT));
                    rt.addView(text("vol " + Fmt.usd(m.vol24), 11, MUTED));
                    r.addView(rt);
                    if (m.url != null && !m.url.isEmpty()) r.setOnClickListener(v -> openUrl(m.url));
                    box.addView(r);
                    box.addView(divider());
                }
                if (bn) {
                    TextView a = chip("📈 " + it.coin + " ka live chart + analysis", true);
                    a.setOnClickListener(v -> openAnalyze(it.coin + "USDT"));
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
                    lp.topMargin = dp(6);
                    box.addView(a, lp);
                }
                TextView b = chip("🟡 Binance app mein kholen", false);
                b.setOnClickListener(v -> BinanceLink.open(this, it.coin, false));
                LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(-2, -2);
                lp2.topMargin = dp(6);
                box.addView(b, lp2);
                box.addView(text("Row par tap = us DEX / exchange ka page khulega.", 11, MUTED));
            });
        });
    }

    // ============================================================ SIGNAL screen (live chart for one signal)
    private void openSignalView(final JSONObject o) {
        closeSignalView();
        final String sym = o.optString("sym");
        final boolean buy = "BUY".equals(o.optString("side"));
        final int m = o.optInt("mode", Mode.SPOT);
        final String tf = o.optString("tf", m == Mode.SCALP ? "5m" : "4h");
        final double entry = o.optDouble("entry", o.optDouble("price", 0));
        final double sl = o.optDouble("sl", 0), tp1 = o.optDouble("tp", 0), tp2 = o.optDouble("tp2", 0);
        final double zlo = o.optDouble("zlo", 0), zhi = o.optDouble("zhi", 0);
        final int col = buy ? GREEN : RED;
        final Assets.Asset as = Assets.find(o.optString("asset", ""));
        final java.util.function.DoubleFunction<String> fp = v -> as != null ? Assets.fmt(as, v) : "$" + Fmt.price(v);

        sigOverlay = column();
        sigOverlay.setTag(o);
        sigOverlay.setBackgroundColor(Mode.bgTop(uiMode));
        ScrollView sv = new ScrollView(this);
        LinearLayout c = column();
        c.setPadding(dp(12), dp(10), dp(12), dp(24));
        sv.addView(c);
        sigOverlay.addView(sv, new LinearLayout.LayoutParams(-1, -1));

        LinearLayout hr = row();
        hr.addView(bold((buy ? "🟢 BUY  " : "🔴 SELL  ") + (as != null ? as.icon + " " + as.short_ : base(sym) + "/USDT"), 20, col), new LinearLayout.LayoutParams(0, -2, 1));
        TextView mb = bold((as != null ? (Assets.FOREX.equals(as.market) ? "Forex" : "Commodity") : Mode.label(m)) + " · " + tf, 11, INK);
        mb.setPadding(dp(7), dp(3), dp(7), dp(3));
        mb.setBackground(round(as != null ? YELLOW : Mode.accent(m), 10, 0));
        hr.addView(mb);
        TextView x = chip("✕", true);
        x.setOnClickListener(v -> closeSignalView());
        LinearLayout.LayoutParams xl = new LinearLayout.LayoutParams(-2, -2);
        xl.leftMargin = dp(8);
        hr.addView(x, xl);
        c.addView(hr);

        final TextView livePx = bold("Live price load ho rahi hai...", 15, TEXT);
        c.addView(livePx);
        String adv = o.optString("adv", "");
        if (!adv.isEmpty()) {
            TextView at = bold(adv, 16, col);
            at.setPadding(0, dp(6), 0, 0);
            c.addView(at);
            String aw = o.optString("advWhy", "");
            if (!aw.isEmpty()) c.addView(text(aw, 13, SOFT));
            if (o.has("horizon")) c.addView(bold("⏳ Hold ka waqt: " + o.optString("horizon"), 13, YELLOW));
        }
        LinearLayout lv = card(c, col);
        if (zhi > 0) lv.addView(text((buy ? "BUY" : "SELL") + " zone: " + fp.apply(zlo) + " – " + fp.apply(zhi), 14, TEXT));
        lv.addView(text("Entry: " + fp.apply(entry), 14, TEXT));
        if (sl > 0) lv.addView(text("🛑 SL: " + fp.apply(sl) + pctFrom(sl, entry), 14, RED));
        if (tp1 > 0) lv.addView(text("🎯 TP1: " + fp.apply(tp1) + pctFrom(tp1, entry) + (o.optBoolean("acc") ? "  (1R — accuracy mode)" : ""), 14, GREEN));
        JSONArray tpl = o.optJSONArray("tpl");
        String[] tplS = {"", "", "", ""};
        if (tpl != null) for (int q = 0; q < 4 && q < tpl.length(); q++) tplS[q] = tpl.optString(q);
        if (tpl != null && tp1 > 0) {   // relabel TP1 with its time
            lv.removeViewAt(lv.getChildCount() - 1);
            lv.addView(text("🎯 TP1 (" + tplS[0] + "): " + fp.apply(tp1) + pctFrom(tp1, entry), 14, GREEN));
        }
        if (tp2 > 0) lv.addView(text("🎯 TP2" + (tplS[1].isEmpty() ? "" : " (" + tplS[1] + ")") + ": " + fp.apply(tp2) + pctFrom(tp2, entry), 14, GREEN));
        final double tp3 = o.optDouble("tp3", 0), tp4 = o.optDouble("tp4", 0);
        if (tp3 > 0) lv.addView(text("🎯 TP3 (" + tplS[2] + "): " + fp.apply(tp3) + pctFrom(tp3, entry), 14, GREEN));
        if (tp4 > 0) lv.addView(text("🎯 TP4 (" + tplS[3] + "): " + fp.apply(tp4) + pctFrom(tp4, entry), 14, GREEN));
        if (o.has("hit")) lv.addView(bold("🏁 " + o.optInt("hit") + " / 4 targets hit ho chuke", 13, GREEN));
        final String[] tpLabels = tplS;
        if (sl > 0 && tp1 > 0 && entry > 0 && Math.abs(entry - sl) > 0)
            lv.addView(text(String.format(Locale.US, "Risk : Reward = 1 : %.1f", Math.abs(tp1 - entry) / Math.abs(entry - sl)), 13, SOFT));
        String st = o.optString("st", "open");
        lv.addView(bold(st.equals("win") ? "✅ Target hit ho chuka" : st.equals("loss") ? "❌ Stop-loss hit ho chuka"
                : st.equals("expired") ? "⌛ Waqt khatam" : "⏳ Signal abhi khula hai", 13, st.equals("win") ? GREEN : st.equals("loss") ? RED : YELLOW));
        signalLearnCard(c, o, buy);

        final ChartView sc = new ChartView(this);
        sc.setAccent(Mode.accent(m));
        sc.setLayers(false, true, false, false, false, false);
        sc.setCompact(true);
        final String sigTitle = (as != null ? as.short_ : base(sym) + "/USDT") + " · " + tf + " · " + (buy ? "BUY" : "SELL") + " signal";
        sc.setOnTap(() -> openChartFullscreen(sc, sigTitle, false));
        sc.setMessage("Live chart load ho raha hai...");
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, dp(430));
        cl.topMargin = dp(10);
        c.addView(sc, cl);
        c.addView(text("Sirf zaroori cheezein: " + (buy ? "BUY" : "SELL") + " zone, SL, TP1/TP2, trendlines aur pattern · "
                + "chart par tap = full screen", 11, MUTED));

        Button an = button("📈 Poora analysis dekhen", Mode.accent(m), INK, 0);
        an.setOnClickListener(v -> {
            closeSignalView();
            if (as != null) openAssetAnalysis(as);
            else openAnalyze(sym);
        });
        c.addView(an);
        if (as == null) {
            Button bn = button("🟡 Binance app mein kholen", 0xFFF0B90B, INK, 0);
            bn.setOnClickListener(v -> BinanceLink.open(this, base(sym), m == Mode.SCALP && !buy));
            c.addView(bn);
        }
        c.addView(text(o.optString("why"), 12, SOFT));

        rootFrame.addView(sigOverlay, new FrameLayout.LayoutParams(-1, -1));

        if (as != null) {
            pool.execute(() -> {
                try {
                    final Candles cd = YahooData.fetch(as.sym, tf, false);
                    final PatternEngine.Result p = PatternEngine.analyze(cd.closedOnly(), Math.min(150, cd.n));
                    YahooData.Quote q = null;
                    try { q = YahooData.quote(as.sym); } catch (Exception ignored) { }
                    final YahooData.Quote fq = q;
                    runOnUiThread(() -> {
                        if (sigOverlay == null) return;
                        sc.setTitle(as.short_);
                        sc.setData(cd, p, new double[cd.n], new double[cd.n], tf, false);
                        for (String k : new String[]{"Fib", "Zones", "VolProfile", "Whales", "Retail", "RSI", "MACD", "BB", "EMA200", "VWAP", "EMA"}) sc.setInd(k, false);
                        sc.setInd("Patterns", true);
                        sc.setInd("MA Ribbon", true);
                        sc.setInd("ParaDox", true);
                        sc.setInd("Volume", Assets.COMMODITY.equals(as.market));
                        sc.setPlan(entry > 0, buy, entry, sl, tp1, tp2);
                        if (zhi > 0) sc.setZone(zlo, zhi, buy ? "BUY ZONE" : "SELL ZONE", col);
                        double price = fq != null && fq.price > 0 ? fq.price : cd.close[cd.n - 1];
                        String ty = o.optString("type", Position.NOW);
                        sc.setScenario(tp1 > 0, ty, buy, price, Position.NOW.equals(ty) ? 0 : (zlo + zhi) / 2, tp1, tp2 > 0 ? tp2 : tp1);
                        double pnl = entry > 0 ? (buy ? price / entry - 1 : 1 - price / entry) * 100 : 0;
                        livePx.setText(String.format(Locale.US, "Abhi %s  ·  entry se %+.2f%%  (har minute update)", Assets.fmt(as, price), pnl));
                        livePx.setTextColor(pnl >= 0 ? GREEN : RED);
                    });
                } catch (Exception e) {
                    final String msg = e.getMessage();
                    runOnUiThread(() -> sc.setMessage("Chart nahi mila: " + msg));
                }
            });
            return;
        }
        sigLive = new LiveChart(sc, handler);
        pool.execute(() -> {
            try {
                final Candles cd = Candles.fetch(sym, tf, 300, false);
                final PatternEngine.Result p = PatternEngine.analyze(cd.closedOnly(), Math.min(150, cd.n));
                runOnUiThread(() -> {
                    if (sigOverlay == null) return;
                    sc.setTitle(base(sym) + "/USDT");
                    sc.setData(cd, p, new double[cd.n], new double[cd.n], tf, false);
                    for (String k : new String[]{"Fib", "Zones", "VolProfile", "Whales", "Retail", "RSI", "MACD", "BB", "EMA200", "VWAP"}) sc.setInd(k, false);
                    sc.setInd("Patterns", true);
                    sc.setInd("EMA", true);
                    sc.setInd("Volume", true);
                    sc.setPlan(entry > 0, buy, entry, sl, tp1, tp2);
                    if (zhi > 0) sc.setZone(zlo, zhi, buy ? "BUY ZONE" : "SELL ZONE", col);
                    sc.setInd("MA Ribbon", true);
                    sc.setInd("ParaDox", true);
                    sc.setInd("EMA", false);
                    String ty = o.optString("type", Position.NOW);
                    double lvl = Position.NOW.equals(ty) || "HEAVY_SELL".equals(ty) ? 0 : (zlo + zhi) / 2;
                    sc.setScenario(tp1 > 0, ty, buy, cd.close[cd.n - 1], lvl, tp1, tp4 > 0 ? tp4 : tp2 > 0 ? tp2 : tp1);
                    if (tp3 > 0 || tp4 > 0) sc.setMoreTargets(tp3, tp4, tpLabels);
                    sigLive.start(sym, tf, Prefs.whaleUsd(this), price -> {
                        double pnl = entry > 0 ? (buy ? price / entry - 1 : 1 - price / entry) * 100 : 0;
                        livePx.setText(String.format(Locale.US, "Live $%s  ·  entry se %+.2f%%", Fmt.price(price), pnl));
                        livePx.setTextColor(pnl >= 0 ? GREEN : RED);
                    });
                });
            } catch (Exception e) {
                final String msg = e.getMessage();
                runOnUiThread(() -> sc.setMessage("Chart nahi mila: " + msg));
            }
        });
    }

    private void closeSignalView() {
        if (fsOverlay != null) closeFullscreen();
        if (sigLive != null) sigLive.stop();
        sigLive = null;
        if (sigOverlay != null) rootFrame.removeView(sigOverlay);
        sigOverlay = null;
    }

    // ============================================================ SIGNALS tab
    private void buildSignals() {
        LinearLayout col = pageColumn(2);
        LinearLayout seg = row();
        seg.setPadding(dp(4), dp(4), dp(4), dp(4));
        seg.setBackground(round(CARD, 16, STROKE));
        String[] segN = {"🪙 Crypto", "🥇 Gold & Comm.", "💱 Forex"};
        for (int i = 0; i < 3; i++) {
            final int si = i;
            sigSegChips[i] = chip(segN[i], i == 0);
            sigSegChips[i].setTextSize(12);
            sigSegChips[i].setOnClickListener(v -> setSigSeg(si));
            seg.addView(sigSegChips[i], new LinearLayout.LayoutParams(0, -2, 1));
        }
        LinearLayout.LayoutParams segLp = new LinearLayout.LayoutParams(-1, -2);
        segLp.topMargin = dp(10);
        col.addView(seg, segLp);
        cryptoBotBox = column();
        col.addView(cryptoBotBox);
        assetBotBox = column();
        assetBotBox.setVisibility(View.GONE);
        col.addView(assetBotBox);
        LinearLayout ab = card(assetBotBox, YELLOW);
        ab.addView(bold("🤖 24/7 Market Bot", 17, TEXT));
        ab.addView(text("Har 15 minute mein poori list scan hoti hai (15m · 1h · 4h · 1d + moving averages + dollar index + news). "
                + "Market band ho (weekend) to bot intezar karta hai. Yeh signals crypto se bilkul alag rehte hain.", 12, MUTED));
        assetBotBtn = button("", YELLOW, INK, 0);
        assetBotBtn.setOnClickListener(v -> toggleMarketBot(sigSeg == 2 ? Assets.FOREX : Assets.COMMODITY));
        ab.addView(assetBotBtn);
        assetBotStatus = text("", 13, MUTED);
        ab.addView(assetBotStatus);
        LinearLayout st = card(cryptoBotBox, ACC);
        st.addView(bold("🤖 24/7 Signal Bots", 17, TEXT));
        st.addView(text("Scalp aur Spot bot alag alag ON/OFF karein. Dono saath bhi chal sakte hain.", 12, MUTED));
        scalpBtn = button("", Mode.accent(Mode.SCALP), INK, 0);
        scalpBtn.setOnClickListener(v -> toggleMode(Mode.SCALP));
        st.addView(scalpBtn);
        spotBtn = button("", Mode.accent(Mode.SPOT), INK, 0);
        spotBtn.setOnClickListener(v -> toggleMode(Mode.SPOT));
        st.addView(spotBtn);
        statusView = text("", 13, MUTED);
        st.addView(statusView);
        Button bat = button("🔋 Battery restriction hatayen (zaroori)", CARD, ACC, ACC);
        bat.setOnClickListener(v -> askBattery());
        st.addView(bat);

        LinearLayout ac = card(cryptoBotBox, ACC2);
        ac.addView(bold("🔔 Price alerts", 16, TEXT));
        ac.addView(text("Analyze tab se alert lagayen · hatane ke liye alert par tap karein", 12, MUTED));
        alertList = column();
        ac.addView(alertList);

        LinearLayout sc = card(col);
        LinearLayout hr = row();
        hr.addView(bold("📡 Signals", 17, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView clr = chip("Clear", false);
        clr.setOnClickListener(v -> {
            Prefs.clearSignals(this);
            renderSignals(true);
        });
        hr.addView(clr);
        sc.addView(hr);
        statsView = bold("", 13, ACC2);
        sc.addView(statsView);
        sc.addView(text("Har signal ka asal nateeja bot khud check karta hai: ✅ target hit · ❌ stop hit · ⌛ waqt khatam. "
                + "Signal par tap karein — us ka apna LIVE chart khulega: BUY/SELL zone, SL, TP aur trendline.", 12, MUTED));
        signalList = column();
        sc.addView(signalList);
    }

    private void setSigSeg(int i) {
        sigSeg = i;
        for (int k = 0; k < 3; k++) styleChip(sigSegChips[k], k == i);
        cryptoBotBox.setVisibility(i == 0 ? View.VISIBLE : View.GONE);
        assetBotBox.setVisibility(i == 0 ? View.GONE : View.VISIBLE);
        refreshStatus();
        renderSignals(true);
    }

    private static String segMarket(int seg) {
        return seg == 1 ? Assets.COMMODITY : seg == 2 ? Assets.FOREX : Assets.CRYPTO;
    }

    private void toggleMarketBot(String mkt) {
        boolean on = !Prefs.mktOn(this, mkt);
        Prefs.setMktOn(this, mkt, on);
        if (on) Prefs.setLastAssetScan(this, mkt, 0);
        if (Prefs.enabled(this)) startForegroundService(new Intent(this, ScannerService.class));
        else startService(new Intent(this, ScannerService.class).setAction(ScannerService.ACTION_STOP));
        toast((Assets.FOREX.equals(mkt) ? "💱 Forex" : "🥇 Gold & Commodities") + " bot " + (on ? "ON ✅" : "OFF"));
        handler.postDelayed(this::refreshStatus, 300);
    }

    private void toggleMode(int m) {
        boolean on = !Prefs.modeOn(this, m);
        Prefs.setModeOn(this, m, on);
        if (Prefs.enabled(this)) {
            startForegroundService(new Intent(this, ScannerService.class));
        } else {
            startService(new Intent(this, ScannerService.class).setAction(ScannerService.ACTION_STOP));
        }
        toast(Mode.label(m) + " bot " + (on ? "ON ✅" : "OFF"));
        handler.postDelayed(this::refreshStatus, 300);
    }

    private void renderAlerts() {
        alertList.removeAllViews();
        JSONArray a = Prefs.alerts(this);
        if (a.length() == 0) {
            alertList.addView(text("Koi alert nahi", 13, MUTED));
            return;
        }
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            final int idx = i;
            boolean above = o.optBoolean("above");
            TextView t = bold((above ? "⬆ " : "⬇ ") + base(o.optString("sym")) + "  " + (above ? "upar jaye " : "neeche aaye ")
                    + "$" + Fmt.price(o.optDouble("price")) + "   ✕", 14, above ? GREEN : RED);
            t.setPadding(0, dp(6), 0, dp(6));
            t.setOnClickListener(v -> {
                List<Integer> l = new ArrayList<>();
                l.add(idx);
                Prefs.removeAlerts(this, l);
                renderAlerts();
            });
            alertList.addView(t);
        }
    }

    private void renderSignals(boolean force) {
        JSONArray all = Prefs.signals(this);
        String want = segMarket(sigSeg);
        JSONArray arr = new JSONArray();
        for (int i = 0; i < all.length(); i++) {
            JSONObject o = all.optJSONObject(i);
            if (o != null && want.equals(o.optString("mkt", Assets.CRYPTO))) arr.put(o);
        }
        JSONObject first = arr.optJSONObject(0);
        StringBuilder kb = new StringBuilder().append(sigSeg).append('/').append(arr.length()).append(':').append(first == null ? 0 : first.optLong("t"));
        int[] st = Scanner.signalStats(arr);
        kb.append(':').append(st[0]).append(st[1]).append(st[2]);
        String key = kb.toString();
        if (!force && key.equals(signalKey)) return;
        signalKey = key;
        int done = st[0] + st[1];
        statsView.setText(done > 0
                ? String.format(Locale.US, "🏆 Win rate %.0f%%  ·  ✅ %d  ❌ %d  ⌛ %d  ⏳ %d open", st[0] * 100.0 / done, st[0], st[1], st[2], st[3])
                : "🏆 Win rate: abhi koi signal mukammal nahi hua (" + st[3] + " open)");
        signalList.removeAllViews();
        if (arr.length() == 0) {
            signalList.addView(text(sigSeg == 0 ? "Abhi koi crypto signal nahi. Upar se Scalp ya Spot bot ON karein — signal aate hi notification aa jayegi."
                    : "Abhi koi " + (sigSeg == 1 ? "Gold / Commodities" : "Forex") + " signal nahi. Upar se bot ON karein. Accuracy mode mein sirf saaf setups aate hain — kabhi kabhi din mein ek bhi nahi.", 13, MUTED));
            return;
        }
        SimpleDateFormat f = new SimpleDateFormat("dd MMM HH:mm", Locale.US);
        for (int i = 0; i < arr.length() && i < 60; i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            final boolean buy = "BUY".equals(o.optString("side"));
            final String sym = o.optString("sym");
            int m = o.optInt("mode", Mode.SPOT);
            LinearLayout item = column();
            item.setPadding(dp(12), dp(10), dp(12), dp(10));
            item.setBackground(round(buy ? 0x1A0ECB81 : 0x1AF6465D, 12, buy ? 0x550ECB81 : 0x55F6465D));
            LinearLayout hr = row();
            final Assets.Asset as = Assets.find(o.optString("asset", ""));
            hr.addView(bold((buy ? "🟢 BUY  " : "🔴 SELL  ") + (as != null ? as.icon + " " + as.short_ : base(sym) + "/USDT"), 15, buy ? GREEN : RED),
                    new LinearLayout.LayoutParams(0, -2, 1));
            String s = o.optString("st", "");
            String res = s.equals("win") ? String.format(Locale.US, "✅ WIN %+.1f%%", o.optDouble("pnl"))
                    : s.equals("loss") ? String.format(Locale.US, "❌ LOSS %+.1f%%", o.optDouble("pnl"))
                    : s.equals("expired") ? String.format(Locale.US, "⌛ %+.1f%%", o.optDouble("pnl"))
                    : s.equals("open") ? "⏳ open" : "";
            if (!res.isEmpty()) {
                TextView rv = bold(res, 11, s.equals("win") ? GREEN : s.equals("loss") ? RED : YELLOW);
                rv.setPadding(0, 0, dp(6), 0);
                hr.addView(rv);
            }
            TextView mb = bold(as != null ? o.optString("tf", "1h") : Mode.label(m), 10, INK);
            mb.setPadding(dp(6), dp(2), dp(6), dp(2));
            mb.setBackground(round(as != null ? YELLOW : Mode.accent(m), 8, 0));
            hr.addView(mb);
            item.addView(hr);
            String wr = (o.has("wr") ? " · backtest WR " + o.optInt("wr") + "%" : "") + (o.has("hit") ? " · 🎯 " + o.optInt("hit") + "/4 TP" : "")
                    + (o.has("horizon") ? " · ⏳ " + o.optString("horizon") : "");
            item.addView(text((as != null ? Assets.fmt(as, o.optDouble("price")) : "$" + Fmt.price(o.optDouble("price"))) + " · score " + o.optInt("score") + wr + " · "
                    + f.format(new Date(o.optLong("t"))), 12, MUTED));
            String advT = o.optString("adv", "");
            if (!advT.isEmpty()) item.addView(bold(advT, 13, buy ? GREEN : RED));
            String whyT = o.optString("why");
            if (!advT.isEmpty() && whyT.startsWith(advT)) whyT = whyT.substring(advT.length()).trim();
            item.addView(text(whyT, 12, SOFT));
            final JSONObject sig = o;
            item.setOnClickListener(v -> openSignalView(sig));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(8);
            signalList.addView(item, lp);
        }
    }

    private void refreshStatus() {
        boolean sc = Prefs.modeOn(this, Mode.SCALP), sp = Prefs.modeOn(this, Mode.SPOT);
        boolean on = Prefs.enabled(this);
        if (assetBotBtn != null && sigSeg != 0) {
            String mkt = segMarket(sigSeg);
            boolean ao = Prefs.mktOn(this, mkt);
            String nm = sigSeg == 2 ? "💱 FOREX" : "🥇 GOLD & COMMODITIES";
            assetBotBtn.setText(ao ? "⏹  " + nm + " bot ON — band karein" : "▶  " + nm + " bot start karein");
            assetBotBtn.setBackground(round(ao ? YELLOW : CHIP, 14, YELLOW));
            assetBotBtn.setTextColor(ao ? INK : YELLOW);
            assetBotStatus.setText((ao ? Prefs.getStr(this, "astatus_" + mkt, "Pehla scan thori der mein...") : "Bot band hai")
                    + (Prefs.accuracyMode(this) ? "\n🎯 Accuracy mode ON · sirf backtest win rate ≥ " + Prefs.minWinRate(this) + "% wale setups" : ""));
        }
        liveDot.setText(on ? "● LIVE" : "○ OFF");
        liveDot.setTextColor(on ? GREEN : MUTED);
        statusView.setText((sc || sp ? Prefs.status(this) : "Dono crypto bots band hain")
                + (Prefs.accuracyMode(this) ? "\n🎯 Accuracy mode ON · min backtest win rate " + Prefs.minWinRate(this) + "%" : ""));
        scalpBtn.setText(sc ? "⏹  ⚡ SCALP bot ON — band karein" : "▶  ⚡ SCALP bot start karein");
        scalpBtn.setBackground(round(sc ? Mode.accent(Mode.SCALP) : CHIP, 14, Mode.accent(Mode.SCALP)));
        scalpBtn.setTextColor(sc ? INK : Mode.accent(Mode.SCALP));
        spotBtn.setText(sp ? "⏹  💎 SPOT bot ON — band karein" : "▶  💎 SPOT bot start karein");
        spotBtn.setBackground(round(sp ? Mode.accent(Mode.SPOT) : CHIP, 14, Mode.accent(Mode.SPOT)));
        spotBtn.setTextColor(sp ? INK : Mode.accent(Mode.SPOT));
        if (currentTab == 2) renderSignals(false);
    }

    private void askBattery() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm.isIgnoringBatteryOptimizations(getPackageName())) {
                toast("Pehle se unrestricted hai ✅");
                return;
            }
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception ignored) {
            }
        }
    }

    // ============================================================ SETTINGS tab
    private EditText field(LinearLayout parent, String label, String value, int inputType) {
        parent.addView(text(label, 13, MUTED));
        EditText e = input("", value, inputType);
        parent.addView(e);
        return e;
    }

    private EditText numField(LinearLayout parent, String label, int value) {
        return field(parent, label, String.valueOf(value), InputType.TYPE_CLASS_NUMBER);
    }

    private CheckBox check(LinearLayout parent, String label, boolean on) {
        CheckBox cb = new CheckBox(this);
        cb.setText(label);
        cb.setTextColor(TEXT);
        cb.setChecked(on);
        parent.addView(cb);
        return cb;
    }

    // ------------------------------------------------------------ settings building blocks
    /** Collapsible settings section (tap the header to open / close). Returns the body. */
    private void group(LinearLayout col, String title) {
        TextView t = bold(title, 11, MUTED);
        t.setLetterSpacing(0.14f);
        t.setPadding(dp(6), dp(18), 0, 0);
        col.addView(t);
    }

    private LinearLayout section(LinearLayout col, String title, String sub, int color, boolean open) {
        LinearLayout c = card(col, STROKE);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout head = row();
        String icon = title, name = title;
        int sp = title.indexOf(' ');
        if (sp > 0 && sp <= 4) { icon = title.substring(0, sp); name = title.substring(sp + 1); }
        TextView ib = text(icon, 18, TEXT);
        ib.setGravity(Gravity.CENTER);
        ib.setBackground(round((color & 0x00FFFFFF) | 0x33000000, 12, 0));
        head.addView(ib, new LinearLayout.LayoutParams(dp(40), dp(40)));
        LinearLayout tt = column();
        tt.setPadding(dp(12), 0, 0, 0);
        tt.addView(bold(name, 15, TEXT));
        if (sub != null) tt.addView(text(sub, 11, MUTED));
        head.addView(tt, new LinearLayout.LayoutParams(0, -2, 1));
        final TextView arrow = bold(open ? "⌄" : "›", 22, MUTED);
        head.addView(arrow);
        c.addView(head);
        final LinearLayout body = column();
        body.setVisibility(open ? View.VISIBLE : View.GONE);
        c.addView(body);
        head.setOnClickListener(v -> {
            boolean o = body.getVisibility() != View.VISIBLE;
            body.setVisibility(o ? View.VISIBLE : View.GONE);
            arrow.setText(o ? "⌄" : "›");
        });
        return body;
    }

    /** A real-app style ON/OFF row that saves immediately. */
    private Switch toggle(LinearLayout parent, String label, String sub, boolean on, CompoundButton.OnCheckedChangeListener l) {
        LinearLayout r = row();
        r.setPadding(0, dp(8), 0, dp(8));
        LinearLayout t = column();
        t.addView(bold(label, 14, TEXT));
        if (sub != null) t.addView(text(sub, 11, MUTED));
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        Switch sw = new Switch(this);
        sw.setChecked(on);
        sw.setOnCheckedChangeListener(l);
        r.addView(sw);
        parent.addView(r);
        parent.addView(divider());
        return sw;
    }

    private void buildSettings() {
        LinearLayout col = pageColumn(TAB_SETTINGS);
        String ver = "?";
        try {
            ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
        }

        // ---- header / quick controls
        LinearLayout head = card(col, ACC);
        LinearLayout hr = row();
        TextView logo = bold("P", 26, INK);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(round(ACC, 14, 0));
        hr.addView(logo, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout ht = column();
        ht.setPadding(dp(12), 0, 0, 0);
        ht.addView(bold("ParaDox", 17, TEXT));
        ht.addView(text("Version " + ver + " · by Nohman Arshid", 12, MUTED));
        hr.addView(ht, new LinearLayout.LayoutParams(0, -2, 1));
        head.addView(hr);
        toggle(head, "⚡ Scalp bot", "Heavy buying = BUY · heavy selling = SELL · 24/7", Prefs.modeOn(this, Mode.SCALP), (b, on) -> {
            if (on != Prefs.modeOn(this, Mode.SCALP)) toggleMode(Mode.SCALP);
        });
        toggle(head, "💎 Spot bot", "Achhi entry par BUY · $5M+ selling par SELL · 24/7", Prefs.modeOn(this, Mode.SPOT), (b, on) -> {
            if (on != Prefs.modeOn(this, Mode.SPOT)) toggleMode(Mode.SPOT);
        });
        toggle(head, "🥇 Gold & Commodities bot", "Gold, silver, oil, gas, copper — har 15 min", Prefs.mktOn(this, Assets.COMMODITY), (b, on) -> {
            if (on != Prefs.mktOn(this, Assets.COMMODITY)) toggleMarketBot(Assets.COMMODITY);
        });
        toggle(head, "💱 Forex bot", "EURUSD, GBPUSD, USDJPY... — har 15 min", Prefs.mktOn(this, Assets.FOREX), (b, on) -> {
            if (on != Prefs.mktOn(this, Assets.FOREX)) toggleMarketBot(Assets.FOREX);
        });
        LinearLayout mr = row();
        mr.setPadding(0, dp(8), 0, 0);
        mr.addView(text("App ka rang / screens:", 13, SOFT), new LinearLayout.LayoutParams(0, -2, 1));
        for (int m = 0; m < 2; m++) {
            final int mm = m;
            TextView c = chip(Mode.label(m), m == uiMode);
            c.setOnClickListener(v -> switchMode(mm));
            mr.addView(c, chipLp());
        }
        head.addView(mr);

        // ---- per-mode bot settings
        group(col, "TRADING BOTS");
        for (int m = 0; m < 2; m++) {
            LinearLayout b = section(col, (m == Mode.SCALP ? "⚡ Scalp bot" : "💎 Spot bot"), Mode.desc(m), Mode.accent(m), false);
            modeSettings(b, m);
        }

        // ---- notifications
        group(col, "ALERTS");
        LinearLayout n = section(col, "🔔 Notifications", "Signals, price alerts, portfolio, institutions, news, quiet hours", ACC2, false);
        toggle(n, "📡 Buy / Sell signals", "Scalp aur Spot bots ke signals", Prefs.notifOn(this, Prefs.N_SIGNALS), (b, on) -> Prefs.setNotif(this, Prefs.N_SIGNALS, on));
        toggle(n, "🔔 Price alerts", "Aap ke lagaye hue price levels", Prefs.notifOn(this, Prefs.N_ALERTS), (b, on) -> Prefs.setNotif(this, Prefs.N_ALERTS, on));
        toggle(n, "💼 Mere wallets", "Balance badhe ya ghate", Prefs.notifOn(this, Prefs.N_WALLET), (b, on) -> Prefs.setNotif(this, Prefs.N_WALLET, on));
        toggle(n, "🐋 Bade log (ETF / companies / whales)", "Million/billion ki khareed-farokht", Prefs.notifOn(this, Prefs.N_BIG), (b, on) -> Prefs.setNotif(this, Prefs.N_BIG, on));
        toggle(n, "🔄 App updates", "Naya version aaye to batao", Prefs.notifOn(this, Prefs.N_UPDATE), (b, on) -> Prefs.setNotif(this, Prefs.N_UPDATE, on));
        toggle(n, "📆 Catalyst reminders (unlock, listing, delisting...)", "Bare event se 24 ghante aur 1 ghanta pehle", Prefs.notifOn(this, Prefs.N_CATALYST), (b, on) -> Prefs.setNotif(this, Prefs.N_CATALYST, on));
        toggle(n, "📰 Crypto news alerts (hack, listing, ETF, SEC...)", "News radar ON ho to bari khabar par foran notification", Prefs.notifOn(this, Prefs.N_NEWS), (b, on) -> Prefs.setNotif(this, Prefs.N_NEWS, on));
        toggle(n, "📅 Economic news (Fed, CPI, NFP...)", "Pehle reminder + asal figure + BTC reaction", Prefs.notifOn(this, Prefs.N_MACRO), (b, on) -> Prefs.setNotif(this, Prefs.N_MACRO, on));
        minConfEt = numField(n, "Signal tabhi bhejo jab confidence kam az kam (%) ho — 0 = sab", Prefs.minConfidence(this));
        quietCb = check(n, "🌙 Quiet hours — is waqt koi notification nahi", Prefs.quietOn(this));
        LinearLayout qr = row();
        LinearLayout q1 = column(), q2 = column();
        q1.addView(text("Se (ghanta 0–23)", 11, MUTED));
        quietFromEt = input("", String.valueOf(Prefs.quietFrom(this)), InputType.TYPE_CLASS_NUMBER);
        q1.addView(quietFromEt);
        q2.addView(text("Tak (ghanta 0–23)", 11, MUTED));
        quietToEt = input("", String.valueOf(Prefs.quietTo(this)), InputType.TYPE_CLASS_NUMBER);
        q2.addView(quietToEt);
        qr.addView(q1, new LinearLayout.LayoutParams(0, -2, 1));
        qr.addView(new View(this), new LinearLayout.LayoutParams(dp(10), 1));
        qr.addView(q2, new LinearLayout.LayoutParams(0, -2, 1));
        n.addView(qr);
        TextView sys = chip("📱 Android notification settings (awaaz / vibration)", false);
        sys.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()));
            } catch (Exception e) {
                toast("Settings nahi khuli");
            }
        });
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-2, -2);
        sl.topMargin = dp(8);
        n.addView(sys, sl);

        // ---- signal engine
        group(col, "INTELLIGENCE");
        LinearLayout acc = section(col, "🎯 Accuracy mode (ParaDox rule)", "Sirf woh signals jin ka rule pehle kamyab raha", GREEN, true);
        accCb = check(acc, "🎯 Accuracy mode ON — backtest + moving averages + timeframes sab ek taraf hon tabhi signal", Prefs.accuracyMode(this));
        minWrEt = numField(acc, "Kam az kam backtest win rate (%) — 40 se 90 (default 55, zyada = kam magar saaf signals)", Prefs.minWinRate(this));
        acc.addView(text("Kaise kaam karta hai: har coin/asset ke chart par ParaDox rule (EMA trend + EMA9/21 trigger + RSI + MACD + volume) "
                + "pichli ~1000 candles par chala kar dekha jata hai ke kitni dafa TP1 (1R) pehle laga. Is se kam win rate wala setup nahi bheja jata. "
                + "TP1 = 1R rakha jata hai (jaldi profit, zyada hit rate).\n\n"
                + "Sach: zyada win rate (70%+) ka matlab kam signals. 95% kisi bhi bot ki guarantee nahi hoti — stop-loss hamesha lagayen.", 12, MUTED));
        LinearLayout e = section(col, "🎛️ Signal engine", "Filters, confirmation, whale size, news pause", ACC, false);
        btcCb = check(e, "BTC filter: jab BTC bearish ho to BUY signal na do", Prefs.btcFilter(this));
        smartCb = check(e, "🐋 Smart money: whale trades, top traders, open interest", Prefs.smartMoney(this));
        strongCb = check(e, "🎯 Strong signal: SAB sources (10 exchanges, ETF, on-chain, patterns) se confirm karo", Prefs.strongConfirm(this));
        whaleEt = numField(e, "Whale trade kitne USD se bada ho (e.g. 50000)", Prefs.whaleUsd(this));
        spotSellEt = field(e, "💎 Spot SELL sirf tab jab SAB exchanges par 1 ghante mein itne MILLION $ ki net selling ho (default 5)",
                String.valueOf((float) Prefs.spotSellUsd(this)), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        scalpHeavyEt = field(e, "⚡ Scalp HEAVY (foran FAST signal): 15 min mein itne HAZAR $ net (default 250 — chhote coin ke liye khud kam ho jata hai)",
                String.valueOf((int) Prefs.scalpHeavyUsd(this)), InputType.TYPE_CLASS_NUMBER);
        e.addView(text("Spot: BUY sirf achhi entry par — bot 1h/4h/1d/1w dekh kar horizon chunta hai (1–2 din · 1–2 hafte · 1–2 mahine) aur 4 targets deta hai. "
                + "SELL sirf heavy selling par (Binance, OKX, Bybit, Coinbase, KuCoin, Gate, Bitget sab mila kar).\n"
                + "Scalp: HEAVY buying/selling par foran FAST signal; kam volume par bhi signal jab woh volume is coin ki price hilane ke liye kaafi ho "
                + "(bot har coin ka price-impact khud seekhta hai).", 11, MUTED));
        toggle(e, "🛑 Bade US news ke waqt signals roko", "CPI, Fed, NFP se ±30 min pehle/baad naye signal nahi", Prefs.newsPause(this), (b, on) -> Prefs.setNewsPause(this, on));

        // ---- Claude AI
        LinearLayout ai = section(col, "🤖 Claude AI Analyst", "API key, model", CLAUDE, false);
        claudeEt = field(ai, "Claude API key (sk-ant-...)", Prefs.claudeKey(this),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        ai.addView(text("Model", 13, MUTED));
        modelSpinner = new Spinner(this);
        modelSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, ClaudeAI.MODELS));
        for (int i = 0; i < ClaudeAI.MODELS.length; i++) if (ClaudeAI.MODELS[i].equals(Prefs.claudeModel(this))) modelSpinner.setSelection(i);
        ai.addView(modelSpinner);
        ai.addView(text("Sonnet = behtareen balance · Opus = sab se gehri soch (mehenga) · Haiku = sab se tez aur sasta", 11, MUTED));
        TextView link = chip("🔑 Key kahan se milegi? (console.anthropic.com)", false);
        link.setOnClickListener(v -> openUrl("https://console.anthropic.com/settings/keys"));
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(-2, -2);
        llp.topMargin = dp(6);
        ai.addView(link, llp);

        // ---- API keys
        LinearLayout k = section(col, "🔑 API keys", "Optional paid data sources", ACC2, false);
        glassEt = field(k, "Glassnode API key (sirf paid plan par milti hai)", Prefs.glassKey(this),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        cmEt = field(k, "CoinMarketCal API key (FREE — coinmarketcal.com/en/developer/register) · crypto events calendar", Prefs.getStr(this, "cmcal", ""),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        cpEt = field(k, "CryptoPanic token (FREE — cryptopanic.com/developers/api) · 100s news sites + social", Prefs.getStr(this, "cryptopanic", ""),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        // ---- update
        group(col, "APP");
        LinearLayout up = section(col, "🔄 App updates", "Version " + ver + " · in-app install", GREEN, false);
        up.addView(text("Naya version GitHub par banta hai to app khud bata deti hai — phir sirf 'Install' dabana hai.", 12, MUTED));
        repoEt = field(up, "GitHub repo (owner/naam)", Prefs.updateRepo(this), InputType.TYPE_CLASS_TEXT);
        updStatus = text("", 13, SOFT);
        up.addView(updStatus);
        Button chk = button("🔍 Update check karein", GREEN, INK, 0);
        chk.setOnClickListener(v -> {
            Prefs.setUpdateRepo(this, repoEt.getText().toString());
            checkForUpdate(true);
        });
        up.addView(chk);

        // ---- battery & background
        LinearLayout bt = section(col, "🔋 Battery & background", "24/7 operation, autostart", YELLOW, false);
        bt.addView(text("Xiaomi, Oppo, Vivo, Infinix, Tecno, Samsung waghera mein: Battery = 'No restrictions' aur Autostart = ON karein.", 12, SOFT));
        Button bb = button("🔋 Battery restriction hatayen", CARD, YELLOW, YELLOW);
        bb.setOnClickListener(v -> askBattery());
        bt.addView(bb);
        Button ap = button("📱 App info kholen (Autostart / permissions)", CARD, TEXT, STROKE);
        ap.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:" + getPackageName())));
            } catch (Exception ex) {
                toast("Nahi khula");
            }
        });
        bt.addView(ap);

        // ---- data & privacy
        group(col, "PRIVACY & ABOUT");
        LinearLayout dpv = section(col, "🛡️ Data & privacy", "On-device storage, reset options", RED, false);
        dpv.addView(text("• Koi account / login nahi · koi data hamare server par nahi jata\n"
                + "• Wallet tracker sirf PUBLIC address dekhta hai — seed phrase / private key kabhi nahi maangta\n"
                + "• API keys sirf is phone mein save hoti hain", 12, SOFT));
        confirmButton(dpv, "🗑 Saare signals mitayen", () -> { Prefs.clearSignals(this); renderSignals(true); });
        confirmButton(dpv, "🗑 Bade log ki history mitayen", () -> { Prefs.saveBigSnap(this, new JSONObject()); });
        confirmButton(dpv, "🗑 Saare wallets hatayen", () -> { Prefs.saveWallets(this, new JSONArray()); loadWallets(); });
        confirmButton(dpv, "↺ Settings default par wapas", () -> { Prefs.resetSettings(this); recreate(); });

        // ---- about
        LinearLayout ab = section(col, "ℹ️ About", "Data sources, disclaimer", ACC2, false);
        ab.addView(text("• Binance WebSocket: live price, candles, har trade, order book\n"
                + "• 10 exchanges ka buy/sell volume: Binance, OKX, Bybit, Coinbase, Kraken, KuCoin, Gate, Bitget\n"
                + "• ETF flows (BlackRock, Fidelity ...): Farside Investors\n"
                + "• Companies / governments holdings: CoinGecko\n"
                + "• Wallets: mempool.space, Ethplorer, BNB Chain RPC, TronGrid, Solana RPC, Blockchair\n"
                + "• On-chain: DefiLlama, Blockchain.com, Coin Metrics, Coinbase premium\n"
                + "• Listings: Binance, Bybit, OKX, KuCoin announcements · DexScreener\n"
                + "• Futures: Binance open interest, top traders, funding · Fear & Greed · News", 12, SOFT));
        ab.addView(text("⚠️ Signals sirf maloomat ke liye hain, financial advice nahi. Bot khud koi trade nahi karta.", 12, MUTED));

        Button save = button("💾 Save all settings", ACC, INK, 0);
        save.setOnClickListener(v -> saveSettings());
        LinearLayout.LayoutParams svl = new LinearLayout.LayoutParams(-1, dp(54));
        svl.topMargin = dp(14);
        col.addView(save, svl);
    }

    /** Button that needs two taps (safety for destructive actions). */
    private void confirmButton(LinearLayout parent, String label, final Runnable action) {
        final Button b = button(label, CARD, RED, RED);
        final long[] armed = {0};
        b.setOnClickListener(v -> {
            long now = System.currentTimeMillis();
            if (now - armed[0] < 3000) {
                action.run();
                b.setText("✅ Ho gaya");
                armed[0] = 0;
            } else {
                armed[0] = now;
                b.setText("Pakka? Dobara dabayen");
                handler.postDelayed(() -> b.setText(label), 3000);
            }
        });
        parent.addView(b);
    }

    private void modeSettings(LinearLayout c, int m) {
        EditText[] f = new EditText[7];
        f[0] = numField(c, "Har kitne minute baad scan", Prefs.intervalMin(this, m));
        c.addView(text("Scan candle timeframe", 13, MUTED));
        String[] tfs = Mode.scanTfs(m);
        Spinner sp = new Spinner(this);
        sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, tfs));
        for (int i = 0; i < tfs.length; i++) if (tfs[i].equals(Prefs.timeframe(this, m))) sp.setSelection(i);
        c.addView(sp);
        tfSpinners[m] = sp;
        f[1] = numField(c, "Kitne top coins (volume ke hisaab se, max 400)", Prefs.topCoins(this, m));
        f[2] = numField(c, "Kam az kam 24h volume (million USDT)", Prefs.minVolMillion(this, m));
        f[3] = numField(c, "BUY score threshold (zyada = kam magar pakke)", Prefs.buyThreshold(this, m));
        f[4] = numField(c, "SELL score threshold", Prefs.sellThreshold(this, m));
        f[5] = field(c, "Volume spike = average ka kitna guna", String.valueOf(Prefs.volMult(this, m)),
                InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        f[6] = numField(c, "Ek coin ka dobara signal kitne minute baad", Prefs.cooldownMin(this, m));
        modeFields[m] = f;
        final int mm = m;
        TextView preset = chip("↺ Recommended " + (m == Mode.SCALP ? "scalp" : "spot") + " values", false);
        preset.setOnClickListener(v -> {
            int[] vals = mm == Mode.SCALP ? new int[]{1, 60, 10, 6, 4, 30} : new int[]{15, 150, 5, 7, 5, 240};
            modeFields[mm][0].setText(String.valueOf(vals[0]));
            modeFields[mm][1].setText(String.valueOf(vals[1]));
            modeFields[mm][2].setText(String.valueOf(vals[2]));
            modeFields[mm][3].setText(String.valueOf(vals[3]));
            modeFields[mm][4].setText(String.valueOf(vals[4]));
            modeFields[mm][5].setText(mm == Mode.SCALP ? "1.8" : "2.0");
            modeFields[mm][6].setText(String.valueOf(vals[5]));
            tfSpinners[mm].setSelection(2);
            toast("Recommended values bhar di — neeche Save dabayen");
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = dp(8);
        c.addView(preset, lp);
    }

    private int num(EditText e, int def) {
        try {
            return Integer.parseInt(e.getText().toString().trim());
        } catch (Exception x) {
            return def;
        }
    }

    private void saveSettings() {
        for (int m = 0; m < 2; m++) {
            EditText[] f = modeFields[m];
            float vm;
            try {
                vm = Float.parseFloat(f[5].getText().toString().trim());
            } catch (Exception x) {
                vm = 2.0f;
            }
            Prefs.saveMode(this, m, num(f[0], Prefs.intervalMin(this, m)), Mode.scanTfs(m)[tfSpinners[m].getSelectedItemPosition()],
                    num(f[1], 100), num(f[2], 5), num(f[3], 7), num(f[4], 5), vm, num(f[6], 120));
        }
        Prefs.saveCommon(this, btcCb.isChecked(), smartCb.isChecked(), strongCb.isChecked(),
                num(whaleEt, 50000), glassEt.getText().toString());
        Prefs.saveClaude(this, claudeEt.getText().toString(), ClaudeAI.MODELS[modelSpinner.getSelectedItemPosition()]);
        Prefs.setUpdateRepo(this, repoEt.getText().toString());
        Prefs.setMinConfidence(this, num(minConfEt, 0));
        Prefs.saveQuiet(this, quietCb.isChecked(), num(quietFromEt, 0), num(quietToEt, 7));
        Prefs.setAccuracyMode(this, accCb.isChecked());
        Prefs.setSpotSellUsd(this, (float) parse(spotSellEt, 5));
        Prefs.setScalpHeavyUsd(this, (float) parse(scalpHeavyEt, 250));
        Prefs.putStr(this, "cryptopanic", cpEt.getText().toString().trim());
        Prefs.putStr(this, "cmcal", cmEt.getText().toString().trim());
        Prefs.setMinWinRate(this, num(minWrEt, 55));
        toast("Saved ✅ — agla scan naye settings se hoga");
    }
}
