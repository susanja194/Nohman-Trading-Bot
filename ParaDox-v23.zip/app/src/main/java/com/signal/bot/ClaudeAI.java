package com.signal.bot;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

/** Calls the Claude API (Anthropic Messages API) with the user's own API key. */
public final class ClaudeAI {
    private ClaudeAI() {}

    public static final String[] MODELS = {"claude-sonnet-5-5", "claude-opus-5-5", "claude-haiku-5-5"};

    public static final String SYSTEM = "You are an expert crypto, gold (commodities) and forex trader and market analyst inside the 'ParaDox' "
            + "Android app. The user is a Pakistani trader. Always reply in simple Roman Urdu (Urdu written in English letters), "
            + "short and clear, using bullet points. You receive a LIVE data report (Binance price, multi-timeframe technicals, "
            + "chart patterns, money flow, whale trades, order book, futures positioning, news, sentiment) and must base "
            + "your answer ONLY on that data. Give one clear direction (BUY or SELL / long or short), entry zone, stop-loss, "
            + "2 targets, what would invalidate the idea, and the main risks. If the data conflicts, say which side is "
            + "stronger and why. Never promise profit; end with one short line that this is not financial advice.";

    /** history: list of {role ("user"/"assistant"), text}. Returns Claude's reply text. */
    public static String ask(String apiKey, String model, List<String[]> history) throws Exception {
        JSONObject body = new JSONObject();
        body.put("model", model);
        body.put("max_tokens", 1500);
        body.put("system", SYSTEM);
        JSONArray msgs = new JSONArray();
        for (String[] h : history) {
            JSONObject m = new JSONObject();
            m.put("role", h[0]);
            m.put("content", h[1]);
            msgs.put(m);
        }
        body.put("messages", msgs);

        HttpURLConnection c = (HttpURLConnection) new URL("https://api.anthropic.com/v1/messages").openConnection();
        try {
            c.setRequestMethod("POST");
            c.setConnectTimeout(20000);
            c.setReadTimeout(90000);
            c.setDoOutput(true);
            c.setRequestProperty("content-type", "application/json");
            c.setRequestProperty("x-api-key", apiKey.trim());
            c.setRequestProperty("anthropic-version", "2023-06-01");
            try (OutputStream os = c.getOutputStream()) {
                os.write(body.toString().getBytes("UTF-8"));
            }
            int code = c.getResponseCode();
            String resp = read(code >= 400 ? c.getErrorStream() : c.getInputStream());
            if (code != 200) {
                String msg = resp;
                try {
                    msg = new JSONObject(resp).getJSONObject("error").optString("message", resp);
                } catch (Exception ignored) {
                }
                if (code == 401) msg = "API key ghalat hai — Settings mein sahi Claude API key daalein";
                else if (code == 429) msg = "Bahut zyada requests — thori der baad try karein";
                else if (code == 400 && msg.toLowerCase().contains("credit")) msg = "Anthropic account mein credit khatam — console.anthropic.com par balance add karein";
                throw new Exception(msg);
            }
            JSONArray content = new JSONObject(resp).getJSONArray("content");
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < content.length(); i++) {
                JSONObject b = content.getJSONObject(i);
                if ("text".equals(b.optString("type"))) sb.append(b.optString("text"));
            }
            return sb.toString().trim();
        } finally {
            c.disconnect();
        }
    }

    private static String read(InputStream in) throws Exception {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
            String l;
            while ((l = br.readLine()) != null) sb.append(l).append('\n');
        }
        return sb.toString();
    }
}
