package com.signal.bot;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import java.util.Calendar;

/** Central place that respects notification toggles and quiet hours. */
public final class Notify {
    private Notify() {}

    /** True if this kind of notification may be shown right now. */
    public static boolean allowed(Context c, String type) {
        if (!Prefs.notifOn(c, type)) return false;
        if (Prefs.quietOn(c)) {
            int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
            int f = Prefs.quietFrom(c), t = Prefs.quietTo(c);
            boolean quiet = f <= t ? (h >= f && h < t) : (h >= f || h < t);
            if (quiet) return false;
        }
        return true;
    }

    /** Notification that opens a page of the app ("open" extra, e.g. "catalyst"). */
    public static void showPage(Context c, String type, int id, String title, String text, int color, String page) {
        if (!allowed(c, type)) return;
        ScannerService.createChannels(c);
        Intent open = new Intent(c, MainActivity.class);
        open.putExtra("open", page);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, id, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(c, Scanner.CH_SIGNALS)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(pi)
                .setColor(color)
                .setAutoCancel(true)
                .build();
        ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(id, n);
    }

    /** Simple notification that opens the app on a given tab. */
    public static void show(Context c, String type, int id, String title, String text, int color, int tab) {
        if (!allowed(c, type)) return;
        ScannerService.createChannels(c);
        Intent open = new Intent(c, MainActivity.class);
        open.putExtra("tab", tab);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, id, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(c, Scanner.CH_SIGNALS)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(pi)
                .setColor(color)
                .setAutoCancel(true)
                .build();
        ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(id, n);
    }
}
