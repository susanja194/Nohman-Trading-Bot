package com.signal.bot;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * 🇨🇳 China pulse — China moves crypto and gold (huge OTC USDT market, biggest physical gold buyer, Asian risk mood):
 *  • USDT OTC premium in yuan (OKX P2P vs official USD/CNY): + premium = Chinese money buying crypto, − = selling / capital pull-back
 *  • Yuan (USD/CNH): a weakening yuan historically pushes Chinese savings into BTC and gold
 *  • Hang Seng + Shanghai Composite: Asian risk appetite
 *  • China news from the news radar (PBOC, Beijing, Hong Kong ETFs, bans...)
 */
public final class ChinaPulse {
    private ChinaPulse() {}

    public static final class Result {
        public double otc = Double.NaN, official = Double.NaN, premium = Double.NaN;
        public double cnh5 = Double.NaN, hsi1 = Double.NaN, hsi5 = Double.NaN, sh1 = Double.NaN;
        public int newsUp, newsDown;
        public int cryptoScore, goldScore;
        public final List<String> lines = new ArrayList<>();
        public long at;
    }

    private static volatile Result cache;

    public static Result cached() { return cache; }

    public static Result fetch(long maxAge) {
        Result c = cache;
        if (c != null && System.currentTimeMillis() - c.at < maxAge) return c;
        Result r = new Result();
        r.otc = otc();
        try {
            r.official = YahooData.quote("CNY=X").price;
        } catch (Exception ignored) {
        }
        if (!Double.isNaN(r.otc) && r.official > 0) r.premium = (r.otc / r.official - 1) * 100;
        r.cnh5 = change("CNH=X", 5);
        r.hsi1 = change("^HSI", 1);
        r.hsi5 = change("^HSI", 5);
        r.sh1 = change("000001.SS", 1);
        long now = System.currentTimeMillis();
        for (NewsEngine.Item it : NewsEngine.cached()) {
            if (now - it.time > 24 * 3600_000L) break;
            String t = " " + it.title.toLowerCase(Locale.US) + " ";
            if (!(t.contains("china") || t.contains("chinese") || t.contains("pboc") || t.contains("beijing") || t.contains("hong kong") || t.contains("yuan"))) continue;
            if (it.dir > 0) r.newsUp++;
            else if (it.dir < 0) r.newsDown++;
        }
        // ---- scores
        double cs = 0, gs = 0;
        if (!Double.isNaN(r.premium)) {
            double p = r.premium;
            cs += p >= 1.5 ? 40 : p >= 0.5 ? 20 : p <= -1 ? -40 : p <= -0.3 ? -20 : 0;
            r.lines.add(String.format(Locale.US, "USDT OTC (China P2P): ¥%.3f vs official ¥%.3f → premium %+.2f%% %s", r.otc, r.official, p,
                    p >= 0.5 ? "🟢 Chinese khareedar zyada (crypto mein paisa aa raha)" : p <= -0.3 ? "🔴 Chinese bech rahe / paisa nikal raha" : "⚪ normal"));
        } else r.lines.add("USDT OTC premium abhi nahi mila");
        if (!Double.isNaN(r.cnh5)) {
            cs += r.cnh5 > 0.3 ? 10 : r.cnh5 < -0.3 ? -5 : 0;
            gs += r.cnh5 > 0.3 ? 20 : r.cnh5 < -0.3 ? -10 : 0;
            r.lines.add(String.format(Locale.US, "Yuan (USD/CNH) 5 din: %+.2f%% %s", r.cnh5,
                    r.cnh5 > 0.3 ? "— yuan KAMZOR: Chinese paisa aksar gold / BTC mein jata hai" : r.cnh5 < -0.3 ? "— yuan MAZBOOT" : "— stable"));
        }
        if (!Double.isNaN(r.hsi1)) {
            cs += Fmt.clamp(r.hsi1 * 8, -20, 20);
            gs += Fmt.clamp(-r.hsi1 * 3, -8, 8);
            r.lines.add(String.format(Locale.US, "Hang Seng: aaj %+.2f%% · 5 din %+.2f%% %s", r.hsi1, Double.isNaN(r.hsi5) ? 0 : r.hsi5,
                    r.hsi1 > 1 ? "🟢 Asia risk-ON" : r.hsi1 < -1 ? "🔴 Asia risk-OFF" : ""));
        }
        if (!Double.isNaN(r.sh1)) r.lines.add(String.format(Locale.US, "Shanghai Composite: aaj %+.2f%%", r.sh1));
        if (r.newsUp + r.newsDown > 0) {
            cs += Fmt.clamp((r.newsUp - r.newsDown) * 8, -20, 20);
            r.lines.add("China news (24h): 🟢 " + r.newsUp + " · 🔴 " + r.newsDown);
        }
        r.cryptoScore = (int) Math.round(Fmt.clamp(cs, -100, 100));
        r.goldScore = (int) Math.round(Fmt.clamp(gs, -100, 100));
        r.at = System.currentTimeMillis();
        cache = r;
        return r;
    }

    static double change(String sym, int days) {
        try {
            Candles c = YahooData.fetch(sym, "1d", false);
            if (c.n <= days) return Double.NaN;
            return (c.close[c.n - 1] / c.close[c.n - 1 - days] - 1) * 100;
        } catch (Exception e) {
            return Double.NaN;
        }
    }

    /** Median of the best 10 USDT/CNY P2P ads on OKX (fallback HTX). */
    static double otc() {
        try {
            JSONObject o = new JSONObject(Scanner.getAbsolute("https://www.okx.com/v3/c2c/tradingOrders/books?quoteCurrency=CNY&baseCurrency=USDT&side=sell"
                    + "&paymentMethod=all&userType=all&showTrade=false&showFollow=false&showAlreadyTraded=false&isAbleFilter=false"));
            JSONArray a = o.getJSONObject("data").getJSONArray("sell");
            List<Double> p = new ArrayList<>();
            for (int i = 0; i < a.length() && i < 10; i++) p.add(Double.parseDouble(a.getJSONObject(i).optString("price", "0")));
            p.removeIf(x -> x <= 0);
            if (!p.isEmpty()) {
                Collections.sort(p);
                return p.get(p.size() / 2);
            }
        } catch (Exception ignored) {
        }
        try {
            JSONArray a = new JSONObject(Scanner.getAbsolute("https://otc-api.trygofast.com/v1/data/trade-market?coinId=2&currency=1&tradeType=sell"
                    + "&currPage=1&payMethod=0&acceptOrder=0&blockType=general&online=1&range=0&onlyTradable=false")).getJSONArray("data");
            List<Double> p = new ArrayList<>();
            for (int i = 0; i < a.length() && i < 10; i++) p.add(a.getJSONObject(i).optDouble("price", 0));
            p.removeIf(x -> x <= 0);
            if (!p.isEmpty()) {
                Collections.sort(p);
                return p.get(p.size() / 2);
            }
        } catch (Exception ignored) {
        }
        return Double.NaN;
    }
}
