package com.signal.bot;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Moving-average system (the classic trend-confirmation tool):
 *  - EMA ribbon 9 / 21 / 50 / 100 / 200 and how well it is stacked (bull / bear alignment)
 *  - Golden cross (EMA50 crosses above EMA200) / Death cross (below)
 *  - Fast cross (EMA9 / EMA21) for entries, price vs EMA200, slope of EMA50
 * Pure Java.
 */
public final class MaSystem {
    private MaSystem() {}

    public static final int[] PERIODS = {9, 21, 50, 100, 200};

    public static final class Result {
        public double[][] ema = new double[5][];
        public int alignment;        // -4..+4 (how many neighbouring EMAs are stacked bullish minus bearish)
        public int score;            // -100..100
        public String trend = "";
        public final List<String> lines = new ArrayList<>();
        public final List<int[]> crosses = new ArrayList<>();   // {index, type}: 1 golden, -1 death, 2 fast up, -2 fast down
        public int lastGoldenAgo = -1, lastDeathAgo = -1, lastFastUpAgo = -1, lastFastDownAgo = -1;
    }

    public static Result analyze(double[] close) {
        Result r = new Result();
        int n = close.length;
        for (int k = 0; k < 5; k++) r.ema[k] = Indicators.ema(close, PERIODS[k]);
        if (n < 30) { r.trend = "Data kam"; return r; }
        int li = n - 1;
        double px = close[li];
        boolean has200 = n >= 200, has100 = n >= 100;
        int max = has200 ? 4 : has100 ? 3 : 2;
        for (int k = 0; k < max; k++) {
            if (r.ema[k][li] > r.ema[k + 1][li]) r.alignment++;
            else if (r.ema[k][li] < r.ema[k + 1][li]) r.alignment--;
        }
        // crosses (scan the whole history, remember the latest)
        for (int i = 1; i < n; i++) {
            double f0 = r.ema[0][i - 1] - r.ema[1][i - 1], f1 = r.ema[0][i] - r.ema[1][i];
            if (f0 <= 0 && f1 > 0) r.crosses.add(new int[]{i, 2});
            if (f0 >= 0 && f1 < 0) r.crosses.add(new int[]{i, -2});
            if (i >= 200) {
                double g0 = r.ema[2][i - 1] - r.ema[4][i - 1], g1 = r.ema[2][i] - r.ema[4][i];
                if (g0 <= 0 && g1 > 0) r.crosses.add(new int[]{i, 1});
                if (g0 >= 0 && g1 < 0) r.crosses.add(new int[]{i, -1});
            }
        }
        for (int[] c : r.crosses) {
            int ago = li - c[0];
            if (c[1] == 1) r.lastGoldenAgo = ago;
            if (c[1] == -1) r.lastDeathAgo = ago;
            if (c[1] == 2) r.lastFastUpAgo = ago;
            if (c[1] == -2) r.lastFastDownAgo = ago;
        }
        double slope50 = li >= 10 ? (r.ema[2][li] / r.ema[2][li - 10] - 1) * 100 : 0;

        double sc = r.alignment / (double) max * 45;
        if (has200) sc += px > r.ema[4][li] ? 15 : -15;
        sc += px > r.ema[1][li] ? 10 : -10;
        sc += Fmt.clamp(slope50 / 2.0, -1, 1) * 10;
        if (r.lastFastUpAgo >= 0 && r.lastFastUpAgo <= 3 && (r.lastFastDownAgo < 0 || r.lastFastUpAgo < r.lastFastDownAgo)) sc += 12;
        if (r.lastFastDownAgo >= 0 && r.lastFastDownAgo <= 3 && (r.lastFastUpAgo < 0 || r.lastFastDownAgo < r.lastFastUpAgo)) sc -= 12;
        if (r.lastGoldenAgo >= 0 && r.lastGoldenAgo <= 20) sc += 10;
        if (r.lastDeathAgo >= 0 && r.lastDeathAgo <= 20) sc -= 10;
        r.score = (int) Math.round(Fmt.clamp(sc, -100, 100));

        r.trend = r.alignment == max ? "Poora BULLISH ribbon (9>21>50" + (has100 ? ">100" : "") + (has200 ? ">200" : "") + ")"
                : r.alignment == -max ? "Poora BEARISH ribbon (9<21<50" + (has100 ? "<100" : "") + (has200 ? "<200" : "") + ")"
                : r.alignment > 0 ? "Zyada tar bullish (MAs upar ki taraf)" : r.alignment < 0 ? "Zyada tar bearish (MAs neeche ki taraf)" : "MAs uljhe hue — range / sideways";
        r.lines.add("Ribbon: " + r.trend);
        if (has200) r.lines.add("Price " + (px > r.ema[4][li] ? "EMA200 ke UPAR — lambi trend bullish ✅" : "EMA200 ke NEECHE — lambi trend bearish ⚠️"));
        r.lines.add(String.format(Locale.US, "EMA50 ka jhukao (10 candles): %+.2f%%", slope50));
        if (r.lastFastUpAgo >= 0 && (r.lastFastDownAgo < 0 || r.lastFastUpAgo < r.lastFastDownAgo))
            r.lines.add("Taaza fast cross: EMA9 ne EMA21 ko UPAR kata (" + r.lastFastUpAgo + " candles pehle) 🟢");
        else if (r.lastFastDownAgo >= 0)
            r.lines.add("Taaza fast cross: EMA9 ne EMA21 ko NEECHE kata (" + r.lastFastDownAgo + " candles pehle) 🔴");
        if (r.lastGoldenAgo >= 0 && (r.lastDeathAgo < 0 || r.lastGoldenAgo < r.lastDeathAgo))
            r.lines.add("✨ Golden cross (EMA50 > EMA200) " + r.lastGoldenAgo + " candles pehle — bull market ka ishara");
        else if (r.lastDeathAgo >= 0)
            r.lines.add("☠️ Death cross (EMA50 < EMA200) " + r.lastDeathAgo + " candles pehle — bear market ka ishara");
        return r;
    }
}
