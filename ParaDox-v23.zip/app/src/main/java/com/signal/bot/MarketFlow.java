package com.signal.bot;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * Money IN / OUT of a coin across ALL big exchanges (USD, 15m · 1h · 4h · 24h):
 *  • Binance spot + futures — exact (taker-buy volume per 5m candle)
 *  • OKX spot + perpetual — exact buy/sell ratio per 5m (rubik) × OKX's own 24h USD volume
 *  • Bybit, Coinbase, KuCoin, Gate, Bitget — buy/sell share of their latest trades × their 24h USD volume
 *    (an estimate that fades for the longer windows, because recent trades only cover minutes)
 */
public final class MarketFlow {
    private MarketFlow() {}

    public static final class Venue {
        public String name;
        public boolean exact;
        public double vol24, buyPct = 50;
        public final double[] net = new double[4];
    }

    public static final class Result {
        public final List<Venue> venues = new ArrayList<>();
        public final double[] net = new double[4];
        public double vol24, exactVol;
        public int up, down;

        public double net15() { return net[0]; }
        public double net1h() { return net[1]; }
        public double net4h() { return net[2]; }
        public double net24h() { return net[3]; }

        public List<String> lines() {
            List<String> l = new ArrayList<>();
            String[] w = {"15 min", "1 ghanta", "4 ghante", "24 ghante"};
            l.add(String.format(Locale.US, "%d exchanges · 24h volume %s · %d par buyers aage, %d par sellers", venues.size(), Fmt.usd(vol24), up, down));
            for (int k = 0; k < 4; k++)
                l.add(String.format(Locale.US, "%s: SAB exchanges net %s%s %s", w[k], net[k] >= 0 ? "+" : "−", Fmt.usd(Math.abs(net[k])), net[k] >= 0 ? "🟢 IN" : "🔴 OUT"));
            for (Venue v : venues)
                l.add(String.format(Locale.US, "   %s %s%s: buy %.0f%% · 1h %s%s · 24h vol %s", v.buyPct >= 52 ? "🟢" : v.buyPct <= 48 ? "🔴" : "⚪", v.name,
                        v.exact ? "" : " (andaza)", v.buyPct, v.net[1] >= 0 ? "+" : "−", Fmt.usd(Math.abs(v.net[1])), Fmt.usd(v.vol24)));
            return l;
        }
    }

    private static final ExecutorService POOL = Executors.newFixedThreadPool(7);
    private static final double[] WIN_MIN = {15, 60, 240, 1440};
    private static final double[] FADE = {1.0, 0.8, 0.5, 0.25};   // trade-sample venues: tone fades on long windows

    private static double d(String s) {
        try { return Double.parseDouble(s); } catch (Exception e) { return 0; }
    }

    public static Result fetch(final String base, HeavyFlow.Result hf) {
        Result r = new Result();
        if (hf != null) {
            Venue b = new Venue();
            b.name = "Binance spot+futures";
            b.exact = true;
            for (int k = 0; k < 4; k++) b.net[k] = hf.net(k);
            b.vol24 = hf.gross[3];
            b.buyPct = hf.gross[1] > 0 ? 50 + hf.net1h() / hf.gross[1] * 50 : 50;
            r.venues.add(b);
        }
        List<Callable<Venue>> jobs = new ArrayList<>();
        jobs.add(() -> okx(base, false));
        jobs.add(() -> okx(base, true));
        jobs.add(() -> bybit(base));
        jobs.add(() -> coinbase(base));
        jobs.add(() -> kucoin(base));
        jobs.add(() -> gate(base));
        jobs.add(() -> bitget(base));
        try {
            for (Future<Venue> f : POOL.invokeAll(jobs, 12, TimeUnit.SECONDS)) {
                try {
                    Venue v = f.get();
                    if (v != null && v.vol24 > 0) r.venues.add(v);
                } catch (Exception ignored) {
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        for (Venue v : r.venues) {
            for (int k = 0; k < 4; k++) r.net[k] += v.net[k];
            r.vol24 += v.vol24;
            if (v.exact) r.exactVol += v.vol24;
            if (v.buyPct >= 52) r.up++;
            else if (v.buyPct <= 48) r.down++;
        }
        return r;
    }

    /** Trade-sample venue: share of taker buys in the latest trades × 24h USD volume, scaled per window. */
    private static Venue sample(String name, double buyUsd, double sellUsd, double vol24) {
        if (buyUsd + sellUsd <= 0 || vol24 <= 0) return null;
        Venue v = new Venue();
        v.name = name;
        v.vol24 = vol24;
        double p = buyUsd / (buyUsd + sellUsd);
        v.buyPct = p * 100;
        for (int k = 0; k < 4; k++) v.net[k] = (2 * p - 1) * vol24 * WIN_MIN[k] / 1440.0 * FADE[k];
        return v;
    }

    private static Venue okx(String base, boolean swap) throws Exception {
        JSONObject o = new JSONObject(Scanner.getAbsolute("https://www.okx.com/api/v5/rubik/stat/taker-volume?ccy=" + base
                + "&instType=" + (swap ? "CONTRACTS" : "SPOT") + "&period=5m"));
        JSONArray a = o.getJSONArray("data");   // newest first: [ts, sellVol, buyVol]
        int[] rows = {3, 12, 48, 288};
        double[] b = new double[4], s = new double[4];
        for (int i = 0; i < a.length() && i < 288; i++) {
            JSONArray x = a.getJSONArray(i);
            double sv = d(x.getString(1)), bv = d(x.getString(2));
            for (int k = 0; k < 4; k++) if (i < rows[k]) { b[k] += bv; s[k] += sv; }
        }
        double tot24 = b[3] + s[3];
        if (tot24 <= 0) return null;
        String inst = base + "-USDT" + (swap ? "-SWAP" : "");
        JSONObject t = new JSONObject(Scanner.getAbsolute("https://www.okx.com/api/v5/market/ticker?instId=" + inst)).getJSONArray("data").getJSONObject(0);
        double last = d(t.optString("last"));
        double vol24 = swap ? d(t.optString("volCcy24h")) * last : d(t.optString("volCcy24h"));
        Venue v = new Venue();
        v.name = swap ? "OKX futures" : "OKX spot";
        v.exact = true;
        v.vol24 = vol24;
        v.buyPct = b[1] + s[1] > 0 ? b[1] / (b[1] + s[1]) * 100 : 50;
        for (int k = 0; k < 4; k++) {
            double t2 = b[k] + s[k];
            if (t2 <= 0) continue;
            double share = t2 / tot24;                 // this window's part of the day's OKX volume
            v.net[k] = (b[k] - s[k]) / t2 * vol24 * share;
        }
        return v;
    }

    private static Venue bybit(String base) throws Exception {
        String sym = base + "USDT";
        JSONArray a = new JSONObject(Scanner.getAbsolute("https://api.bybit.com/v5/market/recent-trade?category=linear&symbol=" + sym + "&limit=1000"))
                .getJSONObject("result").getJSONArray("list");
        double b = 0, s = 0;
        for (int i = 0; i < a.length(); i++) {
            JSONObject t = a.getJSONObject(i);
            double usd = d(t.optString("price")) * d(t.optString("size"));
            if ("Buy".equalsIgnoreCase(t.optString("side"))) b += usd; else s += usd;
        }
        JSONObject tk = new JSONObject(Scanner.getAbsolute("https://api.bybit.com/v5/market/tickers?category=linear&symbol=" + sym))
                .getJSONObject("result").getJSONArray("list").getJSONObject(0);
        return sample("Bybit futures", b, s, d(tk.optString("turnover24h")));
    }

    private static Venue coinbase(String base) throws Exception {
        String pair = base + "-USD";
        JSONArray a = new JSONArray(Scanner.getAbsolute("https://api.exchange.coinbase.com/products/" + pair + "/trades?limit=1000"));
        double b = 0, s = 0;
        for (int i = 0; i < a.length(); i++) {
            JSONObject t = a.getJSONObject(i);
            double usd = d(t.optString("price")) * d(t.optString("size"));
            if ("sell".equals(t.optString("side"))) b += usd; else s += usd;   // maker side -> taker is the opposite
        }
        JSONObject st = new JSONObject(Scanner.getAbsolute("https://api.exchange.coinbase.com/products/" + pair + "/stats"));
        return sample("Coinbase", b, s, d(st.optString("volume")) * d(st.optString("last")));
    }

    private static Venue kucoin(String base) throws Exception {
        String sym = base + "-USDT";
        JSONArray a = new JSONObject(Scanner.getAbsolute("https://api.kucoin.com/api/v1/market/histories?symbol=" + sym)).getJSONArray("data");
        double b = 0, s = 0;
        for (int i = 0; i < a.length(); i++) {
            JSONObject t = a.getJSONObject(i);
            double usd = d(t.optString("price")) * d(t.optString("size"));
            if ("buy".equals(t.optString("side"))) b += usd; else s += usd;
        }
        JSONObject st = new JSONObject(Scanner.getAbsolute("https://api.kucoin.com/api/v1/market/stats?symbol=" + sym)).getJSONObject("data");
        return sample("KuCoin", b, s, d(st.optString("volValue")));
    }

    private static Venue gate(String base) throws Exception {
        String pair = base + "_USDT";
        JSONArray a = new JSONArray(Scanner.getAbsolute("https://api.gateio.ws/api/v4/spot/trades?currency_pair=" + pair + "&limit=1000"));
        double b = 0, s = 0;
        for (int i = 0; i < a.length(); i++) {
            JSONObject t = a.getJSONObject(i);
            double usd = d(t.optString("price")) * d(t.optString("amount"));
            if ("buy".equals(t.optString("side"))) b += usd; else s += usd;
        }
        JSONArray tk = new JSONArray(Scanner.getAbsolute("https://api.gateio.ws/api/v4/spot/tickers?currency_pair=" + pair));
        return sample("Gate", b, s, tk.length() > 0 ? d(tk.getJSONObject(0).optString("quote_volume")) : 0);
    }

    private static Venue bitget(String base) throws Exception {
        String sym = base + "USDT";
        JSONArray a = new JSONObject(Scanner.getAbsolute("https://api.bitget.com/api/v2/spot/market/fills?symbol=" + sym + "&limit=500")).getJSONArray("data");
        double b = 0, s = 0;
        for (int i = 0; i < a.length(); i++) {
            JSONObject t = a.getJSONObject(i);
            double usd = d(t.optString("price")) * d(t.optString("size"));
            if ("buy".equals(t.optString("side"))) b += usd; else s += usd;
        }
        JSONArray tk = new JSONObject(Scanner.getAbsolute("https://api.bitget.com/api/v2/spot/market/tickers?symbol=" + sym)).getJSONArray("data");
        double v = 0;
        if (tk.length() > 0) {
            JSONObject o = tk.getJSONObject(0);
            v = d(o.optString("usdtVolume", o.optString("quoteVolume")));
        }
        return sample("Bitget", b, s, v);
    }
}
