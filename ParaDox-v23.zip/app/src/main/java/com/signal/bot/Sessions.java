package com.signal.bot;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/**
 * World trading sessions with live OPEN / CLOSED status and countdowns, computed in each market's own time zone
 * (so summer / winter time changes are handled automatically) and shown in Pakistan time.
 */
public final class Sessions {
    private Sessions() {}

    public static final TimeZone PKT = TimeZone.getTimeZone("Asia/Karachi");

    public static final class Session {
        public final String icon, name, market, tz, note;
        public final int openH, openM, closeH, closeM;   // local time of that city
        public final boolean[] days;                      // Calendar.SUNDAY(1)..SATURDAY(7) -> trading day (open date)
        public boolean open;
        public long nextChange;                           // ms
        public String pktHours = "";

        Session(String icon, String name, String market, String tz, int oh, int om, int ch, int cm, boolean[] days, String note) {
            this.icon = icon; this.name = name; this.market = market; this.tz = tz;
            openH = oh; openM = om; closeH = ch; closeM = cm; this.days = days; this.note = note;
        }
    }

    static final boolean[] MON_FRI = {false, false, true, true, true, true, true, false};
    static final boolean[] SUN_THU = {false, true, true, true, true, true, false, false};   // opens Sun evening .. Thu evening (closes next day)

    public static List<Session> all() {
        List<Session> l = new ArrayList<>();
        // ---- Forex (24/5): the four big centres
        l.add(new Session("🇦🇺", "Sydney", "Forex", "Australia/Sydney", 7, 0, 16, 0, MON_FRI, "AUD, NZD pairs active · forex hafta yahin se khulta hai"));
        l.add(new Session("🇯🇵", "Tokyo", "Forex", "Asia/Tokyo", 9, 0, 18, 0, MON_FRI, "JPY pairs (USDJPY, EURJPY, GBPJPY), AUD"));
        l.add(new Session("🇬🇧", "London", "Forex", "Europe/London", 8, 0, 17, 0, MON_FRI, "Sab se bara forex center (~38% volume) · EUR, GBP, CHF · gold bhi"));
        l.add(new Session("🇺🇸", "New York", "Forex", "America/New_York", 8, 0, 17, 0, MON_FRI, "USD pairs, US news (CPI, NFP, Fed) · gold aur crypto par bhi asar"));
        // ---- Gold
        l.add(new Session("🥇", "COMEX gold futures (CME Globex)", "Gold", "America/New_York", 18, 0, 17, 0, SUN_THU, "Sun 6pm – Fri 5pm New York · roz 5–6pm ka 1 ghanta break"));
        l.add(new Session("🇬🇧", "London gold (LBMA)", "Gold", "Europe/London", 8, 0, 17, 0, MON_FRI, "Duniya ki sab se bari physical gold market · price fix 10:30 aur 15:00 London"));
        l.add(new Session("🇨🇳", "Shanghai Gold Exchange (din)", "Gold", "Asia/Shanghai", 9, 0, 15, 30, MON_FRI, "China — bari physical demand · 11:30–13:30 lunch break"));
        l.add(new Session("🇨🇳", "Shanghai Gold Exchange (raat)", "Gold", "Asia/Shanghai", 20, 0, 2, 30, MON_FRI, "Raat ka session (agle din 2:30 tak)"));
        // ---- Stocks that move gold / forex / crypto
        l.add(new Session("🗽", "US stocks (NYSE / Nasdaq)", "Stocks", "America/New_York", 9, 30, 16, 0, MON_FRI, "Stocks khulte waqt crypto mein bhi volatility · ETF flows isi waqt"));
        return l;
    }

    /** Compute open/closed + next change for every session at time `now`. */
    public static List<Session> status(long now) {
        List<Session> l = all();
        for (Session s : l) compute(s, now);
        return l;
    }

    static void compute(Session s, long now) {
        TimeZone tz = TimeZone.getTimeZone(s.tz);
        boolean overnight = s.closeH * 60 + s.closeM <= s.openH * 60 + s.openM;
        long best = Long.MAX_VALUE;
        s.open = false;
        // check windows that started from 3 days ago to 8 days ahead
        for (int dOff = -3; dOff <= 8; dOff++) {
            Calendar c = Calendar.getInstance(tz);
            c.setTimeInMillis(now);
            c.add(Calendar.DAY_OF_YEAR, dOff);
            int dow = c.get(Calendar.DAY_OF_WEEK);
            if (!s.days[dow]) continue;
            c.set(Calendar.HOUR_OF_DAY, s.openH);
            c.set(Calendar.MINUTE, s.openM);
            c.set(Calendar.SECOND, 0);
            c.set(Calendar.MILLISECOND, 0);
            long o = c.getTimeInMillis();
            if (overnight) c.add(Calendar.DAY_OF_YEAR, 1);
            c.set(Calendar.HOUR_OF_DAY, s.closeH);
            c.set(Calendar.MINUTE, s.closeM);
            long cl = c.getTimeInMillis();
            if (now >= o && now < cl) {
                s.open = true;
                best = cl;
            } else if (!s.open && o > now && o < best) best = o;
        }
        s.nextChange = best;
        s.pktHours = pkt(s, tz);
    }

    /** Session hours converted to Pakistan time for today's date. */
    static String pkt(Session s, TimeZone tz) {
        Calendar c = Calendar.getInstance(tz);
        c.set(Calendar.HOUR_OF_DAY, s.openH);
        c.set(Calendar.MINUTE, s.openM);
        long o = c.getTimeInMillis();
        c.set(Calendar.HOUR_OF_DAY, s.closeH);
        c.set(Calendar.MINUTE, s.closeM);
        long cl = c.getTimeInMillis();
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("h:mm a", Locale.US);
        f.setTimeZone(PKT);
        return f.format(new java.util.Date(o)) + " – " + f.format(new java.util.Date(cl)) + " PKT";
    }

    public static String countdown(long ms) {
        if (ms <= 0) return "abhi";
        long m = ms / 60_000L;
        if (m < 60) return m + " min";
        long h = m / 60;
        if (h < 48) return h + " ghante " + (m % 60) + " min";
        return (h / 24) + " din " + (h % 24) + " ghante";
    }

    /** Short line about the current trading moment. */
    public static String moment(List<Session> l) {
        boolean lon = false, ny = false, tok = false, syd = false;
        for (Session s : l) {
            if (!s.market.equals("Forex")) continue;
            if (s.name.equals("London")) lon = s.open;
            if (s.name.equals("New York")) ny = s.open;
            if (s.name.equals("Tokyo")) tok = s.open;
            if (s.name.equals("Sydney")) syd = s.open;
        }
        if (!Assets.marketOpen(System.currentTimeMillis())) return "🔴 Weekend — forex aur gold band hain (crypto 24/7 chal raha hai)";
        if (lon && ny) return "🔥 London + New York OVERLAP — din ka sab se zyada volume aur sab se tez moves (forex + gold)";
        if (tok && lon) return "⚡ Tokyo + London overlap — JPY / EUR pairs mein harkat";
        if (lon) return "🟢 London session — EUR, GBP, gold mein achha volume";
        if (ny) return "🟢 New York session — USD pairs, gold aur US news";
        if (tok) return "🟡 Tokyo session — JPY pairs, baqi market dheemi";
        if (syd) return "🟡 Sydney session — dheema waqt, spread zyada";
        return "⚪ Dheema waqt";
    }
}
