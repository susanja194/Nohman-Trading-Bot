package com.signal.bot;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * World trading volume and money IN / OUT for the three markets, from free public data:
 *  • Crypto: CoinGecko global 24h volume & market-cap change, DefiLlama stablecoin supply (new dollars in / out)
 *  • Gold: COMEX gold futures (GC=F) + gold ETFs GLD / IAU (Yahoo) — dollar volume and money-flow (in / out)
 *  • Forex: BIS survey size ($9.6 trillion / day, April 2025) + CME currency futures (EUR, JPY, GBP) and the dollar index
 */
public final class GlobalVolume {
    private GlobalVolume() {}

    public static final class Block {
        public String title = "", headline = "";
        public double volume, net, net5;      // USD
        public int dir;
        public final List<String> lines = new ArrayList<>();
    }

    public static final class Result {
        public Block crypto, gold, forex;
        public long at;
    }

    private static volatile Result cache;

    public static Result cached() { return cache; }

    public static Result fetch(boolean force) {
        if (!force && cache != null && System.currentTimeMillis() - cache.at < 5 * 60_000L) return cache;
        Result r = new Result();
        r.crypto = crypto();
        r.gold = gold();
        r.forex = forex();
        r.at = System.currentTimeMillis();
        cache = r;
        return r;
    }

    // ------------------------------------------------------------------ crypto
    static Block crypto() {
        Block b = new Block();
        b.title = "🪙 Crypto (24/7)";
        try {
            JSONObject g = new JSONObject(Scanner.getAbsolute("https://api.coingecko.com/api/v3/global")).getJSONObject("data");
            double vol = g.getJSONObject("total_volume").optDouble("usd", 0), mcap = g.getJSONObject("total_market_cap").optDouble("usd", 0);
            double ch = g.optDouble("market_cap_change_percentage_24h_usd", 0);
            b.volume = vol;
            b.net = mcap - mcap / (1 + ch / 100);
            b.lines.add("24h trading volume (sab exchanges): " + Fmt.usd(vol));
            b.lines.add(String.format(Locale.US, "Total market cap: %s (%+.2f%% · %s%s 24h)", Fmt.usd(mcap), ch, b.net >= 0 ? "+" : "−", Fmt.usd(Math.abs(b.net))));
            JSONObject pct = g.optJSONObject("market_cap_percentage");
            if (pct != null) b.lines.add(String.format(Locale.US, "BTC dominance %.1f%% · ETH %.1f%%", pct.optDouble("btc", 0), pct.optDouble("eth", 0)));
        } catch (Exception e) {
            b.lines.add("CoinGecko abhi nahi mila");
        }
        try {
            JSONArray a = new JSONArray(Scanner.getAbsolute("https://stablecoins.llama.fi/stablecoincharts/all"));
            int n = a.length();
            if (n > 8) {
                double now = sc(a.getJSONObject(n - 1)), d1 = sc(a.getJSONObject(n - 2)), d7 = sc(a.getJSONObject(n - 8));
                b.net5 = now - d7;
                b.lines.add(String.format(Locale.US, "Stablecoins (naya dollar crypto mein): %s · 24h %s%s · 7 din %s%s", Fmt.usd(now),
                        now >= d1 ? "+" : "−", Fmt.usd(Math.abs(now - d1)), now >= d7 ? "+" : "−", Fmt.usd(Math.abs(now - d7))));
            }
        } catch (Exception ignored) {
        }
        b.dir = b.net > 0 ? 1 : b.net < 0 ? -1 : 0;
        b.headline = (b.dir >= 0 ? "💰 Paisa AA raha: +" : "🚨 Paisa NIKAL raha: −") + Fmt.usd(Math.abs(b.net)) + " (24h market cap)";
        return b;
    }

    static double sc(JSONObject o) {
        JSONObject t = o.optJSONObject("totalCirculatingUSD");
        return t != null ? t.optDouble("peggedUSD", 0) : 0;
    }

    // ------------------------------------------------------------------ gold
    /** {dollar volume last day, money-flow last day, money-flow 5 days} from daily candles. */
    static double[] flow(String sym, double mult) {
        try {
            Candles c = YahooData.fetch(sym, "1d", false);
            if (c.n < 7) return null;
            double[] r = new double[3];
            for (int k = 0; k < 5; k++) {
                int i = c.n - 1 - k;
                double rng = c.high[i] - c.low[i];
                double m = rng > 0 ? ((c.close[i] - c.low[i]) - (c.high[i] - c.close[i])) / rng : 0;
                double usd = c.vol[i] * mult * c.close[i];
                if (k == 0) { r[0] = usd; r[1] = m * usd; }
                r[2] += m * usd;
            }
            return r;
        } catch (Exception e) {
            return null;
        }
    }

    static Block gold() {
        Block b = new Block();
        b.title = "🥇 Gold";
        String[][] src = {{"GC=F", "COMEX gold futures", "100"}, {"GLD", "SPDR Gold ETF (GLD)", "1"}, {"IAU", "iShares Gold ETF (IAU)", "1"}};
        for (String[] s : src) {
            double[] f = flow(s[0], Double.parseDouble(s[2]));
            if (f == null) continue;
            b.volume += f[0];
            b.net += f[1];
            b.net5 += f[2];
            b.lines.add(String.format(Locale.US, "%s: volume %s · aaj %s%s · 5 din %s%s", s[1], Fmt.usd(f[0]), f[1] >= 0 ? "IN +" : "OUT −", Fmt.usd(Math.abs(f[1])),
                    f[2] >= 0 ? "+" : "−", Fmt.usd(Math.abs(f[2]))));
        }
        b.lines.add("London OTC (LBMA) aur Shanghai ka physical volume is se kahin zyada hai — woh roz free data mein nahi milta.");
        b.dir = b.net > 0 ? 1 : b.net < 0 ? -1 : 0;
        b.headline = (b.volume > 0 ? "Measured volume " + Fmt.usd(b.volume) + " · " : "")
                + (b.dir >= 0 ? "💰 Paisa AA raha" : "🚨 Paisa NIKAL raha") + " (aaj " + (b.net >= 0 ? "+" : "−") + Fmt.usd(Math.abs(b.net)) + ")";
        return b;
    }

    // ------------------------------------------------------------------ forex
    static Block forex() {
        Block b = new Block();
        b.title = "💱 Forex (24/5)";
        b.volume = 9.6e12;
        b.lines.add("Duniya ka forex volume: ~$9.6 trillion ROZ (BIS survey, April 2025) — duniya ki sab se bari market");
        b.lines.add("Sab se zyada: USD (~89% trades mein), phir EUR, JPY, GBP · London ~38%, New York ~19% volume");
        String[][] fut = {{"6E=F", "Euro futures (CME)", "125000"}, {"6J=F", "Yen futures (CME)", "12500000"}, {"6B=F", "Pound futures (CME)", "62500"}};
        double usdOut = 0;
        for (String[] s : fut) {
            try {
                Candles c = YahooData.fetch(s[0], "1d", false);
                if (c.n < 7) continue;
                int i = c.n - 1;
                double rng = c.high[i] - c.low[i];
                double m = rng > 0 ? ((c.close[i] - c.low[i]) - (c.high[i] - c.close[i])) / rng : 0;
                double usd = c.vol[i] * Double.parseDouble(s[2]) * c.close[i];
                usdOut += m * usd;   // money INTO the foreign currency = OUT of the dollar
                b.lines.add(String.format(Locale.US, "%s: volume %s · %s", s[1], Fmt.usd(usd), m > 0.1 ? "currency mein paisa AA raha" : m < -0.1 ? "currency se paisa NIKAL raha" : "barabar"));
            } catch (Exception ignored) {
            }
        }
        try {
            Candles d = YahooData.fetch(Assets.DXY, "1d", false);
            if (d.n > 6) {
                double ch1 = (d.close[d.n - 1] / d.close[d.n - 2] - 1) * 100, ch5 = (d.close[d.n - 1] / d.close[d.n - 6] - 1) * 100;
                b.lines.add(String.format(Locale.US, "Dollar index (DXY) %.2f · aaj %+.2f%% · 5 din %+.2f%%", d.close[d.n - 1], ch1, ch5));
                b.dir = ch1 > 0.05 ? 1 : ch1 < -0.05 ? -1 : 0;
            }
        } catch (Exception ignored) {
        }
        b.net = -usdOut;
        b.headline = b.dir > 0 ? "💵 Paisa DOLLAR mein AA raha (dollar mazboot)" : b.dir < 0 ? "💸 Paisa DOLLAR se NIKAL raha (dollar kamzor)" : "⚖️ Dollar barabar";
        return b;
    }
}
