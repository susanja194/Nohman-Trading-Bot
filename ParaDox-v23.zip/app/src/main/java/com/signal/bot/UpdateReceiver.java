package com.signal.bot;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.widget.Toast;

/** Receives the result of an in-app update install. */
public class UpdateReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        int st = i.getIntExtra(PackageInstaller.EXTRA_STATUS, -999);
        if (st == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            Intent confirm = i.getParcelableExtra(Intent.EXTRA_INTENT);
            if (confirm != null) {
                confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try {
                    c.startActivity(confirm);
                } catch (Exception e) {
                    notify(c, "Update tayyar hai — app kholen aur dobara Install dabayen");
                }
            }
        } else if (st == PackageInstaller.STATUS_SUCCESS) {
            notify(c, "✅ ParaDox update ho gaya — app kholen");
        } else {
            String msg = i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
            notify(c, "❌ Update install nahi hua: " + (msg == null ? ("status " + st) : msg));
            try {
                Toast.makeText(c, "Update install nahi hua", Toast.LENGTH_LONG).show();
            } catch (Exception ignored) {
            }
        }
    }

    static void notify(Context c, String text) {
        ScannerService.createChannels(c);
        Notification n = new Notification.Builder(c, Scanner.CH_SIGNALS)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("ParaDox")
                .setContentText(text)
                .setAutoCancel(true)
                .build();
        ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(4243, n);
    }
}
