package com.signal.bot;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Reader mode: downloads a news page and keeps only the story — headline, main picture, paragraphs, sub-headings
 * and in-article images — so it can be read INSIDE the app instead of opening the website.
 */
public final class ArticleReader {
    private ArticleReader() {}

    public static final class Block {
        public final String text, img;
        public final boolean heading;
        Block(String text, String img, boolean heading) { this.text = text; this.img = img; this.heading = heading; }
    }

    public static final class Article {
        public String url = "", title = "", site = "", image = "";
        public final List<Block> blocks = new ArrayList<>();
    }

    static String fetchHtml(String url, String[] finalUrl) throws Exception {
        String cur = url;
        for (int hop = 0; hop < 5; hop++) {
            HttpURLConnection c = (HttpURLConnection) new URL(cur).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(15000);
            c.setReadTimeout(25000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36");
            c.setRequestProperty("Accept", "text/html,application/xhtml+xml");
            c.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) break;
                cur = new URL(new URL(cur), loc).toString();
                continue;
            }
            if (code != 200) { c.disconnect(); throw new Exception("HTTP " + code); }
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            try (InputStream in = c.getInputStream()) {
                byte[] buf = new byte[16384];
                int r, total = 0;
                while ((r = in.read(buf)) > 0 && total < 3_000_000) { bo.write(buf, 0, r); total += r; }
            } finally {
                c.disconnect();
            }
            finalUrl[0] = cur;
            return bo.toString("UTF-8");
        }
        throw new Exception("Redirect loop");
    }

    public static Article read(String url) throws Exception {
        String[] fin = {url};
        String html = fetchHtml(url, fin);
        // Google News wrapper page -> the real article link
        if (fin[0].contains("news.google.com")) {
            Matcher m = Pattern.compile("data-n-au=\"(https?://[^\"]+)\"").matcher(html);
            String real = m.find() ? m.group(1) : null;
            if (real == null) {
                Matcher a = Pattern.compile("<a[^>]+href=\"(https?://(?!news\\.google|www\\.google|accounts\\.google|policies\\.google|support\\.google)[^\"]+)\"").matcher(html);
                if (a.find()) real = a.group(1);
            }
            if (real != null) html = fetchHtml(real.replace("&amp;", "&"), fin);
        }
        return parse(html, fin[0]);
    }

    public static Article parse(String html, String finalUrl) {
        String[] fin = {finalUrl};
        Article art = new Article();
        art.url = fin[0];
        try { art.site = new URL(fin[0]).getHost().replace("www.", ""); } catch (Exception ignored) { }
        art.title = meta(html, "og:title");
        if (art.title.isEmpty()) art.title = NewsEngine.clean(NewsEngine.tagv(html, "title"));
        art.image = abs(meta(html, "og:image"), fin[0]);

        String body = html.replaceAll("(?is)<script.*?</script>", " ").replaceAll("(?is)<style.*?</style>", " ")
                .replaceAll("(?is)<noscript.*?</noscript>", " ").replaceAll("(?is)<(nav|header|footer|aside|form|figcaption)[\\s>].*?</\\1>", " ");
        Matcher am = Pattern.compile("(?is)<article[\\s>](.*?)</article>").matcher(body);
        String best = null;
        while (am.find()) if (best == null || am.group(1).length() > best.length()) best = am.group(1);
        if (best != null && best.length() > 1500) body = best;
        else {
            Matcher mm = Pattern.compile("(?is)<main[\\s>](.*?)</main>").matcher(body);
            if (mm.find() && mm.group(1).length() > 1500) body = mm.group(1);
        }
        Pattern tok = Pattern.compile("(?is)<(p|h2|h3|li|blockquote)(?:\\s[^>]*)?>(.*?)</\\1>|<img\\s[^>]*>");
        Matcher t = tok.matcher(body);
        Set<String> seen = new HashSet<>();
        int imgs = 0, chars = 0;
        if (!art.image.isEmpty()) seen.add(art.image);
        while (t.find() && art.blocks.size() < 90 && chars < 25_000) {
            if (t.group(1) == null) {
                String tag = t.group();
                String src = attr(tag, "data-src");
                if (src.isEmpty()) src = attr(tag, "src");
                if (src.isEmpty()) {
                    String ss = attr(tag, "srcset");
                    if (!ss.isEmpty()) src = ss.split(",")[0].trim().split(" ")[0];
                }
                src = abs(src, fin[0]);
                String low = src.toLowerCase(Locale.US);
                if (src.isEmpty() || low.endsWith(".svg") || low.startsWith("data:") || low.contains("logo") || low.contains("icon") || low.contains("avatar")
                        || low.contains("pixel") || low.contains("sprite") || low.contains("gravatar") || low.contains("1x1") || seen.contains(src) || imgs >= 6) continue;
                String w = attr(tag, "width");
                try { if (!w.isEmpty() && Integer.parseInt(w.replaceAll("[^0-9]", "")) < 200) continue; } catch (Exception ignored) { }
                seen.add(src);
                art.blocks.add(new Block(null, src, false));
                imgs++;
                continue;
            }
            String tg = t.group(1).toLowerCase(Locale.US);
            String txt = NewsEngine.clean(t.group(2));
            boolean head = tg.startsWith("h");
            if (txt.isEmpty() || seen.contains(txt)) continue;
            if (!head && txt.length() < (tg.equals("li") ? 25 : 45)) continue;
            String tl = txt.toLowerCase(Locale.US);
            if (tl.contains("cookie") || tl.contains("subscribe to") || tl.contains("sign up for") || tl.contains("newsletter") || tl.contains("all rights reserved")
                    || tl.startsWith("advertisement") || tl.contains("follow us on")) continue;
            seen.add(txt);
            art.blocks.add(new Block(txt, null, head));
            chars += txt.length();
        }
        return art;
    }

    static String meta(String html, String prop) {
        Matcher m = Pattern.compile("(?is)<meta[^>]+(?:property|name)=[\"']" + Pattern.quote(prop) + "[\"'][^>]*content=[\"']([^\"']*)[\"']").matcher(html);
        if (m.find()) return NewsEngine.clean(m.group(1));
        m = Pattern.compile("(?is)<meta[^>]+content=[\"']([^\"']*)[\"'][^>]*(?:property|name)=[\"']" + Pattern.quote(prop) + "[\"']").matcher(html);
        return m.find() ? NewsEngine.clean(m.group(1)) : "";
    }

    static String attr(String tag, String name) {
        Matcher m = Pattern.compile("(?is)\\s" + Pattern.quote(name) + "=[\"']([^\"']*)[\"']").matcher(tag);
        return m.find() ? m.group(1).replace("&amp;", "&").trim() : "";
    }

    static String abs(String src, String base) {
        if (src == null || src.isEmpty()) return "";
        try {
            return new URL(new URL(base), src).toString();
        } catch (Exception e) {
            return src.startsWith("http") ? src : "";
        }
    }

    /** Downloads and decodes a picture, scaled down to about `maxW` pixels wide. */
    public static Bitmap image(String url, int maxW) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(12000);
            c.setReadTimeout(20000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) Chrome/124.0 Mobile");
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            try (InputStream in = c.getInputStream()) {
                byte[] buf = new byte[16384];
                int r, total = 0;
                while ((r = in.read(buf)) > 0) {
                    total += r;
                    if (total > 6_000_000) return null;
                    bo.write(buf, 0, r);
                }
            } finally {
                c.disconnect();
            }
            byte[] b = bo.toByteArray();
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(b, 0, b.length, o);
            int s = 1;
            while (o.outWidth / (s * 2) >= maxW) s *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = s;
            Bitmap bm = BitmapFactory.decodeByteArray(b, 0, b.length, o2);
            return bm != null && bm.getWidth() >= 120 ? bm : null;
        } catch (Exception e) {
            return null;
        }
    }
}
