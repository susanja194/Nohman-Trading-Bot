package com.signal.bot;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * SPOT entry planner for holding periods of 1 day → 2 months.
 * Checks the 1h · 4h · 1d · 1w charts plus the all-exchange money flow, picks the longest horizon whose
 * conditions are met (1–2 din · 1–2 hafte · 1–2 mahine) and builds 4 time-based take-profits
 * (distance grows with √time × daily ATR, snapped below real resistance levels) and a stop for that horizon.
 */
public final class SpotPlan {
    private SpotPlan() {}

    public static final String SHORT = "short", WEEK = "week", MONTH = "month";

    public static final class Plan {
        public boolean ok;
        public String key = "", horizon = "", why = "";
        public final List<String> checks = new ArrayList<>();
        public double zoneLo, zoneHi, sl, waitLevel, atrD;
        public final double[] tp = new double[4];
        public final String[] tpLbl = new String[4];
        public long maxAgeMs;
        public boolean shortOk, weekOk, monthOk;
    }

    static boolean add(Plan p, boolean ok, String s) {
        p.checks.add((ok ? "✅ " : "❌ ") + s);
        return ok;
    }

    public static Plan build(String sym, double price, MarketFlow.Result mf, double sellUsd) throws Exception {
        Plan p = new Plan();
        Candles h1 = Candles.fetch(sym, "1h", 200, true);
        Candles h4 = Candles.fetch(sym, "4h", 200, true);
        Candles d1 = Candles.fetch(sym, "1d", 250, true);
        Candles w1 = null;
        try { w1 = Candles.fetch(sym, "1w", 150, true); } catch (Exception ignored) { }
        if (h4.n < 60 || d1.n < 30) {
            p.why = "Naya coin — data kam, spot plan nahi ban sakta";
            p.checks.add("❌ " + p.why);
            return p;
        }
        double atr1 = Indicators.atr(h1.high, h1.low, h1.close, 14), atr4 = Indicators.atr(h4.high, h4.low, h4.close, 14),
                atrD = Indicators.atr(d1.high, d1.low, d1.close, 14);
        p.atrD = atrD;
        double[] e21h1 = Indicators.ema(h1.close, 21);
        double[] e21h4 = Indicators.ema(h4.close, 21), e50h4 = Indicators.ema(h4.close, 50), rsi4 = Indicators.rsi(h4.close, 14);
        double[] e21d = Indicators.ema(d1.close, 21), e50d = Indicators.ema(d1.close, 50), e200d = Indicators.ema(d1.close, 200), rsiD = Indicators.rsi(d1.close, 14);
        int l1 = h1.n - 1, l4 = h4.n - 1, ld = d1.n - 1;

        // ---- money flow (all exchanges)
        boolean noDump = mf == null || mf.net4h() > -sellUsd;
        if (mf != null) add(p, noDump, "Sab exchanges (" + mf.venues.size() + "): 4 ghante net " + (mf.net4h() >= 0 ? "+" : "−") + Fmt.usd(Math.abs(mf.net4h()))
                + " · 24h " + (mf.net24h() >= 0 ? "+" : "−") + Fmt.usd(Math.abs(mf.net24h())) + (noDump ? " (heavy selling nahi)" : " — HEAVY SELLING"));

        // ---- short swing (1–2 days): 4h trend
        p.checks.add("— 1–2 din (4h chart) —");
        boolean s1 = add(p, price > e50h4[l4] && e21h4[l4] > e50h4[l4], "4h trend upar (price > EMA50, EMA21 > EMA50)");
        boolean s2 = add(p, rsi4[l4] >= 45 && rsi4[l4] <= 70, String.format(Locale.US, "4h RSI %.0f (45–70)", rsi4[l4]));
        double st1 = atr1 > 0 ? (price - e21h1[l1]) / atr1 : 0;
        boolean s3 = add(p, st1 <= 1.8, String.format(Locale.US, "1h EMA21 se %.1f ATR door (≤ 1.8 = mehngi entry nahi)", st1));
        boolean s4 = add(p, price > e50d[ld] || e21d[ld] > e21d[Math.max(0, ld - 3)], "Daily chart bearish nahi");
        p.shortOk = s1 && s2 && s3 && s4 && noDump;

        // ---- week / 2 weeks: daily trend
        p.checks.add("— 1–2 hafte (1d chart) —");
        boolean w1ok = add(p, price > e50d[ld] && (d1.n < 200 || price > e200d[ld] || e50d[ld] > e200d[ld]), "Daily trend upar (EMA50" + (d1.n >= 200 ? "/200" : "") + ")");
        boolean w2 = add(p, rsiD[ld] < 70, String.format(Locale.US, "Daily RSI %.0f (< 70)", rsiD[ld]));
        double st4 = atr4 > 0 ? (price - e21h4[l4]) / atr4 : 0;
        boolean w3 = add(p, st4 <= 1.5, String.format(Locale.US, "4h EMA21 se %.1f ATR door (≤ 1.5)", st4));
        boolean w4 = add(p, price >= e50h4[l4] - 0.5 * atr4, "4h structure (EMA50 ke upar / paas)");
        p.weekOk = w1ok && w2 && w3 && w4 && noDump;

        // ---- month: weekly trend
        p.checks.add("— 1–2 mahine (1w chart) —");
        boolean m1 = false;
        if (w1 != null && w1.n >= 25) {
            double[] e21w = Indicators.ema(w1.close, 21), e50w = Indicators.ema(w1.close, 50), rsiW = Indicators.rsi(w1.close, 14);
            int lw = w1.n - 1;
            boolean a = add(p, price > e21w[lw] && (w1.n < 50 || e21w[lw] > e50w[lw]), "Weekly trend upar (EMA21" + (w1.n >= 50 ? " > EMA50" : "") + ")");
            boolean b = add(p, rsiW[lw] < 72, String.format(Locale.US, "Weekly RSI %.0f (< 72)", rsiW[lw]));
            m1 = a && b;
        } else p.checks.add("➖ Weekly data kam (naya coin)");
        p.monthOk = m1 && p.weekOk;

        p.key = p.monthOk ? MONTH : p.weekOk ? WEEK : p.shortOk ? SHORT : "";
        p.ok = !p.key.isEmpty();
        int[] days;
        String[] lbl;
        double slv, zl;
        switch (p.key) {
            case MONTH:
                days = new int[]{7, 14, 30, 60};
                lbl = new String[]{"1 hafta", "2 hafte", "1 mahina", "2 mahine"};
                p.horizon = "1–2 mahine (long term)";
                p.maxAgeMs = 60L * 86_400_000L;
                slv = Math.min(price - 2.5 * atrD, swingLow(d1, 20) - 0.3 * atrD);
                zl = Math.max(e21d[ld] - 0.3 * atrD, price - 1.0 * atrD);
                break;
            case WEEK:
                days = new int[]{2, 7, 14, 30};
                lbl = new String[]{"2 din", "1 hafta", "2 hafte", "1 mahina"};
                p.horizon = "1–2 hafte";
                p.maxAgeMs = 30L * 86_400_000L;
                slv = Math.min(price - 1.5 * atrD, swingLow(d1, 10) - 0.2 * atrD);
                zl = Math.max(e21h4[l4] - 0.3 * atr4, price - 1.2 * atr4);
                break;
            default:
                days = new int[]{1, 2, 7, 14};
                lbl = new String[]{"1 din", "2 din", "1 hafta", "2 hafte"};
                p.horizon = "1–2 din (short swing)";
                p.maxAgeMs = 14L * 86_400_000L;
                slv = Math.min(price - 1.0 * atrD, swingLow(h4, 12) - 0.2 * atr4);
                zl = Math.max(e21h1[l1] - 0.3 * atr1, price - 1.2 * atr1);
        }
        p.sl = slv > 0 ? slv : price * 0.85;
        p.zoneLo = Math.min(zl, price);
        p.zoneHi = price;
        // resistance levels above price (daily swing highs + weekly)
        List<Double> res = new ArrayList<>();
        swingHighs(d1, price, res);
        if (w1 != null) swingHighs(w1, price, res);
        double prev = price;
        for (int k = 0; k < 4; k++) {
            double t = price + 0.75 * atrD * Math.sqrt(days[k]);
            for (double r : res) if (r > prev * 1.003 && r >= t * 0.85 && r <= t * 1.1) { t = Math.min(t, r * 0.995); break; }
            t = Math.max(t, prev + 0.3 * atrD);
            p.tp[k] = t;
            p.tpLbl[k] = lbl[k];
            prev = t;
        }
        if (p.ok) {
            p.why = "Achhi spot entry — " + p.horizon + ": trend, RSI aur money flow saath hain";
        } else {
            p.waitLevel = e21h4[l4];
            p.why = !noDump ? "Heavy selling chal rahi — abhi BUY nahi"
                    : st4 > 1.5 || st1 > 1.8 ? "Price bahut upar nikal chuki — $" + Fmt.price(e21h4[l4]) + " (4h EMA21) tak pullback ka intezar"
                    : "Trend ab tak spot BUY ke qabil nahi";
        }
        return p;
    }

    static double swingLow(Candles c, int bars) {
        double lo = Double.MAX_VALUE;
        for (int i = Math.max(0, c.n - bars); i < c.n; i++) lo = Math.min(lo, c.low[i]);
        return lo == Double.MAX_VALUE ? 0 : lo;
    }

    static void swingHighs(Candles c, double above, List<Double> out) {
        for (int i = 2; i < c.n - 2; i++) {
            double h = c.high[i];
            if (h > above && h >= c.high[i - 1] && h >= c.high[i - 2] && h >= c.high[i + 1] && h >= c.high[i + 2]) out.add(h);
        }
        java.util.Collections.sort(out);
    }
}
