package com.signal.bot;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.TimeZone;

/**
 * In-app updates: checks the latest GitHub release of the app's repo and installs the new APK
 * directly (Android's PackageInstaller). Works because every build is signed with the same key.
 */
public final class UpdateManager {
    private UpdateManager() {}

    public interface Progress {
        void on(int percent);
    }

    public static final class Info {
        public String url, notes, title;
        public long time, size;
    }

    public static Info latest(Context c) throws Exception {
        String repo = Prefs.updateRepo(c);
        JSONObject o = new JSONObject(Scanner.getAbsolute("https://api.github.com/repos/" + repo + "/releases/latest"));
        JSONArray assets = o.getJSONArray("assets");
        for (int i = 0; i < assets.length(); i++) {
            JSONObject a = assets.getJSONObject(i);
            if (!a.optString("name").toLowerCase(Locale.US).endsWith(".apk")) continue;
            Info in = new Info();
            in.url = a.optString("browser_download_url");
            in.size = a.optLong("size");
            in.time = iso(a.optString("updated_at"));
            in.title = o.optString("name");
            in.notes = o.optString("body");
            return in;
        }
        throw new Exception("Release mein APK nahi mili");
    }

    /** Returns the release if it is newer than the installed app, else null. */
    public static Info check(Context c) throws Exception {
        Info in = latest(c);
        long installed = c.getPackageManager().getPackageInfo(c.getPackageName(), 0).lastUpdateTime;
        Prefs.setLastUpdateCheck(c, System.currentTimeMillis());
        return in.time > installed + 3 * 60_000L ? in : null;
    }

    static long iso(String s) {
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            return f.parse(s.substring(0, 19)).getTime();
        } catch (Exception e) {
            return 0;
        }
    }

    public static boolean canInstall(Context c) {
        return c.getPackageManager().canRequestPackageInstalls();
    }

    /** Downloads the APK into an install session and asks Android to install it (user taps "Update"). */
    public static void install(Context c, Info in, Progress p) throws Exception {
        PackageInstaller pi = c.getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        params.setAppPackageName(c.getPackageName());
        int id = pi.createSession(params);
        PackageInstaller.Session s = pi.openSession(id);
        try {
            HttpURLConnection con = (HttpURLConnection) new URL(in.url).openConnection();
            con.setInstanceFollowRedirects(true);
            con.setConnectTimeout(20000);
            con.setReadTimeout(60000);
            con.setRequestProperty("User-Agent", "ParaDox-Updater");
            int code = con.getResponseCode();
            if (code != 200) throw new Exception("Download nahi hua (HTTP " + code + ")");
            long len = con.getContentLengthLong();
            if (len <= 0) len = in.size;
            try (InputStream is = con.getInputStream(); OutputStream os = s.openWrite("update.apk", 0, len > 0 ? len : -1)) {
                byte[] buf = new byte[65536];
                long done = 0;
                int r, last = -1;
                while ((r = is.read(buf)) > 0) {
                    os.write(buf, 0, r);
                    done += r;
                    if (len > 0 && p != null) {
                        int pct = (int) (done * 100 / len);
                        if (pct != last) { last = pct; p.on(pct); }
                    }
                }
                s.fsync(os);
            } finally {
                con.disconnect();
            }
            Intent cb = new Intent(c, UpdateReceiver.class);
            PendingIntent pin = PendingIntent.getBroadcast(c, 4242, cb,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
            s.commit(pin.getIntentSender());
        } catch (Exception e) {
            s.abandon();
            throw e;
        } finally {
            s.close();
        }
    }
}
