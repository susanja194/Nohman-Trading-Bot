package com.signal.bot;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Free gold / commodity / forex candles from Yahoo Finance's public chart API (no key).
 * Hosts query1 / query2 are tried in turn. Gold falls back to Binance PAXGUSDT (1 PAXG = 1 oz gold).
 */
public final class YahooData {
    private YahooData() {}

    private static final String[] HOSTS = {"https://query1.finance.yahoo.com", "https://query2.finance.yahoo.com"};

    public static final class Quote {
        public double price, prevClose, change;
        public long time;
    }

    private static final Map<String, Quote> CACHE = new HashMap<>();
    private static final Map<String, Long> CACHE_T = new HashMap<>();

    /** Yahoo interval + range for our timeframe names. */
    static String[] map(String tf) {
        switch (tf) {
            case "5m": return new String[]{"5m", "5d"};
            case "15m": return new String[]{"15m", "1mo"};
            case "30m": return new String[]{"30m", "1mo"};
            case "1h": return new String[]{"60m", "3mo"};
            case "4h": return new String[]{"60m", "6mo"};   // aggregated below
            case "1w": return new String[]{"1wk", "10y"};
            case "1M": return new String[]{"1mo", "max"};
            case "1Y": return new String[]{"1d", "1y"};
            case "2Y": return new String[]{"1d", "2y"};
            case "3Y": case "4Y": case "5Y": return new String[]{"1wk", "5y"};
            case "ALL": return new String[]{"1mo", "max"};
            default: return new String[]{"1d", "2y"};
        }
    }

    static String raw(String sym, String interval, String range) throws Exception {
        Exception last = new Exception("Yahoo tak pohanch nahi ho rahi");
        String enc = java.net.URLEncoder.encode(sym, "UTF-8");
        for (String h : HOSTS) {
            try {
                return Scanner.getAbsolute(h + "/v8/finance/chart/" + enc + "?interval=" + interval + "&range=" + range + "&includePrePost=false");
            } catch (Exception e) { last = e; }
        }
        throw last;
    }

    /** Parse a Yahoo v8 chart response into candles (null rows skipped). */
    public static Candles parse(String json) throws Exception {
        JSONObject res = new JSONObject(json).getJSONObject("chart").getJSONArray("result").getJSONObject(0);
        JSONArray ts = res.optJSONArray("timestamp");
        if (ts == null) return Candles.create(0);
        JSONObject q = res.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0);
        JSONArray o = q.optJSONArray("open"), h = q.optJSONArray("high"), l = q.optJSONArray("low"),
                c = q.optJSONArray("close"), v = q.optJSONArray("volume");
        int n = ts.length(), good = 0;
        boolean[] ok = new boolean[n];
        for (int i = 0; i < n; i++) {
            ok[i] = c != null && !c.isNull(i) && o != null && !o.isNull(i) && h != null && !h.isNull(i) && l != null && !l.isNull(i)
                    && c.optDouble(i, 0) > 0;
            if (ok[i]) good++;
        }
        Candles out = Candles.create(good);
        int k = 0;
        for (int i = 0; i < n; i++) {
            if (!ok[i]) continue;
            out.time[k] = ts.getLong(i) * 1000L;
            out.open[k] = o.getDouble(i);
            out.high[k] = h.getDouble(i);
            out.low[k] = l.getDouble(i);
            out.close[k] = c.getDouble(i);
            double vol = v != null && !v.isNull(i) ? v.optDouble(i, 0) : 0;
            out.vol[k] = vol;
            out.takerBuy[k] = vol / 2;
            out.quoteVol[k] = vol * out.close[k];
            out.takerBuyQuote[k] = out.quoteVol[k] / 2;
            k++;
        }
        return out;
    }

    /** Merge every `group` candles into one (used to build 4h from 1h). */
    static Candles group(Candles c, int group) {
        int m = c.n / group;
        Candles x = Candles.create(m);
        int start = c.n - m * group;
        for (int j = 0; j < m; j++) {
            int a = start + j * group;
            x.time[j] = c.time[a];
            x.open[j] = c.open[a];
            double hi = c.high[a], lo = c.low[a], v = 0;
            for (int i = a; i < a + group; i++) { hi = Math.max(hi, c.high[i]); lo = Math.min(lo, c.low[i]); v += c.vol[i]; }
            x.high[j] = hi; x.low[j] = lo; x.close[j] = c.close[a + group - 1];
            x.vol[j] = v; x.takerBuy[j] = v / 2; x.quoteVol[j] = v * x.close[j]; x.takerBuyQuote[j] = x.quoteVol[j] / 2;
        }
        return x;
    }

    private static final Map<String, Candles> C_CACHE = new HashMap<>();
    private static final Map<String, Long> C_T = new HashMap<>();

    /** Candles for a Yahoo symbol (cached 2 min). closedOnly drops the forming candle. */
    public static Candles fetch(String sym, String tf, boolean closedOnly) throws Exception {
        String key = sym + "|" + tf + "|" + closedOnly;
        synchronized (C_CACHE) {
            Long t = C_T.get(key);
            if (t != null && System.currentTimeMillis() - t < 120_000L) return C_CACHE.get(key);
        }
        Candles c = load(sym, tf, closedOnly);
        synchronized (C_CACHE) {
            C_CACHE.put(key, c);
            C_T.put(key, System.currentTimeMillis());
        }
        return c;
    }

    private static Candles load(String sym, String tf, boolean closedOnly) throws Exception {
        Candles c;
        try {
            String[] m = map(tf);
            c = parse(raw(sym, m[0], m[1]));
            if ("4h".equals(tf)) c = group(c, 4);
            if ("3Y".equals(tf)) c = last(c, 157);
            if ("4Y".equals(tf)) c = last(c, 209);
        } catch (Exception e) {
            if (!"GC=F".equals(sym)) throw e;
            String btf = tf.equals("1w") ? "1w" : tf;   // PAXG backup for gold
            c = Candles.fetch("PAXGUSDT", ChartRange.interval(btf), Math.min(1000, Math.max(300, ChartRange.limit(btf))), false);
        }
        if (closedOnly && c.n > 1) c = drop(c);
        return c;
    }

    static Candles last(Candles c, int k) {
        if (c.n <= k) return c;
        Candles x = Candles.create(k);
        int o = c.n - k;
        System.arraycopy(c.time, o, x.time, 0, k);
        System.arraycopy(c.open, o, x.open, 0, k);
        System.arraycopy(c.high, o, x.high, 0, k);
        System.arraycopy(c.low, o, x.low, 0, k);
        System.arraycopy(c.close, o, x.close, 0, k);
        System.arraycopy(c.vol, o, x.vol, 0, k);
        System.arraycopy(c.takerBuy, o, x.takerBuy, 0, k);
        System.arraycopy(c.quoteVol, o, x.quoteVol, 0, k);
        System.arraycopy(c.takerBuyQuote, o, x.takerBuyQuote, 0, k);
        return x;
    }

    static Candles drop(Candles c) {
        Candles x = Candles.create(c.n - 1);
        System.arraycopy(c.time, 0, x.time, 0, x.n);
        System.arraycopy(c.open, 0, x.open, 0, x.n);
        System.arraycopy(c.high, 0, x.high, 0, x.n);
        System.arraycopy(c.low, 0, x.low, 0, x.n);
        System.arraycopy(c.close, 0, x.close, 0, x.n);
        System.arraycopy(c.vol, 0, x.vol, 0, x.n);
        System.arraycopy(c.takerBuy, 0, x.takerBuy, 0, x.n);
        System.arraycopy(c.quoteVol, 0, x.quoteVol, 0, x.n);
        System.arraycopy(c.takerBuyQuote, 0, x.takerBuyQuote, 0, x.n);
        return x;
    }

    /** Latest price + day change (cached 60 s). */
    public static Quote quote(String sym) throws Exception {
        synchronized (CACHE) {
            Long t = CACHE_T.get(sym);
            if (t != null && System.currentTimeMillis() - t < 12_000) return CACHE.get(sym);
        }
        Quote q = new Quote();
        try {
            JSONObject res = new JSONObject(raw(sym, "5m", "1d")).getJSONObject("chart").getJSONArray("result").getJSONObject(0);
            JSONObject meta = res.getJSONObject("meta");
            q.price = meta.optDouble("regularMarketPrice", 0);
            q.prevClose = meta.optDouble("chartPreviousClose", meta.optDouble("previousClose", 0));
            q.time = meta.optLong("regularMarketTime", 0) * 1000L;
        } catch (Exception e) {
            if (!"GC=F".equals(sym)) throw e;
            JSONObject o = new JSONObject(Scanner.get("/api/v3/ticker/24hr?symbol=PAXGUSDT"));
            q.price = o.getDouble("lastPrice");
            q.prevClose = o.getDouble("openPrice");
            q.time = System.currentTimeMillis();
        }
        q.change = q.prevClose > 0 ? (q.price / q.prevClose - 1) * 100 : 0;
        synchronized (CACHE) { CACHE.put(sym, q); CACHE_T.put(sym, System.currentTimeMillis()); }
        return q;
    }
}
