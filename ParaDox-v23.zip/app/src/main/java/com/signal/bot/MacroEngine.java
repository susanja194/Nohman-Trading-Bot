package com.signal.bot;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * US macro / Fed calendar for crypto traders:
 *  - Schedule + forecast + previous: ForexFactory weekly feed (this week + next week)
 *  - Official FOMC decision dates (2026-27) and minutes (3 weeks later) as a built-in fallback
 *  - ACTUAL numbers after release: FRED (St. Louis Fed) public CSV, no key
 *  - Market reaction: BTC move in the 5 minutes after the release (Binance)
 *  - Macro pulse: Fed funds rate, 10Y yield, dollar index (FRED), Fed speeches (federalreserve.gov RSS)
 * Every event comes with "what it is" and "what higher / lower means for crypto".
 */
public final class MacroEngine {
    private MacroEngine() {}

    // ------------------------------------------------------------------ knowledge base
    public static final class Info {
        public final String key, urdu, what, ifHigher, ifLower, fred;
        public final int sign;   // +1 higher number is GOOD for crypto, -1 BAD, 0 mixed
        public final int calc;   // 0 level · 1 m/m % of index · 2 monthly difference (K) · 3 level/1000 (K) · 4 level/1000 (M) · 5 y/y %

        Info(String key, String urdu, String what, String ifHigher, String ifLower, int sign, String fred, int calc) {
            this.key = key; this.urdu = urdu; this.what = what; this.ifHigher = ifHigher; this.ifLower = ifLower;
            this.sign = sign; this.fred = fred; this.calc = calc;
        }
    }

    static Info info(String title) {
        String t = title.toLowerCase(Locale.US);
        boolean core = t.contains("core");
        if (t.contains("federal funds rate") || t.contains("fomc statement") || t.contains("interest rate decision"))
            return new Info("FED_RATE", "Fed ka interest rate faisla (FOMC)",
                    "Fed rates barhayega (hike), ghatayega (cut) ya wahi rakhega. Crypto ke liye sab se bada event.",
                    "Rate zyada / hike = dollar mazboot, sasta paisa band → crypto par PRESSURE 🔴",
                    "Rate cut = sasta paisa, liquidity → crypto ko SUPPORT 🟢", -1, "DFEDTARU", 0);
        if (t.contains("press conference") || (t.contains("fed chair") && t.contains("speak")))
            return new Info("FED_SPEECH", "Fed Chair ki speech / press conference",
                    "Agay rate cut hoga ya hike? Chair ki baaton se market andaza lagati hai.",
                    "Hawkish (sakht, rates high) = crypto par PRESSURE 🔴",
                    "Dovish (narm, cut ka ishara) = crypto ko SUPPORT 🟢", 0, null, 0);
        if (t.contains("minutes"))
            return new Info("MINUTES", "FOMC Minutes", "Fed members ki andarooni discussion (meeting ke 3 hafte baad).",
                    "Zyada members rates high rakhna chahein (hawkish) = PRESSURE 🔴",
                    "Zyada members cut ki baat karein (dovish) = SUPPORT 🟢", 0, null, 0);
        if (t.contains("cpi"))
            return new Info("CPI", core ? "Core CPI (khana/fuel ke baghair mehngai)" : "CPI inflation (mehngai)",
                    "Mehngai kitni hai? Fed isi ko dekh kar rates ka faisla karta hai.",
                    "Inflation ZYADA = rate cut door → crypto 🔴 BEARISH",
                    "Inflation KAM = rate cut ki umeed → crypto 🟢 BULLISH", -1,
                    core ? "CPILFESL" : "CPIAUCSL", t.contains("y/y") ? 5 : 1);
        if (t.contains("pce"))
            return new Info("PCE", core ? "Core PCE (Fed ka pasandeeda inflation measure)" : "PCE inflation",
                    "Fed ka pasandeeda inflation measure.",
                    "PCE ZYADA = rates high rehne ka risk → 🔴",
                    "PCE KAM = rate cuts ki umeed barh sakti hai → 🟢", -1,
                    core ? "PCEPILFE" : "PCEPI", t.contains("y/y") ? 5 : 1);
        if (t.contains("ppi"))
            return new Info("PPI", "PPI (factory / producer mehngai)", "Producers ki qeematein — aage CPI ka ishara.",
                    "PPI zyada = aage mehngai → 🔴", "PPI kam = mehngai thandi → 🟢", -1, core ? null : "PPIFIS", 1);
        if (t.contains("adp"))
            return new Info("ADP", "ADP private jobs (NFP se pehle ishara)", "Private companies mein kitni jobs bani.",
                    "Bohat strong jobs = rates ka risk → 🔴", "Kamzor jobs = cut ki umeed → 🟢", -1, null, 0);
        if (t.contains("non-farm") || t.contains("nonfarm") || t.contains("payroll"))
            return new Info("NFP", "NFP / Jobs Report", "US mein kitni nayi jobs add hui?",
                    "Bohat STRONG jobs = inflation/rates ka risk → 🔴",
                    "KAMZOR jobs = rate cut ki umeed → 🟢 (lekin bahut kamzor = recession ka dar)", -1, "PAYEMS", 2);
        if (t.contains("unemployment claims") || t.contains("jobless claims"))
            return new Info("CLAIMS", "Jobless Claims (har Jumeraat)", "Is hafte kitne logon ne berozgari allowance manga.",
                    "Claims ZYADA = jobs kamzor = cut ki umeed → 🟢", "Claims KAM = jobs mazboot = rates high → 🔴", 1, "ICSA", 3);
        if (t.contains("unemployment rate"))
            return new Info("UNEMP", "Unemployment Rate (berozgari)", "Jobs market mazboot hai ya kamzor?",
                    "Berozgari ZYADA = rate cut ki umeed (lekin economy kamzor) → mixed/🟢",
                    "Berozgari KAM = jobs mazboot = rates high rehne ka risk → mixed/🔴", 1, "UNRATE", 0);
        if (t.contains("gdp"))
            return new Info("GDP", "GDP (US economy ki growth)", "US economy kitni grow kar rahi hai? Growth aur inflation dono dekhne hote hain.",
                    "Strong growth = risk-on, lekin rates high reh sakte hain → mixed",
                    "Kamzor growth = recession dar, magar rate cut ki umeed → mixed", 0, "A191RL1Q225SBEA", 0);
        if (t.contains("retail sales"))
            return new Info("RETAIL", core ? "Core Retail Sales" : "Retail Sales", "American consumers kitna kharch kar rahe hain?",
                    "Strong spending = rates high rehne ka risk → 🔴", "Kam kharch = cut ki umeed (economy slow) → 🟢", -1,
                    core ? null : "RSAFS", 1);
        if (t.contains("jolts"))
            return new Info("JOLTS", "JOLTS (khaali jobs)", "Companies ke paas kitni khaali jobs hain.",
                    "Zyada openings = jobs garam = rates risk → 🔴", "Kam openings = cut ki umeed → 🟢", -1, "JTSJOL", 4);
        if (t.contains("ism"))
            return new Info("ISM", t.contains("services") ? "ISM Services PMI" : "ISM Manufacturing PMI",
                    "Factories / services ki sehat (50 se upar = barh rahi, neeche = sukar rahi).",
                    "Zyada = economy mazboot (risk-on) magar prices paid se mehngai ka dar → mixed",
                    "Kam = slowdown, cut ki umeed → mixed", 0, null, 0);
        if (t.contains("consumer sentiment") || t.contains("consumer confidence"))
            return new Info("SENTIMENT", "Consumer sentiment / confidence", "Log economy ke baare mein kitne pur-umeed hain.",
                    "Zyada confidence = risk-on → 🟢", "Kam confidence = risk-off → 🔴", 1, null, 0);
        if (t.contains("fomc member") || t.contains("fed") && t.contains("speak"))
            return new Info("FED_SPEAKER", "Fed member ki taqreer", "Fed ke kisi member ki baat — rates ka ishara.",
                    "Hawkish = 🔴", "Dovish = 🟢", 0, null, 0);
        return new Info("OTHER", title, "US economic data", "Forecast se behtar = USD mazboot", "Forecast se kamzor = USD kamzor", 0, null, 0);
    }

    // ------------------------------------------------------------------ events
    public static final class Event {
        public String id, title, impact, forecast = "", previous = "", actual = "", verdict = "", expectation = "";
        public long time;
        public Info info;
        public double reaction = Double.NaN;   // BTC % move 5 min after release
        public int verdictSign;                 // +1 bullish crypto, -1 bearish, 0 neutral
        public boolean official;                // from built-in FOMC schedule
    }

    /** FOMC decision days (2:00 PM New York). Source: Federal Reserve schedule. */
    static final String[] FOMC = {"2026-01-28", "2026-03-18", "2026-04-29", "2026-06-17", "2026-07-29", "2026-09-16",
            "2026-10-28", "2026-12-09", "2027-01-27", "2027-03-17", "2027-04-28", "2027-06-09", "2027-07-28",
            "2027-09-15", "2027-10-27", "2027-12-08"};

    static long nyTime(String date, int hour, int min) {
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("America/New_York"));
            return f.parse(date + " " + String.format(Locale.US, "%02d:%02d", hour, min)).getTime();
        } catch (Exception e) {
            return 0;
        }
    }

    public static long nextFomc() {
        long now = System.currentTimeMillis();
        for (String d : FOMC) {
            long t = nyTime(d, 14, 0);
            if (t > now - 3 * 3600_000L) return t;
        }
        return 0;
    }

    private static volatile List<Event> cache;
    private static volatile long cacheAt;

    /** USD events for this + next week (cached 1 hour), merged with the official FOMC schedule. */
    public static List<Event> calendar(Context c, boolean force) {
        if (!force && cache != null && System.currentTimeMillis() - cacheAt < 3600_000L) return cache;
        List<Event> out = new ArrayList<>();
        for (String week : new String[]{"thisweek", "nextweek"}) {
            String raw = null;
            try {
                raw = Scanner.getAbsolute("https://nfs.faireconomy.media/ff_calendar_" + week + ".json");
                if (c != null) Prefs.putStr(c, "ffcal_" + week, raw);
            } catch (Exception e) {
                if (c != null) raw = Prefs.getStr(c, "ffcal_" + week, null);
            }
            if (raw == null) continue;
            try {
                JSONArray a = new JSONArray(raw);
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    if (!"USD".equals(o.optString("country"))) continue;
                    String imp = o.optString("impact");
                    if (!imp.equals("High") && !imp.equals("Medium")) continue;
                    Event e = new Event();
                    e.title = o.optString("title");
                    e.impact = imp;
                    e.time = iso(o.optString("date"));
                    e.forecast = o.optString("forecast", "");
                    e.previous = o.optString("previous", "");
                    e.actual = o.optString("actual", "");
                    e.id = e.title + "@" + e.time;
                    e.info = info(e.title);
                    if (e.time > 0) out.add(e);
                }
            } catch (Exception ignored) {
            }
        }
        // official FOMC days + minutes (decision + 21 days) for the next ~10 weeks, if the feed did not have them
        long now = System.currentTimeMillis();
        for (String d : FOMC) {
            long t = nyTime(d, 14, 0);
            addOfficial(out, t, "Federal Funds Rate", now);
            addOfficial(out, t + 30 * 60_000L, "FOMC Press Conference", now);
            addOfficial(out, t + 21 * 86_400_000L, "FOMC Meeting Minutes", now);
        }
        Collections.sort(out, (a, b) -> Long.compare(a.time, b.time));
        if (c != null) applyStored(c, out);
        for (Event e : out) expectation(e);
        cache = out;
        cacheAt = System.currentTimeMillis();
        return out;
    }

    private static void addOfficial(List<Event> out, long t, String title, long now) {
        if (t < now - 7 * 86_400_000L || t > now + 70 * 86_400_000L) return;
        String key = title.toLowerCase(Locale.US).contains("minutes") ? "minutes" : title.toLowerCase(Locale.US).contains("press") ? "press" : "rate";
        for (Event e : out) {
            String tl = e.title.toLowerCase(Locale.US);
            boolean same = key.equals("minutes") ? tl.contains("minutes") : key.equals("press") ? tl.contains("press") : (tl.contains("funds rate") || tl.contains("fomc statement"));
            if (same && Math.abs(e.time - t) < 2 * 86_400_000L) return;
        }
        Event e = new Event();
        e.title = title;
        e.impact = "High";
        e.time = t;
        e.official = true;
        e.id = title + "@" + t;
        e.info = info(title);
        out.add(e);
    }

    static long iso(String s) {
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US);
            return f.parse(s).getTime();
        } catch (Exception e) {
            return 0;
        }
    }

    private static final Pattern NUM = Pattern.compile("(-?\\d+(?:\\.\\d+)?)\\s*([KMB%]?)");

    /** "0.3%" -> 0.3 · "150K" -> 150 · "7.20M" -> 7.2 · "" -> NaN */
    static double num(String s) {
        if (s == null) return Double.NaN;
        Matcher m = NUM.matcher(s.replace(",", ""));
        if (!m.find()) return Double.NaN;
        try {
            return Double.parseDouble(m.group(1));
        } catch (Exception e) {
            return Double.NaN;
        }
    }

    /** Pre-release: what the market expects (forecast vs previous). */
    static void expectation(Event e) {
        double f = num(e.forecast), p = num(e.previous);
        Info in = e.info;
        if (in.key.equals("FED_RATE")) {
            e.expectation = "Rate ka faisla — hold, cut ya hike. Cut = 🟢 support · hike = 🔴 pressure · hold = Chair ki baaton par depend";
        } else if (in.key.equals("FED_SPEECH") || in.key.equals("FED_SPEAKER") || in.key.equals("MINUTES")) {
            e.expectation = "Tone dekhni hai: dovish (narm) = 🟢 · hawkish (sakht) = 🔴";
        } else if (!Double.isNaN(f) && !Double.isNaN(p)) {
            if (Math.abs(f - p) < 1e-9) e.expectation = "Market pichli jaisi figure ki umeed kar rahi hai (" + e.forecast + ")";
            else {
                boolean up = f > p;
                String dir = up ? "barhne" : "ghatne";
                String eff = in.sign == 0 ? "mixed asar" : ((up ? in.sign : -in.sign) > 0 ? "crypto ke liye achha 🟢" : "crypto ke liye bura 🔴");
                e.expectation = "Umeed: " + e.previous + " se " + e.forecast + " ki taraf " + dir + " ki — agar aisa hua to " + eff;
            }
        } else {
            e.expectation = "Forecast maloom nahi — release ke baad asar dekhen";
        }
    }

    /** Post-release verdict from actual vs forecast (or previous). */
    static void verdict(Event e) {
        double a = num(e.actual), f = num(e.forecast);
        if (Double.isNaN(f)) f = num(e.previous);
        if (Double.isNaN(a) || Double.isNaN(f)) return;
        double diff = a - f;
        double tol = Math.max(Math.abs(f) * 0.03, e.info.calc == 1 || e.info.calc == 0 ? 0.05 : 1e-9);
        if (Math.abs(diff) <= tol) {
            e.verdictSign = 0;
            e.verdict = "Umeed ke mutabiq (" + e.actual + " vs forecast " + (e.forecast.isEmpty() ? e.previous : e.forecast) + ") — asar kam";
            return;
        }
        boolean higher = diff > 0;
        int s = e.info.sign == 0 ? 0 : ((higher ? e.info.sign : -e.info.sign) > 0 ? 1 : -1);
        e.verdictSign = s;
        e.verdict = (higher ? "Forecast se ZYADA aaya" : "Forecast se KAM aaya") + " (" + e.actual + " vs " + (e.forecast.isEmpty() ? e.previous : e.forecast) + ") → "
                + (s > 0 ? "crypto ke liye 🟢 BULLISH" : s < 0 ? "crypto ke liye 🔴 BEARISH" : "mixed asar") + " · " + (higher ? e.info.ifHigher : e.info.ifLower);
    }

    // ------------------------------------------------------------------ FRED actuals
    /** {latest observation date, computed value} from FRED, or null. */
    static String[] fred(Info in) {
        if (in.fred == null) return null;
        try {
            String csv = Scanner.getAbsolute("https://fred.stlouisfed.org/graph/fredgraph.csv?id=" + in.fred);
            String[] lines = csv.trim().split("\n");
            List<String[]> rows = new ArrayList<>();
            for (int i = 1; i < lines.length; i++) {
                String[] p = lines[i].trim().split(",");
                if (p.length < 2 || p[1].equals(".") || p[1].isEmpty()) continue;
                rows.add(p);
            }
            int n = rows.size();
            if (n < 13) return null;
            double v = Double.parseDouble(rows.get(n - 1)[1]), prev = Double.parseDouble(rows.get(n - 2)[1]);
            String val;
            switch (in.calc) {
                case 1: val = String.format(Locale.US, "%.1f%%", (v / prev - 1) * 100); break;
                case 2: val = String.format(Locale.US, "%.0fK", v - prev); break;
                case 3: val = String.format(Locale.US, "%.0fK", v / 1000); break;
                case 4: val = String.format(Locale.US, "%.2fM", v / 1000); break;
                case 5: val = String.format(Locale.US, "%.1f%%", (v / Double.parseDouble(rows.get(n - 13)[1]) - 1) * 100); break;
                default: val = in.fred.equals("DFEDTARU") ? String.format(Locale.US, "%.2f%%", v) : String.format(Locale.US, "%.1f%%", v);
            }
            return new String[]{rows.get(n - 1)[0], val};
        } catch (Exception e) {
            return null;
        }
    }

    /** Latest numeric value and change over N observations for a FRED series: {last, change}. */
    static double[] fredLevel(String id, int back) {
        try {
            String csv = Scanner.getAbsolute("https://fred.stlouisfed.org/graph/fredgraph.csv?id=" + id);
            String[] lines = csv.trim().split("\n");
            List<Double> v = new ArrayList<>();
            for (int i = 1; i < lines.length; i++) {
                String[] p = lines[i].trim().split(",");
                if (p.length < 2 || p[1].equals(".") || p[1].isEmpty()) continue;
                v.add(Double.parseDouble(p[1]));
            }
            if (v.size() <= back) return null;
            double last = v.get(v.size() - 1);
            return new double[]{last, last - v.get(v.size() - 1 - back)};
        } catch (Exception e) {
            return null;
        }
    }

    /** BTC % move in the first 5 minutes after t. NaN if not available yet. */
    static double btcReaction(long t) {
        if (System.currentTimeMillis() < t + 5 * 60_000L) return Double.NaN;
        try {
            JSONArray a = new JSONArray(Scanner.get("/api/v3/klines?symbol=BTCUSDT&interval=1m&startTime=" + t + "&limit=5"));
            if (a.length() < 5) return Double.NaN;
            double o = Double.parseDouble(a.getJSONArray(0).getString(1));
            double c = Double.parseDouble(a.getJSONArray(4).getString(4));
            return o > 0 ? (c / o - 1) * 100 : Double.NaN;
        } catch (Exception e) {
            return Double.NaN;
        }
    }

    // ------------------------------------------------------------------ stored state (actuals, reactions, notifications)
    private static JSONObject state(Context c) {
        try {
            return new JSONObject(Prefs.getStr(c, "macrostate", "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private static void saveState(Context c, JSONObject s) {
        // keep the state small: drop entries older than 21 days
        try {
            JSONObject out = new JSONObject();
            java.util.Iterator<String> it = s.keys();
            long cut = System.currentTimeMillis() - 21 * 86_400_000L;
            while (it.hasNext()) {
                String k = it.next();
                JSONObject v = s.optJSONObject(k);
                if (v != null && v.optLong("t", 0) < cut) continue;
                out.put(k, s.get(k));
            }
            Prefs.putStr(c, "macrostate", out.toString());
        } catch (Exception ignored) {
        }
    }

    private static void applyStored(Context c, List<Event> evs) {
        JSONObject st = state(c);
        for (Event e : evs) {
            JSONObject o = st.optJSONObject(e.id);
            if (o == null) continue;
            if (e.actual.isEmpty()) e.actual = o.optString("actual", "");
            if (o.has("react")) e.reaction = o.optDouble("react", Double.NaN);
        }
        for (Event e : evs) if (!e.actual.isEmpty()) verdict(e);
    }

    /**
     * Called by the background service every few minutes: reminders before high-impact events,
     * the BTC reaction 5 min after, and the actual number (from FRED) with a bullish/bearish verdict.
     */
    public static void tick(Context c) {
        List<Event> evs = calendar(c, false);
        JSONObject st = state(c);
        long now = System.currentTimeMillis();
        int lead = Prefs.macroLeadMin(c);
        boolean changed = false;
        for (Event e : evs) {
            boolean high = "High".equals(e.impact);
            if (!high && !Prefs.macroMedium(c)) continue;
            JSONObject o = st.optJSONObject(e.id);
            if (o == null) o = new JSONObject();
            try {
                o.put("t", e.time);
                long dt = e.time - now;
                // 1) reminder before
                if (dt > 0 && dt <= lead * 60_000L && !o.optBoolean("pre")) {
                    o.put("pre", true);
                    if (e.info.fred != null) {
                        String[] f = fred(e.info);
                        if (f != null) o.put("fredDate", f[0]);
                    }
                    String body = e.info.urdu + "\n" + (e.forecast.isEmpty() ? "" : "Forecast " + e.forecast + " · pichla " + e.previous + "\n")
                            + e.expectation + "\n⚠️ Is waqt volatility zyada hogi — SL tight rakhen ya intezar karein.";
                    Notify.show(c, Prefs.N_MACRO, 8000 + (e.id.hashCode() & 0x3FF), "⏰ " + mins(dt) + " baad: " + e.title, body,
                            0xFFFFC94D, MainActivity.TAB_LISTINGS);
                    changed = true;
                }
                // 2) BTC reaction 5 minutes after release
                if (dt < -5 * 60_000L && dt > -3 * 3600_000L && !o.has("react")) {
                    double r = btcReaction(e.time);
                    if (!Double.isNaN(r)) {
                        o.put("react", r);
                        e.reaction = r;
                        Notify.show(c, Prefs.N_MACRO, 8400 + (e.id.hashCode() & 0x3FF), "📊 " + e.title + " ke baad BTC",
                                String.format(Locale.US, "Release ke 5 minute mein BTC %+.2f%% %s", r,
                                        r > 0.3 ? "— market ne achha liya 🟢" : r < -0.3 ? "— market ne bura liya 🔴" : "— khaas asar nahi"),
                                r >= 0 ? 0xFF0ECB81 : 0xFFF6465D, MainActivity.TAB_LISTINGS);
                        changed = true;
                    }
                }
                // 3) actual number from FRED (poll for up to 8 hours after release)
                if (dt < 0 && dt > -8 * 3600_000L && e.info.fred != null && !o.has("actual") && e.actual.isEmpty()) {
                    long lastPoll = o.optLong("poll", 0);
                    if (now - lastPoll > 10 * 60_000L) {
                        o.put("poll", now);
                        String[] f = fred(e.info);
                        String before = o.optString("fredDate", "");
                        if (f != null && !before.isEmpty() && !f[0].equals(before)) {
                            o.put("actual", f[1]);
                            e.actual = f[1];
                            verdict(e);
                            Notify.show(c, Prefs.N_MACRO, 8800 + (e.id.hashCode() & 0x3FF), "📢 " + e.title + ": " + e.actual,
                                    e.verdict, e.verdictSign > 0 ? 0xFF0ECB81 : e.verdictSign < 0 ? 0xFFF6465D : 0xFFFFC94D, MainActivity.TAB_LISTINGS);
                        }
                        changed = true;
                    }
                }
                if (o.length() > 1) st.put(e.id, o);
            } catch (Exception ignored) {
            }
        }
        if (changed) saveState(c, st);
    }

    static String mins(long ms) {
        long m = Math.max(0, ms / 60000);
        if (m >= 1440) return (m / 1440) + " din " + (m % 1440) / 60 + " ghante";
        if (m >= 60) return (m / 60) + " ghante " + (m % 60) + " min";
        return m + " min";
    }

    /** True if a HIGH-impact event is within ±minutes of now (for pausing signals). */
    public static boolean highImpactNear(Context c, int minutes) {
        List<Event> evs = cache != null ? cache : calendar(c, false);
        long now = System.currentTimeMillis();
        for (Event e : evs) if ("High".equals(e.impact) && Math.abs(e.time - now) <= minutes * 60_000L) return true;
        return false;
    }

    // ------------------------------------------------------------------ macro pulse
    public static final class Pulse {
        public double fedRate = Double.NaN, us10y = Double.NaN, us10yChg, dxy = Double.NaN, dxyChg;
        public double us2y = Double.NaN, us2yChg, spx = Double.NaN, spxChgPct, vix = Double.NaN;
        public long nextFomc;
        public final List<String[]> speeches = new ArrayList<>();   // {title, link, date}
        public int hawk, dove;
        public int score;            // -100..100 (+ = risk-on for crypto)
        public String mood = "";
        public final List<String> lines = new ArrayList<>();
    }

    private static volatile Pulse pulseCache;
    private static volatile long pulseAt;

    static final String[] HAWK = {"hike", "higher for longer", "restrictive", "persistent inflation", "sticky", "tighten", "hawkish", "no rush", "patient", "pause cuts"};
    static final String[] DOVE = {"cut", "easing", "dovish", "lower rates", "cooling", "slowdown", "softening", "rate reduction", "accommodative"};

    public static Pulse pulse(boolean force) {
        if (!force && pulseCache != null && System.currentTimeMillis() - pulseAt < 30 * 60_000L) return pulseCache;
        Pulse p = new Pulse();
        double sc = 0;
        double[] ff = fredLevel("DFEDTARU", 1);
        if (ff != null) p.fedRate = ff[0];
        double[] y = fredLevel("DGS10", 5);
        if (y != null) {
            p.us10y = y[0];
            p.us10yChg = y[1];
            sc += Fmt.clamp(-y[1] / 0.15, -1, 1) * 30;   // falling yields = good for crypto
        }
        double[] d = fredLevel("DTWEXBGS", 5);
        if (d != null) {
            p.dxy = d[0];
            p.dxyChg = d[1];
            sc += Fmt.clamp(-d[1] / 0.8, -1, 1) * 30;    // weaker dollar = good for crypto
        }
        double[] y2 = fredLevel("DGS2", 5);
        if (y2 != null) { p.us2y = y2[0]; p.us2yChg = y2[1]; sc += Fmt.clamp(-y2[1] / 0.15, -1, 1) * 15; }
        double[] spx = fredLevel("SP500", 5);
        if (spx != null && spx[0] > 0) { p.spx = spx[0]; p.spxChgPct = spx[1] / (spx[0] - spx[1]) * 100; sc += Fmt.clamp(p.spxChgPct / 2.0, -1, 1) * 15; }
        double[] vix = fredLevel("VIXCLS", 5);
        if (vix != null) { p.vix = vix[0]; sc += vix[0] > 25 ? -15 : vix[0] < 15 ? 8 : 0; }
        p.nextFomc = nextFomc();
        // Fed speeches (official) + Fed-related headlines tone
        try {
            String xml = Scanner.getAbsolute("https://www.federalreserve.gov/feeds/speeches.xml");
            Matcher m = Pattern.compile("<item>(.*?)</item>", Pattern.DOTALL).matcher(xml);
            while (m.find() && p.speeches.size() < 6) {
                String it = m.group(1);
                p.speeches.add(new String[]{tag(it, "title"), tag(it, "link"), tag(it, "pubDate")});
            }
        } catch (Exception ignored) {
        }
        for (String feed : new String[]{"https://www.federalreserve.gov/feeds/press_monetary.xml", "https://cointelegraph.com/rss", "https://www.coindesk.com/arc/outboundfeeds/rss/"}) {
            try {
                String xml = Scanner.getAbsolute(feed);
                Matcher m = Pattern.compile("<title>(?:<!\\[CDATA\\[)?(.*?)(?:\\]\\]>)?</title>", Pattern.DOTALL).matcher(xml);
                while (m.find()) {
                    String t = m.group(1).toLowerCase(Locale.US);
                    if (!(t.contains("fed") || t.contains("fomc") || t.contains("powell") || t.contains("rate"))) continue;
                    for (String k : HAWK) if (t.contains(k)) p.hawk++;
                    for (String k : DOVE) if (t.contains(k)) p.dove++;
                }
            } catch (Exception ignored) {
            }
        }
        if (p.hawk + p.dove > 0) sc += Fmt.clamp((p.dove - p.hawk) / (double) (p.hawk + p.dove), -1, 1) * 40;
        p.score = (int) Math.round(Fmt.clamp(sc, -100, 100));
        p.mood = p.score >= 20 ? "🟢 Risk-ON — macro crypto ke haq mein" : p.score <= -20 ? "🔴 Risk-OFF — macro crypto par pressure" : "⚖️ Neutral macro";
        if (!Double.isNaN(p.fedRate)) p.lines.add(String.format(Locale.US, "Fed rate (upper): %.2f%%", p.fedRate));
        if (p.nextFomc > 0) p.lines.add("Agla FOMC faisla: " + pkt(p.nextFomc) + " (" + mins(p.nextFomc - System.currentTimeMillis()) + ")");
        if (!Double.isNaN(p.us10y)) p.lines.add(String.format(Locale.US, "US 10Y yield: %.2f%% (5 din %+.2f) %s", p.us10y, p.us10yChg,
                p.us10yChg < -0.05 ? "↓ achha 🟢" : p.us10yChg > 0.05 ? "↑ pressure 🔴" : ""));
        if (!Double.isNaN(p.dxy)) p.lines.add(String.format(Locale.US, "US Dollar index: %.2f (5 din %+.2f) %s", p.dxy, p.dxyChg,
                p.dxyChg < -0.3 ? "↓ dollar kamzor = crypto 🟢" : p.dxyChg > 0.3 ? "↑ dollar mazboot = crypto 🔴" : ""));
        if (!Double.isNaN(p.us2y)) p.lines.add(String.format(Locale.US, "US 2Y yield (rate expectations): %.2f%% (5 din %+.2f) %s", p.us2y, p.us2yChg,
                p.us2yChg < -0.05 ? "↓ market cuts dekh rahi 🟢" : p.us2yChg > 0.05 ? "↑ hikes ka dar 🔴" : ""));
        if (!Double.isNaN(p.spx)) p.lines.add(String.format(Locale.US, "S&P 500: %s (5 din %+.1f%%) %s", Fmt.num(p.spx), p.spxChgPct,
                p.spxChgPct > 1 ? "stocks risk-on 🟢" : p.spxChgPct < -1 ? "stocks risk-off 🔴" : ""));
        if (!Double.isNaN(p.vix)) p.lines.add(String.format(Locale.US, "VIX (dar ka index): %.1f %s", p.vix,
                p.vix > 25 ? "— market mein dar 🔴" : p.vix < 15 ? "— market pur-sukoon 🟢" : "— normal"));
        if (p.hawk + p.dove > 0) p.lines.add("Fed tone (taaza khabrein): dovish " + p.dove + " · hawkish " + p.hawk);
        pulseCache = p;
        pulseAt = System.currentTimeMillis();
        return p;
    }

    private static String tag(String it, String name) {
        Matcher m = Pattern.compile("<" + name + ">(?:<!\\[CDATA\\[)?(.*?)(?:\\]\\]>)?</" + name + ">", Pattern.DOTALL).matcher(it);
        return m.find() ? m.group(1).trim() : "";
    }

    /** Time in Pakistan (device time zone). */
    public static String pkt(long t) {
        return new SimpleDateFormat("EEE dd MMM, hh:mm a", Locale.US).format(new Date(t));
    }

    /** For the coin analysis: upcoming risk + recent results + macro mood. {score, lines...} */
    public static List<String> reportLines(int[] scoreOut) {
        List<String> out = new ArrayList<>();
        List<Event> evs = cache != null ? cache : calendar(null, false);
        Pulse p = pulse(false);
        long now = System.currentTimeMillis();
        int sc = p.score / 2;
        out.add("Macro mood: " + p.mood);
        out.addAll(p.lines);
        for (Event e : evs) {
            if (!"High".equals(e.impact)) continue;
            long dt = e.time - now;
            if (dt > 0 && dt < 48 * 3600_000L) out.add("⏰ " + mins(dt) + " baad: " + e.title + (e.forecast.isEmpty() ? "" : " (forecast " + e.forecast + ")"));
            if (dt < 0 && dt > -72 * 3600_000L && !e.verdict.isEmpty()) {
                out.add("📢 " + e.title + ": " + e.verdict);
                sc += e.verdictSign * 15;
            }
        }
        for (Event e : evs) {
            if ("High".equals(e.impact) && Math.abs(e.time - now) < 2 * 3600_000L) {
                out.add("⚠️ 2 ghante ke andar bada US data — price achanak upar/neeche ho sakti hai, SL tight rakhen");
                break;
            }
        }
        scoreOut[0] = (int) Fmt.clamp(sc, -100, 100);
        return out;
    }
}
