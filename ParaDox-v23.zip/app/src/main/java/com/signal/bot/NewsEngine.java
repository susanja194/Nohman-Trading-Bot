package com.signal.bot;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * LIVE crypto news radar: ~20 free sources (news sites RSS, Google News which covers Reuters/Bloomberg/CNBC etc.,
 * Binance announcements, Tree of Alpha — which republishes important X/Twitter posts — and optional CryptoPanic).
 * The same story from many sources is merged into one item. Every item is classified:
 * category (hack, listing, ETF, regulation...), BULLISH/BEARISH, severity, coins & exchanges involved,
 * and a Roman Urdu explanation of what may happen and what to do.
 */
public final class NewsEngine {
    private NewsEngine() {}

    public static final class Item {
        public String id = "", title = "", summary = "", link = "", source = "";
        public long time;
        public final List<String> coins = new ArrayList<>();
        public final List<String> exchanges = new ArrayList<>();
        public final List<String[]> sources = new ArrayList<>();    // {source, link}
        public int dir;              // +1 bullish, -1 bearish, 0 neutral
        public int severity = 1;     // 1 normal, 2 important, 3 critical
        public String category = "📰 News", catKey = "news";
        public String impact = "", action = "";
        public boolean social, macro, breaking;
        Set<String> words;
    }

    // {name, url, kind, tier}  kind: rss | rssf (general site, crypto-filtered) | tree | binance
    // tier: F = fast (every refresh, ~1 min in background) · S = slow (every ~5 min) — saves battery and mobile data
    static final String G = "https://news.google.com/rss/search?hl=en-US&gl=US&ceid=US:en&q=";
    static final String CRYPTO_Q = "(crypto OR bitcoin OR ethereum OR binance OR stablecoin OR tether OR hack OR exploit)";
    static final String[][] FEEDS = {
            // ---- fastest: X posts, exchanges, breaking searches
            {"X / Tree of Alpha", "https://news.treeofalpha.com/api/news?limit=60", "tree", "F"},
            {"Binance News", "https://www.binance.com/bapi/composite/v1/public/cms/article/list/query?type=1&catalogId=49&pageNo=1&pageSize=15", "binance", "F"},
            {"Binance Delisting", "https://www.binance.com/bapi/composite/v1/public/cms/article/list/query?type=1&catalogId=161&pageNo=1&pageSize=10", "binance", "F"},
            {"Binance Listing", "https://www.binance.com/bapi/composite/v1/public/cms/article/list/query?type=1&catalogId=48&pageNo=1&pageSize=10", "binance", "F"},
            {"Google News", G + enc("(hack OR hacked OR exploit OR drained OR breach OR \"withdrawals\" OR depeg OR delist) (crypto OR exchange OR binance OR wallet) when:1d"), "rss", "F"},
            {"Google News", G + enc("(crypto OR bitcoin OR ethereum OR binance OR stablecoin) when:1d"), "rss", "F"},
            {"Watcher.Guru", "https://watcher.guru/news/feed", "rss", "F"},
            {"BNO News", "https://bnonews.com/index.php/feed/", "rssf", "F"},
            // ---- crypto news sites (direct RSS)
            {"Cointelegraph", "https://cointelegraph.com/rss", "rss", "S"},
            {"CoinDesk", "https://www.coindesk.com/arc/outboundfeeds/rss/", "rss", "S"},
            {"Decrypt", "https://decrypt.co/feed", "rss", "S"},
            {"The Block", "https://www.theblock.co/rss.xml", "rss", "S"},
            {"Bitcoin Magazine", "https://bitcoinmagazine.com/.rss/full/", "rss", "S"},
            {"CryptoSlate", "https://cryptoslate.com/feed/", "rss", "S"},
            {"BeInCrypto", "https://beincrypto.com/feed/", "rss", "S"},
            {"CryptoPotato", "https://cryptopotato.com/feed/", "rss", "S"},
            {"NewsBTC", "https://www.newsbtc.com/feed/", "rss", "S"},
            {"Bitcoinist", "https://bitcoinist.com/feed/", "rss", "S"},
            {"U.Today", "https://u.today/rss", "rss", "S"},
            {"Blockworks", "https://blockworks.co/feed", "rss", "S"},
            {"CoinGape", "https://coingape.com/feed/", "rss", "S"},
            {"crypto.news", "https://crypto.news/feed/", "rss", "S"},
            {"The Defiant", "https://thedefiant.io/feed", "rss", "S"},
            {"CryptoTicker", "https://cryptoticker.io/en/feed/", "rss", "S"},
            {"Blockchain.News", "https://blockchain.news/RSS/", "rss", "S"},
            {"AMBCrypto", "https://ambcrypto.com/feed/", "rss", "S"},
            {"FinanceFeeds", "https://financefeeds.com/feed/", "rssf", "S"},
            {"investingLive", "https://investinglive.com/feed/", "rssf", "S"},
            {"FXStreet", "https://www.fxstreet.com/rss/news", "rssf", "S"},
            {"Cyber Kendra", "https://www.cyberkendra.com/feeds/posts/default?alt=rss", "rssf", "S"},
            {"TheCable", "https://www.thecable.ng/feed", "rssf", "S"},
            {"Cryptonews", "https://cryptonews.com/news/feed/", "rss", "S"},
            {"The Daily Hodl", "https://dailyhodl.com/feed/", "rss", "S"},
            {"Crypto Briefing", "https://cryptobriefing.com/feed/", "rss", "S"},
            {"DL News", "https://www.dlnews.com/arc/outboundfeeds/rss/", "rss", "S"},
            {"Protos", "https://protos.com/feed/", "rss", "S"},
            {"Bitcoin.com News", "https://news.bitcoin.com/feed/", "rss", "S"},
            {"CoinJournal", "https://coinjournal.net/feed/", "rss", "S"},
            {"Finbold", "https://finbold.com/feed/", "rss", "S"},
            {"ZyCrypto", "https://zycrypto.com/feed/", "rss", "S"},
            {"Coinpedia", "https://coinpedia.org/feed/", "rss", "S"},
            {"CryptoDaily", "https://cryptodaily.co.uk/feed", "rss", "S"},
            // ---- sites without a public RSS: read through Google News "site:" search
            {"Google News", G + enc("(site:bloomingbit.io OR site:tradingview.com OR site:onesafe.io OR site:finance.yahoo.com OR site:streetinsider.com OR site:hindustantimes.com) " + CRYPTO_Q + " when:1d"), "rss", "S"},
            {"Google News", G + enc("(site:reuters.com OR site:bloomberg.com OR site:cnbc.com OR site:wsj.com OR site:ft.com OR site:forbes.com) " + CRYPTO_Q + " when:1d"), "rss", "S"},
            {"Google News", G + enc("(site:fxstreet.com OR site:investinglive.com OR site:financefeeds.com OR site:cyberkendra.com OR site:thecable.ng OR site:bnonews.com) " + CRYPTO_Q + " when:1d"), "rss", "S"},
            {"Google News", G + enc("(site:cointelegraph.com OR site:decrypt.co OR site:coindesk.com OR site:theblock.co OR site:ambcrypto.com OR site:blockchain.news OR site:cryptoticker.io) when:1d"), "rss", "S"},
    };

    /** Words that make a general-news headline crypto related (for "rssf" feeds). */
    static final String[] CRYPTO_WORDS = {"crypto", "bitcoin", "btc", "ethereum", "ether ", "binance", "coinbase", "blockchain", "stablecoin",
            "tether", "usdt", "usdc", "circle", "token", "defi", "solana", "xrp", "web3", "nft", "exchange hack", "wallet", "altcoin", "memecoin", "sec "};

    static boolean cryptoRelated(String t) {
        String l = " " + t.toLowerCase(Locale.US) + " ";
        for (String w : CRYPTO_WORDS) if (l.contains(w)) return true;
        return false;
    }

    public static int sourceCount() { return FEEDS.length; }

    private static String enc(String s) {
        try { return URLEncoder.encode(s, "UTF-8"); } catch (Exception e) { return s; }
    }

    private static volatile List<Item> cache = new ArrayList<>();
    private static volatile long cacheAt;
    private static volatile String lastStatus = "";
    private static final Object LOCK = new Object();
    /** Base symbols tradable on Binance (filled by the market screens / scanner). */
    public static final Set<String> KNOWN = Collections.synchronizedSet(new HashSet<>());

    public static List<Item> cached() { return cache; }
    public static String status() { return lastStatus; }

    /** Fetches all sources (in parallel), merges duplicates, classifies. Cached for maxAgeMs. */
    private static final Map<String, List<Item>> FEED_ITEMS = new HashMap<>();
    private static final Map<String, Long> FEED_AT = new HashMap<>();
    private static final Map<String, Long> FIRST_SEEN = new HashMap<>();
    private static final Set<String> FEED_OK = Collections.synchronizedSet(new HashSet<>());

    static Item copy(Item o) {
        Item x = new Item();
        x.title = o.title; x.summary = o.summary; x.link = o.link; x.source = o.source; x.time = o.time; x.social = o.social;
        x.coins.addAll(o.coins);
        return x;
    }

    public static List<Item> fetch(Context ctx, long maxAgeMs) {
        if (System.currentTimeMillis() - cacheAt < maxAgeMs && !cache.isEmpty()) return cache;
        synchronized (LOCK) {
            if (System.currentTimeMillis() - cacheAt < maxAgeMs && !cache.isEmpty()) return cache;
            List<String[]> feeds = new ArrayList<>();
            Collections.addAll(feeds, FEEDS);
            String cp = ctx != null ? Prefs.getStr(ctx, "cryptopanic", "") : "";
            if (cp != null && !cp.trim().isEmpty()) feeds.add(new String[]{"CryptoPanic", cp.trim(), "cpanic", "F"});
            long t0 = System.currentTimeMillis();
            ExecutorService ex = Executors.newFixedThreadPool(10);
            for (final String[] f : feeds) {
                Long last;
                synchronized (FEED_ITEMS) { last = FEED_AT.get(f[1]); }
                long every = "F".equals(f[3]) ? 15_000L : 4 * 60_000L;   // slow sources at most every 4 min
                if (last != null && t0 - last < every) continue;
                ex.submit(() -> {
                    try {
                        List<Item> l = load(f);
                        if ("rssf".equals(f[2])) {
                            List<Item> k = new ArrayList<>();
                            for (Item it : l) if (cryptoRelated(it.title + " " + it.summary)) k.add(it);
                            l = k;
                        }
                        synchronized (FEED_ITEMS) {
                            for (Item it : l) {   // undated items keep the time we first saw them
                                if (it.time <= 0) {
                                    Long fsn = FIRST_SEEN.get(it.title);
                                    if (fsn == null) { fsn = System.currentTimeMillis(); FIRST_SEEN.put(it.title, fsn); }
                                    it.time = fsn;
                                }
                            }
                            FEED_ITEMS.put(f[1], l);
                            FEED_AT.put(f[1], System.currentTimeMillis());
                        }
                        FEED_OK.add(f[1]);
                    } catch (Exception e) {
                        synchronized (FEED_ITEMS) { FEED_AT.put(f[1], System.currentTimeMillis() - ("F".equals(f[3]) ? 0 : 2 * 60_000L)); }
                        FEED_OK.remove(f[1]);
                    }
                });
            }
            ex.shutdown();
            try { ex.awaitTermination(25, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
            ex.shutdownNow();
            final List<Item> all = new ArrayList<>();
            synchronized (FEED_ITEMS) {
                for (List<Item> l : FEED_ITEMS.values()) for (Item it : l) all.add(copy(it));
                if (FIRST_SEEN.size() > 3000) FIRST_SEEN.clear();
            }
            final int[] ok = {FEED_OK.size()};
            long now = System.currentTimeMillis();
            List<Item> fresh = new ArrayList<>();
            synchronized (all) {
                for (Item it : all) {
                    if (it.title.isEmpty()) continue;
                    if (it.time <= 0 || it.time > now + 3600_000L) it.time = now;
                    if (now - it.time > 3 * 86_400_000L) continue;   // last 3 days
                    fresh.add(it);
                }
            }
            Collections.sort(fresh, (a, b) -> Long.compare(a.time, b.time));   // oldest first -> earliest source becomes primary
            List<Item> merged = new ArrayList<>();
            for (Item it : fresh) {
                it.words = words(it.title);
                Item same = null;
                for (Item m : merged) {
                    if (Math.abs(m.time - it.time) < 12 * 3600_000L && similar(m.words, it.words)) { same = m; break; }
                }
                if (same == null) {
                    it.sources.add(new String[]{it.source, it.link});
                    merged.add(it);
                } else {
                    boolean have = false;
                    for (String[] s : same.sources) if (s[0].equals(it.source)) have = true;
                    if (!have) same.sources.add(new String[]{it.source, it.link});
                    if (it.social) same.social = true;
                    if (same.summary.isEmpty()) same.summary = it.summary;
                    for (String c : it.coins) if (!same.coins.contains(c)) same.coins.add(c);
                }
            }
            for (Item it : merged) classify(it);
            Collections.sort(merged, (a, b) -> Long.compare(b.time, a.time));
            if (merged.size() > 300) merged = new ArrayList<>(merged.subList(0, 300));
            if (!merged.isEmpty() || cache.isEmpty()) {
                cache = merged;
                cacheAt = System.currentTimeMillis();
            }
            lastStatus = ok[0] + "/" + feeds.size() + " sources · " + merged.size() + " khabrein · "
                    + new SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date());
            return cache;
        }
    }

    // ------------------------------------------------------------------ loaders
    private static List<Item> load(String[] f) throws Exception {
        switch (f[2]) {
            case "tree": return tree(f[0], f[1]);
            case "binance": return binance(f[0], f[1]);
            case "cpanic": return cryptoPanic(f[1]);
            default: return rss(f[0], Scanner.getAbsolute(f[1]), f[1].contains("news.google"));
        }
    }

    private static final Pattern ITEM = Pattern.compile("<(item|entry)[\\s>](.*?)</\\1>", Pattern.DOTALL);

    static String tagv(String xml, String tag) {
        Matcher m = Pattern.compile("<" + tag + "(?:\\s[^>]*)?>(.*?)</" + tag + ">", Pattern.DOTALL).matcher(xml);
        if (!m.find()) return "";
        String v = m.group(1).trim();
        if (v.startsWith("<![CDATA[")) v = v.substring(9, v.endsWith("]]>") ? v.length() - 3 : v.length());
        return v.trim();
    }

    static List<Item> rss(String name, String xml, boolean google) {
        List<Item> out = new ArrayList<>();
        Matcher m = ITEM.matcher(xml);
        int n = 0;
        while (m.find() && n < 40) {
            String it = m.group(2);
            Item x = new Item();
            x.title = clean(tagv(it, "title"));
            String link = tagv(it, "link");
            if (link.isEmpty()) {
                Matcher lm = Pattern.compile("<link[^>]*href=\"([^\"]+)\"").matcher(it);
                if (lm.find()) link = lm.group(1);
            }
            x.link = clean(link);
            String d = tagv(it, "pubDate");
            if (d.isEmpty()) d = tagv(it, "published");
            if (d.isEmpty()) d = tagv(it, "updated");
            if (d.isEmpty()) d = tagv(it, "dc:date");
            x.time = parseDate(d);
            String desc = tagv(it, "description");
            if (desc.isEmpty()) desc = tagv(it, "summary");
            x.summary = trim(clean(desc), 280);
            x.source = name;
            if (google) {   // "Title - Publisher"
                String src = tagv(it, "source");
                int dash = x.title.lastIndexOf(" - ");
                if (dash > 20) {
                    if (src.isEmpty()) src = x.title.substring(dash + 3);
                    x.title = x.title.substring(0, dash);
                }
                if (!src.isEmpty()) x.source = clean(src) + " (Google News)";
                x.summary = "";
            }
            if (!x.title.isEmpty()) { out.add(x); n++; }
        }
        return out;
    }

    /** Tree of Alpha: fast feed that includes important X (Twitter) posts and exchange announcements. */
    static List<Item> tree(String name, String url) throws Exception {
        List<Item> out = new ArrayList<>();
        String raw = Scanner.getAbsolute(url);
        JSONArray a = raw.trim().startsWith("[") ? new JSONArray(raw) : new JSONObject(raw).optJSONArray("news");
        if (a == null) return out;
        for (int i = 0; i < a.length() && i < 60; i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            Item x = new Item();
            String t = o.optString("title", "");
            if (t.isEmpty()) t = o.optString("body", "");
            x.title = trim(clean(t), 300);
            x.link = o.optString("url", o.optString("link", ""));
            long tm = o.optLong("time", 0);
            if (tm > 0 && tm < 10_000_000_000L) tm *= 1000;
            x.time = tm;
            String src = o.optString("source", "");
            x.social = o.has("icon") || src.toLowerCase(Locale.US).contains("twitter") || x.link.contains("twitter.com") || x.link.contains("x.com");
            x.source = x.social ? "X (Twitter)" + (src.isEmpty() || src.equalsIgnoreCase("twitter") ? "" : " · " + src) : (src.isEmpty() ? name : src);
            JSONArray sug = o.optJSONArray("suggestions");
            if (sug != null) for (int k = 0; k < sug.length(); k++) {
                JSONObject s = sug.optJSONObject(k);
                if (s != null) {
                    String c = s.optString("coin", "").toUpperCase(Locale.US);
                    if (!c.isEmpty() && !x.coins.contains(c)) x.coins.add(c);
                }
            }
            if (!x.title.isEmpty()) out.add(x);
        }
        return out;
    }

    static List<Item> binance(String name, String url) throws Exception {
        List<Item> out = new ArrayList<>();
        JSONObject o = new JSONObject(Scanner.getAbsolute(url));
        JSONArray cats = o.getJSONObject("data").getJSONArray("catalogs");
        for (int c = 0; c < cats.length(); c++) {
            JSONArray arts = cats.getJSONObject(c).optJSONArray("articles");
            if (arts == null) continue;
            for (int i = 0; i < arts.length(); i++) {
                JSONObject a = arts.getJSONObject(i);
                Item x = new Item();
                x.title = a.optString("title");
                x.link = "https://www.binance.com/en/support/announcement/" + a.optString("code");
                x.time = a.optLong("releaseDate", 0);
                x.source = name;
                out.add(x);
            }
        }
        return out;
    }

    /** Optional: user's own free CryptoPanic token (aggregates 100s of sites + social). */
    static List<Item> cryptoPanic(String token) throws Exception {
        List<Item> out = new ArrayList<>();
        String raw;
        try {
            raw = Scanner.getAbsolute("https://cryptopanic.com/api/developer/v2/posts/?auth_token=" + enc(token) + "&public=true");
        } catch (Exception e) {
            raw = Scanner.getAbsolute("https://cryptopanic.com/api/v1/posts/?auth_token=" + enc(token) + "&public=true");
        }
        JSONArray r = new JSONObject(raw).optJSONArray("results");
        if (r == null) return out;
        for (int i = 0; i < r.length(); i++) {
            JSONObject o = r.optJSONObject(i);
            if (o == null) continue;
            Item x = new Item();
            x.title = clean(o.optString("title"));
            x.link = o.optString("url", o.optString("original_url", ""));
            if (x.link.isEmpty()) x.link = "https://cryptopanic.com/news/" + o.optString("id") + "/";
            x.time = parseDate(o.optString("published_at"));
            JSONObject s = o.optJSONObject("source");
            x.source = (s != null ? s.optString("title", "CryptoPanic") : "CryptoPanic") + " (CryptoPanic)";
            x.social = "media".equals(o.optString("kind")) || (s != null && s.optString("domain").contains("twitter"));
            JSONArray cs = o.optJSONArray("currencies");
            if (cs == null) cs = o.optJSONArray("instruments");
            if (cs != null) for (int k = 0; k < cs.length(); k++) {
                JSONObject c = cs.optJSONObject(k);
                if (c != null && !c.optString("code").isEmpty()) x.coins.add(c.optString("code").toUpperCase(Locale.US));
            }
            out.add(x);
        }
        return out;
    }

    // ------------------------------------------------------------------ text helpers
    static String clean(String s) {
        if (s == null) return "";
        s = s.replaceAll("(?s)<!\\[CDATA\\[(.*?)\\]\\]>", "$1").replaceAll("(?s)<[^>]+>", " ");
        s = s.replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'").replace("&#039;", "'").replace("&apos;", "'")
                .replace("&lt;", "<").replace("&gt;", ">").replace("&nbsp;", " ").replace("&#8217;", "'").replace("&#8216;", "'")
                .replace("&#8220;", "\"").replace("&#8221;", "\"").replace("&#8211;", "–").replace("&#8212;", "—").replace("&#038;", "&");
        s = s.replaceAll("&#(\\d+);", " ").replaceAll("(?s)<[^>]+>", " ");
        return s.replaceAll("\\s+", " ").trim();
    }

    static String trim(String s, int n) { return s.length() <= n ? s : s.substring(0, n).trim() + "…"; }

    static long parseDate(String d) {
        if (d == null || d.isEmpty()) return 0;
        d = d.trim();
        String[] fm = {"EEE, dd MMM yyyy HH:mm:ss Z", "EEE, d MMM yyyy HH:mm:ss Z", "EEE, dd MMM yyyy HH:mm:ss zzz", "EEE, d MMM yyyy HH:mm:ss zzz",
                "dd MMM yyyy HH:mm:ss Z", "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ss'Z'",
                "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd'T'HH:mm:ssZ", "yyyy-MM-dd HH:mm:ss"};
        for (String f : fm) {
            try {
                SimpleDateFormat s = new SimpleDateFormat(f, Locale.US);
                if (f.endsWith("'Z'") || f.equals("yyyy-MM-dd HH:mm:ss")) s.setTimeZone(TimeZone.getTimeZone("UTC"));
                s.setLenient(true);
                java.util.Date dt = s.parse(d);
                if (dt != null) return dt.getTime();
            } catch (Exception ignored) {
            }
        }
        return 0;
    }

    private static final Set<String> STOP = new HashSet<>(java.util.Arrays.asList(
            "the", "a", "an", "to", "of", "in", "on", "for", "and", "is", "as", "at", "by", "with", "from", "its", "it", "after", "be",
            "are", "this", "that", "will", "has", "have", "new", "says", "say", "amid", "over", "into", "crypto", "news", "price", "up", "than",
            "million", "billion", "breaking", "just", "report", "reportedly", "worth"));

    static Set<String> words(String t) {
        Set<String> s = new HashSet<>();
        for (String w : t.toLowerCase(Locale.US).replaceAll("[^a-z0-9$%. ]", " ").split("\\s+")) {
            if (w.length() < 3 || STOP.contains(w)) continue;
            if (w.matches("\\$?[0-9.]+[mbk]")) w = w.substring(0, w.length() - 1);
            for (String suf : new String[]{"ing", "ed", "er", "s"}) {
                if (w.length() > suf.length() + 3 && w.endsWith(suf)) { w = w.substring(0, w.length() - suf.length()); break; }
            }
            if (w.length() < 3 || STOP.contains(w)) continue;
            s.add(w);
        }
        return s;
    }

    static boolean similar(Set<String> a, Set<String> b) {
        if (a.size() < 3 || b.size() < 3) return false;
        int inter = 0;
        for (String w : a) if (b.contains(w)) inter++;
        double j = inter / (double) (a.size() + b.size() - inter);
        return j >= 0.42 || (inter >= 4 && inter >= 0.6 * Math.min(a.size(), b.size()));
    }

    // ------------------------------------------------------------------ coins & exchanges
    static final String[][] NAMES = {
            {"bitcoin", "BTC"}, {"ethereum", "ETH"}, {"ether", "ETH"}, {"solana", "SOL"}, {"ripple", "XRP"}, {"xrp", "XRP"},
            {"bnb", "BNB"}, {"cardano", "ADA"}, {"dogecoin", "DOGE"}, {"tron", "TRX"}, {"toncoin", "TON"}, {"avalanche", "AVAX"},
            {"shiba inu", "SHIB"}, {"polkadot", "DOT"}, {"chainlink", "LINK"}, {"polygon", "POL"}, {"litecoin", "LTC"},
            {"near protocol", "NEAR"}, {"uniswap", "UNI"}, {"aptos", "APT"}, {"sui", "SUI"}, {"pepe", "PEPE"}, {"arbitrum", "ARB"},
            {"optimism", "OP"}, {"injective", "INJ"}, {"render", "RENDER"}, {"filecoin", "FIL"}, {"cosmos", "ATOM"}, {"hedera", "HBAR"},
            {"stellar", "XLM"}, {"monero", "XMR"}, {"ethena", "ENA"}, {"worldcoin", "WLD"}, {"bonk", "BONK"}, {"dogwifhat", "WIF"},
            {"floki", "FLOKI"}, {"jupiter", "JUP"}, {"celestia", "TIA"}, {"aave", "AAVE"}, {"lido", "LDO"}, {"algorand", "ALGO"},
            {"vechain", "VET"}, {"hyperliquid", "HYPE"}, {"ondo", "ONDO"}, {"pyth", "PYTH"}, {"starknet", "STRK"}, {"zksync", "ZK"},
            {"bitcoin cash", "BCH"}, {"ethereum classic", "ETC"}, {"internet computer", "ICP"}, {"kaspa", "KAS"}, {"pi network", "PI"},
            {"world liberty", "WLFI"}, {"official trump", "TRUMP"}, {"trump coin", "TRUMP"}, {"tether", "USDT"}, {"usdc", "USDC"},
            {"binance coin", "BNB"}, {"the sandbox", "SAND"}, {"decentraland", "MANA"}, {"axie", "AXS"}, {"gala", "GALA"},
            {"fetch.ai", "FET"}, {"bittensor", "TAO"}, {"zcash", "ZEC"}, {"stacks", "STX"}, {"mantle", "MNT"}, {"cronos", "CRO"},
            {"sei", "SEI"}, {"berachain", "BERA"}, {"eigenlayer", "EIGEN"}, {"pendle", "PENDLE"}, {"curve", "CRV"}, {"maker", "MKR"},
            {"sky", "SKY"}, {"kaia", "KAIA"}, {"layerzero", "ZRO"}, {"pancakeswap", "CAKE"}, {"raydium", "RAY"}, {"jito", "JTO"},
            {"btc", "BTC"}, {"eth", "ETH"}, {"sol", "SOL"}, {"doge", "DOGE"}, {"avax", "AVAX"}, {"ltc", "LTC"}, {"trx", "TRX"},
            {"xlm", "XLM"}, {"hbar", "HBAR"}, {"shib", "SHIB"}, {"ada", "ADA"}};
    static final String[][] EXCHANGES = {
            {"binance", "BNB"}, {"coinbase", ""}, {"kraken", ""}, {"okx", "OKB"}, {"bybit", ""}, {"bitget", "BGB"}, {"kucoin", "KCS"},
            {"upbit", ""}, {"gate.io", "GT"}, {"htx", "HTX"}, {"huobi", "HTX"}, {"mexc", ""}, {"crypto.com", "CRO"}, {"bitfinex", "LEO"},
            {"robinhood", ""}, {"hyperliquid", "HYPE"}, {"bithumb", ""}, {"gemini", ""}, {"ftx", "FTT"}};
    static final Set<String> NOT_COINS = new HashSet<>(java.util.Arrays.asList(
            "THE", "CEO", "SEC", "ETF", "ETFS", "USD", "NEW", "ALL", "ONE", "FOR", "AND", "NOT", "CFTC", "FED", "FOMC", "CPI", "GDP", "NFP",
            "IPO", "NFT", "NFTS", "DEX", "CEX", "API", "USA", "UK", "EU", "AI", "ATH", "TVL", "DAO", "DEFI", "SOON", "NOW", "OUT", "NEAR",
            "JUST", "BREAKING", "HACK", "BIG", "TOP", "WILL", "CAN", "GET", "HAS", "WHO", "WHY", "HOW", "OPEN", "HIGH", "LOW", "BUY", "SELL",
            "DOJ", "IRS", "IMF", "ECB", "BOJ", "PBOC", "MICA", "KYC", "AML", "OTC", "LP", "TV", "PR", "ID", "GAS", "ARE", "WIN", "ANY",
            "LIVE", "MEME", "FUD", "HODL", "BULL", "BEAR", "PUMP", "DUMP", "MOVE", "BANK", "COIN", "SAFE", "TRUE", "FREE", "PEOPLE"));

    static void detect(Item it) {
        String low = " " + it.title.toLowerCase(Locale.US) + " ";
        for (String[] n : NAMES) {
            if (Pattern.compile("[^a-z0-9]" + Pattern.quote(n[0]) + "[^a-z0-9]").matcher(low).find() && !it.coins.contains(n[1])) it.coins.add(n[1]);
        }
        Matcher m = Pattern.compile("\\$([A-Za-z][A-Za-z0-9]{1,9})\\b").matcher(it.title);
        while (m.find()) {
            String s = m.group(1).toUpperCase(Locale.US);
            if (!NOT_COINS.contains(s) && !it.coins.contains(s)) it.coins.add(s);
        }
        Matcher u = Pattern.compile("\\b([A-Z][A-Z0-9]{2,9})\\b").matcher(it.title);
        while (u.find()) {
            String s = u.group(1);
            if (!NOT_COINS.contains(s) && KNOWN.contains(s) && !it.coins.contains(s)) it.coins.add(s);
        }
        for (String[] e : EXCHANGES) {
            if (Pattern.compile("[^a-z0-9]" + Pattern.quote(e[0]) + "[^a-z0-9]").matcher(low).find()) {
                String nm = Character.toUpperCase(e[0].charAt(0)) + e[0].substring(1);
                if (!it.exchanges.contains(nm)) it.exchanges.add(nm);
            }
        }
        // "Binance" alone is an exchange, not necessarily the BNB coin
        if (it.exchanges.contains("Binance") && !low.contains(" bnb")) it.coins.remove("BNB");
        if (it.coins.size() > 6) it.coins.subList(6, it.coins.size()).clear();
    }

    // ------------------------------------------------------------------ classification
    /** {key, label, direction, severity, keywords...} — first keyword group that matches with the highest severity wins. */
    static final Object[][] RULES = {
            {"hack", "🚨 Hack / Exploit", -1, 3, new String[]{"hacked", "hack ", "hacker", "exploit", "drained", "stolen", "breach", "compromised", "attacker", "security incident", "rug pull", "rugpull"}},
            {"halt", "⛔ Withdrawals band / Outage", -1, 3, new String[]{"suspend withdrawal", "suspends withdrawal", "halts withdrawal", "halted withdrawal", "pauses withdrawal", "paused withdrawal", "withdrawals paused", "withdrawals suspended", "outage", "downtime", "network halt", "chain halt", "halted block"}},
            {"depeg", "💥 Stablecoin depeg", -1, 3, new String[]{"depeg", "de-peg", "loses peg", "lost its peg", "lost peg"}},
            {"bankrupt", "💀 Bankruptcy / Collapse", -1, 3, new String[]{"bankrupt", "insolven", "chapter 11", "collapse", "liquidation proceedings"}},
            {"delist", "📤 Delisting", -1, 3, new String[]{"delist", "will remove", "removal of", "cease trading", "monitoring tag"}},
            {"etfneg", "🏦 ETF outflow / reject", -1, 2, new String[]{"etf outflow", "etfs outflow", "outflows from", "etf reject", "rejects etf", "denies etf", "delays etf", "etf delay", "record outflow"}},
            {"reg", "⚖️ Regulation / Lawsuit", -1, 2, new String[]{"sec sues", "sues ", "lawsuit", "charged", "charges against", "indict", "arrest", "banned", "bans ", "ban on", "crackdown", "sanction", "fraud", "probe", "investigat", "subpoena", "fine ", "fined", "penalty", "wells notice"}},
            {"liqlong", "💣 Longs liquidated", -1, 2, new String[]{"longs liquidated", "long liquidations", "long positions liquidated", "liquidations hit", "billion in liquidations", "million in liquidations"}},
            {"liqshort", "🔥 Short squeeze", 1, 2, new String[]{"shorts liquidated", "short squeeze", "short liquidations"}},
            {"unlock", "🔓 Token unlock (supply)", -1, 1, new String[]{"token unlock", "unlocks", "unlock of", "vesting"}},
            {"whaleout", "🐋 Whale ne exchange par bheja", -1, 1, new String[]{"whale deposit", "whale sends", "whale moves", "whale transfers", "whale sells", "whale dumps", "deposited to binance", "deposits to binance", "sent to binance", "moved to exchange", "deposited to coinbase", "transferred to binance", "dumps", "sold "}},
            {"macroneg", "🏛️ Macro (bearish)", -1, 2, new String[]{"rate hike", "hikes rates", "hawkish", "hotter than expected", "inflation rises", "tariff", "recession", "yields surge", "dollar surges"}},
            {"macropos", "🏛️ Macro (bullish)", 1, 2, new String[]{"rate cut", "cuts rates", "dovish", "cooler than expected", "inflation falls", "inflation eases", "qe ", "stimulus", "liquidity injection"}},
            {"macro", "🏛️ Macro / Fed", 0, 2, new String[]{"fed ", "fomc", "powell", "cpi", "inflation", "jobs report", "nonfarm", "payrolls", "pce", "treasury yield"}},
            {"etfpos", "🏦 ETF approval / inflow", 1, 3, new String[]{"etf approv", "approves etf", "approves spot", "etf inflow", "etfs inflow", "record inflow", "inflows into", "etf launch", "etf debut", "files for etf", "etf filing"}},
            {"list", "🆕 Listing", 1, 2, new String[]{"will list", "lists ", "listing", "launchpool", "hodler airdrop", "adds support", "now available on", "perpetual contract", "will add", "added to the roadmap"}},
            {"treasury", "🏢 Institution / Treasury buy", 1, 2, new String[]{"buys bitcoin", "buys btc", "acquires", "acquired", "adds to treasury", "treasury", "strategy buys", "microstrategy", "saylor", "blackrock", "fidelity", "purchase", "purchased", "accumulat", "reserve"}},
            {"regpos", "✅ Regulation (positive)", 1, 2, new String[]{"approved", "approval", "legal tender", "clarity act", "passes bill", "signs bill", "license", "licence", "greenlight", "dismiss", "drops case", "drops lawsuit", "settle", "pardon"}},
            {"partner", "🤝 Partnership / Adoption", 1, 1, new String[]{"partnership", "partners with", "integrat", "adopts", "adoption", "collaborat", "teams up", "accepts crypto", "payments"}},
            {"upgrade", "🛠️ Upgrade / Mainnet", 1, 1, new String[]{"mainnet", "upgrade", "hard fork", "launches", "goes live", "testnet", "roadmap"}},
            {"burn", "🔥 Burn / Buyback", 1, 1, new String[]{"burn", "buyback", "buy back"}},
            {"airdrop", "🎁 Airdrop", 0, 1, new String[]{"airdrop"}},
            {"pumpw", "📈 Price surge", 1, 1, new String[]{"surge", "soar", "rall", "jumps", "skyrocket", "all-time high", "record high", "new high", "breaks out", "pumps", "spikes", "climbs"}},
            {"dumpw", "📉 Price crash", -1, 1, new String[]{"plunge", "crash", "tumble", "slump", "dumps", "plummet", "sinks", "drops", "falls", "sell-off", "selloff", "bloodbath"}},
    };

    static void classify(Item it) {
        detect(it);
        String low = " " + it.title.toLowerCase(Locale.US) + " " + it.summary.toLowerCase(Locale.US) + " ";
        String tlow = " " + it.title.toLowerCase(Locale.US) + " ";
        int bestSev = 0, dirSum = 0;
        Object[] best = null;
        for (Object[] r : RULES) {
            String[] kw = (String[]) r[4];
            boolean hit = false, inTitle = false;
            for (String k : kw) {
                if (tlow.contains(k)) { hit = true; inTitle = true; break; }
                if (low.contains(k)) hit = true;
            }
            if (!hit) continue;
            int sev = (Integer) r[3];
            if (!inTitle) sev = Math.max(1, sev - 1);
            int d = (Integer) r[2];
            dirSum += d * sev * (inTitle ? 2 : 1);
            if (sev > bestSev) { bestSev = sev; best = r; }
        }
        it.breaking = tlow.contains("breaking") || tlow.contains("just in") || tlow.contains("urgent") || tlow.contains("🚨");
        if (best != null) {
            it.catKey = (String) best[0];
            it.category = (String) best[1];
            it.severity = bestSev;
            int bd = (Integer) best[2];
            it.dir = bd != 0 ? bd : Integer.signum(dirSum);
        } else {
            it.dir = 0;
            it.severity = 1;
        }
        if (it.breaking) it.severity = Math.min(3, it.severity + 1);
        if (it.sources.size() >= 4) it.severity = Math.min(3, it.severity + 1);   // many outlets = big story
        // listing on a top exchange is big
        if (it.catKey.equals("list") && (tlow.contains("binance") || tlow.contains("coinbase") || tlow.contains("upbit"))) it.severity = 3;
        it.macro = it.catKey.startsWith("macro");
        explain(it);
    }

    static void explain(Item it) {
        String who = !it.coins.isEmpty() ? String.join(", ", it.coins) : !it.exchanges.isEmpty() ? String.join(", ", it.exchanges) : "market";
        String ex = it.exchanges.isEmpty() ? "" : it.exchanges.get(0);
        switch (it.catKey) {
            case "hack":
                it.impact = "Hack ki khabar par mutasira " + (ex.isEmpty() ? "project ka coin (" + who + ")" : ex + " aur us ke token") + " aksar foran 5–30% girta hai. "
                        + "Poori market mein dar phailta hai, log exchanges se coins nikalte hain. Agar chori shuda coins bechay jayein to mazeed dabao.";
                it.action = (ex.isEmpty() ? "" : "Agar " + ex + " par aap ke funds hain to official update dekhein aur zaroorat ho to withdraw karein. ")
                        + "Mutasira coin mein naya BUY na lein jab tak project official bayan na de. Bot is coin ke BUY signals 2 ghante rok deta hai.";
                break;
            case "halt":
                it.impact = "Withdrawals ya network ruk jaye to us exchange/chain par bharosa kam hota hai; price aksar girti hai aur doosre exchanges par farq (premium/discount) ban jata hai.";
                it.action = "Is exchange par trading/naye deposit se bachein. Official status page dekhein.";
                break;
            case "depeg":
                it.impact = "Stablecoin ka $1 se hatna poori market ke liye khatarnak hai — DeFi mein liquidations aur panic selling ho sakti hai.";
                it.action = "Us stablecoin se nikal kar mazboot stablecoin (USDT/USDC) ya cash mein jayen. Leverage kam karein.";
                break;
            case "bankrupt":
                it.impact = "Bankruptcy / collapse se jure coins mein bari giraawat aur poori market mein dar (FTX 2022 jaisa) ho sakta hai.";
                it.action = "Mutasira platform se funds nikalein, us ke token se door rahein, leverage band.";
                break;
            case "delist":
                it.impact = "Delisting ki khabar par coin aksar 20–50% girta hai kyun ke liquidity khatam hoti hai.";
                it.action = "Agar " + who + " hold kar rahe hain to deadline se pehle bechne/transfer ka faisla karein. Naya BUY nahi.";
                break;
            case "etfneg":
                it.impact = "ETF se paisa nikalna = institutions bech rahi hain. Kai din lagataar ho to BTC/ETH par dabao.";
                it.action = "Spot mein naya bara BUY rokein; support levels par nazar rakhen.";
                break;
            case "reg":
                it.impact = "Lawsuit / pabandi / tehqeeqat ki khabar se mutasira coin (" + who + ") aur exchange par dabao aata hai; faisla aane tak volatility.";
                it.action = "Position chhoti rakhein, stop-loss lazmi. Official faisla aur asal tafseel parhein.";
                break;
            case "liqlong":
                it.impact = "Bari tadaad mein long liquidations = neeche ka jhatka. Aksar is ke baad thori der mein bounce bhi aata hai (leverage saaf ho jata hai).";
                it.action = "Girti price mein foran BUY na karein; support par stability aur volume ka intezar karein.";
                break;
            case "liqshort":
                it.impact = "Short squeeze = shorts majboori mein khareedte hain, price tez upar jaati hai.";
                it.action = "Late entry se bachein; pullback/retest par entry behtar.";
                break;
            case "unlock":
                it.impact = "Token unlock se naye coins market mein aate hain — supply barhti hai, aksar unlock se pehle aur baad price par dabao.";
                it.action = "Unlock ki tareekh aur miqdaar dekhein (total supply ka kitna %). Bara unlock ho to BUY se pehle intezar.";
                break;
            case "whaleout":
                it.impact = "Whale ka coins exchange par bhejna aksar bechne ki tayyari hoti hai — mukhtasir muddat ka dabao.";
                it.action = "Is coin mein naya long chhota rakhein; order book mein bari sell walls dekhein.";
                break;
            case "macroneg":
                it.impact = "Sakht Fed / mehngai / tariff ki khabar se dollar mazboot aur crypto, gold, stocks par dabao.";
                it.action = "Leverage kam karein, bari news ke 30 min aas paas naya trade na lein.";
                break;
            case "macropos":
                it.impact = "Rate cut / narm Fed / kam mehngai = sasta paisa — crypto aur gold ke liye aam tor par bullish.";
                it.action = "Trend ke saath rahein; news ke foran baad ka pehla move aksar fake hota hai, 15–30 min intezar.";
                break;
            case "macro":
                it.impact = "US macro news (Fed, CPI, jobs) poori market ko hilati hai — asal figure forecast se upar/neeche hone par tez move.";
                it.action = "News & Calendar tab mein forecast dekhein; release se pehle naye trade se bachein.";
                break;
            case "etfpos":
                it.impact = "ETF approval / inflow = institutions ka paisa aa raha hai — " + who + " ke liye mazboot bullish.";
                it.action = "Pullback par BUY ka mauqa dhoondein; 'sell the news' bhi ho sakta hai, is liye stop-loss ke saath.";
                break;
            case "list":
                it.impact = "Bare exchange (Binance/Coinbase/Upbit) par listing se coin aksar foran 20–100% upar jaata hai, phir aksar wapas aata hai.";
                it.action = "Listing ke foran baad ki pump mein FOMO entry na karein; pehli candle ke baad retest ka intezar. Pehle se hold ho to kuch profit lein.";
                break;
            case "treasury":
                it.impact = "Company / institution ki khareed = lambay arsay ki demand. Bari khareed BTC/ETH ko sahara deti hai.";
                it.action = "Spot holders ke liye achha ishara; short se bachein.";
                break;
            case "regpos":
                it.impact = "Achhi regulation / case khatam hona = bharosa barhta hai, naya paisa aa sakta hai — " + who + " ke liye bullish.";
                it.action = "Trend ke saath BUY, magar 'sell the news' ka khayal — stop-loss lagayen.";
                break;
            case "partner":
                it.impact = "Partnership / adoption aam tor par halki bullish khabar hai; asar khabar ki bulandi par depend karta hai.";
                it.action = "Sirf khabar par BUY nahi — chart aur volume se confirm karein.";
                break;
            case "upgrade":
                it.impact = "Mainnet / upgrade se pehle aksar price barhti hai ('buy the rumor'), launch ke din 'sell the news' bhi hota hai.";
                it.action = "Tareekh qareeb ho to profit lene ka plan banayen.";
                break;
            case "burn":
                it.impact = "Burn / buyback se supply kam hoti hai — halki bullish.";
                it.action = "Miqdaar dekhein: total supply ke muqable mein chhota burn ka asar kam hota hai.";
                break;
            case "airdrop":
                it.impact = "Airdrop se pehle demand, aur milne ke baad log bechte hain — airdrop ke baad aksar dabao.";
                it.action = "Airdrop token milte hi bari bikwali ka khayal rakhen.";
                break;
            case "pumpw":
                it.impact = who + " mein tez upar ka move report ho raha hai. Momentum hai, magar khabar aane tak move ka bara hissa ho chuka hota hai.";
                it.action = "Peeche bhaag kar BUY na karein; pullback / EMA21 retest par dekhein.";
                break;
            case "dumpw":
                it.impact = who + " mein giraawat report ho rahi hai. Wajah dhoondein (hack? macro? unlock?) — wajah ke baghair girawat aksar jaldi recover ho jaati hai.";
                it.action = "Girti chhuri na pakrein; support par stability ka intezar.";
                break;
            default:
                it.impact = "Aam khabar — market par seedha bara asar ka imkaan kam.";
                it.action = "Maloomat ke liye; chart aur signals ke saath milayen.";
        }
    }

    public static String dirLabel(Item it) {
        return it.dir > 0 ? "🟢 BULLISH" : it.dir < 0 ? "🔴 BEARISH" : "⚪ NEUTRAL";
    }

    public static String sevLabel(Item it) {
        return it.severity >= 3 ? "🚨 CRITICAL" : it.severity == 2 ? "⚠️ Important" : "ℹ️ Normal";
    }

    /** Recent strong BEARISH news about a coin (used to block BUY signals). */
    public static Item criticalBearish(String base, long withinMs) {
        long now = System.currentTimeMillis();
        for (Item it : cache) {
            if (now - it.time > withinMs) break;
            if (it.dir < 0 && it.severity >= 3 && it.coins.contains(base)) return it;
        }
        return null;
    }

    /**
     * News score for one coin from the radar: every story about it in the last `within` ms, weighted by
     * severity, how many outlets carried it, and how recent it is. Returns {score -100..100, stories}.
     */
    public static int[] coinScore(String base, long within) {
        long now = System.currentTimeMillis();
        double sum = 0, w = 0;
        int n = 0;
        for (Item it : cache) {
            if (now - it.time > within) break;
            if (!it.coins.contains(base)) continue;
            double age = (now - it.time) / 3_600_000.0;
            double decay = Math.exp(-age / 6.0);                       // half weight after ~4h
            double weight = it.severity * it.severity * (1 + Math.min(4, it.sources.size() - 1) * 0.25) * decay;
            sum += it.dir * weight;
            w += weight;
            n++;
        }
        if (n == 0) return new int[]{0, 0};
        double sc = w > 0 ? sum / w : 0;                                // -1..1 net tone
        double strength = Math.min(1, w / 6.0);                         // a single small story counts little
        return new int[]{(int) Math.round(Math.max(-100, Math.min(100, sc * strength * 100))), n};
    }

    /** Market-wide danger: a critical bearish story about a big exchange, a stablecoin, or the whole market. */
    public static Item marketRisk(long within) {
        long now = System.currentTimeMillis();
        for (Item it : cache) {
            if (now - it.time > within) break;
            if (it.dir >= 0 || it.severity < 3) continue;
            boolean exch = !it.exchanges.isEmpty() && (it.catKey.equals("hack") || it.catKey.equals("halt") || it.catKey.equals("bankrupt"));
            boolean stable = it.catKey.equals("depeg") || it.coins.contains("USDT") || it.coins.contains("USDC");
            boolean big = it.sources.size() >= 3 && (it.coins.contains("BTC") || it.coins.contains("ETH") || it.coins.isEmpty());
            if (exch || stable || big) return it;
        }
        return null;
    }

    /** Recent news mentioning a coin. */
    public static List<Item> about(String base, long withinMs, int max) {
        List<Item> out = new ArrayList<>();
        long now = System.currentTimeMillis();
        for (Item it : cache) {
            if (now - it.time > withinMs) break;
            if (it.coins.contains(base)) out.add(it);
            if (out.size() >= max) break;
        }
        return out;
    }

    // ------------------------------------------------------------------ background radar + notifications
    public static void tick(Context ctx) {
        if (!Prefs.newsOn(ctx)) return;
        List<Item> l = fetch(ctx, 45_000L);
        long now = System.currentTimeMillis();
        Set<String> seen = new LinkedHashSet<>(java.util.Arrays.asList(Prefs.getStr(ctx, "newsseen", "").split("\\|")));
        boolean first = seen.size() <= 1;   // first run: just remember what is already there
        int minSev = Prefs.newsMinSev(ctx), sent = 0;
        for (Item it : l) {
            String key = String.valueOf(it.title.toLowerCase(Locale.US).hashCode());
            if (seen.contains(key)) continue;
            seen.add(key);
            if (first || now - it.time > 45 * 60_000L) continue;
            if (it.severity < minSev || sent >= 4) continue;
            if (!Notify.allowed(ctx, Prefs.N_NEWS)) continue;
            notifyItem(ctx, it);
            sent++;
        }
        List<String> keep = new ArrayList<>(seen);
        if (keep.size() > 600) keep = keep.subList(keep.size() - 600, keep.size());
        Prefs.putStr(ctx, "newsseen", String.join("|", keep));
    }

    static void notifyItem(Context ctx, Item it) {
        ScannerService.createChannels(ctx);
        Intent open = new Intent(ctx, MainActivity.class);
        open.putExtra("news", it.title);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int id = ("news" + it.title).hashCode();
        PendingIntent pi = PendingIntent.getActivity(ctx, id, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String coins = it.coins.isEmpty() ? "" : " · " + String.join(", ", it.coins);
        String title = (it.severity >= 3 ? "🚨 " : "📰 ") + it.category + " · " + dirLabel(it) + coins;
        String body = it.title + "\n\n🧠 Asar: " + it.impact + "\n👉 " + it.action + "\n— " + it.source
                + (it.sources.size() > 1 ? " +" + (it.sources.size() - 1) + " aur sources" : "");
        Notification n = new Notification.Builder(ctx, Scanner.CH_SIGNALS)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(it.title)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setContentIntent(pi)
                .setColor(it.dir > 0 ? 0xFF0ECB81 : it.dir < 0 ? 0xFFF6465D : 0xFFF0B90B)
                .setAutoCancel(true)
                .build();
        ((NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE)).notify(id, n);
    }

    /** Price reaction of a coin after the news time: {price at news, +5m %, +15m %, +1h %, now %} (NaN = not yet). */
    public static double[] reaction(String base, long t) throws Exception {
        Candles c = Candles.parse(Scanner.get("/api/v3/klines?symbol=" + base + "USDT&interval=1m&startTime=" + (t - 60_000L) + "&limit=70"), false);
        double[] r = {Double.NaN, Double.NaN, Double.NaN, Double.NaN, Double.NaN};
        if (c.n == 0) return r;
        double p0 = c.open[0];
        r[0] = p0;
        int[] mins = {5, 15, 60};
        for (int k = 0; k < 3; k++) if (c.n > mins[k] + 1) r[k + 1] = (c.close[mins[k] + 1] / p0 - 1) * 100;
        JSONObject now = new JSONObject(Scanner.get("/api/v3/ticker/price?symbol=" + base + "USDT"));
        r[4] = (now.optDouble("price", p0) / p0 - 1) * 100;
        return r;
    }

    public static Map<String, Integer> categoryCounts(List<Item> l) {
        Map<String, Integer> m = new HashMap<>();
        for (Item it : l) m.put(it.category, m.getOrDefault(it.category, 0) + 1);
        return m;
    }
}
