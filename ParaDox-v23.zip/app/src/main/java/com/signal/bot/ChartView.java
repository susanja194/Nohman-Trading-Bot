package com.signal.bot;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * LIVE trading chart. Candles update every second from the WebSocket, whale trades drop onto the
 * candle they happen in, and the analysis is drawn on top: Fibonacci, trendlines + pattern box +
 * projected arrow, S/R zones, volume profile, whale/retail markers, candle patterns, EMA20/50, VWAP,
 * entry/stop/target lines, buy/sell volume and an RSI panel with divergence.
 *
 * Gestures: drag = scroll back in time · pinch = zoom · press & hold = crosshair with candle details.
 */
public class ChartView extends View {
    private static final int UP = 0xFF089981, DOWN = 0xFFF23645, GRID = 0xFF1C2335, TXT = 0xFF9AA4B5,
            EMA20 = 0xFF22D3EE, EMA50 = 0xFFA855F7, VWAP = 0xFFFF8A3D, WHITE = 0xFFE8EAED;
    private static final int[] FIB_COL = {0xFF9CA3AF, 0xFFF6465D, 0xFF9BE15D, 0xFF22C55E, 0xFF14B8A6, 0xFF3B82F6, 0xFF9CA3AF};
    private static final int FUTURE = 14;
    /** Empty space on the right for projections (bigger when the analysis plan is drawn). */
    private int fut() { return scenOn ? Math.max(FUTURE, (int) Math.round(visible * 0.38)) : FUTURE; }

    private Candles data;
    private PatternEngine.Result pat;
    private double[] ema20, ema50, vwap, wBuy, wSell;
    private String tf = "1h";
    private double visible = 90, offset = 0;
    private int touchIdx = -1, accent = 0xFFA855F7;
    private boolean fib = true, lines = true, zones = true, vp = true, whales = true, rsiOn = true, vwapOn;
    // TradingView-style options
    private boolean showEma = true, showEma200, showBB, showVol = true, retail, compact;
    // v11: moving-average ribbon (9/21/50/100/200), golden/death cross labels, ParaDox rule arrows
    private boolean ribbon, crossesOn = true, ruleOn = true, stOn, ichOn, arrowsOn;
    private int[] combo, comboExit;
    private double[] stLine;
    private boolean[] stUp;
    private double[][] ich;
    private double[] ema9, ema21, ema100;
    private final List<int[]> crossList = new ArrayList<>();
    private final List<int[]> ruleList = new ArrayList<>();
    private float touchY = -1;
    private static final int[] RIB_COL = {0xFFFFC94D, 0xFF22D3EE, 0xFFA855F7, 0xFFFF8A3D, 0xFFE8EAED};
    private int lower = 1;          // 0 none · 1 RSI · 2 MACD
    private int chartType = 0;      // 0 candles · 1 line · 2 Heikin Ashi
    private double[] ema200, bbU, bbL, bbM, haO, haH, haL, haC;
    private Runnable tapListener;
    // drawings (stored by time so they survive new candles)
    private final java.util.List<double[]> hLines = new java.util.ArrayList<>();
    private final java.util.List<double[]> tLines = new java.util.ArrayList<>();
    private int drawMode;           // 0 none · 1 horizontal line · 2 trendline
    private double[] pendingPt;
    private boolean planOn, planBuy;
    private double pEntry, pSl, pTp1, pTp2;
    private double prevPrice;
    private long flashUntil;
    private int flashColor;
    private String message = "Chart load ho raha hai...";
    private String liveText = "";
    private final float d;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), stroke = new Paint(Paint.ANTI_ALIAS_FLAG),
            text = new Paint(Paint.ANTI_ALIAS_FLAG), dash = new Paint(Paint.ANTI_ALIAS_FLAG), grid = new Paint();

    public ChartView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        stroke.setStyle(Paint.Style.STROKE);
        dash.setStyle(Paint.Style.STROKE);
        dash.setPathEffect(new DashPathEffect(new float[]{6 * d, 4 * d}, 0));
        grid.setColor(GRID);
        grid.setStrokeWidth(1);
        text.setTextSize(10 * d);
    }

    // ------------------------------------------------------------ public API
    public void setMessage(String m) {
        message = m;
        data = null;
        invalidate();
    }

    public void setAccent(int c) { accent = c; invalidate(); }

    private String title = "";

    /** Symbol shown in the chart header, e.g. "BTC/USDT". */
    public void setTitle(String t) { title = t == null ? "" : t; invalidate(); }

    // ---------------- TradingView-style API
    public static final String[] TYPES = {"Candles", "Line", "Heikin Ashi"};

    /** Embedded charts: a quick tap calls this (e.g. open full screen). Null = tap shows candle details. */
    public void setOnTap(Runnable r) { tapListener = r; }

    /** Compact = embedded card (less text on the chart). */
    public void setCompact(boolean c) { compact = c; invalidate(); }

    public boolean ind(String k) {
        switch (k) {
            case "EMA": return showEma;
            case "EMA200": return showEma200;
            case "VWAP": return vwapOn;
            case "BB": return showBB;
            case "Volume": return showVol;
            case "RSI": return lower == 1;
            case "MACD": return lower == 2;
            case "Fib": return fib;
            case "Patterns": return lines;
            case "Zones": return zones;
            case "VolProfile": return vp;
            case "Whales": return whales;
            case "Retail": return retail;
            case "MA Ribbon": return ribbon;
            case "Crosses": return crossesOn;
            case "ParaDox": return ruleOn;
            case "Supertrend": return stOn;
            case "Arrows": return arrowsOn;
            case "Ichimoku": return ichOn;
            default: return false;
        }
    }

    public void setInd(String k, boolean on) {
        switch (k) {
            case "EMA": showEma = on; break;
            case "EMA200": showEma200 = on; break;
            case "VWAP": vwapOn = on; break;
            case "BB": showBB = on; break;
            case "Volume": showVol = on; break;
            case "RSI": lower = on ? 1 : (lower == 1 ? 0 : lower); break;
            case "MACD": lower = on ? 2 : (lower == 2 ? 0 : lower); break;
            case "Fib": fib = on; break;
            case "Patterns": lines = on; break;
            case "Zones": zones = on; break;
            case "VolProfile": vp = on; break;
            case "Whales": whales = on; break;
            case "Retail": retail = on; break;
            case "MA Ribbon": ribbon = on; break;
            case "Crosses": crossesOn = on; break;
            case "ParaDox": ruleOn = on; break;
            case "Supertrend": stOn = on; break;
            case "Arrows": arrowsOn = on; break;
            case "Ichimoku": ichOn = on; break;
            default: break;
        }
        rsiOn = lower != 0;
        invalidate();
    }

    public String cycleType() {
        chartType = (chartType + 1) % 3;
        if (data != null) recalc();
        invalidate();
        return TYPES[chartType];
    }

    public int getType() { return chartType; }

    public void setType(int t) {
        chartType = Math.max(0, Math.min(2, t));
        if (data != null) recalc();
        invalidate();
    }

    /** 0 off · 1 horizontal line · 2 trendline (tap 2 points). */
    public void setDrawMode(int m) {
        drawMode = m;
        pendingPt = null;
        invalidate();
    }

    public int getDrawMode() { return drawMode; }

    public void clearDrawings() {
        hLines.clear();
        tLines.clear();
        pendingPt = null;
        invalidate();
    }

    public void setLayers(boolean fib, boolean lines, boolean zones, boolean vp, boolean whales, boolean rsi) {
        this.fib = fib; this.lines = lines; this.zones = zones; this.vp = vp; this.whales = whales;
        if (!rsi && lower == 1) lower = 0;
        if (rsi && lower == 0) lower = 1;
        this.rsiOn = lower != 0;
        invalidate();
    }

    /** How many candles fit on screen (e.g. show the whole history for 1Y / ALL). */
    public void setVisible(int n) {
        visible = Math.max(15, Math.min(1000, n));
        invalidate();
    }

    // news / event marker (vertical line at a time)
    private long eventT;
    private String eventLabel = "";

    public void setEvent(long t, String label) {
        eventT = t;
        eventLabel = label == null ? "" : label;
        invalidate();
    }

    public void zoom(int delta) {
        visible = Math.max(20, Math.min(1000, visible + delta));
        invalidate();
    }

    /** Jump back to the newest candle. */
    public void goLive() {
        offset = 0;
        invalidate();
    }

    public boolean isLive() { return offset < 0.5; }

    public void setLiveText(String s) {
        liveText = s == null ? "" : s;
        invalidate();
    }

    public Candles getData() { return data; }

    public void setData(Candles c, PatternEngine.Result p, double[] whaleBuy, double[] whaleSell, String tf, boolean showVwap) {
        data = c;
        pat = p;
        wBuy = whaleBuy;
        wSell = whaleSell;
        this.tf = tf;
        vwapOn = showVwap;
        offset = 0;
        manualY = false;   // a new coin / timeframe always starts auto-scaled (old scale could hide every candle)
        prevPrice = c.n > 0 ? c.close[c.n - 1] : 0;
        recalc();
        touchIdx = -1;
        invalidate();
    }

    public void setPatterns(PatternEngine.Result p) {
        pat = p;
        invalidate();
    }

    /** Applies updated/shifted candles from the live stream. */
    public void liveCandles(Candles c) {
        if (data == null || c == null) return;
        if (c != data) {
            // a new candle opened -> shift whale arrays and keep the view still if user scrolled back
            wBuy = shift(wBuy);
            wSell = shift(wSell);
            if (pat != null) pat = shiftPattern(pat);
            if (offset >= 0.5) offset += 1;
            data = c;
        }
        double last = data.close[data.n - 1];
        if (prevPrice > 0 && last != prevPrice) {
            flashColor = last > prevPrice ? UP : DOWN;
            flashUntil = System.currentTimeMillis() + 450;
        }
        prevPrice = last;
        recalc();
        invalidate();
    }

    /** A live trade: if it is a whale trade add it to the candle it belongs to. */
    public void liveTrade(long t, double usd, boolean sell) {
        if (data == null || wBuy == null) return;
        int idx = data.indexOf(t);
        if (idx < 0 || idx >= wBuy.length) return;
        if (sell) wSell[idx] += usd; else wBuy[idx] += usd;
    }

    // retest / entry zone shading
    private double zLo, zHi;
    private String zLabel = "";
    private int zColor;

    public void setZone(double lo, double hi, String label, int color) {
        zLo = Math.min(lo, hi);
        zHi = Math.max(lo, hi);
        zLabel = label == null ? "" : label;
        zColor = color;
        invalidate();
    }

    // TradingView-style manual price scale
    private boolean manualY;
    private double yMax, yMin;

    /** Back to automatic price scale and newest candles. */
    public void resetView() {
        manualY = false;
        offset = 0;
        invalidate();
    }

    // ---- analysis scenario: "where to buy and how far it can go"
    private boolean scenOn, scenBuy;
    private String scenType = "";
    private double scenPx, scenLevel, scenT1, scenT2;

    /**
     * Draws the bot's plan into the future area of the chart:
     * NOW = buy here → target range · RETEST / PULLBACK = wait for price to come back to `level`, then up to target ·
     * BREAKOUT = wait for a close above `level`, then target · HEAVY_SELL = selling path down.
     */
    public void setScenario(boolean on, String type, boolean buy, double price, double level, double t1, double t2) {
        scenOn = on && price > 0 && t1 > 0;
        scenType = type == null ? "" : type;
        scenBuy = buy;
        scenPx = price;
        scenLevel = level;
        scenT1 = t1;
        scenT2 = t2 > 0 ? t2 : t1;
        invalidate();
    }

    public void setPlan(boolean on, boolean buy, double entry, double sl, double tp1, double tp2) {
        planOn = on; planBuy = buy; pEntry = entry; pSl = sl; pTp1 = tp1; pTp2 = tp2;
        invalidate();
    }

    private static double[] shift(double[] a) {
        if (a == null) return null;
        double[] b = new double[a.length];
        System.arraycopy(a, 1, b, 0, a.length - 1);
        return b;
    }

    /** Patterns are index based; after a shift the indices move left by one. */
    private static PatternEngine.Result shiftPattern(PatternEngine.Result p) {
        if (p.crowd != null && p.crowd.length > 1) {
            int[] c = new int[p.crowd.length];
            System.arraycopy(p.crowd, 1, c, 0, c.length - 1);
            p.crowd = c;
        }
        if (p.rsi != null && p.rsi.length > 1) {
            double[] r = new double[p.rsi.length];
            System.arraycopy(p.rsi, 1, r, 0, r.length - 1);
            r[r.length - 1] = r[r.length - 2];
            p.rsi = r;
        }
        p.shift++;
        return p;
    }

    private void recalc() {
        Candles c = data;
        ema20 = Indicators.ema(c.close, 20);
        ema50 = Indicators.ema(c.close, 50);
        ema200 = Indicators.ema(c.close, 200);
        ema9 = Indicators.ema(c.close, 9);
        ema21 = Indicators.ema(c.close, 21);
        ema100 = Indicators.ema(c.close, 100);
        crossList.clear();
        ruleList.clear();
        if (c.n > 20) {
            Object[] st = IndicatorPack.supertrend(c, 10, 3);
            stLine = (double[]) st[0];
            stUp = (boolean[]) st[1];
            ich = IndicatorPack.ichimoku(c);
        }
        if (c.n > 40) {
            Candles closed = c.closedOnly();
            int[] a = ArrowLab.arrows(closed, 3), ex = ArrowLab.exits(closed, a);
            combo = new int[c.n];
            comboExit = new int[c.n];
            System.arraycopy(a, 0, combo, 0, Math.min(a.length, c.n));
            System.arraycopy(ex, 0, comboExit, 0, Math.min(ex.length, c.n));
        }
        if (c.n > 60) {
            for (int i = 1; i < c.n - 1; i++) {     // closed candles only
                if (i >= 200) {
                    double g0 = ema50[i - 1] - ema200[i - 1], g1 = ema50[i] - ema200[i];
                    if (g0 <= 0 && g1 > 0) crossList.add(new int[]{i, 1});
                    if (g0 >= 0 && g1 < 0) crossList.add(new int[]{i, -1});
                }
                double f0 = ema9[i - 1] - ema21[i - 1], f1 = ema9[i] - ema21[i];
                if (f0 <= 0 && f1 > 0) crossList.add(new int[]{i, 2});
                if (f0 >= 0 && f1 < 0) crossList.add(new int[]{i, -2});
            }
            try {
                ParadoxRule.Ind x = ParadoxRule.prepare(c);
                int last = -10;
                for (int i = 60; i < c.n - 1; i++) {
                    int sg = ParadoxRule.signalAt(x, i);
                    if (sg != 0 && i - last > 3) { ruleList.add(new int[]{i, sg}); last = i; }
                }
            } catch (Exception ignored) {
            }
        }
        bbU = new double[c.n];
        bbL = new double[c.n];
        bbM = new double[c.n];
        for (int i = 0; i < c.n; i++) {
            int f = Math.max(0, i - 19);
            double m = 0;
            for (int k = f; k <= i; k++) m += c.close[k];
            m /= (i - f + 1);
            double v = 0;
            for (int k = f; k <= i; k++) v += (c.close[k] - m) * (c.close[k] - m);
            double sd = Math.sqrt(v / (i - f + 1));
            bbM[i] = m;
            bbU[i] = m + 2 * sd;
            bbL[i] = m - 2 * sd;
        }
        haO = new double[c.n];
        haH = new double[c.n];
        haL = new double[c.n];
        haC = new double[c.n];
        for (int i = 0; i < c.n; i++) {
            haC[i] = (c.open[i] + c.high[i] + c.low[i] + c.close[i]) / 4;
            haO[i] = i == 0 ? (c.open[i] + c.close[i]) / 2 : (haO[i - 1] + haC[i - 1]) / 2;
            haH[i] = Math.max(c.high[i], Math.max(haO[i], haC[i]));
            haL[i] = Math.min(c.low[i], Math.min(haO[i], haC[i]));
        }
        vwap = new double[c.n];
        double pv = 0, vv = 0;
        long day = -1;
        for (int i = 0; i < c.n; i++) {
            long dd = c.time[i] / 86_400_000L;
            if (dd != day) { day = dd; pv = 0; vv = 0; }
            double tp = (c.high[i] + c.low[i] + c.close[i]) / 3;
            pv += tp * c.vol[i];
            vv += c.vol[i];
            vwap[i] = vv > 0 ? pv / vv : tp;
        }
    }

    // ------------------------------------------------------------ geometry
    private float top, priceBottom, volTop, volBottom, rsiTop, rsiBottom, plotW, cw;
    private int start, end, sh;
    private double max, min, range;

    private float rightPad() { return 60 * d; }
    private float x(double i) { return (float) ((i - start) * cw + cw / 2); }
    private float y(double v) { return (float) (top + (max - v) / range * (priceBottom - top)); }
    /** pattern index -> current data index */
    private int pi(int i) { return i - sh; }

    private void layout(float w, float h) {
        top = 32 * d;
        float axisH = 14 * d, gap = 6 * d;
        rsiOn = lower != 0;
        float rsiH = rsiOn ? h * 0.15f : 0;
        rsiBottom = h - axisH;
        rsiTop = rsiBottom - rsiH;
        // TradingView style: volume sits INSIDE the price pane (bottom 18%), price scale leaves room for it
        priceBottom = rsiOn ? rsiTop - gap : rsiBottom - 2 * d;
        volBottom = priceBottom;
        volTop = priceBottom - (priceBottom - top) * 0.18f;
        plotW = w - rightPad();
        int vis = (int) Math.min(Math.round(visible), data.n);
        offset = Math.max(0, Math.min(offset, data.n - Math.min(vis, data.n)));
        end = data.n - (int) Math.round(offset);
        start = Math.max(0, end - vis);
        boolean live = offset < 0.5;
        cw = plotW / (vis + (live ? fut() : 2));
        sh = pat == null ? 0 : pat.shift;
        max = -Double.MAX_VALUE;
        min = Double.MAX_VALUE;
        for (int i = start; i < end; i++) {
            max = Math.max(max, data.high[i]);
            min = Math.min(min, data.low[i]);
        }
        double r0 = Math.max(max - min, max * 0.002);
        if (live && scenOn) {   // keep the plan's levels on screen (within reason)
            for (double v : new double[]{scenLevel, scenT1, scenT2}) {
                if (v <= 0) continue;
                if (v > max && v < max + r0 * 0.9) max = v;
                if (v < min && v > min - r0 * 0.9) min = v;
            }
        }
        if (live && pat != null && pat.target > 0 && lines) {
            if (pat.target > max && pat.target < max + r0 * 0.6) max = pat.target;
            if (pat.target < min && pat.target > min - r0 * 0.6) min = pat.target;
        }
        range = Math.max(max - min, max * 0.002);
        double dataHi = max, dataLo = min;
        max += range * 0.06;
        min -= range * (showVol ? 0.26 : 0.06);   // candles stay above the volume bars
        range = max - min;
        // a stale manual scale that no longer shows any candle is dropped automatically
        if (manualY && (yMax <= yMin || yMin > dataHi || yMax < dataLo || (yMax - yMin) > (dataHi - dataLo) * 60 || (yMax - yMin) < (dataHi - dataLo) / 200)) manualY = false;
        if (manualY && yMax > yMin) {
            max = yMax;
            min = yMin;
            range = max - min;
        } else {
            yMax = max;
            yMin = min;
        }
    }

    private void paint(Paint p, int color, float width) {
        p.setColor(color);
        p.setStrokeWidth(width);
    }

    private void label(Canvas cv, String s, float x, float y, int color, float size, boolean bold) {
        text.setColor(color);
        text.setTextSize(size * d);
        text.setFakeBoldText(bold);
        cv.drawText(s, x, y, text);
        text.setFakeBoldText(false);
        text.setTextSize(10 * d);
    }

    private void tag(Canvas cv, String s, float x, float y, int bg, int fg) {
        text.setTextSize(9.5f * d);
        text.setFakeBoldText(true);
        float tw = text.measureText(s);
        fill.setColor(bg);
        cv.drawRoundRect(new RectF(x, y - 7 * d, x + tw + 6 * d, y + 7 * d), 3 * d, 3 * d, fill);
        text.setColor(fg);
        cv.drawText(s, x + 3 * d, y + 3.5f * d, text);
        text.setFakeBoldText(false);
        text.setTextSize(10 * d);
    }

    // ------------------------------------------------------------ draw
    @Override
    protected void onDraw(Canvas cv) {
        super.onDraw(cv);
        float w = getWidth(), h = getHeight();
        if (data == null || data.n < 2) {
            label(cv, message, 12 * d, h / 2, TXT, 12, false);
            return;
        }
        layout(w, h);
        boolean live = offset < 0.5;

        // price axis: round "nice" levels like TradingView (about one every 45dp)
        int want = Math.max(4, (int) ((priceBottom - top) / (45 * d)));
        double step = niceStep(range / want);
        int guard = 0;
        for (double v = Math.ceil(min / step) * step; v <= max && guard++ < 60; v += step) {
            float yy = y(v);
            if (yy < top + 4 * d || yy > priceBottom - 2 * d) continue;
            cv.drawLine(0, yy, plotW, yy, grid);
            label(cv, Fmt.price(v), plotW + 5 * d, yy + 3.5f * d, TXT, 9.5f, false);
        }
        // vertical grid at the time-axis labels
        for (int gi : timeTicks()) cv.drawLine(x(gi), top, x(gi), priceBottom, grid);
        if (showVol) drawVolume(cv);

        if (pat != null && zones) drawZones(cv);
        if (pat != null && vp) drawVolumeProfile(cv);
        if (pat != null && fib) drawFib(cv);
        if (zHi > 0) drawZone(cv);
        if (showBB) {
            drawSeries(cv, bbU, 0x9938BDF8, 1f);
            drawSeries(cv, bbL, 0x9938BDF8, 1f);
            drawSeries(cv, bbM, 0x5538BDF8, 0.8f);
        }
        if (ichOn && ich != null) drawIchimoku(cv, live);
        drawCandles(cv);
        if (stOn && stLine != null) drawSupertrend(cv);
        if (ichOn && ich != null) {
            drawSeries(cv, ich[0], 0xFF2962FF, 1.1f);   // tenkan
            drawSeries(cv, ich[1], 0xFFB71C1C, 1.3f);   // kijun
        }
        if (showEma) {
            drawSeries(cv, ema20, EMA20, 1.4f);
            drawSeries(cv, ema50, EMA50, 1.4f);
        }
        if (showEma200) drawSeries(cv, ema200, 0xFFE8EAED, 1.6f);
        if (ribbon) {
            double[][] rb = {ema9, ema21, ema50, ema100, ema200};
            float[] wd = {1.1f, 1.3f, 1.5f, 1.5f, 1.8f};
            for (int k = 0; k < 5; k++) drawSeries(cv, rb[k], RIB_COL[k], wd[k]);
        }
        if (crossesOn) drawCrosses(cv);
        if (eventT > 0) {
            int ei = data.indexOf(eventT);
            if (ei >= start && ei < end) {
                paint(dash, 0xFFF0B90B, 1.5f * d);
                cv.drawLine(x(ei), top, x(ei), priceBottom, dash);
                tag(cv, eventLabel, Math.min(plotW - 60 * d, x(ei) + 3 * d), top + 8 * d, 0xDDF0B90B, 0xFF0A0E17);
            }
        }
        if (ruleOn) drawRule(cv);
        if (arrowsOn && combo != null) drawArrows(cv);
        if (vwapOn) drawSeries(cv, vwap, VWAP, 1.2f);
        drawDrawings(cv);
        if (pat != null && lines) drawPattern(cv, live);
        if (planOn) drawPlan(cv);
        if (scenOn && live) drawScenario(cv);
        if (whales) drawWhales(cv);
        if (pat != null) drawCandleMarks(cv);

        // live price line + flashing price tag
        double lp = data.close[data.n - 1];
        float ly = y(lp);
        if (ly >= top && ly <= priceBottom) {
            paint(dash, 0xAAF0B90B, 1);
            cv.drawLine(0, ly, plotW, ly, dash);
        }
        boolean upC = data.close[data.n - 1] >= data.open[data.n - 1];
        int tagCol = System.currentTimeMillis() < flashUntil ? flashColor : (upC ? UP : DOWN);
        float tagY = Math.max(top, Math.min(priceBottom, ly));
        tag(cv, Fmt.price(lp), plotW + 1 * d, tagY, tagCol, 0xFFFFFFFF);
        if (System.currentTimeMillis() < flashUntil) postInvalidateDelayed(120);

        // countdown to candle close
        long ms = tfMillis(tf);
        if (ms > 0 && live) {
            long left = data.time[data.n - 1] + ms - System.currentTimeMillis();
            if (left > 0) label(cv, countdown(left), plotW + 4 * d, tagY + 18 * d, TXT, 8.5f, false);
        }

        if (lower == 1 && pat != null && pat.rsi != null) drawRsi(cv);
        else if (lower == 1) drawRsiPlain(cv);
        else if (lower == 2) drawMacd(cv);
        drawTimeAxis(cv, h);
        drawLegend(cv, live);
        if (touchIdx < 0) drawOhlc(cv);
        if (manualY) label(cv, "↕ 2x tap = auto", plotW + 2 * d, top - 4 * d, 0xFFFFC94D, 7.5f, true);
        if (touchIdx >= start && touchIdx < end) drawTouch(cv, w);
    }

    static long tfMillis(String tf) {
        try {
            long n = Long.parseLong(tf.substring(0, tf.length() - 1));
            char u = tf.charAt(tf.length() - 1);
            if (u == 'm') return n * 60_000L;
            if (u == 'h') return n * 3_600_000L;
            if (u == 'd') return n * 86_400_000L;
            if (u == 'w') return n * 7 * 86_400_000L;
        } catch (Exception ignored) {
        }
        return 0;
    }

    private static String countdown(long ms) {
        long s = ms / 1000;
        if (s >= 3600) return String.format(Locale.US, "%dh%02dm", s / 3600, (s % 3600) / 60);
        return String.format(Locale.US, "%02d:%02d", s / 60, s % 60);
    }

    private void drawZones(Canvas cv) {
        double hw = Math.max(pat.atr * 0.3, range * 0.006);
        for (PatternEngine.Zone z : pat.zones) {
            float y1 = y(z.price + hw), y2 = y(z.price - hw);
            if (y2 < top || y1 > priceBottom) continue;
            fill.setColor(z.support ? 0x2A0ECB81 : 0x2AF6465D);
            cv.drawRect(0, Math.max(top, y1), plotW, Math.min(priceBottom, y2), fill);
            tag(cv, (z.support ? "S " : "R ") + z.touches + "x  " + Fmt.price(z.price), 2 * d, (y1 + y2) / 2,
                    z.support ? 0xCC0B5E44 : 0xCC7A1F2B, 0xFFFFFFFF);
        }
    }

    private void drawVolumeProfile(Canvas cv) {
        if (pat.vpBuy == null) return;
        int bins = pat.vpBuy.length;
        double mx = 0;
        for (int b = 0; b < bins; b++) mx = Math.max(mx, pat.vpBuy[b] + pat.vpSell[b]);
        if (mx <= 0) return;
        float vpW = plotW * 0.22f;
        double step = (pat.vpHi - pat.vpLo) / bins;
        for (int b = 0; b < bins; b++) {
            float y1 = y(pat.vpLo + (b + 1) * step), y2 = y(pat.vpLo + b * step);
            if (y2 < top || y1 > priceBottom) continue;
            float lb = (float) (pat.vpBuy[b] / mx * vpW), ls = (float) (pat.vpSell[b] / mx * vpW);
            float yy1 = y1 + 0.6f * d, yy2 = Math.max(yy1 + 1, y2 - 0.6f * d);
            fill.setColor(b == pat.poc ? 0x9938BDF8 : 0x5538BDF8);
            cv.drawRect(plotW - lb, yy1, plotW, yy2, fill);
            fill.setColor(b == pat.poc ? 0x99F0B90B : 0x55F0B90B);
            cv.drawRect(plotW - lb - ls, yy1, plotW - lb, yy2, fill);
        }
        if (pat.poc >= 0) {
            double pp = pat.vpLo + (pat.poc + 0.5) * step;
            float yy = y(pp);
            if (yy >= top && yy <= priceBottom) {
                paint(dash, 0x99F0B90B, 1);
                cv.drawLine(0, yy, plotW, yy, dash);
                label(cv, "POC", plotW - vpW - 22 * d, yy - 2 * d, 0xFFF0B90B, 9, true);
            }
        }
    }

    private void drawFib(Canvas cv) {
        if (!pat.hasFib) return;
        double hi = pat.fibHi, lo = pat.fibLo, rng = hi - lo;
        int from = Math.max(start, pi(Math.min(pat.fibHiIdx, pat.fibLoIdx)));
        if (from >= end) return;
        float x0 = x(from);
        for (int k = 0; k < PatternEngine.FIB.length; k++) {
            double r = PatternEngine.FIB[k];
            double pr = pat.fibUp ? hi - rng * r : lo + rng * r;
            float yy = y(pr);
            if (yy < top || yy > priceBottom) continue;
            paint(stroke, (FIB_COL[k] & 0x00FFFFFF) | 0xAA000000, 1.1f * d);
            cv.drawLine(x0, yy, plotW, yy, stroke);
            label(cv, String.format(Locale.US, "%s(%s)", trimFib(r), Fmt.price(pr)), x0 + 2 * d, yy - 2 * d, FIB_COL[k], 9, false);
        }
        double a = pat.fibUp ? hi - rng * 0.5 : lo + rng * 0.5, b = pat.fibUp ? hi - rng * 0.618 : lo + rng * 0.618;
        fill.setColor(0x1A14B8A6);
        cv.drawRect(x0, Math.max(top, Math.min(y(a), y(b))), plotW, Math.min(priceBottom, Math.max(y(a), y(b))), fill);
    }

    private static String trimFib(double r) {
        if (r == 0) return "0";
        if (r == 1) return "1";
        String s = String.format(Locale.US, "%.3f", r);
        while (s.endsWith("0")) s = s.substring(0, s.length() - 1);
        return s;
    }

    private void drawCandles(Canvas cv) {
        if (chartType == 1) {
            Path pth = new Path();
            for (int i = start; i < end; i++) {
                if (i == start) pth.moveTo(x(i), y(data.close[i])); else pth.lineTo(x(i), y(data.close[i]));
            }
            paint(stroke, accent, 2 * d);
            cv.drawPath(pth, stroke);
            return;
        }
        boolean ha = chartType == 2 && haC != null;
        double[] O = ha ? haO : data.open, H = ha ? haH : data.high, L = ha ? haL : data.low, C = ha ? haC : data.close;
        float half = Math.max(1, cw * 0.36f);
        for (int i = start; i < end; i++) {
            float xx = x(i);
            boolean up = C[i] >= O[i];
            int col = up ? UP : DOWN;
            if (i == data.n - 1 && System.currentTimeMillis() < flashUntil) col = flashColor;
            fill.setColor(col);
            paint(stroke, col, Math.max(1, 1.1f * d));
            cv.drawLine(xx, y(H[i]), xx, y(L[i]), stroke);
            float yo = y(O[i]), yc = y(C[i]);
            float bt = Math.min(yo, yc), bb = Math.max(Math.max(yo, yc), bt + 1.2f * d);
            cv.drawRect(xx - half, bt, xx + half, bb, fill);
        }
    }

    private void drawSeries(Canvas cv, double[] e, int color, float width) {
        if (e == null) return;
        Path path = new Path();
        boolean first = true;
        for (int i = start; i < end && i < e.length; i++) {
            float yy = y(e[i]);
            if (yy < top || yy > priceBottom) { first = true; continue; }
            if (first) { path.moveTo(x(i), yy); first = false; } else path.lineTo(x(i), yy);
        }
        paint(stroke, color, width * d);
        cv.drawPath(path, stroke);
    }

    private void drawPattern(Canvas cv, boolean live) {
        int lastI = data.n - 1;
        float xEnd = live ? x(lastI + FUTURE - 1) : plotW;
        if (pat.res != null) drawTrend(cv, pat.res, 0xFFF6465D, xEnd);
        if (pat.sup != null) drawTrend(cv, pat.sup, 0xFF0ECB81, xEnd);

        if (pat.divType != 0 && pi(pat.divA) >= start && pi(pat.divB) < end) {
            boolean bull = pat.divType > 0;
            int a = pi(pat.divA), b = pi(pat.divB);
            double pa = bull ? data.low[a] : data.high[a], pb = bull ? data.low[b] : data.high[b];
            paint(stroke, bull ? 0xFF9BE15D : 0xFFFF8A3D, 1.6f * d);
            cv.drawLine(x(a), y(pa), x(b), y(pb), stroke);
        }

        int bias = pat.bias;
        int col = bias > 0 ? UP : DOWN;
        if (live && pat.target > 0 && bias != 0) {
            float x1 = x(lastI), y1 = y(data.close[lastI]);
            float x2 = x(lastI + FUTURE - 3), y2 = Math.max(top + 4 * d, Math.min(priceBottom - 4 * d, y(pat.target)));
            paint(dash, col, 2 * d);
            Path p = new Path();
            p.moveTo(x1, y1);
            p.lineTo(x2, y2);
            cv.drawPath(p, dash);
            paint(stroke, col, 2 * d);
            double ang = Math.atan2(y2 - y1, x2 - x1);
            float hl = 8 * d;
            cv.drawLine(x2, y2, (float) (x2 - hl * Math.cos(ang - 0.45)), (float) (y2 - hl * Math.sin(ang - 0.45)), stroke);
            cv.drawLine(x2, y2, (float) (x2 - hl * Math.cos(ang + 0.45)), (float) (y2 - hl * Math.sin(ang + 0.45)), stroke);
            tag(cv, "🎯 " + Fmt.price(pat.target), Math.min(x2 - 20 * d, plotW - 70 * d), y2 + (bias > 0 ? -11 : 11) * d, col, 0xFF0A0E17);
        }

        List<String> ls = new ArrayList<>();
        ls.add(pat.name);
        if (!compact) ls.addAll(wrap(pat.note, plotW * 0.62f));
        text.setTextSize(10 * d);
        float bw = 0;
        for (String s : ls) bw = Math.max(bw, text.measureText(s));
        bw += 12 * d;
        float bh = ls.size() * 13 * d + 8 * d;
        float bx = 6 * d, by = top + 18 * d;
        fill.setColor(0xE6141B2B);
        RectF box = new RectF(bx, by, bx + bw, by + bh);
        cv.drawRoundRect(box, 8 * d, 8 * d, fill);
        paint(stroke, col, 1.5f * d);
        cv.drawRoundRect(box, 8 * d, 8 * d, stroke);
        for (int i = 0; i < ls.size(); i++) {
            label(cv, ls.get(i), bx + 6 * d, by + 15 * d + i * 13 * d, i == 0 ? col : WHITE, i == 0 ? 11 : 9.5f, i == 0);
        }
    }

    private List<String> wrap(String s, float maxW) {
        List<String> out = new ArrayList<>();
        if (s == null || s.isEmpty()) return out;
        text.setTextSize(9.5f * d);
        StringBuilder line = new StringBuilder();
        for (String word : s.split(" ")) {
            String t = line.length() == 0 ? word : line + " " + word;
            if (text.measureText(t) > maxW && line.length() > 0) {
                out.add(line.toString());
                line = new StringBuilder(word);
                if (out.size() == 2) break;
            } else {
                line = new StringBuilder(t);
            }
        }
        if (out.size() < 3 && line.length() > 0) out.add(line.toString());
        text.setTextSize(10 * d);
        return out;
    }

    private void drawTrend(Canvas cv, PatternEngine.Line l, int color, float xEnd) {
        int i1 = pi(l.i1), i2 = pi(l.i2);
        int i0 = Math.max(start, i1);
        double endIdx = (xEnd - cw / 2) / cw + start;
        // line value at data index j = l.at(j + sh)
        float x1 = x(i0), y1 = y(l.at(i0 + sh)), x2 = xEnd, y2 = y(l.at(endIdx + sh));
        paint(stroke, color, 2 * d);
        cv.drawLine(x1, y1, x2, y2, stroke);
        fill.setColor(color);
        if (i1 >= start && i1 < end) cv.drawCircle(x(i1), y(l.p1), 3 * d, fill);
        if (i2 >= start && i2 < end) cv.drawCircle(x(i2), y(l.p2), 3 * d, fill);
    }

    private void drawZone(Canvas cv) {
        float y1 = y(zHi), y2 = y(zLo);
        if (y2 < top || y1 > priceBottom) return;
        y1 = Math.max(top, y1);
        y2 = Math.min(priceBottom, Math.max(y1 + 2 * d, y2));
        fill.setColor((zColor & 0x00FFFFFF) | 0x33000000);
        cv.drawRect(0, y1, plotW, y2, fill);
        paint(dash, zColor, 1.2f * d);
        cv.drawLine(0, y1, plotW, y1, dash);
        cv.drawLine(0, y2, plotW, y2, dash);
        if (!zLabel.isEmpty()) tag(cv, zLabel, plotW * 0.35f, (y1 + y2) / 2, (zColor & 0x00FFFFFF) | 0xDD000000, 0xFF0A0E17);
    }

    private void drawScenario(Canvas cv) {
        float xs = x(data.n - 1);
        float xe = Math.min(plotW - 4 * d, xs + (fut() - 1) * cw);
        if (xe - xs < 20 * d) return;
        int col = scenBuy ? UP : DOWN;
        boolean wait = scenType.equals("RETEST") || scenType.equals("PULLBACK") || scenType.equals("BREAKOUT");
        // target range box
        float ty1 = y(Math.max(scenT1, scenT2)), ty2 = y(Math.min(scenT1, scenT2));
        if (ty2 - ty1 < 6 * d) { ty1 -= 3 * d; ty2 += 3 * d; }
        float bx = xs + (xe - xs) * 0.55f;
        fill.setColor((col & 0x00FFFFFF) | 0x30000000);
        cv.drawRect(bx, Math.max(top, ty1), xe, Math.min(priceBottom, ty2), fill);
        paint(stroke, (col & 0x00FFFFFF) | 0xAA000000, 1 * d);
        cv.drawRect(bx, Math.max(top, ty1), xe, Math.min(priceBottom, ty2), stroke);
        // path
        Path path = new Path();
        float y0 = y(scenPx);
        path.moveTo(xs, y0);
        float lx = 0, ly = 0;
        if (wait && scenLevel > 0) {
            float x1 = xs + (xe - xs) * 0.3f, y1 = y(scenLevel);
            path.lineTo(x1, y1);
            lx = x1;
            ly = y1;
        }
        float x2 = bx + (xe - bx) * 0.5f, y2 = y((scenT1 + scenT2) / 2);
        path.lineTo(x2, y2);
        paint(stroke, col, 2.2f * d);
        stroke.setPathEffect(new DashPathEffect(new float[]{8 * d, 5 * d}, 0));
        cv.drawPath(path, stroke);
        stroke.setPathEffect(null);
        // arrow head
        float px = wait && scenLevel > 0 ? lx : xs, py = wait && scenLevel > 0 ? ly : y0;
        double ang = Math.atan2(y2 - py, x2 - px);
        Path head = new Path();
        float hs = 8 * d;
        head.moveTo(x2, y2);
        head.lineTo((float) (x2 - hs * Math.cos(ang - 0.45)), (float) (y2 - hs * Math.sin(ang - 0.45)));
        head.lineTo((float) (x2 - hs * Math.cos(ang + 0.45)), (float) (y2 - hs * Math.sin(ang + 0.45)));
        head.close();
        fill.setColor(col);
        cv.drawPath(head, fill);
        // level marker
        if (wait && scenLevel > 0 && ly >= top && ly <= priceBottom) {
            paint(dash, 0xFFFFC94D, 1.6f * d);
            cv.drawLine(Math.max(0, xs - 120 * d), ly, xe, ly, dash);
            fill.setColor(0xFFFFC94D);
            cv.drawCircle(lx, ly, 4 * d, fill);
            String t = scenType.equals("BREAKOUT") ? "🚀 " + Fmt.price(scenLevel) + " ke upar close = " + (scenBuy ? "BUY" : "SELL")
                    : "⏳ " + Fmt.price(scenLevel) + " par " + (scenBuy ? "BUY" : "SELL") + " (retest)";
            tag(cv, t, Math.max(2 * d, Math.min(plotW - 150 * d, xs - 150 * d)), ly - 11 * d, 0xEEFFC94D, 0xFF0A0E17);
        } else if (y0 >= top && y0 <= priceBottom) {
            tag(cv, scenType.equals("HEAVY_SELL") ? "🚨 HEAVY SELLING" : (scenBuy ? "✅ ABHI BUY zone" : "✅ ABHI SELL zone"),
                    Math.max(2 * d, xs - 110 * d), y0 + (scenBuy ? 14 : -14) * d, (col & 0x00FFFFFF) | 0xEE000000, 0xFF0A0E17);
        }
        String rt = "🎯 " + Fmt.price(Math.min(scenT1, scenT2)) + " – " + Fmt.price(Math.max(scenT1, scenT2));
        float tyy = scenBuy ? Math.max(top + 8 * d, ty1 - 9 * d) : Math.min(priceBottom - 4 * d, ty2 + 11 * d);
        text.setTextSize(9.5f * d);
        float tw = text.measureText(rt) + 8 * d;
        text.setTextSize(10 * d);
        tag(cv, rt, Math.max(bx - tw * 0.4f, Math.min(xe - tw, bx)), tyy, (col & 0x00FFFFFF) | 0xEE000000, 0xFF0A0E17);
    }

    private double pTp3, pTp4;
    private String[] tpNames = {"TP1", "TP2", "TP3", "TP4"};

    /** Extra spot targets (TP3 / TP4) and their labels, e.g. "TP1 · 1 din". */
    public void setMoreTargets(double tp3, double tp4, String[] labels) {
        pTp3 = tp3;
        pTp4 = tp4;
        if (labels != null && labels.length == 4) {
            for (int i = 0; i < 4; i++) tpNames[i] = "TP" + (i + 1) + (labels[i] == null || labels[i].isEmpty() ? "" : " · " + labels[i]);
        }
        invalidate();
    }

    private void drawPlan(Canvas cv) {
        double[] v = {pEntry, pSl, pTp1, pTp2, pTp3, pTp4};
        String[] n = {planBuy ? "BUY" : "SELL", "SL", tpNames[0], tpNames[1], tpNames[2], tpNames[3]};
        int[] c = {accent, DOWN, UP, UP, 0xFF16A34A, 0xFF15803D};
        float xs = Math.min(x(data.n - 1), plotW - 95 * d);
        for (int k = 0; k < 6; k++) {
            if (v[k] <= 0) continue;
            float yy = y(v[k]);
            if (yy < top || yy > priceBottom) continue;
            paint(dash, c[k], 1.4f * d);
            cv.drawLine(Math.max(0, xs - 40 * d), yy, plotW, yy, dash);
            String tt = n[k] + " " + Fmt.price(v[k]);
            text.setTextSize(9.5f * d);
            float tw = text.measureText(tt) + 8 * d;
            text.setTextSize(10 * d);
            tag(cv, tt, plotW - Math.max(92 * d, tw), yy, c[k], 0xFF0A0E17);
        }
    }

    private void drawWhales(Canvas cv) {
        double mx = 0;
        if (wBuy != null) for (int i = start; i < end && i < wBuy.length; i++) mx = Math.max(mx, Math.max(wBuy[i], wSell[i]));
        int bigI = -1;
        double big = 0;
        boolean bigBuy = true;
        for (int i = start; i < end; i++) {
            float xx = x(i);
            float yl = y(data.low[i]) + 7 * d, yh = y(data.high[i]) - 7 * d;
            int cr = pat != null && pat.crowd != null && i < pat.crowd.length ? pat.crowd[i] : 0;
            boolean exact = false;
            if (wBuy != null && i < wBuy.length && mx > 0) {
                if (wBuy[i] > 0) {
                    float r = (float) Math.max(2.5 * d, Math.sqrt(wBuy[i] / mx) * Math.max(cw, 6 * d) * 0.9);
                    fill.setColor(0xCC0ECB81);
                    cv.drawCircle(xx, yl + r, r, fill);
                    paint(stroke, 0xFFFFFFFF, 1);
                    cv.drawCircle(xx, yl + r, r, stroke);
                    exact = true;
                    if (wBuy[i] > big) { big = wBuy[i]; bigI = i; bigBuy = true; }
                }
                if (wSell[i] > 0) {
                    float r = (float) Math.max(2.5 * d, Math.sqrt(wSell[i] / mx) * Math.max(cw, 6 * d) * 0.9);
                    fill.setColor(0xCCF6465D);
                    cv.drawCircle(xx, yh - r, r, fill);
                    paint(stroke, 0xFFFFFFFF, 1);
                    cv.drawCircle(xx, yh - r, r, stroke);
                    exact = true;
                    if (wSell[i] > big) { big = wSell[i]; bigI = i; bigBuy = false; }
                }
            }
            if (!exact) {
                if (cr == 2) label(cv, "W", xx - 3 * d, yl + 7 * d, UP, 9, true);
                else if (cr == -2) label(cv, "W", xx - 3 * d, yh, DOWN, 9, true);
            }
            if (!retail) continue;
            if (cr == 1) { fill.setColor(0xCC38BDF8); cv.drawCircle(xx, yl + (exact ? 14 : 3) * d, 1.8f * d, fill); }
            else if (cr == -1) { fill.setColor(0xCCFF8A3D); cv.drawCircle(xx, yh - (exact ? 14 : 3) * d, 1.8f * d, fill); }
        }
        if (bigI >= 0 && big > 0) {
            float yy = bigBuy ? y(data.low[bigI]) + 30 * d : y(data.high[bigI]) - 26 * d;
            tag(cv, "🐋 " + (bigBuy ? "BUY " : "SELL ") + Fmt.usd(big), Math.min(x(bigI) - 20 * d, plotW - 90 * d),
                    Math.max(top + 8 * d, Math.min(priceBottom - 8 * d, yy)), bigBuy ? 0xDD0B5E44 : 0xDD7A1F2B, 0xFFFFFFFF);
        }
    }

    private void drawCandleMarks(Canvas cv) {
        for (PatternEngine.Mark m : pat.marks) {
            int i = pi(m.idx);
            if (i < start || i >= end) continue;
            float xx = x(i);
            if (m.side > 0) label(cv, m.label, xx - 12 * d, y(data.low[i]) + 22 * d, 0xFF9BE15D, 8, true);
            else label(cv, m.label, xx - 12 * d, y(data.high[i]) - 16 * d, 0xFFFF8A3D, 8, true);
        }
    }

    private void drawVolume(Canvas cv) {
        double mv = 0;
        for (int i = start; i < end; i++) mv = Math.max(mv, data.vol[i]);
        if (mv <= 0) return;
        float half = Math.max(1, cw * 0.36f), vh = volBottom - volTop;
        for (int i = start; i < end; i++) {
            float xx = x(i);
            float total = (float) (data.vol[i] / mv * vh);
            fill.setColor(data.close[i] >= data.open[i] ? 0x66089981 : 0x66F23645);
            cv.drawRect(xx - half, volBottom - total, xx + half, volBottom, fill);
        }
        int li = Math.min(end, data.n) - 1;
        if (li >= 0) label(cv, "Vol " + Fmt.num(data.quoteVol[li] > 0 ? data.quoteVol[li] : data.vol[li]), 4 * d, volTop + 9 * d,
                data.close[li] >= data.open[li] ? UP : DOWN, 8.5f, false);
    }

    private void drawRsi(Canvas cv) {
        float h = rsiBottom - rsiTop;
        cv.drawLine(0, rsiTop - 3 * d, plotW, rsiTop - 3 * d, grid);
        float y70 = rsiTop + h * 0.3f, y30 = rsiTop + h * 0.7f, y50 = rsiTop + h * 0.5f;
        paint(stroke, 0x55F6465D, 1);
        cv.drawLine(0, y70, plotW, y70, stroke);
        paint(stroke, 0x550ECB81, 1);
        cv.drawLine(0, y30, plotW, y30, stroke);
        paint(dash, 0x33FFFFFF, 1);
        cv.drawLine(0, y50, plotW, y50, dash);
        label(cv, "70", plotW + 4 * d, y70 + 3 * d, DOWN, 9, false);
        label(cv, "30", plotW + 4 * d, y30 + 3 * d, UP, 9, false);
        // live RSI from current candles
        double[] rsi = Indicators.rsi(data.close, 14);
        Path p = new Path();
        boolean first = true;
        for (int i = Math.max(start, 14); i < end; i++) {
            float yy = rsiTop + (float) ((100 - rsi[i]) / 100.0 * h);
            if (first) { p.moveTo(x(i), yy); first = false; } else p.lineTo(x(i), yy);
        }
        paint(stroke, accent, 1.5f * d);
        cv.drawPath(p, stroke);
        label(cv, String.format(Locale.US, "RSI %.0f", rsi[Math.max(0, end - 1)]), 3 * d, rsiTop + 9 * d, accent, 9, true);
        int a = pi(pat.divA), b = pi(pat.divB);
        if (pat.divType != 0 && a >= start && b < end && b >= 0) {
            boolean bull = pat.divType > 0;
            paint(stroke, bull ? 0xFF9BE15D : 0xFFFF8A3D, 1.8f * d);
            float ya = rsiTop + (float) ((100 - rsi[a]) / 100.0 * h), yb = rsiTop + (float) ((100 - rsi[b]) / 100.0 * h);
            cv.drawLine(x(a), ya, x(b), yb, stroke);
            label(cv, bull ? "Bull div" : "Bear div", x(b) + 4 * d, yb, bull ? 0xFF9BE15D : 0xFFFF8A3D, 9, true);
        }
    }

    private void drawRsiPlain(Canvas cv) {
        PatternEngine.Result keep = pat;
        PatternEngine.Result tmp = new PatternEngine.Result();
        tmp.rsi = new double[0];
        pat = tmp;
        drawRsi(cv);
        pat = keep;
    }

    private void drawMacd(Canvas cv) {
        float h = rsiBottom - rsiTop;
        cv.drawLine(0, rsiTop - 3 * d, plotW, rsiTop - 3 * d, grid);
        double[] fast = Indicators.ema(data.close, 12), slow = Indicators.ema(data.close, 26);
        double[] line = new double[data.n];
        for (int i = 0; i < data.n; i++) line[i] = fast[i] - slow[i];
        double[] sig = Indicators.ema(line, 9);
        double mx = 1e-12;
        for (int i = start; i < end; i++) mx = Math.max(mx, Math.max(Math.abs(line[i]), Math.abs(line[i] - sig[i])));
        float mid = rsiTop + h / 2;
        paint(dash, 0x33FFFFFF, 1);
        cv.drawLine(0, mid, plotW, mid, dash);
        float half = Math.max(1, cw * 0.32f);
        for (int i = start; i < end; i++) {
            double hv = line[i] - sig[i];
            float yy = mid - (float) (hv / mx * h / 2);
            fill.setColor(hv >= 0 ? 0x990ECB81 : 0x99F6465D);
            cv.drawRect(x(i) - half, Math.min(mid, yy), x(i) + half, Math.max(mid, yy), fill);
        }
        Path a = new Path(), b = new Path();
        for (int i = start; i < end; i++) {
            float ya = mid - (float) (line[i] / mx * h / 2), yb = mid - (float) (sig[i] / mx * h / 2);
            if (i == start) { a.moveTo(x(i), ya); b.moveTo(x(i), yb); } else { a.lineTo(x(i), ya); b.lineTo(x(i), yb); }
        }
        paint(stroke, 0xFF38BDF8, 1.4f * d);
        cv.drawPath(a, stroke);
        paint(stroke, 0xFFFF8A3D, 1.2f * d);
        cv.drawPath(b, stroke);
        label(cv, "MACD 12 26 9", 3 * d, rsiTop + 9 * d, 0xFF38BDF8, 9, true);
    }

    private float xt(double t) {
        int i = data.indexOf((long) t);
        if (i < 0) i = 0;
        double frac = 0;
        long step = tfMillis(tf);
        if (step > 0) frac = (t - data.time[i]) / step;
        return x(i + frac);
    }

    private void drawDrawings(Canvas cv) {
        for (double[] h : hLines) {
            float yy = y(h[0]);
            if (yy < top || yy > priceBottom) continue;
            paint(stroke, 0xFFFFC94D, 1.4f * d);
            cv.drawLine(0, yy, plotW, yy, stroke);
            tag(cv, Fmt.price(h[0]), plotW - 70 * d, yy, 0xDDFFC94D, 0xFF0A0E17);
        }
        for (double[] t : tLines) {
            float x1 = xt(t[0]), y1 = y(t[1]), x2 = xt(t[2]), y2 = y(t[3]);
            if (Math.abs(x2 - x1) < 1) continue;
            float xe = plotW;
            float ye = y1 + (y2 - y1) * (xe - x1) / (x2 - x1);
            paint(stroke, 0xFF22D3EE, 1.6f * d);
            cv.drawLine(x1, y1, xe, ye, stroke);
            fill.setColor(0xFF22D3EE);
            cv.drawCircle(x1, y1, 3 * d, fill);
            cv.drawCircle(x2, y2, 3 * d, fill);
        }
        if (pendingPt != null) {
            fill.setColor(0xFFFFC94D);
            cv.drawCircle(xt(pendingPt[0]), y(pendingPt[1]), 4 * d, fill);
        }
    }

    private double priceAt(float yPos) {
        return max - (yPos - top) / (priceBottom - top) * range;
    }

    private double timeAt(float xPos) {
        double idx = (xPos - cw / 2) / cw + start;
        int i = (int) Math.floor(idx);
        long step = tfMillis(tf);
        if (i >= 0 && i < data.n) return data.time[i] + (idx - i) * step;
        if (i >= data.n) return data.time[data.n - 1] + (idx - (data.n - 1)) * step;
        return data.time[0];
    }

    /** Places a drawing point; returns true if handled. */
    private boolean placeDrawing(float xPos, float yPos) {
        if (drawMode == 0 || yPos < top || yPos > priceBottom || xPos > plotW) return false;
        double p = priceAt(yPos), t = timeAt(xPos);
        if (drawMode == 1) {
            hLines.add(new double[]{p});
            drawMode = 0;
        } else if (pendingPt == null) {
            pendingPt = new double[]{t, p};
        } else {
            tLines.add(new double[]{pendingPt[0], pendingPt[1], t, p});
            pendingPt = null;
            drawMode = 0;
        }
        invalidate();
        return true;
    }

    /** Candle indexes for time labels: ~ every 80dp, snapped to round times (hour / day / month / year boundaries). */
    private List<Integer> timeTicks() {
        List<Integer> out = new ArrayList<>();
        if (data == null || end - start < 2 || cw <= 0) return out;
        int every = Math.max(1, (int) Math.ceil(80 * d / cw));
        int last = -every;
        java.util.Calendar c = java.util.Calendar.getInstance();
        int prevKey = -1;
        for (int i = start; i < end; i++) {
            c.setTimeInMillis(data.time[i]);
            int key = unitKey(c);
            boolean boundary = prevKey != -1 && key != prevKey;
            prevKey = key;
            if (boundary && i - last >= every) { out.add(i); last = i; }
        }
        if (out.size() < 2) {   // fallback: evenly spaced
            out.clear();
            for (int i = start + every / 2; i < end; i += every) out.add(i);
        }
        return out;
    }

    private int unitKey(java.util.Calendar c) {
        long ms = tfMillis(tf);
        if (tf.equals("1M") || ms >= 7 * 86_400_000L) return c.get(java.util.Calendar.YEAR) * 100 + (tf.equals("1M") ? 0 : c.get(java.util.Calendar.MONTH) / 3);
        if (ms >= 86_400_000L) return c.get(java.util.Calendar.YEAR) * 100 + c.get(java.util.Calendar.MONTH);
        if (ms >= 3_600_000L) return c.get(java.util.Calendar.DAY_OF_YEAR);
        if (ms >= 15 * 60_000L) return c.get(java.util.Calendar.HOUR_OF_DAY) / 3 + c.get(java.util.Calendar.DAY_OF_YEAR) * 10;
        return c.get(java.util.Calendar.HOUR_OF_DAY) + c.get(java.util.Calendar.DAY_OF_YEAR) * 100;
    }

    private void drawTimeAxis(Canvas cv, float h) {
        long ms = tfMillis(tf);
        java.util.Calendar c = java.util.Calendar.getInstance();
        for (int i : timeTicks()) {
            c.setTimeInMillis(data.time[i]);
            String f;
            if (tf.equals("1M") || ms >= 7 * 86_400_000L) f = c.get(java.util.Calendar.MONTH) == 0 || tf.equals("1M") ? "yyyy" : "MMM yy";
            else if (ms >= 86_400_000L) f = c.get(java.util.Calendar.MONTH) == 0 ? "yyyy" : "MMM";
            else if (ms >= 3_600_000L) f = c.get(java.util.Calendar.DAY_OF_MONTH) == 1 ? "MMM" : "d MMM";
            else f = c.get(java.util.Calendar.HOUR_OF_DAY) == 0 && c.get(java.util.Calendar.MINUTE) == 0 ? "d MMM" : "HH:mm";
            String s2 = new SimpleDateFormat(f, Locale.US).format(new Date(data.time[i]));
            text.setTextSize(8.5f * d);
            float tw = text.measureText(s2);
            text.setTextSize(10 * d);
            float xx = Math.max(0, Math.min(plotW - tw, x(i) - tw / 2));
            label(cv, s2, xx, h - 3 * d, TXT, 8.5f, false);
        }
    }

    static double niceStep(double raw) {
        if (raw <= 0 || Double.isNaN(raw) || Double.isInfinite(raw)) return 1;
        double p = Math.pow(10, Math.floor(Math.log10(raw)));
        double f = raw / p;
        double n = f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10;
        return n * p;
    }

    private void drawLegend(Canvas cv, boolean live) {
        float xx = 4 * d, yy = 27 * d;
        String[] n = {showEma ? "EMA20" : null, showEma ? "EMA50" : null, showEma200 ? "EMA200" : null, vwapOn ? "VWAP" : null, showBB ? "BB" : null};
        int[] c = {EMA20, EMA50, 0xFFE8EAED, VWAP, 0xFF38BDF8};
        for (int k = 0; k < n.length; k++) {
            if (n[k] == null) continue;
            label(cv, n[k], xx, yy, c[k], 9f, true);
            xx += (n[k].length() * 6.5f + 8) * d;
        }
        if (drawMode != 0) {
            label(cv, drawMode == 1 ? "✏ H-line: chart par tap karein" : (pendingPt == null ? "✏ Trendline: pehla point tap" : "✏ Trendline: doosra point tap"),
                    xx, yy, 0xFFFFC94D, 9, true);
            return;
        }
        if (!live) label(cv, "⏪ purana data dekh rahe hain · ⏩ Live dabayen", xx, yy, 0xFFFFC94D, 9, true);
        else if (!liveText.isEmpty()) label(cv, liveText, xx, yy, liveText.startsWith("●") ? UP : 0xFFFFC94D, 9, true);
    }

    private void drawTouch(Canvas cv, float w) {
        int i = touchIdx;
        paint(stroke, 0x88FFFFFF, 1);
        cv.drawLine(x(i), top, x(i), rsiBottom, stroke);
        double chg = data.open[i] > 0 ? (data.close[i] / data.open[i] - 1) * 100 : 0;
        double bp = data.vol[i] > 0 ? data.takerBuy[i] / data.vol[i] * 100 : 50;
        String when = new SimpleDateFormat("dd MMM HH:mm", Locale.US).format(new Date(data.time[i]));
        StringBuilder s = new StringBuilder(when).append("  O ").append(Fmt.price(data.open[i]))
                .append(" H ").append(Fmt.price(data.high[i])).append(" L ").append(Fmt.price(data.low[i]))
                .append(" C ").append(Fmt.price(data.close[i]))
                .append(String.format(Locale.US, "  %+.2f%%  Buy %.0f%%", chg, bp));
        int cr = pat != null && pat.crowd != null && i < pat.crowd.length ? pat.crowd[i] : 0;
        String extra = "";
        if (wBuy != null && i < wBuy.length && (wBuy[i] > 0 || wSell[i] > 0))
            extra = "🐋 Whale buy " + Fmt.usd(wBuy[i]) + " · sell " + Fmt.usd(wSell[i]);
        else if (cr == 2) extra = "W: is candle mein bade (whale) buyers";
        else if (cr == -2) extra = "W: is candle mein bade (whale) sellers";
        else if (cr == 1) extra = "Retail crowd khareed raha tha";
        else if (cr == -1) extra = "Retail crowd bech raha tha";
        extra += (extra.isEmpty() ? "" : " · ") + "Volume " + Fmt.usd(data.quoteVol[i]) + " · " + (long) data.trades[i] + " trades";
        fill.setColor(0xF0141B2B);
        cv.drawRect(0, 0, w, 31 * d, fill);
        label(cv, s.toString(), 4 * d, 12.5f * d, WHITE, 9.5f, false);
        label(cv, extra, 4 * d, 26 * d, 0xFFF0B90B, 9.5f, true);
        float yy = touchY >= top && touchY <= priceBottom ? touchY : y(data.close[i]);
        if (yy >= top && yy <= priceBottom) {
            paint(dash, 0x88FFFFFF, 1);
            cv.drawLine(0, yy, plotW, yy, dash);
            double pv = max - (yy - top) / (priceBottom - top) * range;
            tag(cv, Fmt.price(pv), plotW + 1 * d, yy, 0xFF2B3550, 0xFFFFFFFF);   // price under the finger (axis label)
        }
        boolean intraday = tf.endsWith("m") || tf.endsWith("h");
        String tl = new SimpleDateFormat(intraday ? "dd MMM HH:mm" : "dd MMM yyyy", Locale.US).format(new Date(data.time[i]));
        text.setTextSize(9.5f * d);
        float tw = text.measureText(tl);
        text.setTextSize(10 * d);
        float tx = Math.max(0, Math.min(plotW - tw - 6 * d, x(i) - tw / 2));
        tag(cv, tl, tx, rsiBottom + 7 * d, 0xFF2B3550, 0xFFFFFFFF);       // time label on the time axis
    }

    /** TradingView-style OHLC line of the newest candle (always visible). */
    private void drawOhlc(Canvas cv) {
        int i = data.n - 1;
        double chg = data.open[i] > 0 ? (data.close[i] / data.open[i] - 1) * 100 : 0;
        int col = data.close[i] >= data.open[i] ? UP : DOWN;
        String s = "O " + Fmt.price(data.open[i]) + "  H " + Fmt.price(data.high[i]) + "  L " + Fmt.price(data.low[i])
                + "  C " + Fmt.price(data.close[i]) + String.format(Locale.US, "  %+.2f%%", chg);
        float xx0 = 4 * d;
        if (!title.isEmpty()) {
            String tt = title + " · " + tf;
            label(cv, tt, xx0, 13 * d, 0xFFE8EAED, 9.5f, true);
            text.setTextSize(9.5f * d);
            xx0 += text.measureText(tt) + 8 * d;
            text.setTextSize(10 * d);
        }
        label(cv, compact ? "C " + Fmt.price(data.close[i]) + String.format(Locale.US, "  %+.2f%%", chg) : s, xx0, 13 * d, col, 9f, false);
        if (ribbon) {
            String[] nm = {"9", "21", "50", "100", "200"};
            float xx = plotW - 5 * 22 * d;
            for (int k = 0; k < 5; k++) {
                label(cv, nm[k], xx, 27 * d, RIB_COL[k], 8.5f, true);
                xx += 22 * d;
            }
        }
    }

    /** MACD + MA + RSI arrows (▲ BUY / ▼ SELL) and their exit points (✕). */
    private void drawArrows(Canvas cv) {
        for (int i = start; i < end && i < combo.length; i++) {
            float xx = x(i);
            if (combo[i] != 0) {
                boolean b = combo[i] > 0;
                float yy = b ? y(data.low[i]) + 22 * d : y(data.high[i]) - 22 * d;
                if (yy < top || yy > priceBottom + 8 * d) continue;
                Path tri = new Path();
                float sz = 6 * d;
                if (b) { tri.moveTo(xx, yy - sz); tri.lineTo(xx - sz, yy + sz); tri.lineTo(xx + sz, yy + sz); }
                else { tri.moveTo(xx, yy + sz); tri.lineTo(xx - sz, yy - sz); tri.lineTo(xx + sz, yy - sz); }
                tri.close();
                fill.setColor(b ? 0xFF2962FF : 0xFFFF6D00);
                cv.drawPath(tri, fill);
                label(cv, b ? "B" : "S", xx - 3 * d, b ? yy + sz + 9 * d : yy - sz - 2 * d, b ? 0xFF2962FF : 0xFFFF6D00, 8, true);
            }
            if (comboExit[i] != 0) {
                float yy = y(data.close[i]);
                if (yy < top || yy > priceBottom) continue;
                paint(stroke, 0xFFE8EAED, 1.6f * d);
                float sz = 4 * d;
                cv.drawLine(xx - sz, yy - sz, xx + sz, yy + sz, stroke);
                cv.drawLine(xx - sz, yy + sz, xx + sz, yy - sz, stroke);
                label(cv, "exit", xx + 5 * d, yy - 4 * d, 0xFFE8EAED, 7.5f, false);
            }
        }
    }

    private void drawSupertrend(Canvas cv) {
        for (int i = Math.max(start + 1, 1); i < end && i < stLine.length; i++) {
            if (stUp[i] != stUp[i - 1]) {
                fill.setColor(stUp[i] ? UP : DOWN);
                cv.drawCircle(x(i), y(stLine[i]), 3 * d, fill);
                continue;
            }
            float y1 = y(stLine[i - 1]), y2 = y(stLine[i]);
            if ((y1 < top && y2 < top) || (y1 > priceBottom && y2 > priceBottom)) continue;
            paint(stroke, stUp[i] ? UP : DOWN, 1.8f * d);
            cv.drawLine(x(i - 1), y1, x(i), y2, stroke);
        }
        int li = Math.min(end, stLine.length) - 1;
        if (li > 0) tag(cv, stUp[li] ? "ST ▲" : "ST ▼", Math.max(2 * d, x(li) - 34 * d), y(stLine[li]) + (stUp[li] ? 12 : -12) * d,
                (stUp[li] ? UP : DOWN) & 0xDDFFFFFF, 0xFFFFFFFF);
    }

    /** Ichimoku cloud: span A / B shifted 26 candles ahead (also into the future area). */
    private void drawIchimoku(Canvas cv, boolean live) {
        int last = live ? end + 26 : end;
        for (int i = start + 1; i < last; i++) {
            int j = i - 26, j0 = j - 1;
            if (j0 < 52 || j >= ich[2].length) continue;
            float xa = x(i - 1), xb = x(i);
            if (xb > plotW) break;
            double a0 = ich[2][j0], b0 = ich[3][j0], a1 = ich[2][j], b1 = ich[3][j];
            Path p = new Path();
            p.moveTo(xa, y(a0));
            p.lineTo(xb, y(a1));
            p.lineTo(xb, y(b1));
            p.lineTo(xa, y(b0));
            p.close();
            fill.setColor(a1 >= b1 ? 0x2A089981 : 0x2AF23645);
            cv.drawPath(p, fill);
        }
    }

    private void drawCrosses(Canvas cv) {
        for (int[] c : crossList) {
            int i = c[0];
            if (i < start || i >= end) continue;
            if (Math.abs(c[1]) == 1) {
                float yy = y(ema50[i]);
                if (yy < top || yy > priceBottom) continue;
                fill.setColor(c[1] > 0 ? 0xFFF0B90B : 0xFF9CA3AF);
                cv.drawCircle(x(i), yy, 4 * d, fill);
                tag(cv, c[1] > 0 ? "✨ Golden cross" : "☠ Death cross", x(i) + 5 * d, yy - 10 * d,
                        c[1] > 0 ? 0xDD7A5A00 : 0xDD3A3F4B, 0xFFFFFFFF);
            } else if (ribbon || showEma) {
                float yy = y(ema21[i]);
                if (yy < top || yy > priceBottom) continue;
                fill.setColor(c[1] > 0 ? 0xCC0ECB81 : 0xCCF6465D);
                cv.drawCircle(x(i), yy, 2.6f * d, fill);
            }
        }
    }

    /** ParaDox confluence rule hits: ▲ BUY under the candle, ▼ SELL above it. */
    private void drawRule(Canvas cv) {
        for (int[] r : ruleList) {
            int i = r[0];
            if (i < start || i >= end) continue;
            float xx = x(i);
            boolean b = r[1] > 0;
            float yy = b ? y(data.low[i]) + 12 * d : y(data.high[i]) - 12 * d;
            if (yy < top || yy > priceBottom + 6 * d) continue;
            Path tri = new Path();
            float s = Math.max(4 * d, Math.min(7 * d, cw * 0.45f));
            if (b) { tri.moveTo(xx, yy - s); tri.lineTo(xx - s, yy + s * 0.6f); tri.lineTo(xx + s, yy + s * 0.6f); }
            else { tri.moveTo(xx, yy + s); tri.lineTo(xx - s, yy - s * 0.6f); tri.lineTo(xx + s, yy - s * 0.6f); }
            tri.close();
            fill.setColor(b ? UP : DOWN);
            cv.drawPath(tri, fill);
            if (cw > 5 * d || !compact) label(cv, b ? "BUY" : "SELL", xx - 9 * d, b ? yy + s + 9 * d : yy - s - 3 * d, b ? UP : DOWN, 7.5f, true);
        }
    }

    // ------------------------------------------------------------ gestures (TradingView / Binance style)
    // 1 finger drag left/right = scroll time · drag up/down = move price
    // drag on the right price scale = stretch / squeeze price · 2 fingers = zoom
    // press & hold = crosshair · double tap = reset to auto + live
    private static final int G_NONE = 0, G_PENDING = 1, G_PAN = 2, G_CROSS = 3, G_PINCH = 4, G_YSCALE = 5, G_YPAN = 6;
    private int gesture = G_NONE;
    private float downX, downY, lastX, lastY;
    private double pinchDx, pinchDy, pinchVisible, pinchMax, pinchMin;
    private long lastTap;
    private final Runnable crossOn = () -> {
        if (gesture == G_PENDING) {
            gesture = G_CROSS;
            touchIdx = idxAt(downX);
            touchY = downY;
            invalidate();
        }
    };

    private int idxAt(float xPos) {
        if (cw <= 0) return -1;
        int idx = start + (int) (xPos / cw);
        return Math.max(start, Math.min(end - 1, idx));
    }

    private void startManualY() {
        if (!manualY) {
            manualY = true;
            yMax = max;
            yMin = min;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (data == null || data.n == 0 || cw <= 0) return false;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = lastX = e.getX();
                downY = lastY = e.getY();
                if (!compact && downX > plotW && downY < priceBottom) {
                    gesture = G_YSCALE;
                    startManualY();
                } else {
                    gesture = G_PENDING;
                    postDelayed(crossOn, 300);
                }
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                removeCallbacks(crossOn);
                if (e.getPointerCount() >= 2) {
                    gesture = G_PINCH;
                    pinchDx = Math.max(10, Math.abs(e.getX(0) - e.getX(1)));
                    pinchDy = Math.max(10, Math.abs(e.getY(0) - e.getY(1)));
                    pinchVisible = visible;
                    pinchMax = max;
                    pinchMin = min;
                    touchIdx = -1;
                }
                return true;
            case MotionEvent.ACTION_MOVE: {
                float x = e.getX(), y = e.getY();
                if (gesture == G_PINCH && e.getPointerCount() >= 2) {
                    double dx = Math.max(10, Math.abs(e.getX(0) - e.getX(1)));
                    double dy = Math.max(10, Math.abs(e.getY(0) - e.getY(1)));
                    visible = Math.max(15, Math.min(1000, pinchVisible * pinchDx / dx));
                    if (!compact && Math.abs(dy - pinchDy) > 30 * d) {
                        // vertical pinch also stretches the price scale
                        startManualY();
                        double mid = (pinchMax + pinchMin) / 2, half = (pinchMax - pinchMin) / 2 * pinchDy / dy;
                        yMax = mid + half;
                        yMin = mid - half;
                    }
                    invalidate();
                } else if (gesture == G_YSCALE) {
                    double f = Math.exp((y - lastY) / (150 * d));
                    double mid = (yMax + yMin) / 2, half = (yMax - yMin) / 2 * f;
                    yMax = mid + half;
                    yMin = mid - half;
                    invalidate();
                } else if (gesture == G_PENDING) {
                    float adx = Math.abs(x - downX), ady = Math.abs(y - downY);
                    if (adx > 10 * d || ady > 10 * d) {
                        removeCallbacks(crossOn);
                        gesture = ady > adx * 1.3f ? G_YPAN : G_PAN;
                        if (gesture == G_YPAN && compact) {
                            // embedded chart: keep the chart window fixed, let the page scroll instead
                            gesture = G_NONE;
                            if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                            return false;
                        }
                        if (gesture == G_YPAN) startManualY();
                    }
                } else if (gesture == G_CROSS) {
                    touchIdx = idxAt(x);
                    touchY = y;
                    invalidate();
                }
                if (gesture == G_PAN) {
                    offset = Math.max(0, offset + (x - lastX) / cw);
                    invalidate();
                } else if (gesture == G_YPAN) {
                    double dp = (y - lastY) / Math.max(1, priceBottom - top) * (yMax - yMin);
                    yMax += dp;
                    yMin += dp;
                    invalidate();
                }
                lastX = x;
                lastY = y;
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                removeCallbacks(crossOn);
                if (gesture == G_PENDING && placeDrawing(e.getX(), e.getY())) {
                    gesture = G_NONE;
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                    return true;
                }
                if (gesture == G_PENDING && tapListener != null) {
                    gesture = G_NONE;
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                    tapListener.run();
                    return true;
                }
                if (gesture == G_PENDING) {
                    long now = System.currentTimeMillis();
                    if (now - lastTap < 320) {
                        resetView();
                        touchIdx = -1;
                        lastTap = 0;
                    } else {
                        lastTap = now;
                        touchIdx = idxAt(e.getX());
                        postDelayed(() -> { touchIdx = -1; invalidate(); }, 2500);
                    }
                } else {
                    touchIdx = -1;
                }
                gesture = G_NONE;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                invalidate();
                return true;
            default:
                return true;
        }
    }
}
