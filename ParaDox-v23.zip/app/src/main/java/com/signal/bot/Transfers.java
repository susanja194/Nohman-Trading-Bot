package com.signal.bot;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Deposit / withdraw status of a coin on exchanges that publish it without a key (KuCoin, Gate, Bitget).
 * A big arbitrage gap is very often a closed deposit or withdrawal — check before trading.
 */
public final class Transfers {
    private Transfers() {}

    /** {deposit open, withdraw open} or null if unknown. */
    static boolean[] check(String venue, String base) {
        try {
            switch (venue) {
                case "KuCoin": {
                    JSONObject d = new JSONObject(Scanner.getAbsolute("https://api.kucoin.com/api/v3/currencies/" + base)).getJSONObject("data");
                    JSONArray ch = d.optJSONArray("chains");
                    boolean dep = false, wd = false;
                    if (ch != null) for (int i = 0; i < ch.length(); i++) {
                        JSONObject c = ch.getJSONObject(i);
                        dep |= c.optBoolean("isDepositEnabled");
                        wd |= c.optBoolean("isWithdrawEnabled");
                    }
                    return new boolean[]{dep, wd};
                }
                case "Gate": {
                    JSONObject d = new JSONObject(Scanner.getAbsolute("https://api.gateio.ws/api/v4/spot/currencies/" + base));
                    return new boolean[]{!d.optBoolean("deposit_disabled"), !d.optBoolean("withdraw_disabled")};
                }
                case "Bitget": {
                    JSONArray a = new JSONObject(Scanner.getAbsolute("https://api.bitget.com/api/v2/spot/public/coins?coin=" + base)).getJSONArray("data");
                    if (a.length() == 0) return null;
                    JSONArray ch = a.getJSONObject(0).optJSONArray("chains");
                    boolean dep = false, wd = false;
                    if (ch != null) for (int i = 0; i < ch.length(); i++) {
                        JSONObject c = ch.getJSONObject(i);
                        dep |= "true".equals(c.optString("rechargeable"));
                        wd |= "true".equals(c.optString("withdrawable"));
                    }
                    return new boolean[]{dep, wd};
                }
                default:
                    return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    /** Lowest withdrawal fee (in coins) across the coin's networks, or NaN when the exchange does not publish it without a key. */
    public static double withdrawFee(String venue, String base) {
        try {
            switch (venue) {
                case "KuCoin": {
                    JSONArray ch = new JSONObject(Scanner.getAbsolute("https://api.kucoin.com/api/v3/currencies/" + base)).getJSONObject("data").optJSONArray("chains");
                    double best = Double.NaN;
                    if (ch != null) for (int i = 0; i < ch.length(); i++) {
                        JSONObject c = ch.getJSONObject(i);
                        if (!c.optBoolean("isWithdrawEnabled")) continue;
                        double f = c.optDouble("withdrawalMinFee", Double.NaN);
                        if (!Double.isNaN(f) && (Double.isNaN(best) || f < best)) best = f;
                    }
                    return best;
                }
                case "Bitget": {
                    JSONArray a = new JSONObject(Scanner.getAbsolute("https://api.bitget.com/api/v2/spot/public/coins?coin=" + base)).getJSONArray("data");
                    if (a.length() == 0) return Double.NaN;
                    JSONArray ch = a.getJSONObject(0).optJSONArray("chains");
                    double best = Double.NaN;
                    if (ch != null) for (int i = 0; i < ch.length(); i++) {
                        JSONObject c = ch.getJSONObject(i);
                        if (!"true".equals(c.optString("withdrawable"))) continue;
                        double f = c.optDouble("withdrawFee", Double.NaN);
                        if (!Double.isNaN(f) && (Double.isNaN(best) || f < best)) best = f;
                    }
                    return best;
                }
                default:
                    return Double.NaN;
            }
        } catch (Exception e) {
            return Double.NaN;
        }
    }

    public static String status(String base, String buyVenue, String sellVenue) {
        StringBuilder sb = new StringBuilder();
        boolean[] b = check(buyVenue, base), s = check(sellVenue, base);
        sb.append(buyVenue).append(" (khareed): ").append(b == null ? "status maloom nahi (exchange key ke baghair nahi batata)"
                : (b[1] ? "✅ withdraw khula" : "❌ withdraw BAND — coin bahar nahi bhej sakte")).append('\n');
        sb.append(sellVenue).append(" (bech): ").append(s == null ? "status maloom nahi (exchange key ke baghair nahi batata)"
                : (s[0] ? "✅ deposit khula" : "❌ deposit BAND — gap isi wajah se ho sakta hai"));
        return sb.toString();
    }
}
