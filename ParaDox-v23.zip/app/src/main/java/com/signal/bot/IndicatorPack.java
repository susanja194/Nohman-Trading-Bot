package com.signal.bot;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * 12 professional indicators that each VOTE bullish / bearish / neutral on the last closed candle:
 * EMA trend · MACD · RSI · Stochastic RSI · ADX/DMI (trend strength) · Supertrend · Ichimoku cloud ·
 * MFI (volume-weighted RSI) · CMF (Chaikin money flow) · OBV slope · Bollinger %B / squeeze · VWAP.
 * The agreement % is used in reports and in accuracy mode (signals need trend strength + majority agreement).
 */
public final class IndicatorPack {
    private IndicatorPack() {}

    public static final class Result {
        public int bull, bear, total;
        public double adx, plusDi, minusDi;
        public boolean squeeze;
        public int score;                       // -100..100
        public final List<String> lines = new ArrayList<>();
        public double[] stLine;                 // supertrend line (for the chart)
        public boolean[] stUp;
        public double agreement(boolean buy) { return total == 0 ? 0 : (buy ? bull : bear) * 100.0 / total; }
    }

    // ------------------------------------------------------------------ building blocks
    static double[] trueRange(Candles c) {
        double[] tr = new double[c.n];
        for (int i = 0; i < c.n; i++) {
            double hl = c.high[i] - c.low[i];
            tr[i] = i == 0 ? hl : Math.max(hl, Math.max(Math.abs(c.high[i] - c.close[i - 1]), Math.abs(c.low[i] - c.close[i - 1])));
        }
        return tr;
    }

    /** Wilder smoothing. */
    static double[] rma(double[] v, int p) {
        double[] o = new double[v.length];
        double s = 0;
        for (int i = 0; i < v.length; i++) {
            if (i < p) { s += v[i]; o[i] = s / (i + 1); }
            else o[i] = (o[i - 1] * (p - 1) + v[i]) / p;
        }
        return o;
    }

    /** {adx, +DI, -DI} arrays. */
    public static double[][] adx(Candles c, int p) {
        int n = c.n;
        double[] pdm = new double[n], mdm = new double[n];
        for (int i = 1; i < n; i++) {
            double up = c.high[i] - c.high[i - 1], dn = c.low[i - 1] - c.low[i];
            pdm[i] = up > dn && up > 0 ? up : 0;
            mdm[i] = dn > up && dn > 0 ? dn : 0;
        }
        double[] tr = rma(trueRange(c), p), sp = rma(pdm, p), sm = rma(mdm, p);
        double[] pdi = new double[n], mdi = new double[n], dx = new double[n];
        for (int i = 0; i < n; i++) {
            pdi[i] = tr[i] > 0 ? sp[i] / tr[i] * 100 : 0;
            mdi[i] = tr[i] > 0 ? sm[i] / tr[i] * 100 : 0;
            double s = pdi[i] + mdi[i];
            dx[i] = s > 0 ? Math.abs(pdi[i] - mdi[i]) / s * 100 : 0;
        }
        return new double[][]{rma(dx, p), pdi, mdi};
    }

    /** Supertrend (ATR 10, mult 3): line + direction. */
    public static Object[] supertrend(Candles c, int p, double mult) {
        int n = c.n;
        double[] atr = rma(trueRange(c), p), line = new double[n];
        boolean[] up = new boolean[n];
        double fu = 0, fl = 0;
        for (int i = 0; i < n; i++) {
            double mid = (c.high[i] + c.low[i]) / 2, bu = mid + mult * atr[i], bl = mid - mult * atr[i];
            if (i == 0) { fu = bu; fl = bl; up[i] = true; line[i] = fl; continue; }
            fu = (bu < fu || c.close[i - 1] > fu) ? bu : fu;
            fl = (bl > fl || c.close[i - 1] < fl) ? bl : fl;
            boolean u = up[i - 1];
            if (u && c.close[i] < fl) u = false;
            else if (!u && c.close[i] > fu) u = true;
            up[i] = u;
            line[i] = u ? fl : fu;
        }
        return new Object[]{line, up};
    }

    /** Ichimoku: {tenkan, kijun, spanA, spanB} (spans NOT shifted; shift 26 when drawing). */
    public static double[][] ichimoku(Candles c) {
        int n = c.n;
        double[] t = new double[n], k = new double[n], a = new double[n], b = new double[n];
        for (int i = 0; i < n; i++) {
            t[i] = mid(c, i, 9);
            k[i] = mid(c, i, 26);
            a[i] = (t[i] + k[i]) / 2;
            b[i] = mid(c, i, 52);
        }
        return new double[][]{t, k, a, b};
    }

    static double mid(Candles c, int i, int p) {
        double hi = -Double.MAX_VALUE, lo = Double.MAX_VALUE;
        for (int j = Math.max(0, i - p + 1); j <= i; j++) { hi = Math.max(hi, c.high[j]); lo = Math.min(lo, c.low[j]); }
        return (hi + lo) / 2;
    }

    static double mfi(Candles c, int p) {
        int n = c.n;
        if (n < p + 2) return 50;
        double pos = 0, neg = 0;
        for (int i = n - p; i < n; i++) {
            double tp = (c.high[i] + c.low[i] + c.close[i]) / 3, tp0 = (c.high[i - 1] + c.low[i - 1] + c.close[i - 1]) / 3;
            double mf = tp * c.vol[i];
            if (tp > tp0) pos += mf; else if (tp < tp0) neg += mf;
        }
        if (pos + neg <= 0) return 50;
        return 100 - 100 / (1 + (neg > 0 ? pos / neg : 99));
    }

    static double cmf(Candles c, int p) {
        int n = c.n;
        double mfv = 0, v = 0;
        for (int i = Math.max(0, n - p); i < n; i++) {
            double r = c.high[i] - c.low[i];
            double m = r > 0 ? ((c.close[i] - c.low[i]) - (c.high[i] - c.close[i])) / r : 0;
            mfv += m * c.vol[i];
            v += c.vol[i];
        }
        return v > 0 ? mfv / v : 0;
    }

    static double stochRsi(double[] rsi, int p) {
        int n = rsi.length;
        if (n < p + 3) return 0.5;
        double[] k = new double[3];
        for (int z = 0; z < 3; z++) {
            int e = n - 1 - z;
            double hi = -1, lo = 101;
            for (int i = e - p + 1; i <= e; i++) { hi = Math.max(hi, rsi[i]); lo = Math.min(lo, rsi[i]); }
            k[z] = hi > lo ? (rsi[e] - lo) / (hi - lo) : 0.5;
        }
        return (k[0] + k[1] + k[2]) / 3;
    }

    // ------------------------------------------------------------------ the vote
    public static Result analyze(Candles c) {
        Result r = new Result();
        int n = c.n;
        if (n < 60) { r.lines.add("Data kam hai (60+ candles chahiye)"); return r; }
        int i = n - 1;
        double px = c.close[i];
        boolean hasVol = false;
        for (int k = n - 20; k < n; k++) if (c.vol[k] > 0) { hasVol = true; break; }

        double[] e21 = Indicators.ema(c.close, 21), e50 = Indicators.ema(c.close, 50);
        vote(r, px > e50[i] && e21[i] > e50[i], px < e50[i] && e21[i] < e50[i], "EMA trend (21/50)",
                px > e50[i] ? "price EMA50 ke upar" : "price EMA50 ke neeche");

        double[] h = Indicators.macdHist(c.close);
        vote(r, h[i] > 0 && h[i] >= h[i - 1], h[i] < 0 && h[i] <= h[i - 1], "MACD",
                String.format(Locale.US, "histogram %s, %s", h[i] > 0 ? "positive" : "negative", h[i] >= h[i - 1] ? "barh raha" : "ghat raha"));

        double[] rsi = Indicators.rsi(c.close, 14);
        vote(r, rsi[i] > 52 && rsi[i] < 72, rsi[i] < 48 && rsi[i] > 28, "RSI 14", String.format(Locale.US, "%.0f", rsi[i]));

        double sr = stochRsi(rsi, 14);
        double sr1 = stochRsi(java.util.Arrays.copyOf(rsi, n - 1), 14);
        vote(r, sr > sr1 && sr < 0.85, sr < sr1 && sr > 0.15, "Stochastic RSI",
                String.format(Locale.US, "%.0f%% %s", sr * 100, sr > sr1 ? "upar mud raha" : "neeche mud raha"));

        double[][] ad = adx(c, 14);
        r.adx = ad[0][i];
        r.plusDi = ad[1][i];
        r.minusDi = ad[2][i];
        boolean trend = r.adx >= 20;
        vote(r, trend && r.plusDi > r.minusDi, trend && r.minusDi > r.plusDi, "ADX / DMI",
                String.format(Locale.US, "ADX %.0f (%s) · +DI %.0f / −DI %.0f", r.adx, r.adx >= 25 ? "mazboot trend" : r.adx >= 20 ? "trend" : "range — kamzor", r.plusDi, r.minusDi));

        Object[] st = supertrend(c, 10, 3);
        r.stLine = (double[]) st[0];
        r.stUp = (boolean[]) st[1];
        boolean flip = r.stUp[i] != r.stUp[i - 1] || r.stUp[i - 1] != r.stUp[i - 2];
        vote(r, r.stUp[i], !r.stUp[i], "Supertrend (10, 3)", (r.stUp[i] ? "BUY mode" : "SELL mode") + (flip ? " · abhi palta ⚡" : ""));

        double[][] ich = ichimoku(c);
        int s = i - 26;   // cloud plotted 26 ahead -> cloud under today's candle comes from 26 bars ago
        if (s > 52) {
            double top = Math.max(ich[2][s], ich[3][s]), bot = Math.min(ich[2][s], ich[3][s]);
            boolean above = px > top, below = px < bot;
            vote(r, above && ich[0][i] > ich[1][i], below && ich[0][i] < ich[1][i], "Ichimoku cloud",
                    above ? "price badal (cloud) ke upar" : below ? "price badal ke neeche" : "price badal ke andar — faisla nahi");
        }

        if (hasVol) {
            double mf = mfi(c, 14);
            vote(r, mf > 50 && mf < 80, mf < 50 && mf > 20, "MFI (volume RSI)", String.format(Locale.US, "%.0f", mf));
            double cm = cmf(c, 20);
            vote(r, cm > 0.05, cm < -0.05, "Chaikin money flow", String.format(Locale.US, "%+.2f (%s)", cm, cm > 0.05 ? "paisa aa raha" : cm < -0.05 ? "paisa nikal raha" : "neutral"));
            double[] obv = Indicators.obv(c.close, c.vol);
            double[] oe = Indicators.ema(obv, 20);
            vote(r, obv[i] > oe[i] && oe[i] > oe[i - 5], obv[i] < oe[i] && oe[i] < oe[i - 5], "OBV trend", obv[i] > oe[i] ? "upar" : "neeche");
        }

        // Bollinger %B + squeeze
        double m = 0, v = 0;
        for (int k = n - 20; k < n; k++) m += c.close[k];
        m /= 20;
        for (int k = n - 20; k < n; k++) v += (c.close[k] - m) * (c.close[k] - m);
        double sd = Math.sqrt(v / 20), up = m + 2 * sd, lo = m - 2 * sd;
        double pb = up > lo ? (px - lo) / (up - lo) : 0.5;
        double bw = m > 0 ? (up - lo) / m : 0, bwAvg = 0;
        for (int k = n - 120 > 20 ? n - 120 : 20; k < n; k++) {
            double mm = 0, vv = 0;
            for (int j = k - 19; j <= k; j++) mm += c.close[j];
            mm /= 20;
            for (int j = k - 19; j <= k; j++) vv += (c.close[j] - mm) * (c.close[j] - mm);
            bwAvg += mm > 0 ? 4 * Math.sqrt(vv / 20) / mm : 0;
        }
        bwAvg /= Math.max(1, n - Math.max(20, n - 120));
        r.squeeze = bw < bwAvg * 0.6;
        vote(r, pb > 0.55 && pb < 1.0, pb < 0.45 && pb > 0.0, "Bollinger %B",
                String.format(Locale.US, "%.0f%%", pb * 100) + (r.squeeze ? " · SQUEEZE (bara move qareeb) ⚡" : ""));

        if (hasVol) {   // rolling VWAP (last 50 candles)
            double pv = 0, vv = 0;
            for (int k = n - 50; k < n; k++) { double tp = (c.high[k] + c.low[k] + c.close[k]) / 3; pv += tp * c.vol[k]; vv += c.vol[k]; }
            double vw = vv > 0 ? pv / vv : px;
            vote(r, px > vw, px < vw, "VWAP (50)", px > vw ? "price VWAP ke upar" : "price VWAP ke neeche");
        }

        r.score = r.total > 0 ? (int) Math.round((r.bull - r.bear) * 100.0 / r.total) : 0;
        if (r.adx < 18) r.score = (int) Math.round(r.score * 0.6);   // no trend -> less trust
        r.lines.add(0, String.format(Locale.US, "%d indicators: 🟢 %d bullish · 🔴 %d bearish · ⚪ %d neutral", r.total, r.bull, r.bear, r.total - r.bull - r.bear));
        return r;
    }

    private static void vote(Result r, boolean bull, boolean bear, String name, String detail) {
        r.total++;
        if (bull) r.bull++;
        else if (bear) r.bear++;
        r.lines.add((bull ? "🟢 " : bear ? "🔴 " : "⚪ ") + name + " — " + detail);
    }
}
