package com.signal.bot;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 📆 Catalyst Radar — PUBLIC events that are known in advance and often move a coin before they happen:
 * token unlocks (DefiLlama), Binance listings / delistings / Launchpool / airdrops, launches & upgrades found in the
 * news, US macro (Fed, CPI...), CoinMarketCal (optional free key), Polymarket odds jumps (crowd / smart money
 * expectations) and futures position build-ups (open interest rising while price is flat).
 * No secret "insider" data — only public, legal sources.
 */
public final class CatalystEngine {
    private CatalystEngine() {}

    public static final String UNLOCK = "unlock", LISTING = "listing", DELIST = "delist", LAUNCH = "launch", AIRDROP = "airdrop",
            MACRO = "macro", ETF = "etf", ODDS = "odds", OI = "oi", EVENT = "event";

    public static final class Event {
        public String id = "", type = EVENT, title = "", source = "", link = "", impact = "", action = "";
        public long time;               // when it happens (ms); for "odds" / "oi" = when detected
        public boolean estimated;       // date guessed from text
        public final List<String> coins = new ArrayList<>();
        public int dir, severity = 1;   // +1 bullish, -1 bearish · 1..3
        public double usd, pctMcap;     // unlock size
        public String icon() {
            switch (type) {
                case UNLOCK: return "🔓";
                case LISTING: return "🆕";
                case DELIST: return "📤";
                case LAUNCH: return "🚀";
                case AIRDROP: return "🎁";
                case MACRO: return "🏛️";
                case ETF: return "🏦";
                case ODDS: return "🎲";
                case OI: return "📊";
                default: return "📌";
            }
        }
    }

    private static volatile List<Event> cache = new ArrayList<>();
    private static volatile long cacheAt;
    private static volatile String status = "";
    private static final Object LOCK = new Object();

    public static List<Event> cached() { return cache; }
    public static String status() { return status; }

    public static List<Event> fetch(final Context ctx, long maxAge) {
        if (System.currentTimeMillis() - cacheAt < maxAge && !cache.isEmpty()) return cache;
        synchronized (LOCK) {
            if (System.currentTimeMillis() - cacheAt < maxAge && !cache.isEmpty()) return cache;
            final List<Event> all = Collections.synchronizedList(new ArrayList<>());
            final List<String> ok = Collections.synchronizedList(new ArrayList<>());
            ExecutorService ex = Executors.newFixedThreadPool(6);
            ex.submit(() -> { try { all.addAll(unlocks()); ok.add("DefiLlama unlocks"); } catch (Exception ignored) { } });
            ex.submit(() -> { try { all.addAll(binance(48, "Binance Listing")); all.addAll(binance(161, "Binance Delisting")); ok.add("Binance"); } catch (Exception ignored) { } });
            ex.submit(() -> { try { all.addAll(polymarket()); ok.add("Polymarket"); } catch (Exception ignored) { } });
            ex.submit(() -> { try { all.addAll(openInterest()); ok.add("Futures OI"); } catch (Exception ignored) { } });
            ex.submit(() -> { try { all.addAll(macro(ctx)); ok.add("Macro calendar"); } catch (Exception ignored) { } });
            ex.submit(() -> { try { all.addAll(fromNews(ctx)); ok.add("News"); } catch (Exception ignored) { } });
            final String key = ctx != null ? Prefs.getStr(ctx, "cmcal", "") : "";
            if (key != null && !key.trim().isEmpty())
                ex.submit(() -> { try { all.addAll(coinMarketCal(key.trim())); ok.add("CoinMarketCal"); } catch (Exception ignored) { } });
            ex.shutdown();
            try { ex.awaitTermination(30, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
            ex.shutdownNow();
            long now = System.currentTimeMillis();
            List<Event> out = new ArrayList<>();
            Set<String> seen = new HashSet<>();
            synchronized (all) {
                for (Event e : all) {
                    if (e.time <= 0) continue;
                    boolean detected = e.type.equals(ODDS) || e.type.equals(OI);
                    if (!detected && (e.time < now - 6 * 3600_000L || e.time > now + 45L * 86_400_000L)) continue;
                    String k = e.type + "|" + String.join(",", e.coins) + "|" + (e.time / 3_600_000L) + "|" + e.title.toLowerCase(Locale.US).hashCode();
                    String k2 = e.type + "|" + String.join(",", e.coins) + "|" + (e.time / 86_400_000L);
                    if (seen.contains(k) || (!e.coins.isEmpty() && !e.type.equals(MACRO) && seen.contains(k2))) continue;
                    seen.add(k);
                    seen.add(k2);
                    if (e.id.isEmpty()) e.id = k;
                    explain(e);
                    out.add(e);
                }
            }
            Collections.sort(out, (a, b) -> Long.compare(a.time, b.time));
            if (!out.isEmpty() || cache.isEmpty()) {
                cache = out;
                cacheAt = System.currentTimeMillis();
            }
            status = String.join(" · ", ok) + " · " + out.size() + " events";
            return cache;
        }
    }

    // ------------------------------------------------------------------ sources
    /** DefiLlama emissions (token unlock schedule). */
    static List<Event> unlocks() throws Exception {
        List<Event> out = new ArrayList<>();
        String raw = Scanner.getAbsolute("https://api.llama.fi/emissions");
        JSONArray a = raw.trim().startsWith("[") ? new JSONArray(raw) : new JSONObject(raw).optJSONArray("data");
        if (a == null) return out;
        long now = System.currentTimeMillis();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            JSONObject ne = o.optJSONObject("nextEvent");
            if (ne == null) continue;
            long t = ne.optLong("date", 0);
            if (t > 0 && t < 10_000_000_000L) t *= 1000;
            if (t < now - 3600_000L || t > now + 30L * 86_400_000L) continue;
            double amount = ne.optDouble("toUnlock", 0);
            double price = o.optDouble("tPrice", 0), mcap = o.optDouble("mcap", 0);
            double usd = amount * price;
            if (usd < 1_000_000) continue;
            Event e = new Event();
            e.type = UNLOCK;
            e.time = t;
            e.usd = usd;
            e.pctMcap = mcap > 0 ? usd / mcap * 100 : 0;
            String sym = o.optString("tSymbol", o.optString("symbol", "")).toUpperCase(Locale.US);
            String name = o.optString("name", sym);
            if (!sym.isEmpty()) e.coins.add(sym);
            e.title = name + (sym.isEmpty() ? "" : " (" + sym + ")") + " token unlock · " + Fmt.usd(usd)
                    + (e.pctMcap > 0 ? String.format(Locale.US, " · %.1f%% market cap", e.pctMcap) : "");
            e.source = "DefiLlama";
            e.link = "https://defillama.com/unlocks";
            e.dir = -1;
            e.severity = e.pctMcap >= 3 || usd >= 100_000_000 ? 3 : e.pctMcap >= 1 || usd >= 20_000_000 ? 2 : 1;
            out.add(e);
        }
        return out;
    }

    static final Pattern PAREN = Pattern.compile("\\(([A-Z0-9]{2,12})\\)");
    static final Pattern ISO_DATE = Pattern.compile("(20\\d\\d)-(\\d\\d)-(\\d\\d)");

    /** Binance listing (48) / delisting (161) announcements: coin in "(XYZ)", date in title or ~1 day after release. */
    static List<Event> binance(int catalog, String name) throws Exception {
        List<Event> out = new ArrayList<>();
        JSONObject o = new JSONObject(Scanner.getAbsolute("https://www.binance.com/bapi/composite/v1/public/cms/article/list/query?type=1&catalogId="
                + catalog + "&pageNo=1&pageSize=20"));
        JSONArray cats = o.getJSONObject("data").getJSONArray("catalogs");
        long now = System.currentTimeMillis();
        for (int c = 0; c < cats.length(); c++) {
            JSONArray arts = cats.getJSONObject(c).optJSONArray("articles");
            if (arts == null) continue;
            for (int i = 0; i < arts.length(); i++) {
                JSONObject a = arts.getJSONObject(i);
                String title = a.optString("title");
                long rel = a.optLong("releaseDate", 0);
                if (now - rel > 10L * 86_400_000L) continue;
                String low = title.toLowerCase(Locale.US);
                Event e = new Event();
                e.title = title;
                e.source = name;
                e.link = "https://www.binance.com/en/support/announcement/" + a.optString("code");
                Matcher m = PAREN.matcher(title);
                while (m.find()) if (!e.coins.contains(m.group(1))) e.coins.add(m.group(1));
                Matcher dm = ISO_DATE.matcher(title);
                long t = 0;
                if (dm.find()) t = utc(Integer.parseInt(dm.group(1)), Integer.parseInt(dm.group(2)), Integer.parseInt(dm.group(3)), 3);
                if (catalog == 161 || low.contains("delist") || low.contains("removal")) {
                    e.type = DELIST;
                    e.dir = -1;
                    e.severity = 3;
                    e.time = t > 0 ? t : rel + 7L * 86_400_000L;
                    e.estimated = t == 0;
                } else if (low.contains("airdrop") || low.contains("launchpool") || low.contains("megadrop")) {
                    e.type = AIRDROP;
                    e.dir = 1;
                    e.severity = 2;
                    e.time = t > 0 ? t : rel + 86_400_000L;
                    e.estimated = t == 0;
                } else if (low.contains("will list") || low.contains("will add") || low.contains("listing") || low.contains("futures will launch")) {
                    e.type = LISTING;
                    e.dir = 1;
                    e.severity = low.contains("will list") ? 3 : 2;
                    e.time = t > 0 ? t : rel + 86_400_000L;
                    e.estimated = t == 0;
                } else continue;
                out.add(e);
            }
        }
        return out;
    }

    static long utc(int y, int mo, int d, int h) {
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.clear();
        c.set(y, mo - 1, d, h, 0, 0);
        return c.getTimeInMillis();
    }

    static final String[] CRYPTO_Q = {"bitcoin", "btc", "ethereum", "eth", "solana", "sol", "xrp", "crypto", "etf", "binance", "coinbase", "doge", "stablecoin",
            "microstrategy", "strategy", "tether", "usdt", "sec ", "token", "airdrop", "hyperliquid", "trump", "fdv", "launch", "megaeth", "base "};

    /** Polymarket: crypto prediction markets whose odds moved a lot in a day (the crowd expects something). */
    static List<Event> polymarket() throws Exception {
        List<Event> out = new ArrayList<>();
        JSONArray a = new JSONArray(Scanner.getAbsolute("https://gamma-api.polymarket.com/markets?active=true&closed=false&limit=300&order=volume24hr&ascending=false"));
        long now = System.currentTimeMillis();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            String q = o.optString("question");
            String ql = " " + q.toLowerCase(Locale.US) + " ";
            boolean crypto = false;
            for (String w : CRYPTO_Q) if (ql.contains(w)) { crypto = true; break; }
            if (!crypto) continue;
            double ch = o.optDouble("oneDayPriceChange", 0);
            double vol = o.optDouble("volume24hr", 0);
            double yes = 0;
            try {
                JSONArray pr = new JSONArray(o.optString("outcomePrices", "[]"));
                yes = Double.parseDouble(pr.optString(0, "0"));
            } catch (Exception ignored) {
            }
            // skip pure "price above X on date" ladders unless the move is big
            boolean priceLadder = ql.contains(" above ") || ql.contains(" below ") || ql.contains("price of") || ql.contains(" reach ") || ql.contains(" dip to ");
            if (Math.abs(ch) < (priceLadder ? 0.25 : 0.10) || vol < 20_000) continue;
            Event e = new Event();
            e.type = ODDS;
            e.time = now;
            e.title = q + String.format(Locale.US, " — ab %.0f%% YES (%+.0f%% aaj)", yes * 100, ch * 100);
            e.source = "Polymarket";
            e.link = "https://polymarket.com/market/" + o.optString("slug");
            for (String[] n : NewsEngine.NAMES) if (ql.contains(" " + n[0] + " ") && !e.coins.contains(n[1])) e.coins.add(n[1]);
            e.severity = Math.abs(ch) >= 0.25 && vol >= 100_000 ? 3 : 2;
            e.dir = guessDir(ql) * (ch > 0 ? 1 : -1);
            String end = o.optString("endDate", "");
            if (!end.isEmpty()) e.impact = "Faisla: " + end.substring(0, Math.min(10, end.length()));
            out.add(e);
            if (out.size() >= 15) break;
        }
        return out;
    }

    /** Does a YES outcome sound good (+1) or bad (−1) for crypto prices? */
    static int guessDir(String q) {
        String[] bad = {"hack", "ban", "crash", "bankrupt", "delist", "lawsuit", "sue", "recession", "rate hike", "below", "dip", "depeg", "jail", "arrest", "reject"};
        String[] good = {"approve", "approval", "etf", "reserve", "buy", "above", "reach", "rate cut", "launch", "list", "all time high", "ath", "adopt", "pass"};
        for (String b : bad) if (q.contains(b)) return -1;
        for (String g : good) if (q.contains(g)) return 1;
        return 0;
    }

    static final String[] OI_COINS = {"BTC", "ETH", "SOL", "XRP", "BNB", "DOGE", "ADA", "AVAX", "LINK", "SUI", "TRX", "LTC", "DOT", "NEAR", "APT", "ARB", "OP",
            "WIF", "PEPE", "HYPE", "ENA", "TON", "INJ", "TIA", "SEI"};

    /** Futures build-up: open interest +15% in 24h while price barely moved = big move coming (direction unknown). */
    static List<Event> openInterest() throws Exception {
        List<Event> out = new ArrayList<>();
        long now = System.currentTimeMillis();
        for (String c : OI_COINS) {
            try {
                JSONArray a = new JSONArray(Scanner.getAbsolute("https://fapi.binance.com/futures/data/openInterestHist?symbol=" + c + "USDT&period=1h&limit=25"));
                if (a.length() < 20) continue;
                JSONObject f = a.getJSONObject(0), l = a.getJSONObject(a.length() - 1);
                double o0 = f.optDouble("sumOpenInterestValue", 0), o1 = l.optDouble("sumOpenInterestValue", 0);
                if (o0 <= 0) continue;
                double oiCh = (o1 / o0 - 1) * 100;
                JSONArray k = new JSONArray(Scanner.get("/api/v3/klines?symbol=" + c + "USDT&interval=1h&limit=25"));
                double p0 = Double.parseDouble(k.getJSONArray(0).getString(1)), p1 = Double.parseDouble(k.getJSONArray(k.length() - 1).getString(4));
                double pCh = (p1 / p0 - 1) * 100;
                if (oiCh < 15 || Math.abs(pCh) > 4) continue;
                double fr = 0;
                try {
                    JSONArray fa = new JSONArray(Scanner.getAbsolute("https://fapi.binance.com/fapi/v1/fundingRate?symbol=" + c + "USDT&limit=1"));
                    fr = fa.getJSONObject(0).optDouble("fundingRate", 0) * 100;
                } catch (Exception ignored) {
                }
                Event e = new Event();
                e.type = OI;
                e.time = now;
                e.coins.add(c);
                e.title = String.format(Locale.US, "%s futures mein positions jama: OI %+.0f%% (24h) jab ke price sirf %+.1f%% · funding %.3f%%", c, oiCh, pCh, fr);
                e.source = "Binance Futures";
                e.link = "https://www.binance.com/en/futures/" + c + "USDT";
                e.severity = oiCh >= 30 ? 3 : 2;
                e.dir = fr > 0.03 ? -1 : fr < -0.01 ? 1 : 0;   // crowded longs -> squeeze down risk; crowded shorts -> squeeze up
                out.add(e);
            } catch (Exception ignored) {
            }
        }
        return out;
    }

    static List<Event> macro(Context ctx) {
        List<Event> out = new ArrayList<>();
        for (MacroEngine.Event m : MacroEngine.calendar(ctx, false)) {
            if (!"High".equals(m.impact)) continue;
            Event e = new Event();
            e.type = MACRO;
            e.time = m.time;
            e.title = "🇺🇸 " + m.title + (m.forecast.isEmpty() ? "" : " · forecast " + m.forecast);
            e.source = "Economic calendar";
            e.severity = 3;
            e.impact = m.expectation;
            out.add(e);
        }
        return out;
    }

    static final String[] MONTHS = {"january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"};
    static final Pattern MONTH_DAY = Pattern.compile("(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\\.?\\s+(\\d{1,2})(st|nd|rd|th)?\\b");

    /** Scheduled things mentioned in the news: launches, upgrades, TGE, airdrops, ETF deadlines, "will list", unlocks. */
    static List<Event> fromNews(Context ctx) {
        List<Event> out = new ArrayList<>();
        long now = System.currentTimeMillis();
        for (NewsEngine.Item it : NewsEngine.fetch(ctx, 10 * 60_000L)) {
            if (now - it.time > 4L * 86_400_000L) continue;
            String t = it.title.toLowerCase(Locale.US);
            String type = null;
            int dir = 0, sev = 2;
            if (t.contains("unlock")) { type = UNLOCK; dir = -1; }
            else if (t.contains("delist")) { type = DELIST; dir = -1; sev = 3; }
            else if (t.contains("will list") || t.contains("to list") || t.contains("roadmap") || t.contains("listing on")) { type = LISTING; dir = 1; }
            else if (t.contains("airdrop") || t.contains("tge") || t.contains("token generation")) { type = AIRDROP; dir = 0; }
            else if (t.contains("mainnet") || t.contains("upgrade") || t.contains("hard fork") || t.contains("launch") || t.contains("goes live")) { type = LAUNCH; dir = 1; sev = 1; }
            else if (t.contains("etf") && (t.contains("deadline") || t.contains("decision") || t.contains("approval") || t.contains("launch"))) { type = ETF; dir = 1; sev = 3; }
            if (type == null) continue;
            boolean future = t.contains("will ") || t.contains("next week") || t.contains("tomorrow") || t.contains("upcoming") || t.contains("set to")
                    || t.contains("scheduled") || t.contains("plans") || t.contains("deadline") || t.contains(" to ") || MONTH_DAY.matcher(t).find();
            if (!future) continue;
            Event e = new Event();
            e.type = type;
            e.title = it.title;
            e.source = it.source + " (news)";
            e.link = it.link;
            e.coins.addAll(it.coins);
            e.dir = dir;
            e.severity = Math.max(sev, it.severity >= 3 ? 3 : sev);
            e.time = dateFrom(t, it.time);
            e.estimated = true;
            out.add(e);
        }
        return out;
    }

    /** Best guess of the event date from text ("tomorrow", "next week", "Nov 5", "2026-11-05"); fallback = +2 days. */
    static long dateFrom(String t, long published) {
        Matcher iso = ISO_DATE.matcher(t);
        if (iso.find()) return utc(Integer.parseInt(iso.group(1)), Integer.parseInt(iso.group(2)), Integer.parseInt(iso.group(3)), 12);
        Matcher m = MONTH_DAY.matcher(t);
        if (m.find()) {
            String mo = m.group(1);
            int mi = 0;
            for (int i = 0; i < 12; i++) if (MONTHS[i].startsWith(mo)) { mi = i; break; }
            int day = Integer.parseInt(m.group(2));
            if (day >= 1 && day <= 31) {
                Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
                c.setTimeInMillis(published);
                int y = c.get(Calendar.YEAR);
                long tt = utc(y, mi + 1, day, 12);
                if (tt < published - 20L * 86_400_000L) tt = utc(y + 1, mi + 1, day, 12);
                return tt;
            }
        }
        if (t.contains("tomorrow")) return published + 86_400_000L;
        if (t.contains("next week")) return published + 7L * 86_400_000L;
        if (t.contains("next month")) return published + 30L * 86_400_000L;
        if (t.contains("today")) return published + 3 * 3600_000L;
        return published + 2L * 86_400_000L;
    }

    /** CoinMarketCal (free developer key): the biggest crypto events calendar. */
    static List<Event> coinMarketCal(String key) throws Exception {
        List<Event> out = new ArrayList<>();
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL("https://developers.coinmarketcal.com/v1/events?max=75&showOnly=hot_events").openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setRequestProperty("x-api-key", key);
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("Accept-Encoding", "identity");
        StringBuilder sb = new StringBuilder();
        try (java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(c.getInputStream(), "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        } finally {
            c.disconnect();
        }
        JSONObject o = new JSONObject(sb.toString());
        JSONArray a = o.optJSONArray("body");
        if (a == null) return out;
        for (int i = 0; i < a.length(); i++) {
            JSONObject ev = a.optJSONObject(i);
            if (ev == null) continue;
            Event e = new Event();
            JSONObject ti = ev.optJSONObject("title");
            e.title = ti != null ? ti.optString("en", "") : ev.optString("title", "");
            e.time = NewsEngine.parseDate(ev.optString("date_event"));
            e.source = "CoinMarketCal";
            e.link = "https://coinmarketcal.com/en/event/" + ev.optString("slug", String.valueOf(ev.optInt("id")));
            JSONArray coins = ev.optJSONArray("coins");
            if (coins != null) for (int k = 0; k < coins.length(); k++) {
                JSONObject co = coins.optJSONObject(k);
                if (co != null && !co.optString("symbol").isEmpty()) e.coins.add(co.optString("symbol").toUpperCase(Locale.US));
            }
            String cat = "";
            JSONArray cats = ev.optJSONArray("categories");
            if (cats != null && cats.length() > 0) cat = cats.optJSONObject(0) != null ? cats.optJSONObject(0).optString("name", "") : "";
            String cl = (cat + " " + e.title).toLowerCase(Locale.US);
            e.type = cl.contains("unlock") ? UNLOCK : cl.contains("delist") ? DELIST : cl.contains("listing") || cl.contains("exchange") ? LISTING
                    : cl.contains("airdrop") ? AIRDROP : cl.contains("release") || cl.contains("fork") || cl.contains("launch") || cl.contains("update") ? LAUNCH : EVENT;
            e.dir = e.type.equals(UNLOCK) || e.type.equals(DELIST) ? -1 : e.type.equals(EVENT) ? 0 : 1;
            e.severity = ev.optInt("percentage", 50) >= 80 ? 2 : 1;
            if (!cat.isEmpty()) e.impact = "Category: " + cat;
            out.add(e);
        }
        return out;
    }

    // ------------------------------------------------------------------ explanation
    static void explain(Event e) {
        String who = e.coins.isEmpty() ? "market" : String.join(", ", e.coins);
        String extra = e.impact.isEmpty() ? "" : e.impact + " · ";
        switch (e.type) {
            case UNLOCK:
                e.impact = extra + "Unlock ke din naye coins market mein aate hain — log aksar pehle hi bech dete hain. Jitna bara (% market cap), utna zyada dabao.";
                e.action = "Unlock se 3–5 din pehle " + who + " ka naya BUY na lein; hold ho to profit lene ka socho. Unlock ke 1–3 din baad aksar dabao khatam ho jata hai.";
                break;
            case LISTING:
                e.impact = extra + "Bare exchange par listing tak aksar price upar jaati hai (log pehle khareedte hain); listing ke waqt 'sell the news' bhi hota hai.";
                e.action = "Elaan ke foran baad, listing se pehle chhoti spot position + stop. Listing ki pehli candle par aksar profit lena behtar.";
                break;
            case DELIST:
                e.impact = extra + "Delisting ki tareekh tak liquidity khatam hoti hai — price 20–50% gir sakti hai.";
                e.action = who + " ka koi BUY nahi; hold ho to tareekh se pehle bech dein ya doosre exchange par le jayen.";
                break;
            case AIRDROP:
                e.impact = extra + "Airdrop / Launchpool se pehle demand barhti hai, milne ke baad log bechte hain.";
                e.action = "Airdrop ke baad wale din bari bikwali ka khayal rakhein.";
                break;
            case LAUNCH:
                e.impact = extra + "Mainnet / upgrade se pehle 'buy the rumor', launch ke din aksar 'sell the news'.";
                e.action = "Tareekh se pehle trend ke saath; launch ke din profit lene ka plan.";
                break;
            case ETF:
                e.impact = extra + "ETF ka faisla bara catalyst hai — approval par tez move, reject/delay par giraawat.";
                e.action = "Faisle se pehle leverage kam; faisle ke baad direction confirm hone par entry.";
                break;
            case MACRO:
                e.action = "Release ke ±30 min mein naya trade na lein (bot is waqt signals rok deta hai).";
                if (e.impact.isEmpty()) e.impact = "US data se poori market hilti hai.";
                break;
            case ODDS:
                e.impact = extra + "Polymarket par log asal paisa laga rahe hain — odds ka achanak badalna aksar dikhata hai ke kisi ko kuch pehle pata hai ya khabar aane wali hai.";
                e.action = "Is ko akela signal na samjhein; related coin ka chart aur news dekhein.";
                break;
            case OI:
                e.impact = "Futures mein bohot nayi positions khul rahi hain magar price ruki hui hai — bara move qareeb hai. Funding zyada positive = longs bhare hue (neeche ka jhatka mumkin), negative = shorts bhare (short squeeze mumkin).";
                e.action = "Breakout ki direction ka intezar karein; dono taraf stop zaroori.";
                break;
            default:
                e.impact = extra + "Coin ka scheduled event.";
                e.action = "Tareekh qareeb aane par chart aur volume dekhein.";
        }
    }

    // ------------------------------------------------------------------ for signals
    /** Events for a coin within [now - back, now + ahead]. */
    public static List<Event> forCoin(String base, long ahead) {
        List<Event> out = new ArrayList<>();
        long now = System.currentTimeMillis();
        for (Event e : cache) {
            if (!e.coins.contains(base)) continue;
            boolean detected = e.type.equals(ODDS) || e.type.equals(OI);
            if (detected ? now - e.time < 24 * 3600_000L : e.time >= now - 6 * 3600_000L && e.time <= now + ahead) out.add(e);
        }
        return out;
    }

    /** Reason to block a BUY (big unlock in ≤3 days, delisting ahead), or null. */
    public static Event buyBlocker(String base) {
        long now = System.currentTimeMillis();
        for (Event e : forCoin(base, 3L * 86_400_000L)) {
            if (e.type.equals(DELIST)) return e;
            if (e.type.equals(UNLOCK) && e.time > now && e.severity >= 2) return e;
        }
        return null;
    }

    /** −100..100 catalyst score for a coin (upcoming 7 days + fresh odds / OI signals). */
    public static int score(String base) {
        long now = System.currentTimeMillis();
        double s = 0;
        for (Event e : forCoin(base, 7L * 86_400_000L)) {
            double days = Math.max(0.2, (e.time - now) / 86_400_000.0);
            double w = e.severity * (e.type.equals(ODDS) || e.type.equals(OI) ? 1 : Math.min(1.5, 2.5 / days));
            s += e.dir * w * 15;
        }
        return (int) Math.max(-100, Math.min(100, Math.round(s)));
    }

    // ------------------------------------------------------------------ reminders (24 h and 1 h before)
    public static void tick(Context ctx) {
        List<Event> l = fetch(ctx, 30 * 60_000L);
        if (!Prefs.notifOn(ctx, Prefs.N_CATALYST)) return;
        long now = System.currentTimeMillis();
        Set<String> sent = new LinkedHashSet<>(java.util.Arrays.asList(Prefs.getStr(ctx, "catsent", "").split("\\|")));
        int n = 0;
        for (Event e : l) {
            if (e.severity < 2 || n >= 3) continue;
            String stage = null;
            boolean detected = e.type.equals(ODDS) || e.type.equals(OI);
            long dt = e.time - now;
            if (detected) stage = "now";
            else if (dt > 0 && dt <= 3600_000L) stage = "1h";
            else if (dt > 3600_000L && dt <= 24 * 3600_000L) stage = "24h";
            if (stage == null) continue;
            String k = e.id + "#" + stage;
            if (sent.contains(k)) continue;
            sent.add(k);
            if (!Notify.allowed(ctx, Prefs.N_CATALYST)) continue;
            String when = detected ? "abhi" : stage.equals("1h") ? MacroEngine.mins(dt) + " baad" : "kal tak (" + MacroEngine.pkt(e.time) + ")";
            String coins = e.coins.isEmpty() ? "" : " · " + String.join(", ", e.coins);
            Notify.showPage(ctx, Prefs.N_CATALYST, k.hashCode(), "📆 " + e.icon() + " " + label(e) + " · " + when + coins,
                    e.title + "\n🧠 " + e.impact + "\n👉 " + e.action, e.dir > 0 ? 0xFF0ECB81 : e.dir < 0 ? 0xFFF6465D : 0xFFF0B90B, "catalyst");
            n++;
        }
        List<String> keep = new ArrayList<>(sent);
        if (keep.size() > 400) keep = keep.subList(keep.size() - 400, keep.size());
        Prefs.putStr(ctx, "catsent", String.join("|", keep));
    }

    public static String label(Event e) {
        switch (e.type) {
            case UNLOCK: return "Token unlock";
            case LISTING: return "Listing";
            case DELIST: return "Delisting";
            case AIRDROP: return "Airdrop / Launchpool";
            case LAUNCH: return "Launch / Upgrade";
            case MACRO: return "US macro";
            case ETF: return "ETF";
            case ODDS: return "Polymarket odds";
            case OI: return "Futures build-up";
            default: return "Event";
        }
    }
}
