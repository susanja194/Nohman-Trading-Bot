package com.signal.bot;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * 📊 Indicator probability lab — for MACD, MA (EMA 9/21), RSI (30/70) and all three together, on M5 · M15 · M30:
 * every BUY ▲ / SELL ▼ arrow in the last ~1000 candles is replayed to measure
 *   • how often price went the right way after N candles (win %),
 *   • the average move, the best holding time (exit after how many candles),
 *   • a 1.5×ATR target vs 1×ATR stop test,
 *   • and "exit on the opposite arrow".
 * Then it says which arrow is active RIGHT NOW on each timeframe and what history says about it.
 * History is not a guarantee — it is the honest base-rate of each arrow on this coin.
 */
public final class ArrowLab {
    private ArrowLab() {}

    public static final String[] RULES = {"MACD", "MA 9/21", "RSI 30/70", "MACD+MA+RSI"};

    public static final class Stat {
        public String rule;
        public boolean buy;
        public int n;
        public double winPct, avgPct, tpFirstPct, oppAvgPct;
        public int bestBars, holdBars;
        public double bestAvgPct;
        public String exitTip = "";
    }

    public static final class TfResult {
        public String tf;
        public long barMs;
        public final List<Stat> stats = new ArrayList<>();
        /** active arrow per rule: {side (+1/−1/0), bars ago} */
        public final int[][] now = new int[RULES.length][2];
        public double price;
    }

    // ------------------------------------------------------------------ arrows
    /** side[i] = +1 BUY arrow, −1 SELL arrow, 0 none — for one rule, on closed candles. */
    public static int[] arrows(Candles c, int rule) {
        int n = c.n;
        int[] out = new int[n];
        if (n < 40) return out;
        double[] e12 = Indicators.ema(c.close, 12), e26 = Indicators.ema(c.close, 26);
        double[] macd = new double[n];
        for (int i = 0; i < n; i++) macd[i] = e12[i] - e26[i];
        double[] sig = Indicators.ema(macd, 9);
        double[] e9 = Indicators.ema(c.close, 9), e21 = Indicators.ema(c.close, 21);
        double[] rsi = Indicators.rsi(c.close, 14);
        int last = -10;
        for (int i = 35; i < n; i++) {
            boolean mUp = macd[i] > sig[i] && macd[i - 1] <= sig[i - 1], mDn = macd[i] < sig[i] && macd[i - 1] >= sig[i - 1];
            boolean aUp = e9[i] > e21[i] && e9[i - 1] <= e21[i - 1], aDn = e9[i] < e21[i] && e9[i - 1] >= e21[i - 1];
            boolean rUp = rsi[i] > 30 && rsi[i - 1] <= 30, rDn = rsi[i] < 70 && rsi[i - 1] >= 70;
            int s = 0;
            switch (rule) {
                case 0: s = mUp ? 1 : mDn ? -1 : 0; break;
                case 1: s = aUp ? 1 : aDn ? -1 : 0; break;
                case 2: s = rUp ? 1 : rDn ? -1 : 0; break;
                default: {
                    boolean trigUp = mUp || aUp || (macd[i - 1] > sig[i - 1] && macd[i - 2] <= sig[i - 2]) || (e9[i - 1] > e21[i - 1] && e9[i - 2] <= e21[i - 2]);
                    boolean trigDn = mDn || aDn || (macd[i - 1] < sig[i - 1] && macd[i - 2] >= sig[i - 2]) || (e9[i - 1] < e21[i - 1] && e9[i - 2] >= e21[i - 2]);
                    if (trigUp && macd[i] > sig[i] && e9[i] > e21[i] && rsi[i] >= 45 && rsi[i] <= 70) s = 1;
                    else if (trigDn && macd[i] < sig[i] && e9[i] < e21[i] && rsi[i] <= 55 && rsi[i] >= 30) s = -1;
                    if (s != 0 && i - last < 4) s = 0;   // no repeated arrows
                }
            }
            if (s != 0) { out[i] = s; last = i; }
        }
        return out;
    }

    /** Exit points for the combined rule: opposite arrow, EMA9/21 cross back, or RSI exhaustion (>75 turning down / <25 turning up). */
    public static int[] exits(Candles c, int[] arr) {
        int n = c.n;
        int[] ex = new int[n];
        double[] e9 = Indicators.ema(c.close, 9), e21 = Indicators.ema(c.close, 21), rsi = Indicators.rsi(c.close, 14);
        int pos = 0;
        for (int i = 1; i < n; i++) {
            if (pos != 0) {
                boolean out = arr[i] == -pos
                        || (pos > 0 && e9[i] < e21[i] && e9[i - 1] >= e21[i - 1]) || (pos < 0 && e9[i] > e21[i] && e9[i - 1] <= e21[i - 1])
                        || (pos > 0 && rsi[i - 1] > 75 && rsi[i] < rsi[i - 1]) || (pos < 0 && rsi[i - 1] < 25 && rsi[i] > rsi[i - 1]);
                if (out) { ex[i] = pos; pos = 0; }
            }
            if (arr[i] != 0 && pos == 0) pos = arr[i];
        }
        return ex;
    }

    // ------------------------------------------------------------------ statistics
    public static TfResult study(Candles c, String tf) {
        TfResult t = new TfResult();
        t.tf = tf;
        t.barMs = ChartView.tfMillis(tf);
        int n = c.n;
        if (n < 80) return t;
        t.price = c.close[n - 1];
        double[] tr = new double[n];
        for (int i = 1; i < n; i++)
            tr[i] = Math.max(c.high[i] - c.low[i], Math.max(Math.abs(c.high[i] - c.close[i - 1]), Math.abs(c.low[i] - c.close[i - 1])));
        double[] atr = new double[n];
        for (int i = 1; i < n; i++) atr[i] = i < 15 ? tr[i] : (atr[i - 1] * 13 + tr[i]) / 14;
        final int H = 24, HOLD = 6;
        for (int r = 0; r < RULES.length; r++) {
            int[] a = arrows(c, r);
            // current arrow (last 6 closed candles)
            for (int i = n - 1; i >= Math.max(0, n - 7); i--) if (a[i] != 0) { t.now[r][0] = a[i]; t.now[r][1] = n - 1 - i; break; }
            for (int side : new int[]{1, -1}) {
                Stat s = new Stat();
                s.rule = RULES[r];
                s.buy = side > 0;
                double[] sumK = new double[H + 1];
                int[] cntK = new int[H + 1];
                int wins = 0, cnt = 0, tpFirst = 0, tpTests = 0, opp = 0;
                double sum = 0, oppSum = 0;
                for (int i = 35; i < n - 1; i++) {
                    if (a[i] != side) continue;
                    double p0 = c.close[i];
                    for (int k = 1; k <= H && i + k < n; k++) {
                        sumK[k] += side * (c.close[i + k] / p0 - 1) * 100;
                        cntK[k]++;
                    }
                    if (i + HOLD < n) {
                        double ret = side * (c.close[i + HOLD] / p0 - 1) * 100;
                        cnt++;
                        sum += ret;
                        if (ret > 0) wins++;
                    }
                    // ATR test: 1.5 ATR target vs 1 ATR stop
                    if (atr[i] > 0) {
                        double tp = p0 + side * 1.5 * atr[i], sl = p0 - side * atr[i];
                        for (int k = i + 1; k < n && k <= i + 60; k++) {
                            boolean hitTp = side > 0 ? c.high[k] >= tp : c.low[k] <= tp;
                            boolean hitSl = side > 0 ? c.low[k] <= sl : c.high[k] >= sl;
                            if (hitSl) { tpTests++; break; }
                            if (hitTp) { tpTests++; tpFirst++; break; }
                        }
                    }
                    // exit on the opposite arrow
                    for (int k = i + 1; k < n && k <= i + 200; k++) {
                        if (a[k] == -side) { oppSum += side * (c.close[k] / p0 - 1) * 100; opp++; break; }
                    }
                }
                s.n = cnt;
                s.winPct = cnt > 0 ? wins * 100.0 / cnt : 0;
                s.avgPct = cnt > 0 ? sum / cnt : 0;
                s.holdBars = HOLD;
                s.tpFirstPct = tpTests > 0 ? tpFirst * 100.0 / tpTests : 0;
                s.oppAvgPct = opp > 0 ? oppSum / opp : 0;
                double best = -1e9;
                for (int k = 1; k <= H; k++) if (cntK[k] >= 3 && sumK[k] / cntK[k] > best) { best = sumK[k] / cntK[k]; s.bestBars = k; }
                s.bestAvgPct = best == -1e9 ? 0 : best;
                // which exit worked best on this coin / timeframe
                double atrExp = tpTests > 0 ? (s.tpFirstPct / 100 * 1.5 - (1 - s.tpFirstPct / 100)) : -9;   // in "R"
                String bars = s.bestBars + " candles (~" + mins(s.bestBars * t.barMs) + ")";
                if (s.n < 5) s.exitTip = "Data kam — faisla nahi";
                else if (s.bestAvgPct <= 0 && s.oppAvgPct <= 0) s.exitTip = "Is coin par yeh arrow aksar FAIL — follow na karein";
                else if (atrExp > 0.15 && s.tpFirstPct >= 45) s.exitTip = String.format(Locale.US, "Target 1.5×ATR / stop 1×ATR (%.0f%% target pehle)", s.tpFirstPct);
                else if (s.oppAvgPct > s.bestAvgPct) s.exitTip = "Ulta arrow aane par exit";
                else s.exitTip = "~" + bars + " baad exit";
                t.stats.add(s);
            }
        }
        return t;
    }

    static String mins(long ms) {
        long m = ms / 60_000L;
        return m < 60 ? m + " min" : m < 1440 ? (m / 60) + " ghante" + (m % 60 > 0 ? " " + (m % 60) + "m" : "") : (m / 1440) + " din";
    }

    /** Binance (crypto) or Yahoo (gold / forex) candles for M5 · M15 · M30. */
    public static List<TfResult> run(String symbolOrYahoo, boolean yahoo) throws Exception {
        List<TfResult> out = new ArrayList<>();
        for (String tf : new String[]{"5m", "15m", "30m"}) {
            Candles c = yahoo ? YahooData.fetch(symbolOrYahoo, tf, true) : Candles.fetch(symbolOrYahoo, tf, 1000, true);
            out.add(study(c, tf));
        }
        return out;
    }

    public static Stat find(TfResult t, int rule, boolean buy) {
        for (Stat s : t.stats) if (s.rule.equals(RULES[rule]) && s.buy == buy) return s;
        return null;
    }

    /** One-line verdict across the three timeframes for the combined rule. */
    public static String verdict(List<TfResult> l) {
        int up = 0, dn = 0;
        double p = 0;
        int k = 0;
        for (TfResult t : l) {
            int side = t.now[3][0];
            if (side == 0) continue;
            if (side > 0) up++; else dn++;
            Stat s = find(t, 3, side > 0);
            if (s != null && s.n >= 5) { p += s.winPct; k++; }
        }
        if (up == 0 && dn == 0) return "⚪ Abhi kisi timeframe par MACD+MA+RSI ka taaza arrow nahi — intezar";
        String side = up > dn ? "BUY ▲" : dn > up ? "SELL ▼" : "MIXED";
        return (up > dn ? "🟢 " : dn > up ? "🔴 " : "⚪ ") + side + " arrow " + Math.max(up, dn) + "/3 timeframes par"
                + (k > 0 ? String.format(Locale.US, " · history: ~%.0f%% dafa sahi gaya", p / k) : "");
    }
}
