package com.signal.bot;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Exact USD money flow (aggressive buy − aggressive sell) on Binance SPOT + FUTURES over 15 min · 1 h · 4 h · 24 h
 * (5m candles with taker-buy quote volume), plus a PRICE-IMPACT model: from the last 24 h it learns how much net
 * money this coin needs to move its price — so small coins can signal on small volume and big coins need big volume.
 * MarketFlow adds every other exchange on top of this.
 */
public final class HeavyFlow {
    private HeavyFlow() {}

    public static final class Result {
        public final double[] spot = new double[4], fut = new double[4];   // net USD: 15m, 1h, 4h, 24h
        public final double[] gross = new double[4];                        // total traded USD
        public boolean hasFut;
        /** Price % change per $1M of net flow in one 5-minute candle (learned from the last 24 h). */
        public double impactPerM;
        /** Average 5-minute range in % (ATR of 5m candles). */
        public double atr5Pct;
        public double lastPrice, move15Pct;

        public double net(int k) { return spot[k] + fut[k]; }
        public double net15() { return net(0); }
        public double net1h() { return net(1); }
        public double net4h() { return net(2); }
        public double net24h() { return net(3); }

        /** Net USD that usually moves this coin by `pct` percent (null model -> +inf). */
        public double netForMove(double pct) {
            if (impactPerM <= 0) return Double.MAX_VALUE;
            return pct / impactPerM * 1_000_000.0;
        }

        public List<String> lines() {
            List<String> l = new ArrayList<>();
            String[] w = {"15 min", "1 ghanta", "4 ghante", "24 ghante"};
            for (int k = 0; k < 4; k++) {
                double n = net(k);
                l.add(String.format(Locale.US, "%s: net %s%s %s (Binance spot %s%s · futures %s%s)", w[k], n >= 0 ? "+" : "−", Fmt.usd(Math.abs(n)),
                        n >= 0 ? "🟢" : "🔴", spot[k] >= 0 ? "+" : "−", Fmt.usd(Math.abs(spot[k])), fut[k] >= 0 ? "+" : "−", Fmt.usd(Math.abs(fut[k]))));
            }
            return l;
        }
    }

    private static final int[] SPAN = {3, 12, 48, 288};

    /** Parses 5m klines; adds windows into net/gross and returns {net per candle, close, high, low} arrays. */
    static double[][] sum(String json, double[] net, double[] gross) throws Exception {
        JSONArray a = new JSONArray(json);
        int n = a.length();
        double[][] out = new double[4][n];
        for (int i = 0; i < n; i++) {
            JSONArray k = a.getJSONArray(i);
            double q = Double.parseDouble(k.getString(7)), tb = Double.parseDouble(k.getString(10));
            double v = 2 * tb - q;
            out[0][i] = v;
            out[1][i] = Double.parseDouble(k.getString(4));
            out[2][i] = Double.parseDouble(k.getString(2));
            out[3][i] = Double.parseDouble(k.getString(3));
            int fromEnd = n - 1 - i;
            for (int w = 0; w < 4; w++) {
                if (fromEnd < SPAN[w]) {
                    net[w] += v;
                    if (gross != null) gross[w] += q;
                }
            }
        }
        return out;
    }

    public static Result fetch(String sym) throws Exception {
        Result r = new Result();
        double[][] s = sum(Scanner.get("/api/v3/klines?symbol=" + sym + "&interval=5m&limit=288"), r.spot, r.gross);
        double[][] f = null;
        try {
            f = sum(Scanner.getAbsolute("https://fapi.binance.com/fapi/v1/klines?symbol=" + sym + "&interval=5m&limit=288"), r.fut, r.gross);
            r.hasFut = true;
        } catch (Exception ignored) {
        }
        int n = s[0].length;
        if (n > 20) {
            // regression through the origin: return% = beta * netUSD(M) per candle (spot + futures)
            double sxy = 0, sxx = 0, atr = 0;
            for (int i = 1; i < n; i++) {
                double net = s[0][i] + (f != null && f[0].length == n ? f[0][i] : 0);
                double ret = s[1][i - 1] > 0 ? (s[1][i] / s[1][i - 1] - 1) * 100 : 0;
                double x = net / 1_000_000.0;
                sxy += x * ret;
                sxx += x * x;
                atr += s[1][i] > 0 ? (s[2][i] - s[3][i]) / s[1][i] * 100 : 0;
            }
            r.impactPerM = sxx > 0 ? Math.max(0, sxy / sxx) : 0;
            r.atr5Pct = atr / (n - 1);
            r.lastPrice = s[1][n - 1];
            if (n > 3 && s[1][n - 4] > 0) r.move15Pct = (s[1][n - 1] / s[1][n - 4] - 1) * 100;
        }
        return r;
    }

    /** Quick spot-only net USD over the last `ms` from already-loaded candles (no extra request). */
    public static double quickNet(Candles c, long ms) {
        if (c == null || c.n == 0) return 0;
        long from = System.currentTimeMillis() - ms;
        double s = 0;
        for (int i = c.n - 1; i >= 0 && c.time[i] >= from - 1; i--) s += 2 * c.takerBuyQuote[i] - c.quoteVol[i];
        return s;
    }

    public static double quickGross(Candles c, long ms) {
        if (c == null || c.n == 0) return 0;
        long from = System.currentTimeMillis() - ms;
        double s = 0;
        for (int i = c.n - 1; i >= 0 && c.time[i] >= from - 1; i--) s += c.quoteVol[i];
        return s;
    }

    /**
     * "Heavy" (fast-track) for scalping: at least 8% of everything traded in those 15 minutes, and the $ floor from
     * Settings — but the floor never asks a small coin for more than 30% of its own 15-minute volume.
     */
    public static double scalpThreshold(double minUsd, double gross15) {
        return Math.max(gross15 * 0.08, Math.min(minUsd, gross15 * 0.30));
    }

    /**
     * "Enough" volume for a scalp on THIS coin: the net 15-min flow that historically moves its price by about
     * one scalp target (max of 0.35% and 1.5 × the 5-minute ATR), bounded to [$15k, heavy].
     */
    public static double scalpEnough(Result hf, double heavy) {
        double target = Math.max(0.35, 1.5 * hf.atr5Pct);
        double need = hf.netForMove(target);   // impact is additive over the 3 five-minute candles
        return Math.max(15_000, Math.min(heavy, need));
    }
}
