package com.signal.bot;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The ParaDox confluence rule — ONE rule used for live signals AND for the backtest, so the
 * shown win rate is the real historical hit rate of exactly what the bot sends.
 *
 * BUY when ALL agree on the closed candle:
 *   1. Trend: EMA21 > EMA50 and price > EMA50 (and > EMA200 when available)
 *   2. Trigger: EMA9 crossed above EMA21 in the last 3 candles, OR a pullback to EMA21 bounced
 *   3. Momentum: RSI 50–72 and MACD histogram > 0
 *   4. Participation: volume >= 0.9x its 20-candle average (skipped for FX, which has no real volume)
 * SELL is the mirror image. Exits: stop = 1.5 ATR, target = R multiple (default 1.5R).
 */
public final class ParadoxRule {
    private ParadoxRule() {}

    public static final class Ind {
        public double[] e9, e21, e50, e200, rsi, hist, atr, volAvg;
        public double[] close, high, low, vol;
        public boolean hasVol;
    }

    public static Ind prepare(Candles c) {
        Ind x = new Ind();
        x.close = c.close;
        x.high = c.high;
        x.low = c.low;
        x.vol = c.vol;
        x.e9 = Indicators.ema(c.close, 9);
        x.e21 = Indicators.ema(c.close, 21);
        x.e50 = Indicators.ema(c.close, 50);
        x.e200 = Indicators.ema(c.close, 200);
        x.rsi = Indicators.rsi(c.close, 14);
        x.hist = Indicators.macdHist(c.close);
        int n = c.n;
        x.atr = new double[n];
        x.volAvg = new double[n];
        double v = 0;
        for (int i = 0; i < n; i++) v += c.vol[i];
        x.hasVol = v > 0;
        for (int i = 1; i < n; i++) {
            double tr = Math.max(c.high[i] - c.low[i], Math.max(Math.abs(c.high[i] - c.close[i - 1]), Math.abs(c.low[i] - c.close[i - 1])));
            x.atr[i] = i < 15 ? tr : (x.atr[i - 1] * 13 + tr) / 14;
        }
        for (int i = 0; i < n; i++) x.volAvg[i] = Indicators.mean(c.vol, i - 20, i);
        return x;
    }

    /** EMA9 crossed EMA21 (up = true) within the last 3 candles. */
    static boolean crossed(Ind x, int i, boolean up) {
        for (int k = i; k > i - 3 && k > 0; k--) {
            if (up ? x.e9[k] > x.e21[k] && x.e9[k - 1] <= x.e21[k - 1] : x.e9[k] < x.e21[k] && x.e9[k - 1] >= x.e21[k - 1]) return true;
        }
        return false;
    }

    /** Pullback to EMA21 (wick touched it in the last 3 candles) and this candle closed back in trend direction. */
    static boolean bounce(Ind x, int i, boolean up) {
        boolean touched = false;
        for (int k = i; k > i - 3 && k > 0; k--) {
            if (up ? x.low[k] <= x.e21[k] : x.high[k] >= x.e21[k]) touched = true;
        }
        if (!touched) return false;
        return up ? x.close[i] > x.e21[i] && x.close[i] > x.close[i - 1] : x.close[i] < x.e21[i] && x.close[i] < x.close[i - 1];
    }

    static boolean volOk(Ind x, int i) {
        return !x.hasVol || x.volAvg[i] <= 0 || x.vol[i] >= 0.9 * x.volAvg[i];
    }

    /** +1 BUY, -1 SELL, 0 none — evaluated on candle i (must be a CLOSED candle). */
    public static int signalAt(Ind x, int i) {
        if (i < 60) return 0;
        double px = x.close[i];
        boolean use200 = i >= 200;
        boolean upTrend = x.e21[i] > x.e50[i] && px > x.e50[i] && (!use200 || px > x.e200[i]);
        boolean dnTrend = x.e21[i] < x.e50[i] && px < x.e50[i] && (!use200 || px < x.e200[i]);
        boolean v = volOk(x, i);
        if (upTrend && (crossed(x, i, true) || bounce(x, i, true)) && x.rsi[i] >= 50 && x.rsi[i] <= 72 && x.hist[i] > 0 && v) return 1;
        if (dnTrend && (crossed(x, i, false) || bounce(x, i, false)) && x.rsi[i] <= 50 && x.rsi[i] >= 28 && x.hist[i] < 0 && v) return -1;
        return 0;
    }

    /** Human-readable checklist for candle i (used to teach "how this signal was built"). */
    public static List<String> checklist(Ind x, int i, int side) {
        List<String> l = new ArrayList<>();
        if (i < 60) return l;
        boolean b = side >= 0;
        double px = x.close[i];
        l.add(mark(b ? x.e21[i] > x.e50[i] : x.e21[i] < x.e50[i]) + " Trend: EMA21 " + (b ? ">" : "<") + " EMA50");
        if (i >= 200) l.add(mark(b ? px > x.e200[i] : px < x.e200[i]) + " Price EMA200 ke " + (b ? "upar" : "neeche"));
        l.add(mark(crossed(x, i, b) || bounce(x, i, b)) + " Trigger: EMA9/21 cross ya EMA21 se bounce");
        l.add(mark(b ? x.rsi[i] >= 50 && x.rsi[i] <= 72 : x.rsi[i] <= 50 && x.rsi[i] >= 28) + String.format(Locale.US, " RSI %.0f (%s)", x.rsi[i], b ? "50–72" : "28–50"));
        l.add(mark(b ? x.hist[i] > 0 : x.hist[i] < 0) + " MACD histogram " + (b ? "positive" : "negative"));
        if (x.hasVol && x.volAvg[i] > 0) l.add(mark(volOk(x, i)) + String.format(Locale.US, " Volume %.1fx average", x.vol[i] / x.volAvg[i]));
        return l;
    }

    private static String mark(boolean ok) { return ok ? "✅" : "❌"; }

    public static final class Backtest {
        public int trades, wins, losses;
        public double winRate, avgR, totalR;
        public final List<int[]> marks = new ArrayList<>();   // {index, side} for chart arrows
        public boolean enough() { return trades >= 5; }
    }

    /**
     * Walk-forward backtest on closed candles: enter at the close of the signal candle,
     * stop = stopAtr x ATR, target = rr x risk; whichever is touched first decides the trade.
     */
    public static Backtest backtest(Candles c, double stopAtr, double rr) {
        Ind x = prepare(c);
        Backtest b = new Backtest();
        int n = c.n;
        int i = 60;
        while (i < n - 1) {
            int s = signalAt(x, i);
            if (s == 0 || x.atr[i] <= 0) { i++; continue; }
            b.marks.add(new int[]{i, s});
            double entry = c.close[i], risk = stopAtr * x.atr[i];
            double sl = s > 0 ? entry - risk : entry + risk, tp = s > 0 ? entry + rr * risk : entry - rr * risk;
            int j = i + 1, res = 0;
            for (; j < n; j++) {
                boolean hitSl = s > 0 ? c.low[j] <= sl : c.high[j] >= sl;
                boolean hitTp = s > 0 ? c.high[j] >= tp : c.low[j] <= tp;
                if (hitSl && hitTp) { res = -1; break; }   // same candle: count as loss (conservative)
                if (hitSl) { res = -1; break; }
                if (hitTp) { res = 1; break; }
            }
            if (res == 0) break;       // still open at the end of data
            b.trades++;
            if (res > 0) { b.wins++; b.totalR += rr; } else { b.losses++; b.totalR -= 1; }
            i = j + 1;
        }
        b.winRate = b.trades > 0 ? b.wins * 100.0 / b.trades : 0;
        b.avgR = b.trades > 0 ? b.totalR / b.trades : 0;
        return b;
    }
}
