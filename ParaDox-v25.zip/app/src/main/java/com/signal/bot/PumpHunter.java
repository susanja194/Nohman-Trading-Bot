package com.signal.bot;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * 🎯 Gainer / Loser hunter — finds coins BEFORE they reach the top-gainers / top-losers list.
 * Pumps almost always leave footprints first:
 *   1. Volume wakes up: last 15 min volume many times its normal pace (RVOL), while the price has NOT moved much yet
 *   2. Aggressive buyers (taker buy %) take over · bid side of the order book thicker than asks
 *   3. Futures positions build (open interest up) · funding not yet crowded
 *   4. Tight range (squeeze) just breaking
 *   5. Korea first: Upbit (KRW) volume spike / kimchi premium often starts Asian pumps
 *   6. News / listing / catalyst for the coin
 * Mirror logic finds dumps. Every alert is tracked: did the coin really move 5%+ within 4 h?
 */
public final class PumpHunter {
    private PumpHunter() {}

    public static final class Pick {
        public String sym, base;
        public boolean pump;            // true = likely gainer, false = likely loser
        public int score;               // 0..100
        public int feat;                // feature bitmask (for learning)
        public String venue = "Binance";
        public double venueSpike = Double.NaN;
        public double price, ch15, ch1h, ch24, rvol15, rvol1h, buyPct, bookImb = Double.NaN, oiCh = Double.NaN, funding = Double.NaN,
                upbitRvol = Double.NaN, kimchi = Double.NaN, vol24, squeeze;
        public final List<String> why = new ArrayList<>();
        public long at;
    }

    public static final class Result {
        public final List<Pick> pumps = new ArrayList<>(), dumps = new ArrayList<>();
        public int scanned;
        public long ms, at;
        public String note = "";
    }

    private static volatile Result cache;
    private static final Object LOCK = new Object();
    private static final ExecutorService POOL = Executors.newFixedThreadPool(6);

    public static Result cached() { return cache; }

    static double d(String s) {
        try { return Double.parseDouble(s); } catch (Exception e) { return 0; }
    }

    /** Binance rolling-window stats for many symbols (100 per request). {sym -> {quoteVol, change%}} */
    static Map<String, double[]> window(List<String> syms, String w) {
        Map<String, double[]> out = new HashMap<>();
        for (int i = 0; i < syms.size(); i += 100) {
            List<String> part = syms.subList(i, Math.min(syms.size(), i + 100));
            StringBuilder q = new StringBuilder("[");
            for (String s : part) { if (q.length() > 1) q.append(','); q.append('"').append(s).append('"'); }
            q.append(']');
            try {
                JSONArray a = new JSONArray(Scanner.get("/api/v3/ticker?type=MINI&windowSize=" + w + "&symbols=" + java.net.URLEncoder.encode(q.toString(), "UTF-8")));
                for (int k = 0; k < a.length(); k++) {
                    JSONObject o = a.getJSONObject(k);
                    double open = d(o.optString("openPrice")), last = d(o.optString("lastPrice"));
                    out.put(o.optString("symbol"), new double[]{d(o.optString("quoteVolume")), open > 0 ? (last / open - 1) * 100 : 0});
                }
            } catch (Exception ignored) {
            }
        }
        return out;
    }

    public static Result scan(Context ctx) {
        synchronized (LOCK) {
            long t0 = System.currentTimeMillis();
            Result r = new Result();
            if (ctx != null) FEAT_ADJ = Track.featureAdj(ctx);
            loadHype();
            Map<String, double[]> day = new HashMap<>();   // sym -> {last, change24, quoteVol24}
            try {
                JSONArray a = new JSONArray(Scanner.get("/api/v3/ticker/24hr?type=MINI"));
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    String s = o.optString("symbol");
                    if (!Scanner.isTradable(s)) continue;
                    double last = d(o.optString("lastPrice")), open = d(o.optString("openPrice")), qv = d(o.optString("quoteVolume"));
                    if (last <= 0 || qv < 300_000) continue;
                    day.put(s, new double[]{last, open > 0 ? (last / open - 1) * 100 : 0, qv});
                }
            } catch (Exception e) {
                r.note = "Binance tak pohanch nahi hui";
                return r;
            }
            List<String> syms = new ArrayList<>(day.keySet());
            Map<String, double[]> w15 = window(syms, "15m"), w1h = window(syms, "1h");
            r.scanned = syms.size();
            // ---- stage 1: cheap screen on volume pace vs price move
            List<Pick> cands = new ArrayList<>();
            for (String s : syms) {
                double[] dd = day.get(s), a15 = w15.get(s), a1 = w1h.get(s);
                if (a15 == null || a1 == null) continue;
                double pace15 = dd[2] / 96.0, pace1h = dd[2] / 24.0;
                double rv15 = pace15 > 0 ? a15[0] / pace15 : 0, rv1 = pace1h > 0 ? a1[0] / pace1h : 0;
                if (rv15 < 2.2 && rv1 < 1.8) continue;
                Pick p = new Pick();
                p.sym = s;
                p.base = s.substring(0, s.length() - 4);
                p.price = dd[0];
                p.ch24 = dd[1];
                p.vol24 = dd[2];
                p.ch15 = a15[1];
                p.ch1h = a1[1];
                p.rvol15 = rv15;
                p.rvol1h = rv1;
                cands.add(p);
            }
            // early = volume woke up but price has not run yet
            Collections.sort(cands, (x, y) -> Double.compare(early(y), early(x)));
            if (cands.size() > 24) cands = new ArrayList<>(cands.subList(0, 24));
            // ---- stage 2: deep checks in parallel
            List<Callable<Void>> jobs = new ArrayList<>();
            for (final Pick p : cands) jobs.add(() -> { deep(p); return null; });
            try { POOL.invokeAll(jobs, 25, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
            upbit(cands);
            // ---- every other exchange: volume waking up there first (also coins NOT on Binance)
            Map<String, Pick> bySym = new HashMap<>();
            for (Pick p : cands) bySym.put(p.base, p);
            List<Pick> outside = multiVenue(bySym, day.keySet());
            cands.addAll(outside);
            long now = System.currentTimeMillis();
            for (Pick p : cands) {
                score(p);
                p.at = now;
                if (p.score < 40) continue;
                if (p.pump) r.pumps.add(p); else r.dumps.add(p);
            }
            Collections.sort(r.pumps, (x, y) -> y.score - x.score);
            Collections.sort(r.dumps, (x, y) -> y.score - x.score);
            r.ms = System.currentTimeMillis() - t0;
            r.at = now;
            cache = r;
            if (ctx != null) Track.record(ctx, r);
            return r;
        }
    }

    static double early(Pick p) {
        double moved = Math.abs(p.ch1h);
        return p.rvol15 * 1.2 + p.rvol1h - moved * 0.6 - Math.max(0, Math.abs(p.ch24) - 12) * 0.3;
    }

    /** 5m candles (taker buy %, squeeze), order book imbalance, futures OI + funding. */
    static void deep(Pick p) {
        try {
            Candles c = Candles.fetch(p.sym, "5m", 60, false);
            int n = c.n;
            if (n > 20) {
                double tb = 0, q = 0;
                for (int i = n - 3; i < n; i++) { tb += c.takerBuyQuote[i]; q += c.quoteVol[i]; }
                p.buyPct = q > 0 ? tb / q * 100 : 50;
                double hi = 0, lo = Double.MAX_VALUE, hi2 = 0, lo2 = Double.MAX_VALUE;
                for (int i = n - 40; i < n - 4; i++) { hi = Math.max(hi, c.high[i]); lo = Math.min(lo, c.low[i]); }
                for (int i = n - 4; i < n; i++) { hi2 = Math.max(hi2, c.high[i]); lo2 = Math.min(lo2, c.low[i]); }
                p.squeeze = lo > 0 ? (hi / lo - 1) * 100 : 99;   // % range of the 3 hours before
                if (c.close[n - 1] > hi && p.squeeze < 4) p.why.add(String.format(Locale.US, "Tight range (%.1f%%) se UPAR breakout", p.squeeze));
                if (c.close[n - 1] < lo && p.squeeze < 4) p.why.add(String.format(Locale.US, "Tight range (%.1f%%) se NEECHE breakdown", p.squeeze));
            }
        } catch (Exception ignored) {
        }
        try {
            JSONObject o = new JSONObject(Scanner.get("/api/v3/depth?symbol=" + p.sym + "&limit=100"));
            JSONArray b = o.getJSONArray("bids"), a = o.getJSONArray("asks");
            double mid = p.price, bs = 0, as = 0;
            for (int i = 0; i < b.length(); i++) { JSONArray x = b.getJSONArray(i); double pr = d(x.getString(0)); if (pr >= mid * 0.98) bs += pr * d(x.getString(1)); }
            for (int i = 0; i < a.length(); i++) { JSONArray x = a.getJSONArray(i); double pr = d(x.getString(0)); if (pr <= mid * 1.02) as += pr * d(x.getString(1)); }
            if (bs + as > 0) p.bookImb = (bs - as) / (bs + as) * 100;
        } catch (Exception ignored) {
        }
        try {
            JSONArray oi = new JSONArray(Scanner.getAbsolute("https://fapi.binance.com/futures/data/openInterestHist?symbol=" + p.sym + "&period=5m&limit=13"));
            if (oi.length() >= 12) {
                double o0 = oi.getJSONObject(0).optDouble("sumOpenInterestValue", 0), o1 = oi.getJSONObject(oi.length() - 1).optDouble("sumOpenInterestValue", 0);
                if (o0 > 0) p.oiCh = (o1 / o0 - 1) * 100;
            }
            JSONArray f = new JSONArray(Scanner.getAbsolute("https://fapi.binance.com/fapi/v1/fundingRate?symbol=" + p.sym + "&limit=1"));
            if (f.length() > 0) p.funding = f.getJSONObject(0).optDouble("fundingRate", 0) * 100;
        } catch (Exception ignored) {
        }
    }

    /** Korea: Upbit KRW volume spike + kimchi premium for the candidates listed there. */
    static void upbit(List<Pick> l) {
        try {
            JSONArray mk = new JSONArray(Scanner.getAbsolute("https://api.upbit.com/v1/market/all"));
            java.util.Set<String> krw = new java.util.HashSet<>();
            for (int i = 0; i < mk.length(); i++) {
                String m = mk.getJSONObject(i).optString("market");
                if (m.startsWith("KRW-")) krw.add(m.substring(4));
            }
            StringBuilder q = new StringBuilder("KRW-USDT");
            for (Pick p : l) if (krw.contains(p.base)) q.append(",KRW-").append(p.base);
            JSONArray t = new JSONArray(Scanner.getAbsolute("https://api.upbit.com/v1/ticker?markets=" + q));
            double usdtKrw = 0;
            Map<String, JSONObject> tk = new HashMap<>();
            for (int i = 0; i < t.length(); i++) {
                JSONObject o = t.getJSONObject(i);
                String m = o.optString("market").substring(4);
                if (m.equals("USDT")) usdtKrw = o.optDouble("trade_price", 0); else tk.put(m, o);
            }
            for (Pick p : l) {
                JSONObject o = tk.get(p.base);
                if (o == null) continue;
                if (usdtKrw > 0 && p.price > 0) p.kimchi = (o.optDouble("trade_price", 0) / (p.price * usdtKrw) - 1) * 100;
                try {
                    JSONArray cs = new JSONArray(Scanner.getAbsolute("https://api.upbit.com/v1/candles/minutes/15?market=KRW-" + p.base + "&count=2"));
                    double v15 = cs.getJSONObject(0).optDouble("candle_acc_trade_price", 0);
                    double day = o.optDouble("acc_trade_price_24h", 0);
                    if (day > 0) p.upbitRvol = v15 / (day / 96.0);
                } catch (Exception ignored) {
                }
            }
        } catch (Exception ignored) {
        }
    }

    // ------------------------------------------------------------------ other exchanges (snapshots of 24h volume)
    static final String[] VENUES = {"OKX", "Bybit", "Bitget", "KuCoin", "Gate", "MEXC", "HTX", "Bithumb"};
    private static final Map<String, Map<String, double[]>> SNAP = new HashMap<>();   // venue -> base -> {vol24, price, t}
    private static long snapAt;

    static Map<String, double[]> loadVenue(String v) throws Exception {
        Map<String, double[]> m = new HashMap<>();
        if (v.equals("Bithumb")) {
            JSONObject d = new JSONObject(Scanner.getAbsolute("https://api.bithumb.com/public/ticker/ALL_KRW")).getJSONObject("data");
            java.util.Iterator<String> it = d.keys();
            while (it.hasNext()) {
                String k = it.next();
                JSONObject o = d.optJSONObject(k);
                if (o == null) continue;
                m.put(k.toUpperCase(Locale.US), new double[]{d(o.optString("acc_trade_value_24H")), d(o.optString("closing_price")), 0});
            }
            return m;
        }
        for (Map.Entry<String, Mispricing.Quote> e : Mispricing.load(v).entrySet())
            m.put(e.getKey(), new double[]{e.getValue().vol24, e.getValue().last > 0 ? e.getValue().last : e.getValue().mid(), 0});
        return m;
    }

    /**
     * Compares each exchange's rolling 24h volume with the previous snapshot (4–15 min ago): the volume added per minute vs the
     * normal per-minute pace = a volume spike on THAT exchange. Binance coins get extra reasons; coins only listed elsewhere become picks.
     */
    static List<Pick> multiVenue(Map<String, Pick> binPicks, java.util.Set<String> binanceSyms) {
        List<Pick> out = new ArrayList<>();
        long now = System.currentTimeMillis();
        if (now - snapAt < 4 * 60_000L && !SNAP.isEmpty()) return out;
        final Map<String, Map<String, double[]>> fresh = new java.util.concurrent.ConcurrentHashMap<>();
        List<Callable<Void>> jobs = new ArrayList<>();
        for (final String v : VENUES) jobs.add(() -> { try { fresh.put(v, loadVenue(v)); } catch (Exception ignored) { } return null; });
        try { POOL.invokeAll(jobs, 20, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
        boolean have = !SNAP.isEmpty() && now - snapAt < 16 * 60_000L;
        double mins = Math.max(1, (now - snapAt) / 60_000.0);
        Map<String, Pick> outsideBest = new HashMap<>();
        if (have) {
            for (Map.Entry<String, Map<String, double[]>> e : fresh.entrySet()) {
                Map<String, double[]> old = SNAP.get(e.getKey());
                if (old == null) continue;
                boolean krw = e.getKey().equals("Bithumb");
                for (Map.Entry<String, double[]> c : e.getValue().entrySet()) {
                    double[] o = old.get(c.getKey()), nw = c.getValue();
                    if (o == null || o[0] <= 0 || nw[0] <= 0) continue;
                    double usdVol = krw ? nw[0] / 1400.0 : nw[0];
                    if (usdVol < 150_000) continue;
                    double added = (nw[0] - o[0]) / mins, pace = nw[0] / 1440.0;
                    if (added <= 0 || pace <= 0) continue;
                    double spike = added / pace;   // >1 = faster than normal (lower bound: the dropped old volume is ignored)
                    if (spike < 3) continue;
                    double pch = o[1] > 0 ? (nw[1] / o[1] - 1) * 100 : 0;
                    String base = c.getKey();
                    Pick bp = binPicks.get(base);
                    if (bp != null) {
                        if (Double.isNaN(bp.venueSpike) || spike > bp.venueSpike) bp.venueSpike = spike;
                        bp.why.add(String.format(Locale.US, "🌐 %s par bhi volume %.1fx (pichle %.0f min)", e.getKey(), spike, mins));
                    } else if (!binanceSyms.contains(base + "USDT") && !Mispricing.isStable(base)) {
                        Pick p = outsideBest.get(base);
                        if (p != null && p.venueSpike >= spike) continue;
                        p = new Pick();
                        p.sym = base;
                        p.base = base;
                        p.venue = e.getKey();
                        p.price = krw ? 0 : nw[1];
                        p.vol24 = usdVol;
                        p.venueSpike = spike;
                        p.rvol15 = spike;
                        p.rvol1h = spike;
                        p.ch15 = pch;
                        p.ch1h = pch;
                        p.buyPct = pch > 0.3 ? 60 : pch < -0.3 ? 40 : 50;
                        p.why.add(String.format(Locale.US, "🌐 Sirf %s par (Binance par nahi): volume %.1fx, price %+.1f%% pichle %.0f min mein", e.getKey(), spike, pch, mins));
                        outsideBest.put(base, p);
                    }
                }
            }
        }
        SNAP.clear();
        SNAP.putAll(fresh);
        snapAt = now;
        out.addAll(outsideBest.values());
        Collections.sort(out, (a, b) -> Double.compare(b.venueSpike, a.venueSpike));
        if (out.size() > 12) out = new ArrayList<>(out.subList(0, 12));
        return out;
    }

    // ------------------------------------------------------------------ hype: what people search / promote right now
    static volatile java.util.Map<String, Integer> TRENDING = new HashMap<>();
    static volatile java.util.Set<String> BOOSTED = new java.util.HashSet<>();
    private static long hypeAt;

    static void loadHype() {
        if (System.currentTimeMillis() - hypeAt < 10 * 60_000L) return;
        hypeAt = System.currentTimeMillis();
        try {
            JSONArray c = new JSONObject(Scanner.getAbsolute("https://api.coingecko.com/api/v3/search/trending")).getJSONArray("coins");
            Map<String, Integer> m = new HashMap<>();
            for (int i = 0; i < c.length(); i++) {
                JSONObject it = c.getJSONObject(i).optJSONObject("item");
                if (it != null) m.put(it.optString("symbol").toUpperCase(Locale.US), i + 1);
            }
            if (!m.isEmpty()) TRENDING = m;
        } catch (Exception ignored) {
        }
        try {
            JSONArray b = new JSONArray(Scanner.getAbsolute("https://api.dexscreener.com/token-boosts/top/v1"));
            java.util.Set<String> addrs = new java.util.HashSet<>();
            for (int i = 0; i < b.length() && i < 30; i++) {
                JSONObject o = b.getJSONObject(i);
                addrs.add(o.optString("chainId") + ":" + o.optString("tokenAddress"));
            }
            java.util.Set<String> syms = new java.util.HashSet<>();
            int n = 0;
            for (String a : addrs) {
                if (n++ >= 12) break;
                try {
                    String[] ca = a.split(":", 2);
                    JSONObject r = new JSONObject(Scanner.getAbsolute("https://api.dexscreener.com/latest/dex/tokens/" + ca[1]));
                    JSONArray pairs = r.optJSONArray("pairs");
                    if (pairs != null && pairs.length() > 0) syms.add(pairs.getJSONObject(0).getJSONObject("baseToken").optString("symbol").toUpperCase(Locale.US));
                } catch (Exception ignored) {
                }
            }
            if (!syms.isEmpty()) BOOSTED = syms;
        } catch (Exception ignored) {
        }
    }

    /** Feature bits, also used to learn which footprints really worked. */
    static final int F_RVOL = 1, F_BUY = 2, F_BOOK = 4, F_OI = 8, F_KOREA = 16, F_TREND = 32, F_VENUE = 64, F_NEWS = 128;
    static final String[] F_NAMES = {"Volume 4x+", "Buyers 60%+", "Order book", "Futures OI", "Korea", "CoinGecko trending", "Doosre exchange", "News"};
    static volatile double[] FEAT_ADJ = new double[8];

    static void score(Pick p) {
        double bull = 0, bear = 0;
        double rv = Math.max(p.rvol15, p.rvol1h * 0.9);
        double vScore = Math.min(30, (rv - 1.5) * 8);   // volume is the main footprint
        boolean notRun = Math.abs(p.ch1h) < 6 && Math.abs(p.ch24) < 20;
        double dirFlow = (p.buyPct - 50) / 50;          // −1..1
        if (p.buyPct >= 55) bull += vScore; else if (p.buyPct <= 45) bear += vScore; else { bull += vScore / 2; bear += vScore / 2; }
        if (rv >= 4) p.feat |= F_RVOL;
        if (p.buyPct >= 60 || p.buyPct <= 40) p.feat |= F_BUY;
        if (!Double.isNaN(p.bookImb) && Math.abs(p.bookImb) > 15) p.feat |= F_BOOK;
        if (!Double.isNaN(p.oiCh) && Math.abs(p.oiCh) >= 3) p.feat |= F_OI;
        if ((!Double.isNaN(p.upbitRvol) && p.upbitRvol >= 2) || (!Double.isNaN(p.kimchi) && Math.abs(p.kimchi) >= 1.5)) p.feat |= F_KOREA;
        if (!"Binance".equals(p.venue)) p.why.add(0, "📍 Exchange: " + p.venue + " (Binance par listed nahi)");
        else p.why.add(0, String.format(Locale.US, "Volume jaag gaya: 15 min %.1fx · 1 ghanta %.1fx normal se", p.rvol15, p.rvol1h));
        p.why.add(1, String.format(Locale.US, "Aggressive buyers %.0f%% (5m×3)", p.buyPct));
        if (dirFlow > 0) bull += dirFlow * 25; else bear += -dirFlow * 25;
        if (!Double.isNaN(p.bookImb)) {
            if (p.bookImb > 15) { bull += Math.min(12, p.bookImb / 4); p.why.add(String.format(Locale.US, "Order book: BUY side %+.0f%% bhari (2%% ke andar)", p.bookImb)); }
            else if (p.bookImb < -15) { bear += Math.min(12, -p.bookImb / 4); p.why.add(String.format(Locale.US, "Order book: SELL side %.0f%% bhari", -p.bookImb)); }
        }
        if (!Double.isNaN(p.oiCh) && Math.abs(p.oiCh) >= 3) {
            double s = Math.min(12, Math.abs(p.oiCh));
            if (p.ch1h >= 0) bull += s; else bear += s;
            p.why.add(String.format(Locale.US, "Futures positions 1 ghante mein %+.1f%%", p.oiCh));
        }
        if (!Double.isNaN(p.funding) && Math.abs(p.funding) >= 0.05) {
            if (p.funding < 0) { bull += 6; p.why.add(String.format(Locale.US, "Funding %.3f%% — shorts bhare (short squeeze ka imkaan)", p.funding)); }
            else { bear += 6; p.why.add(String.format(Locale.US, "Funding %.3f%% — longs bhare (girawat par liquidations)", p.funding)); }
        }
        if (!Double.isNaN(p.upbitRvol) && p.upbitRvol >= 2) {
            bull += Math.min(12, p.upbitRvol * 2.5);
            p.why.add(String.format(Locale.US, "🇰🇷 Upbit par volume %.1fx (Korea mein khareed)", p.upbitRvol));
        }
        if (!Double.isNaN(p.kimchi) && Math.abs(p.kimchi) >= 1.5) {
            if (p.kimchi > 0) bull += Math.min(8, p.kimchi * 2); else bear += Math.min(8, -p.kimchi * 2);
            p.why.add(String.format(Locale.US, "Kimchi premium %+.1f%%", p.kimchi));
        }
        // hype: CoinGecko trending (people searching) · DexScreener boosts · many fresh mentions in the news radar / X feed
        Integer tr = TRENDING.get(p.base);
        if (tr != null) { bull += Math.max(4, 14 - tr); p.feat |= F_TREND; p.why.add("🔥 CoinGecko trending #" + tr + " — log is coin ko dhoond rahe hain"); }
        if (BOOSTED.contains(p.base)) { bull += 4; p.why.add("💸 DexScreener par promote / boost ho raha (hype — ehtiyat)"); }
        int mentions = NewsEngine.about(p.base, 6 * 3600_000L, 20).size();
        if (mentions >= 3) { bull += 3; bear += 3; p.feat |= F_NEWS; p.why.add("🗣️ Pichle 6 ghante mein " + mentions + " khabrein / posts — charcha barh rahi"); }
        if (!Double.isNaN(p.venueSpike) && p.venueSpike >= 3) {
            double vs = Math.min(10, p.venueSpike * 1.5);
            if (p.ch15 >= 0) bull += vs; else bear += vs;
            p.feat |= F_VENUE;
        }
        // news / catalysts for this coin
        for (NewsEngine.Item it : NewsEngine.about(p.base, 6 * 3600_000L, 2)) {
            if (it.dir > 0) bull += 6 * it.severity; else if (it.dir < 0) bear += 6 * it.severity;
            p.why.add("📰 " + it.category + ": " + it.title);
        }
        for (CatalystEngine.Event e : CatalystEngine.forCoin(p.base, 3L * 86_400_000L)) {
            if (e.dir > 0) bull += 5 * e.severity; else if (e.dir < 0) bear += 5 * e.severity;
            p.why.add("📆 " + CatalystEngine.label(e) + ": " + e.title);
        }
        if (p.squeeze > 0 && p.squeeze < 4) { bull += 3; bear += 3; }
        p.pump = bull >= bear;
        double s = Math.max(bull, bear) - Math.min(bull, bear) * 0.4;
        if (!notRun) {
            s *= 0.6;   // already moved a lot: late
            p.why.add(String.format(Locale.US, "⚠️ Pehle hi chal chuka: 1h %+.1f%% · 24h %+.1f%% — der ho sakti hai", p.ch1h, p.ch24));
        } else p.why.add(String.format(Locale.US, "✅ Price abhi zyada nahi hili: 15m %+.1f%% · 1h %+.1f%% — jaldi pakra", p.ch15, p.ch1h));
        // learning: footprints that really led to moves on this phone's history get extra weight (and failed ones less)
        double adj = 0;
        for (int b = 0; b < 8; b++) if ((p.feat & (1 << b)) != 0) adj += FEAT_ADJ[b];
        if (Math.abs(adj) >= 1) p.why.add(String.format(Locale.US, "🧠 Seekha hua wazan: %+.0f (pichle nateejon se)", adj));
        s += adj;
        p.score = (int) Math.round(Math.max(0, Math.min(100, s)));
    }

    // ------------------------------------------------------------------ track record (honest hit rate)
    public static final class Track {
        /** Saves the strongest picks; later checks whether they really moved 5%+ the predicted way within 4 h. */
        static void record(Context ctx, Result r) {
            try {
                JSONArray a = new JSONArray(Prefs.getStr(ctx, "hunttrack", "[]"));
                long now = System.currentTimeMillis();
                java.util.Set<String> open = new java.util.HashSet<>();
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    if (!o.has("res")) open.add(o.optString("s"));
                }
                List<Pick> top = new ArrayList<>();
                for (Pick p : r.pumps) if (p.score >= 60 && top.size() < 5) top.add(p);
                for (Pick p : r.dumps) if (p.score >= 60 && top.size() < 8) top.add(p);
                for (Pick p : top) {
                    if (open.contains(p.sym)) continue;
                    JSONObject o = new JSONObject();
                    o.put("s", p.sym);
                    o.put("t", now);
                    o.put("p", p.price);
                    o.put("up", p.pump);
                    o.put("sc", p.score);
                    o.put("f", p.feat);
                    if (!"Binance".equals(p.venue)) continue;   // only Binance picks can be checked later
                    a.put(o);
                }
                JSONArray keep = new JSONArray();
                for (int i = Math.max(0, a.length() - 300); i < a.length(); i++) keep.put(a.get(i));
                Prefs.putStr(ctx, "hunttrack", keep.toString());
            } catch (Exception ignored) {
            }
        }

        /** Resolves picks older than 4 h using 15m candles: hit = moved 5%+ the right way before moving 5% the wrong way. */
        public static void resolve(Context ctx) {
            try {
                JSONArray a = new JSONArray(Prefs.getStr(ctx, "hunttrack", "[]"));
                long now = System.currentTimeMillis();
                boolean ch = false;
                int done = 0;
                for (int i = 0; i < a.length() && done < 10; i++) {
                    JSONObject o = a.getJSONObject(i);
                    if (o.has("res") || now - o.optLong("t") < 4 * 3600_000L) continue;
                    Candles c = Candles.parse(Scanner.get("/api/v3/klines?symbol=" + o.optString("s") + "&interval=15m&startTime=" + o.optLong("t") + "&limit=17"), false);
                    double p0 = o.optDouble("p"), best = 0, worst = 0;
                    boolean up = o.optBoolean("up");
                    String res = "miss";
                    for (int k = 0; k < c.n; k++) {
                        double fav = up ? (c.high[k] / p0 - 1) * 100 : (1 - c.low[k] / p0) * 100;
                        double adv = up ? (1 - c.low[k] / p0) * 100 : (c.high[k] / p0 - 1) * 100;
                        best = Math.max(best, fav);
                        worst = Math.max(worst, adv);
                        if (adv >= 5 && fav < 5) { res = "wrong"; break; }
                        if (fav >= 5) { res = "hit"; break; }
                    }
                    o.put("res", res);
                    o.put("best", best);
                    done++;
                    ch = true;
                }
                if (ch) Prefs.putStr(ctx, "hunttrack", a.toString());
            } catch (Exception ignored) {
            }
        }

        /** Per-feature score adjustment: (hit rate with feature − overall hit rate) × 40, needs 8+ samples. */
        static double[] featureAdj(Context ctx) {
            double[] adj = new double[8];
            try {
                JSONArray a = new JSONArray(Prefs.getStr(ctx, "hunttrack", "[]"));
                int tot = 0, hits = 0;
                int[] n = new int[8], h = new int[8];
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    if (!o.has("res") || !o.has("f")) continue;
                    boolean hit = "hit".equals(o.optString("res"));
                    tot++;
                    if (hit) hits++;
                    int f = o.optInt("f");
                    for (int b = 0; b < 8; b++) if ((f & (1 << b)) != 0) { n[b]++; if (hit) h[b]++; }
                }
                if (tot < 15) return adj;
                double base = hits / (double) tot;
                for (int b = 0; b < 8; b++) if (n[b] >= 8) adj[b] = Math.max(-12, Math.min(12, (h[b] / (double) n[b] - base) * 40));
            } catch (Exception ignored) {
            }
            return adj;
        }

        /** Hit rate per footprint, for the screen. */
        public static String featureReport(Context ctx) {
            double[] adj = featureAdj(ctx);
            StringBuilder sb = new StringBuilder();
            for (int b = 0; b < 8; b++) if (adj[b] != 0) sb.append(adj[b] > 0 ? "🟢 " : "🔴 ").append(F_NAMES[b]).append(String.format(Locale.US, " %+.0f   ", adj[b]));
            return sb.toString().trim();
        }

        /** {resolved, hits, wrong, avg best move %} */
        public static double[] stats(Context ctx) {
            double[] s = new double[4];
            try {
                JSONArray a = new JSONArray(Prefs.getStr(ctx, "hunttrack", "[]"));
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    if (!o.has("res")) continue;
                    s[0]++;
                    if ("hit".equals(o.optString("res"))) s[1]++;
                    if ("wrong".equals(o.optString("res"))) s[2]++;
                    s[3] += o.optDouble("best", 0);
                }
                if (s[0] > 0) s[3] /= s[0];
            } catch (Exception ignored) {
            }
            return s;
        }
    }

    // ------------------------------------------------------------------ 24/7 alerts
    public static void tick(Context ctx) {
        if (!Prefs.huntOn(ctx)) return;
        if (System.currentTimeMillis() - Prefs.getLong(ctx, "hunttick") < Prefs.huntEverySec(ctx) * 1000L) return;
        Prefs.putLong(ctx, "hunttick", System.currentTimeMillis());
        Result r = scan(ctx);
        Track.resolve(ctx);
        int min = Prefs.huntMinScore(ctx), sent = 0;
        List<Pick> all = new ArrayList<>(r.pumps);
        all.addAll(r.dumps);
        Collections.sort(all, (x, y) -> y.score - x.score);
        for (Pick p : all) {
            if (p.score < min || sent >= 3) break;
            String k = "hunt_" + p.sym + (p.pump ? "U" : "D");
            if (System.currentTimeMillis() - Prefs.getLong(ctx, k) < 2 * 3600_000L) continue;
            Prefs.putLong(ctx, k, System.currentTimeMillis());
            String title = (p.pump ? "🚀 PRE-PUMP: " : "🩸 PRE-DUMP: ") + p.base + " · score " + p.score + "/100";
            StringBuilder b = new StringBuilder(String.format(Locale.US, "Price $%s · 15m %+.1f%% · 1h %+.1f%%\n", Fmt.price(p.price), p.ch15, p.ch1h));
            for (int i = 0; i < p.why.size() && i < 5; i++) b.append("• ").append(p.why.get(i)).append('\n');
            b.append(p.pump ? "Gainers list mein aane se PEHLE ka ishara — chart dekh kar, stop ke saath." : "Losers list mein jaane se PEHLE ka ishara — holding ho to ehtiyat.");
            Notify.showPage(ctx, Prefs.N_HUNT, k.hashCode(), title, b.toString(), p.pump ? 0xFF0ECB81 : 0xFFF6465D, "hunt");
            sent++;
        }
    }
}
