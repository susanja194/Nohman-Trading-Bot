# AutoPilot — setup and safety

1. Create an API key on the exchange with **Spot trading** only. **Never enable withdrawals.** Add an IP whitelist if the exchange allows it.
2. App → More → AutoPilot → pick the exchange → paste key / secret (OKX: also the passphrase) → Save → Test (reads the balance, sends no order).
3. Leave it on **PAPER** for 1–2 weeks. Compare the paper results with what you expect before going LIVE.
4. LIVE needs you to type `LIVE`. Start with a small per-trade amount.
5. Keep the bot running (Settings → Start) with battery optimisation off — stops are watched by the app every ~5 s.

Supported: spot only (MEXC, Binance, Bybit, OKX, Gate). No leverage, no shorting, no withdrawals — the code has no withdrawal call.
No profit is guaranteed. Connectors for more exchanges are one class each in `ExchangeApi.java`.
