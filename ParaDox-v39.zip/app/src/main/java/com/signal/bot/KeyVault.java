package com.signal.bot;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Exchange API keys are stored ENCRYPTED with a key that lives in the Android Keystore (hardware-backed where available),
 * so the stored text is useless outside this phone / this app. Keys never leave the phone: they are only used to sign
 * requests that go straight to the exchange.
 */
public final class KeyVault {
    private KeyVault() {}

    private static final String ALIAS = "paradox_vault";

    private static SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(ALIAS)) return (SecretKey) ks.getKey(ALIAS, null);
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build());
        return kg.generateKey();
    }

    public static String enc(String plain) {
        if (plain == null || plain.isEmpty()) return "";
        try {
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, key());
            byte[] ct = c.doFinal(plain.getBytes("UTF-8"));
            byte[] iv = c.getIV();
            return "v1:" + Base64.encodeToString(iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP);
        } catch (Exception e) {
            return "";   // never fall back to storing a secret in plain text
        }
    }

    public static String dec(String stored) {
        if (stored == null || !stored.startsWith("v1:")) return "";
        try {
            String[] p = stored.split(":");
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, Base64.decode(p[1], Base64.NO_WRAP)));
            return new String(c.doFinal(Base64.decode(p[2], Base64.NO_WRAP)), "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    // ------------------------------------------------------------------ per-exchange credentials
    public static void save(Context c, String exchange, String apiKey, String secret, String pass) {
        Prefs.putStr(c, "vk_" + exchange, enc(apiKey));
        Prefs.putStr(c, "vs_" + exchange, enc(secret));
        Prefs.putStr(c, "vp_" + exchange, enc(pass));
    }

    public static String apiKey(Context c, String ex) { return dec(Prefs.getStr(c, "vk_" + ex, "")); }
    public static String secret(Context c, String ex) { return dec(Prefs.getStr(c, "vs_" + ex, "")); }
    public static String pass(Context c, String ex) { return dec(Prefs.getStr(c, "vp_" + ex, "")); }
    public static boolean has(Context c, String ex) { return !apiKey(c, ex).isEmpty() && !secret(c, ex).isEmpty(); }

    public static void clear(Context c, String ex) {
        Prefs.putStr(c, "vk_" + ex, "");
        Prefs.putStr(c, "vs_" + ex, "");
        Prefs.putStr(c, "vp_" + ex, "");
    }

    /** "ab12…9z" — enough to recognise a saved key without showing it. */
    public static String mask(String k) {
        if (k == null || k.length() < 8) return k == null || k.isEmpty() ? "—" : "••••";
        return k.substring(0, 4) + "…" + k.substring(k.length() - 3);
    }
}
