package com.signal.bot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * HISTORIC MARKET COMPARE: "aaj ki haalat" ko is coin ki apni history ke sab se milte-julte din / haftay se match karta hai
 * (pichle 7 / 30 din ki move, RSI, 90-din ke high se doori, volume, buyers vs sellers) aur dikhata hai ke un ke baad kya hua.
 * Yeh ek AGAR-MAGAR ka sabit nahi — sirf yeh ke pehle aisi haalat mein kitni baar upar / neeche gaya. Aage ka data kabhi match mein nahi aata.
 */
public final class HistoryCompare {
    private HistoryCompare() {}

    public static final class Analog {
        public int idx;
        public long t;
        public double dist, r1, r2, r3;
        public String when() { return new SimpleDateFormat("dd MMM yyyy", Locale.US).format(new Date(t)); }
    }

    public static final class Result {
        public boolean ok;
        public String coin = "", unit = "din", headline = "";
        public int h1, h2, h3, n;
        public final List<Analog> top = new ArrayList<>();
        public double med1, med2, med3, win1, win2, win3, worst2, best2;
        public final List<String> now = new ArrayList<>();
        public String note = "";
    }

    static double rsi(double[] c, int i, int p) {
        double g = 0, l = 0;
        for (int k = i - p + 1; k <= i; k++) {
            double d = c[k] - c[k - 1];
            if (d > 0) g += d; else l -= d;
        }
        return l == 0 ? 100 : 100 - 100 / (1 + g / l);
    }

    static double[] feat(Candles c, OrderFlow.Result fl, int i) {
        double hi = 0;
        for (int k = Math.max(0, i - 89); k <= i; k++) hi = Math.max(hi, c.high[k]);
        double av = 0;
        for (int k = i - 20; k < i; k++) av += c.vol[k];
        av /= 20;
        double vr = av > 0 ? Math.log(Math.max(0.05, c.vol[i] / av)) : 0;
        double bp = 0.5;
        if (fl != null && fl.real) {
            double b = 0, v = 0;
            for (int k = i - 2; k <= i; k++) { b += fl.buy[k]; v += c.vol[k]; }
            bp = v > 0 ? b / v : 0.5;
        }
        return new double[]{c.close[i] / c.close[i - 7] - 1, c.close[i] / c.close[i - 30] - 1, rsi(c.close, i, 14) / 100, c.close[i] / hi - 1, vr, bp};
    }

    public static Result analyze(String coin, Candles c, String unit, int h1, int h2, int h3) {
        Result r = new Result();
        r.coin = coin; r.unit = unit; r.h1 = h1; r.h2 = h2; r.h3 = h3;
        if (c == null || c.n < 150) { r.headline = "History kam hai (" + (c == null ? 0 : c.n) + " candles) — kam az kam 150 chahiye"; return r; }
        int n = c.n, first = 95;
        OrderFlow.Result fl = OrderFlow.analyze(c);
        double[][] f = new double[n][];
        for (int i = first; i < n; i++) f[i] = feat(c, fl, i);
        int dims = 6;
        double[] mean = new double[dims], sd = new double[dims];
        for (int d = 0; d < dims; d++) {
            double s = 0;
            for (int i = first; i < n; i++) s += f[i][d];
            mean[d] = s / (n - first);
            double v = 0;
            for (int i = first; i < n; i++) v += (f[i][d] - mean[d]) * (f[i][d] - mean[d]);
            sd[d] = Math.max(1e-9, Math.sqrt(v / (n - first)));
        }
        double[] w = {1, 1, 1, 1, 0.5, fl != null && fl.real ? 0.5 : 0};
        int cur = n - 1;
        List<Analog> all = new ArrayList<>();
        for (int j = first; j + h3 < n - 1; j++) {
            double dist = 0;
            for (int d = 0; d < dims; d++) {
                double z = ((f[j][d] - mean[d]) - (f[cur][d] - mean[d])) / sd[d];
                dist += w[d] * z * z;
            }
            Analog a = new Analog();
            a.idx = j; a.t = c.time[j]; a.dist = Math.sqrt(dist);
            a.r1 = c.close[j + h1] / c.close[j] - 1;
            a.r2 = c.close[j + h2] / c.close[j] - 1;
            a.r3 = c.close[j + h3] / c.close[j] - 1;
            all.add(a);
        }
        Collections.sort(all, (x, y) -> Double.compare(x.dist, y.dist));
        int gap = Math.max(h2, 5);
        for (Analog a : all) {
            boolean near = false;
            for (Analog t : r.top) if (Math.abs(t.idx - a.idx) < gap) { near = true; break; }
            if (near) continue;
            r.top.add(a);
            if (r.top.size() >= 12) break;
        }
        r.n = r.top.size();
        if (r.n < 5) { r.headline = "Milti-julti haalat kam mili"; return r; }
        double[] a1 = new double[r.n], a2 = new double[r.n], a3 = new double[r.n];
        int u1 = 0, u2 = 0, u3 = 0;
        r.worst2 = 1e9; r.best2 = -1e9;
        for (int i = 0; i < r.n; i++) {
            Analog a = r.top.get(i);
            a1[i] = a.r1; a2[i] = a.r2; a3[i] = a.r3;
            if (a.r1 > 0) u1++;
            if (a.r2 > 0) u2++;
            if (a.r3 > 0) u3++;
            r.worst2 = Math.min(r.worst2, a.r2);
            r.best2 = Math.max(r.best2, a.r2);
        }
        r.med1 = med(a1) * 100; r.med2 = med(a2) * 100; r.med3 = med(a3) * 100;
        r.win1 = u1 * 100.0 / r.n; r.win2 = u2 * 100.0 / r.n; r.win3 = u3 * 100.0 / r.n;
        r.worst2 *= 100; r.best2 *= 100;
        double[] x = f[cur];
        r.now.add(String.format(Locale.US, "Pichle 7 %s: %+.1f%% · pichle 30: %+.1f%%", unit, x[0] * 100, x[1] * 100));
        r.now.add(String.format(Locale.US, "RSI %.0f · 90-%s ke high se %.0f%% neeche", x[2] * 100, unit, -x[3] * 100));
        if (fl != null && fl.real) r.now.add(String.format(Locale.US, "Aakhri 3 candles mein buyers %.0f%%", x[5] * 100));
        r.ok = true;
        r.headline = String.format(Locale.US, "Aisi %d milti-julti haalat mein %d %s baad %d/%d baar upar (median %+.1f%%)", r.n, h2, unit, u2, r.n, r.med2);
        r.note = "Yeh sirf pichli frequency hai (chhota sample, " + r.n + " cases) — guarantee nahi. Stop-loss phir bhi zaroori hai.";
        return r;
    }

    static double med(double[] a) {
        double[] b = a.clone();
        java.util.Arrays.sort(b);
        int n = b.length;
        return n % 2 == 1 ? b[n / 2] : (b[n / 2 - 1] + b[n / 2]) / 2;
    }

    /** Network: daily (≈2.7 saal) or weekly (poori history) candles → analyze. */
    public static Result run(String coin, boolean weekly) throws Exception {
        Candles c = Candles.fetch(coin + "USDT", weekly ? "1w" : "1d", 1000, true);
        return weekly ? analyze(coin, c, "hafta", 2, 4, 8) : analyze(coin, c, "din", 3, 7, 14);
    }
}
