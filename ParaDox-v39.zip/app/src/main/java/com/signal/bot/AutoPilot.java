package com.signal.bot;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * AUTOPILOT — spot auto-trader. OFF by default. Three modes:
 *   OFF   : nothing happens.
 *   PAPER : the full logic runs on real prices, no order is sent (use this first, for days).
 *   LIVE  : real market orders on YOUR exchange account through YOUR API key (trade-only key, no withdrawal).
 *
 * Entry only when ALL of these agree (nothing is bought on a single indicator):
 *   - a signal came from the bot (Scanner BUY or SMC Pro long)
 *   - Trade Agent: BUY (now, or limit zone reached) with enough judges for and at most 1 against
 *   - order flow (buyers vs sellers per candle) is not on the sellers' side
 *   - 24h volume is liquid, stop distance is sane, price has not run away from the entry zone
 * Exit: stop-loss, TP1 (sell 1/3, stop to break-even), TP2 (sell half of the rest, lock profit), TP3 (all), time stop.
 * Risk: per-trade size cap, max open trades, daily loss limit (then no new entries), loss-streak pause, kill switch.
 *
 * IMPORTANT limits (shown to the user): stops are watched by the app every ~5 s — they are NOT resting orders on the exchange,
 * so the phone must stay online with the bot running. No profit is promised.
 */
public final class AutoPilot {
    private AutoPilot() {}

    public static final String OFF = "off", PAPER = "paper", LIVE = "live";

    // ------------------------------------------------------------------ settings
    public static String mode(Context c) { return Prefs.getStr(c, "apMode", OFF); }
    public static void setMode(Context c, String m) { Prefs.putStr(c, "apMode", m); }
    public static String exchange(Context c) { return Prefs.getStr(c, "apEx", "MEXC"); }
    public static double perTrade(Context c) { return Prefs.getInt(c, "apUsdt", 10); }
    public static int maxOpen(Context c) { return Prefs.getInt(c, "apMax", 3); }
    public static double dayLoss(Context c) { return Prefs.getInt(c, "apDayLoss", 20); }
    public static int minVotes(Context c) { return Prefs.getInt(c, "apVotes", 5); }
    public static boolean needFlow(Context c) { return Prefs.getBool(c, "apFlow", true); }
    public static double maxHoldH(Context c) { return Prefs.getInt(c, "apHold", 72); }

    // ------------------------------------------------------------------ position
    public static final class Pos {
        public String id = "", coin = "", ex = "", src = "";
        public boolean live, closed;
        public double qty, entry, sl, tp1, tp2, tp3, cost, proceeds;
        public int stage, errs;
        public long openT, exitT;
        public String exitWhy = "";

        public double pnl() { return proceeds - cost; }

        JSONObject json() throws Exception {
            return new JSONObject().put("id", id).put("coin", coin).put("ex", ex).put("src", src).put("live", live).put("closed", closed)
                    .put("qty", qty).put("entry", entry).put("sl", sl).put("tp1", tp1).put("tp2", tp2).put("tp3", tp3)
                    .put("cost", cost).put("proceeds", proceeds).put("stage", stage).put("errs", errs).put("openT", openT).put("exitT", exitT).put("exitWhy", exitWhy);
        }

        static Pos from(JSONObject o) {
            Pos p = new Pos();
            p.id = o.optString("id"); p.coin = o.optString("coin"); p.ex = o.optString("ex"); p.src = o.optString("src");
            p.live = o.optBoolean("live"); p.closed = o.optBoolean("closed");
            p.qty = o.optDouble("qty"); p.entry = o.optDouble("entry"); p.sl = o.optDouble("sl");
            p.tp1 = o.optDouble("tp1"); p.tp2 = o.optDouble("tp2"); p.tp3 = o.optDouble("tp3");
            p.cost = o.optDouble("cost"); p.proceeds = o.optDouble("proceeds"); p.stage = o.optInt("stage"); p.errs = o.optInt("errs");
            p.openT = o.optLong("openT"); p.exitT = o.optLong("exitT"); p.exitWhy = o.optString("exitWhy");
            return p;
        }
    }

    /** What the engine needs from an exchange (real or paper). */
    public interface Broker {
        ExchangeApi.Fill buy(String coin, double usdt) throws Exception;
        ExchangeApi.Fill sell(String coin, double qty) throws Exception;
    }

    /** Paper broker: fills at the given price with 0.1% slippage and 0.1% fee each side (so paper results are not flattering). */
    public static final class PaperBroker implements Broker {
        public double price;
        public PaperBroker(double price) { this.price = price; }
        @Override public ExchangeApi.Fill buy(String coin, double usdt) {
            ExchangeApi.Fill f = new ExchangeApi.Fill();
            f.avg = price * 1.001;
            f.quote = usdt * 1.001;
            f.qty = usdt / f.avg;
            f.id = "paper";
            return f;
        }
        @Override public ExchangeApi.Fill sell(String coin, double qty) {
            ExchangeApi.Fill f = new ExchangeApi.Fill();
            f.avg = price * 0.999;
            f.qty = qty;
            f.quote = qty * f.avg * 0.999;
            f.id = "paper";
            return f;
        }
    }

    // ------------------------------------------------------------------ pure engine (unit-tested)
    /** null = go · "WAIT: ..." = valid idea, price not in the zone yet · anything else = reason for NO. */
    public static String entryGate(TradeAgent.Verdict v, OrderFlow.Result f, double vol24h, int minVotes, boolean needFlow, double price) {
        if (v == null || !v.isBuy()) return "Trade Agent ab BUY nahi keh raha";
        if (v.buy < minVotes) return "Judges kam: " + v.buy + "/7 haq mein (chahiye " + minVotes + ")";
        if (v.sell > 1) return "Judges mein " + v.sell + " khilaf";
        if (needFlow && f != null && f.ok && f.real && (f.action.equals("SELL") || f.score < -15))
            return "Order flow sellers ke haq mein (score " + f.score + ") — candle ke neeche ke numbers khilaf";
        if (vol24h < 2_000_000) return "24h volume kam (" + Fmt.usd(vol24h) + ") — slippage ka khatra";
        double risk = (v.entryHi - v.sl) / v.entryHi;
        if (risk < 0.003 || risk > 0.10) return String.format(Locale.US, "Stop ka faasla ghair-munasib (%.1f%%)", risk * 100);
        if (price > v.entryHi * 1.012) return "Price entry zone se bhaag gayi — peecha karna (chase) nahi";
        if (price > v.entryHi * 1.003) return "WAIT: price $" + Fmt.price(price) + " zone ($" + Fmt.price(v.entryLo) + "–$" + Fmt.price(v.entryHi) + ") mein aaye";
        if (price < v.sl) return "Price pehle hi stop ke neeche";
        return null;
    }

    /** Advances one position by one price tick. Returns human events (empty = nothing happened). Never throws. */
    public static List<String> step(Pos p, double price, long now, double maxHoldH, Broker b) {
        List<String> ev = new ArrayList<>();
        if (p.closed || price <= 0) return ev;
        for (int guard = 0; guard < 4 && !p.closed; guard++) {
            String why = null;
            if (price <= p.sl) why = p.stage == 0 ? "🛑 Stop-loss" : p.stage == 1 ? "⚖️ Break-even stop" : "🔒 Profit-lock stop";
            else if (now - p.openT > (long) (maxHoldH * 3600_000L)) why = "⌛ Time stop";
            if (why != null) {
                sell(p, p.qty, price, b, ev, why, true, now);
                return ev;
            }
            if (p.stage == 0 && price >= p.tp1) {
                if (!sell(p, p.qty / 3.0, price, b, ev, "🎯 TP1", false, now)) return ev;
                p.stage = 1;
                p.sl = Math.max(p.sl, p.entry * 1.001);
            } else if (p.stage == 1 && price >= p.tp2) {
                if (!sell(p, p.qty / 2.0, price, b, ev, "🎯 TP2", false, now)) return ev;
                p.stage = 2;
                p.sl = Math.max(p.sl, p.tp1);
            } else if (p.stage == 2 && price >= p.tp3) {
                sell(p, p.qty, price, b, ev, "🏁 TP3", true, now);
                return ev;
            } else break;
        }
        return ev;
    }

    private static boolean sell(Pos p, double q, double price, Broker b, List<String> ev, String why, boolean all, long now) {
        if (!all && (p.qty - q) * price < 6) { q = p.qty; all = true; }   // leftover would be below the exchange minimum → sell it all
        try {
            ExchangeApi.Fill f = b.sell(p.coin, q);
            double sold = f.qty > 0 ? f.qty : q;
            p.qty = Math.max(0, p.qty - sold);
            p.proceeds += f.quote > 0 ? f.quote : sold * price;
            p.errs = 0;
            if (all || p.qty * price < 1) {
                p.closed = true;
                p.exitT = now;
                p.exitWhy = why;
                p.qty = 0;
            }
            ev.add(String.format(Locale.US, "%s %s @ $%s (%s%.2f USDT)", why, p.coin, Fmt.price(f.avg > 0 ? f.avg : price), p.pnl() >= 0 ? "+" : "", p.pnl()));
            return true;
        } catch (Exception e) {
            p.errs++;
            ev.add("⚠️ " + p.coin + " bechne mein masla (" + why + "): " + e.getMessage() + (p.errs >= 3 ? " — MANUAL check karein!" : " — dobara koshish hogi"));
            return false;
        }
    }

    // ------------------------------------------------------------------ storage
    private static final Object LOCK = new Object();

    public static List<Pos> positions(Context c) {
        List<Pos> l = new ArrayList<>();
        synchronized (LOCK) {
            try {
                JSONArray a = new JSONArray(Prefs.getStr(c, "apPos", "[]"));
                for (int i = 0; i < a.length(); i++) l.add(Pos.from(a.getJSONObject(i)));
            } catch (Exception ignored) { }
        }
        return l;
    }

    /** Writes back only the positions that changed, onto the LATEST stored list (so a concurrent kill / new entry is never overwritten). */
    static void saveMerge(Context c, List<Pos> changed) {
        synchronized (LOCK) {
            List<Pos> latest = positions(c);
            for (Pos ch : changed) {
                boolean found = false;
                for (int i = 0; i < latest.size(); i++) if (latest.get(i).id.equals(ch.id)) { latest.set(i, ch); found = true; break; }
                if (!found) latest.add(ch);
            }
            save(c, latest);
        }
    }

    static void save(Context c, List<Pos> l) {
        synchronized (LOCK) {
            JSONArray a = new JSONArray();
            try { for (int i = Math.max(0, l.size() - 200); i < l.size(); i++) a.put(l.get(i).json()); } catch (Exception ignored) { }
            Prefs.putStr(c, "apPos", a.toString());
        }
    }

    public static List<String> log(Context c) {
        List<String> l = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(Prefs.getStr(c, "apLog", "[]"));
            for (int i = 0; i < a.length(); i++) l.add(a.getString(i));
        } catch (Exception ignored) { }
        return l;
    }

    static void log(Context c, String s) {
        synchronized (LOCK) {
            try {
                JSONArray a = new JSONArray(Prefs.getStr(c, "apLog", "[]")), b = new JSONArray();
                b.put(new java.text.SimpleDateFormat("dd MMM HH:mm", Locale.US).format(new java.util.Date()) + " · " + s);
                for (int i = 0; i < a.length() && i < 119; i++) b.put(a.get(i));
                Prefs.putStr(c, "apLog", b.toString());
            } catch (Exception ignored) { }
        }
    }

    public static double todayPnl(Context c) {
        double t = 0;
        Calendar k = Calendar.getInstance();
        k.set(Calendar.HOUR_OF_DAY, 0); k.set(Calendar.MINUTE, 0); k.set(Calendar.SECOND, 0); k.set(Calendar.MILLISECOND, 0);
        long ds = k.getTimeInMillis();
        for (Pos p : positions(c)) if (p.closed && p.exitT >= ds) t += p.pnl();
        return t;
    }

    // ------------------------------------------------------------------ runtime
    private static final ConcurrentLinkedQueue<String[]> QUEUE = new ConcurrentLinkedQueue<>();       // {coin, src}
    private static final ConcurrentHashMap<String, long[]> WAIT = new ConcurrentHashMap<>();           // coin -> {expiry, lastCheck}
    private static final ConcurrentHashMap<String, String> WAITSRC = new ConcurrentHashMap<>();
    private static volatile Thread worker;
    public static volatile String status = "";

    /** Called by Scanner when a BUY signal is published. */
    public static void offer(Context c, String coin, String src) {
        if (OFF.equals(mode(c)) || Prefs.getBool(c, "apKill", false)) return;
        for (String[] q : QUEUE) if (q[0].equals(coin)) return;
        QUEUE.add(new String[]{coin, src});
        start(c);
    }

    public static synchronized void start(final Context c) {
        if (worker != null && worker.isAlive()) return;
        final Context app = c.getApplicationContext();
        worker = new Thread(() -> {
            long lastMgmt = 0;
            while (ScannerService.running) {
                try {
                    // open positions are ALWAYS watched (even when new entries are switched off); new entries only when mode != OFF
                    if (System.currentTimeMillis() - lastMgmt >= 5000) { lastMgmt = System.currentTimeMillis(); manage(app); }
                    if (!OFF.equals(mode(app))) {
                        String[] q = QUEUE.poll();
                        if (q != null) evaluate(app, q[0], q[1]);
                        else recheckWaiting(app);
                    }
                    Thread.sleep(OFF.equals(mode(app)) ? 8000 : 1500);
                } catch (InterruptedException e) {
                    return;
                } catch (Exception e) {
                    status = "error: " + e.getMessage();
                }
            }
        }, "autopilot");
        worker.setDaemon(true);
        worker.start();
    }

    static ExchangeApi api(Context c) {
        String ex = exchange(c);
        if (!KeyVault.has(c, ex)) return null;
        return ExchangeApi.create(ex, KeyVault.apiKey(c, ex), KeyVault.secret(c, ex), KeyVault.pass(c, ex));
    }

    static double publicPrice(String coin) throws Exception {
        return new JSONObject(Scanner.get("/api/v3/ticker/price?symbol=" + coin + "USDT")).getDouble("price");
    }

    /** Watches every open position. */
    static void manage(Context c) {
        List<Pos> l = positions(c);
        List<Pos> changedList = new ArrayList<>();
        boolean ch = false;
        ExchangeApi api = null;
        for (Pos p : l) {
            if (p.closed) continue;
            try {
                double price;
                Broker br;
                if (p.live) {
                    if (api == null || !api.name().equals(p.ex)) api = ExchangeApi.create(p.ex, KeyVault.apiKey(c, p.ex), KeyVault.secret(c, p.ex), KeyVault.pass(c, p.ex));
                    final ExchangeApi a = api;
                    price = a.last(p.coin);
                    br = new Broker() {
                        @Override public ExchangeApi.Fill buy(String coin, double usdt) throws Exception { return a.marketBuy(coin, usdt); }
                        @Override public ExchangeApi.Fill sell(String coin, double qty) throws Exception { return a.marketSell(coin, qty); }
                    };
                } else {
                    price = publicPrice(p.coin);
                    br = new PaperBroker(price);
                }
                List<String> ev = step(p, price, System.currentTimeMillis(), maxHoldH(c), br);
                if (!ev.isEmpty()) {
                    ch = true;
                    changedList.add(p);
                    for (String e : ev) {
                        log(c, (p.live ? "LIVE " : "PAPER ") + e);
                        Notify.show(c, Prefs.N_SIGNALS, (p.id + e).hashCode(), "🤖 AutoPilot " + (p.live ? "(LIVE)" : "(paper)"), e,
                                e.startsWith("🛑") || e.startsWith("⚠️") ? 0xFFF6465D : 0xFF0ECB81, MainActivity.TAB_SIGNALS);
                    }
                }
            } catch (Exception e) {
                status = p.coin + ": " + e.getMessage();
            }
        }
        if (ch) saveMerge(c, changedList);
    }

    static boolean lossStreakPause(Context c) {
        List<Pos> l = positions(c);
        int streak = 0;
        long last = 0;
        for (int i = l.size() - 1; i >= 0; i--) {
            Pos p = l.get(i);
            if (!p.closed) continue;
            if (p.pnl() > 0) break;
            streak++;
            last = Math.max(last, p.exitT);
        }
        return streak >= 3 && System.currentTimeMillis() - last < 12 * 3600_000L;
    }

    static void recheckWaiting(Context c) {
        long now = System.currentTimeMillis();
        for (String coin : new ArrayList<>(WAIT.keySet())) {
            long[] w = WAIT.get(coin);
            if (w == null) continue;
            if (now > w[0]) { WAIT.remove(coin); WAITSRC.remove(coin); log(c, "⏳ " + coin + ": zone tak price nahi aayi — intezar khatam"); continue; }
            if (now - w[1] < 45_000) continue;
            w[1] = now;
            String src = WAITSRC.get(coin);
            WAIT.remove(coin);
            evaluate(c, coin, src == null ? "wait" : src);
            return;   // one per cycle
        }
    }

    /** Full decision for one coin. Heavy (builds the whole report) — runs on the autopilot thread only. */
    static void evaluate(Context c, String coin, String src) {
        String m = mode(c);
        if (OFF.equals(m) || Prefs.getBool(c, "apKill", false)) return;
        try {
            List<Pos> l = positions(c);
            int open = 0;
            for (Pos p : l) if (!p.closed) { open++; if (p.coin.equals(coin)) { return; } }
            if (open >= maxOpen(c)) { log(c, "⛔ " + coin + ": max open trades (" + maxOpen(c) + ") poore"); return; }
            if (todayPnl(c) <= -dayLoss(c)) { log(c, "⛔ " + coin + ": aaj ka loss limit (" + dayLoss(c) + " USDT) poora — kal tak naye trade band"); return; }
            if (lossStreakPause(c)) { log(c, "⛔ " + coin + ": 3 loss lagatar — 12 ghante ka pause"); return; }
            CoinReport r = CoinReport.build(coin + "USDT", src != null && (src.startsWith("scalp") || src.equals("smc")) ? Mode.SCALP : Mode.SPOT, "", 0, false);
            TradeAgent.Verdict v = TradeAgent.decide(r);
            double price = r.price;
            String gate = entryGate(v, r.flow, r.quoteVol24h, minVotes(c), needFlow(c), price);
            if (gate != null) {
                if (gate.startsWith("WAIT")) {
                    WAIT.put(coin, new long[]{System.currentTimeMillis() + 3 * 3600_000L, System.currentTimeMillis()});
                    WAITSRC.put(coin, src);
                    log(c, "⏳ " + coin + ": " + gate.substring(5));
                } else log(c, "🚫 " + coin + " nahi liya: " + gate);
                return;
            }
            double usdt = perTrade(c);
            Pos p = new Pos();
            p.id = coin + System.currentTimeMillis();
            p.coin = coin; p.src = src == null ? "" : src; p.ex = exchange(c); p.live = LIVE.equals(m);
            p.sl = v.sl; p.tp1 = v.tp1; p.tp2 = v.tp2; p.tp3 = v.tp3; p.openT = System.currentTimeMillis();
            ExchangeApi.Fill f;
            if (p.live) {
                ExchangeApi api = api(c);
                if (api == null) { log(c, "❌ " + exchange(c) + " ki API key save nahi — pehle connect karein"); return; }
                double bal = api.free("USDT");
                if (bal < usdt) { log(c, "❌ " + coin + ": " + exchange(c) + " par USDT kam (" + String.format(Locale.US, "%.2f", bal) + ")"); return; }
                if (usdt > bal * 0.25 && bal > 40) usdt = Math.floor(bal * 0.25);   // never more than 25% of the account in one trade
                if (usdt < 5) { log(c, "❌ " + coin + ": trade size 5 USDT se kam"); return; }
                f = api.marketBuy(coin, usdt);
                if (f.qty <= 0) {
                    log(c, "⚠️ " + coin + ": buy order bheja gaya lekin fill confirm nahi hua — exchange app mein check karein (order id " + f.id + ")");
                    Notify.show(c, Prefs.N_SIGNALS, ("unk" + coin).hashCode(), "⚠️ AutoPilot: " + coin, "Order bheja, fill confirm nahi hua. Exchange app check karein.", 0xFFF6465D, MainActivity.TAB_SIGNALS);
                    return;
                }
            } else {
                f = new PaperBroker(price).buy(coin, usdt);
            }
            p.qty = f.qty; p.entry = f.avg > 0 ? f.avg : price; p.cost = f.quote > 0 ? f.quote : usdt;
            if (p.entry >= p.tp1) { log(c, "⚠️ " + coin + ": fill price TP1 se upar — position turant nikaal di jayegi"); }
            saveMerge(c, java.util.Collections.singletonList(p));
            String msg = String.format(Locale.US, "%s BUY %s: %s USDT @ $%s · SL $%s · TP1 $%s · TP2 $%s · TP3 $%s", p.live ? "LIVE" : "PAPER", coin, String.format(Locale.US, "%.2f", p.cost), Fmt.price(p.entry),
                    Fmt.price(p.sl), Fmt.price(p.tp1), Fmt.price(p.tp2), Fmt.price(p.tp3));
            log(c, "✅ " + msg + " · judges " + v.buy + "/7" + (r.flow != null && r.flow.real ? " · flow " + r.flow.score : ""));
            Notify.show(c, Prefs.N_SIGNALS, p.id.hashCode(), "🤖 AutoPilot " + (p.live ? "(LIVE)" : "(paper)") + " BUY " + coin, msg, 0xFF0ECB81, MainActivity.TAB_SIGNALS);
        } catch (Exception e) {
            log(c, "❌ " + coin + ": " + e.getMessage());
        }
    }

    /** Kill switch: stops new entries; optionally sells every open position at market. */
    public static void kill(Context c, boolean closeAll) {
        Prefs.putBool(c, "apKill", true);
        setMode(c, OFF);
        QUEUE.clear();
        WAIT.clear();
        log(c, "🛑 KILL SWITCH dabaya" + (closeAll ? " — sab positions band ki ja rahi hain" : ""));
        if (!closeAll) return;
        List<Pos> l = positions(c);
        for (Pos p : l) {
            if (p.closed) continue;
            try {
                Broker br;
                double price;
                if (p.live) {
                    final ExchangeApi a = ExchangeApi.create(p.ex, KeyVault.apiKey(c, p.ex), KeyVault.secret(c, p.ex), KeyVault.pass(c, p.ex));
                    price = a.last(p.coin);
                    br = new Broker() {
                        @Override public ExchangeApi.Fill buy(String coin, double usdt) throws Exception { return a.marketBuy(coin, usdt); }
                        @Override public ExchangeApi.Fill sell(String coin, double qty) throws Exception { return a.marketSell(coin, qty); }
                    };
                } else { price = publicPrice(p.coin); br = new PaperBroker(price); }
                p.sl = price * 2;   // force the stop branch
                for (String e : step(p, price, System.currentTimeMillis(), maxHoldH(c), br)) log(c, e);
                if (!p.closed) log(c, "⚠️ " + p.coin + " band nahi hui — exchange app se khud band karein");
            } catch (Exception e) {
                log(c, "⚠️ " + p.coin + ": " + e.getMessage() + " — exchange app se khud band karein");
            }
        }
        saveMerge(c, l);
    }
}
