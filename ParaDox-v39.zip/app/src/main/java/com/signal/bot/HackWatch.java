package com.signal.bot;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * HACK WATCH — exchange / protocol hack ki khabar jitni jaldi public hoti hai utni jaldi alert.
 * Sources (sab free): Google News RSS (har 2 minute, "last 1 day"), CoinDesk / Cointelegraph / The Block / Decrypt RSS, DeFiLlama hacks list.
 * Limit (seedhi baat): yeh PUBLIC khabar pakadta hai — aam taur par hack hone ke 1–10 minute baad jab pehla news / X post aata hai.
 * Exchange ke apne internal alarm ya on-chain monitoring (paid) is se tez hote hain. Hack ki khabar akeli confirm nahi hoti — pehle exchange ka
 * official statement dekhein; alert "unconfirmed" bhi ho sakta hai.
 */
public final class HackWatch {
    private HackWatch() {}

    public static final String[][] EXCHANGES = {
            {"Binance", "BNB"}, {"Coinbase", "COIN"}, {"Bybit", ""}, {"OKX", "OKB"}, {"KuCoin", "KCS"}, {"MEXC", "MX"}, {"Bitget", "BGB"},
            {"Gate.io", "GT"}, {"Gate ", "GT"}, {"HTX", "HT"}, {"Huobi", "HT"}, {"Kraken", ""}, {"Upbit", ""}, {"Bithumb", ""}, {"Crypto.com", "CRO"},
            {"Bitfinex", "LEO"}, {"Bitstamp", ""}, {"WazirX", "WRX"}, {"CoinDCX", ""}, {"BingX", ""}, {"Phemex", ""}, {"Deribit", ""}, {"Bitmart", "BMX"},
            {"LBank", ""}, {"Poloniex", ""}, {"Gemini", ""}, {"Bitso", ""}, {"CoinEx", "CET"}, {"BtcTurk", ""}, {"Nobitex", ""}, {"Indodax", ""}, {"Rain", ""}
    };
    static final String[] HACK = {"hack", "hacked", "exploit", "exploited", "drained", "stolen", "breach", "security incident", "suspends withdrawals",
            "suspended withdrawals", "halts withdrawals", "withdrawals halted", "withdrawals paused", "suspends deposits", "compromised", "cyberattack", "attack", "rug pull", "funds missing", "unauthorized"};
    static final String[] NOISE = {"how to", "prevent", "quiz", "webinar", "guide", "opinion", "explainer", "tips", "protect your", "report:"};

    public static final class Item {
        public String title = "", link = "", source = "", exchange = "", token = "";
        public long t;
        public int sev;          // 3 = exchange hit · 2 = big protocol hack · 1 = general
        public boolean unconfirmed;
        public String when() { return new SimpleDateFormat("dd MMM HH:mm", Locale.US).format(new Date(t)); }
    }

    private static boolean has(String s, String[] keys) {
        for (String k : keys) if (s.contains(k)) return true;
        return false;
    }

    /** Pure classifier. null = not a hack story. */
    public static Item classify(String title, String source, long t, String link) {
        if (title == null) return null;
        String s = title.toLowerCase(Locale.US);
        if (!has(s, HACK) || has(s, NOISE)) return null;
        Item it = new Item();
        it.title = title; it.source = source; it.t = t; it.link = link;
        for (String[] e : EXCHANGES) {
            if (s.contains(e[0].toLowerCase(Locale.US)) && !(e[0].equals("Rain") || e[0].equals("Gate "))) { it.exchange = e[0].trim(); it.token = e[1]; break; }
            if (e[0].equals("Gate ") && Pattern.compile("\\bgate\\b").matcher(s).find()) { it.exchange = "Gate"; it.token = "GT"; break; }
        }
        boolean strong = s.contains("hack") || s.contains("exploit") || s.contains("drain") || s.contains("stolen") || s.contains("breach")
                || s.contains("suspend") || s.contains("halt") || s.contains("compromis");
        boolean exchangeWord = s.contains("exchange") || !it.exchange.isEmpty();
        if (!it.exchange.isEmpty() && strong) it.sev = 3;
        else if (exchangeWord && strong && (s.contains("withdraw") || s.contains("hot wallet") || s.contains("million"))) it.sev = 3;
        else if (amountMillions(s) >= 20 && strong) it.sev = 2;
        else it.sev = 1;
        it.unconfirmed = s.contains("rumor") || s.contains("rumour") || s.contains("alleged") || s.contains("reportedly") || s.contains("claims") || s.contains("?");
        return it;
    }

    /** "$50 million" / "$1.2B" / "$300M" in a headline → millions. */
    static double amountMillions(String s) {
        Matcher m = Pattern.compile("\\$\\s?([0-9]+(?:\\.[0-9]+)?)\\s?(million|billion|m\\b|b\\b|bn\\b)").matcher(s);
        double best = 0;
        while (m.find()) {
            double v = Double.parseDouble(m.group(1));
            String u = m.group(2);
            best = Math.max(best, u.startsWith("b") ? v * 1000 : v);
        }
        return best;
    }

    // ------------------------------------------------------------------ RSS
    static String unesc(String s) {
        return s.replace("<![CDATA[", "").replace("]]>", "").replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'").replace("&lt;", "<").replace("&gt;", ">").trim();
    }

    public static List<Item> parseRss(String xml, String defaultSource) {
        List<Item> out = new ArrayList<>();
        Matcher m = Pattern.compile("<item>(.*?)</item>", Pattern.DOTALL).matcher(xml);
        SimpleDateFormat df = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US);
        while (m.find() && out.size() < 60) {
            String b = m.group(1);
            String title = tag(b, "title"), link = tag(b, "link"), pub = tag(b, "pubDate"), src = tag(b, "source");
            long t = System.currentTimeMillis();
            try { t = df.parse(pub).getTime(); } catch (Exception ignored) { }
            if (src.isEmpty()) src = defaultSource;
            Item it = classify(unesc(title), unesc(src), t, unesc(link));
            if (it != null) out.add(it);
        }
        return out;
    }

    static String tag(String b, String name) {
        Matcher m = Pattern.compile("<" + name + "[^>]*>(.*?)</" + name + ">", Pattern.DOTALL).matcher(b);
        return m.find() ? m.group(1) : "";
    }

    static final String[][] FEEDS = {
            {"CoinDesk", "https://www.coindesk.com/arc/outboundfeeds/rss/"},
            {"Cointelegraph", "https://cointelegraph.com/rss"},
            {"The Block", "https://www.theblock.co/rss.xml"},
            {"Decrypt", "https://decrypt.co/feed"},
    };

    static String fetch(String url) throws Exception {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(10000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 ParaDox/39");
        try (java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(c.getInputStream(), "UTF-8"))) {
            StringBuilder sb = new StringBuilder();
            char[] buf = new char[8192];
            int n;
            while ((n = br.read(buf)) > 0 && sb.length() < 2_000_000) sb.append(buf, 0, n);
            return sb.toString();
        }
    }

    public static List<Item> fetchAll() {
        List<Item> all = new ArrayList<>();
        try {
            String q = "(exchange OR Binance OR Bybit OR OKX OR KuCoin OR MEXC OR Bitget OR Kraken OR Upbit OR Bithumb OR WazirX OR Coinbase OR crypto) (hacked OR hack OR exploit OR drained OR \"suspends withdrawals\" OR \"security incident\") when:1d";
            all.addAll(parseRss(fetch("https://news.google.com/rss/search?q=" + URLEncoder.encode(q, "UTF-8") + "&hl=en-US&gl=US&ceid=US:en"), "Google News"));
        } catch (Exception ignored) { }
        for (String[] f : FEEDS) {
            try { all.addAll(parseRss(fetch(f[1]), f[0])); } catch (Exception ignored) { }
        }
        try {
            JSONArray a = new JSONArray(fetch("https://api.llama.fi/hacks"));
            long cut = System.currentTimeMillis() - 3 * 86400_000L;
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                long t = o.optLong("date") * 1000L;
                if (t < cut) continue;
                String name = o.optString("name"), tech = o.optString("technique", o.optString("classification"));
                double amt = o.optDouble("amount", 0);
                Item it = classify(name + " hacked" + (amt > 0 ? " — " + Fmt.usd(amt) : "") + " (" + tech + ")", "DeFiLlama", t, o.optString("source"));
                if (it != null) { if (amt >= 20e6) it.sev = Math.max(it.sev, 2); all.add(it); }
            }
        } catch (Exception ignored) { }
        // newest first, de-duplicate similar titles
        all.sort((x, y) -> Long.compare(y.t, x.t));
        List<Item> out = new ArrayList<>();
        for (Item it : all) {
            boolean dup = false;
            String k = key(it.title);
            for (Item o : out) if (key(o.title).equals(k)) { dup = true; break; }
            if (!dup && System.currentTimeMillis() - it.t < 3 * 86400_000L) out.add(it);
        }
        return out;
    }

    static String key(String t) {
        String s = t.toLowerCase(Locale.US).replaceAll("[^a-z0-9 ]", "");
        return s.length() > 40 ? s.substring(0, 40) : s;
    }

    // ------------------------------------------------------------------ cache + alerts
    public static List<Item> cached(Context c) {
        List<Item> l = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(Prefs.getStr(c, "hwItems", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Item it = new Item();
                it.title = o.optString("t"); it.link = o.optString("l"); it.source = o.optString("s"); it.exchange = o.optString("e");
                it.token = o.optString("k"); it.sev = o.optInt("v"); it.unconfirmed = o.optBoolean("u"); it.t = o.optLong("d");
                l.add(it);
            }
        } catch (Exception ignored) { }
        return l;
    }

    static void store(Context c, List<Item> l) {
        JSONArray a = new JSONArray();
        try {
            for (int i = 0; i < l.size() && i < 60; i++) {
                Item it = l.get(i);
                a.put(new JSONObject().put("t", it.title).put("l", it.link).put("s", it.source).put("e", it.exchange).put("k", it.token).put("v", it.sev).put("u", it.unconfirmed).put("d", it.t));
            }
        } catch (Exception ignored) { }
        Prefs.putStr(c, "hwItems", a.toString());
    }

    public static boolean on(Context c) { return Prefs.getBool(c, "hwOn", true); }

    /** Every ~2 minutes. Returns the list (also cached for the page). */
    public static List<Item> tick(Context c, boolean force) {
        long now = System.currentTimeMillis();
        if (!force && (!on(c) || now - Prefs.getLong(c, "hwRun") < 110_000L)) return cached(c);
        Prefs.putLong(c, "hwRun", now);
        List<Item> l = fetchAll();
        if (l.isEmpty() && !force) return cached(c);
        store(c, l);
        String seen = Prefs.getStr(c, "hwSeen", "");
        StringBuilder ns = new StringBuilder(seen);
        boolean first = seen.isEmpty();
        for (Item it : l) {
            String k = key(it.title);
            if (seen.contains(k)) continue;
            ns.append(k).append('|');
            if (first || it.sev < 2 || now - it.t > 6 * 3600_000L) continue;     // first run only fills history; no old alerts
            boolean ex = !it.exchange.isEmpty();
            String body = it.title + (it.unconfirmed ? "\n⚠️ Abhi unconfirmed lag raha hai — exchange ka official statement dekhein." : "")
                    + (ex ? "\n💡 Agar paisa " + it.exchange + " par hai: withdraw ka option check karein" + (it.token.isEmpty() ? "" : " · " + it.token + " token par dabao aa sakta hai") + "." : "")
                    + "\n📰 " + it.source;
            Notify.show(c, Prefs.N_NEWS, ("hw" + k).hashCode(), (ex ? "🚨 EXCHANGE HACK ALERT: " + it.exchange : "🚨 Hack alert") + (it.unconfirmed ? " (unconfirmed)" : ""),
                    body, 0xFFF6465D, MainActivity.TAB_MORE);
        }
        String s = ns.toString();
        if (s.length() > 6000) s = s.substring(s.length() - 5000);
        Prefs.putStr(c, "hwSeen", s);
        return l;
    }
}
