package com.signal.bot;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * ORDER FLOW — "candle ke neeche ke numbers": har candle mein kitne BUYERS (market buy / taker buy) aur kitne SELLERS
 * (market sell / taker sell) the, un ka farq (delta) aur cumulative delta (CVD).
 *
 * Data: Binance klines ka taker-buy volume (asal buyers/sellers). MEXC fallback par yeh field nahi hota → real = false
 * aur flow signals band (neutral) rehte hain — andaza kabhi asal bana kar nahi dikhaya jata.
 *
 * Signals (sab sirf CLOSED candle par, aage ka data kabhi nahi dekhte):
 *  - Absorption: bohat selling lekin price nahi gira (buyers ne jazb kiya) / bohat buying lekin price nahi chala.
 *  - Delta divergence: price naya low/high, lekin CVD nahi.
 *  - Stacked imbalance: lagatar 3 candles mein ek taraf ka ghalba.
 *  - Exhaustion: price naye high par lekin delta kamzor (ya naye low par lekin delta musbat).
 *  - Volume surge breakout: 2x volume + ek taraf ka delta.
 * Agli candle ka andaza = IS coin ki apni history mein usi tarah ke delta ke baad agli candle kitni baar upar gayi (sirf frequency).
 */
public final class OrderFlow {
    private OrderFlow() {}

    public static final class Result {
        public boolean ok, real;
        public double[] buy, sell, delta, cvd, dpct;
        public int score;                       // -100 .. +100
        public String action = "WAIT";          // BUY / SELL / WAIT
        public String headline = "";
        public final List<String> lines = new ArrayList<>();
        public double nextUpPct = Double.NaN;   // history: % of times next candle closed higher in a similar flow state
        public int nextN;
        public double lastBuyPct = 50, avg3BuyPct = 50, lastRv = 1;
    }

    public static Result analyze(Candles c) {
        Result r = new Result();
        if (c == null || c.n < 30) { r.headline = "Order flow: data kam"; return r; }
        int n = c.n;
        r.buy = new double[n]; r.sell = new double[n]; r.delta = new double[n]; r.cvd = new double[n]; r.dpct = new double[n];
        double cum = 0;
        int diffs = 0;
        for (int i = 0; i < n; i++) {
            double v = c.vol[i], b = Math.min(v, Math.max(0, c.takerBuy[i]));
            r.buy[i] = b; r.sell[i] = Math.max(0, v - b); r.delta[i] = r.buy[i] - r.sell[i];
            cum += r.delta[i];
            r.cvd[i] = cum;
            r.dpct[i] = v > 0 ? r.delta[i] / v : 0;
            if (v > 0 && Math.abs(c.takerBuy[i] - v / 2) > v * 1e-6) diffs++;
        }
        r.real = diffs > n / 4;
        r.ok = true;
        if (!r.real) {
            r.headline = "⚪ Order flow: is source (MEXC) mein asal buyers/sellers ka data nahi — Binance chahiye";
            r.lines.add("MEXC ke candle data mein taker-buy volume nahi hota, is liye buyers/sellers ke numbers andaze se nahi dikhaye jate.");
            return r;
        }
        int i = n - 1;
        double avgV = 0, avgR = 0;
        for (int k = i - 20; k < i; k++) { avgV += c.vol[k]; avgR += c.high[k] - c.low[k]; }
        avgV /= 20; avgR /= 20;
        double rv = avgV > 0 ? c.vol[i] / avgV : 1, rr = avgR > 0 ? (c.high[i] - c.low[i]) / avgR : 1;
        double rng = c.high[i] - c.low[i];
        double closePos = rng > 0 ? (c.close[i] - c.low[i]) / rng : 0.5;
        r.lastRv = rv;
        r.lastBuyPct = c.vol[i] > 0 ? r.buy[i] / c.vol[i] * 100 : 50;
        double s3b = 0, s3v = 0;
        for (int k = i - 2; k <= i; k++) { s3b += r.buy[k]; s3v += c.vol[k]; }
        r.avg3BuyPct = s3v > 0 ? s3b / s3v * 100 : 50;

        double sc = 0;
        double dp = r.dpct[i];
        r.lines.add(String.format(Locale.US, "Aakhri candle: buyers %.0f%% · sellers %.0f%% · delta %s%s · volume %.1fx normal",
                r.lastBuyPct, 100 - r.lastBuyPct, r.delta[i] >= 0 ? "+" : "−", k(Math.abs(r.delta[i])), rv));
        r.lines.add(String.format(Locale.US, "Aakhri 3 candles: buyers %.0f%% · sellers %.0f%%", r.avg3BuyPct, 100 - r.avg3BuyPct));

        // absorption
        if (rv >= 1.4 && dp <= -0.12 && (closePos >= 0.5 || rr < 0.9)) {
            sc += 30;
            r.lines.add("🟢 Absorption: sellers ne zor lagaya (delta manfi, volume zyada) lekin price nahi gira — kharidar khamoshi se maal utha rahe hain.");
        } else if (rv >= 1.4 && dp >= 0.12 && (closePos <= 0.5 || rr < 0.9)) {
            sc -= 30;
            r.lines.add("🔴 Absorption: buyers ne zor lagaya lekin price nahi barha — upar bechne wale maal de rahe hain (distribution).");
        }
        // divergence
        int j = -1;
        double lo = Double.MAX_VALUE, hi = -Double.MAX_VALUE;
        int jl = -1, jh = -1;
        for (int k = i - 14; k <= i - 3; k++) {
            if (c.low[k] < lo) { lo = c.low[k]; jl = k; }
            if (c.high[k] > hi) { hi = c.high[k]; jh = k; }
        }
        if (jl >= 0 && c.low[i] < lo && r.cvd[i] > r.cvd[jl]) {
            sc += 30;
            r.lines.add("🟢 Delta divergence: price ne naya low banaya lekin CVD ne nahi — selling kamzor pad rahi hai, neeche se palat sakta hai.");
        }
        if (jh >= 0 && c.high[i] > hi && r.cvd[i] < r.cvd[jh]) {
            sc -= 30;
            r.lines.add("🔴 Delta divergence: price ne naya high banaya lekin CVD ne nahi — buying kamzor, upar se palat sakta hai.");
        }
        // stacked imbalance
        boolean sb = true, ss = true;
        for (int k = i - 2; k <= i; k++) { sb &= r.dpct[k] >= 0.10; ss &= r.dpct[k] <= -0.10; }
        if (sb) { sc += 20; r.lines.add("🟢 Stacked imbalance: lagatar 3 candles mein buyers ka ghalba."); }
        if (ss) { sc -= 20; r.lines.add("🔴 Stacked imbalance: lagatar 3 candles mein sellers ka ghalba."); }
        // exhaustion
        double h10 = -Double.MAX_VALUE, l10 = Double.MAX_VALUE;
        for (int k = i - 10; k < i; k++) { h10 = Math.max(h10, c.high[k]); l10 = Math.min(l10, c.low[k]); }
        if (c.high[i] > h10 && dp < -0.02) { sc -= 20; r.lines.add("🔴 Exhaustion: naya 10-candle high lekin delta manfi — buyers thak gaye."); }
        if (c.low[i] < l10 && dp > 0.02) { sc += 20; r.lines.add("🟢 Exhaustion: naya 10-candle low lekin delta musbat — sellers thak gaye."); }
        // surge
        if (rv >= 2 && dp >= 0.2 && c.close[i] > c.open[i]) { sc += 25; r.lines.add("🟢 Volume surge: 2x volume + buyers ka mazboot ghalba — breakout ki taqat."); }
        if (rv >= 2 && dp <= -0.2 && c.close[i] < c.open[i]) { sc -= 25; r.lines.add("🔴 Volume surge: 2x volume + sellers ka mazboot ghalba — girawat ki taqat."); }
        sc += Fmt.clamp((r.avg3BuyPct - 50) * 1.2, -20, 20);
        r.score = (int) Math.round(Fmt.clamp(sc, -100, 100));
        r.action = r.score >= 35 ? "BUY" : r.score <= -35 ? "SELL" : "WAIT";
        r.headline = r.action.equals("BUY") ? "🟢 Order flow: BUYERS haavi (score " + r.score + ")"
                : r.action.equals("SELL") ? "🔴 Order flow: SELLERS haavi (score " + r.score + ")"
                : "⚪ Order flow: mixed (score " + r.score + ") — koi saaf ghalba nahi";

        // next-candle frequency from THIS coin's own history (same flow state)
        int st = bucket(r.dpct[i]), sl = slope(r, i);
        int up = 0, cnt = 0;
        for (int k = 6; k < i - 1; k++) {
            if (bucket(r.dpct[k]) == st && slope(r, k) == sl) {
                cnt++;
                if (c.close[k + 1] > c.close[k]) up++;
            }
        }
        r.nextN = cnt;
        if (cnt >= 25) r.nextUpPct = up * 100.0 / cnt;
        return r;
    }

    private static int bucket(double dp) { return dp <= -0.10 ? -1 : dp >= 0.10 ? 1 : 0; }

    private static int slope(Result r, int i) {
        double d = r.cvd[i] - r.cvd[Math.max(0, i - 5)];
        return d > 0 ? 1 : d < 0 ? -1 : 0;
    }

    /** "1.2K", "3.4M", "0.05" — compact number for the small labels under candles. */
    public static String k(double v) {
        double a = Math.abs(v);
        String s;
        if (a >= 1e9) s = String.format(Locale.US, "%.1fB", a / 1e9);
        else if (a >= 1e6) s = String.format(Locale.US, "%.1fM", a / 1e6);
        else if (a >= 1e4) s = String.format(Locale.US, "%.0fK", a / 1e3);
        else if (a >= 1e3) s = String.format(Locale.US, "%.1fK", a / 1e3);
        else if (a >= 100) s = String.format(Locale.US, "%.0f", a);
        else if (a >= 1) s = String.format(Locale.US, "%.1f", a);
        else s = String.format(Locale.US, "%.2f", a);
        return s;
    }

    // ------------------------------------------------------------------ per-price footprint of ONE candle (aggTrades)
    public static final class Level {
        public double price, buy, sell;
        public boolean imbBuy, imbSell, poc;
    }

    public static final class Footprint {
        public final List<Level> levels = new ArrayList<>();   // high price first
        public double totalBuy, totalSell;
        public long trades;
    }

    /** Builds a price ladder (buy vs sell at each price) from raw aggregate trades. Binance aggTrades: p, q, m (m = buyer is maker = SELL aggressor). */
    public static Footprint footprintFrom(JSONArray trades, int bins) {
        Footprint f = new Footprint();
        int n = trades.length();
        if (n == 0) return f;
        double lo = Double.MAX_VALUE, hi = -Double.MAX_VALUE;
        double[] p = new double[n], q = new double[n];
        boolean[] sellAgg = new boolean[n];
        for (int i = 0; i < n; i++) {
            JSONObject o = trades.optJSONObject(i);
            if (o == null) continue;
            p[i] = Double.parseDouble(o.optString("p", "0"));
            q[i] = Double.parseDouble(o.optString("q", "0"));
            sellAgg[i] = o.optBoolean("m");
            if (p[i] > 0) { lo = Math.min(lo, p[i]); hi = Math.max(hi, p[i]); }
        }
        if (hi <= lo) {
            Level l = new Level();
            l.price = hi;
            for (int i = 0; i < n; i++) { if (sellAgg[i]) l.sell += q[i]; else l.buy += q[i]; }
            f.levels.add(l); f.totalBuy = l.buy; f.totalSell = l.sell; f.trades = n;
            return f;
        }
        double step = (hi - lo) / bins;
        Level[] ls = new Level[bins];
        for (int b = 0; b < bins; b++) { ls[b] = new Level(); ls[b].price = lo + step * (b + 0.5); }
        for (int i = 0; i < n; i++) {
            if (p[i] <= 0) continue;
            int b = (int) Math.min(bins - 1, Math.max(0, Math.floor((p[i] - lo) / step)));
            if (sellAgg[i]) { ls[b].sell += q[i]; f.totalSell += q[i]; } else { ls[b].buy += q[i]; f.totalBuy += q[i]; }
        }
        double best = 0;
        int bi = -1;
        for (int b = 0; b < bins; b++) {
            double t = ls[b].buy + ls[b].sell;
            if (t > best) { best = t; bi = b; }
            // diagonal imbalance: buyers at this price vs sellers one price below (and the reverse)
            double below = b > 0 ? ls[b - 1].sell : 0, above = b < bins - 1 ? ls[b + 1].buy : 0;
            ls[b].imbBuy = ls[b].buy > 0 && ls[b].buy >= 3 * Math.max(below, 1e-12);
            ls[b].imbSell = ls[b].sell > 0 && ls[b].sell >= 3 * Math.max(above, 1e-12);
        }
        if (bi >= 0) ls[bi].poc = true;
        for (int b = bins - 1; b >= 0; b--) f.levels.add(ls[b]);
        f.trades = n;
        return f;
    }

    /** Network: ladder of the most recent candle of this timeframe (aggTrades, up to ~6000 trades). Run off the UI thread. */
    public static Footprint footprint(String symbol, long fromMs, long toMs) throws Exception {
        JSONArray all = new JSONArray();
        long t = fromMs;
        for (int page = 0; page < 6 && t < toMs; page++) {
            JSONArray a = new JSONArray(Scanner.get("/api/v3/aggTrades?symbol=" + symbol + "&startTime=" + t + "&endTime=" + toMs + "&limit=1000"));
            if (a.length() == 0) break;
            for (int i = 0; i < a.length(); i++) all.put(a.get(i));
            long last = a.getJSONObject(a.length() - 1).optLong("T", a.getJSONObject(a.length() - 1).optLong("time"));
            if (a.length() < 1000 || last <= t) break;
            t = last + 1;
        }
        return footprintFrom(all, 12);
    }
}
