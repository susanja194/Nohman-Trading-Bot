package com.signal.bot;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    static final int CARD = 0xFF141B2B, CHIP = 0xFF1C2638, STROKE = 0xFF263352,
            TEXT = 0xFFE8EAED, SOFT = 0xFFC9D1DC, MUTED = 0xFF8B95A7,
            GREEN = 0xFF0ECB81, RED = 0xFFF6465D, YELLOW = 0xFFFFC94D, INK = 0xFF0A0E17, CLAUDE = 0xFFD97757,
            CYAN_TXT = 0xFF22D3EE;

    private int uiMode;
    private int ACC, ACC2;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private final View[] pages = new View[10];
    static final int TAB_MARKET = 0, TAB_ANALYZE = 1, TAB_SIGNALS = 2, TAB_WALLET = 3, TAB_BIG = 4, TAB_LISTINGS = 5, TAB_SETTINGS = 6,
            TAB_HOME = 7, TAB_MORE = 8, TAB_HUNT = 9;
    static final String[] PAGE_TITLE = {"Markets", "Analysis", "Signals", "Portfolio", "Institutions", "News & Calendar", "Settings", "Dashboard", "More", "Gainer Hunter"};
    // bottom navigation: Home · Markets · Analysis · Signals · More
    private static final int[] NAV_PAGE = {TAB_HOME, TAB_MARKET, TAB_ANALYZE, TAB_SIGNALS, TAB_HUNT, TAB_MORE};
    private final LinearLayout[] navItems = new LinearLayout[6];
    private final TextView[] navIcon = new TextView[6], navLabel = new TextView[6];
    private TextView pageTitle, backBtn;

    // Home dashboard
    private LinearLayout homeBox;
    private String[] lastFg;
    private MacroEngine.Pulse homePulse;
    private List<MacroEngine.Event> homeEvents;

    // generic full-page overlay (wallet details etc.)
    private LinearLayout infoOverlay;

    // full-screen chart
    private ChartView fsChart;
    private boolean fsTfSwitch;
    static final String[] IND = {"Arrows", "MA Ribbon", "ParaDox", "Supertrend", "Ichimoku", "Crosses", "EMA", "EMA200", "VWAP", "BB", "Volume", "RSI", "MACD", "Fib", "FibTMF", "SMC", "Flow", "Patterns", "Zones", "VolProfile", "Whales", "Retail"};
    private String fsTitle = "Chart";

    // v11: three markets (crypto · gold & commodities · forex)
    private int mktSeg = 0;
    private final TextView[] mktSegChips = new TextView[4];
    private LinearLayout cryptoWrap, assetWrap, assetList;
    private TextView assetStatus, assetHead;
    private EditText assetSearch;
    private final Map<String, YahooData.Quote> assetQ = new HashMap<>();
    private long assetLoadedAt;
    private int assetLoadedSeg = -1;
    private int sigSeg = 0;
    private final TextView[] sigSegChips = new TextView[3];
    private LinearLayout cryptoBotBox, assetBotBox;
    private Button assetBotBtn;
    private TextView assetBotStatus;
    private CheckBox accCb;
    private EditText minWrEt, cpEt, spotSellEt, scalpHeavyEt, cmEt, geminiEt, groqEt;
    private LinearLayout newsList, newsOverlayRef;
    private TextView newsStatus;
    private int newsFilter = 0;
    private String newsQuery = "";

    // Wallet tracker
    private LinearLayout walletList;
    private TextView walletTotal, walletNet;
    private EditText walLabelEt, walAddrEt;
    private long walletsLoadedAt;

    // Big players
    private LinearLayout bigBox, bigMovesBox;
    private TextView bigStatus;
    private long bigLoadedAt;
    private final TextView[] bigMinChips = new TextView[5];
    private static final long[] BIG_MINS = {10_000_000L, 50_000_000L, 100_000_000L, 500_000_000L, 1_000_000_000L};

    // Settings extras
    private EditText minConfEt, quietFromEt, quietToEt;
    private CheckBox quietCb;

    // Macro / economic news
    private LinearLayout macroCol, listCol, macroBox, pulseBox;
    private TextView macroLine;
    private boolean macroHighOnly = true, showMacro = true;
    private long macroLoadedAt;
    private TextView[] newsSeg = new TextView[2];

    // Listings
    private LinearLayout listingBox;
    private TextView listingStatus;
    private long listingsLoadedAt;

    // Signal screen (live chart for one signal)
    private LinearLayout sigOverlay;
    private LiveChart sigLive;
    private int currentTab = -1;
    private TextView liveDot;
    private FrameLayout rootFrame;
    private boolean resumed;

    // in-app update
    private LinearLayout updateBanner;
    private TextView updStatus;
    private EditText repoEt;
    private volatile boolean installing;

    // Market
    private GaugeView fgGauge;
    private TextView btcView, globalView, marketCount;
    private EditText marketSearch;
    private LinearLayout marketList;
    private final TextView[] modeChips = new TextView[5];
    private int marketMode = -1, marketLimit = 50;   // -1 = normal list (biggest coins first, like Binance)
    private final Map<String, double[]> mk = new HashMap<>();          // sym -> {last, open, quoteVol}
    private final Map<String, TextView[]> rowViews = new HashMap<>();  // sym -> {price, pct}
    private WsStream marketWs;
    private final Map<String, double[]> pendingMini = new HashMap<>();
    private long marketLoadedAt;

    // Analyze
    private EditText searchEt;
    private TextView starBtn, chartTitle, livePrice;
    private String[] chartTfs;
    private TextView[] tfChips;
    private String chartTf;
    private String currentSym = "BTCUSDT";
    private ChartView chart;
    private BookView book;
    private TapeView tape;
    private LinearLayout watchRow, resultBox, fsOverlay;
    private ViewGroup chartParent;
    private int chartIndex;
    private ViewGroup.LayoutParams chartLp;
    private static final String[] LAYERS = {"Fib", "Lines", "Zones", "VolProfile", "Whales", "RSI"};
    private final TextView[] layerChips = new TextView[LAYERS.length];
    private CoinReport lastReport;

    // live coin stream
    private WsStream coinWs;
    private final Object liveLock = new Object();
    private double[] pendingKline;
    private final List<double[]> pendingTrades = new ArrayList<>();
    private double[][] pendingBids, pendingAsks;
    private boolean candleClosed;
    private volatile boolean coinLive;
    private String liveSym = "", liveTf = "";
    private double chartWhaleThr = 50000;
    private double dayOpen;

    // Signals
    private TextView statusView, statsView, diagView;
    /** Live Binance prices for the coins in the Signals tab (updated every ~15 s while the tab is open). */
    private final Map<String, Double> sigPx = new java.util.concurrent.ConcurrentHashMap<>();
    private long sigPxAt;
    private volatile boolean sigPxBusy;
    private Button scalpBtn, spotBtn;
    private LinearLayout signalList, alertList;
    private String signalKey = "";

    // Settings
    private final EditText[][] modeFields = new EditText[2][];
    private final Spinner[] tfSpinners = new Spinner[2];
    private CheckBox btcCb, smartCb, strongCb;
    private EditText whaleEt, glassEt;

    private final Runnable refresher = new Runnable() {
        @Override
        public void run() {
            refreshStatus();
            if (currentTab == 0 && mktSeg != 0 && infoOverlay == null && System.currentTimeMillis() - assetLoadedAt > 15_000) loadAssets();
            if (currentTab == 0 && (mktSeg == 0 || mktSeg == 3) && infoOverlay == null) updateUsdPrices();
            if (currentTab == TAB_SIGNALS && sigSeg == 0) refreshSigPx();
            if (currentTab == TAB_HUNT && infoOverlay == null && !huntBusy) {
                PumpHunter.Result hr1 = PumpHunter.cached();
                if (hr1 == null || System.currentTimeMillis() - hr1.at > 60_000L) runHunt();
                else if (huntTab != 4 && System.currentTimeMillis() - huntLiveDraw > 15_000) { huntLiveDraw = System.currentTimeMillis(); renderHunt(); }
            }
            handler.postDelayed(this, 5000);
        }
    };

    private final Runnable liveTick = new Runnable() {
        @Override
        public void run() {
            applyLive();
            applyMarketLive();
            handler.postDelayed(this, 400);
        }
    };

    // ============================================================ lifecycle
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        uiMode = Prefs.uiMode(this);
        ACC = Mode.accent(uiMode);
        ACC2 = Mode.accent2(uiMode);
        {
            List<String> tl = new ArrayList<>(java.util.Arrays.asList(Mode.chartTfs(uiMode)));
            for (String x : new String[]{"1d", "1w", "1M", "1Y", "5Y", "ALL"}) if (!tl.contains(x)) tl.add(x);
            chartTfs = tl.toArray(new String[0]);
        }
        chartTf = Mode.defaultChartTf(uiMode);
        tfChips = new TextView[chartTfs.length];
        ScannerService.createChannels(this);
        getWindow().setStatusBarColor(Mode.bgTop(uiMode));
        getWindow().setNavigationBarColor(CARD);
        currentSym = Prefs.lastCoin(this);

        rootFrame = new FrameLayout(this);
        LinearLayout root = column();
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Mode.bgTop(uiMode), Mode.bgBottom(uiMode)}));
        root.addView(header());
        FrameLayout content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));
        buildMarket();
        buildAnalyze();
        buildSignals();
        buildWallet();
        buildBig();
        buildListings();
        buildSettings();
        buildHome();
        buildMore();
        buildHunter();
        for (View p : pages) content.addView(p, new FrameLayout.LayoutParams(-1, -1));
        root.addView(bottomNav());
        rootFrame.addView(root, new FrameLayout.LayoutParams(-1, -1));
        setContentView(rootFrame);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        int startTab = savedInstanceState != null ? savedInstanceState.getInt("tab", TAB_HOME) : TAB_HOME;
        if (!handleIntent(getIntent())) showTab(startTab);
        loadChart();
        if (System.currentTimeMillis() - Prefs.lastUpdateCheck(this) > 3 * 3600_000L) checkForUpdate(false);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt("tab", currentTab);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private boolean handleIntent(Intent i) {
        if (i == null) return false;
        int tabX = i.getIntExtra("tab", -1);
        if (tabX >= 0 && tabX < pages.length) {
            i.removeExtra("tab");
            showTab(tabX);
            if (tabX == TAB_SIGNALS) {
                JSONObject first = Prefs.signals(this).optJSONObject(0);
                String mk0 = first == null ? Assets.CRYPTO : first.optString("mkt", Assets.CRYPTO);
                setSigSeg(Assets.FOREX.equals(mk0) ? 2 : Assets.COMMODITY.equals(mk0) ? 1 : 0);
            }
            return true;
        }
        if (i.getBooleanExtra("update", false)) {
            i.removeExtra("update");
            showTab(TAB_SETTINGS);
            checkForUpdate(true);
            return true;
        }
        String op = i.getStringExtra("open");
        if ("hunt".equals(op)) {
            i.removeExtra("open");
            final String pk = i.getStringExtra("pick");
            i.removeExtra("pick");
            openHunter();
            if (pk != null && pk.startsWith("pure:")) {
                huntTab = 0;
                JSONObject po = PumpHunter.Pure.find(this, pk.substring(5));
                if (po != null) openPure(po);
            } else if (pk != null) {
                PumpHunter.Pick pp = PumpHunter.HuntLog.find(this, pk);
                if (pp != null) openPick(pp);
            }
            return true;
        }
        if ("arb".equals(op)) {
            i.removeExtra("open");
            showTab(TAB_MORE);
            openArb();
            return true;
        }
        if ("catalyst".equals(op)) {
            i.removeExtra("open");
            showTab(TAB_MORE);
            openCatalysts();
            return true;
        }
        String nt = i.getStringExtra("news");
        if (nt != null) {
            i.removeExtra("news");
            showTab(TAB_MORE);
            NewsEngine.Item hit = null;
            for (NewsEngine.Item it : NewsEngine.cached()) if (it.title.equals(nt)) { hit = it; break; }
            if (hit != null) openNewsDetail(hit);
            else openNews();
            return true;
        }
        String coin = i.getStringExtra("coin");
        if (coin == null || coin.isEmpty()) return false;
        i.removeExtra("coin");
        openAnalyze(coin);
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        handler.post(refresher);
        handler.post(liveTick);
        if (chart.getData() != null) startCoinFeed();
        if ((currentTab == 0 && (mktSeg == 0 || mktSeg == 3)) || currentTab == TAB_HOME) startMarketFeed();
        if (sigOverlay != null && sigOverlay.getTag() instanceof JSONObject) openSignalView((JSONObject) sigOverlay.getTag());
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumed = false;
        handler.removeCallbacks(refresher);
        handler.removeCallbacks(liveTick);
        stopCoinFeed();
        stopMarketFeed();
        if (sigLive != null) sigLive.stop();
    }

    @Override
    protected void onDestroy() {
        stopCoinFeed();
        stopMarketFeed();
        pool.shutdownNow();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (chatGptOpen()) { if (gptWeb.canGoBack()) gptWeb.goBack(); else closeChatGpt(); }
        else if (fsOverlay != null) closeFullscreen();
        else if (infoOverlay != null) infoBackPressed();
        else if (sigOverlay != null) closeSignalView();
        else if (isSubPage(currentTab)) showTab(TAB_MORE);
        else if (currentTab != TAB_HOME) showTab(TAB_HOME);
        else super.onBackPressed();
    }

    private void switchMode(int m) {
        if (m == uiMode) return;
        Prefs.setUiMode(this, m);
        recreate();
    }

    // ============================================================ ui helpers
    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable round(int color, float radiusDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) g.setStroke(dp(1), strokeColor);
        return g;
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setPadding(0, dp(2), 0, dp(2));
        return t;
    }

    private TextView bold(String s, float sp, int color) {
        TextView t = text(s, sp, color);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private LinearLayout card(LinearLayout parent) {
        return card(parent, STROKE);
    }

    private LinearLayout card(LinearLayout parent, int border) {
        LinearLayout c = column();
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        c.setBackground(round(CARD, 18, border));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        parent.addView(c, lp);
        return c;
    }

    private LinearLayout pageColumn(int idx) {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout col = column();
        col.setPadding(dp(12), 0, dp(12), dp(28));
        sv.addView(col);
        pages[idx] = sv;
        return col;
    }

    private TextView chip(String s, boolean on) {
        TextView t = bold(s, 13, TEXT);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(13), dp(8), dp(13), dp(8));
        styleChip(t, on);
        return t;
    }

    private void styleChip(TextView t, boolean on) {
        t.setTextColor(on ? INK : TEXT);
        t.setBackground(round(on ? ACC : CHIP, 20, on ? ACC : STROKE));
    }

    private LinearLayout.LayoutParams chipLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dp(8);
        return lp;
    }

    private HorizontalScrollView hscroll(LinearLayout inner) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(inner);
        return hs;
    }

    private Button button(String s, int bg, int fg, int stroke) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(fg);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(round(bg, 14, stroke));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(50));
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    private View bar(double leftPct, int leftColor, int rightColor) {
        LinearLayout b = row();
        b.setBackground(round(rightColor, 6, 0));
        float l = (float) Math.max(0, Math.min(100, leftPct));
        View a = new View(this);
        a.setBackground(round(leftColor, 6, 0));
        b.addView(a, new LinearLayout.LayoutParams(0, -1, l));
        b.addView(new View(this), new LinearLayout.LayoutParams(0, -1, 100 - l));
        return b;
    }

    private View divider() {
        View d = new View(this);
        d.setBackgroundColor(STROKE);
        d.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1)));
        return d;
    }

    private EditText input(String hint, String value, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(MUTED);
        e.setTextColor(TEXT);
        e.setSingleLine(true);
        e.setInputType(type);
        e.setText(value);
        return e;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void openUrl(String url) {
        if (url == null || url.isEmpty()) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            toast("Link nahi khula");
        }
    }

    private static String base(String sym) {
        return sym.endsWith("USDT") ? sym.substring(0, sym.length() - 4) : sym;
    }

    private static double parse(EditText e, double def) {
        try {
            return Double.parseDouble(e.getText().toString().trim().replace(",", ""));
        } catch (Exception x) {
            return def;
        }
    }

    private static double num(JSONObject o, String k) {
        try {
            return Double.parseDouble(o.optString(k, "0"));
        } catch (Exception e) {
            return 0;
        }
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null && getCurrentFocus() != null) imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        } catch (Exception ignored) {
        }
    }

    // ============================================================ frame
    private static boolean isSubPage(int t) {
        return t == TAB_WALLET || t == TAB_BIG || t == TAB_LISTINGS || t == TAB_SETTINGS;
    }

    /** App bar: back (on sub pages) · page title · mode · bot status. */
    private View header() {
        LinearLayout h = row();
        h.setPadding(dp(12), dp(12), dp(14), dp(8));
        backBtn = bold("‹", 28, TEXT);
        backBtn.setPadding(dp(4), 0, dp(10), dp(4));
        backBtn.setVisibility(View.GONE);
        backBtn.setOnClickListener(v -> onBackPressed());
        h.addView(backBtn);
        LinearLayout tt = column();
        TextView brand = bold("PARADOX", 10, ACC);
        brand.setLetterSpacing(0.15f);
        tt.addView(brand);
        pageTitle = bold("Dashboard", 22, TEXT);
        tt.addView(pageTitle);
        h.addView(tt, new LinearLayout.LayoutParams(0, -2, 1));
        TextView vpn = bold("🛡️ VPN", 11, CYAN_TXT);
        vpn.setPadding(dp(9), dp(5), dp(9), dp(5));
        vpn.setBackground(round(CHIP, 12, CYAN_TXT));
        vpn.setOnClickListener(v -> openVpn());
        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(-2, -2);
        vlp.rightMargin = dp(6);
        h.addView(vpn, vlp);
        TextView mode = bold(Mode.label(uiMode), 11, INK);
        mode.setPadding(dp(9), dp(5), dp(9), dp(5));
        mode.setBackground(round(ACC, 12, 0));
        mode.setOnClickListener(v -> switchMode(uiMode == Mode.SCALP ? Mode.SPOT : Mode.SCALP));
        h.addView(mode);
        liveDot = bold("○ OFF", 11, MUTED);
        liveDot.setPadding(dp(9), dp(5), dp(9), dp(5));
        liveDot.setBackground(round(CHIP, 12, STROKE));
        liveDot.setOnClickListener(v -> showTab(TAB_SIGNALS));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = dp(6);
        h.addView(liveDot, lp);
        return h;
    }

    /** Bottom navigation with 5 large items (professional app style). */
    private View bottomNav() {
        LinearLayout nav = row();
        nav.setBackground(round(CARD, 0, STROKE));
        nav.setPadding(dp(4), dp(6), dp(4), dp(8));
        String[] icons = {"🏠", "📈", "🔍", "🔔", "🎯", "☰"};
        String[] labels = {"Home", "Markets", "Analysis", "Signals", "Hunter", "More"};
        for (int i = 0; i < 6; i++) {
            final int idx = i;
            LinearLayout it = column();
            it.setGravity(Gravity.CENTER);
            it.setPadding(0, dp(4), 0, dp(4));
            navIcon[i] = text(icons[i], 20, MUTED);
            navIcon[i].setGravity(Gravity.CENTER);
            navLabel[i] = text(labels[i], 10, MUTED);
            navLabel[i].setGravity(Gravity.CENTER);
            it.addView(navIcon[i]);
            it.addView(navLabel[i]);
            it.setOnClickListener(v -> showTab(NAV_PAGE[idx]));
            navItems[i] = it;
            nav.addView(it, new LinearLayout.LayoutParams(0, -2, 1));
        }
        return nav;
    }

    private void showTab(int i) {
        currentTab = i;
        for (int k = 0; k < pages.length; k++) pages[k].setVisibility(k == i ? View.VISIBLE : View.GONE);
        int navSel = 5;
        for (int k = 0; k < 6; k++) if (NAV_PAGE[k] == i) navSel = k;
        for (int k = 0; k < 6; k++) {
            boolean on = k == navSel;
            navLabel[k].setTextColor(on ? ACC : MUTED);
            navLabel[k].setTypeface(on ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            navItems[k].setBackground(on ? round((ACC & 0x00FFFFFF) | 0x26000000, 14, 0) : null);
        }
        pageTitle.setText(PAGE_TITLE[i]);
        backBtn.setVisibility(isSubPage(i) ? View.VISIBLE : View.GONE);
        if (i == 0 && mktSeg != 0) {
            stopMarketFeed();
            if (assetLoadedSeg != mktSeg || System.currentTimeMillis() - assetLoadedAt > 60_000) loadAssets();
        } else if (i == 0) {
            if (mk.isEmpty() || System.currentTimeMillis() - marketLoadedAt > 10 * 60_000) loadMarket();
            if (resumed) startMarketFeed();
        } else if (i == TAB_HOME) {
            if (resumed) startMarketFeed();   // live BTC / ETH prices on the dashboard
        } else {
            stopMarketFeed();
        }
        if (i == 2) {
            renderSignals(true);
            renderAlerts();
        }
        if (i == TAB_LISTINGS) {
            if (showMacro && System.currentTimeMillis() - macroLoadedAt > 5 * 60_000L) loadMacro(false);
            if (!showMacro && System.currentTimeMillis() - listingsLoadedAt > 10 * 60_000L) loadListings();
        }
        if (i == TAB_WALLET && System.currentTimeMillis() - walletsLoadedAt > 2 * 60_000L) loadWallets();
        if (i == TAB_BIG) {
            renderBigMoves();
            if (System.currentTimeMillis() - bigLoadedAt > 15 * 60_000L) loadBig();
        }
        if (i == TAB_HOME) loadHome();
        if (i == TAB_HUNT) {
            renderHunt();
            PumpHunter.Result hr0 = PumpHunter.cached();
            if (hr0 == null || System.currentTimeMillis() - hr0.at > 60_000L) runHunt();
        }
        refreshStatus();
    }

    // ============================================================ HOME (dashboard)
    private void buildHome() {
        LinearLayout col = pageColumn(TAB_HOME);
        homeBox = column();
        col.addView(homeBox);
    }

    private TextView tileValue;
    private final Map<String, TextView> homePx = new HashMap<>();

    /** Small stat tile used on the dashboard. */
    private LinearLayout tile(LinearLayout parent, String label, String value, String sub, int color, Runnable click) {
        LinearLayout t = column();
        t.setPadding(dp(12), dp(10), dp(12), dp(10));
        t.setBackground(round(CARD, 16, STROKE));
        t.addView(text(label, 11, MUTED));
        tileValue = bold(value, 18, color);
        t.addView(tileValue);
        if (sub != null) t.addView(text(sub, 11, color == TEXT ? SOFT : color));
        if (click != null) t.setOnClickListener(v -> click.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.rightMargin = dp(6);
        lp.leftMargin = dp(6);
        parent.addView(t, lp);
        return t;
    }

    private LinearLayout tileRow(LinearLayout parent) {
        LinearLayout r = row();
        r.setPadding(0, dp(10), 0, 0);
        parent.addView(r, new LinearLayout.LayoutParams(-1, -2));
        return r;
    }

    private void loadHome() {
        renderHome();
        pool.execute(() -> {
            try {
                if (mk.isEmpty() || System.currentTimeMillis() - marketLoadedAt > 5 * 60_000) {
                    final JSONArray tick = new JSONArray(Scanner.get("/api/v3/ticker/24hr?type=MINI"));
                    final String[] fg = SmartMoney.fearGreed();
                    runOnUiThread(() -> {
                        for (int i = 0; i < tick.length(); i++) {
                            JSONObject o = tick.optJSONObject(i);
                            if (o == null) continue;
                            String sy = o.optString("symbol");
                            if (!Scanner.isTradable(sy) || o.optDouble("lastPrice", 0) <= 0) continue;
                            mk.put(sy, new double[]{o.optDouble("lastPrice", 0), o.optDouble("openPrice", 0), o.optDouble("quoteVolume", 0)});
                        }
                        lastFg = fg;
                        marketLoadedAt = System.currentTimeMillis();
                        if (currentTab == TAB_HOME) renderHome();
                    });
                }
                for (String ys : new String[]{"GC=F", "EURUSD=X"}) {
                    try {
                        YahooData.Quote q = YahooData.quote(ys);
                        synchronized (assetQ) { assetQ.put(ys, q); }
                    } catch (Exception ignored) {
                    }
                }
                NewsEngine.fetch(this, 5 * 60_000L);
                CatalystEngine.fetch(this, 30 * 60_000L);
                final List<MacroEngine.Event> evs = MacroEngine.calendar(this, false);
                final MacroEngine.Pulse p = MacroEngine.pulse(false);
                runOnUiThread(() -> {
                    homeEvents = evs;
                    homePulse = p;
                    if (currentTab == TAB_HOME) renderHome();
                });
            } catch (Exception ignored) {
            }
        });
    }

    private TextView homeCd;
    private long homeCdT;
    private final Runnable homeClock = new Runnable() {
        @Override
        public void run() {
            handler.removeCallbacks(this);
            if (homeCd == null) return;
            long dt = homeCdT - System.currentTimeMillis();
            homeCd.setText(dt > 0 ? "⏳ " + clock(dt) + " baqi" : dt > -5 * 60_000L ? "🔴 ABHI release ho raha hai" : "✅ Release ho chuka — tap: final report");
            homeCd.setTextColor(dt > 0 && dt < 60_000 ? RED : dt <= 0 ? GREEN : YELLOW);
            if (currentTab == TAB_HOME) handler.postDelayed(this, 1000);
        }
    };

    private void renderHome() {
        homeBox.removeAllViews();
        homePx.clear();
        int h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY);
        LinearLayout g = card(homeBox, ACC);
        g.addView(bold((h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening") + " 👋", 20, TEXT));
        g.addView(text(new SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.US).format(new Date()) + " · " + Mode.label(uiMode) + " mode", 12, MUTED));
        boolean sc = Prefs.modeOn(this, Mode.SCALP), sp = Prefs.modeOn(this, Mode.SPOT);
        LinearLayout br = row();
        br.setPadding(0, dp(10), 0, 0);
        for (int m = 0; m < 2; m++) {
            final int mm = m;
            boolean on = m == 0 ? sc : sp;
            TextView b = bold((on ? "● " : "○ ") + Mode.label(m) + (on ? " ON" : " OFF"), 13, on ? INK : Mode.accent(m));
            b.setGravity(Gravity.CENTER);
            b.setPadding(dp(8), dp(10), dp(8), dp(10));
            b.setBackground(round(on ? Mode.accent(m) : CHIP, 14, Mode.accent(m)));
            b.setOnClickListener(v -> { toggleMode(mm); handler.postDelayed(this::renderHome, 400); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            lp.rightMargin = dp(6);
            br.addView(b, lp);
        }
        g.addView(br);
        boolean co = Prefs.mktOn(this, Assets.COMMODITY), fo = Prefs.mktOn(this, Assets.FOREX);
        TextView mb2 = text((co ? "🟢" : "⚪") + " Gold bot " + (co ? "ON" : "OFF") + "   ·   " + (fo ? "🟢" : "⚪") + " Forex bot " + (fo ? "ON" : "OFF")
                + (Prefs.accuracyMode(this) ? "   ·   🎯 Accuracy mode" : ""), 12, SOFT);
        mb2.setPadding(0, dp(8), 0, 0);
        mb2.setOnClickListener(v -> { showTab(TAB_SIGNALS); setSigSeg(co || !fo ? 1 : 2); });
        g.addView(mb2);

        // market snapshot
        TextView sh = bold("MARKET SNAPSHOT", 11, MUTED);
        sh.setLetterSpacing(0.12f);
        sh.setPadding(dp(4), dp(16), 0, 0);
        homeBox.addView(sh);
        LinearLayout r1 = tileRow(homeBox);
        for (String sy : new String[]{"BTCUSDT", "ETHUSDT"}) {
            double[] v = mk.get(sy);
            double ch = v == null ? 0 : change(v);
            final String s2 = sy;
            tile(r1, base(sy) + "/USDT  ● live", v == null ? "—" : "$" + Fmt.price(v[0]), v == null ? "load ho raha hai" : Fmt.pct(ch) + " · 24h",
                    v == null ? TEXT : ch >= 0 ? GREEN : RED, () -> openAnalyze(s2));
            homePx.put(sy, tileValue);
        }
        LinearLayout rg = tileRow(homeBox);
        for (String ys : new String[]{"GC=F", "EURUSD=X"}) {
            final Assets.Asset as = Assets.find(ys);
            YahooData.Quote q;
            synchronized (assetQ) { q = assetQ.get(ys); }
            tile(rg, as.icon + " " + as.short_, q == null ? "—" : Assets.fmt(as, q.price), q == null ? "load ho raha hai" : Fmt.pct(q.change) + " · aaj",
                    q == null ? TEXT : q.change >= 0 ? GREEN : RED, () -> openAssetChart(as));
        }
        LinearLayout r2 = tileRow(homeBox);
        int fgv = -1;
        try { if (lastFg != null) fgv = Integer.parseInt(lastFg[0]); } catch (Exception ignored) { }
        tile(r2, "Fear & Greed", fgv < 0 ? "—" : String.valueOf(fgv), lastFg == null ? "" : lastFg[1], GaugeView.colorFor(fgv), () -> showTab(TAB_MARKET));
        tile(r2, "Macro mood", homePulse == null ? "—" : homePulse.score >= 20 ? "Risk-ON" : homePulse.score <= -20 ? "Risk-OFF" : "Neutral",
                homePulse == null || Double.isNaN(homePulse.fedRate) ? "Fed · yields · dollar" : String.format(Locale.US, "Fed rate %.2f%%", homePulse.fedRate),
                homePulse == null ? TEXT : homePulse.score >= 20 ? GREEN : homePulse.score <= -20 ? RED : YELLOW,
                () -> { showTab(TAB_LISTINGS); setNewsSeg(true); });

        // v31: ONE live news ticker (important news + catalysts, right → left) instead of separate cards that repeated the same event
        {
            long nowT = System.currentTimeMillis();
            List<String> tx = new ArrayList<>();
            List<Integer> tc = new ArrayList<>();
            java.util.Set<String> seenT = new java.util.HashSet<>();
            for (NewsEngine.Item it : NewsEngine.cached()) {
                if (nowT - it.time > 12 * 3600_000L) break;
                if (it.severity < 2 || tx.size() >= 7) continue;
                if (!seenT.add(it.title.toLowerCase(Locale.US))) continue;
                tx.add((it.severity >= 3 ? "🚨 " : "📰 ") + it.title + " (" + ago(it.time) + ")");
                tc.add(it.dir > 0 ? GREEN : it.dir < 0 ? RED : TEXT);
            }
            int cat = 0;
            for (CatalystEngine.Event e : CatalystEngine.cached()) {
                if (cat >= 5 || e.type.equals(CatalystEngine.MACRO)) continue;   // macro events are in the countdown card below — not twice
                boolean det = e.type.equals(CatalystEngine.ODDS) || e.type.equals(CatalystEngine.OI);
                if (e.severity < 2 || !(det || (e.time > nowT && e.time - nowT < 3L * 86_400_000L))) continue;
                if (!seenT.add(e.title.toLowerCase(Locale.US))) continue;
                tx.add(e.icon() + " " + e.title + " · " + (det ? ago(e.time) : until(e.time)));
                tc.add(e.dir > 0 ? GREEN : e.dir < 0 ? RED : YELLOW);
                cat++;
            }
            if (!tx.isEmpty()) {
                LinearLayout tk = card(homeBox, YELLOW);
                tk.setPadding(dp(10), dp(8), dp(10), dp(8));
                LinearLayout th = row();
                th.addView(bold("🔴 LIVE", 10, RED), chipLp());
                th.addView(text("Top news & catalysts · tap = sab khabrein", 10, MUTED));
                tk.addView(th);
                TickerView tv = new TickerView(this);
                tv.set(tx, tc);
                tk.addView(tv, new LinearLayout.LayoutParams(-1, dp(30)));
                tk.setOnClickListener(v -> openNews());
                tv.setOnClickListener(v -> openNews());
            }
        }

        // v34: latest US data RESULT (last 48 h) right on the dashboard
        if (homeEvents != null) {
            long nowR = System.currentTimeMillis();
            for (final MacroEngine.Event e : homeEvents) {
                if (!"High".equals(e.impact) || e.time > nowR - 60_000L || e.time < nowR - 48 * 3600_000L) continue;
                if (e.actual.isEmpty() && Double.isNaN(e.reaction)) continue;
                TextView rh = bold("📢 US DATA RESULT", 11, MUTED);
                rh.setLetterSpacing(0.12f);
                rh.setPadding(dp(4), dp(14), 0, 0);
                homeBox.addView(rh);
                macroResultCard(homeBox, e);
                break;
            }
        }

        // next high-impact macro event — with a live second-by-second countdown
        homeCd = null;
        if (homeEvents != null) {
            long now = System.currentTimeMillis();
            for (final MacroEngine.Event e : homeEvents) {
                if (!"High".equals(e.impact) || e.time < now - 30 * 60_000L) continue;
                long dt = e.time - now;
                LinearLayout ec = card(homeBox, dt < 2 * 3600_000L ? RED : YELLOW);
                ec.addView(text("NEXT HIGH-IMPACT EVENT · tap = poori report", 10, MUTED));
                ec.addView(bold("🇺🇸 " + e.title, 16, TEXT));
                ec.addView(text(MacroEngine.pkt(e.time) + " PKT" + (e.forecast.isEmpty() ? "" : " · forecast " + e.forecast + " · pichla " + e.previous), 12, SOFT));
                homeCd = bold("", 18, YELLOW);
                homeCdT = e.time;
                ec.addView(homeCd);
                ec.addView(text(e.expectation, 12, SOFT));
                ec.setOnClickListener(v -> openEventReport("🏛️ US macro", e.title, e.time, "Economic calendar", e.expectation, "", 0, 3, new ArrayList<>(), "", false, false, "", null));
                break;
            }
        }
        homeClock.run();

        // latest signals
        TextView ss = bold("LATEST SIGNALS", 11, MUTED);
        ss.setLetterSpacing(0.12f);
        ss.setPadding(dp(4), dp(16), 0, 0);
        homeBox.addView(ss);
        JSONArray sig = Prefs.signals(this);
        LinearLayout sc2 = card(homeBox);
        if (sig.length() == 0) sc2.addView(text("Abhi koi signal nahi — upar se bot ON karein.", 13, MUTED));
        for (int i = 0; i < sig.length() && i < 3; i++) {
            final JSONObject o = sig.optJSONObject(i);
            if (o == null) continue;
            boolean buy = "BUY".equals(o.optString("side"));
            LinearLayout rr = row();
            rr.setPadding(0, dp(6), 0, dp(6));
            Assets.Asset sa = Assets.find(o.optString("asset", ""));
            rr.addView(bold((buy ? "🟢 BUY " : "🔴 SELL ") + (sa != null ? sa.icon + " " + sa.short_ : base(o.optString("sym"))), 14, buy ? GREEN : RED), new LinearLayout.LayoutParams(0, -2, 1));
            String st = o.optString("st", "");
            rr.addView(text(st.equals("win") ? "✅ WIN" : st.equals("loss") ? "❌ LOSS" : st.equals("open") ? "⏳ open" : "", 12, SOFT));
            rr.setOnClickListener(v -> openSignalView(o));
            sc2.addView(rr);
        }
        int[] stt = Scanner.signalStats(sig);
        if (stt[0] + stt[1] > 0) sc2.addView(text(String.format(Locale.US, "🏆 Win rate %.0f%% (%d trades)", stt[0] * 100.0 / (stt[0] + stt[1]), stt[0] + stt[1]), 12, ACC2));
        sc2.setOnClickListener(v -> showTab(TAB_SIGNALS));

        // portfolio + institutions
        TextView ps = bold("PORTFOLIO & SMART MONEY", 11, MUTED);
        ps.setLetterSpacing(0.12f);
        ps.setPadding(dp(4), dp(16), 0, 0);
        homeBox.addView(ps);
        LinearLayout r3 = tileRow(homeBox);
        double tot = 0;
        JSONArray ws = Prefs.wallets(this);
        for (int i = 0; i < ws.length(); i++) tot += ws.optJSONObject(i) == null ? 0 : ws.optJSONObject(i).optDouble("usd", 0);
        tile(r3, "My portfolio", ws.length() == 0 ? "Add wallet" : Fmt.usd(tot), ws.length() + " wallets · watch-only", ws.length() == 0 ? ACC : TEXT, () -> showTab(TAB_WALLET));
        JSONArray mv = Prefs.bigMoves(this);
        JSONObject m0 = mv.optJSONObject(0);
        tile(r3, "Institutions", m0 == null ? "Track" : (m0.optBoolean("buy") ? "🟢 Buying" : "🔴 Selling"),
                m0 == null ? "BlackRock · Strategy · WLFI" : m0.optString("text"), m0 == null ? ACC : m0.optBoolean("buy") ? GREEN : RED, () -> showTab(TAB_BIG));

        // quick actions
        TextView qa = bold("QUICK ACTIONS", 11, MUTED);
        qa.setLetterSpacing(0.12f);
        qa.setPadding(dp(4), dp(16), 0, 0);
        homeBox.addView(qa);
        LinearLayout r4 = tileRow(homeBox);
        tile(r4, "🔍", "Analyze", "Kisi bhi coin ka", ACC, () -> showTab(TAB_ANALYZE));
        tile(r4, "📅", "Calendar", "Fed · CPI · NFP", YELLOW, () -> { showTab(TAB_LISTINGS); setNewsSeg(true); });
        LinearLayout r5 = tileRow(homeBox);
        tile(r5, "🆕", "Listings", "Naye coins", ACC2, () -> { showTab(TAB_LISTINGS); setNewsSeg(false); });
        tile(r5, "⚙️", "Settings", "Bots · alerts", SOFT, () -> showTab(TAB_SETTINGS));
        LinearLayout r6 = tileRow(homeBox);
        tile(r6, "📚", "Academy", "Trading seekhein", CYAN_TXT, this::openAcademy);
        tile(r6, "🧮", "Tools", "SL/TP · Average", GREEN, this::openTools);
        LinearLayout r7 = tileRow(homeBox);
        tile(r7, "📰", "Live News", Prefs.newsOn(this) ? "● radar ON" : "Hack · listing · ETF", Prefs.newsOn(this) ? GREEN : YELLOW, this::openNews);
        tile(r7, "📈", "Markets", "Crypto · Gold · Forex", ACC, () -> showTab(TAB_MARKET));
        homeBox.addView(text("\n⚠️ Signals maloomat ke liye hain, financial advice nahi.", 11, MUTED));
    }

    // ============================================================ MORE (menu hub)
    private void buildMore() {
        LinearLayout col = pageColumn(TAB_MORE);
        String[][] items = {
                {"🧠", "SMC Pro Lab (signals · backtest · paper)", "Smart Money Concepts signals, historical backtest, walk-forward, live paper forward-test, risk manager", "smc"},
                {"🤖", "AutoPilot (auto trade) · exchange API connect", "MEXC · Binance · Bybit · OKX · Gate — API jodein, PAPER ya LIVE mein confirm signals par khud khareed/farokht, stop-loss + TP, kill switch", "autopilot"},
                {"🩸", "Dip Hunter (gire hue coins)", "Bohat gire coins jo wapas upar ja sakte hain — oversold, washout volume, buyers wapas (order flow), girta chaqu alag", "dip"},
                {"🎉", "Occasions calendar (Cat Day · Dog Day...)", "Event se pehle alert + pichle saalon ka run-up — theme coins pehle se kharidne ke liye", "events"},
                {"🚨", "Exchange Hack Watch", "Kisi exchange / protocol ka hack ya withdrawals band hone ki khabar foran notification", "hack"},
                {"🕰", "History compare", "Aaj ki haalat vs maazi: milti-julti situations ke baad kya hua (daily / weekly)", "history"},
                {"💥", "Liquidation Map (LIVE)", "Kis coin ki LONG / SHORT liquidations kis price par pari hain — magnet zones + asal live liquidations", "liqmap"},
                {"🏦", "Exchange liquidations (LIVE)", "Binance · Bybit · OKX · Gate · HTX ne alag alag kitna liquidate kiya (1h–24h), long vs short, top coins, exchange ka andazan faida", "liqex"},
                {"🇨🇳", "China pulse", "USDT OTC premium · yuan · Hang Seng · China news — crypto & gold par asar", "china"},
                {"⚡", "Mispricing Radar (24/7)", "Price errors · arbitrage 8 exchanges · triangle · funding · stablecoin peg", "arb"},
                {"📰", "Crypto News · LIVE", "Hack, listing, ETF, SEC, whales, X posts — asar ke saath", "news"},
                {"🌍", "Market hours & world volume", "Forex, gold, stocks kab khulte / band · crypto, gold, forex ka volume IN/OUT", "hours"},
                {"📆", "Catalyst Radar", "Aane wale unlocks, listings, delistings, airdrops, ETF, Polymarket odds", "catalyst"},
                {"💼", "Portfolio", "Apne wallets — watch-only, 100% safe", String.valueOf(TAB_WALLET)},
                {"🏛️", "Institutions", "BlackRock, ETFs, companies, governments, whale wallets", String.valueOf(TAB_BIG)},
                {"📅", "Economic Calendar", "Fed, CPI, PCE, NFP, GDP — asar aur alerts", "cal"},
                {"🆕", "New Listings", "Binance, Bybit, OKX, KuCoin — listing se pehle", "list"},
                {"📚", "ParaDox Academy", "Trading seekhein — basics se pro tak (" + Academy.LESSONS.length + " sabaq)", "academy"},
                {"🧮", "Trading Tools", "SL/TP · Average price (DCA) · Position size · R:R · P/L", "tools"},
                {"⚙️", "Settings", "Bots, notifications, AI, data & privacy", String.valueOf(TAB_SETTINGS)},
                {"ℹ️", "About ParaDox", "Developer: Nohman Arshid · version, data sources, privacy", "about"}};
        for (String[] it : items) {
            final String target = it[3];
            LinearLayout c = card(col);
            LinearLayout r = row();
            TextView ic = text(it[0], 24, TEXT);
            ic.setGravity(Gravity.CENTER);
            ic.setBackground(round((ACC & 0x00FFFFFF) | 0x22000000, 14, 0));
            r.addView(ic, new LinearLayout.LayoutParams(dp(50), dp(50)));
            LinearLayout t = column();
            t.setPadding(dp(14), 0, 0, 0);
            t.addView(bold(it[1], 16, TEXT));
            t.addView(text(it[2], 12, MUTED));
            r.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
            r.addView(bold("›", 24, MUTED));
            c.addView(r);
            c.setOnClickListener(v -> {
                if (target.equals("cal")) { showTab(TAB_LISTINGS); setNewsSeg(true); }
                else if (target.equals("list")) { showTab(TAB_LISTINGS); setNewsSeg(false); }
                else if (target.equals("academy")) openAcademy();
                else if (target.equals("news")) openNews();
                else if (target.equals("catalyst")) openCatalysts();
                else if (target.equals("arb")) openArb();
                else if (target.equals("hunt")) openHunter();
                else if (target.equals("china")) openChina();
                else if (target.equals("liqmap")) openLiqMap();
                else if (target.equals("smc")) openSmcLab();
                else if (target.equals("autopilot")) openAutoPilot();
                else if (target.equals("dip")) openDipHunter();
                else if (target.equals("events")) openEvents();
                else if (target.equals("hack")) openHackWatch();
                else if (target.equals("history")) openHistory(null);
                else if (target.equals("liqex")) openLiqExchanges();
                else if (target.equals("hours")) openMarketHours();
                else if (target.equals("about")) openAbout();
                else if (target.equals("tools")) openTools();
                else showTab(Integer.parseInt(target));
            });
        }
        String ver = "?";
        try {
            ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
        }
        TextView f = text("ParaDox · v" + ver + "\nCrypto · Gold · Forex\nDeveloped by Nohman Arshid 🇵🇰", 11, MUTED);
        f.setGravity(Gravity.CENTER);
        f.setPadding(0, dp(24), 0, 0);
        col.addView(f);
    }

    // ============================================================ generic full page (overlay)
    private Runnable infoBack;

    private void infoBackPressed() {
        Runnable r = infoBack;
        if (r != null) r.run();
        else closeInfo();
    }

    /** Page whose ‹ / back button goes to `back` (e.g. the list it was opened from). */
    private LinearLayout openPage(String title, Runnable back) {
        LinearLayout c = openPage(title);
        infoBack = back;
        return c;
    }

    private LinearLayout openPage(String title) {
        closeInfo();
        infoBack = null;
        infoOverlay = column();
        infoOverlay.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Mode.bgTop(uiMode), Mode.bgBottom(uiMode)}));
        LinearLayout h = row();
        h.setPadding(dp(12), dp(12), dp(14), dp(8));
        TextView b = bold("‹", 28, TEXT);
        b.setPadding(dp(4), 0, dp(12), dp(4));
        b.setOnClickListener(v -> infoBackPressed());
        h.addView(b);
        h.addView(bold(title, 20, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        infoOverlay.addView(h);
        ScrollView sv = new ScrollView(this);
        LinearLayout c = column();
        c.setPadding(dp(12), 0, dp(12), dp(28));
        sv.addView(c);
        infoOverlay.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        rootFrame.addView(infoOverlay, new FrameLayout.LayoutParams(-1, -1));
        return c;
    }

    private void closeInfo() {
        if (infoOverlay != null) rootFrame.removeView(infoOverlay);
        infoOverlay = null;
    }

    // ============================================================ v11: GOLD & COMMODITIES · FOREX markets
    private void setMktSeg(int i) {
        mktSeg = i;
        for (int k = 0; k < 4; k++) styleChip(mktSegChips[k], k == i);
        // v32: 3 = "Sab" — gold + forex on top, then the crypto coin list (mixed in one page)
        cryptoWrap.setVisibility(i == 0 || i == 3 ? View.VISIBLE : View.GONE);
        assetWrap.setVisibility(i == 0 ? View.GONE : View.VISIBLE);
        if (i == 0 || i == 3) {
            if (mk.isEmpty()) loadMarket();
            if (resumed) startMarketFeed();
        }
        if (i != 0) {
            if (i != 3) stopMarketFeed();
            assetHead.setText(i == 1 ? "🥇 Gold & Commodities" : i == 2 ? "💱 Forex" : "🥇 Gold · 💱 Forex · ₿ Crypto");
            renderAssets();
            if (assetLoadedSeg != i || System.currentTimeMillis() - assetLoadedAt > 60_000) loadAssets();
        }
    }

    private void buildAssetMarket(LinearLayout wrap) {
        LinearLayout c = card(wrap, YELLOW);
        LinearLayout hr = row();
        assetHead = bold("🥇 Gold & Commodities", 18, TEXT);
        hr.addView(assetHead, new LinearLayout.LayoutParams(0, -2, 1));
        TextView rf = chip("↻ Refresh", false);
        rf.setOnClickListener(v -> loadAssets());
        hr.addView(rf);
        c.addView(hr);
        assetStatus = text("", 12, MUTED);
        c.addView(assetStatus);
        TextView hrs = bold("🌍 Market timings, sessions aur duniya ka volume ›", 13, CYAN_TXT);
        hrs.setPadding(0, dp(4), 0, dp(4));
        hrs.setOnClickListener(v -> openMarketHours());
        c.addView(hrs);
        assetSearch = input("🔎 Search (jaise GOLD, XAU, OIL, EURUSD, JPY)", "", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        assetSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s2, int a2, int b2, int c2) { }
            @Override public void onTextChanged(CharSequence s2, int a2, int b2, int c2) { }
            @Override public void afterTextChanged(Editable s2) { renderAssets(); }
        });
        c.addView(assetSearch);
        assetList = column();
        c.addView(assetList);
        LinearLayout info = card(wrap);
        info.addView(bold("ℹ️ Is market ke baare mein", 14, TEXT));
        info.addView(text("Prices Yahoo Finance (futures / spot FX) se aati hain, har minute taaza hoti hain. Kisi bhi asset par tap karein — "
                + "poora analysis: multi-timeframe trend, moving averages (EMA 9·21·50·100·200), golden/death cross, chart patterns, "
                + "ParaDox rule ka backtest, US dollar index (DXY), yields aur is hafte ki bari news.\n"
                + "Market timings: Sunday raat ~3 baje (PKT) se Saturday subah ~3 baje tak. Weekend par band.", 12, MUTED));
    }

    private void loadAssets() {
        if (mktSeg == 0) return;
        final int seg = mktSeg;
        final Assets.Asset[] list = segAssets(seg);
        assetLoadedAt = System.currentTimeMillis();
        assetLoadedSeg = seg;
        if (assetQ.isEmpty()) assetStatus.setText("Prices load ho rahi hain...");
        pool.execute(() -> {
            int ok = 0;
            for (Assets.Asset a : list) {
                try {
                    YahooData.Quote q = YahooData.quote(a.sym);
                    synchronized (assetQ) { assetQ.put(a.sym, q); }
                    ok++;
                } catch (Exception ignored) {
                }
            }
            final int fok = ok;
            runOnUiThread(() -> {
                if (mktSeg != seg) return;
                renderAssets();
                boolean open = Assets.marketOpen(System.currentTimeMillis());
                String t = new SimpleDateFormat("HH:mm", Locale.US).format(new Date());
                assetStatus.setText(fok == 0 ? "❌ Data nahi mila — internet check karke Refresh dabayen"
                        : (open ? "🟢 Market khuli hai" : "🔴 Market band (weekend) — aakhri prices") + " · updated " + t + " · tap = analysis");
            });
        });
    }

    /** Assets of a Markets segment; 3 = everything (commodities + forex + BTC/ETH/SOL in USD). */
    private static Assets.Asset[] segAssets(int seg) {
        if (seg != 3) return Assets.list(segMarket(seg));
        List<Assets.Asset> l = new ArrayList<>();
        Collections.addAll(l, Assets.list(Assets.COMMODITY));
        for (Assets.Asset a : Assets.list(Assets.FOREX)) if (!l.contains(a)) l.add(a);
        Collections.addAll(l, Assets.CRYPTO_USD_LIST);
        return l.toArray(new Assets.Asset[0]);
    }

    private void renderAssets() {
        if (assetList == null || mktSeg == 0) return;
        assetList.removeAllViews();
        String aq = assetSearch == null ? "" : assetSearch.getText().toString().trim().toUpperCase(Locale.US).replace("/", "");
        int shown = 0;
        for (final Assets.Asset a : segAssets(mktSeg)) {
            if (!aq.isEmpty() && !(a.short_.toUpperCase(Locale.US).replace("/", "").contains(aq) || a.name.toUpperCase(Locale.US).contains(aq) || a.sym.toUpperCase(Locale.US).contains(aq))) continue;
            shown++;
            YahooData.Quote q;
            synchronized (assetQ) { q = assetQ.get(a.sym); }
            LinearLayout r = row();
            r.setPadding(0, dp(11), 0, dp(11));
            TextView ic = text(a.icon, 22, TEXT);
            ic.setGravity(Gravity.CENTER);
            r.addView(ic, new LinearLayout.LayoutParams(dp(40), -2));
            LinearLayout nm = column();
            nm.addView(bold(a.short_, 15, TEXT));
            nm.addView(text(a.name, 11, MUTED));
            r.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
            LinearLayout pr = column();
            pr.setGravity(Gravity.END);
            TextView pv = bold(q != null ? Assets.fmt(a, q.price) : "—", 15, TEXT);
            pv.setGravity(Gravity.END);
            pr.addView(pv);
            if (q != null) {
                TextView ch = bold(Fmt.pct(q.change), 12, q.change >= 0 ? GREEN : RED);
                ch.setGravity(Gravity.END);
                ch.setPadding(dp(8), dp(2), dp(8), dp(2));
                ch.setBackground(round(q.change >= 0 ? 0x220ECB81 : 0x22F6465D, 8, 0));
                pr.addView(ch);
            }
            r.addView(pr);
            r.setOnClickListener(v -> openAssetChart(a));
            assetList.addView(r);
            assetList.addView(divider());
        }
        if (shown == 0) assetList.addView(text("\"" + aq + "\" nahi mila — naam ya symbol check karein (jaise GOLD, OIL, EUR, JPY).", 12, MUTED));
    }

    /** Simple chart page for gold / commodity / forex (no lines) — "Analyze" opens the full analysis. */
    private void openAssetChart(final Assets.Asset a) {
        final LinearLayout col = openPage(a.icon + " " + a.short_);
        final LinearLayout page = infoOverlay;
        LinearLayout h = card(col, YELLOW);
        LinearLayout hr = row();
        LinearLayout nm = column();
        nm.addView(bold(a.name, 16, TEXT));
        boolean cu = Assets.CRYPTO_USD.equals(a.market);
        nm.addView(text(a.short_ + " · " + (cu ? "Crypto (US dollar)" : Assets.FOREX.equals(a.market) ? "Forex" : "Commodity") + " · "
                + (cu || Assets.marketOpen(System.currentTimeMillis()) ? "🟢 market khuli" : "🔴 market band"), 11, MUTED));
        hr.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
        final TextView pv = bold("—", 18, TEXT);
        hr.addView(pv);
        h.addView(hr);
        final ChartView cv = new ChartView(this);
        cv.setAccent(YELLOW);
        cv.setCompact(true);
        cv.setTitle(a.short_);
        cleanChart(cv);
        final String[] tfs = {"5m", "15m", "1h", "4h", "1d", "1w", "1M", "1Y", "5Y", "ALL"};
        final TextView[] tc = new TextView[tfs.length];
        LinearLayout tr = row();
        tr.setPadding(0, dp(6), 0, dp(4));
        final Runnable[] load = new Runnable[1];
        final String[] cur = {"1h"};
        load[0] = () -> {
            cv.setMessage(cur[0] + " chart load ho raha hai...");
            final String tf = cur[0];
            pool.execute(() -> {
                try {
                    final Candles c = YahooData.fetch(a.sym, tf, false);
                    YahooData.Quote q = null;
                    try { q = YahooData.quote(a.sym); } catch (Exception ignored) { }
                    final YahooData.Quote fq = q;
                    runOnUiThread(() -> {
                        if (infoOverlay != page) return;
                        cv.setData(c, null, new double[c.n], new double[c.n], ChartRange.interval(tf), false);
                        cv.setVisible(ChartRange.visible(tf, c.n));
                        cleanChart(cv);
                        if (fq != null) {
                            pv.setText(Assets.fmt(a, fq.price) + "  " + Fmt.pct(fq.change));
                            pv.setTextColor(fq.change >= 0 ? GREEN : RED);
                        }
                    });
                } catch (Exception e) {
                    final String m = e.getMessage();
                    runOnUiThread(() -> cv.setMessage("Chart nahi mila: " + m));
                }
            });
        };
        for (int i = 0; i < tfs.length; i++) {
            final int ti = i;
            tc[i] = chip(tfs[i], tfs[i].equals("1h"));
            tc[i].setOnClickListener(v -> {
                for (int k = 0; k < tfs.length; k++) styleChip(tc[k], k == ti);
                cur[0] = tfs[ti];
                load[0].run();
            });
            tr.addView(tc[i], chipLp());
        }
        h.addView(hscroll(tr));
        cv.setOnTap(() -> openChartFullscreen(cv, a.short_ + " · " + a.name, false));
        int ch = Math.max(dp(380), Math.min(dp(640), (int) (getResources().getDisplayMetrics().heightPixels * 0.55f)));
        h.addView(cv, new LinearLayout.LayoutParams(-1, ch));
        h.addView(text("Simple chart · tap = full screen (indicators khud on kar sakte hain)", 11, MUTED));
        Button an = button("🧠 Analyze " + a.short_ + " — patterns, indicators, plan", YELLOW, INK, 0);
        an.setOnClickListener(v -> openAssetAnalysis(a));
        h.addView(an);
        load[0].run();
        // live price every 15 s
        final Runnable[] tick = new Runnable[1];
        tick[0] = () -> {
            if (infoOverlay != page) return;
            pool.execute(() -> {
                try {
                    final YahooData.Quote q = YahooData.quote(a.sym);
                    runOnUiThread(() -> {
                        if (infoOverlay != page || q.price <= 0) return;
                        pv.setText(Assets.fmt(a, q.price) + "  " + Fmt.pct(q.change) + " ●");
                        pv.setTextColor(q.change >= 0 ? GREEN : RED);
                        Candles cd = cv.getData();
                        if (cd != null && cd.n > 0) {
                            int li = cd.n - 1;
                            cd.close[li] = q.price;
                            cd.high[li] = Math.max(cd.high[li], q.price);
                            cd.low[li] = Math.min(cd.low[li], q.price);
                            cv.liveCandles(cd);
                        }
                    });
                } catch (Exception ignored) {
                }
            });
            handler.postDelayed(tick[0], 15_000);
        };
        handler.postDelayed(tick[0], 15_000);
    }

    /** Full analysis page for a gold / commodity / forex asset. */
    private void openAssetAnalysis(final Assets.Asset a) {
        final LinearLayout col = openPage(a.icon + " " + a.short_ + " · analysis", () -> openAssetChart(a));
        LinearLayout w = card(col, YELLOW);
        w.addView(bold("⏳ " + a.name + " ka analysis ho raha hai...", 15, YELLOW));
        w.addView(text("15m · 1h · 4h · 1d candles, moving averages, patterns, backtest, dollar index, yields aur news jama ho rahe hain. 10–20 second.", 12, MUTED));
        final LinearLayout overlay = infoOverlay;
        pool.execute(() -> {
            try {
                final AssetReport r = AssetReport.build(this, a);
                runOnUiThread(() -> {
                    if (infoOverlay != overlay) return;
                    col.removeAllViews();
                    showAssetReport(col, r);
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> {
                    if (infoOverlay != overlay) return;
                    col.removeAllViews();
                    LinearLayout c = card(col, RED);
                    c.addView(bold("❌ Analysis nahi ho saka", 15, RED));
                    c.addView(text(m == null ? "Internet check karein" : m, 13, SOFT));
                    TextView again = chip("↻ Dobara koshish", true);
                    again.setOnClickListener(v -> openAssetAnalysis(a));
                    c.addView(again);
                });
            }
        });
    }

    private void showAssetReport(final LinearLayout col, final AssetReport r) {
        final Assets.Asset a = r.asset;
        int vc = r.isBuy ? GREEN : RED;
        LinearLayout h = card(col, vc);
        LinearLayout hr = row();
        LinearLayout nm = column();
        nm.addView(bold(a.icon + " " + a.name, 16, TEXT));
        nm.addView(text(a.short_ + " · " + (Assets.FOREX.equals(a.market) ? "Forex" : "Commodity"), 11, MUTED));
        hr.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout pc = column();
        pc.setGravity(Gravity.END);
        final TextView pv = bold(Assets.fmt(a, r.price), 18, TEXT);
        pv.setGravity(Gravity.END);
        pc.addView(pv);
        TextView cv0 = bold(String.format(Locale.US, "%+.2f%% aaj · %+.2f%% hafta", r.change, r.weekChange), 11, r.change >= 0 ? GREEN : RED);
        cv0.setGravity(Gravity.END);
        pc.addView(cv0);
        hr.addView(pc);
        h.addView(hr);
        TextView big = bold((r.isBuy ? "▲ " : "▼ ") + r.verdict, 30, vc);
        big.setGravity(Gravity.CENTER);
        h.addView(big);
        TextView conf = bold("Confidence " + r.confidence + "%  ·  Score " + r.total + "/100", 13, TEXT);
        conf.setGravity(Gravity.CENTER);
        h.addView(conf);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, dp(10));
        clp.topMargin = dp(6);
        clp.bottomMargin = dp(6);
        h.addView(bar(r.confidence, vc, 0xFF243049), clp);
        TextView vt = text(r.verdictText, 14, SOFT);
        vt.setGravity(Gravity.CENTER);
        h.addView(vt);
        TextView rf = chip("↻ Dobara analysis (taaza data)", false);
        rf.setOnClickListener(v -> openAssetAnalysis(a));
        h.addView(rf);
        final TextView fo = chip(Prefs.inFocus(this, a.sym) ? "🎯 Focus list mein hai (hatayen)" : "🎯 Sirf iske signals — focus list mein add", Prefs.inFocus(this, a.sym));
        fo.setOnClickListener(v -> {
            if (Prefs.inFocus(this, a.sym)) Prefs.removeFocus(this, a.sym); else Prefs.addFocus(this, a.sym, a.market, "both");
            boolean in = Prefs.inFocus(this, a.sym);
            fo.setText(in ? "🎯 Focus list mein hai (hatayen)" : "🎯 Sirf iske signals — focus list mein add");
            styleChip(fo, in);
            renderFocus();
            if (in) toast("Signals tab mein 🎯 Focus mode ON karein");
        });
        LinearLayout.LayoutParams fol = new LinearLayout.LayoutParams(-2, -2);
        fol.topMargin = dp(6);
        h.addView(fo, fol);

        // ---- chart
        LinearLayout cc = card(col, ACC);
        cc.addView(bold("📈 Chart · " + a.short_, 15, TEXT));
        final ChartView cv = new ChartView(this);
        cv.setAccent(YELLOW);
        cv.setCompact(true);
        final String[] tfs = {"15m", "1h", "4h", "1d", "1w", "1M", "1Y", "2Y", "5Y", "ALL"};
        final TextView[] tc = new TextView[tfs.length];
        LinearLayout tr = row();
        tr.setPadding(0, dp(6), 0, dp(4));
        for (int i = 0; i < tfs.length; i++) {
            final int ti = i;
            tc[i] = chip(tfs[i], tfs[i].equals("1h"));
            tc[i].setOnClickListener(v -> {
                for (int k = 0; k < tfs.length; k++) styleChip(tc[k], k == ti);
                cv.setMessage(tfs[ti] + " chart load ho raha hai...");
                pool.execute(() -> {
                    try {
                        final Candles c = YahooData.fetch(a.sym, tfs[ti], false);
                        final PatternEngine.Result p = PatternEngine.analyze(c.closedOnly(), Math.min(150, c.n));
                        runOnUiThread(() -> setAssetChart(cv, r, c, p, tfs[ti]));
                    } catch (Exception e) {
                        final String m = e.getMessage();
                        runOnUiThread(() -> cv.setMessage("Chart nahi mila: " + m));
                    }
                });
            });
            tr.addView(tc[i], chipLp());
        }
        TextView fs = chip("⛶ Full screen", true);
        fs.setOnClickListener(v -> openChartFullscreen(cv, a.short_ + " · " + a.name, false));
        tr.addView(fs, chipLp());
        cc.addView(hscroll(tr));
        final String title = a.short_ + " · " + a.name;
        cv.setOnTap(() -> openChartFullscreen(cv, title, false));
        cc.addView(cv, new LinearLayout.LayoutParams(-1, dp(430)));
        cc.addView(text("〰️ EMA ribbon: 🟡9 🔵21 🟣50 🟠100 ⚪200 · ▲▼ = ParaDox rule ke purane signals · ✨ golden / ☠ death cross · "
                + "tap = full screen (indicators, drawing, crosshair)", 11, MUTED));
        if (r.chart != null && r.chart.n > 1) setAssetChart(cv, r, r.chart, r.patterns, "1h");
        // live price: refresh every 15 s while this page is open (Yahoo quote) and move the last candle
        final LinearLayout page = infoOverlay;
        final double[] lastPx = {r.price};
        final Runnable[] tick = new Runnable[1];
        tick[0] = () -> {
            if (infoOverlay != page || page == null) return;
            pool.execute(() -> {
                try {
                    final YahooData.Quote q = YahooData.quote(a.sym);
                    runOnUiThread(() -> {
                        if (infoOverlay != page || q.price <= 0) return;
                        pv.setText(Assets.fmt(a, q.price) + " ●");
                        pv.setTextColor(q.price > lastPx[0] ? GREEN : q.price < lastPx[0] ? RED : TEXT);
                        lastPx[0] = q.price;
                        Candles cd = cv.getData();
                        if (cd != null && cd.n > 0) {
                            int li = cd.n - 1;
                            cd.close[li] = q.price;
                            cd.high[li] = Math.max(cd.high[li], q.price);
                            cd.low[li] = Math.min(cd.low[li], q.price);
                            cv.liveCandles(cd);
                        }
                    });
                } catch (Exception ignored) {
                }
            });
            handler.postDelayed(tick[0], 15_000);
        };
        handler.postDelayed(tick[0], 15_000);

        // ---- plan
        assetPlanCard(col, r);
        paradoxCard(col, r.ma, r.bt, r.bt2, r.ruleSide, r.ruleChecks, r.mtfAgree, "1h", 4);
        arrowLabCard(col, a.sym, true);
        for (CoinReport.Section s : r.sections) sectionCard(col, s);
        scoreBuildCard(col, r.sections, r.total, r.confidence);

        // ---- AI
        LinearLayout ai = card(col, CLAUDE);
        ai.addView(bold("🤖 AI se poochen (Gemini / Groq — FREE)", 15, TEXT));
        final LinearLayout chat = column();
        ai.addView(chat);
        final List<String[]> history = new ArrayList<>();
        TextView full = chip("✨ AI se " + a.short_ + " ka trade plan likhwayen", true);
        full.setBackground(round(CLAUDE, 20, CLAUDE));
        full.setOnClickListener(v -> askClaudeText(r.toText(), chat, history,
                "Is asset ka poora analysis karo: direction, entry, stop-loss, 2 targets, dollar/news ka asar, aur kis cheez se idea ghalat hoga."));
        ai.addView(full);

        LinearLayout act = card(col);
        act.addView(text("⚠️ Yeh analysis maloomat ke liye hai, financial advice nahi. Forex/commodities mein leverage bahut khatarnak ho sakta hai — "
                + "har trade mein stop-loss lagayen aur 1–2% se zyada risk na karein.", 12, MUTED));
    }

    private void setAssetChart(ChartView cv, AssetReport r, Candles c, PatternEngine.Result p, String tf) {
        cv.setTitle(r.asset.short_);
        cv.setData(c, p, new double[c.n], new double[c.n], ChartRange.interval(tf), false);
        cv.setVisible(ChartRange.visible(tf, c.n));
        analysisLayers(cv);
        setScenario(cv, r.advice, r.price);
        cv.setInd("Whales", false);
        cv.setInd("Retail", false);
        cv.setInd("VolProfile", false);
        if (!Assets.COMMODITY.equals(r.asset.market)) cv.setInd("Volume", false);
        if (!cv.ind("MA Ribbon") && !cv.ind("EMA")) cv.setInd("MA Ribbon", true);
        double entry = r.advice != null && r.advice.entry > 0 ? r.advice.entry : r.price;
        cv.setPlan(r.stop > 0, r.isBuy, entry, r.stop, r.target1, r.target2);
        if (r.advice != null && r.advice.zoneHi > 0) cv.setZone(r.advice.zoneLo, r.advice.zoneHi, r.isBuy ? "BUY ZONE" : "SELL ZONE", r.isBuy ? GREEN : RED);
    }

    private void assetPlanCard(LinearLayout col, AssetReport r) {
        Assets.Asset a = r.asset;
        LinearLayout p = card(col, r.isBuy ? GREEN : RED);
        p.addView(bold("🧭 Position plan — " + (r.isBuy ? "BUY (long)" : "SELL (short)"), 16, TEXT));
        if (r.advice != null) {
            p.addView(bold(r.advice.title, 14, r.isBuy ? GREEN : RED));
            p.addView(text(r.advice.why, 13, SOFT));
            if (r.advice.zoneHi > 0) p.addView(text("Entry zone: " + Assets.fmt(a, r.advice.zoneLo) + " – " + Assets.fmt(a, r.advice.zoneHi), 14, TEXT));
        }
        p.addView(text("Support: " + Assets.fmt(a, r.support) + "   ·   Resistance: " + Assets.fmt(a, r.resistance), 13, SOFT));
        if (r.stop > 0) {
            double e = r.advice != null && r.advice.entry > 0 ? r.advice.entry : r.price;
            double pip = Assets.pip(a);
            String pips1 = pip > 0 ? String.format(Locale.US, "  (%.0f pips)", Math.abs(e - r.stop) / pip) : "";
            p.addView(text("🛑 Stop-loss: " + Assets.fmt(a, r.stop) + pctFrom(r.stop, e) + pips1, 14, RED));
            p.addView(text("🎯 TP1: " + Assets.fmt(a, r.target1) + pctFrom(r.target1, e)
                    + (pip > 0 ? String.format(Locale.US, "  (%.0f pips)", Math.abs(r.target1 - e) / pip) : ""), 14, GREEN));
            p.addView(text("🎯 TP2: " + Assets.fmt(a, r.target2) + pctFrom(r.target2, e)
                    + (pip > 0 ? String.format(Locale.US, "  (%.0f pips)", Math.abs(r.target2 - e) / pip) : ""), 14, GREEN));
            p.addView(text("ATR (1h ki ausat harkat): " + Assets.fmt(a, r.atr) + " · stop = 1.5×ATR taa ke aam shor se stop na lage.", 12, MUTED));
        }
        if (!r.events.isEmpty()) {
            p.addView(divider());
            p.addView(bold("📅 Is hafte ki bari news", 13, YELLOW));
            for (String ev : r.events) p.addView(text(ev, 12, SOFT));
        }
        learnToggle(p, "Entry zone = jahan risk kam aur reward zyada ho (support ke paas buy / resistance ke paas sell). "
                + "Stop-loss woh jagah hai jahan aap ka idea ghalat sabit ho jata hai. TP1 par aadha profit lein aur stop entry par le aayen — "
                + "phir trade 'free' ho jata hai. Forex mein pips naapte hain: EURUSD mein 0.0001 = 1 pip.");
    }

    /** Moving-average system + ParaDox rule + backtest, with teaching notes. */
    private void paradoxCard(LinearLayout col, MaSystem.Result ma, ParadoxRule.Backtest bt, ParadoxRule.Backtest bt2, int ruleSide,
                             List<String> checks, int mtf, String tf, int tfCount) {
        if (ma == null) return;
        LinearLayout c = card(col, ruleSide > 0 ? GREEN : ruleSide < 0 ? RED : ACC2);
        c.addView(bold("⚡ ParaDox rule · Moving averages (" + tf + ")", 16, TEXT));
        c.addView(bold(ruleSide > 0 ? "▲ BUY setup abhi bana hai" : ruleSide < 0 ? "▼ SELL setup abhi bana hai" : "Abhi koi taaza setup nahi — intezar behtar",
                14, ruleSide > 0 ? GREEN : ruleSide < 0 ? RED : YELLOW));
        for (String l : ma.lines) c.addView(text("• " + l, 13, SOFT));
        c.addView(divider());
        c.addView(bold("Checklist (aakhri band candle):", 13, TEXT));
        for (String l : checks) c.addView(text(l, 13, l.startsWith("✅") ? GREEN : l.startsWith("❌") ? RED : SOFT));
        c.addView(text("Timeframes agreement: " + (mtf > 0 ? "+" : "") + mtf + " / " + tfCount + (mtf == tfCount ? " — sab bullish ✅" : mtf == -tfCount ? " — sab bearish ✅" : ""), 13, SOFT));
        if (bt != null) {
            c.addView(divider());
            c.addView(bold("📊 Backtest — yahi rule isi chart par pehle", 13, TEXT));
            if (bt.trades == 0) c.addView(text("Is chart par pichle data mein rule ka koi mukammal trade nahi bana.", 12, MUTED));
            else {
                int wc = bt.winRate >= 60 ? GREEN : bt.winRate >= 50 ? YELLOW : RED;
                c.addView(bold(String.format(Locale.US, "TP 1R: %d trades · ✅ %d · ❌ %d · win rate %.0f%% · avg %+.2fR",
                        bt.trades, bt.wins, bt.losses, bt.winRate, bt.avgR), 13, wc));
                if (bt2 != null && bt2.trades > 0)
                    c.addView(text(String.format(Locale.US, "TP 2R: %d trades · win rate %.0f%% · avg %+.2fR", bt2.trades, bt2.winRate, bt2.avgR), 12, SOFT));
                if (!bt.enough()) c.addView(text("⚠️ 5 se kam trades — natija pakka nahi", 12, YELLOW));
            }
        }
        learnToggle(c, "Rule: (1) EMA21 > EMA50 aur price EMA50/200 ke upar = uptrend, (2) EMA9 ne EMA21 ko upar kata ya price EMA21 se uchhli = trigger, "
                + "(3) RSI 50–72 aur MACD positive = momentum, (4) volume average ke barabar ya zyada. SELL is ka ulta.\n\n"
                + "Backtest: bot ne yahi rule pichli candles par chala kar dekha — har trade mein stop 1.5×ATR aur target 1R (ya 2R). "
                + "Agar target pehle laga to WIN, stop pehle to LOSS (ek hi candle mein dono = LOSS, ehtiyatan). "
                + "1R par 50% se zyada aur 2R par 34% se zyada win rate = rule ka faida. Accuracy mode mein kam win rate wale setups ke signal nahi aate.");
    }

    /** "How the final score was built": weighted average of every section. */
    private void scoreBuildCard(LinearLayout col, List<CoinReport.Section> secs, int total, int confidence) {
        LinearLayout c = card(col, ACC);
        c.addView(bold("🧠 Final score kaise bana?", 15, TEXT));
        double ws = 0;
        for (CoinReport.Section s : secs) if (s.available) ws += s.weight;
        for (CoinReport.Section s : secs) {
            if (!s.available || ws <= 0) continue;
            double share = s.score * s.weight / ws / 2;
            LinearLayout r = row();
            r.addView(text(s.icon + " " + s.title, 12, SOFT), new LinearLayout.LayoutParams(0, -2, 1));
            r.addView(bold(String.format(Locale.US, "%+d × %d%% = %+.1f", s.score, Math.round(s.weight * 100 / ws), share), 12,
                    share > 0.5 ? GREEN : share < -0.5 ? RED : MUTED));
            c.addView(r);
        }
        c.addView(divider());
        c.addView(bold("50 + sab ka jor = " + total + "/100 → " + (total >= 50 ? "BUY" : "SELL") + " · confidence " + confidence + "%", 13, total >= 50 ? GREEN : RED));
        learnToggle(c, "Har section −100 (poora bearish) se +100 (poora bullish) score deta hai. Har ek ka wazan (weight) alag hai — "
                + "technical aur volume zyada ahem, sentiment kam. Wazni ausat ko aadha karke 50 mein jora jata hai: 50 se upar BUY, neeche SELL. "
                + "Confidence = 50 se kitna door (×2.5). Signal tabhi bhejta hai jab score 62+ (BUY) ya 38− (SELL) ho.");
    }

    /** Expandable "📖 Seekhein" teaching note. */
    private void learnToggle(LinearLayout parent, final String tip) {
        final TextView body = text(tip, 12, 0xFFB8C2D3);
        body.setPadding(dp(10), dp(8), dp(10), dp(8));
        body.setBackground(round(0x1422D3EE, 10, 0x3322D3EE));
        body.setVisibility(View.GONE);
        final TextView t = bold("📖 Seekhein ▾", 12, CYAN_TXT);
        t.setPadding(0, dp(8), 0, dp(4));
        t.setOnClickListener(v -> {
            boolean open = body.getVisibility() != View.VISIBLE;
            body.setVisibility(open ? View.VISIBLE : View.GONE);
            t.setText(open ? "📖 Seekhein ▴" : "📖 Seekhein ▾");
        });
        parent.addView(t);
        parent.addView(body);
    }

    /** Signal screen: "how this signal was built" step by step. */
    private void signalLearnCard(LinearLayout c, JSONObject o, boolean buy) {
        JSONArray ch = o.optJSONArray("checks");
        LinearLayout k = card(c, CYAN_TXT);
        k.addView(bold("🧠 Yeh signal kaise bana?", 16, TEXT));
        if (ch == null || ch.length() == 0) {
            k.addView(text("Yeh purane version ka signal hai — tafseel mehfooz nahi. Naye signals mein har check dikhega.", 12, MUTED));
            return;
        }
        k.addView(text("Bot ne yeh sab cheezein check kin — ✅ = " + (buy ? "BUY" : "SELL") + " ke haq mein, ❌ = khilaf, ➖ = neutral:", 12, MUTED));
        for (int i = 0; i < ch.length(); i++) {
            String l = ch.optString(i);
            k.addView(text(l, 13, l.startsWith("✅") ? GREEN : l.startsWith("❌") ? RED : l.trim().startsWith("✅") ? GREEN : l.trim().startsWith("❌") ? RED : SOFT));
        }
        if (o.has("wr")) k.addView(bold("📊 Is rule ka backtest win rate: " + o.optInt("wr") + "% (" + o.optInt("bt") + " trades)", 13, ACC2));
        JSONArray secs = o.optJSONArray("secs");
        if (secs != null && secs.length() > 0) {
            k.addView(divider());
            k.addView(bold("Score mein har source ka hissa:", 12, TEXT));
            for (int i = 0; i < secs.length(); i++) {
                JSONObject s = secs.optJSONObject(i);
                if (s == null) continue;
                int sc = s.optInt("s");
                LinearLayout r = row();
                r.addView(text(s.optString("i") + " " + s.optString("t"), 12, SOFT), new LinearLayout.LayoutParams(0, -2, 1));
                r.addView(bold((sc > 0 ? "+" : "") + sc, 12, sc > 15 ? GREEN : sc < -15 ? RED : YELLOW));
                k.addView(r);
            }
        }
        learnToggle(k, "Signal 3 marhalon mein banta hai: (1) tez scan — volume, RSI, MACD aur whales ka basic score; "
                + "(2) all-source confirmation — 10 exchanges ka volume, futures, ETF, news, patterns, moving averages sab ka wazni score 62+ (BUY) / 38− (SELL); "
                + "(3) accuracy mode — ParaDox rule ka backtest win rate, timeframes aur MA trend ek taraf. Teeno paas hon to hi notification aati hai.");
    }

    private void askClaudeText(final String data, final LinearLayout chat, final List<String[]> history, String question) {
        askAi(data, chat, history, question);
    }

    // ============================================================ v12: LIVE CRYPTO NEWS
    private static String ago(long t) {
        long s = Math.max(0, (System.currentTimeMillis() - t) / 1000);
        if (s < 60) return s + " sec pehle";
        if (s < 3600) return (s / 60) + " min pehle";
        if (s < 86400) return (s / 3600) + " ghante pehle";
        return (s / 86400) + " din pehle";
    }

    private final Runnable newsTick = new Runnable() {
        @Override
        public void run() {
            if (infoOverlay == null || infoOverlay != newsOverlayRef) return;
            loadNews(false);
            handler.postDelayed(this, 20_000);
        }
    };

    private void openNews() {
        LinearLayout col = openPage("📰 Crypto News · LIVE");
        newsOverlayRef = infoOverlay;

        LinearLayout top = card(col, ACC);
        LinearLayout tr = row();
        tr.addView(bold("🛰️ News radar", 16, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        final TextView rf = chip("↻", false);
        rf.setOnClickListener(v -> loadNews(true));
        tr.addView(rf);
        top.addView(tr);
        top.addView(text(NewsEngine.sourceCount() + " sources: Cointelegraph, CoinDesk, The Block, Decrypt, Blockworks, Watcher.Guru, BNO News, AMBCrypto, "
                + "Blockchain.News, CryptoTicker, FinanceFeeds, investingLive, FXStreet, Cyber Kendra, DL News, Protos, BeInCrypto… · Google News se Reuters, "
                + "Bloomberg, CNBC, Yahoo Finance, TradingView, Bloomingbit, StreetInsider, Hindustan Times · Binance listing/delisting · "
                + "X (Twitter) ki ahem posts · CryptoPanic (Settings mein free token). Tez sources har 15 sec, baqi har 4 min. "
                + "Ek hi khabar kayi jagah ho to ek saath '+N sources'.", 11, MUTED));
        toggle(top, "🔔 Background radar + notifications", "Har 1 minute mein sab sources check · bari khabar par foran notification",
                Prefs.newsOn(this), (b, on) -> {
                    Prefs.setNewsOn(this, on);
                    if (on) startForegroundService(new Intent(this, ScannerService.class));
                    else if (!Prefs.enabled(this)) startService(new Intent(this, ScannerService.class).setAction(ScannerService.ACTION_STOP));
                    toast(on ? "News radar ON ✅" : "News radar OFF");
                });
        LinearLayout sv = row();
        sv.addView(text("Notification:", 12, SOFT), chipLp());
        final String[] sn = {"Sab", "Important+", "Sirf Critical"};
        final TextView[] sc = new TextView[3];
        for (int i = 0; i < 3; i++) {
            final int lv = i + 1;
            sc[i] = chip(sn[i], Prefs.newsMinSev(this) == lv);
            sc[i].setTextSize(11);
            sc[i].setOnClickListener(v -> {
                Prefs.setNewsMinSev(this, lv);
                for (int k = 0; k < 3; k++) styleChip(sc[k], k == lv - 1);
            });
            sv.addView(sc[i], chipLp());
        }
        top.addView(hscroll(sv));
        newsStatus = text("Load ho raha hai...", 11, ACC2);
        top.addView(newsStatus);

        LinearLayout fc = card(col);
        final EditText q = input("🔎 Coin ya lafz (BTC, Binance, hack, ETF...)", newsQuery, InputType.TYPE_CLASS_TEXT);
        q.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { newsQuery = s.toString().trim(); renderNews(); }
        });
        fc.addView(q);
        LinearLayout fr = row();
        final String[] fn = {"Sab", "🚨 Critical", "🟢 Bullish", "🔴 Bearish", "🐦 X / Social", "🏛️ Macro", "🆕 Listing/Delist", "🚨 Hacks"};
        final TextView[] fcs = new TextView[fn.length];
        for (int i = 0; i < fn.length; i++) {
            final int fi = i;
            fcs[i] = chip(fn[i], i == newsFilter);
            fcs[i].setTextSize(11);
            fcs[i].setOnClickListener(v -> {
                newsFilter = fi;
                for (int k = 0; k < fn.length; k++) styleChip(fcs[k], k == fi);
                renderNews();
            });
            fr.addView(fcs[i], chipLp());
        }
        fc.addView(hscroll(fr));
        newsList = column();
        col.addView(newsList);
        renderNews();
        loadNews(false);
        handler.removeCallbacks(newsTick);
        handler.postDelayed(newsTick, 20_000);
    }

    private void loadNews(final boolean force) {
        if (newsStatus != null) newsStatus.setText("⏳ Sab sources check ho rahe hain...");
        pool.execute(() -> {
            NewsEngine.fetch(this, force ? 0 : 15_000L);
            runOnUiThread(() -> {
                if (newsStatus != null) newsStatus.setText("● LIVE · " + NewsEngine.status() + " · har 20 sec auto-refresh");
                renderNews();
            });
        });
    }

    private boolean newsMatch(NewsEngine.Item it) {
        switch (newsFilter) {
            case 1: if (it.severity < 3) return false; break;
            case 2: if (it.dir <= 0) return false; break;
            case 3: if (it.dir >= 0) return false; break;
            case 4: if (!it.social) return false; break;
            case 5: if (!it.macro) return false; break;
            case 6: if (!it.catKey.equals("list") && !it.catKey.equals("delist")) return false; break;
            case 7: if (!it.catKey.equals("hack") && !it.catKey.equals("halt")) return false; break;
            default: break;
        }
        if (!newsQuery.isEmpty()) {
            String ql = newsQuery.toLowerCase(Locale.US);
            if (!it.title.toLowerCase(Locale.US).contains(ql) && !it.coins.contains(newsQuery.toUpperCase(Locale.US))) return false;
        }
        return true;
    }

    private void renderNews() {
        if (newsList == null) return;
        newsList.removeAllViews();
        List<NewsEngine.Item> l = NewsEngine.cached();
        int shown = 0;
        for (final NewsEngine.Item it : l) {
            if (!newsMatch(it)) continue;
            if (shown++ >= 80) break;
            int col = it.dir > 0 ? GREEN : it.dir < 0 ? RED : (it.severity >= 2 ? YELLOW : STROKE);
            LinearLayout c = card(newsList, it.severity >= 3 ? col : STROKE);
            LinearLayout h = row();
            TextView cat = bold(it.category, 10, INK);
            cat.setPadding(dp(6), dp(2), dp(6), dp(2));
            cat.setBackground(round(it.dir > 0 ? GREEN : it.dir < 0 ? RED : (it.severity >= 2 ? YELLOW : 0xFF8B95A7), 8, 0));
            h.addView(cat);
            TextView tm = text("  " + ago(it.time) + " · " + it.source + (it.sources.size() > 1 ? " +" + (it.sources.size() - 1) : ""), 10, MUTED);
            h.addView(tm, new LinearLayout.LayoutParams(0, -2, 1));
            if (it.severity >= 3) h.addView(bold("🚨", 13, RED));
            c.addView(h);
            TextView t = bold(it.title, 14, TEXT);
            t.setPadding(0, dp(4), 0, dp(2));
            c.addView(t);
            c.addView(text(NewsEngine.dirLabel(it) + " · " + NewsEngine.trim(it.impact, 130), 12, it.dir > 0 ? GREEN : it.dir < 0 ? RED : SOFT));
            if (!it.coins.isEmpty() || !it.exchanges.isEmpty()) {
                LinearLayout cr = row();
                for (final String co : it.coins) {
                    TextView cc = chip(co, false);
                    cc.setTextSize(10);
                    cc.setPadding(dp(8), dp(3), dp(8), dp(3));
                    cc.setOnClickListener(v -> { closeInfo(); openAnalyze(co + "USDT"); });
                    cr.addView(cc, chipLp());
                }
                for (String ex : it.exchanges) cr.addView(text("🏦 " + ex + "  ", 10, MUTED));
                c.addView(hscroll(cr));
            }
            c.setOnClickListener(v -> openNewsDetail(it));
        }
        if (shown == 0) newsList.addView(text(l.isEmpty() ? "\nKhabrein load ho rahi hain... (internet check karein)" : "\nIs filter mein koi khabar nahi", 13, MUTED));
    }

    private void openNewsDetail(final NewsEngine.Item it) {
        handler.removeCallbacks(newsTick);
        LinearLayout col = openPage("📰 Khabar", this::openNews);
        int dc = it.dir > 0 ? GREEN : it.dir < 0 ? RED : YELLOW;
        LinearLayout h = card(col, dc);
        LinearLayout br = row();
        TextView cat = bold(it.category, 11, INK);
        cat.setPadding(dp(7), dp(3), dp(7), dp(3));
        cat.setBackground(round(dc, 8, 0));
        br.addView(cat, chipLp());
        br.addView(bold(NewsEngine.sevLabel(it), 12, it.severity >= 3 ? RED : it.severity == 2 ? YELLOW : MUTED));
        h.addView(br);
        TextView t = bold(it.title, 17, TEXT);
        t.setTextIsSelectable(true);
        t.setPadding(0, dp(6), 0, dp(4));
        h.addView(t);
        h.addView(text(MacroEngine.pkt(it.time) + " PKT · " + ago(it.time) + " · " + it.source, 11, MUTED));
        if (!it.summary.isEmpty()) h.addView(text(it.summary, 13, SOFT));

        LinearLayout a = card(col, CYAN_TXT);
        a.addView(bold("🧠 Bot ka analysis", 16, TEXT));
        a.addView(bold("Asar: " + NewsEngine.dirLabel(it) + " · " + NewsEngine.sevLabel(it), 14, dc));
        if (!it.coins.isEmpty()) a.addView(text("🪙 Coins: " + String.join(", ", it.coins), 13, TEXT));
        if (!it.exchanges.isEmpty()) a.addView(text("🏦 Exchanges: " + String.join(", ", it.exchanges), 13, TEXT));
        a.addView(bold("📌 Is se kya ho sakta hai?", 13, YELLOW));
        a.addView(text(it.impact, 13, SOFT));
        a.addView(bold("👉 Kya karein?", 13, GREEN));
        a.addView(text(it.action, 13, SOFT));
        learnToggle(a, "Khabar parhne ka tareeqa: (1) Source kitne hain? Kayi bare outlets = sachi bari khabar; sirf ek X post = afwah bhi ho sakti hai. "
                + "(2) Khabar kab aayi aur price pehle hi kitna hil chuki? Neeche 'asal asar' dekhein. (3) 'Buy the rumor, sell the news' — achhi khabar ke din bhi "
                + "price gir sakti hai. (4) Hack, delisting, depeg sab se khatarnak — inhein kabhi nazar-andaz na karein. "
                + "Bot ki raaye keywords par mabni hai — hamesha asal khabar khud parhein.");

        LinearLayout s = card(col);
        s.addView(bold("📡 Kahan kahan report hui (" + it.sources.size() + ")", 15, TEXT));
        for (final String[] so : it.sources) {
            TextView st = text("🔗 " + so[0], 13, CYAN_TXT);
            st.setPadding(0, dp(5), 0, dp(5));
            st.setOnClickListener(v -> openUrl(so[1]));
            s.addView(st);
        }

        // ---- price reaction + chart around the news time
        String coin = null;
        for (String c0 : it.coins) if (!c0.equals("USDT") && !c0.equals("USDC") && (NewsEngine.KNOWN.isEmpty() || NewsEngine.KNOWN.contains(c0))) { coin = c0; break; }
        if (coin == null && it.exchanges.contains("Binance")) coin = "BNB";
        if (coin == null) coin = "BTC";
        final String fc = coin;
        LinearLayout r = card(col, ACC);
        r.addView(bold("📊 Asal asar — " + fc + " ki price khabar ke baad", 15, TEXT));
        final TextView rt = text("Load ho raha hai...", 13, SOFT);
        r.addView(rt);
        final ChartView cv = new ChartView(this);
        cv.setAccent(ACC);
        cv.setCompact(true);
        cv.setMessage("Chart load ho raha hai...");
        cv.setOnTap(() -> openChartFullscreen(cv, fc + "/USDT · news", false));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, dp(340));
        cl.topMargin = dp(8);
        r.addView(cv, cl);
        r.addView(text("Peeli line = khabar ka waqt · tap = full screen", 11, MUTED));
        Button an = button("📈 " + fc + " ka poora analysis", ACC, INK, 0);
        an.setOnClickListener(v -> { closeInfo(); openAnalyze(fc + "USDT"); });
        r.addView(an);
        pool.execute(() -> {
            try {
                final double[] re = NewsEngine.reaction(fc, it.time);
                long age = System.currentTimeMillis() - it.time;
                String iv = age < 4 * 3600_000L ? "1m" : age < 20 * 3600_000L ? "5m" : age < 3 * 86_400_000L ? "15m" : "1h";
                long step = ChartView.tfMillis(iv);
                final Candles c = Candles.parse(Scanner.get("/api/v3/klines?symbol=" + fc + "USDT&interval=" + iv
                        + "&startTime=" + (it.time - 60 * step) + "&limit=1000"), false);
                final String fiv = iv;
                runOnUiThread(() -> {
                    StringBuilder b = new StringBuilder();
                    b.append("Khabar ke waqt price: $").append(Fmt.price(re[0])).append('\n');
                    String[] lb = {"5 min baad", "15 min baad", "1 ghanta baad", "Ab tak"};
                    for (int k = 0; k < 4; k++)
                        b.append(lb[k]).append(": ").append(Double.isNaN(re[k + 1]) ? "abhi waqt nahi guzra" : Fmt.pct(re[k + 1])).append('\n');
                    double now = re[4];
                    b.append(Double.isNaN(now) ? "" : (it.dir != 0 && Math.signum(now) == it.dir && Math.abs(now) > 0.5
                            ? "✅ Market ne khabar ke mutabiq react kiya" : Math.abs(now) <= 0.5 ? "➖ Market par abhi khaas asar nahi"
                            : "⚠️ Market ne khabar ke ulat react kiya (pehle se price mein shamil thi?)"));
                    rt.setText(b.toString().trim());
                    if (c.n > 1) {
                        cv.setTitle(fc + "/USDT");
                        cv.setData(c, null, new double[c.n], new double[c.n], fiv, false);
                        for (String k2 : new String[]{"Fib", "Zones", "VolProfile", "Whales", "Retail", "RSI", "MACD", "BB", "EMA200", "VWAP", "Patterns", "ParaDox"}) cv.setInd(k2, false);
                        cv.setInd("EMA", true);
                        cv.setInd("Volume", true);
                        cv.setVisible(c.n);
                        cv.setEvent(it.time, "📰 News");
                    }
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> {
                    rt.setText(fc + " ka Binance data nahi mila (" + m + ")");
                    cv.setMessage("Chart nahi mila");
                });
            }
        });
        readerSection(col, it.link, it.title, it.coins);
        TextView o = chip("🌐 Asal website kholen", false);
        o.setOnClickListener(v -> openUrl(it.link));
        LinearLayout.LayoutParams ol = new LinearLayout.LayoutParams(-1, -2);
        ol.topMargin = dp(12);
        col.addView(o, ol);
    }

    // ============================================================ v16: CATALYST RADAR
    private int catFilter = 0;
    private LinearLayout catList;
    private TextView catStatus;

    private static String until(long t) {
        long d = t - System.currentTimeMillis();
        if (d <= 0) return "abhi / ho chuka";
        long m = d / 60_000L;
        if (m < 60) return m + " min baad";
        if (m < 48 * 60) return (m / 60) + " ghante baad";
        return (m / 1440) + " din baad";
    }

    private void openCatalysts() {
        LinearLayout col = openPage("📆 Catalyst Radar");
        LinearLayout top = card(col, ACC);
        top.addView(bold("Aane wale events — pehle se pata, pehle se tayyar", 15, TEXT));
        top.addView(text("Sirf PUBLIC aur legal sources: DefiLlama (token unlocks), Binance (listing · delisting · Launchpool · airdrop), "
                + "news mein di gayi tareekhein (mainnet, TGE, ETF deadline), US macro calendar, Polymarket ke odds (log asal paisa laga kar kya "
                + "umeed rakh rahe hain), Binance futures mein positions ka jama hona. CoinMarketCal ka free key Settings mein daalein to aur events.\n"
                + "⚠️ Asal 'insider' maloomat koi free/legal jagah nahi deti — aise dawe aksar scam hote hain.", 11, MUTED));
        toggle(top, "🔔 Event reminders", "Bare event se 24 ghante aur 1 ghanta pehle notification", Prefs.notifOn(this, Prefs.N_CATALYST),
                (b, on) -> Prefs.setNotif(this, Prefs.N_CATALYST, on));
        catStatus = text("Load ho raha hai...", 11, ACC2);
        top.addView(catStatus);
        LinearLayout fr = row();
        final String[] fn = {"Sab", "🔓 Unlocks", "🆕 Listings", "📤 Delist", "🚀 Launch/Airdrop", "🏛️ Macro/ETF", "🎲 Polymarket", "📊 Futures", "✅ US data results"};
        final TextView[] fc = new TextView[fn.length];
        for (int i = 0; i < fn.length; i++) {
            final int fi = i;
            fc[i] = chip(fn[i], i == catFilter);
            fc[i].setTextSize(11);
            fc[i].setOnClickListener(v -> {
                catFilter = fi;
                for (int k = 0; k < fn.length; k++) styleChip(fc[k], k == fi);
                renderCatalysts();
            });
            fr.addView(fc[i], chipLp());
        }
        LinearLayout fcCard = card(col);
        fcCard.addView(hscroll(fr));
        catList = column();
        col.addView(catList);
        renderCatalysts();
        pool.execute(() -> {
            CatalystEngine.fetch(this, 10 * 60_000L);
            runOnUiThread(() -> {
                if (catStatus != null) catStatus.setText("● " + CatalystEngine.status());
                renderCatalysts();
            });
        });
    }

    /** v34: US data that has ALREADY come out — actual vs forecast, verdict, BTC reaction; tap = full report. */
    private void renderMacroResults(final LinearLayout box) {
        box.addView(text("✅ Jo US data aa chuka — asal number, forecast, faisla aur BTC ka react. Naya data aate hi yahan aata hai (aur notification). Tap = poori report.", 12, MUTED));
        final LinearLayout l = column();
        box.addView(l);
        l.addView(text("Load ho raha hai...", 12, MUTED));
        pool.execute(() -> {
            final List<MacroEngine.Event> r = MacroEngine.released(this, 30);
            runOnUiThread(() -> {
                l.removeAllViews();
                if (r.isEmpty()) { l.addView(text("Pichle 30 din ka koi high-impact data nahi mila.", 13, MUTED)); return; }
                for (final MacroEngine.Event e : r) macroResultCard(l, e);
            });
        });
    }

    private void macroResultCard(LinearLayout parent, final MacroEngine.Event e) {
        int col = e.verdictSign > 0 ? GREEN : e.verdictSign < 0 ? RED : e.actual.isEmpty() ? STROKE : YELLOW;
        LinearLayout c = card(parent, col);
        LinearLayout h = row();
        h.addView(bold("🇺🇸 " + e.title, 14, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        h.addView(text(MacroEngine.pkt(e.time), 10, MUTED));
        c.addView(h);
        c.addView(bold("Asal: " + (e.actual.isEmpty() ? "⏳ aana baqi / feed mein nahi" : e.actual) + "   ·   Forecast: " + (e.forecast.isEmpty() ? "—" : e.forecast)
                + "   ·   Pichla: " + (e.previous.isEmpty() ? "—" : e.previous), 13, e.actual.isEmpty() ? SOFT : TEXT));
        if (!e.verdict.isEmpty()) c.addView(text(e.verdict, 12, col));
        if (!Double.isNaN(e.reaction)) c.addView(bold(String.format(Locale.US, "📊 BTC release ke 5 min mein: %+.2f%%", e.reaction), 12, e.reaction >= 0 ? GREEN : RED));
        c.setOnClickListener(v -> openEventReport("🏛️ US macro", e.title, e.time, "Economic calendar", e.expectation, "", e.verdictSign, 3, new ArrayList<>(), "", false, false, "", null));
    }

    private boolean catMatch(CatalystEngine.Event e) {
        switch (catFilter) {
            case 1: return e.type.equals(CatalystEngine.UNLOCK);
            case 2: return e.type.equals(CatalystEngine.LISTING);
            case 3: return e.type.equals(CatalystEngine.DELIST);
            case 4: return e.type.equals(CatalystEngine.LAUNCH) || e.type.equals(CatalystEngine.AIRDROP) || e.type.equals(CatalystEngine.EVENT);
            case 5: return e.type.equals(CatalystEngine.MACRO) || e.type.equals(CatalystEngine.ETF);
            case 6: return e.type.equals(CatalystEngine.ODDS);
            case 7: return e.type.equals(CatalystEngine.OI);
            default: return true;
        }
    }

    private void renderCatalysts() {
        if (catList == null) return;
        catList.removeAllViews();
        if (catFilter == 8) { renderMacroResults(catList); return; }
        List<CatalystEngine.Event> l = CatalystEngine.cached();
        // live signals (odds / futures) first, then by date
        List<CatalystEngine.Event> live = new ArrayList<>(), sched = new ArrayList<>();
        for (CatalystEngine.Event e : l) {
            if (!catMatch(e)) continue;
            if (e.type.equals(CatalystEngine.ODDS) || e.type.equals(CatalystEngine.OI)) live.add(e); else sched.add(e);
        }
        if (!live.isEmpty()) {
            TextView h = bold("⚡ ABHI KE ISHARE", 11, MUTED);
            h.setLetterSpacing(0.12f);
            h.setPadding(dp(4), dp(14), 0, 0);
            catList.addView(h);
            for (CatalystEngine.Event e : live) catalystRow(e);
        }
        String lastDay = "";
        SimpleDateFormat df = new SimpleDateFormat("EEEE, dd MMM", Locale.US);
        df.setTimeZone(java.util.TimeZone.getTimeZone("Asia/Karachi"));
        for (CatalystEngine.Event e : sched) {
            String day = df.format(new Date(e.time));
            if (!day.equals(lastDay)) {
                lastDay = day;
                TextView h = bold(day.toUpperCase(Locale.US), 11, MUTED);
                h.setLetterSpacing(0.12f);
                h.setPadding(dp(4), dp(14), 0, 0);
                catList.addView(h);
            }
            catalystRow(e);
        }
        if (live.isEmpty() && sched.isEmpty())
            catList.addView(text(l.isEmpty() ? "\nEvents load ho rahe hain..." : "\nIs filter mein koi event nahi", 13, MUTED));
    }

    private void catalystRow(final CatalystEngine.Event e) {
        int col = e.dir > 0 ? GREEN : e.dir < 0 ? RED : YELLOW;
        LinearLayout c = card(catList, e.severity >= 3 ? col : STROKE);
        LinearLayout h = row();
        TextView b = bold(e.icon() + " " + CatalystEngine.label(e), 10, INK);
        b.setPadding(dp(6), dp(2), dp(6), dp(2));
        b.setBackground(round(col, 8, 0));
        h.addView(b);
        boolean detected = e.type.equals(CatalystEngine.ODDS) || e.type.equals(CatalystEngine.OI);
        h.addView(text("  " + (detected ? ago(e.time) : MacroEngine.pkt(e.time) + " · " + until(e.time)) + (e.estimated ? " · andaza" : ""), 10, MUTED),
                new LinearLayout.LayoutParams(0, -2, 1));
        if (e.severity >= 3) h.addView(bold("🔥", 12, col));
        c.addView(h);
        TextView t = bold(e.title, 14, TEXT);
        t.setPadding(0, dp(4), 0, dp(2));
        c.addView(t);
        c.addView(text((e.dir > 0 ? "🟢 BULLISH · " : e.dir < 0 ? "🔴 BEARISH · " : "⚪ ") + NewsEngine.trim(e.impact, 140), 12, e.dir > 0 ? GREEN : e.dir < 0 ? RED : SOFT));
        if (!e.coins.isEmpty()) {
            LinearLayout cr = row();
            for (final String co : e.coins) {
                TextView cc = chip(co, false);
                cc.setTextSize(10);
                cc.setPadding(dp(8), dp(3), dp(8), dp(3));
                cc.setOnClickListener(v -> { closeInfo(); openAnalyze(co + "USDT"); });
                cr.addView(cc, chipLp());
            }
            c.addView(hscroll(cr));
        }
        c.setOnClickListener(v -> openCatalystDetail(e));
    }

    private void openCatalystDetail(final CatalystEngine.Event e) {
        boolean detected = e.type.equals(CatalystEngine.ODDS) || e.type.equals(CatalystEngine.OI);
        String coin = e.coins.isEmpty() ? null : e.coins.get(0);
        eventFromCatalysts = true;
        openEventReport(e.icon() + " " + CatalystEngine.label(e), e.title, e.time, e.source, e.impact, e.action, e.dir, e.severity, e.coins, e.link, detected, e.estimated,
                e.usd > 0 ? "Size: " + Fmt.usd(e.usd) + (e.pctMcap > 0 ? String.format(Locale.US, " (%.2f%% market cap)", e.pctMcap) : "") : "", coin);
    }

    private boolean eventFromCatalysts;

    /** "2 din 03:14:22" · "03:14:22" · "00:59" */
    static String clock(long ms) {
        long s = Math.max(0, ms / 1000);
        long dd = s / 86400, h = (s % 86400) / 3600, m = (s % 3600) / 60, sec = s % 60;
        if (dd > 0) return String.format(Locale.US, "%d din %02d:%02d:%02d", dd, h, m, sec);
        if (h > 0) return String.format(Locale.US, "%02d:%02d:%02d", h, m, sec);
        return String.format(Locale.US, "%02d:%02d", m, sec);
    }

    /**
     * v31: professional event page — live second-by-second countdown, what the event is and what each outcome means,
     * then after release the FINAL REPORT: actual number, real market reaction (BTC, ETH, gold, dollar, stocks, yields)
     * and the headlines about it from many sources, refreshed every minute.
     */
    private void openEventReport(String label, final String title, final long time, String source, String impact, String action, int dir, int severity,
                                 final List<String> coins, final String link, final boolean detected, boolean estimated, String sizeLine, final String coin) {
        final boolean fromCat = eventFromCatalysts;   // v38 fix: back returns to where the report was opened from
        eventFromCatalysts = false;
        LinearLayout col = fromCat ? openPage(label, this::openCatalysts) : openPage(label);
        final LinearLayout page = infoOverlay;
        int dc = dir > 0 ? GREEN : dir < 0 ? RED : YELLOW;
        final MacroEngine.Event me = EventReport.macro(this, title, time);

        LinearLayout h = card(col, dc);
        TextView t = bold(me != null ? "🇺🇸 " + me.title : title, 18, TEXT);
        t.setTextIsSelectable(true);
        h.addView(t);
        h.addView(bold((detected ? "Pata chala: " + ago(time) : "📅 " + MacroEngine.pkt(time) + " PKT") + (estimated ? " (tareekh andaza)" : ""), 13, YELLOW));
        h.addView(text("Source: " + source + (severity >= 3 ? " · 🔥 Bara asar" : severity == 2 ? " · Darmiyana asar" : ""), 12, MUTED));
        if (!sizeLine.isEmpty()) h.addView(text(sizeLine, 13, TEXT));
        final TextView cd = bold("", 30, TEXT), cdSub = text("", 12, MUTED);
        if (!detected) {
            cd.setPadding(0, dp(8), 0, 0);
            h.addView(cd);
            h.addView(cdSub);
        }

        // ---- what it is + what each outcome means
        LinearLayout a = card(col, CYAN_TXT);
        a.addView(bold("📋 Yeh kya hai aur kya ho sakta hai", 16, TEXT));
        if (me != null && me.info != null) {
            a.addView(text(me.info.what, 13, SOFT));
            if (!me.forecast.isEmpty() || !me.previous.isEmpty())
                a.addView(bold("Forecast: " + (me.forecast.isEmpty() ? "—" : me.forecast) + "   ·   Pichla: " + (me.previous.isEmpty() ? "—" : me.previous), 14, TEXT));
            a.addView(text(me.expectation, 13, YELLOW));
            a.addView(bold("📈 Agar ZYADA aaya:", 13, TEXT));
            a.addView(text(me.info.ifHigher, 13, SOFT));
            a.addView(bold("📉 Agar KAM aaya:", 13, TEXT));
            a.addView(text(me.info.ifLower, 13, SOFT));
        } else {
            a.addView(bold("Asar: " + (dir > 0 ? "🟢 BULLISH" : dir < 0 ? "🔴 BEARISH" : "⚪ Direction pehle se pakki nahi — nateeje par depend"), 14, dc));
            if (impact != null && !impact.isEmpty()) a.addView(text(impact, 13, SOFT));
        }
        String tl = title.toLowerCase(Locale.US);
        if (tl.contains("election") || tl.contains("congress"))
            a.addView(text("🗳️ US elections: nateeje raat bhar aate hain. Market dekhti hai ke Congress kis party ke paas gaya — tax, spending, crypto qanoon (stablecoin / "
                    + "market structure bills) aur SEC ki policy par asar. Ghair-yaqeeni ke waqt volatility zyada; saaf nateeje ke baad trend banta hai.", 12, SOFT));
        if (action != null && !action.isEmpty()) {
            a.addView(bold("👉 Release se pehle kya karein?", 13, GREEN));
            a.addView(text(action, 13, SOFT));
        } else a.addView(text("👉 Release se ±30 min naya trade na lein (bot is waqt signals rok deta hai). Open trades par stop lagayen.", 13, SOFT));

        // ---- v34: 1-year record of this indicator (FRED)
        if (me != null && me.info != null && me.info.fred != null) {
            final LinearLayout hc = card(col, YELLOW);
            hc.addView(bold("📜 Pichle 12 releases ka record (1 saal)", 15, TEXT));
            final LinearLayout hb = column();
            hc.addView(hb);
            hb.addView(text("Load ho raha hai (FRED · St. Louis Fed)...", 12, MUTED));
            pool.execute(() -> {
                final List<String[]> hist = MacroEngine.history(me.info, 12);
                runOnUiThread(() -> {
                    if (infoOverlay != page) return;
                    hb.removeAllViews();
                    if (hist.isEmpty()) { hb.addView(text("Record nahi mila (internet / FRED).", 12, MUTED)); return; }
                    for (int i = 0; i < hist.size(); i++) {   // newest first
                        String[] h2 = hist.get(i);
                        double v = MacroEngine.num(h2[1]), prevV = i + 1 < hist.size() ? MacroEngine.num(hist.get(i + 1)[1]) : Double.NaN;
                        String arrow = Double.isNaN(prevV) || Double.isNaN(v) ? "  " : v > prevV ? "▲ " : v < prevV ? "▼ " : "= ";
                        LinearLayout rw = row();
                        rw.addView(text(h2[0], 12, MUTED), new LinearLayout.LayoutParams(0, -2, 1));
                        rw.addView(bold(arrow + h2[1], 13, arrow.startsWith("▲") ? GREEN : arrow.startsWith("▼") ? RED : TEXT));
                        hb.addView(rw);
                    }
                    hb.addView(text("Sab se upar = sab se naya. ▲▼ = pichle mahine se zyada / kam. Trend dekh kar andaza: number barh raha hai ya ghat raha.", 11, MUTED));
                });
            });
        }

        // ---- final report (after release)
        final LinearLayout rep = card(col, ACC);
        rep.addView(bold("🧾 Final report", 16, TEXT));
        final LinearLayout repBody = column();
        rep.addView(repBody);
        repBody.addView(text(detected || time <= System.currentTimeMillis() ? "Report ban rahi hai — number, market ka asar aur khabrein jama ho rahi hain..."
                : "Release ke baad yahan asal nateeja aayega: number (forecast vs actual), BTC · ETH · Gold · Dollar · US stocks · yields ka asal asar (15 min, 1 ghanta, ab), "
                + "aur har jagah ki khabrein — phir final faisla.", 13, MUTED));

        if (!coins.isEmpty()) {
            for (final String co : coins) {
                Button an = button("📈 " + co + " ka analysis", ACC, INK, 0);
                an.setOnClickListener(v -> { closeInfo(); openAnalyze(co + "USDT"); });
                col.addView(an);
            }
        }
        readerSection(col, link.contains("polymarket.com") || link.contains("binance.com/en/futures") ? "" : link, title, coins);
        if (!link.isEmpty()) {
            TextView o = chip("🌐 Asal source kholen", false);
            o.setOnClickListener(v -> openUrl(link));
            LinearLayout.LayoutParams ol = new LinearLayout.LayoutParams(-1, -2);
            ol.topMargin = dp(12);
            col.addView(o, ol);
        }

        final long[] lastLoad = {0};
        final boolean[] loading = {false};
        final Runnable[] tick = new Runnable[1];
        tick[0] = () -> {
            if (infoOverlay != page) return;
            long now = System.currentTimeMillis(), dt = time - now;
            if (!detected) {
                if (dt > 0) {
                    cd.setText("⏳ " + clock(dt));
                    cd.setTextColor(dt < 60_000 ? RED : dt < 3600_000L ? YELLOW : TEXT);
                    cdSub.setText(dt < 60_000 ? "Aakhri second — release hone wala hai!" : "Release mein baqi waqt (live)");
                } else if (dt > -5 * 60_000L) {
                    cd.setText("🔴 ABHI — release ho raha hai");
                    cd.setTextColor(RED);
                    cdSub.setText("Pehli report " + clock(dt + 5 * 60_000L) + " mein (market ka pehla react)");
                } else {
                    cd.setText("✅ Release ho chuka");
                    cd.setTextColor(GREEN);
                    cdSub.setText(ago(time) + " · report har minute update");
                }
            }
            boolean after = detected || dt < -60_000L;
            if (after && !loading[0] && now - lastLoad[0] > 60_000L && (detected || dt > -12 * 3600_000L || lastLoad[0] == 0)) {
                loading[0] = true;
                lastLoad[0] = now;
                pool.execute(() -> {
                    EventReport.Report r = null;
                    try { r = EventReport.build(this, title, time, coin); } catch (Exception ignored) { }
                    final EventReport.Report fr = r;
                    runOnUiThread(() -> {
                        loading[0] = false;
                        if (infoOverlay == page && fr != null) renderEventReport(repBody, fr, me);
                    });
                });
            }
            handler.postDelayed(tick[0], 1000);
        };
        tick[0].run();
    }

    private void renderEventReport(LinearLayout b, EventReport.Report r, MacroEngine.Event me) {
        b.removeAllViews();
        b.addView(text("Update: " + new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date(r.at)) + " PKT", 11, MUTED));
        // 1) the number
        if (!r.actual.isEmpty()) {
            b.addView(bold("🔢 Asal number: " + r.actual + "   (forecast " + (r.forecast.isEmpty() ? "—" : r.forecast) + " · pichla " + (r.previous.isEmpty() ? "—" : r.previous) + ")", 15, TEXT));
            if (!r.verdict.isEmpty()) b.addView(bold(r.verdict, 13, r.verdictSign > 0 ? GREEN : r.verdictSign < 0 ? RED : YELLOW));
        } else if (me != null) b.addView(text("🔢 Asal number abhi feed mein nahi aaya (kuch minute lagte hain) — tab tak market ka asal react neeche dekhein.", 12, MUTED));
        // 2) the market
        b.addView(bold("\n📊 Market ka asal react (release ke waqt se)", 14, TEXT));
        if (r.moves.isEmpty()) b.addView(text("Market data load nahi hua — thori der baad khud update hoga.", 12, MUTED));
        for (EventReport.Move m : r.moves) {
            LinearLayout row = row();
            row.addView(text(m.name, 12, SOFT), new LinearLayout.LayoutParams(0, -2, 1.4f));
            for (double v : new double[]{m.m15, m.m60, m.now}) {
                String s = Double.isNaN(v) ? "—" : m.bps ? String.format(Locale.US, "%+.0f bps", v) : String.format(Locale.US, "%+.2f%%", v);
                row.addView(bold(s, 12, Double.isNaN(v) ? MUTED : v > 0 ? GREEN : v < 0 ? RED : SOFT), new LinearLayout.LayoutParams(0, -2, 1));
            }
            b.addView(row);
        }
        if (!r.moves.isEmpty()) b.addView(text("Columns: 15 min · 1 ghanta · ab tak", 10, MUTED));
        b.addView(bold(r.market, 13, r.marketSign > 0 ? GREEN : r.marketSign < 0 ? RED : YELLOW));
        // 3) the headlines
        b.addView(bold("\n📰 Is par khabrein (" + r.news.size() + ") · 🟢 " + r.newsBull + " · 🔴 " + r.newsBear, 14, TEXT));
        if (r.news.isEmpty()) b.addView(text("Abhi koi khabar nahi mili — har minute dobara dhoondta hai.", 12, MUTED));
        for (final NewsEngine.Item it : r.news) {
            TextView tv = text((it.dir > 0 ? "🟢 " : it.dir < 0 ? "🔴 " : "⚪ ") + it.title + "\n   " + it.source + " · " + ago(it.time), 12, SOFT);
            tv.setPadding(0, dp(5), 0, dp(5));
            tv.setOnClickListener(v -> { if (!it.link.isEmpty()) openUrl(it.link); });
            b.addView(tv);
        }
        // 4) verdict
        b.addView(bold("\n✅ Final faisla", 14, TEXT));
        b.addView(text(r.action, 13, TEXT));
    }

    // ============================================================ v18: 🎯 FOCUS MODE (only my chosen coins / gold / forex)
    private LinearLayout focusBox;

    private void restartService() {
        if (Prefs.enabled(this)) startForegroundService(new Intent(this, ScannerService.class));
        else startService(new Intent(this, ScannerService.class).setAction(ScannerService.ACTION_STOP));
        handler.postDelayed(this::refreshStatus, 300);
    }

    private static String focusName(String sym, String kind) {
        if (Assets.CRYPTO.equals(kind)) return sym.endsWith("USDT") ? sym.substring(0, sym.length() - 4) + "/USDT" : sym;
        Assets.Asset a = Assets.find(sym);
        return a != null ? a.icon + " " + a.short_ : sym;
    }

    private void renderFocus() {
        if (focusBox == null) return;
        focusBox.removeAllViews();
        boolean on = Prefs.focusOn(this);
        JSONArray l = Prefs.focusList(this);
        LinearLayout c = card(focusBox, on ? YELLOW : STROKE);
        LinearLayout h = row();
        LinearLayout tt = column();
        tt.addView(bold("🎯 Focus mode — sirf meri list ke signals", 15, TEXT));
        tt.addView(text(on ? "ON · baqi saare bots ruke hue hain · " + l.length() + " items" : "OFF · normal bots chal rahe hain", 12, on ? YELLOW : MUTED));
        h.addView(tt, new LinearLayout.LayoutParams(0, -2, 1));
        Switch sw = new Switch(this);
        sw.setChecked(on);
        sw.setOnCheckedChangeListener((b, v) -> {
            if (v && Prefs.focusList(this).length() == 0) {
                toast("Pehle list mein coin / gold / forex add karein");
                b.setChecked(false);
                openFocusPicker();
                return;
            }
            Prefs.setFocusOn(this, v);
            restartService();
            toast(v ? "🎯 Focus ON — sirf aap ki list ke signals aayenge" : "Focus OFF — normal bots");
            renderFocus();
        });
        h.addView(sw);
        c.addView(h);
        c.addView(text("Har item ka poora analysis hota hai: multi-timeframe technicals, moving averages + ParaDox rule + backtest, sab exchanges ka volume, "
                + "whales, futures, news radar, catalysts (unlock/listing), Fed/CPI — sab paas ho to hi signal.", 11, MUTED));
        if (l.length() == 0) c.addView(text("List khali hai.", 13, MUTED));
        for (int i = 0; i < l.length(); i++) {
            final JSONObject o = l.optJSONObject(i);
            if (o == null) continue;
            final String sym = o.optString("s"), kind = o.optString("k"), mode = o.optString("m", "both");
            LinearLayout r = row();
            r.setPadding(0, dp(8), 0, dp(4));
            TextView nm = bold(focusName(sym, kind), 14, TEXT);
            nm.setOnClickListener(v -> {
                if (Assets.CRYPTO.equals(kind)) openAnalyze(sym);
                else { Assets.Asset a = Assets.find(sym); if (a != null) openAssetChart(a); }
            });
            r.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
            if (Assets.CRYPTO.equals(kind)) {
                String[] ms = {"scalp", "spot", "both"}, ml = {"⚡", "💎", "⚡+💎"};
                for (int k = 0; k < 3; k++) {
                    final String mm = ms[k];
                    TextView ch = chip(ml[k], mode.equals(mm));
                    ch.setTextSize(11);
                    ch.setPadding(dp(9), dp(5), dp(9), dp(5));
                    ch.setOnClickListener(v -> { Prefs.setFocusMode(this, sym, mm); renderFocus(); });
                    r.addView(ch, chipLp());
                }
            } else {
                r.addView(text(Assets.FOREX.equals(kind) ? "Forex · 1h  " : "Commodity · 1h  ", 11, MUTED));
            }
            TextView x = chip("✕", false);
            x.setTextSize(11);
            x.setPadding(dp(9), dp(5), dp(9), dp(5));
            x.setOnClickListener(v -> {
                Prefs.removeFocus(this, sym);
                if (Prefs.focusList(this).length() == 0 && Prefs.focusOn(this)) { Prefs.setFocusOn(this, false); restartService(); }
                renderFocus();
            });
            r.addView(x);
            c.addView(r);
        }
        Button add = button("＋ Coin / Gold / Forex add karein", CHIP, YELLOW, YELLOW);
        add.setOnClickListener(v -> openFocusPicker());
        c.addView(add);
    }

    private void openFocusPicker() {
        final LinearLayout col = openPage("🎯 Focus list mein add karein", () -> { closeInfo(); renderFocus(); });
        LinearLayout cr = card(col, ACC);
        cr.addView(bold("🪙 Crypto coin", 15, TEXT));
        LinearLayout sr = row();
        final EditText q = input("BTC, SOL, PEPE...", "", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        sr.addView(q, new LinearLayout.LayoutParams(0, -2, 1));
        final String[] modeSel = {"both"};
        TextView ad = chip("Add", true);
        ad.setOnClickListener(v -> {
            String s = q.getText().toString().trim();
            if (s.isEmpty()) return;
            String sym = CoinReport.normalize(s);
            if (!mk.isEmpty() && !mk.containsKey(sym)) { toast(sym + " Binance par nahi mila"); return; }
            Prefs.addFocus(this, sym, Assets.CRYPTO, modeSel[0]);
            q.setText("");
            hideKeyboard();
            toast("✅ " + sym + " focus list mein");
            openFocusPicker();
        });
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(-2, -2);
        al.leftMargin = dp(8);
        sr.addView(ad, al);
        cr.addView(sr);
        LinearLayout mr = row();
        final String[] ms = {"scalp", "spot", "both"}, ml = {"⚡ Scalp", "💎 Spot", "⚡+💎 Dono"};
        final TextView[] mc = new TextView[3];
        for (int k = 0; k < 3; k++) {
            final int kk = k;
            mc[k] = chip(ml[k], k == 2);
            mc[k].setTextSize(11);
            mc[k].setOnClickListener(v -> { modeSel[0] = ms[kk]; for (int z = 0; z < 3; z++) styleChip(mc[z], z == kk); });
            mr.addView(mc[k], chipLp());
        }
        cr.addView(hscroll(mr));
        LinearLayout qr = row();
        for (String b : new String[]{"BTC", "ETH", "SOL", "XRP", "BNB", "DOGE", "SUI", "HYPE", "PEPE"}) {
            final String sym = b + "USDT";
            TextView ch = chip((Prefs.inFocus(this, sym) ? "✓ " : "+ ") + b, Prefs.inFocus(this, sym));
            ch.setTextSize(11);
            ch.setOnClickListener(v -> {
                if (Prefs.inFocus(this, sym)) Prefs.removeFocus(this, sym); else Prefs.addFocus(this, sym, Assets.CRYPTO, modeSel[0]);
                openFocusPicker();
            });
            qr.addView(ch, chipLp());
        }
        cr.addView(hscroll(qr));
        String[][] groups = {{Assets.COMMODITY, "🥇 Gold, commodities & Dollar index"}, {Assets.FOREX, "💱 Forex pairs"}};
        for (String[] g : groups) {
            LinearLayout gc = card(col, YELLOW);
            gc.addView(bold(g[1], 15, TEXT));
            LinearLayout wrapRow = null;
            int n = 0;
            for (final Assets.Asset a : Assets.list(g[0])) {
                if (n % 3 == 0) { wrapRow = row(); wrapRow.setPadding(0, dp(4), 0, 0); gc.addView(wrapRow); }
                n++;
                final boolean in = Prefs.inFocus(this, a.sym) && Prefs.focusAssets(this, g[0]).contains(a.sym);
                TextView ch = chip((in ? "✓ " : "+ ") + a.icon + " " + a.short_, in);
                ch.setTextSize(11);
                final String kind = g[0];
                ch.setOnClickListener(v -> {
                    if (Prefs.inFocus(this, a.sym)) Prefs.removeFocus(this, a.sym); else Prefs.addFocus(this, a.sym, kind, "both");
                    openFocusPicker();
                });
                wrapRow.addView(ch, new LinearLayout.LayoutParams(0, -2, 1));
                if (n % 3 != 0) wrapRow.addView(new View(this), new LinearLayout.LayoutParams(dp(6), 1));
            }
        }
        JSONArray l = Prefs.focusList(this);
        LinearLayout sc = card(col, GREEN);
        sc.addView(bold("Aap ki list (" + l.length() + ")", 14, TEXT));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.length(); i++) {
            JSONObject o = l.optJSONObject(i);
            if (o != null) sb.append(focusName(o.optString("s"), o.optString("k"))).append(Assets.CRYPTO.equals(o.optString("k")) ? " (" + o.optString("m") + ")" : "").append("   ");
        }
        sc.addView(text(sb.length() == 0 ? "Abhi khali" : sb.toString().trim(), 13, SOFT));
        Button on = button(Prefs.focusOn(this) ? "✅ Focus mode ON hai — wapas" : "🎯 Focus mode ON karein (sirf yeh signals)", YELLOW, INK, 0);
        on.setOnClickListener(v -> {
            if (Prefs.focusList(this).length() == 0) { toast("Pehle kuch add karein"); return; }
            Prefs.setFocusOn(this, true);
            restartService();
            closeInfo();
            showTab(TAB_SIGNALS);
            renderFocus();
            toast("🎯 Focus ON — baqi bots ruke, sirf aap ki list");
        });
        sc.addView(on);
    }

    // ============================================================ v19: 🌍 MARKET HOURS + GLOBAL VOLUME
    private void openMarketHours() {
        final LinearLayout col = openPage("🌍 Market hours & volume");
        final LinearLayout page = infoOverlay;
        final LinearLayout sess = column();
        col.addView(sess);
        final LinearLayout vol = column();
        col.addView(vol);
        final Runnable[] tick = new Runnable[1];
        tick[0] = () -> {
            if (infoOverlay != page) return;
            renderSessions(sess);
            handler.postDelayed(tick[0], 30_000);
        };
        tick[0].run();
        LinearLayout w = card(vol, ACC2);
        w.addView(bold("🌐 Duniya bhar ka volume — load ho raha hai...", 14, TEXT));
        pool.execute(() -> {
            final GlobalVolume.Result r = GlobalVolume.fetch(false);
            runOnUiThread(() -> {
                if (infoOverlay != page) return;
                vol.removeAllViews();
                TextView h = bold("🌐 DUNIYA BHAR KA VOLUME · PAISA IN / OUT", 11, MUTED);
                h.setLetterSpacing(0.1f);
                h.setPadding(dp(4), dp(16), 0, 0);
                vol.addView(h);
                for (GlobalVolume.Block b : new GlobalVolume.Block[]{r.crypto, r.gold, r.forex}) {
                    int col2 = b.dir > 0 ? GREEN : b.dir < 0 ? RED : YELLOW;
                    LinearLayout c = card(vol, col2);
                    c.addView(bold(b.title, 16, TEXT));
                    if (b.volume > 0) c.addView(bold("Volume: " + Fmt.usd(b.volume) + (b.title.startsWith("💱") ? " / din" : " (24h)"), 15, TEXT));
                    c.addView(bold(b.headline, 14, col2));
                    for (String l : b.lines) c.addView(text("• " + l, 12, SOFT));
                }
                LinearLayout n = card(vol);
                n.addView(text("Note: crypto ka volume sab exchanges ka hai (CoinGecko). Gold mein sirf woh hissa jo roz free data mein milta hai (COMEX futures + "
                        + "bare gold ETFs); London aur Shanghai ka physical gold is se zyada hai. Forex ka asal roz ka hisaab koi free source nahi deta — BIS ka "
                        + "survey (har 3 saal) aur CME currency futures se andaza. 'In/Out' = din ki candle mein khareedne walon ka zor (money flow).", 11, MUTED));
                learnToggle(n, "Volume ka matlab: kitna paisa haath badla. Paisa IN = khareedne wale zyada zor se (price din ke upar wale hisse mein band hui), "
                        + "OUT = bechne wale zyada. Jab dollar mein paisa aata hai (DXY upar) to aksar gold aur crypto par dabao hota hai, aur ulta.");
            });
        });
        learnToggle(col, "Forex aur gold 24 ghante, haftay mein 5 din chalte hain — Sydney se shuru ho kar Tokyo, London aur New York. Sab se behtar waqt "
                + "London + New York ka overlap hai (takreeban 5 PM – 9 PM PKT, sardiyon mein 6 PM – 10 PM): volume sab se zyada, spread kam. "
                + "Sydney / raat ka waqt dheema hota hai aur spread zyada. Crypto 24/7 chalta hai magar US market khulne (6:30 / 7:30 PM PKT) par sab se tez hota hai. "
                + "Chhuttiyon (Christmas, US holidays) mein volume kam aur moves ajeeb ho sakte hain.");
    }

    private void renderSessions(LinearLayout box) {
        box.removeAllViews();
        long now = System.currentTimeMillis();
        List<Sessions.Session> l = Sessions.status(now);
        LinearLayout top = card(box, ACC);
        SimpleDateFormat f = new SimpleDateFormat("EEE, dd MMM · h:mm a", Locale.US);
        f.setTimeZone(Sessions.PKT);
        top.addView(text("Pakistan time: " + f.format(new Date(now)), 12, MUTED));
        top.addView(bold(Sessions.moment(l), 15, TEXT));
        top.addView(text("🪙 Crypto: 24 ghante · 7 din · kabhi band nahi", 13, GREEN));
        top.addView(text("💱 Forex hafta: Sunday raat (Sydney) se Saturday subah (New York close) tak", 12, SOFT));
        String market = "";
        for (Sessions.Session s : l) {
            if (!s.market.equals(market)) {
                market = s.market;
                TextView h = bold(market.equals("Forex") ? "💱 FOREX SESSIONS" : market.equals("Gold") ? "🥇 GOLD MARKETS" : "🗽 STOCKS (asar dalte hain)", 11, MUTED);
                h.setLetterSpacing(0.1f);
                h.setPadding(dp(4), dp(14), 0, 0);
                box.addView(h);
            }
            LinearLayout c = card(box, s.open ? GREEN : STROKE);
            LinearLayout r = row();
            r.addView(bold(s.icon + " " + s.name, 15, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
            TextView st = bold(s.open ? "● OPEN" : "○ CLOSED", 12, s.open ? INK : MUTED);
            st.setPadding(dp(8), dp(3), dp(8), dp(3));
            st.setBackground(round(s.open ? GREEN : CHIP, 10, s.open ? 0 : STROKE));
            r.addView(st);
            c.addView(r);
            c.addView(text("🕒 " + s.pktHours, 13, SOFT));
            if (s.nextChange < Long.MAX_VALUE)
                c.addView(bold((s.open ? "Band hogi: " : "Khulegi: ") + Sessions.countdown(s.nextChange - now) + " baad", 12, s.open ? YELLOW : CYAN_TXT));
            c.addView(text(s.note, 11, MUTED));
        }
    }

    // ============================================================ v21: ⚡ MISPRICING RADAR (arbitrage · price errors · 24/7)
    private int arbTab = 0;
    private LinearLayout arbList, arbNew;
    private TextView arbStatus;
    private volatile boolean arbBusy;

    static String venueUrl(String v, String base) {
        String b = base.toUpperCase(Locale.US), l = base.toLowerCase(Locale.US);
        switch (v.replace(" Spot", "").replace(" Futures", "")) {
            case "Binance": return v.endsWith("Futures") ? "https://www.binance.com/en/futures/" + b + "USDT" : "https://www.binance.com/en/trade/" + b + "_USDT?type=spot";
            case "OKX": return "https://www.okx.com/trade-spot/" + l + "-usdt";
            case "Bybit": return "https://www.bybit.com/en/trade/spot/" + b + "/USDT";
            case "Bitget": return "https://www.bitget.com/spot/" + b + "USDT";
            case "KuCoin": return "https://www.kucoin.com/trade/" + b + "-USDT";
            case "Gate": return "https://www.gate.io/trade/" + b + "_USDT";
            case "MEXC": return "https://www.mexc.com/exchange/" + b + "_USDT";
            case "HTX": return "https://www.htx.com/trade/" + l + "_usdt";
            case "Bithumb": return "https://www.bithumb.com/react/trade/order/" + b + "-KRW";
            case "Upbit": return "https://upbit.com/exchange?code=CRIX.UPBIT.KRW-" + b;
            default: return "";
        }
    }

    private void openArb() {
        LinearLayout col = openPage("⚡ Mispricing Radar");
        final LinearLayout page = infoOverlay;
        LinearLayout top = card(col, YELLOW);
        top.addView(bold("Price errors aur gaps — seconds mein", 16, TEXT));
        top.addView(text("Koi andaza nahi, koi jazbaat nahi — sirf hisaab: 8 exchanges (Binance, OKX, Bybit, Bitget, KuCoin, Gate, MEXC, HTX) ke saare USDT pairs "
                + "ki bid/ask ek saath. Bot dhoondta hai: kahan coin sasta / mehnga hai, kis exchange ki price ghalat hai, Binance par triangle loops, futures vs spot, "
                + "stablecoin peg aur seconds mein bari harkat. Page khula ho to har ~5 second scan.", 12, MUTED));
        toggle(top, "🔔 24/7 background radar + alerts", "Phone band ho tab bhi har " + Prefs.arbEverySec(this) + " sec scan · bara gap mile to notification",
                Prefs.arbOn(this), (b, on) -> {
                    Prefs.setArbOn(this, on);
                    restartService();
                    toast(on ? "⚡ Radar 24/7 ON" : "Radar background OFF");
                });
        LinearLayout mr = row();
        mr.addView(text("Alert jab NET ≥", 12, SOFT), chipLp());
        final float[] mins = {0.3f, 0.5f, 1f, 2f};
        final TextView[] mc = new TextView[mins.length];
        for (int i = 0; i < mins.length; i++) {
            final int k = i;
            mc[i] = chip(String.format(Locale.US, "%.1f%%", mins[i]), Math.abs(Prefs.arbMinNet(this) - mins[i]) < 0.01);
            mc[i].setTextSize(11);
            mc[i].setOnClickListener(v -> { Prefs.setArbMinNet(this, mins[k]); for (int z = 0; z < mins.length; z++) styleChip(mc[z], z == k); });
            mr.addView(mc[i], chipLp());
        }
        top.addView(hscroll(mr));
        LinearLayout er = row();
        er.addView(text("Background scan:", 12, SOFT), chipLp());
        final int[] evs = {15, 30, 60, 300};
        final TextView[] ec = new TextView[evs.length];
        for (int i = 0; i < evs.length; i++) {
            final int k = i;
            ec[i] = chip(evs[i] < 60 ? evs[i] + "s" : (evs[i] / 60) + "m", Prefs.arbEverySec(this) == evs[i]);
            ec[i].setTextSize(11);
            ec[i].setOnClickListener(v -> { Prefs.setArbEverySec(this, evs[k]); for (int z = 0; z < evs.length; z++) styleChip(ec[z], z == k); });
            er.addView(ec[i], chipLp());
        }
        top.addView(hscroll(er));
        top.addView(text("⚠️ Tez scan = zyada mobile data aur battery (har scan ~2–4 MB). Wi-Fi par 15s, mobile data par 1–5 min behtar.", 11, YELLOW));
        arbStatus = bold("Pehla scan chal raha hai...", 12, ACC2);
        top.addView(arbStatus);
        LinearLayout fr0 = row();
        fr0.addView(bold("Dikhao sirf ≥", 12, SOFT), chipLp());
        final float[] fv = {0f, 1f, 2f, 3f, 5f};
        final TextView[] fcs0 = new TextView[fv.length];
        final EditText fin = input("%", Prefs.arbShowMin(this) > 0 ? String.format(Locale.US, "%.1f", Prefs.arbShowMin(this)) : "", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        for (int i = 0; i < fv.length; i++) {
            final int k = i;
            fcs0[i] = chip(fv[i] == 0 ? "Sab" : String.format(Locale.US, "%.0f%%", fv[i]), Math.abs(Prefs.arbShowMin(this) - fv[i]) < 0.01);
            fcs0[i].setTextSize(12);
            fcs0[i].setOnClickListener(v -> {
                Prefs.setArbShowMin(this, fv[k]);
                for (int z = 0; z < fv.length; z++) styleChip(fcs0[z], z == k);
                fin.setText(fv[k] == 0 ? "" : String.format(Locale.US, "%.1f", fv[k]));
                renderArb();
            });
            fr0.addView(fcs0[i], chipLp());
        }
        top.addView(bold("🎚️ Difference filter (gap % jitna ya zyada)", 13, TEXT));
        top.addView(hscroll(fr0));
        LinearLayout fr1 = row();
        fr1.addView(fin, new LinearLayout.LayoutParams(dp(110), -2));
        TextView setF = chip("Apna % lagao", true);
        setF.setOnClickListener(v -> {
            hideKeyboard();
            Prefs.setArbShowMin(this, (float) parse(fin, 0));
            for (int z = 0; z < fv.length; z++) styleChip(fcs0[z], Math.abs(Prefs.arbShowMin(this) - fv[z]) < 0.01);
            renderArb();
            toast("Sirf ≥" + String.format(Locale.US, "%.1f", Prefs.arbShowMin(this)) + "% wale gaps");
        });
        LinearLayout.LayoutParams sfl = new LinearLayout.LayoutParams(-2, -2);
        sfl.leftMargin = dp(8);
        fr1.addView(setF, sfl);
        top.addView(fr1);
        Button scanNow = button("🔄 Abhi scan karein (sab 8 exchanges)", YELLOW, INK, 0);
        scanNow.setOnClickListener(v -> {
            if (arbBusy) { toast("Scan chal raha hai..."); return; }
            arbBusy = true;
            arbStatus.setText("⏳ Scan chal raha hai...");
            pool.execute(() -> {
                try { Mispricing.scan(false, Prefs.arbFee(this), Prefs.arbMinVol(this)); } catch (Exception ignored) { } finally { arbBusy = false; }
                runOnUiThread(() -> { renderArb(); toast("✅ Scan mukammal"); });
            });
        });
        top.addView(scanNow);
        arbNew = column();
        col.addView(arbNew);

        LinearLayout fc = card(col);
        LinearLayout fr = row();
        final String[] fn = {"⚡ Cross-exchange", "🎯 Price errors", "🔺 Triangle", "📊 Futures/funding", "💵 Stablecoins", "💥 Flash moves", "🧪 Paper test"};
        final TextView[] fcs = new TextView[fn.length];
        for (int i = 0; i < fn.length; i++) {
            final int fi = i;
            fcs[i] = chip(fn[i], i == arbTab);
            fcs[i].setTextSize(11);
            fcs[i].setOnClickListener(v -> { arbTab = fi; for (int k = 0; k < fn.length; k++) styleChip(fcs[k], k == fi); renderArb(); });
            fr.addView(fcs[i], chipLp());
        }
        fc.addView(hscroll(fr));
        arbList = column();
        col.addView(arbList);

        LinearLayout warn = card(col, RED);
        warn.addView(bold("🧠 Sach — 'execute' kyun nahi karta?", 14, TEXT));
        warn.addView(text("Bot khud trade nahi karta, sirf dhoondta aur alert karta hai. Wajah:\n"
                + "• Asli arbitrage firms exchanges ke servers ke paas machines rakhti hain (milliseconds). Phone se internet par seconds lagte hain — "
                + "jab tak order pohanche, aksar gap band ho chuka hota hai.\n"
                + "• Do exchanges ke beech dono taraf pehle se paisa hona chahiye; coin bhejne mein minute se ghante lagte hain.\n"
                + "• Bara gap aksar is liye hota hai ke wahan deposit/withdraw BAND hai, ya same naam ka doosra token hai — 'suspicious' nishan dekhein.\n"
                + "• Auto-trading ke liye exchange ki trading API key phone mein rakhni padti — chori ho to poora account khatre mein.\n"
                + "'🧪 Paper test' tab dikhata hai ke aise gaps asal mein kitni der khule rehte hain — trade se pehle yeh zaroor dekhein.", 12, SOFT));

        final Runnable[] loop = new Runnable[1];
        final boolean[] first = {true};
        loop[0] = () -> {
            if (infoOverlay != page) return;
            if (!arbBusy) {
                arbBusy = true;
                final boolean fast = !first[0];
                first[0] = false;
                pool.execute(() -> {
                    try {
                        Mispricing.scan(fast, Prefs.arbFee(this), Prefs.arbMinVol(this));
                    } catch (Exception ignored) {
                    } finally {
                        arbBusy = false;
                    }
                    runOnUiThread(() -> { if (infoOverlay == page) renderArb(); });
                });
            }
            handler.postDelayed(loop[0], 5_000);
        };
        loop[0].run();
    }

    private void renderArb() {
        if (arbList == null) return;
        Mispricing.Result r = Mispricing.cached();
        if (r != null && arbStatus != null) {
            SimpleDateFormat f = new SimpleDateFormat("HH:mm:ss", Locale.US);
            arbStatus.setText("● LIVE · scan #" + r.scanNo + " · " + f.format(new Date(r.at)) + " · " + r.ms + " ms · " + r.coins + " coins · ✅ "
                    + String.join(", ", r.venuesOk) + (r.venuesFail.isEmpty() ? "" : " · ❌ " + String.join(", ", r.venuesFail)));
        }
        arbList.removeAllViews();
        if (r == null) { arbList.addView(text("\nScan chal raha hai...", 13, MUTED)); return; }
        if (arbNew != null) {   // live strip: newest discoveries on top, updated every scan
            arbNew.removeAllViews();
            List<Mispricing.Gap> nw0 = Mispricing.newest(r, 30), nw = new ArrayList<>();
            for (Mispricing.Gap g : nw0) if (gapSize(g) >= Prefs.arbShowMin(this) && nw.size() < 6) nw.add(g);
            if (!nw.isEmpty()) {
                LinearLayout c = card(arbNew, GREEN);
                c.addView(bold("🆕 Abhi mile — live (sab se naye upar)", 14, TEXT));
                long t0 = System.currentTimeMillis();
                for (final Mispricing.Gap g : nw) {
                    String k = g.kind.equals(Mispricing.CROSS) ? "⚡" : g.kind.equals(Mispricing.ERROR) ? "🎯" : g.kind.equals(Mispricing.TRI) ? "🔺"
                            : g.kind.equals(Mispricing.BASIS) ? "📊" : g.kind.equals(Mispricing.PEG) ? "💵" : "💥";
                    long age = (t0 - g.firstSeen) / 1000;
                    TextView t = text((Mispricing.isNew(g) ? "🆕 " : "") + k + " " + g.base + " · " + g.title + " · " + (age < 60 ? age + "s" : (age / 60) + "m") + " pehle", 12,
                            Mispricing.isNew(g) ? GREEN : SOFT);
                    t.setPadding(0, dp(4), 0, dp(4));
                    t.setOnClickListener(v -> openGap(g));
                    c.addView(t);
                }
            }
        }
        if (arbTab == 6) { renderPaper(); return; }
        List<Mispricing.Gap> l = arbTab == 0 ? r.cross : arbTab == 1 ? r.errors : arbTab == 2 ? r.tri : arbTab == 3 ? r.basis : arbTab == 4 ? r.pegs : r.flash;
        String[] help = {
                "Ek exchange par sasta KHAREEDO, doosre par mehnga BECHO. NET = dono exchanges ki asal taker fees (Binance/OKX/Bybit/Bitget/KuCoin 0.1%, MEXC 0.05%, Gate/HTX 0.2%) ke baad bachat. Tap = profit calculator (transfer fee ke saath).",
                "Ek exchange ki price baqi sab se 1.5%+ door — aksar 'price error' (fat finger, kamzor order book, ruka hua feed). Yahi gap insaan ke dekhne se pehle band ho jata hai.",
                "Sirf Binance par 3 trades ka chakkar jo shuru se zyada USDT par khatam ho (3 fees ke baad). Aise gaps bots milliseconds mein khatam karte hain.",
                "Futures ki price index se door ya funding bahut zyada: funding + ho to spot khareed + futures short = har 8 ghante funding (cash-and-carry). Saalana % takreeban hai.",
                "Stablecoins $1 ke paas rehne chahiye. 0.3%+ door = depeg ka khatra ya sasta/mehnga ka mauqa.",
                "Do scans ke beech (seconds) liquid coins mein 1.5%+ ki harkat — bara order, khabar ya liquidations."};
        LinearLayout h = card(arbList);
        h.addView(text(help[arbTab], 11, MUTED));
        if (l.isEmpty()) {
            arbList.addView(text("\nAbhi is qism ka koi gap nahi — market efficient hai. Scan har 5 sec chal raha hai.", 13, MUTED));
            return;
        }
        long now = System.currentTimeMillis();
        int n = 0, hidden = 0;
        double fmin = Prefs.arbShowMin(this);
        for (final Mispricing.Gap g : l) {
            if (fmin > 0 && gapSize(g) < fmin) { hidden++; continue; }
            if (n++ >= 40) break;
            boolean good = g.netPct >= Prefs.arbMinNet(this) && !g.suspicious;
            int col = g.suspicious ? YELLOW : (g.kind.equals(Mispricing.FLASH) ? (g.grossPct >= 0 ? GREEN : RED) : good ? GREEN : STROKE);
            LinearLayout c = card(arbList, col);
            LinearLayout hr = row();
            String val = g.kind.equals(Mispricing.BASIS) ? String.format(Locale.US, "%+.0f%%/saal", g.netPct)
                    : g.kind.equals(Mispricing.FLASH) || g.kind.equals(Mispricing.PEG) ? String.format(Locale.US, "%+.2f%%", g.grossPct)
                    : String.format(Locale.US, "NET %+.2f%%", g.netPct);
            hr.addView(bold((Mispricing.isNew(g) ? "🆕 " : "") + g.base, 15, Mispricing.isNew(g) ? GREEN : TEXT), new LinearLayout.LayoutParams(0, -2, 1));
            hr.addView(bold(val, 14, good || g.kind.equals(Mispricing.BASIS) ? GREEN : g.suspicious ? YELLOW : SOFT));
            c.addView(hr);
            c.addView(text(g.title, 13, SOFT));
            c.addView(text(g.detail, 11, MUTED));
            if (g.firstSeen > 0) c.addView(text("⏱ " + (g.seen <= 1 ? "abhi mila" : (now - g.firstSeen) / 1000 + " sec se khula · " + g.seen + " scans"), 11, CYAN_TXT));
            if (g.minVol > 0) c.addView(text("24h volume (kam wali side): " + Fmt.usd(g.minVol), 11, MUTED));
            if (g.suspicious) c.addView(bold("⚠️ Suspicious — bahut bara gap: aksar deposit/withdraw band ya doosra token. Pehle tasdeeq karein.", 11, YELLOW));
            c.setOnClickListener(v -> openGap(g));
        }
        if (n == 0) arbList.addView(text("\nFilter ≥" + String.format(Locale.US, "%.1f", fmin) + "% — is waqt itna bara koi gap nahi" + (hidden > 0 ? " (" + hidden + " chhote chhupaye)" : "")
                + ". Bot har scan par dhoondta rahega.", 13, MUTED));
        else if (hidden > 0) arbList.addView(text(hidden + " chhote gaps (filter se kam) chhupaye gaye", 11, MUTED));
    }

    /** Size used by the radar filter: NET % for trades, |move| for flash / peg, |basis| for futures. */
    static double gapSize(Mispricing.Gap g) {
        if (g.kind.equals(Mispricing.FLASH) || g.kind.equals(Mispricing.PEG) || g.kind.equals(Mispricing.BASIS)) return Math.abs(g.grossPct);
        return g.netPct;
    }

    private void renderPaper() {
        double[] st = Mispricing.paperStats();
        LinearLayout c = card(arbList, CYAN_TXT);
        c.addView(bold("🧪 Paper test — gaps asal mein kitni der rehte hain?", 15, TEXT));
        c.addView(text("Har gap ko bot har scan par dobara check karta hai (bina paisa lagaye). Jab gap band ho jaye to us ki umar note hoti hai.", 12, MUTED));
        if (st[0] == 0) { c.addView(text("Abhi data jama ho raha hai — page khula rakhein ya 24/7 radar ON karein.", 13, SOFT)); return; }
        c.addView(bold(String.format(Locale.US, "%.0f gaps band hue · median umar %.0f sec", st[0], st[1] / 1000), 14, TEXT));
        c.addView(bold(String.format(Locale.US, "%.0f%% pehle scan ke baad hi gayab (seconds mein)", st[2]), 14, st[2] > 50 ? RED : YELLOW));
        c.addView(text(String.format(Locale.US, "Ausat NET jab mile: %.2f%%", st[3] / 100), 13, SOFT));
        c.addView(text(st[2] > 50 ? "Nateeja: zyada tar gaps itni jaldi band hote hain ke haath se pakarna mushkil hai — sirf woh lein jo kai scans tak khule rahein."
                : "Kaafi gaps kuch der khule rehte hain — magar fees, transfer ka waqt aur deposit band hone ka khayal rakhein.", 12, SOFT));
    }

    private void openGap(final Mispricing.Gap g) {
        LinearLayout col = openPage("⚡ " + g.base, this::openArb);
        LinearLayout c = card(col, g.suspicious ? YELLOW : GREEN);
        c.addView(bold(g.title, 16, TEXT));
        c.addView(text(g.detail, 13, SOFT));
        if (g.kind.equals(Mispricing.CROSS)) {
            c.addView(divider());
            c.addView(bold("Qadam (dono exchanges par pehle se paisa / coin hona chahiye):", 13, YELLOW));
            c.addView(text("1️⃣ " + g.buyVenue + " par " + g.base + " KHAREEDO ~$" + Fmt.price(g.buyPrice) + "\n2️⃣ Usi waqt " + g.sellVenue + " par utna hi BECHO ~$"
                    + Fmt.price(g.sellPrice) + "\n3️⃣ Baad mein balance barabar karne ke liye coin/USDT transfer (network fee + waqt)", 13, SOFT));
            double ex = 1000 * g.netPct / 100;
            c.addView(bold(String.format(Locale.US, "Misal: $1,000 par fees ke baad ~$%.2f (agar gap tab tak khula rahe)", ex), 13, GREEN));
            final TextView dep = text("Deposit / withdraw status check ho raha hai...", 12, MUTED);
            c.addView(dep);
            pool.execute(() -> {
                final String st = Transfers.status(g.base, g.buyVenue, g.sellVenue);
                runOnUiThread(() -> dep.setText(st));
            });
        }
        for (String v : new String[]{g.buyVenue, g.sellVenue}) {
            if (v == null || v.isEmpty()) continue;
            final String url = venueUrl(v, g.base);
            if (url.isEmpty()) continue;
            Button b = button("🌐 " + v + " par " + g.base + " kholen", CHIP, YELLOW, YELLOW);
            b.setOnClickListener(x -> {
                if (v.startsWith("Binance")) BinanceLink.open(this, g.base, v.endsWith("Futures"));
                else openUrl(url);
            });
            c.addView(b);
        }
        if (g.kind.equals(Mispricing.CROSS) || (g.kind.equals(Mispricing.ERROR) && g.buyPrice > 0)) arbCalculator(col, g);
        Button an = button("📈 " + g.base + " ka chart / analysis", ACC, INK, 0);
        an.setOnClickListener(x -> { closeInfo(); openAnalyze(g.base + "USDT"); });
        c.addView(an);
        learnToggle(c, "Arbitrage = ek hi cheez do jagah alag qeemat par. Gap tabhi faida deta hai jab: (1) fees ke baad bhi bache, (2) order book mein itni "
                + "miqdaar ho, (3) dono taraf paisa pehle se ho, (4) deposit/withdraw khule hon. Price error aksar chhote exchange par hota hai jahan order book patli hai.");
    }

    // ============================================================ v22: 📊 INDICATOR PROBABILITY (MACD · MA · RSI on M5 / M15 / M30)
    private void arrowLabCard(final LinearLayout parent, final String sym, final boolean yahoo) {
        final LinearLayout c = card(parent, 0xFF2962FF);
        c.addView(bold("📊 Indicator probability — MACD · MA · RSI (M5 · M15 · M30)", 15, TEXT));
        final TextView wait = text("Pichli ~1000 candles har timeframe par replay ho rahi hain...", 12, MUTED);
        c.addView(wait);
        final LinearLayout page = infoOverlay;
        pool.execute(() -> {
            try {
                final List<ArrowLab.TfResult> l = ArrowLab.run(sym, yahoo);
                runOnUiThread(() -> {
                    if (infoOverlay != page) return;
                    c.removeView(wait);
                    c.addView(bold(ArrowLab.verdict(l), 15, TEXT));
                    for (ArrowLab.TfResult t : l) {
                        c.addView(divider());
                        c.addView(bold("⏱ " + t.tf.toUpperCase(Locale.US).replace("M", "") + " min chart", 14, ACC2));
                        for (int r = 0; r < ArrowLab.RULES.length; r++) {
                            int side = t.now[r][0];
                            ArrowLab.Stat b = ArrowLab.find(t, r, true), s = ArrowLab.find(t, r, false);
                            String now = side == 0 ? "abhi arrow nahi" : (side > 0 ? "▲ BUY arrow " : "▼ SELL arrow ") + (t.now[r][1] == 0 ? "ABHI" : t.now[r][1] + " candle pehle");
                            c.addView(bold((r == 3 ? "⭐ " : "") + ArrowLab.RULES[r] + " — " + now, 13, side > 0 ? GREEN : side < 0 ? RED : SOFT));
                            for (ArrowLab.Stat st : new ArrowLab.Stat[]{b, s}) {
                                if (st == null) continue;
                                String line = st.n < 5 ? (st.buy ? "  ▲ BUY: " : "  ▼ SELL: ") + "data kam (" + st.n + " arrows)"
                                        : String.format(Locale.US, "  %s %d arrows · %d candles baad sahi: %.0f%% · avg %+.2f%% · best exit %d candles (%+.2f%%) · 👉 %s",
                                        st.buy ? "▲ BUY:" : "▼ SELL:", st.n, st.holdBars, st.winPct, st.avgPct, st.bestBars, st.bestAvgPct, st.exitTip);
                                int col = st.n < 5 ? MUTED : st.winPct >= 55 && st.avgPct > 0 ? GREEN : st.winPct < 45 ? RED : SOFT;
                                c.addView(text(line, 11, col));
                            }
                        }
                    }
                    learnToggle(c, "Har arrow ka matlab: MACD line signal ko kaate (MACD), EMA9 EMA21 ko kaate (MA), RSI 30 se upar nikle ya 70 se neeche aaye (RSI). "
                            + "⭐ MACD+MA+RSI = teeno ek saath — sab se kam magar sab se saaf arrows. Bot ne isi coin ki pichli ~1000 candles par har arrow ke baad dekha: "
                            + "6 candles baad price kitni dafa sahi taraf gayi (win %), ausat kitna move, kitni candles baad exit sab se behtar tha, aur 1.5×ATR target pehle laga ya "
                            + "1×ATR stop. 55%+ aur avg + ho to arrow is coin par kaam karta hai; 45% se kam ho to us arrow ko ULTA samjhein ya chhor dein. "
                            + "Exit: '✕ exit' chart par bhi dikhta hai — ulta arrow, EMA9/21 wapas cross, ya RSI 75+ se mudna. Yeh history hai, guarantee nahi.");
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> wait.setText("Data nahi mila: " + m));
            }
        });
    }

    // ============================================================ v22: 🇨🇳 CHINA PULSE
    private void openChina() {
        final LinearLayout col = openPage("🇨🇳 China pulse");
        final LinearLayout page = infoOverlay;
        LinearLayout c = card(col, RED);
        c.addView(bold("China crypto aur gold ko kaise hilata hai", 15, TEXT));
        c.addView(text("• USDT OTC premium: China mein log P2P par yuan de kar USDT khareedte hain. Premium (+) = Chinese paisa crypto mein aa raha; discount (−) = bech rahe.\n"
                + "• Yuan kamzor ho to Chinese bachat aksar gold aur BTC mein bhaagti hai.\n"
                + "• Hang Seng / Shanghai upar = Asia mein risk-ON mood.\n"
                + "• China news: PBOC, Hong Kong ETFs, pabandi waghera.\n"
                + "Yeh sab Crypto aur Gold ke analysis mein '🇨🇳 China pulse' section ban kar signal score mein shamil hai.", 12, SOFT));
        final LinearLayout box = column();
        col.addView(box);
        box.addView(text("Load ho raha hai...", 13, MUTED));
        pool.execute(() -> {
            final ChinaPulse.Result r = ChinaPulse.fetch(60_000L);
            runOnUiThread(() -> {
                if (infoOverlay != page) return;
                box.removeAllViews();
                LinearLayout k = card(box, r.cryptoScore > 15 ? GREEN : r.cryptoScore < -15 ? RED : YELLOW);
                k.addView(bold(String.format(Locale.US, "Crypto ke liye: %+d  ·  Gold ke liye: %+d", r.cryptoScore, r.goldScore), 16,
                        r.cryptoScore > 15 ? GREEN : r.cryptoScore < -15 ? RED : TEXT));
                k.addView(text(r.cryptoScore > 15 ? "🟢 China se crypto ko sahara" : r.cryptoScore < -15 ? "🔴 China se crypto par dabao" : "⚪ China neutral", 13, SOFT));
                for (String l : r.lines) k.addView(text("• " + l, 13, SOFT));
            });
        });
    }

    // BTC/USD live (Coinbase) on the crypto market tab
    private TextView usdView;

    private void updateUsdPrices() {
        if (usdView == null || currentTab != 0 || (mktSeg != 0 && mktSeg != 3)) return;
        pool.execute(() -> {
            StringBuilder sb = new StringBuilder();
            for (String p : new String[]{"BTC-USD", "ETH-USD"}) {
                try {
                    JSONObject o = new JSONObject(Scanner.getAbsolute("https://api.exchange.coinbase.com/products/" + p + "/ticker"));
                    double px = o.optDouble("price", 0);
                    usdPx.put(p, px);
                    double[] u = mk.get(p.substring(0, 3) + "USDT");
                    String prem = u != null && u[0] > 0 ? String.format(Locale.US, " (USDT se %+.2f%%)", (px / u[0] - 1) * 100) : "";
                    sb.append(p.startsWith("BTC") ? "₿ BTC/USD $" : "   Ξ ETH/USD $").append(Fmt.price(px)).append(prem);
                } catch (Exception ignored) {
                }
            }
            final String t = sb.toString();
            runOnUiThread(() -> {
                if (!t.isEmpty()) usdView.setText(t + "  ● Coinbase · tap = chart");
                for (Map.Entry<String, TextView> e : usdRowPx.entrySet()) {
                    Double v = usdPx.get(e.getKey());
                    if (v != null) e.getValue().setText("$" + Fmt.price(v));
                }
            });
        });
    }

    // ============================================================ v23: 📖 READ THE NEWS INSIDE THE APP
    /** Loads the article (text + pictures) into `box`, under the button that started it. */
    private void readInto(final LinearLayout box, final String url) {
        box.removeAllViews();
        final TextView w = text("⏳ Khabar load ho rahi hai (text + tasveeren)...", 12, MUTED);
        box.addView(w);
        final int maxW = getResources().getDisplayMetrics().widthPixels;
        pool.execute(() -> {
            try {
                final ArticleReader.Article a = ArticleReader.read(url);
                runOnUiThread(() -> {
                    box.removeAllViews();
                    LinearLayout c = card(box, CYAN_TXT);
                    if (!a.title.isEmpty()) c.addView(bold(a.title, 17, TEXT));
                    c.addView(text("📰 " + a.site + " · ParaDox reader", 11, MUTED));
                    if (!a.image.isEmpty()) addImage(c, a.image, maxW);
                    int paras = 0;
                    for (ArticleReader.Block b : a.blocks) {
                        if (b.img != null) { addImage(c, b.img, maxW); continue; }
                        TextView t = b.heading ? bold(b.text, 15, TEXT) : text(b.text, 14, SOFT);
                        t.setTextIsSelectable(true);
                        t.setLineSpacing(dp(2), 1f);
                        t.setPadding(0, dp(b.heading ? 10 : 6), 0, dp(2));
                        c.addView(t);
                        if (!b.heading) paras++;
                    }
                    if (paras == 0) c.addView(text("Is website ne apni khabar ka text band rakha hai (paywall / app-only). Neeche se asal page khol sakte hain.", 13, YELLOW));
                    TextView o = chip("🌐 Asal page kholen", false);
                    o.setOnClickListener(v -> openUrl(a.url));
                    LinearLayout.LayoutParams ol = new LinearLayout.LayoutParams(-2, -2);
                    ol.topMargin = dp(10);
                    c.addView(o, ol);
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> {
                    w.setText("❌ Khabar load nahi hui (" + m + ") — kuch sites app ke andar parhne nahi deti.");
                    TextView o = chip("🌐 Asal page kholen", false);
                    o.setOnClickListener(v -> openUrl(url));
                    box.addView(o);
                });
            }
        });
    }

    private void addImage(final LinearLayout parent, final String url, final int maxW) {
        final android.widget.ImageView iv = new android.widget.ImageView(this);
        iv.setAdjustViewBounds(true);
        iv.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(8);
        parent.addView(iv, lp);
        pool.execute(() -> {
            final android.graphics.Bitmap bm = ArticleReader.image(url, Math.min(1200, maxW));
            runOnUiThread(() -> {
                if (bm != null) iv.setImageBitmap(bm);
                else parent.removeView(iv);
            });
        });
    }

    /** "Read here" button + related stories for a headline (news detail and catalyst detail). */
    private void readerSection(LinearLayout col, final String link, final String title, final List<String> coins) {
        final LinearLayout box = column();
        Button rd = button("📖 Poori khabar yahin parhein (text + tasveeren)", CYAN_TXT, INK, 0);
        rd.setOnClickListener(v -> readInto(box, link));
        if (link != null && !link.isEmpty()) {
            col.addView(rd);
            col.addView(box);
        }
        // related stories from the news radar (same coin or same words)
        java.util.Set<String> w = NewsEngine.words(title == null ? "" : title);
        List<NewsEngine.Item> rel = new ArrayList<>();
        for (NewsEngine.Item it : NewsEngine.cached()) {
            if (it.title.equals(title)) continue;
            int common = 0;
            for (String x : NewsEngine.words(it.title)) if (w.contains(x)) common++;
            boolean coin = false;
            for (String c0 : coins) if (it.coins.contains(c0)) coin = true;
            if (common >= 2 || (coin && common >= 1) || (coin && rel.size() < 4)) rel.add(it);
            if (rel.size() >= 10) break;
        }
        if (rel.isEmpty()) return;
        LinearLayout c = card(col);
        c.addView(bold("📰 Is se judi aur khabrein (" + rel.size() + ")", 15, TEXT));
        for (final NewsEngine.Item it : rel) {
            LinearLayout r = column();
            r.setPadding(0, dp(8), 0, dp(4));
            r.addView(bold(it.title, 13, TEXT));
            r.addView(text(ago(it.time) + " · " + it.source + " · " + NewsEngine.dirLabel(it), 11, MUTED));
            final LinearLayout sub = column();
            TextView ld = chip("📖 Load karein", false);
            ld.setTextSize(11);
            ld.setOnClickListener(v -> readInto(sub, it.link));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.topMargin = dp(4);
            r.addView(ld, lp);
            r.addView(sub);
            c.addView(r);
            c.addView(divider());
        }
    }

    // ============================================================ v23: arbitrage profit calculator
    private void arbCalculator(LinearLayout parent, final Mispricing.Gap g) {
        final LinearLayout c = card(parent, GREEN);
        c.addView(bold("🧮 Profit calculator", 16, TEXT));
        LinearLayout r1 = row();
        final EditText amt = calcField(r1, "Kitne USDT ka khareedna", "1000");
        r1.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        final EditText buyPx = calcField(r1, g.buyVenue + " buy price", Fmt.price(g.buyPrice));
        c.addView(r1);
        LinearLayout r2 = row();
        final EditText sellPx = calcField(r2, g.sellVenue + " sell price", Fmt.price(g.sellPrice));
        r2.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        final EditText fb = calcField(r2, g.buyVenue + " fee %", String.format(Locale.US, "%.2f", Mispricing.fee(g.buyVenue)));
        c.addView(r2);
        LinearLayout r3 = row();
        final EditText fs = calcField(r3, g.sellVenue + " fee %", String.format(Locale.US, "%.2f", Mispricing.fee(g.sellVenue)));
        r3.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        final EditText wf = calcField(r3, "Transfer (withdraw) fee — " + g.base + " coins", "0");
        c.addView(r3);
        final TextView wfNote = text("Withdraw fee dhoondi ja rahi hai...", 11, MUTED);
        c.addView(wfNote);
        final TextView out = text("", 13, TEXT);
        final Runnable calc = () -> {
            double a = parse(amt, 0), bp = parse(buyPx, 0), sp = parse(sellPx, 0), f1 = parse(fb, 0.1) / 100, f2 = parse(fs, 0.1) / 100, wfee = parse(wf, 0);
            if (a <= 0 || bp <= 0 || sp <= 0) { out.setText("Amount aur prices likhen"); return; }
            double buyFeeUsd = a * f1;
            double coins = (a - buyFeeUsd) / bp;
            double moved = Math.max(0, coins - wfee);
            double gross = moved * sp;
            double sellFeeUsd = gross * f2;
            double back = gross - sellFeeUsd;
            double profit = back - a;
            double noTransfer = coins * sp * (1 - f2) - a;
            double wfeeUsd = wfee * sp;
            double be = moved > 0 ? a / (moved * (1 - f2)) : 0;
            out.setText(String.format(Locale.US,
                    "1️⃣ %s par khareed: $%.2f → fee −$%.2f → %s %s\n"
                            + "2️⃣ Transfer fee: −%s %s (≈ −$%.2f) → %s %s pohanchenge\n"
                            + "3️⃣ %s par bech: $%.2f → fee −$%.2f → $%.2f wapas\n\n"
                            + "%s TRANSFER KE SAATH: %s$%.2f (%+.2f%%)\n"
                            + "%s Dono taraf pehle se paisa (transfer nahi): %s$%.2f (%+.2f%%)\n\n"
                            + "Break-even: %s par sell price kam az kam $%s honi chahiye",
                    g.buyVenue, a, buyFeeUsd, n6(coins), g.base,
                    n6(wfee), g.base, wfeeUsd, n6(moved), g.base,
                    g.sellVenue, gross, sellFeeUsd, back,
                    profit >= 0 ? "🟢" : "🔴", profit >= 0 ? "+" : "−", Math.abs(profit), profit / a * 100,
                    noTransfer >= 0 ? "🟢" : "🔴", noTransfer >= 0 ? "+" : "−", Math.abs(noTransfer), noTransfer / a * 100,
                    g.sellVenue, Fmt.price(be)));
            out.setTextColor(profit >= 0 ? GREEN : RED);
        };
        TextView cb = chip("Calculate", true);
        cb.setOnClickListener(v -> { hideKeyboard(); calc.run(); });
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-2, -2);
        cl.topMargin = dp(6);
        c.addView(cb, cl);
        c.addView(out);
        c.addView(text("Fees: standard taker fee (VIP / BNB / token discount ke baghair). Transfer fee har network par alag hoti hai — sab se sasta network chunein. "
                + "Transfer mein minute–ghante lagte hain; tab tak gap band ho sakta hai, isi liye 'pehle se paisa' wala hisaab asal arbitrage hai.", 11, MUTED));
        calc.run();
        pool.execute(() -> {
            final double f = Transfers.withdrawFee(g.buyVenue, g.base);
            runOnUiThread(() -> {
                if (!Double.isNaN(f)) {
                    wf.setText(n6(f));
                    wfNote.setText("✅ " + g.buyVenue + " ki sab se sasti withdraw fee: " + n6(f) + " " + g.base + " (≈ $" + Fmt.price(f * g.sellPrice) + ")");
                } else wfNote.setText(g.buyVenue + " withdraw fee bina key ke nahi batata — app mein dekh kar khud likhen (aksar $0.5–$5 ke barabar coins).");
                calc.run();
            });
        });
    }

    private static String n6(double v) {
        if (v == 0) return "0";
        if (Math.abs(v) >= 1000) return String.format(Locale.US, "%,.2f", v);
        if (Math.abs(v) >= 1) return String.format(Locale.US, "%.4f", v);
        return String.format(Locale.US, "%.8f", v);
    }

    // ============================================================ v24/v26: 🎯 GAINER / LOSER HUNTER (bottom tab, live)
    private int huntTab = 0;
    private LinearLayout huntList, huntProg;
    private TextView huntStatus;
    private volatile boolean huntBusy;
    private final Map<String, PumpHunter.Pick> huntLive = new java.util.concurrent.ConcurrentHashMap<>();
    private long huntLiveDraw;

    private void openHunter() {
        closeInfo();
        showTab(TAB_HUNT);
    }

    private void buildHunter() {
        LinearLayout col = pageColumn(TAB_HUNT);
        LinearLayout top = card(col, GREEN);
        top.addView(bold("🎯 Gainer / Loser Hunter — khud-mukhtar, 24/7", 16, TEXT));
        top.addView(text("Top gainers / losers list mein aane se PEHLE pakarta hai. Har scan mein: ~400 Binance coins ka Relative Volume (5m/15m/1h) · "
                + "Price-Volume Divergence (volume aaya, price abhi nahi hili) · aggressive buyers / sellers · order book imbalance · Futures (OI, funding, "
                + "taker ratio, 🐋 top traders) · 🇰🇷 Korea: Upbit, Bithumb, Coinone, Korbit + kimchi premium · 🌐 OKX, Bybit, Bitget, KuCoin, Gate, MEXC, HTX, "
                + "Bitfinex, Binance Futures · 🔥 CoinGecko trending · 💸 DexScreener boosts · 🗣️ news / X posts · 📆 catalysts. Pichle nateejon se khud seekhta hai.\n🏆 Pure hunt = 3+ scans mein mustaqil + research (use case, unlocks, events, news) + plan (entry, SL support ke neeche, TP resistance ke upar, imkaan %). Alert sirf pure hunt par.", 12, MUTED));
        toggle(top, "🔔 24/7 hunter + lock-screen alerts", "App band / screen off ho tab bhi scan · score aap ki had se upar ho to foran notification", Prefs.huntOn(this), (b, on) -> {
            Prefs.setHuntOn(this, on);
            restartService();
            toast(on ? "🎯 Hunter 24/7 ON" : "Hunter OFF");
        });
        LinearLayout sr = row();
        sr.addView(text("Alert score ≥", 12, SOFT), chipLp());
        final int[] ms = {55, 65, 75, 85};
        final TextView[] mc = new TextView[ms.length];
        for (int i = 0; i < ms.length; i++) {
            final int k = i;
            mc[i] = chip(String.valueOf(ms[i]), Prefs.huntMinScore(this) == ms[i]);
            mc[i].setTextSize(11);
            mc[i].setOnClickListener(v -> { Prefs.setHuntMinScore(this, ms[k]); for (int z = 0; z < ms.length; z++) styleChip(mc[z], z == k); renderHunt(); });
            sr.addView(mc[i], chipLp());
        }
        sr.addView(text("  Background scan:", 12, SOFT), chipLp());
        final int[] ev = {60, 120, 300};
        final TextView[] ec = new TextView[ev.length];
        for (int i = 0; i < ev.length; i++) {
            final int k = i;
            ec[i] = chip((ev[i] / 60) + "m", Prefs.huntEverySec(this) == ev[i]);
            ec[i].setTextSize(11);
            ec[i].setOnClickListener(v -> { Prefs.setHuntEverySec(this, ev[k]); for (int z = 0; z < ev.length; z++) styleChip(ec[z], z == k); });
            sr.addView(ec[i], chipLp());
        }
        top.addView(hscroll(sr));
        LinearLayout vr = row();
        vr.addView(text("Volume confirmation ≥", 12, SOFT), chipLp());
        final int[] vcs = {75, 80, 85};
        final TextView[] vcc = new TextView[vcs.length];
        for (int i = 0; i < vcs.length; i++) {
            final int k = i;
            vcc[i] = chip(vcs[i] + "%", Prefs.huntVolConf(this) == vcs[i]);
            vcc[i].setTextSize(11);
            vcc[i].setOnClickListener(v -> { Prefs.setHuntVolConf(this, vcs[k]); for (int z = 0; z < vcs.length; z++) styleChip(vcc[z], z == k); renderHunt(); });
            vr.addView(vcc[i], chipLp());
        }
        top.addView(hscroll(vr));
        top.addView(text("✔️ Volume confirmation = volume kitna bara (RVOL), kitni der se (1h), ek taraf ka dabao (buyers/sellers) aur doosre exchanges / Korea / order book "
                + "se tasdeeq. Is had se kam wala coin na dikhaya jata hai na hunt hota hai.", 11, MUTED));
        top.addView(text("📶 Tab khula ho to har ~60 sec live scan. 13 exchanges ka data bhi aata hai — Wi-Fi behtar; mobile data par background 2m–5m rakhein.", 11, MUTED));
        huntStatus = bold("Pehla scan shuru ho raha hai...", 12, ACC2);
        top.addView(huntStatus);
        huntProg = column();
        top.addView(huntProg);
        Button sn = button("🔄 Abhi hunt karein", GREEN, INK, 0);
        sn.setOnClickListener(v -> runHunt());
        top.addView(sn);
        Button ai = button("🤖 AI se faisla lein — kaun sa sab se mazboot? (Gemini / Groq)", CLAUDE, INK, 0);
        final LinearLayout aiBox = column();
        ai.setOnClickListener(v -> huntAi(aiBox));
        top.addView(ai);
        top.addView(aiBox);
        Button gpt = button("💬 ChatGPT (FREE) — sign up / login + baat karein", 0xFF10A37F, INK, 0);
        gpt.setOnClickListener(v -> openChatGpt(null));
        top.addView(gpt);
        top.addView(text("Kisi bhi hunt hue coin par tap karein → '💬 ChatGPT se trading plan' — coin ki saari details ChatGPT ko khud chali jati hain.", 11, MUTED));

        LinearLayout tc = card(col);
        LinearLayout tr = row();
        final String[] tn = {"🏆 Pure hunts", "👀 Jaanch jaari", "🔴 Live", "📜 Log", "📊 Record", "📈 Gainers check"};
        final TextView[] tcs = new TextView[tn.length];
        for (int i = 0; i < tn.length; i++) {
            final int k = i;
            tcs[i] = chip(tn[i], i == huntTab);
            tcs[i].setTextSize(11);
            tcs[i].setOnClickListener(v -> { huntTab = k; for (int z = 0; z < tn.length; z++) styleChip(tcs[z], z == k); renderHunt(); });
            tr.addView(tcs[i], chipLp());
        }
        tc.addView(hscroll(tr));
        huntList = column();
        col.addView(huntList);
        renderHunt();
    }

    private void huntProgress(String t, int done, int total) {
        if (huntStatus == null) return;
        huntStatus.setText("⏳ " + t);
        huntProg.removeAllViews();
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, dp(5));
        bl.topMargin = dp(4);
        huntProg.addView(bar(total > 0 ? done * 100.0 / total : 0, GREEN, 0xFF243049), bl);
    }

    private void runHunt() {
        if (huntBusy || PumpHunter.busy()) return;
        huntBusy = true;
        huntLive.clear();
        huntProgress("Scan shuru...", 0, 6);
        pool.execute(() -> {
            PumpHunter.Result r = null;
            try {
                r = PumpHunter.scan(this, new PumpHunter.Listener() {
                    @Override
                    public void stage(String t, int done, int total) {
                        runOnUiThread(() -> { if (huntBusy) huntProgress(t, done, total); });
                    }

                    @Override
                    public void found(PumpHunter.Pick p) {
                        huntLive.put(p.key(), p);
                        runOnUiThread(() -> {
                            long now = System.currentTimeMillis();
                            if (currentTab == TAB_HUNT && huntTab <= 2 && now - huntLiveDraw > 700) { huntLiveDraw = now; renderHunt(); }
                        });
                    }
                });
                PumpHunter.Track.resolve(this);
                PumpHunter.alert(this, r);
            } catch (Exception ignored) {
            } finally {
                huntBusy = false;
            }
            runOnUiThread(() -> {
                if (huntProg != null) huntProg.removeAllViews();
                if (currentTab == TAB_HUNT) renderHunt();
            });
        });
    }

    private void renderHunt() {
        if (huntList == null) return;
        huntList.removeAllViews();
        PumpHunter.Result r = PumpHunter.cached();
        int min = Prefs.huntMinScore(this);
        if (!huntBusy && r != null && huntStatus != null) {
            huntStatus.setText("🟢 LIVE · aakhri scan " + new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date(r.at)) + " · " + r.scanned + " Binance coins + "
                    + PumpHunter.VENUES.length + " exchanges · " + (r.ms / 1000) + " sec · 🚀 " + r.pumps.size() + " · 🩸 " + r.dumps.size()
                    + (r.note.isEmpty() ? "" : " · " + r.note) + " · agla scan ~60 sec mein");
        }
        if (huntTab == 4) { renderHuntRecord(); return; }
        if (huntTab == 5) { renderGainersCheck(); return; }
        if (huntTab == 0) { renderPure(); return; }
        if (huntTab == 1) { renderWatching(); return; }
        List<PumpHunter.Pick> l = new ArrayList<>();
        String empty;
        if (huntTab == 3) {
            l = PumpHunter.HuntLog.all(this);
            huntList.addView(text("📜 Har hunt hua coin — kis din, kis waqt pakra, us waqt price, aur ab tak kitna chala. (Score 50+, aakhri 80)", 12, MUTED));
            empty = "Abhi log khali hai — hunter chalta rahe, jo bhi coin pakra jayega yahan time + date ke saath aayega.";
        } else {
            boolean live = huntBusy && !huntLive.isEmpty();
            if (live) {
                l.addAll(huntLive.values());
                huntList.addView(bold("🔴 Scan jaari — jo coin abhi mil rahe hain, foran yahan aa rahe hain:", 12, RED));
            } else if (r != null) {
                l.addAll(r.pumps);
                l.addAll(r.dumps);
            }
            Collections.sort(l, (a, b) -> b.score - a.score);
            empty = r == null && !huntBusy ? "Scan chal raha hai..." : huntBusy && l.isEmpty() ? "🔍 Dhoond raha hai... coin milte hi yahan nazar aayenge."
                    : "Abhi koi coin pump / dump ke nishaan nahi de raha. Bot har ~60 sec dobara dekhega.";
        }
        if (huntTab == 2) {   // v31: only coins with enough volume confirmation
            int vcMin = Prefs.huntVolConf(this), hidden = 0;
            List<PumpHunter.Pick> keep = new ArrayList<>();
            for (PumpHunter.Pick p : l) if (p.volConf >= vcMin) keep.add(p); else hidden++;
            l = keep;
            if (hidden > 0) huntList.addView(text(hidden + " coins chhupaye — volume confirmation " + vcMin + "% se kam (shor)", 11, MUTED));
        }
        if (l.isEmpty()) { huntList.addView(text("\n" + empty, 13, MUTED)); return; }
        for (final PumpHunter.Pick p : l) huntCard(p, min, huntTab == 3);
    }

    private void huntCard(final PumpHunter.Pick p, int min, boolean log) {
        int col = p.pump ? GREEN : RED;
        LinearLayout c = card(huntList, p.score >= min ? col : STROKE);
        LinearLayout h = row();
        String badge = "MOMENTUM".equals(p.stage) ? "  🔥 MOMENTUM" : "EARLY".equals(p.stage) ? "  🎯 EARLY" : "LATE".equals(p.stage) ? "  ⚠️ LATE" : "BREAKOUT".equals(p.stage) ? "  ⚡ MOMENTUM" : "";
        h.addView(bold((p.pump ? "🚀 " : "🩸 ") + p.base + badge, 16, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        h.addView(bold(p.score + "/100" + (p.score >= min ? " 🔔" : ""), 15, col));
        c.addView(h);
        c.addView(bold("✔️ Volume confirmation " + p.volConf + "%", 12, p.volConf >= Prefs.huntVolConf(this) ? GREEN : YELLOW));
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, dp(6));
        bl.topMargin = dp(4);
        c.addView(bar(p.score, col, 0xFF243049), bl);
        long first = p.firstAt;
        if (first <= 0) {
            PumpHunter.Pick old = PumpHunter.HuntLog.find(this, p.key());
            first = old != null && System.currentTimeMillis() - old.at < 6 * 3600_000L ? old.firstAt : (p.at > 0 ? p.at : System.currentTimeMillis());
        }
        c.addView(bold("🕒 Hunt hua: " + PumpHunter.when(first), 12, ACC2));
        double now = PumpHunter.priceNow(p), fp = p.firstPrice > 0 ? p.firstPrice : p.price;
        if (now > 0 && fp > 0 && (log || Math.abs(now / fp - 1) > 0.0005)) {
            double mv = (now / fp - 1) * 100;
            c.addView(text(String.format(Locale.US, "Pakarte waqt $%s → ab $%s (%+.2f%%) · raw ishara — faisla sirf 🏆 Pure hunt par", Fmt.price(fp), Fmt.price(now), mv), 12, SOFT));
        }
        c.addView(text(String.format(Locale.US, "%s · %s · 15m %+.1f%% · 1h %+.1f%% · 24h %+.1f%% · vol %s", p.venue, p.price > 0 ? "$" + Fmt.price(p.price) : "—",
                p.ch15, p.ch1h, p.ch24, Fmt.usd(p.vol24)), 12, SOFT));
        for (int i = 0; i < p.why.size() && i < 3; i++) c.addView(text("• " + p.why.get(i), 11, MUTED));
        c.addView(text("📍 " + p.src.size() + " jagah se saboot · tap karein: poori tafseel", 11, CYAN_TXT));
        c.setOnClickListener(v -> openPick(p));
    }

    private void renderHuntRecord() {
        double[] st = PumpHunter.Track.stats(this);
        LinearLayout c = card(huntList, CYAN_TXT);
        c.addView(bold("📊 Hunter ka asal record", 15, TEXT));
        c.addView(text("Sirf 🏆 Pure hunts gine jate hain. ✅ = TP1 (resistance toot kar) stop se pehle · ❌ = support ke neeche stop · ⌛ = 10 din mein dono nahi. "
                + "TP1 ke baad stop entry par chala jata hai. 1h candles se check hota hai — 0.3% ki chhoti harkat se koi faisla nahi.", 12, MUTED));
        if (st[0] == 0) c.addView(text("Abhi koi pure hunt mukammal nahi hua" + (st.length > 4 && st[4] > 0 ? " (" + (int) st[4] + " open)" : "") + " — nateeje aane mein ghante / din lagte hain.", 13, SOFT));
        else {
            c.addView(bold(String.format(Locale.US, "%.0f mukammal · ✅ %.0f TP1+ (%.0f%%) · ❌ %.0f stop · ⌛ %.0f · ⏳ %.0f open", st[0], st[1], st[1] * 100 / st[0], st[2],
                    st[0] - st[1] - st[2], st[4]), 14, st[1] * 100 / st[0] >= 45 ? GREEN : YELLOW));
            c.addView(text(String.format(Locale.US, "Ausat sab se bari sahi-taraf harkat: %.1f%%", st[3]), 13, SOFT));
        }
        String fr = PumpHunter.Track.featureReport(this);
        c.addView(text(fr.isEmpty() ? "🧠 Learning: 15+ nateejon ke baad bot khud seekhega ke kaun se nishaan is market mein sach mein kaam karte hain."
                : "🧠 Bot ne seekha (score par asar): " + fr, 12, CYAN_TXT));
    }

    // ============================================================ v29: 🏆 PURE hunts (confirmed + researched + full plan)
    private static String pureStatus(JSONObject o) {
        String st = o.optString("st");
        int hit = o.optInt("hit");
        switch (st) {
            case "open": return hit >= 1 ? "🎯 TP" + hit + " hit · chal raha" : "⏳ OPEN";
            case "sl": return String.format(Locale.US, "❌ STOP %+.1f%%", o.optDouble("pnl"));
            case "exp": return String.format(Locale.US, "⌛ 10 din %+.1f%%", o.optDouble("pnl"));
            default: return String.format(Locale.US, "✅ %s %+.1f%%", st.toUpperCase(Locale.US), o.optDouble("pnl"));
        }
    }

    private void renderPure() {
        List<JSONObject> all = PumpHunter.Pure.all(this);
        huntList.addView(text("🏆 Sirf woh coins jo 3+ scans (10+ min) mein mustaqil nazar aaye, research paas ki (use case, unlocks, events, news), aur jin ka "
                + "plan reward ≥ 1.5× risk deta hai. WIN = resistance toot kar TP1 · LOSS = support ke neeche stop. 0.3% ki harkat se faisla nahi hota.", 12, MUTED));
        if (all.isEmpty()) {
            huntList.addView(text("\nAbhi koi pure hunt nahi. Bot jaanch kar raha hai — '👀 Jaanch jaari' tab mein dekhein kaun se coins line mein hain. "
                    + "Pure hunt kam aate hain (din mein kuch) — yahi un ki taqat hai.", 13, MUTED));
            return;
        }
        List<JSONObject> l = new ArrayList<>();
        for (JSONObject o : all) if ("open".equals(o.optString("st"))) l.add(o);
        for (JSONObject o : all) if (!"open".equals(o.optString("st"))) l.add(o);
        for (int i = 0; i < l.size() && i < 40; i++) {
            final JSONObject o = l.get(i);
            boolean up = o.optBoolean("pump");
            int col = up ? GREEN : RED;
            boolean open = "open".equals(o.optString("st"));
            LinearLayout c = card(huntList, open ? col : STROKE);
            LinearLayout h = row();
            h.addView(bold((up ? "🏆 BUY " : "🏆 SELL ") + o.optString("base"), 16, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
            String st = pureStatus(o);
            h.addView(bold(st + " · " + o.optInt("score"), 13, st.startsWith("❌") ? RED : st.startsWith("✅") || st.startsWith("🎯") ? GREEN : col));
            c.addView(h);
            c.addView(bold("🕒 Pehli dafa dekha " + PumpHunter.when(o.optLong("t")) + " · confirm " + new SimpleDateFormat("HH:mm", Locale.US).format(new Date(o.optLong("ct"))), 12, ACC2));
            c.addView(text((up ? "Buy zone $" : "Sell zone $") + Fmt.price(o.optDouble("elo")) + " – $" + Fmt.price(o.optDouble("ehi")) + " · 🛑 SL $" + Fmt.price(o.optDouble("sl")), 12, TEXT));
            c.addView(text(String.format(Locale.US, "🎯 TP1 $%s (%.0f%%) · TP2 $%s (%.0f%%) · TP3 $%s (%.0f%%) · 10 din", Fmt.price(o.optDouble("tp1")), o.optDouble("pr1"),
                    Fmt.price(o.optDouble("tp2")), o.optDouble("pr2"), Fmt.price(o.optDouble("tp3")), o.optDouble("pr3")), 12, SOFT));
            Double now = PumpHunter.LAST_PX.get("Binance:" + o.optString("base"));
            if (open && now != null && now > 0) {
                double mv = (now / o.optDouble("p") - 1) * 100;
                c.addView(text(String.format(Locale.US, "Ab $%s (entry se %+.2f%%) · sab se zyada %+.1f%%", Fmt.price(now), mv, o.optDouble("best")), 12, SOFT));
            }
            JSONObject in = o.optJSONObject("intel");
            if (in != null && !in.optString("pot").isEmpty()) c.addView(text("Multi-day potential: " + in.optString("pot"), 11, MUTED));
            c.setOnClickListener(v -> openPure(o));
        }
    }

    /** Today's top Binance gainers / losers — and whether the hunter caught them BEFORE (time, price then, % move after). */
    private void renderGainersCheck() {
        PumpHunter.Result r = PumpHunter.cached();
        huntList.addView(text("📈 Imaandar jaanch: aaj Binance ke sab se bare gainers / losers — kya hunter ne inhein pehle pakra? (pakarne ka waqt, us waqt price, us ke baad kitna chala)", 12, MUTED));
        if (r == null || r.topGainers.isEmpty()) { huntList.addView(text("\nPehla scan mukammal hone dein.", 13, MUTED)); return; }
        List<PumpHunter.Pick> log = PumpHunter.HuntLog.all(this);
        List<JSONObject> pure = PumpHunter.Pure.all(this);
        int caught = 0;
        for (int pass = 0; pass < 2; pass++) {
            List<Object[]> l = pass == 0 ? r.topGainers : r.topLosers;
            huntList.addView(bold(pass == 0 ? "\n🚀 Top gainers (24h)" : "\n🩸 Top losers (24h)", 14, pass == 0 ? GREEN : RED));
            for (Object[] g : l) {
                String b = (String) g[0];
                double ch = (Double) g[1], px = (Double) g[2];
                PumpHunter.Pick hit = null;
                for (PumpHunter.Pick p : log) if (b.equals(p.base) && p.pump == (pass == 0) && System.currentTimeMillis() - p.firstAt < 30 * 3600_000L) { hit = p; break; }
                JSONObject ph = null;
                for (JSONObject o : pure) if (b.equals(o.optString("base")) && o.optBoolean("pump") == (pass == 0) && System.currentTimeMillis() - o.optLong("ct") < 30 * 3600_000L) { ph = o; break; }
                LinearLayout c = card(huntList, ph != null ? GREEN : hit != null ? YELLOW : STROKE);
                c.addView(bold(String.format(Locale.US, "%s  %+.1f%% · $%s · vol %s", b, ch, Fmt.price(px), Fmt.usd((Double) g[3])), 14, TEXT));
                if (ph != null) {
                    caught++;
                    c.addView(text(String.format(Locale.US, "🏆 Pure hunt: %s · price tab $%s → ab %+.1f%%", PumpHunter.when(ph.optLong("ct")), Fmt.price(ph.optDouble("p")),
                            (px / ph.optDouble("p") - 1) * 100), 12, GREEN));
                } else if (hit != null) {
                    caught++;
                    c.addView(text(String.format(Locale.US, "👀 Raw pakra: %s · price tab $%s → ab %+.1f%% · score %d · vol ✔️ %d%%", PumpHunter.when(hit.firstAt), Fmt.price(hit.firstPrice),
                            hit.firstPrice > 0 ? (px / hit.firstPrice - 1) * 100 : 0, hit.bestScore, hit.volConf), 12, YELLOW));
                } else c.addView(text("❌ Hunter ne nahi pakra (shayad ek dam khabar / listing se, ya volume pehle nahi aaya)", 12, MUTED));
                final String sym = b + "USDT";
                c.setOnClickListener(v -> openAnalyze(sym));
            }
        }
        huntList.addView(text("\n" + caught + " / " + (r.topGainers.size() + r.topLosers.size()) + " coins hunter ki nazar mein pehle se thay.", 13, ACC2));
    }

    private void renderWatching() {
        huntList.addView(text("👀 Yeh coins abhi jaanch mein hain: 3 scans (10+ min) tak mustaqil rahein, ausat score 58+, price ulta na jaye — phir research aur plan. "
                + "Jo beech mein gayab ho jaye ya ulta chale, woh khud nikal jata hai (yeh 'fail' nahi, sirf shor tha).", 12, MUTED));
        List<Object[]> l = PumpHunter.Pure.watching();
        if (l.isEmpty()) { huntList.addView(text("\nAbhi koi coin jaanch mein nahi.", 13, MUTED)); return; }
        for (Object[] w : l) {
            final PumpHunter.Pick p = (PumpHunter.Pick) w[0];
            LinearLayout c = card(huntList, STROKE);
            LinearLayout h = row();
            h.addView(bold((p.pump ? "🚀 " : "🩸 ") + p.base, 15, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
            h.addView(bold(String.format(Locale.US, "%d/3 · score %.0f · vol ✔️ %.0f%%", (Integer) w[1], (Double) w[3], (Double) w[5]), 12, ACC2));
            c.addView(h);
            c.addView(text("🕒 Pehli dafa: " + PumpHunter.when((Long) w[2]) + " · " + String.valueOf(w[4]), 12, SOFT));
            c.setOnClickListener(v -> openPick(p));
        }
    }

    private void openPure(final JSONObject o) {
        final boolean up = o.optBoolean("pump");
        final String base = o.optString("base"), sym = o.optString("sym");
        LinearLayout col = openPage("🏆 " + base + " — pure hunt");
        int c0 = up ? GREEN : RED;
        double e = o.optDouble("p"), sl = o.optDouble("sl");
        double slPct = Math.abs(e - sl) / e * 100;

        LinearLayout hc = card(col, c0);
        hc.addView(bold((up ? "BUY — multi-day gainer hunt" : "SELL / EXIT — multi-day loser hunt") + " · " + o.optInt("score") + "/100", 16, c0));
        hc.addView(bold(pureStatus(o), 14, TEXT));
        hc.addView(text("🕒 Pehli dafa dekha: " + PumpHunter.when(o.optLong("t")) + "\n✅ Confirm (" + o.optInt("seen") + " scans + research): " + PumpHunter.when(o.optLong("ct"))
                + (o.has("et") ? "\n🏁 Band hua: " + PumpHunter.when(o.optLong("et")) : ""), 13, SOFT));
        Double now = PumpHunter.LAST_PX.get("Binance:" + base);
        if (now != null && now > 0) hc.addView(text(String.format(Locale.US, "Ab $%s · entry $%s se %+.2f%% · sab se zyada %+.1f%%", Fmt.price(now), Fmt.price(e), (now / e - 1) * 100, o.optDouble("best")), 13, TEXT));

        LinearLayout pc = card(col, ACC);
        pc.addView(bold("🧭 Trading plan", 15, TEXT));
        pc.addView(bold((up ? "🟢 Buy zone: $" : "🔴 Sell zone: $") + Fmt.price(o.optDouble("elo")) + " – $" + Fmt.price(o.optDouble("ehi")), 14, c0));
        pc.addView(text(up ? "Behtar: zone ke neeche wale hisse mein limit order (pullback). Price zone se bahut upar nikal jaye to peecha na karein."
                : "Holding ho to is zone mein bechein / profit bacha lein. Futures short sirf breakdown confirm hone par.", 12, MUTED));
        pc.addView(bold(String.format(Locale.US, "🛑 Stop loss: $%s (%.1f%% door) — %s $%s ke %s", Fmt.price(sl), slPct, up ? "support" : "resistance",
                Fmt.price(up ? o.optDouble("sup") : o.optDouble("res")), up ? "neeche" : "upar"), 13, RED));
        String[] tl = {"tp1", "tp2", "tp3"}, pl = {"pr1", "pr2", "pr3"};
        for (int i = 0; i < 3; i++) {
            double t = o.optDouble(tl[i]);
            pc.addView(bold(String.format(Locale.US, "🎯 TP%d: $%s (%+.1f%%) · imkaan %.0f%% (10 din)%s", i + 1, Fmt.price(t), (t / e - 1) * 100, o.optDouble(pl[i]),
                    i == 0 && o.optDouble("res") > 0 && up ? " — resistance $" + Fmt.price(o.optDouble("res")) + " tootne ke baad" : ""), 13, GREEN));
        }
        pc.addView(text(String.format(Locale.US, "Reward / risk (TP1): %.1fx · %s", o.optDouble("rr"), o.optString("plan")), 12, SOFT));
        pc.addView(text(String.format(Locale.US, "📊 Imkaan kaise nikla: is coin ke pichle %.0f dinon ki asal history — har din ko entry maan kar dekha ke 10 din mein pehle TP aaya ya SL "
                + "(SL pehle check, yani mohtaat). TP1 aksar ~%.0f din mein aaya.", o.optDouble("prn"), Math.max(1, o.optDouble("prd"))), 11, MUTED));
        if (o.optDouble("spn") >= 8) pc.addView(text(String.format(Locale.US, "🔥 Sirf woh din jab is coin par 2x+ volume aaya (%.0f dafa): TP1 %.0f%% dafa SL se pehle.",
                o.optDouble("spn"), o.optDouble("sp1")), 11, MUTED));
        pc.addView(text(String.format(Locale.US, "💼 $100 account, 1%% risk ($1): position ~$%.0f · 2%% risk ($2): ~$%.0f. TP1 par 1/3 bechein aur stop entry par le aayen, TP2 par 1/3, TP3 par baqi.",
                1 / (slPct / 100), 2 / (slPct / 100)), 12, YELLOW));

        LinearLayout rc = card(col, CYAN_TXT);
        rc.addView(bold("🔬 Research — coin ke baare mein", 15, TEXT));
        JSONArray info = o.optJSONArray("info");
        if (info != null) for (int i = 0; i < info.length(); i++) rc.addView(text(info.optString(i), 13, SOFT));
        JSONObject in = o.optJSONObject("intel");
        if (in != null) {
            rc.addView(bold("Multi-day potential: " + in.optString("pot"), 13, TEXT));
            addList(rc, in.optJSONArray("plus"), "✅ ", GREEN);
            addList(rc, in.optJSONArray("minus"), "⚠️ ", YELLOW);
            JSONArray un = in.optJSONArray("unl"), ev = in.optJSONArray("ev"), nw = in.optJSONArray("news");
            rc.addView(bold("🔓 Token unlocks (30 din)", 13, TEXT));
            if (un == null || un.length() == 0) rc.addView(text("Koi bara unlock nazar nahi aaya", 12, MUTED)); else addList(rc, un, "", SOFT);
            rc.addView(bold("📆 Events / listings / launches", 13, TEXT));
            if (ev == null || ev.length() == 0) rc.addView(text("Koi event nahi mila (CoinMarketCal key Settings mein daalne se zyada events)", 12, MUTED)); else addList(rc, ev, "", SOFT);
            rc.addView(bold("📰 News + 𝕏 / social (3 din)", 13, TEXT));
            if (nw == null || nw.length() == 0) rc.addView(text("Is coin ki koi taaza khabar nahi", 12, MUTED)); else addList(rc, nw, "", SOFT);
        }

        LinearLayout wc = card(col, c0);
        wc.addView(bold("🔎 Kaise pakra", 15, TEXT));
        addList(wc, o.optJSONArray("why"), "• ", SOFT);
        wc.addView(bold("📍 Kahan se", 13, TEXT));
        addList(wc, o.optJSONArray("src"), "• ", SOFT);

        LinearLayout ac = card(col);
        Button an = button("📈 " + base + " chart + analysis", ACC, INK, 0);
        an.setOnClickListener(v -> { closeInfo(); openAnalyze(sym); });
        ac.addView(an);
        Button bn = button("🟡 Binance mein kholen", 0xFFF0B90B, INK, 0);
        bn.setOnClickListener(v -> BinanceLink.open(this, base, !up));
        ac.addView(bn);
        final String prompt = gptPromptPure(o);
        Button gp = button("💬 ChatGPT se is plan ki dobara jaanch (FREE)", 0xFF10A37F, INK, 0);
        gp.setOnClickListener(v -> openChatGpt(prompt));
        ac.addView(gp);
        final LinearLayout chat = column();
        Button ai = button("🤖 Gemini / Groq se raaye", CLAUDE, INK, 0);
        ai.setOnClickListener(v -> askAi(prompt, chat, new ArrayList<>(), "Is plan ko jaancho: entry, stop, targets theek hain? Sab se bara khatra kya hai?"));
        ac.addView(ai);
        ac.addView(chat);
        ac.addView(text("⚠️ Imkaan pichli history se hai, guarantee nahi. 'Insider' yahan public footprint hai (volume, Korea, unlocks, events, news, X) — asal andar ki "
                + "khabar kisi free app ke paas nahi hoti. Har trade stop ke saath, chhoti position.", 11, MUTED));
    }

    private void addList(LinearLayout c, JSONArray a, String pre, int color) {
        if (a == null) return;
        for (int i = 0; i < a.length(); i++) c.addView(text(pre + a.optString(i), 12, color));
    }

    static String gptPromptPure(JSONObject o) {
        boolean up = o.optBoolean("pump");
        StringBuilder sb = new StringBuilder("Tum ek professional crypto trader ho. Mere ParaDox bot ne yeh coin 3+ scans aur research ke baad confirm kiya hai. "
                + "Plan ko jaancho aur Roman Urdu mein behtar BUY/SELL plan do (entry, stop-loss, TP1-3, position size, kab nikalna, khatre).\n\n");
        sb.append("COIN: ").append(o.optString("base")).append(" (Binance) · ").append(up ? "BUY / multi-day pump" : "SELL / dump").append(" · score ").append(o.optInt("score")).append('\n');
        sb.append(String.format(Locale.US, "Entry $%s | zone $%s-$%s | SL $%s | TP1 $%s (%.0f%%) | TP2 $%s | TP3 $%s | R:R %.1f\n", Fmt.price(o.optDouble("p")), Fmt.price(o.optDouble("elo")),
                Fmt.price(o.optDouble("ehi")), Fmt.price(o.optDouble("sl")), Fmt.price(o.optDouble("tp1")), o.optDouble("pr1"), Fmt.price(o.optDouble("tp2")), Fmt.price(o.optDouble("tp3")), o.optDouble("rr")));
        JSONArray info = o.optJSONArray("info");
        if (info != null) for (int i = 0; i < info.length(); i++) sb.append(info.optString(i)).append('\n');
        JSONObject in = o.optJSONObject("intel");
        if (in != null) {
            for (String k : new String[]{"plus", "minus", "unl", "ev", "news"}) {
                JSONArray a = in.optJSONArray(k);
                if (a != null) for (int i = 0; i < a.length() && i < 5; i++) sb.append("- ").append(a.optString(i)).append('\n');
            }
        }
        JSONArray w = o.optJSONArray("why");
        if (w != null) for (int i = 0; i < w.length() && i < 10; i++) sb.append("- ").append(w.optString(i)).append('\n');
        sb.append("Aakhir mein likho ke yeh financial advice nahi.");
        String s = sb.toString();
        return s.length() > 3800 ? s.substring(0, 3800) : s;
    }

    /** Plain-language explanation of the RVOL numbers with real dollar amounts. */
    static String rvolExplain(PumpHunter.Pick p) {
        StringBuilder sb = new StringBuilder();
        boolean bin = "Binance".equals(p.venue);
        sb.append("RVOL (Relative Volume) = abhi ka volume ÷ is coin ka NORMAL volume. 1x = aam din jaisa, 3x = teen guna, 7x = saat guna.\n\n");
        if (bin) {
            sb.append(String.format(Locale.US, "• 15m %.1fx → pichle 15 minute mein %s ka trade hua. Is coin ka normal 15 minute ka trade (24h volume %s ÷ 96) sirf %s hota hai. "
                    + "Yani aam se %.1f guna zyada paisa abhi aaya.\n", p.rvol15, Fmt.usd(p.vol15), Fmt.usd(p.vol24), Fmt.usd(p.vol24 / 96), p.rvol15));
            sb.append(String.format(Locale.US, "• 1h %.1fx → pichle 1 ghante mein %s, jab ke normal ghanta (24h ÷ 24) %s hota hai.\n", p.rvol1h, Fmt.usd(p.vol1h), Fmt.usd(p.vol24 / 24)));
            if (!Double.isNaN(p.rvol5))
                sb.append(String.format(Locale.US, "• 5m %.1fx → sab se taaza 5 minute candle mein %s — pichle 3 ghante ki ausat 5m candle se %.1f guna.\n", p.rvol5, Fmt.usd(p.vol5), p.rvol5));
            if (p.rvol15 > p.rvol1h * 1.6)
                sb.append(String.format(Locale.US, "\n👉 15m (%.1fx) 1h (%.1fx) se kaafi bara hai = volume ABHI ABHI aaya hai (pichle chand minute). Yeh taaza footprint hai — isi liye jaldi pakra.\n", p.rvol15, p.rvol1h));
            else if (p.rvol1h >= p.rvol15)
                sb.append("\n👉 1h ka number 15m ke barabar / zyada = volume ghante bhar se lagatar aa raha hai (steady accumulation / distribution).\n");
        } else {
            sb.append(String.format(Locale.US, "• %s par pichle kuch minute mein volume normal raftaar se %.1f guna tez aaya (andaazan 15 min mein %s, normal %s).\n",
                    p.venue, p.venueSpike, Fmt.usd(p.vol15), Fmt.usd(p.vol24 / 96)));
        }
        sb.append(String.format(Locale.US, "\nPrice ab tak: 15m %+.2f%% · 1h %+.2f%%. Bara volume + choti price harkat = Price-Volume Divergence: koi bara player chupke se "
                + "%s, aur price ne abhi react nahi kiya.", p.ch15, p.ch1h, p.pump ? "khareed raha (accumulation)" : "bech raha (distribution)"));
        return sb.toString();
    }

    private void openPick(final PumpHunter.Pick p) {
        LinearLayout col = openPage((p.pump ? "🚀 " : "🩸 ") + p.base + " — hunt ki tafseel");
        int c0 = p.pump ? GREEN : RED;
        LinearLayout c = card(col, c0);
        c.addView(bold((p.pump ? "PRE-PUMP — gainer ban sakta hai" : "PRE-DUMP — loser ban sakta hai") + " · " + p.score + "/100", 16, c0));
        String stg = "MOMENTUM".equals(p.stage) ? "🔥 MOMENTUM — 5–15% ke baad bhi move tika hua, top gainers ki taraf" : "EARLY".equals(p.stage) ? "🎯 EARLY — move shuru hone se pehle pakra" : "LATE".equals(p.stage) ? "⚠️ LATE — pehle hi chal chuka, risk zyada"
                : "⚡ MOMENTUM — move abhi shuru hua hai";
        c.addView(bold(stg, 13, "LATE".equals(p.stage) ? YELLOW : TEXT));
        c.addView(text(String.format(Locale.US, "%s · %s · 15m %+.2f%% · 1h %+.2f%% · 24h %+.2f%% · 24h vol %s", p.venue, p.price > 0 ? "$" + Fmt.price(p.price) : "—",
                p.ch15, p.ch1h, p.ch24, Fmt.usd(p.vol24)), 13, SOFT));

        // timeline
        LinearLayout tl = card(col, ACC2);
        tl.addView(bold("🕒 Kab pakra", 15, TEXT));
        PumpHunter.Pick lg = PumpHunter.HuntLog.find(this, p.key());
        long first = p.firstAt > 0 ? p.firstAt : lg != null ? lg.firstAt : p.at;
        double fp = p.firstPrice > 0 ? p.firstPrice : lg != null && lg.firstPrice > 0 ? lg.firstPrice : p.price;
        if (first > 0) tl.addView(text("Pehli dafa hunt: " + PumpHunter.when(first), 13, SOFT));
        if (p.at > 0) tl.addView(text("Aakhri update: " + PumpHunter.when(p.at), 13, SOFT));
        if (fp > 0) tl.addView(text("Pakarte waqt price: $" + Fmt.price(fp), 13, SOFT));
        double now = PumpHunter.priceNow(p);
        if (now > 0 && fp > 0) {
            double mv = (now / fp - 1) * 100;
            boolean good = p.pump ? mv > 0 : mv < 0;
            tl.addView(bold(String.format(Locale.US, "Ab: $%s (%+.2f%% hunt ke baad) %s", Fmt.price(now), mv, good ? "✅ sahi taraf" : "❌ abhi ulta / ruka"), 13, good ? GREEN : RED));
        }
        int best = Math.max(p.bestScore, lg != null ? lg.bestScore : 0);
        if (best > 0) tl.addView(text("Sab se zyada score: " + best + "/100 · alert had: " + Prefs.huntMinScore(this), 12, MUTED));

        // where
        LinearLayout wc = card(col, CYAN_TXT);
        wc.addView(bold("📍 Kahan kahan se pakra (" + p.src.size() + " sources)", 15, TEXT));
        if (p.src.isEmpty()) wc.addView(text("• " + p.venue, 13, SOFT));
        for (String s : p.src) wc.addView(text("• " + s, 13, SOFT));

        // rvol explained
        LinearLayout rc = card(col, YELLOW);
        rc.addView(bold("📊 Volume ki tafseel — yeh 7.6x / 2.7x kya hai?", 15, TEXT));
        rc.addView(text(rvolExplain(p), 13, SOFT));

        // how
        LinearLayout hc = card(col, c0);
        hc.addView(bold("🔎 Kaise pakra — saare saboot", 15, TEXT));
        for (String w : p.why) hc.addView(text("• " + w, 13, SOFT));
        hc.addView(divider());
        hc.addView(text(String.format(Locale.US, "🧮 Score ka hisaab: bullish points %.0f · bearish points %.0f → farq (thoda kaat kar) = %d/100. Jitna ek taraf zyada, utna score ooncha.",
                p.bull, p.bear, p.score), 12, MUTED));

        LinearLayout ac = card(col);
        ac.addView(text(p.pump ? "👉 Kya karein: chart kholein — pullback / breakout ki candle close par chhoti entry, stop range ke neeche. Score sirf ishara hai, guarantee nahi."
                : "👉 Kya karein: holding ho to stop tight karein / profit bacha lein. Futures mein short sirf breakdown confirm hone par.", 12, YELLOW));
        if ("Binance".equals(p.venue)) {
            Button an = button("📈 " + p.base + " chart + analysis", ACC, INK, 0);
            an.setOnClickListener(v -> { closeInfo(); openAnalyze(p.sym); });
            ac.addView(an);
            Button bn = button("🟡 Binance mein kholen", 0xFFF0B90B, INK, 0);
            bn.setOnClickListener(v -> BinanceLink.open(this, p.base, !p.pump));
            ac.addView(bn);
        } else {
            final String url = venueUrl(p.venue, p.base);
            if (!url.isEmpty()) {
                Button bn = button("🌐 " + p.venue + " par " + p.base + " kholen", 0xFFF0B90B, INK, 0);
                bn.setOnClickListener(v -> openUrl(url));
                ac.addView(bn);
            }
            ac.addView(text("⚠️ Yeh coin Binance Spot par nahi — chhote exchanges par pumps tez magar khatarnak (kam liquidity, manipulation).", 12, YELLOW));
        }
        Button gp = button("💬 ChatGPT se BUY / SELL trading plan banwayen (FREE)", 0xFF10A37F, INK, 0);
        gp.setOnClickListener(v -> openChatGpt(gptPrompt(p)));
        ac.addView(gp);
        final LinearLayout chat = column();
        Button ai = button("🤖 Gemini / Groq se is coin par raaye", CLAUDE, INK, 0);
        ai.setOnClickListener(v -> askAi(pickText(p), chat, new ArrayList<>(), "Is coin ka data dekho: kya yeh sach mein " + (p.pump ? "pump" : "dump")
                + " ki taraf hai? Entry, stop, target aur khatra batao. Agar data kamzor hai to saaf kaho."));
        ac.addView(ai);
        ac.addView(chat);
        learnToggle(ac, "Har volume spike pump nahi hota — kabhi bara seller bhi hota hai. Isi liye bot buyers %, order book, futures, whales aur Korea bhi dekhta hai. "
                + "'Record' tab mein asal hit rate dekhte rahein.");
    }

    static String pickText(PumpHunter.Pick p) {
        StringBuilder sb = new StringBuilder();
        sb.append(p.base).append(p.pump ? " PRE-PUMP" : " PRE-DUMP").append(" score ").append(p.score).append("/100 on ").append(p.venue).append(", stage ").append(p.stage).append('\n');
        sb.append(String.format(Locale.US, "price %s, 15m %+.2f%%, 1h %+.2f%%, 24h %+.2f%%, 24h vol %s\n", Fmt.price(p.price), p.ch15, p.ch1h, p.ch24, Fmt.usd(p.vol24)));
        for (String w : p.why) sb.append("- ").append(w).append('\n');
        for (String s : p.src) sb.append("source: ").append(s).append('\n');
        return sb.toString();
    }

    // ============================================================ v27: 💬 ChatGPT (free) inside the app
    private LinearLayout gptOverlay;
    private android.webkit.WebView gptWeb;

    /** Builds the ChatGPT request for one hunted coin: full evidence + ask for a complete BUY / SELL trading plan. */
    static String gptPrompt(PumpHunter.Pick p) {
        StringBuilder sb = new StringBuilder();
        sb.append("Tum ek professional crypto trader ho. Mere ParaDox bot ke Gainer Hunter ne yeh coin pakra hai. Neeche ka live data parh kar Roman Urdu mein ")
                .append("ek mukammal trading plan banao.\n\n");
        sb.append("COIN: ").append(p.base).append(" (").append(p.venue).append(")\n");
        sb.append("Bot ka andaza: ").append(p.pump ? "PRE-PUMP (gainer ban sakta hai)" : "PRE-DUMP (loser ban sakta hai)").append(", score ").append(p.score).append("/100, stage ")
                .append(p.stage).append('\n');
        if (p.firstAt > 0) sb.append("Hunt hua: ").append(PumpHunter.when(p.firstAt)).append(" (Pakistan time)\n");
        sb.append(String.format(Locale.US, "Price: %s | 15m %+.2f%% | 1h %+.2f%% | 24h %+.2f%% | 24h volume %s\n", p.price > 0 ? "$" + Fmt.price(p.price) : "n/a",
                p.ch15, p.ch1h, p.ch24, Fmt.usd(p.vol24)));
        sb.append("\nSABOOT:\n");
        for (int i = 0; i < p.why.size() && i < 14; i++) sb.append("- ").append(p.why.get(i)).append('\n');
        if (!p.src.isEmpty()) {
            sb.append("\nKAHAN SE PAKRA:\n");
            for (int i = 0; i < p.src.size() && i < 8; i++) sb.append("- ").append(p.src.get(i)).append('\n');
        }
        sb.append("\nMujhe yeh do:\n1) BUY karun ya SELL / short — ya intezar? Wajah.\n2) Entry zone\n3) Stop-loss (kahan aur kyun)\n4) Target 1, 2, 3 (TP)\n")
                .append("5) $100 account par kitni position size (1-2% risk)\n6) Spot ya futures — aur leverage ho to kitna\n7) Kab nikal jaun / idea kab ghalat sabit hoga\n")
                .append("8) Sab se bara khatra (fake pump, manipulation, liquidity)\nChhota aur saaf jawab do. Aakhir mein likho ke yeh financial advice nahi.");
        String s = sb.toString();
        return s.length() > 3800 ? s.substring(0, 3800) : s;
    }

    /** Opens chatgpt.com inside the app. With a prompt, ChatGPT gets the question already typed (and it is copied too, as a backup). */
    private void openChatGpt(String prompt) {
        String url = "https://chatgpt.com/";
        if (prompt != null && !prompt.isEmpty()) {
            try { url = "https://chatgpt.com/?q=" + java.net.URLEncoder.encode(prompt, "UTF-8"); } catch (Exception ignored) { }
            copyText(prompt);
            toast("📋 Coin ki details copy ho gayi — agar ChatGPT mein khud na aayein to box mein paste karein");
        }
        final String target = url;
        if (gptOverlay == null) {
            gptOverlay = column();
            gptOverlay.setBackgroundColor(0xFF0A0E17);
            LinearLayout h = row();
            h.setPadding(dp(10), dp(10), dp(10), dp(6));
            TextView b = bold("‹", 28, TEXT);
            b.setPadding(dp(4), 0, dp(12), dp(4));
            b.setOnClickListener(v -> onBackPressed());
            h.addView(b);
            h.addView(bold("💬 ChatGPT (FREE)", 18, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
            TextView home = chip("🏠", false);
            home.setOnClickListener(v -> { if (gptWeb != null) gptWeb.loadUrl("https://chatgpt.com/"); });
            h.addView(home, chipLp());
            TextView ext = chip("🌐", false);
            ext.setOnClickListener(v -> openUrl(gptWeb != null && gptWeb.getUrl() != null ? gptWeb.getUrl() : "https://chatgpt.com/"));
            h.addView(ext, chipLp());
            TextView x = chip("✕", false);
            x.setOnClickListener(v -> closeChatGpt());
            h.addView(x, chipLp());
            gptOverlay.addView(h);
            TextView tip = text("Pehli dafa: 'Sign up' → apni email likhein → 'Continue' → email par aaya code daalein. (Google / Apple login yahan nahi chalta — email use karein.) "
                    + "Login ek dafa hota hai, phir yaad rehta hai.", 11, MUTED);
            tip.setPadding(dp(12), 0, dp(12), dp(6));
            gptOverlay.addView(tip);
            gptWeb = new android.webkit.WebView(this);
            android.webkit.WebSettings ws = gptWeb.getSettings();
            ws.setJavaScriptEnabled(true);
            ws.setDomStorageEnabled(true);
            ws.setDatabaseEnabled(true);
            ws.setLoadWithOverviewMode(true);
            ws.setUseWideViewPort(true);
            // look like normal mobile Chrome (some login pages refuse the WebView marker)
            String ua = ws.getUserAgentString();
            if (ua != null) ws.setUserAgentString(ua.replace("; wv", "").replace("Version/4.0 ", ""));
            android.webkit.CookieManager cm = android.webkit.CookieManager.getInstance();
            cm.setAcceptCookie(true);
            cm.setAcceptThirdPartyCookies(gptWeb, true);
            gptWeb.setWebViewClient(new android.webkit.WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(android.webkit.WebView view, android.webkit.WebResourceRequest req) {
                    String u = req.getUrl().toString();
                    if (u.startsWith("http://") || u.startsWith("https://")) return false;
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); } catch (Exception ignored) { }
                    return true;
                }

                @Override
                public void onPageFinished(android.webkit.WebView view, String u) {
                    android.webkit.CookieManager.getInstance().flush();
                }
            });
            gptWeb.setWebChromeClient(new android.webkit.WebChromeClient());
            gptOverlay.addView(gptWeb, new LinearLayout.LayoutParams(-1, 0, 1));
        }
        if (gptOverlay.getParent() == null) rootFrame.addView(gptOverlay, new FrameLayout.LayoutParams(-1, -1));
        gptOverlay.bringToFront();
        if (prompt != null || gptWeb.getUrl() == null) gptWeb.loadUrl(target);
    }

    private void closeChatGpt() {
        if (gptOverlay != null && gptOverlay.getParent() != null) rootFrame.removeView(gptOverlay);
        android.webkit.CookieManager.getInstance().flush();
    }

    private boolean chatGptOpen() { return gptOverlay != null && gptOverlay.getParent() != null; }

    private void copyText(String s) {
        try {
            android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("ParaDox", s));
        } catch (Exception ignored) {
        }
    }

    private void huntAi(LinearLayout box) {
        PumpHunter.Result r = PumpHunter.cached();
        if (r == null || (r.pumps.isEmpty() && r.dumps.isEmpty())) { toast("Pehle hunt hone dein"); return; }
        StringBuilder sb = new StringBuilder("GAINER/LOSER HUNTER CANDIDATES (live Binance data):\n");
        int n = 0;
        for (PumpHunter.Pick p : r.pumps) if (n++ < 6) sb.append(pickText(p)).append('\n');
        n = 0;
        for (PumpHunter.Pick p : r.dumps) if (n++ < 4) sb.append(pickText(p)).append('\n');
        box.removeAllViews();
        askAi(sb.toString(), box, new ArrayList<>(), "In candidates mein se sab se mazboot 3 pre-pump aur 2 pre-dump chuno, wajah do, aur jo kamzor/fake lagein unhein alag batao.");
    }

    /** Ask the selected AI (Gemini free / Groq free) with live data. */
    private void askAi(final String data, final LinearLayout chat, final List<String[]> history, String question) {
        if (!AiRouter.ready(this)) {
            chat.addView(bubble("🔑 Settings → 🤖 AI mein key daalein. FREE: Google Gemini (aistudio.google.com) ya Groq (console.groq.com).", false));
            return;
        }
        history.add(new String[]{"user", "LIVE DATA REPORT:\n" + data + "\n\nSAWAL: " + question});
        chat.addView(bubble("🙋 " + question, true));
        final TextView thinking = bubble("🤖 " + AiRouter.label(this) + " soch raha hai...", false);
        chat.addView(thinking);
        final List<String[]> snap = new ArrayList<>(history);
        pool.execute(() -> {
            try {
                final String ans = AiRouter.ask(this, snap);
                runOnUiThread(() -> { history.add(new String[]{"assistant", ans}); thinking.setText("🤖 " + ans); });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> { thinking.setText("❌ AI se jawab nahi aaya: " + m); thinking.setTextColor(RED); });
            }
        });
    }

    // ============================================================ v32: 🛡️ FREE VPN (VPN Gate servers, many countries)
    private String vpnCountry = "";

    private void openVpn() {
        LinearLayout col = openPage("🛡️ Free VPN");
        final LinearLayout page = infoOverlay;
        LinearLayout h = card(col, CYAN_TXT);
        h.addView(bold("Muft VPN — apni pasand ka mulk", 16, TEXT));
        h.addView(text("Servers VPN Gate (University of Tsukuba, Japan ka public project) ke hain — duniya bhar ke volunteers chalate hain. Connection free app "
                + "\"OpenVPN for Android\" banata hai (Android khud kisi app ko bina is ke VPN nahi chalane deta).", 12, MUTED));
        h.addView(bold("Tareeqa (sirf pehli dafa):", 13, TEXT));
        h.addView(text("1️⃣ Neeche se 'OpenVPN for Android' install karein (free)\n2️⃣ Mulk chunein → server par tap → OpenVPN app khulegi → 'Import' / ✓\n"
                + "3️⃣ Profile par tap = connect · band karna ho to OpenVPN app mein Disconnect", 12, SOFT));
        Button i1 = button("📥 OpenVPN for Android (free) install", GREEN, INK, 0);
        i1.setOnClickListener(v -> openUrl("https://play.google.com/store/apps/details?id=de.blinkt.openvpn"));
        h.addView(i1);
        Button i2 = button("⚙️ Android VPN settings (connected / disconnect)", CARD, ACC, ACC);
        i2.setOnClickListener(v -> { try { startActivity(new Intent("android.settings.VPN_SETTINGS")); } catch (Exception e) { toast("Settings nahi khuli"); } });
        h.addView(i2);
        h.addView(text("⚠️ Free volunteer servers par bank / password wala kaam na karein. Binance waghera ke rules mein VPN se mulk badalna mana ho sakta hai — "
                + "account ki hifazat ke liye apne asal mulk se hi trade karein. Doosre free options: Proton VPN (free, no-logs) · Cloudflare 1.1.1.1 (WARP).", 11, YELLOW));
        LinearLayout oth = row();
        TextView pv = chip("Proton VPN", false);
        pv.setOnClickListener(v -> openUrl("https://play.google.com/store/apps/details?id=ch.protonvpn.android"));
        oth.addView(pv, chipLp());
        TextView wp = chip("1.1.1.1 WARP", false);
        wp.setOnClickListener(v -> openUrl("https://play.google.com/store/apps/details?id=com.cloudflare.onedotonedotonedotone"));
        oth.addView(wp, chipLp());
        h.addView(hscroll(oth));

        final LinearLayout cc = column();
        final LinearLayout list = column();
        final TextView st = bold("Servers load ho rahe hain...", 13, ACC2);
        LinearLayout lc = card(col);
        LinearLayout hr = row();
        hr.addView(st, new LinearLayout.LayoutParams(0, -2, 1));
        TextView rf = chip("↻", false);
        hr.addView(rf);
        lc.addView(hr);
        lc.addView(cc);
        lc.addView(list);
        final Runnable[] load = new Runnable[1];
        load[0] = () -> {
            st.setText("Servers load ho rahe hain...");
            pool.execute(() -> {
                List<VpnGate.Server> l0 = null;
                String err = null;
                try { l0 = VpnGate.list(false); } catch (Exception e) { err = e.getMessage(); }
                final List<VpnGate.Server> l = l0;
                final String fe = err;
                runOnUiThread(() -> {
                    if (infoOverlay != page) return;
                    if (l == null || l.isEmpty()) { st.setText("❌ Server list nahi mili" + (fe == null ? "" : " (" + fe + ")") + " — ↻ dobara"); return; }
                    renderVpn(l, cc, list, st);
                });
            });
        };
        rf.setOnClickListener(v -> load[0].run());
        load[0].run();
    }

    private void renderVpn(final List<VpnGate.Server> l, final LinearLayout cc, final LinearLayout list, final TextView st) {
        Map<String, Integer> cnt = new java.util.LinkedHashMap<>();
        Map<String, String> names = new HashMap<>();
        for (VpnGate.Server s : l) { cnt.put(s.cc, (cnt.containsKey(s.cc) ? cnt.get(s.cc) : 0) + 1); names.put(s.cc, s.country); }
        List<String> ccs = new ArrayList<>(cnt.keySet());
        Collections.sort(ccs, (a, b) -> cnt.get(b) - cnt.get(a));
        cc.removeAllViews();
        LinearLayout r = row();
        TextView all = chip("🌐 Sab (" + l.size() + ")", vpnCountry.isEmpty());
        all.setOnClickListener(v -> { vpnCountry = ""; renderVpn(l, cc, list, st); });
        r.addView(all, chipLp());
        for (final String c : ccs) {
            TextView ch = chip(VpnGate.flag(c) + " " + names.get(c) + " (" + cnt.get(c) + ")", c.equals(vpnCountry));
            ch.setOnClickListener(v -> { vpnCountry = c; renderVpn(l, cc, list, st); });
            r.addView(ch, chipLp());
        }
        cc.addView(hscroll(r));
        list.removeAllViews();
        int n = 0;
        for (final VpnGate.Server s : l) {
            if (!vpnCountry.isEmpty() && !vpnCountry.equals(s.cc)) continue;
            if (n++ >= 40) break;
            LinearLayout row = row();
            row.setPadding(0, dp(10), 0, dp(10));
            row.addView(text(VpnGate.flag(s.cc), 22, TEXT), new LinearLayout.LayoutParams(dp(40), -2));
            LinearLayout nm = column();
            nm.addView(bold(s.country, 14, TEXT));
            nm.addView(text(String.format(Locale.US, "%.1f Mbps · ping %s · %d log online · %s", s.speed / 1e6, s.ping >= 999 ? "—" : s.ping + " ms", s.sessions, s.ip), 11, MUTED));
            row.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
            row.addView(bold("Connect ›", 12, GREEN));
            row.setOnClickListener(v -> connectVpn(s));
            list.addView(row);
            list.addView(divider());
        }
        st.setText("🟢 " + l.size() + " free servers · " + ccs.size() + " mulk · tez pehle");
    }

    private void connectVpn(VpnGate.Server s) {
        try {
            java.io.File dir = new java.io.File(getCacheDir(), "vpn");
            dir.mkdirs();
            String name = ("ParaDox_" + s.cc + "_" + s.ip.replace('.', '_') + ".ovpn").replaceAll("[^A-Za-z0-9_.-]", "_");
            java.io.FileOutputStream fo = new java.io.FileOutputStream(new java.io.File(dir, name));
            fo.write(VpnGate.profile(s).getBytes("UTF-8"));
            fo.close();
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(Uri.parse("content://" + VpnFileProvider.AUTH + "/" + name), "application/x-openvpn-profile");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                startActivity(Intent.createChooser(i, "VPN profile kholen (OpenVPN)"));
                toast(VpnGate.flag(s.cc) + " " + s.country + " — OpenVPN mein Import karein, phir connect");
            } catch (Exception e) {
                toast("Pehle 'OpenVPN for Android' install karein");
                openUrl("https://play.google.com/store/apps/details?id=de.blinkt.openvpn");
            }
        } catch (Exception e) {
            toast("Profile save nahi hua: " + e.getMessage());
        }
    }

    // ============================================================ v35: 💥 LIQUIDATIONS (map + exchanges, live)
    private String liqCoin = "BTC";
    private int liqHours = 168, liqWin = 24, liqEx = 0;

    private void openLiqMap() {
        LiqFeed.start(this);
        LinearLayout col = openPage("💥 Liquidation Map");
        final LinearLayout page = infoOverlay;
        LinearLayout h = card(col, RED);
        h.addView(bold("Long aur short ki liquidation kahan kahan pari hai", 16, TEXT));
        h.addView(text("🟢 Upar = SHORT walon ki liquidation (price wahan pohanchi to shorts zabardasti band → market BUY → price aur upar).\n"
                + "🔴 Neeche = LONG walon ki liquidation (price wahan giri to longs zabardasti band → market SELL → price aur neeche).\n"
                + "Bari patti = wahan zyada paisa. Price aksar in dheron ki taraf 'magnet' ki tarah jaati hai (bade players inhein hunt karte hain).", 12, SOFT));
        LinearLayout cr = row();
        final String[] coins = {"BTC", "ETH", "SOL", "XRP", "DOGE", "BNB", "SUI", "HYPE", "ADA", "LINK", "PEPE", "WIF", "AVAX", "LTC"};
        final TextView[] cc = new TextView[coins.length];
        final LinearLayout body = column();
        final Runnable[] load = new Runnable[1];
        for (int i = 0; i < coins.length; i++) {
            final int k = i;
            cc[i] = chip(coins[i], coins[i].equals(liqCoin));
            cc[i].setOnClickListener(v -> { liqCoin = coins[k]; for (int z = 0; z < coins.length; z++) styleChip(cc[z], z == k); load[0].run(); });
            cr.addView(cc[i], chipLp());
        }
        h.addView(hscroll(cr));
        LinearLayout sr = row();
        final EditText se = input("Koi bhi coin (jaise ARB)", "", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        sr.addView(se, new LinearLayout.LayoutParams(0, -2, 1));
        TextView go = chip("Dekhein", true);
        go.setOnClickListener(v -> {
            String q = se.getText().toString().trim().toUpperCase(Locale.US).replace("USDT", "").replace("/", "");
            if (q.isEmpty()) return;
            liqCoin = q;
            hideKeyboard();
            for (TextView t : cc) styleChip(t, false);
            load[0].run();
        });
        sr.addView(go, chipLp());
        h.addView(sr);
        LinearLayout wr = row();
        final int[] hs = {24, 72, 168, 480};
        final String[] hn = {"1 din", "3 din", "7 din", "20 din"};
        final TextView[] wc = new TextView[hs.length];
        for (int i = 0; i < hs.length; i++) {
            final int k = i;
            wc[i] = chip(hn[i], hs[i] == liqHours);
            wc[i].setOnClickListener(v -> { liqHours = hs[k]; for (int z = 0; z < hs.length; z++) styleChip(wc[z], z == k); load[0].run(); });
            wr.addView(wc[i], chipLp());
        }
        h.addView(text("Kitne din ki positions:", 11, MUTED));
        h.addView(hscroll(wr));
        col.addView(body);
        final LinearLayout liveC = card(col, YELLOW);
        liveC.addView(bold("⚡ Is coin ki asal liquidations — LIVE", 14, TEXT));
        final LinearLayout liveL = column();
        liveC.addView(liveL);
        LinearLayout lc = card(col, CYAN_TXT);
        lc.addView(bold("📚 Ise kaise parhein aur study karein", 15, TEXT));
        lc.addView(text("1️⃣ Price ke sab se qareeb BARA dher dhoondein — price aksar pehle wahan jaati hai (liquidity hunt), phir palat-ti hai.\n"
                + "2️⃣ Agar upar shorts ka dher neeche longs se bohat bara hai → upar 'short squeeze' ka imkaan; ulta ho to neeche 'long squeeze'.\n"
                + "3️⃣ Dher tak pohanch kar jab liquidations ho jaati hain (neeche LIVE list mein bari laal / hari entries), woh fuel khatam — wahan aksar reversal hota hai.\n"
                + "4️⃣ Apna stop-loss bare dher ke bilkul paas na rakhein — wahi jagah hunt hoti hai. Dher se thora aage rakhein.\n"
                + "5️⃣ Long/short ratio: 60%+ log long hon to neeche ki liquidations ka khatra zyada (bheer ulti taraf jaati hai).\n"
                + "⚠️ Yeh map ANDAZA hai: open interest kab barha, us waqt ki price, asal long/short ratio aur aam leverage (5x–100x) se banta hai — "
                + "exchanges har trader ki position public nahi karte. Coinglass waghera bhi isi tarah ke model use karte hain. Neeche ki LIVE liquidations 100% asal hain.", 12, SOFT));
        final long[] mapAt = {0};
        load[0] = () -> {
            body.removeAllViews();
            body.addView(text("⏳ " + liqCoin + " ka liquidation map ban raha hai...", 13, MUTED));
            mapAt[0] = System.currentTimeMillis();
            final String coin = liqCoin;
            final int hrs = liqHours;
            pool.execute(() -> {
                LiqMap.Map2 m = null;
                String err = null;
                try { m = LiqMap.build(coin, hrs); } catch (Exception e) { err = e.getMessage(); }
                final LiqMap.Map2 fm = m;
                final String fe = err;
                runOnUiThread(() -> {
                    if (infoOverlay != page || !coin.equals(liqCoin)) return;
                    body.removeAllViews();
                    if (fm == null) { body.addView(text("❌ " + coin + " ka futures data nahi mila (" + fe + "). Coin ka naam check karein.", 13, RED)); return; }
                    renderLiqMap(body, fm);
                });
            });
        };
        load[0].run();
        final Runnable[] tick = new Runnable[1];
        tick[0] = () -> {
            if (infoOverlay != page) return;
            liveL.removeAllViews();
            liveL.addView(text(liveStatus(), 11, MUTED));
            Map<String, double[]> t24 = LiqFeed.totals(24);
            boolean any = false;
            for (String ex : LiqFeed.EXCHANGES) {   // every exchange in its own block — never mixed
                double[] v = t24.get(ex + "|" + liqCoin);
                List<LiqFeed.Liq> l = LiqFeed.recentEx(ex, liqCoin, 4);
                if (v == null && l.isEmpty()) continue;
                any = true;
                liveL.addView(bold((LiqFeed.live(ex) ? "🟢 " : "⚪ ") + ex + (v == null ? "" : " · 24h: 🔴 " + Fmt.usd(v[0]) + "  🟢 " + Fmt.usd(v[1])), 13, TEXT));
                for (LiqFeed.Liq x : l) liveL.addView(liqRow(x, false));
            }
            if (!any) liveL.addView(text(liqCoin + " ki koi liquidation abhi tak nahi aayi — aate hi yahan (har exchange alag) dikhegi.", 12, MUTED));
            if (System.currentTimeMillis() - mapAt[0] > 60_000L) load[0].run();
            handler.postDelayed(tick[0], 2000);
        };
        tick[0].run();
    }

    private String liveStatus() {
        StringBuilder b = new StringBuilder();
        for (String ex : LiqFeed.EXCHANGES) b.append(LiqFeed.live(ex) ? "🟢 " : "⚪ ").append(ex).append("  ");
        return b.toString().trim();
    }

    private View liqRow(LiqFeed.Liq x, boolean showCoin) {
        LinearLayout r = row();
        r.setPadding(0, dp(4), 0, dp(4));
        r.addView(text(new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date(x.t)), 11, MUTED), new LinearLayout.LayoutParams(dp(62), -2));
        r.addView(bold((x.longLiq ? "🔴 LONG " : "🟢 SHORT ") + (showCoin ? x.coin : ""), 12, x.longLiq ? RED : GREEN), new LinearLayout.LayoutParams(0, -2, 1));
        r.addView(text(x.ex + " · $" + Fmt.price(x.price), 11, SOFT), new LinearLayout.LayoutParams(0, -2, 1.2f));
        r.addView(bold(Fmt.usd(x.usd), 12, x.usd >= 100_000 ? YELLOW : TEXT));
        return r;
    }

    private void renderLiqMap(LinearLayout b, LiqMap.Map2 m) {
        LinearLayout s = card(b, ACC);
        s.addView(bold(m.coin + " · $" + Fmt.price(m.price) + " · " + m.source, 15, TEXT));
        s.addView(text("Open interest " + Fmt.usd(m.oiUsd) + (Double.isNaN(m.longRatio) ? "" : String.format(Locale.US, " · log long %.0f%% / short %.0f%%", m.longRatio * 100, (1 - m.longRatio) * 100)), 12, SOFT));
        double tot = m.totalLong + m.totalShort;
        s.addView(bold("🔴 Neeche long liquidations: " + Fmt.usd(m.totalLong) + "   ·   🟢 Upar short liquidations: " + Fmt.usd(m.totalShort), 13, TEXT));
        if (tot > 0) {
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, dp(8));
            bl.topMargin = dp(4);
            s.addView(bar(m.totalShort * 100 / tot, GREEN, RED), bl);
        }
        // nearest strong magnets (within 8%)
        double[] nl = null, ns = null;
        for (double[] x : m.topLong) if (x[0] > m.price * 0.92 && (nl == null || x[1] > nl[1])) nl = x;
        for (double[] x : m.topShort) if (x[0] < m.price * 1.08 && (ns == null || x[1] > ns[1])) ns = x;
        if (nl != null) s.addView(text("🧲 Qareeb ka bara LONG dher: $" + Fmt.price(nl[0]) + " (" + LiqMap.pct(nl[0], m.price) + ") · " + Fmt.usd(nl[1]), 12, RED));
        if (ns != null) s.addView(text("🧲 Qareeb ka bara SHORT dher: $" + Fmt.price(ns[0]) + " (" + LiqMap.pct(ns[0], m.price) + ") · " + Fmt.usd(ns[1]), 12, GREEN));
        if (nl != null && ns != null)
            s.addView(bold(ns[1] > nl[1] * 1.3 ? "👉 Upar shorts ka dher bara — upar ki taraf squeeze / hunt ka imkaan zyada"
                    : nl[1] > ns[1] * 1.3 ? "👉 Neeche longs ka dher bara — neeche ki taraf hunt / girawat ka imkaan zyada"
                    : "👉 Dono taraf barabar — range; jo taraf pehle toote, wahan tez move", 13, YELLOW));
        // heat ladder
        LinearLayout hc = card(b);
        hc.addView(bold("📊 Price ladder (±25%) — har line ek price zone", 14, TEXT));
        double max = 1;
        for (int i = 0; i < m.longUsd.length; i++) max = Math.max(max, Math.max(m.longUsd[i], m.shortUsd[i]));
        int cur = (int) ((m.price - m.lo) / m.step);
        for (int i = m.longUsd.length - 1; i >= 0; i--) {
            double v = i >= cur ? m.shortUsd[i] : m.longUsd[i];
            if (i == cur) {
                hc.addView(bold("━━━━  ◀ ab price $" + Fmt.price(m.price) + "  ━━━━", 12, ACC));
                continue;
            }
            LinearLayout r = row();
            double mid = m.lo + (i + 0.5) * m.step;
            r.addView(text("$" + Fmt.price(mid), 10, MUTED), new LinearLayout.LayoutParams(dp(78), -2));
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(9), 1);
            bp.topMargin = dp(3);
            r.addView(bar(v * 100 / max, i > cur ? GREEN : RED, 0x14FFFFFF), bp);
            r.addView(text(v >= 1000 ? " " + Fmt.usd(v) : "", 10, SOFT), new LinearLayout.LayoutParams(dp(62), -2));
            hc.addView(r);
        }
        hc.addView(text("Update: " + new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date(m.at)) + " · har minute khud update", 10, MUTED));
    }

    private void openLiqExchanges() {
        LiqFeed.start(this);
        LinearLayout col = openPage("🏦 Exchange liquidations");
        final LinearLayout page = infoOverlay;
        LinearLayout h = card(col, YELLOW);
        h.addView(bold("Kis exchange ne kitne log liquidate kiye — LIVE", 16, TEXT));
        h.addView(text("Binance, Bybit, OKX (live socket) aur Gate, HTX (har minute public data) — har exchange ki apni feed se, har liquidation (BTC aur baqi sab coins) "
                + "jama hoti hai, 24 ghante tak phone par mehfooz. Har exchange ka data alag rakha jata hai.", 12, MUTED));
        LinearLayout wr = row();
        final int[] ws = {1, 4, 12, 24};
        final TextView[] wc = new TextView[ws.length];
        final LinearLayout body = column();
        for (int i = 0; i < ws.length; i++) {
            final int k = i;
            wc[i] = chip(ws[i] + "h", ws[i] == liqWin);
            wc[i].setOnClickListener(v -> { liqWin = ws[k]; for (int z = 0; z < ws.length; z++) styleChip(wc[z], z == k); });
            wr.addView(wc[i], chipLp());
        }
        h.addView(hscroll(wr));
        LinearLayout er = row();
        final String[] en = new String[LiqFeed.EXCHANGES.length + 1];
        en[0] = "📊 Muqabla";
        for (int i = 0; i < LiqFeed.EXCHANGES.length; i++) en[i + 1] = LiqFeed.EXCHANGES[i];
        final TextView[] ec = new TextView[en.length];
        for (int i = 0; i < en.length; i++) {
            final int k = i;
            ec[i] = chip(en[i], i == liqEx);
            ec[i].setOnClickListener(v -> { liqEx = k; for (int z = 0; z < en.length; z++) styleChip(ec[z], z == k); });
            er.addView(ec[i], chipLp());
        }
        h.addView(text("Exchange chunein (har exchange ka data alag — mix nahi):", 11, MUTED));
        h.addView(hscroll(er));
        final TextView st = text("", 11, ACC2);
        h.addView(st);
        col.addView(body);
        final LinearLayout feed = card(col, RED);
        final TextView feedH = bold("", 14, TEXT);
        feed.addView(feedH);
        final LinearLayout feedL = column();
        feed.addView(feedL);
        LinearLayout lc = card(col, CYAN_TXT);
        lc.addView(bold("📚 Exchange ko kya milta hai?", 15, TEXT));
        lc.addView(text("Liquidation = trader ka margin khatam → exchange position zabardasti band karta hai. Agar band karne ki price trader ki 'bankruptcy price' se "
                + "behtar mile to bacha hua margin exchange ke INSURANCE FUND mein jaata hai (Binance, Bybit, OKX sab yahi karte hain). Upar 'exchange / insurance fund ko' "
                + "isi ka andaza hai (~0.3%–1% of liquidated size, maintenance margin ke barabar) — asal figure exchanges public nahi karte, Binance apne insurance fund ka "
                + "balance website par dikhata hai.\n"
                + "• LONG liquidation zyada = price giri, longs saaf · SHORT zyada = price chadhi, shorts saaf.\n"
                + "• Ek ghante mein bohat bari liquidations ke baad aksar market thoda ruk kar palat-ti hai (fuel khatam).\n"
                + "⚠️ Binance apni feed mein har coin ki har second sirf sab se bari liquidation bhejta hai — asal total is se zyada hota hai. HTX ke sirf top 20 coins. "
                + "Hyperliquid apni liquidations public feed mein nahi deta (sirf paid third-party services ke paas) — is liye shamil nahi.", 12, SOFT));
        final Runnable[] tick = new Runnable[1];
        tick[0] = () -> {
            if (infoOverlay != page) return;
            st.setText(liveStatus() + " · data jama: " + PumpHunter.when(LiqFeed.since()) + " · Gate / HTX har minute");
            feedL.removeAllViews();
            if (liqEx == 0) {
                renderLiqCompare(body, liqWin);
                feedH.setText("⚡ Live liquidations — har exchange alag");
                for (String ex : LiqFeed.EXCHANGES) {
                    feedL.addView(bold((LiqFeed.live(ex) ? "🟢 " : "⚪ ") + ex, 13, TEXT));
                    List<LiqFeed.Liq> l = LiqFeed.recentEx(ex, null, 5);
                    if (l.isEmpty()) feedL.addView(text("   abhi koi nahi", 11, MUTED));
                    for (LiqFeed.Liq x : l) feedL.addView(liqRow(x, true));
                }
            } else {
                String ex = LiqFeed.EXCHANGES[liqEx - 1];
                renderLiqExchange(body, ex, liqWin);
                feedH.setText("⚡ " + ex + " — live liquidations (sirf " + ex + ")");
                List<LiqFeed.Liq> l = LiqFeed.recentEx(ex, null, 40);
                if (l.isEmpty()) feedL.addView(text(ex + " se abhi koi liquidation nahi aayi" + (LiqFeed.live(ex) ? "" : " (connect ho raha hai)") + ".", 12, MUTED));
                for (LiqFeed.Liq x : l) feedL.addView(liqRow(x, true));
            }
            handler.postDelayed(tick[0], 2000);
        };
        tick[0].run();
    }

    /** exchange -> {long $, short $, count} and exchange -> coin -> {long, short} for the window. */
    private Map<String, double[]> liqPerEx(int hours, Map<String, Map<String, double[]>> coins) {
        Map<String, double[]> perEx = new HashMap<>();
        for (Map.Entry<String, double[]> e : LiqFeed.totals(hours).entrySet()) {
            String[] k = e.getKey().split("\\|", 2);
            double[] v = e.getValue();
            double[] a = perEx.get(k[0]);
            if (a == null) { a = new double[3]; perEx.put(k[0], a); }
            a[0] += v[0]; a[1] += v[1]; a[2] += v[2];
            Map<String, double[]> m = coins.get(k[0]);
            if (m == null) { m = new HashMap<>(); coins.put(k[0], m); }
            m.put(k[1], new double[]{v[0], v[1], v[2]});
        }
        return perEx;
    }

    /** Side-by-side: one card per exchange with ONLY that exchange's numbers. */
    private void renderLiqCompare(LinearLayout b, int hours) {
        b.removeAllViews();
        Map<String, Map<String, double[]>> coins = new HashMap<>();
        Map<String, double[]> perEx = liqPerEx(hours, coins);
        b.addView(text("📊 " + hours + "h — har exchange alag card mein (kisi ka data doosre mein shamil nahi). Card par tap = sirf us exchange ki tafseel.", 12, MUTED));
        for (int i = 0; i < LiqFeed.EXCHANGES.length; i++) {
            final int k = i + 1;
            String ex = LiqFeed.EXCHANGES[i];
            double[] a = perEx.get(ex);
            LinearLayout c = card(b, a == null ? STROKE : a[0] >= a[1] ? RED : GREEN);
            LinearLayout hr = row();
            hr.addView(bold((LiqFeed.live(ex) ? "🟢 " : "⚪ ") + ex, 16, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
            double s = a == null ? 0 : a[0] + a[1];
            hr.addView(bold(Fmt.usd(s), 16, TEXT));
            c.addView(hr);
            if (a == null || s <= 0) { c.addView(text("Is waqt ki koi liquidation abhi jama nahi hui", 12, MUTED)); }
            else {
                c.addView(text(String.format(Locale.US, "🔴 Long %s (%.0f%%) · 🟢 Short %s (%.0f%%) · %d liquidations", Fmt.usd(a[0]), a[0] * 100 / s, Fmt.usd(a[1]), a[1] * 100 / s, (long) a[2]), 12, SOFT));
                LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, dp(6));
                bl.topMargin = dp(4);
                c.addView(bar(a[0] * 100 / s, RED, GREEN), bl);
                c.addView(text("🏦 " + ex + " / insurance fund ko andazan: " + Fmt.usd(s * 0.003) + " – " + Fmt.usd(s * 0.01), 11, CYAN_TXT));
                List<Map.Entry<String, double[]>> l = new ArrayList<>(coins.get(ex).entrySet());
                Collections.sort(l, (x, y) -> Double.compare(y.getValue()[0] + y.getValue()[1], x.getValue()[0] + x.getValue()[1]));
                StringBuilder sb = new StringBuilder("Top: ");
                for (int j = 0; j < l.size() && j < 4; j++) sb.append(l.get(j).getKey()).append(' ').append(Fmt.usd(l.get(j).getValue()[0] + l.get(j).getValue()[1])).append(j < Math.min(3, l.size() - 1) ? " · " : "");
                c.addView(text(sb.toString(), 12, TEXT));
            }
            c.setOnClickListener(v -> { liqEx = k; });
        }
    }

    /** ONE exchange only: its totals, its coins, nothing from the others. */
    private void renderLiqExchange(LinearLayout b, String ex, int hours) {
        b.removeAllViews();
        Map<String, Map<String, double[]>> coins = new HashMap<>();
        double[] a = liqPerEx(hours, coins).get(ex);
        LinearLayout c = card(b, ACC);
        c.addView(bold((LiqFeed.live(ex) ? "🟢 " : "⚪ ") + ex + " · " + hours + "h", 17, TEXT));
        double s = a == null ? 0 : a[0] + a[1];
        if (s <= 0) { c.addView(text("Abhi " + ex + " ki koi liquidation jama nahi hui" + (ex.equals("Gate") || ex.equals("HTX") ? " (yeh har minute check hota hai)" : "") + ".", 13, MUTED)); return; }
        c.addView(bold("Kul " + Fmt.usd(s) + " liquidate · " + (long) a[2] + " liquidations", 15, TEXT));
        c.addView(text(String.format(Locale.US, "🔴 Longs %s (%.0f%%)  ·  🟢 Shorts %s (%.0f%%)", Fmt.usd(a[0]), a[0] * 100 / s, Fmt.usd(a[1]), a[1] * 100 / s), 13, SOFT));
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, dp(8));
        bl.topMargin = dp(4);
        c.addView(bar(a[0] * 100 / s, RED, GREEN), bl);
        c.addView(text(a[0] > a[1] * 1.5 ? "Long dominant — price girne se longs saaf hue" : a[1] > a[0] * 1.5 ? "Short dominant — price chadhne se shorts saaf hue" : "Dono taraf liquidations", 12, YELLOW));
        c.addView(text("🏦 " + ex + " / insurance fund ko andazan: " + Fmt.usd(s * 0.003) + " – " + Fmt.usd(s * 0.01), 12, CYAN_TXT));
        LinearLayout cc = card(b);
        cc.addView(bold("🪙 " + ex + " par sab se zyada liquidate hone wale coins", 14, TEXT));
        List<Map.Entry<String, double[]>> l = new ArrayList<>(coins.get(ex).entrySet());
        Collections.sort(l, (x, y) -> Double.compare(y.getValue()[0] + y.getValue()[1], x.getValue()[0] + x.getValue()[1]));
        for (int i = 0; i < l.size() && i < 15; i++) {
            final String co = l.get(i).getKey();
            double[] v = l.get(i).getValue();
            LinearLayout r = row();
            r.addView(bold(co, 13, TEXT), new LinearLayout.LayoutParams(dp(70), -2));
            r.addView(text("🔴 " + Fmt.usd(v[0]) + "  🟢 " + Fmt.usd(v[1]) + " · " + (long) v[2] + "x", 12, SOFT), new LinearLayout.LayoutParams(0, -2, 1));
            r.addView(bold(Fmt.usd(v[0] + v[1]), 12, v[0] >= v[1] ? RED : GREEN));
            r.setOnClickListener(v2 -> { liqCoin = co; openLiqMap(); });
            cc.addView(r);
        }
        cc.addView(text("Coin par tap = us ka liquidation map", 10, MUTED));
    }

    // ============================================================ v39: 📊 ORDER FLOW card · 🤖 AUTOPILOT · 🩸 DIP HUNTER · 🎉 EVENTS · 🚨 HACK WATCH · 🕰 HISTORY
    private static long tfMs(String tf) {
        try {
            long n = Long.parseLong(tf.substring(0, tf.length() - 1));
            switch (tf.charAt(tf.length() - 1)) {
                case 'm': return n * 60_000L;
                case 'h': return n * 3600_000L;
                case 'd': return n * 86_400_000L;
                case 'w': return n * 7 * 86_400_000L;
                default: return 3600_000L;
            }
        } catch (Exception e) {
            return 3600_000L;
        }
    }

    private void analyzeFromPage(String coin) {
        closeInfo();
        showTab(TAB_ANALYZE);
        runAnalysis(coin + "USDT");
    }

    /** Candle-by-candle buyers vs sellers, delta, next-candle frequency and the price-by-price footprint of the last closed candle. */
    private void orderFlowCard(final CoinReport r) {
        final OrderFlow.Result f = r.flow;
        if (f == null || !f.ok) return;
        int col = !f.real ? MUTED : f.action.equals("BUY") ? GREEN : f.action.equals("SELL") ? RED : YELLOW;
        LinearLayout c = card(resultBox, col);
        c.addView(bold("📊 Order Flow — candle ke neeche ke numbers", 16, TEXT));
        c.addView(bold(f.headline, 14, col));
        for (String s : f.lines) c.addView(text(s, 12, SOFT));
        if (f.real) {
            if (!Double.isNaN(f.nextUpPct))
                c.addView(text(String.format(Locale.US, "🔮 Agli candle: is coin ki apni history mein aisi hi flow ke baad agli candle %.0f%% baar upar band hui (%d cases). "
                        + "Yeh frequency hai, pakki cheez nahi — 50%% ke qareeb ho to koi edge nahi.", f.nextUpPct, f.nextN), 12, ACC2));
            else
                c.addView(text("🔮 Agli candle ka history-andaza: is flow ki kafi misalein nahi (" + f.nextN + ") — andaza nahi diya.", 12, MUTED));
            c.addView(text("Chart par har candle ke neeche: 🟢 buyers (market buy) · 🔴 sellers (market sell) · Δ = farq. Zoom in karein to numbers, zoom out par delta bars + CVD line.", 11, MUTED));
        }
        LinearLayout br = row();
        TextView show = chip("📈 Chart par numbers", false);
        show.setOnClickListener(v -> { chart.setInd("Flow", true); toast("Chart par buyers/sellers ke numbers lag gaye — zoom in karke dekhein"); });
        br.addView(show, chipLp());
        TextView hist = chip("🕰 History se compare", false);
        hist.setOnClickListener(v -> openHistory(r.base));
        br.addView(hist, chipLp());
        c.addView(hscroll(br));
        if (f.real) {
            final LinearLayout fp = column();
            TextView fb = chip("🔬 Aakhri candle ka footprint (price-wise)", false);
            fb.setOnClickListener(v -> {
                fp.removeAllViews();
                fp.addView(text("⏳ Trades load ho rahe hain...", 12, MUTED));
                final long ms = tfMs(r.patternTf == null ? "1h" : r.patternTf);
                final long from = (System.currentTimeMillis() / ms) * ms - ms, to = from + ms - 1;
                pool.execute(() -> {
                    try {
                        final OrderFlow.Footprint ft = OrderFlow.footprint(r.symbol, from, to);
                        runOnUiThread(() -> showFootprint(fp, ft));
                    } catch (Exception e) {
                        final String m = e.getMessage();
                        runOnUiThread(() -> { fp.removeAllViews(); fp.addView(text("Footprint nahi aaya: " + m, 12, RED)); });
                    }
                });
            });
            c.addView(fb, chipLp());
            c.addView(fp);
        } else {
            c.addView(text("Is source (MEXC) mein asal buyers/sellers ka data nahi — Binance chalne par numbers aate hain.", 11, MUTED));
        }
    }

    private void showFootprint(LinearLayout fp, OrderFlow.Footprint ft) {
        fp.removeAllViews();
        if (ft.levels.isEmpty()) { fp.addView(text("Is candle mein trades nahi mile.", 12, MUTED)); return; }
        double d = ft.totalBuy - ft.totalSell;
        fp.addView(bold(String.format(Locale.US, "Footprint (%s trades) · buyers %s · sellers %s · Δ %s%s", Fmt.num(ft.trades), OrderFlow.k(ft.totalBuy), OrderFlow.k(ft.totalSell),
                d >= 0 ? "+" : "−", OrderFlow.k(Math.abs(d))), 12, d >= 0 ? GREEN : RED));
        fp.addView(text("Price  |  SELLERS ✕ BUYERS   (◀ = sellers ka imbalance · ▶ = buyers ka imbalance · ★ = sab se zyada volume)", 10, MUTED));
        for (OrderFlow.Level l : ft.levels) {
            TextView t = text(String.format(Locale.US, "%s%-11s %8s ✕ %-8s%s", l.poc ? "★" : " ", Fmt.price(l.price), OrderFlow.k(l.sell), OrderFlow.k(l.buy),
                    l.imbSell ? " ◀" : l.imbBuy ? " ▶" : ""), 11, l.imbBuy ? GREEN : l.imbSell ? RED : l.poc ? YELLOW : SOFT);
            t.setTypeface(Typeface.MONOSPACE);
            fp.addView(t);
        }
    }

    // ------------------------------------------------------------------ 🤖 AutoPilot
    private String apShownEx;
    private boolean apLiveConfirm;

    private void openAutoPilot() {
        LinearLayout col = openPage("🤖 AutoPilot (auto trade)");
        renderAutoPilot(col);
    }

    private void renderAutoPilot(final LinearLayout col) {
        col.removeAllViews();
        final String mode = AutoPilot.mode(this);
        if (apShownEx == null) apShownEx = AutoPilot.exchange(this);
        final String ex = apShownEx;

        LinearLayout w = card(col, RED);
        w.addView(bold("⚠️ Pehle yeh padhein", 15, RED));
        w.addView(text("• Koi bot profit ki guarantee nahi de sakta — kaun si bhi strategy ghalat ja sakti hai. Sirf wohi paisa lagayen jo khone ka dukh na ho.\n"
                + "• Pehle 📝 PAPER mode mein kam az kam 1–2 hafte chalayen (asli prices, nakli paisa). Natija achha ho tabhi LIVE.\n"
                + "• API key mein SIRF 'Spot trading' ki ijazat dein. WITHDRAWAL ki ijazat KABHI na dein. Ho sakay to IP whitelist lagayen.\n"
                + "• Stop-loss exchange par rakhe hue order nahi — app har ~5 second mein khud dekhta hai. Isliye phone online rahe, ParaDox chalta rahe, battery optimisation band ho.\n"
                + "• Sirf SPOT (khareed aur bech). Leverage / futures / short nahi.\n"
                + "• Key phone ke Android Keystore mein encrypt hoti hai, kisi server par nahi jaati.", 12, SOFT));

        // ---- mode
        LinearLayout m = card(col, mode.equals(AutoPilot.LIVE) ? RED : mode.equals(AutoPilot.PAPER) ? YELLOW : STROKE);
        m.addView(bold("Mode", 16, TEXT));
        m.addView(text(mode.equals(AutoPilot.OFF) ? "⚪ OFF — kuch nahi hota" : mode.equals(AutoPilot.PAPER) ? "🟡 PAPER — asli prices par nakli trade (paisa nahi lagta)"
                : "🔴 LIVE — " + AutoPilot.exchange(this) + " par asli paisa se khareed/farokht", 13, TEXT));
        if (Prefs.getBool(this, "apKill", false)) m.addView(bold("🛑 Kill switch laga hua hai — dobara chalane ke liye PAPER ya LIVE chunein", 12, RED));
        LinearLayout mr = row();
        final String[] ms = {AutoPilot.OFF, AutoPilot.PAPER, AutoPilot.LIVE};
        final String[] ml = {"⚪ OFF", "🟡 PAPER", "🔴 LIVE"};
        for (int i = 0; i < 3; i++) {
            final String k = ms[i];
            TextView ch = chip(ml[i], k.equals(mode));
            ch.setOnClickListener(v -> {
                if (k.equals(AutoPilot.LIVE)) {
                    if (!KeyVault.has(this, AutoPilot.exchange(this))) { toast("Pehle " + AutoPilot.exchange(this) + " ki API key save + test karein"); return; }
                    apLiveConfirm = true;
                } else {
                    apLiveConfirm = false;
                    Prefs.putBool(this, "apKill", false);
                    AutoPilot.setMode(this, k);
                    if (!k.equals(AutoPilot.OFF) && !Prefs.enabled(this)) toast("Bot (Settings mein Start) chalu hona chahiye, warna AutoPilot kaam nahi karega");
                }
                renderAutoPilot(col);
            });
            mr.addView(ch, chipLp());
        }
        m.addView(hscroll(mr));
        if (apLiveConfirm) {
            LinearLayout cf = card(m, RED);
            cf.addView(bold("LIVE chalane se pehle tasdeeq", 14, RED));
            cf.addView(text(AutoPilot.exchange(this) + " ke asli paisa se trade honge. Har trade ka size: " + (int) AutoPilot.perTrade(this) + " USDT (zyada se zyada account ka 25%). "
                    + "Aaj ka loss " + (int) AutoPilot.dayLoss(this) + " USDT par naye trade band ho jayenge. Neeche LIVE likh kar tasdeeq karein.", 12, SOFT));
            final EditText ce = input("LIVE likhein", "", InputType.TYPE_CLASS_TEXT);
            cf.addView(ce);
            Button go = button("🔴 LIVE shuru karein", RED, INK, RED);
            go.setOnClickListener(v -> {
                if (!"LIVE".equals(ce.getText().toString().trim())) { toast("Tasdeeq ke liye bilkul LIVE likhein"); return; }
                Prefs.putBool(this, "apKill", false);
                AutoPilot.setMode(this, AutoPilot.LIVE);
                apLiveConfirm = false;
                AutoPilot.log(this, "🔴 LIVE mode ON (" + AutoPilot.exchange(this) + ")");
                renderAutoPilot(col);
            });
            cf.addView(go);
        }
        Button kill = button("🛑 KILL SWITCH — sab band + khuli positions market par bech do", RED, TEXT, RED);
        kill.setOnClickListener(v -> {
            toast("Kill switch chal gaya...");
            pool.execute(() -> { AutoPilot.kill(this, true); runOnUiThread(() -> renderAutoPilot(col)); });
        });
        m.addView(kill);
        Button stop = button("⏸ Naye trade band (khuli positions chalti rahengi)", CHIP, TEXT, STROKE);
        stop.setOnClickListener(v -> { AutoPilot.setMode(this, AutoPilot.OFF); renderAutoPilot(col); });
        m.addView(stop);

        // ---- exchange connect
        LinearLayout e = card(col, ACC);
        e.addView(bold("🔌 Exchange connect", 16, TEXT));
        e.addView(text("Exchange chunein, API key + secret daalein, Save, phir Test (sirf balance padhta hai — koi order nahi).", 12, MUTED));
        LinearLayout er = row();
        for (final String n : ExchangeApi.NAMES) {
            TextView ch = chip((KeyVault.has(this, n) ? "✅ " : "") + n, n.equals(ex));
            ch.setOnClickListener(v -> { apShownEx = n; Prefs.putStr(this, "apEx", n); renderAutoPilot(col); });
            er.addView(ch, chipLp());
        }
        e.addView(hscroll(er));
        e.addView(text("Saved: " + (KeyVault.has(this, ex) ? "API key " + KeyVault.mask(KeyVault.apiKey(this, ex)) + " ✅ (encrypted)" : "koi key nahi"), 12, KeyVault.has(this, ex) ? GREEN : MUTED));
        final EditText ke = field(e, "API Key", "", InputType.TYPE_CLASS_TEXT);
        final EditText se = field(e, "API Secret", "", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        final EditText pe = ExchangeApi.needsPassphrase(ex) ? field(e, "Passphrase (OKX mein zaroori)", "", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD) : null;
        final TextView res = text("", 12, SOFT);
        Button sv = button("💾 Save (encrypt karke)", ACC, INK, ACC);
        sv.setOnClickListener(v -> {
            String k = ke.getText().toString().trim(), s = se.getText().toString().trim(), p = pe == null ? "" : pe.getText().toString().trim();
            if (k.length() < 8 || s.length() < 8) { toast("Key aur secret dono daalein"); return; }
            if (pe != null && p.isEmpty()) { toast("OKX ke liye passphrase bhi chahiye"); return; }
            KeyVault.save(this, ex, k, s, p);
            if (!KeyVault.has(this, ex)) { toast("Is phone par secure storage nahi chali — key save nahi hui"); return; }
            ke.setText(""); se.setText(""); if (pe != null) pe.setText("");
            hideKeyboard();
            toast("✅ " + ex + " ki key mehfooz (encrypted)");
            renderAutoPilot(col);
        });
        e.addView(sv);
        Button ts = button("🧪 Connection test (sirf balance)", CHIP, TEXT, STROKE);
        ts.setOnClickListener(v -> {
            if (!KeyVault.has(this, ex)) { toast("Pehle key save karein"); return; }
            res.setText("⏳ Test ho raha hai...");
            pool.execute(() -> {
                final String out = ExchangeApi.create(ex, KeyVault.apiKey(this, ex), KeyVault.secret(this, ex), KeyVault.pass(this, ex)).test();
                runOnUiThread(() -> { res.setText(out); res.setTextColor(out.startsWith("✅") ? GREEN : RED); });
            });
        });
        e.addView(ts);
        e.addView(res);
        Button rm = button("🗑 Is exchange ki key hata dein", CHIP, RED, STROKE);
        rm.setOnClickListener(v -> { KeyVault.clear(this, ex); renderAutoPilot(col); });
        e.addView(rm);
        String guide;
        switch (ex) {
            case "MEXC": guide = "MEXC → Profile → API Management → Create. Permissions: sirf 'Spot Trading' (Account Read + Spot Trade). Withdraw NA tick karein. Key + Secret yahan paste karein."; break;
            case "Binance": guide = "Binance → Profile → API Management → Create API → System generated. 'Enable Spot & Margin Trading' tick karein, 'Enable Withdrawals' NA tick karein. IP restriction lagana behtar hai."; break;
            case "Bybit": guide = "Bybit → Profile → API → Create New Key → API Transaction. Permissions: 'Spot → Trade' (aur Read). Withdrawal permission NA dein. Account Unified ho ya Classic, dono chalte hain."; break;
            case "OKX": guide = "OKX → Profile → API → Create API key. Permission: 'Trade' (Read bhi). 'Withdraw' NA dein. Passphrase woh hai jo aap key banate waqt likhte hain — woh yahan bhi daalna zaroori hai."; break;
            default: guide = "Gate → Profile → API Management → Create API Key (v4). Spot Trade = Read & Write, Withdrawal = NA dein."; break;
        }
        e.addView(text("📖 " + ex + " ki key kaise banayen:\n" + guide, 12, MUTED));
        e.addView(text("Baqi exchanges (Bitget, KuCoin, HTX...) ka connector isi tarah ek file ka kaam hai — zaroorat ho to bataiye.", 11, MUTED));

        // ---- risk settings
        LinearLayout s = card(col, STROKE);
        s.addView(bold("🛡️ Risk settings", 16, TEXT));
        final EditText usdt = numField(s, "Har trade kitne USDT (chhota rakhein; account ka 25% se zyada kabhi nahi)", (int) AutoPilot.perTrade(this));
        final EditText mx = numField(s, "Ek waqt mein zyada se zyada kitne trade", AutoPilot.maxOpen(this));
        final EditText dl = numField(s, "Aaj ka max loss (USDT) — iske baad naye trade band", (int) AutoPilot.dayLoss(this));
        final EditText hd = numField(s, "Zyada se zyada kitne ghante position rakhni (time-stop)", (int) AutoPilot.maxHoldH(this));
        s.addView(text("Entry ke liye kitne judges (7 mein se) haq mein hon:", 12, MUTED));
        LinearLayout vr = row();
        for (final int vv : new int[]{4, 5, 6, 7}) {
            TextView ch = chip(vv + "/7", AutoPilot.minVotes(this) == vv);
            ch.setOnClickListener(v -> { Prefs.putInt(this, "apVotes", vv); renderAutoPilot(col); });
            vr.addView(ch, chipLp());
        }
        s.addView(hscroll(vr));
        toggle(s, "📊 Order flow zaroori", "Candle ke neeche ke numbers (buyers vs sellers) khilaf hon to entry nahi", AutoPilot.needFlow(this), (b, on) -> Prefs.putBool(this, "apFlow", on));
        Button ss = button("💾 Risk settings save", ACC, INK, ACC);
        ss.setOnClickListener(v -> {
            Prefs.putInt(this, "apUsdt", Math.max(5, parseInt(usdt, 10)));
            Prefs.putInt(this, "apMax", Math.max(1, Math.min(10, parseInt(mx, 3))));
            Prefs.putInt(this, "apDayLoss", Math.max(1, parseInt(dl, 20)));
            Prefs.putInt(this, "apHold", Math.max(1, parseInt(hd, 72)));
            hideKeyboard();
            toast("Settings save ho gayin");
            renderAutoPilot(col);
        });
        s.addView(ss);
        s.addView(text("Entry tab hi hoti hai jab: bot ka BUY signal aaye + Trade Agent BUY kahe + kam az kam " + AutoPilot.minVotes(this) + "/7 judges haq mein, 1 se zyada khilaf na hon + order flow sellers ke haq mein na ho + volume liquid ho + price entry zone mein ho. "
                + "Exit: stop-loss · TP1 par 1/3 becho aur stop entry par · TP2 par aadha baqi · TP3 par sab · time-stop.", 11, MUTED));

        // ---- positions
        List<AutoPilot.Pos> ps = AutoPilot.positions(this);
        LinearLayout p = card(col, GREEN);
        double paper = 0, live = 0;
        int wins = 0, closed = 0;
        for (AutoPilot.Pos x : ps) if (x.closed) { if (x.live) live += x.pnl(); else paper += x.pnl(); closed++; if (x.pnl() > 0) wins++; }
        p.addView(bold("📋 Positions", 16, TEXT));
        p.addView(text(String.format(Locale.US, "Aaj ka P&L: %+.2f USDT · Paper kul: %+.2f · LIVE kul: %+.2f · band trade %d (jeete %d)", AutoPilot.todayPnl(this), paper, live, closed, wins), 12, SOFT));
        int shown = 0;
        for (int i = ps.size() - 1; i >= 0 && shown < 15; i--) {
            AutoPilot.Pos x = ps.get(i);
            shown++;
            LinearLayout it = column();
            it.setPadding(0, dp(6), 0, dp(6));
            if (!x.closed) {
                it.addView(bold((x.live ? "🔴 LIVE " : "🟡 PAPER ") + x.coin + " · khuli · stage " + x.stage + "/3", 13, TEXT));
                it.addView(text(String.format(Locale.US, "Entry $%s · qty %s · SL $%s · TP1 $%s · TP2 $%s · TP3 $%s", Fmt.price(x.entry), OrderFlow.k(x.qty), Fmt.price(x.sl), Fmt.price(x.tp1), Fmt.price(x.tp2), Fmt.price(x.tp3)), 11, MUTED));
            } else {
                it.addView(bold((x.pnl() >= 0 ? "✅ " : "❌ ") + (x.live ? "LIVE " : "PAPER ") + x.coin + String.format(Locale.US, " · %+.2f USDT (%+.1f%%)", x.pnl(), x.cost > 0 ? x.pnl() / x.cost * 100 : 0), 13, x.pnl() >= 0 ? GREEN : RED));
                it.addView(text(x.exitWhy + " · " + new SimpleDateFormat("dd MMM HH:mm", Locale.US).format(new Date(x.exitT)), 11, MUTED));
            }
            p.addView(it);
            p.addView(divider());
        }
        if (ps.isEmpty()) p.addView(text("Abhi koi trade nahi. Signal aane aur sab shartein poori hone par yahan nazar aayega.", 12, MUTED));

        // ---- log
        LinearLayout lg = card(col, STROKE);
        lg.addView(bold("🧾 AutoPilot log (kya socha, kya nahi liya, kyun)", 14, TEXT));
        int n = 0;
        for (String l : AutoPilot.log(this)) { if (n++ >= 30) break; lg.addView(text(l, 11, SOFT)); }
        if (n == 0) lg.addView(text("Abhi khali.", 11, MUTED));
        lg.addView(text("AutoPilot.status: " + (AutoPilot.status.isEmpty() ? "ok" : AutoPilot.status), 10, MUTED));
    }

    private int parseInt(EditText e, int def) {
        try { return (int) Math.round(Double.parseDouble(e.getText().toString().trim())); } catch (Exception x) { return def; }
    }

    // ------------------------------------------------------------------ 🩸 Dip Hunter
    private void openDipHunter() {
        LinearLayout col = openPage("🩸 Dip Hunter");
        LinearLayout h = card(col, GREEN);
        h.addView(bold("Bohat gire hue coins jo wapas upar ja sakte hain", 15, TEXT));
        h.addView(text("Sirf 'gira hua' kafi nahi — coin ko liquid hona chahiye aur girawat ruk jane ke saboot hon: oversold RSI, washout volume, naya low nahi, buyers wapas (order flow), hammer. "
                + "Jo coin abhi bhi naye low bana raha ho use ⚠️ 'girta chaqu' likha jata hai. Score reversal ka saboot hai, jeetne ki probability nahi.", 12, MUTED));
        toggle(h, "🔔 Background alert", "Har 45 min scan · mazboot (72+) reversal par ek notification (har coin 24 ghante mein ek baar)", DipHunter.on(this), (b, on) -> Prefs.putBool(this, "dipOn", on));
        final int[] drop = {Prefs.getInt(this, "dipDrop", 30)};
        LinearLayout dr = row();
        final LinearLayout body = column();
        final TextView[] dc = new TextView[3];
        final int[] dv = {25, 30, 45};
        for (int i = 0; i < 3; i++) {
            final int k = i;
            dc[i] = chip("≥" + dv[i] + "% gira", dv[i] == drop[0]);
            dc[i].setOnClickListener(v -> { drop[0] = dv[k]; Prefs.putInt(this, "dipDrop", dv[k]); for (int z = 0; z < 3; z++) styleChip(dc[z], z == k); });
            dr.addView(dc[i], chipLp());
        }
        h.addView(hscroll(dr));
        Button go = button("🔍 Abhi scan karein (top 120 liquid coins)", ACC, INK, ACC);
        go.setOnClickListener(v -> {
            body.removeAllViews();
            body.addView(text("⏳ Scan ho raha hai (10–25 second)...", 13, MUTED));
            pool.execute(() -> {
                try {
                    final List<DipHunter.Pick> l = DipHunter.scan(120, drop[0]);
                    runOnUiThread(() -> renderDips(body, l));
                } catch (Exception ex) {
                    final String m = ex.getMessage();
                    runOnUiThread(() -> { body.removeAllViews(); body.addView(text("Scan nahi hua: " + m, 12, RED)); });
                }
            });
        });
        h.addView(go);
        col.addView(body);
        if (!DipHunter.last.isEmpty()) {
            body.addView(text("Pichla scan " + new SimpleDateFormat("HH:mm", Locale.US).format(new Date(DipHunter.lastRun)) + ":", 11, MUTED));
            renderDips(body, DipHunter.last);
        }
    }

    private void renderDips(LinearLayout body, List<DipHunter.Pick> l) {
        body.removeAllViews();
        body.addView(text(new SimpleDateFormat("dd MMM HH:mm", Locale.US).format(new Date()) + " · " + l.size() + " coin mile jo kaafi gire hain", 11, MUTED));
        if (l.isEmpty()) body.addView(text("Abhi koi liquid coin itna gira hua nahi mila.", 13, SOFT));
        for (final DipHunter.Pick p : l) {
            int col = p.knife ? RED : p.score >= 70 ? GREEN : p.score >= 55 ? YELLOW : MUTED;
            LinearLayout c = card(body, col);
            LinearLayout hr = row();
            hr.addView(bold(p.coin + "/USDT", 16, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
            hr.addView(bold(p.score + "/100", 15, col));
            c.addView(hr);
            c.addView(bold(p.label(), 13, col));
            c.addView(text(String.format(Locale.US, "Price $%s · 24h %+.1f%% · 30-din high se −%.0f%% · RSI(d) %.0f · volume %s", Fmt.price(p.price), p.change24h, p.dropFromHigh, p.rsiD, Fmt.usd(p.vol24h)), 12, SOFT));
            for (String w : p.why) c.addView(text("• " + w, 11, MUTED));
            c.addView(bold(String.format(Locale.US, "🛑 Stop $%s · 🎯 TP1 $%s · TP2 $%s · TP3 $%s (girawat ka 38/50/62%% wapas) · TP1 R:R %.1f", Fmt.price(p.stop), Fmt.price(p.t1), Fmt.price(p.t2), Fmt.price(p.t3), p.rr1), 12, GREEN));
            LinearLayout br = row();
            TextView an = chip("🔎 Poora analysis", true);
            an.setOnClickListener(v -> analyzeFromPage(p.coin));
            br.addView(an, chipLp());
            TextView hi = chip("🕰 History compare", false);
            hi.setOnClickListener(v -> openHistory(p.coin));
            br.addView(hi, chipLp());
            c.addView(hscroll(br));
        }
        body.addView(text("Yeh trade ka mashwara nahi — pehle poora analysis aur stop dekhein. Girta hua coin aur gir sakta hai; stop zaroor lagayen.", 11, MUTED));
    }

    // ------------------------------------------------------------------ 🎉 Events
    private void openEvents() {
        LinearLayout col = openPage("🎉 Occasions calendar");
        LinearLayout h = card(col, YELLOW);
        h.addView(bold("Cat Day · Dog Day · Pi Day · Pizza Day ...", 15, TEXT));
        h.addView(text("Theme wale coins aksar event se PEHLE hype pakadte hain. App har event se 7 / 3 / 1 din pehle aur us din notification deta hai, saath mein pichle saalon ka run-up. "
                + "Yeh mausami hype hai — pakki cheez nahi, aur sample chhota hota hai (2–3 saal). Event ke baad aksar dump bhi aata hai: 'event se pehle buy, event par/baad sell' sochein, hold nahi.", 12, MUTED));
        toggle(h, "🔔 Event alerts", "Har event se 7, 3, 1 din pehle aur us din", Prefs.getBool(this, "evOn", true), (b, on) -> Prefs.putBool(this, "evOn", on));
        for (final EventCal.Next n : EventCal.upcoming(System.currentTimeMillis())) {
            int colr = n.daysLeft <= 7 ? GREEN : n.daysLeft <= 30 ? YELLOW : STROKE;
            final LinearLayout c = card(col, colr);
            LinearLayout hr = row();
            hr.addView(bold(n.ev.emoji + " " + n.ev.name, 15, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
            hr.addView(bold(n.daysLeft == 0 ? "AAJ" : n.daysLeft + " din", 14, colr == STROKE ? MUTED : colr));
            c.addView(hr);
            c.addView(text(EventCal.dateText(n) + " · " + n.ev.note, 12, SOFT));
            c.addView(text("Coins: " + String.join(" · ", n.ev.coins), 12, ACC2));
            final LinearLayout st = column();
            TextView b = chip("📊 Pichle saalon mein kya hua?", false);
            b.setOnClickListener(v -> {
                st.removeAllViews();
                st.addView(text("⏳ History load ho rahi hai...", 11, MUTED));
                pool.execute(() -> {
                    final List<String> rows = new ArrayList<>();
                    for (String coin : n.ev.coins) {
                        try {
                            List<EventCal.Year> ys = EventCal.studyCoin(coin, n.ev);
                            if (ys.isEmpty()) { rows.add(coin + ": is tareekh ka data nahi"); continue; }
                            StringBuilder sb = new StringBuilder(coin + ": ");
                            for (EventCal.Year y : ys) sb.append(String.format(Locale.US, "%d → 7 din pehle se event tak %+.1f%%, event ke 3 din baad %+.1f%%   ", y.year, y.runUp7, y.after3));
                            rows.add(sb.toString().trim());
                        } catch (Exception e) {
                            rows.add(coin + ": data nahi aaya");
                        }
                    }
                    runOnUiThread(() -> {
                        st.removeAllViews();
                        for (String r : rows) st.addView(text(r, 11, SOFT));
                        st.addView(text("Chhota sample — rujhan dikha sakta hai, wada nahi.", 10, MUTED));
                    });
                });
            });
            c.addView(b, chipLp());
            c.addView(st);
        }
    }

    // ------------------------------------------------------------------ 🚨 Hack Watch
    private void openHackWatch() {
        LinearLayout col = openPage("🚨 Exchange Hack Watch");
        LinearLayout h = card(col, RED);
        h.addView(bold("Exchange ya protocol hack ki khabar — jitni jaldi public ho", 15, TEXT));
        h.addView(text("Google News + CoinDesk, Cointelegraph, The Block, Decrypt + DeFiLlama hacks list har ~2 minute check hoti hai. Exchange ka naam + hack/withdrawal-suspend ho to 🚨 notification. "
                + "Seedhi baat: yeh PUBLIC khabar pakadta hai (aam taur par pehli news/post ke 1–10 minute baad). Khabar kabhi kabhi unconfirmed hoti hai — exchange ka official statement zaroor dekhein.", 12, MUTED));
        toggle(h, "🔔 Hack alerts", "Exchange hack / withdrawals band / bara exploit par foran notification", HackWatch.on(this), (b, on) -> Prefs.putBool(this, "hwOn", on));
        final LinearLayout body = column();
        Button rf = button("🔄 Abhi check karein", ACC, INK, ACC);
        rf.setOnClickListener(v -> {
            body.removeAllViews();
            body.addView(text("⏳ Sources check ho rahe hain...", 12, MUTED));
            pool.execute(() -> {
                final List<HackWatch.Item> l = HackWatch.tick(this, true);
                runOnUiThread(() -> renderHacks(body, l));
            });
        });
        h.addView(rf);
        col.addView(body);
        renderHacks(body, HackWatch.cached(this));
        LinearLayout g = card(col, STROKE);
        g.addView(bold("Agar kisi exchange ka hack confirm ho jaye", 14, TEXT));
        g.addView(text("1) Exchange ka official X / announcement dekhein. 2) Agar aap ka paisa wahan hai to withdraw chalta ho to nikalna soch lein (aksar pehle withdrawals band ho jate hain). "
                + "3) Us exchange ka apna token (BNB, OKB, KCS, GT, HT, BGB, MX, CRO...) aksar foran girta hai. 4) Panic mein leverage na len. "
                + "5) Paisa hamesha thora thora kai jagah rakhein — sab ek exchange par nahi.", 12, SOFT));
    }

    private void renderHacks(LinearLayout body, List<HackWatch.Item> l) {
        body.removeAllViews();
        if (l.isEmpty()) { body.addView(text("Pichle 3 din mein koi hack ki khabar nahi mili (ya sources abhi na pohnche).", 13, SOFT)); return; }
        for (final HackWatch.Item it : l) {
            int col = it.sev >= 3 ? RED : it.sev == 2 ? YELLOW : STROKE;
            LinearLayout c = card(body, col);
            c.addView(bold((it.sev >= 3 ? "🚨 " : it.sev == 2 ? "⚠️ " : "• ") + it.title, 13, TEXT));
            c.addView(text(it.when() + " · " + it.source + (it.exchange.isEmpty() ? "" : " · " + it.exchange + (it.token.isEmpty() ? "" : " (" + it.token + ")")) + (it.unconfirmed ? " · unconfirmed" : ""), 11, MUTED));
            if (it.link != null && it.link.startsWith("http")) {
                TextView o = chip("🔗 Khabar kholein", false);
                o.setOnClickListener(v -> { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(it.link))); } catch (Exception ignored) { } });
                c.addView(o, chipLp());
            }
        }
    }

    // ------------------------------------------------------------------ 🕰 History compare
    private boolean histWeekly;

    private void openHistory(String coin) {
        LinearLayout col = openPage("🕰 History compare");
        LinearLayout h = card(col, ACC);
        h.addView(bold("Aaj ki haalat vs maazi", 15, TEXT));
        h.addView(text("Coin ki apni history mein aaj jaisi haalat (pichli move, RSI, high se doori, volume, buyers vs sellers) dhoond kar dikhata hai ke un ke baad kya hua. "
                + "Yeh pichli frequency hai, guarantee nahi.", 12, MUTED));
        final EditText ce = input("Coin (jaise BTC)", coin == null ? "BTC" : coin, InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        h.addView(ce);
        LinearLayout tr = row();
        final TextView d1 = chip("Daily (≈2.7 saal)", !histWeekly), w1 = chip("Weekly (poori history)", histWeekly);
        d1.setOnClickListener(v -> { histWeekly = false; styleChip(d1, true); styleChip(w1, false); });
        w1.setOnClickListener(v -> { histWeekly = true; styleChip(d1, false); styleChip(w1, true); });
        tr.addView(d1, chipLp());
        tr.addView(w1, chipLp());
        h.addView(hscroll(tr));
        final LinearLayout body = column();
        Button go = button("🕰 Compare karein", ACC, INK, ACC);
        go.setOnClickListener(v -> {
            final String c = ce.getText().toString().trim().toUpperCase(Locale.US).replace("USDT", "").replace("/", "");
            if (c.isEmpty()) return;
            hideKeyboard();
            body.removeAllViews();
            body.addView(text("⏳ History load ho rahi hai...", 12, MUTED));
            pool.execute(() -> {
                try {
                    final HistoryCompare.Result r = HistoryCompare.run(c, histWeekly);
                    runOnUiThread(() -> renderHistory(body, r));
                } catch (Exception e) {
                    final String m = e.getMessage();
                    runOnUiThread(() -> { body.removeAllViews(); body.addView(text("History nahi aayi: " + m, 12, RED)); });
                }
            });
        });
        h.addView(go);
        col.addView(body);
        if (coin != null) go.performClick();
    }

    private void renderHistory(LinearLayout body, HistoryCompare.Result r) {
        body.removeAllViews();
        LinearLayout c = card(body, r.ok ? ACC : YELLOW);
        c.addView(bold(r.coin + " — " + r.headline, 14, r.ok ? TEXT : YELLOW));
        if (!r.ok) return;
        for (String s : r.now) c.addView(text("Aaj: " + s, 12, SOFT));
        c.addView(bold(String.format(Locale.US, "Baad ke natije (%d milti-julti haalat): %d %s baad %.0f%% upar (median %+.1f%%) · %d %s baad %.0f%% upar (median %+.1f%%) · %d %s baad %.0f%% upar (median %+.1f%%)",
                r.n, r.h1, r.unit, r.win1, r.med1, r.h2, r.unit, r.win2, r.med2, r.h3, r.unit, r.win3, r.med3), 12, r.med2 >= 0 ? GREEN : RED));
        c.addView(text(String.format(Locale.US, "%d %s baad sab se bura %+.1f%% · sab se achha %+.1f%%", r.h2, r.unit, r.worst2, r.best2), 12, MUTED));
        for (HistoryCompare.Analog a : r.top)
            c.addView(text(String.format(Locale.US, "• %s (milan %.1f) → %d%s %+.1f%% · %d%s %+.1f%% · %d%s %+.1f%%", a.when(), a.dist, r.h1, r.unit.substring(0, 1), a.r1 * 100, r.h2, r.unit.substring(0, 1), a.r2 * 100, r.h3, r.unit.substring(0, 1), a.r3 * 100), 11, a.r2 >= 0 ? GREEN : RED));
        c.addView(text(r.note, 11, MUTED));
    }

    // ============================================================ v37: 🧠 SMC PRO LAB (signals · paper · backtest · walk-forward · risk)
    private int smcTab = 0;
    private volatile boolean smcBusy;

    private void openSmcLab() {
        LinearLayout col = openPage("🧠 SMC Pro Lab");
        final LinearLayout page = infoOverlay;
        LinearLayout h = card(col, ACC);
        h.addView(bold("Smart Money Concepts · institutional order flow · multi-timeframe", 15, TEXT));
        h.addView(text("BOS / CHoCH / MSS · liquidity sweeps (BSL / SSL, EQH / EQL) · order blocks · FVG / IFVG · breakers · premium / discount · volume. "
                + "Ek hi engine live signals, backtest aur paper trading teeno chalata hai. Paper = asli paisa NAHI.", 12, MUTED));
        toggle(h, "🧠 SMC Pro signals ON", "Har naye 1h / 15m candle close par top coins scan · setup + risk manager OK ho to signal + paper trade", SmcScanner.on(this), (b, on) -> {
            Prefs.putBool(this, "smcOn", on);
            restartService();
        });
        LinearLayout tr = row();
        final String[] tn = {"⚡ Live setups", "📝 Paper (forward)", "🧪 Backtest", "🔁 Walk-forward", "🛡️ Risk", "🚫 NO TRADE log", "📚 Guide"};
        final TextView[] tc = new TextView[tn.length];
        final LinearLayout body = column();
        for (int i = 0; i < tn.length; i++) {
            final int k = i;
            tc[i] = chip(tn[i], i == smcTab);
            tc[i].setTextSize(11);
            tc[i].setOnClickListener(v -> { smcTab = k; for (int z = 0; z < tn.length; z++) styleChip(tc[z], z == k); renderSmc(body, page); });
            tr.addView(tc[i], chipLp());
        }
        h.addView(hscroll(tr));
        col.addView(body);
        renderSmc(body, page);
    }

    private void renderSmc(final LinearLayout b, final LinearLayout page) {
        b.removeAllViews();
        switch (smcTab) {
            case 0: smcLive(b, page); break;
            case 1: smcPaper(b); break;
            case 2: smcBacktestView(b, page, false); break;
            case 3: smcBacktestView(b, page, true); break;
            case 4: smcRisk(b); break;
            case 5: smcRejects(b); break;
            default: smcGuide(b);
        }
    }

    private void smcLive(final LinearLayout b, final LinearLayout page) {
        LinearLayout st = card(b, CYAN_TXT);
        st.addView(text(Prefs.getStr(this, "smcStatus1h", "1h: abhi scan nahi hua") + "\n" + Prefs.getStr(this, "smcStatus15m", "15m: abhi scan nahi hua"), 12, SOFT));
        final TextView pr = text("", 12, ACC2);
        st.addView(pr);
        LinearLayout br = row();
        for (final String tf : new String[]{"1h", "15m"}) {
            Button sb = button("🔍 Abhi scan " + tf, ACC, INK, 0);
            sb.setOnClickListener(v -> {
                if (smcBusy) return;
                smcBusy = true;
                pool.execute(() -> {
                    try { SmcScanner.scan(this, tf, m -> runOnUiThread(() -> pr.setText("⏳ " + m))); } catch (Exception ignored) { }
                    smcBusy = false;
                    runOnUiThread(() -> { if (infoOverlay == page && smcTab == 0) renderSmc(b, page); });
                });
            });
            br.addView(sb, new LinearLayout.LayoutParams(0, -2, 1));
        }
        st.addView(br);
        // market narrative
        final LinearLayout nc = card(b, YELLOW);
        nc.addView(bold("🌍 Market narrative", 14, TEXT));
        final TextView nt = text("Load ho raha hai...", 12, SOFT);
        nc.addView(nt);
        pool.execute(() -> {
            final String s = narrative();
            runOnUiThread(() -> nt.setText(s));
        });
        // MTF table for one coin
        LinearLayout mc = card(b, ACC);
        mc.addView(bold("🧭 Multi-timeframe structure (5m → 1W)", 14, TEXT));
        LinearLayout mr = row();
        final EditText me = input("Coin (jaise BTC)", "BTC", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        mr.addView(me, new LinearLayout.LayoutParams(0, -2, 1));
        final LinearLayout mt = column();
        TextView go = chip("Dekhein", true);
        go.setOnClickListener(v -> { hideKeyboard(); smcMtf(me.getText().toString().trim().toUpperCase(Locale.US).replace("USDT", ""), mt); });
        mr.addView(go, chipLp());
        mc.addView(mr);
        mc.addView(mt);
        // setups
        List<SmcEngine.Setup> ok = new ArrayList<>();
        List<String[]> nos = new ArrayList<>();
        for (Map.Entry<String, SmcEngine.Setup> e : SmcScanner.LAST.entrySet()) {
            if (e.getValue().ok) ok.add(e.getValue()); else nos.add(new String[]{e.getKey(), e.getValue().noTrade, String.valueOf(e.getValue().score)});
        }
        b.addView(bold("\n✅ Valid setups (" + ok.size() + ")", 15, GREEN));
        if (ok.isEmpty()) b.addView(text("Is waqt koi setup saari shartein poori nahi karta → NO TRADE. Quality > quantity.", 12, MUTED));
        for (Map.Entry<String, SmcEngine.Setup> e : SmcScanner.LAST.entrySet()) if (e.getValue().ok) smcCard(b, e.getKey().split("\\|")[0], e.getKey().split("\\|")[1], e.getValue());
        if (!nos.isEmpty()) {
            LinearLayout nc2 = card(b);
            nc2.addView(bold("🚫 NO TRADE (" + nos.size() + ") — kyun", 14, TEXT));
            Collections.sort(nos, (x, y) -> Integer.parseInt(y[2]) - Integer.parseInt(x[2]));
            for (int i = 0; i < nos.size() && i < 40; i++) nc2.addView(text("• " + nos.get(i)[0].replace("|", " ") + ": " + nos.get(i)[1], 11, MUTED));
        }
    }

    private String narrative() {
        StringBuilder sb = new StringBuilder();
        try {
            JSONObject g = fetchGlobal();
            if (g != null) {
                double btcD = g.getJSONObject("market_cap_percentage").optDouble("btc", 0), ethD = g.getJSONObject("market_cap_percentage").optDouble("eth", 0);
                double tot = g.getJSONObject("total_market_cap").optDouble("usd", 0), ch = g.optDouble("market_cap_change_percentage_24h_usd", 0);
                sb.append(String.format(Locale.US, "💰 Total crypto market cap %s (%+.1f%% 24h)\n👑 BTC dominance %.1f%% · ETH %.1f%% · altcoins %.1f%%", Fmt.usd(tot), ch, btcD, ethD, 100 - btcD - ethD));
                sb.append(btcD > 58 ? " → paisa BTC mein, altcoins kamzor" : btcD < 50 ? " → altcoins ka zor (alt season ke nishaan)" : " → mila jula");
            }
        } catch (Exception ignored) {
        }
        String[] fg = SmcScanner.on(this) ? SmartMoney.fearGreed() : null;
        if (fg != null) sb.append("\n😨 Fear & Greed: ").append(fg[0]).append(" (").append(fg[1]).append(")");
        try {
            JSONArray cats = new JSONArray(Scanner.getAbsolute("https://api.coingecko.com/api/v3/coins/categories"));
            String[][] want = {{"artificial-intelligence", "AI"}, {"real-world-assets-rwa", "RWA"}, {"depin", "DePIN"}, {"decentralized-finance-defi", "DeFi"}, {"gaming", "Gaming"}, {"meme-token", "Meme"}, {"layer-1", "Layer 1"}};
            sb.append("\n🔥 Sectors (24h):");
            for (String[] w : want)
                for (int i = 0; i < cats.length(); i++) {
                    JSONObject o = cats.getJSONObject(i);
                    if (w[0].equals(o.optString("id"))) { sb.append(String.format(Locale.US, "  %s %+.1f%%", w[1], o.optDouble("market_cap_change_24h", 0))); break; }
                }
        } catch (Exception ignored) {
        }
        sb.append("\n(CoinGecko · alternative.me · waqt: ").append(new SimpleDateFormat("HH:mm", Locale.US).format(new Date())).append(")");
        return sb.toString();
    }

    private void smcMtf(final String coin, final LinearLayout out) {
        out.removeAllViews();
        out.addView(text("⏳ " + coin + "...", 12, MUTED));
        pool.execute(() -> {
            final String[] tfs = {"5m", "15m", "1h", "4h", "1d", "1w"};
            final String[] res = new String[tfs.length];
            for (int i = 0; i < tfs.length; i++) {
                try {
                    Candles c = Candles.fetch(coin + "USDT", tfs[i], 300, true);
                    Smc.Result r = Smc.analyze(c, c.n - 1, 250);
                    Smc.Event e = r.events.isEmpty() ? null : r.events.get(r.events.size() - 1);
                    res[i] = (r.trend > 0 ? "🟢 Bullish" : r.trend < 0 ? "🔴 Bearish" : "⚪ —") + (e == null ? "" : " · " + (e.bull ? "↑" : "↓") + e.type + " " + (r.end - e.i) + "c")
                            + String.format(Locale.US, " · %s", r.rangePos() > 0.5 ? "premium" : "discount");
                } catch (Exception ex) {
                    res[i] = "data nahi";
                }
            }
            runOnUiThread(() -> {
                out.removeAllViews();
                int bull = 0, bear = 0;
                for (int i = 0; i < tfs.length; i++) {
                    LinearLayout r = row();
                    r.addView(bold(tfs[i].toUpperCase(Locale.US), 12, TEXT), new LinearLayout.LayoutParams(dp(46), -2));
                    r.addView(text(res[i], 12, SOFT));
                    out.addView(r);
                    if (res[i].startsWith("🟢")) bull++; else if (res[i].startsWith("🔴")) bear++;
                }
                out.addView(bold(bull >= 5 ? "✅ Taqreeban saare timeframes BULLISH — longs ke haq mein" : bear >= 5 ? "✅ Taqreeban saare timeframes BEARISH — shorts ke haq mein"
                        : "⚠️ Timeframes mile jule — higher (4h/1D/1W) ka bias follow karein, chhote par sirf entry", 12, YELLOW));
            });
        });
    }

    private void smcCard(LinearLayout b, final String coin, final String tf, final SmcEngine.Setup s) {
        int col = s.isLong ? GREEN : RED;
        LinearLayout c = card(b, col);
        LinearLayout hr = row();
        hr.addView(bold((s.isLong ? "🟢 LONG " : "🔴 SHORT ") + coin + "/USDT · " + tf, 16, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        hr.addView(bold(s.score + "/100", 15, col));
        c.addView(hr);
        c.addView(text("🕒 " + PumpHunter.when(s.t + (tf.equals("1h") ? 3600_000L : 900_000L)) + " (candle close)", 11, MUTED));
        c.addView(bold("📥 Entry zone $" + Fmt.price(s.zoneLo) + " – $" + Fmt.price(s.zoneHi) + " · limit ~$" + Fmt.price(s.entry), 13, TEXT));
        c.addView(bold("🛑 SL $" + Fmt.price(s.sl) + String.format(Locale.US, " (%.2f%%)", Math.abs(s.entry - s.sl) / s.entry * 100), 13, RED));
        c.addView(bold(String.format(Locale.US, "🎯 TP1 $%s (%.1fR) · TP2 $%s (%.1fR) · TP3 $%s (%.1fR)", Fmt.price(s.tp1), s.rr1, Fmt.price(s.tp2), s.rr2, Fmt.price(s.tp3),
                Math.abs(s.tp3 - s.entry) / Math.abs(s.entry - s.sl)), 13, GREEN));
        for (String w : s.why) c.addView(text(w, 12, SOFT));
        c.addView(bold("Confidence ka hisaab (quality score — win probability NAHI):", 12, TEXT));
        for (int i = 0; i < 8; i++) {
            LinearLayout r = row();
            r.addView(text(SmcEngine.PART_NAMES[i], 11, MUTED), new LinearLayout.LayoutParams(dp(130), -2));
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(7), 1);
            bp.topMargin = dp(5);
            r.addView(bar(s.parts[i] * 100.0 / SmcEngine.PART_MAX[i], col, 0xFF243049), bp);
            r.addView(text(" " + s.parts[i] + "/" + SmcEngine.PART_MAX[i], 11, SOFT), new LinearLayout.LayoutParams(dp(44), -2));
            c.addView(r);
        }
        double R = Math.abs(s.entry - s.sl), risk = PaperBook.account(this) * PaperBook.riskPct(this) / 100;
        c.addView(text(String.format(Locale.US, "💼 $%.0f account · %.1f%% risk = $%.0f → size ~%s %s (~$%.0f). TP1 par 1/3 + stop entry par, TP2 par 1/3 + stop TP1 par, TP3 baqi. %d candles mein fill na ho to cancel.",
                PaperBook.account(this), PaperBook.riskPct(this), risk, Fmt.num(R > 0 ? risk / R : 0), coin, R > 0 ? risk / R * s.entry : 0, 6), 12, YELLOW));
        LinearLayout br = row();
        Button an = button("📈 Chart", ACC, INK, 0);
        an.setOnClickListener(v -> { closeInfo(); openAnalyze(coin + "USDT"); });
        br.addView(an, new LinearLayout.LayoutParams(0, -2, 1));
        final LinearLayout chat = column();
        Button ai = button("🤖 AI review", CLAUDE, INK, 0);
        final StringBuilder data = new StringBuilder();
        data.append(coin).append(" ").append(tf).append(s.isLong ? " LONG" : " SHORT").append(" setup by a deterministic SMC engine. Entry ").append(Fmt.price(s.entry))
                .append(" SL ").append(Fmt.price(s.sl)).append(" TP1 ").append(Fmt.price(s.tp1)).append(" TP2 ").append(Fmt.price(s.tp2)).append(" TP3 ").append(Fmt.price(s.tp3))
                .append(" confidence ").append(s.score).append("\n");
        for (String w : s.why) data.append(w).append('\n');
        ai.setOnClickListener(v -> askAi(data.toString(), chat, new ArrayList<>(), "Sirf upar ke data se (koi naya data mat banao): bullish aur bearish dono scenario compare karo, "
                + "kaun se nishaan takra rahe hain, setup kitna valid hai, aur kis cheez se yeh ghalat sabit hoga. Risk rules nahi badalne."));
        br.addView(ai, new LinearLayout.LayoutParams(0, -2, 1));
        c.addView(br);
        c.addView(chat);
    }

    private void statRows(LinearLayout c, String title, TradeSim.Stats s) {
        c.addView(bold(title, 13, TEXT));
        if (s.n == 0) { c.addView(text("Abhi koi mukammal trade nahi", 12, MUTED)); return; }
        c.addView(text(String.format(Locale.US, "Trades %d · ✅ %d · ❌ %d · Win %.1f%% (95%% CI %.0f–%.0f%%)\nProfit factor %s · Expectancy %+.2fR · Net %+.1fR (%+.1f%%)\nMax drawdown %.1fR (%.1f%%) · Sharpe %.2f · "
                        + "lagatar jeet %d / haar %d · avg jeet %+.2fR · avg haar %+.2fR",
                s.n, s.wins, s.losses, s.winRate, s.wilsonLo, s.wilsonHi, Double.isInfinite(s.profitFactor) ? "∞" : String.format(Locale.US, "%.2f", s.profitFactor), s.expectancyR,
                s.netR, s.netPct, s.maxDdR, s.maxDdPct, s.sharpe, s.maxWinStreak, s.maxLossStreak, s.avgWinR, s.avgLossR), 12, SOFT));
    }

    private void smcPaper(LinearLayout b) {
        LinearLayout h = card(b, YELLOW);
        h.addView(bold("📝 LIVE FORWARD TEST — PAPER TRADING (asli paisa nahi)", 14, TEXT));
        h.addView(text("Har SMC Pro signal yahan timestamp ke saath darj hota hai aur asal 5-minute candles par follow hota hai — wahi execution model jo backtest mein (limit entry, "
                + "same-candle = stop pehle, partials, break-even, trailing, fee 0.05%, slippage 0.05%, funding). Band trade kabhi badla nahi jata. "
                + "Mayaar: kam az kam 30 din aur 100+ mukammal trades ke baad hi koi nateeja maaniye.", 12, MUTED));
        TradeSim.Stats all = PaperBook.stats(this, null, null);
        statRows(h, "Sab paper trades", all);
        // live vs backtest
        try {
            JSONObject bt = new JSONObject(Prefs.getStr(this, "smcbt", "{}")).optJSONObject("full");
            if (bt != null && bt.optInt("n") > 0 && all.n > 0) {
                double d = all.expectancyR - bt.optDouble("exp");
                h.addView(bold(String.format(Locale.US, "Backtest vs live: expectancy %+.2fR vs %+.2fR · win %.0f%% vs %.0f%%", bt.optDouble("exp"), all.expectancyR, bt.optDouble("wr"), all.winRate), 12, TEXT));
                if (all.n >= 20 && d < -0.3) h.addView(text("⚠️ Live nateeja backtest se kaafi kharab — market regime badla ho sakta hai. Settings sakht karein (confidence ↑) aur dobara backtest karein.", 12, RED));
            }
        } catch (Exception ignored) {
        }
        for (String tf : new String[]{"1h", "15m"}) statRows(card(b), "Timeframe " + tf, PaperBook.stats(this, null, tf));
        List<JSONObject> l = PaperBook.all(this);
        Map<String, Integer> coins = new java.util.LinkedHashMap<>();
        for (JSONObject o : l) if ("closed".equals(o.optString("st"))) coins.put(o.optString("coin"), 1);
        if (!coins.isEmpty()) {
            LinearLayout cc = card(b);
            cc.addView(bold("Coin-wise", 13, TEXT));
            for (String co : coins.keySet()) cc.addView(text(co + ": " + PaperBook.stats(this, co, null).line(), 11, SOFT));
        }
        b.addView(bold("\nTrades (naye pehle)", 14, TEXT));
        if (l.isEmpty()) b.addView(text("Abhi koi paper trade nahi — SMC Pro signal aate hi yahan darj hoga.", 12, MUTED));
        for (int i = l.size() - 1; i >= 0 && i >= l.size() - 60; i--) {
            JSONObject o = l.get(i);
            String st = o.optString("st");
            boolean win = o.optDouble("r", 0) > 0;
            LinearLayout c = card(b, st.equals("closed") ? (win ? GREEN : RED) : st.equals("open") ? ACC : STROKE);
            c.addView(bold((o.optBoolean("long") ? "🟢 LONG " : "🔴 SHORT ") + o.optString("coin") + " · " + o.optString("tf") + " · " + o.optInt("score") + "/100", 13, TEXT));
            c.addView(text("🕒 Signal: " + PumpHunter.when(o.optLong("t")) + (o.has("fillT") ? "\n📥 Fill: " + PumpHunter.when(o.optLong("fillT")) : "")
                    + (o.has("exitT") ? "\n🏁 Band: " + PumpHunter.when(o.optLong("exitT")) : ""), 11, MUTED));
            c.addView(text(String.format(Locale.US, "Entry $%s · SL $%s · TP $%s / $%s / $%s", Fmt.price(o.optDouble("entry")), Fmt.price(o.optDouble("sl")), Fmt.price(o.optDouble("tp1")),
                    Fmt.price(o.optDouble("tp2")), Fmt.price(o.optDouble("tp3"))), 11, SOFT));
            String res = st.equals("closed") ? String.format(Locale.US, "%s %+.2fR · %s", win ? "✅" : "❌", o.optDouble("r"), o.optString("exitWhy"))
                    : st.equals("open") ? String.format(Locale.US, "🟢 OPEN · TP hit %d · abhi %+.2fR (unrealized) · price $%s", o.optInt("hits"), o.optDouble("ur", 0), Fmt.price(o.optDouble("px", 0)))
                    : st.equals("pending") ? "⏳ Entry ka intezar (limit)" : "⌛ " + o.optString("exitWhy", st);
            c.addView(bold(res, 12, st.equals("closed") ? (win ? GREEN : RED) : TEXT));
        }
    }

    private void smcBacktestView(final LinearLayout b, final LinearLayout page, boolean wfOnly) {
        LinearLayout h = card(b, ACC);
        h.addView(bold(wfOnly ? "🔁 Walk-forward + out-of-sample" : "🧪 HISTORICAL BACKTEST (simulation, asli trading nahi)", 14, TEXT));
        h.addView(text("10 coins (BTC, ETH, SOL, BNB, XRP, DOGE, ADA, LINK, AVAX, SUI) · 1h (~250 din) + 15m (~52 din) asli candles. Har candle par engine sirf pichle "
                + "candles dekhta hai (no look-ahead / repaint). Fees, slippage, funding, same-candle = stop pehle. Parameters sirf TRAIN data par chune jate hain; TEST "
                + "data ek dafa, aakhir mein. Phone par 2–6 minute lagte hain (internet + processing).", 12, MUTED));
        final TextView pr = text("", 12, ACC2);
        h.addView(pr);
        LinearLayout br = row();
        for (final boolean spot : new boolean[]{false, true}) {
            Button rb = button(spot ? "▶ Run (spot fees)" : "▶ Run (futures fees)", spot ? CARD : GREEN, spot ? ACC : INK, spot ? ACC : 0);
            rb.setOnClickListener(v -> {
                if (smcBusy) return;
                smcBusy = true;
                pr.setText("⏳ Shuru...");
                pool.execute(() -> {
                    String err = null;
                    try {
                        SmcBacktest.run(this, spot ? TradeSim.Costs.spot() : new TradeSim.Costs(), (m, d, t) -> runOnUiThread(() -> pr.setText("⏳ " + m + " (" + d + "/" + t + ")")));
                    } catch (Exception e) {
                        err = e.getMessage();
                    }
                    smcBusy = false;
                    final String fe = err;
                    runOnUiThread(() -> {
                        if (fe != null) pr.setText("❌ " + fe);
                        if (infoOverlay == page && (smcTab == 2 || smcTab == 3)) renderSmc(b, page);
                    });
                });
            });
            br.addView(rb, new LinearLayout.LayoutParams(0, -2, 1));
        }
        h.addView(br);
        JSONObject rep;
        try { rep = new JSONObject(Prefs.getStr(this, "smcbt", "{}")); } catch (Exception e) { rep = new JSONObject(); }
        if (!rep.has("at")) { b.addView(text("\nAbhi tak backtest nahi chala — upar Run dabayen. Koi number pehle se nahi diya jata.", 13, MUTED)); return; }
        h.addView(text("Aakhri run: " + PumpHunter.when(rep.optLong("at")) + " · data " + new SimpleDateFormat("dd MMM yyyy", Locale.US).format(new Date(rep.optLong("from")))
                + " → " + new SimpleDateFormat("dd MMM yyyy", Locale.US).format(new Date(rep.optLong("to"))) + " · " + rep.optInt("candidates") + " candidate setups · " + rep.optString("costs"), 11, MUTED));
        if (!wfOnly) {
            LinearLayout f = card(b, CYAN_TXT);
            btRows(f, "Poora period (aap ki settings)", rep.optJSONObject("full"));
            for (String[] g : new String[][]{{"byCoin", "Coin-wise"}, {"byTf", "Timeframe-wise"}, {"byRegime", "Market condition (bull / bear / sideways · high / low volatility)"}}) {
                JSONObject o = rep.optJSONObject(g[0]);
                if (o == null) continue;
                LinearLayout c = card(b);
                c.addView(bold(g[1], 13, TEXT));
                java.util.Iterator<String> it = o.keys();
                while (it.hasNext()) { String k = it.next(); JSONObject x = o.optJSONObject(k); if (x != null) c.addView(text(k + ": " + x.optString("line"), 11, SOFT)); }
            }
        } else {
            JSONObject wf = rep.optJSONObject("wf");
            if (wf == null) return;
            LinearLayout c = card(b, YELLOW);
            c.addView(bold("Train par chune gaye parameters: " + wf.optString("chosen"), 13, TEXT));
            btRows(c, "TRAIN (pehla 60%) — yahin parameters chune", wf.optJSONObject("train"));
            btRows(c, "VALIDATION (agla 20%)", wf.optJSONObject("validation"));
            btRows(c, "TEST (aakhri 20%, bilkul unseen)", wf.optJSONObject("test"));
            LinearLayout fc = card(b);
            fc.addView(bold("Anchored walk-forward folds", 13, TEXT));
            JSONArray fo = wf.optJSONArray("folds");
            if (fo != null) for (int i = 0; i < fo.length(); i++) { JSONObject x = fo.optJSONObject(i); fc.addView(text(x.optString("fold") + "\n   " + x.optString("line"), 11, SOFT)); }
            btRows(fc, "Saare folds ka OUT-OF-SAMPLE total", wf.optJSONObject("oos"));
            JSONObject tr = wf.optJSONObject("train"), te = wf.optJSONObject("test");
            if (tr != null && te != null && tr.optInt("n") > 0 && te.optInt("n") > 0) {
                double drop = tr.optDouble("exp") - te.optDouble("exp");
                fc.addView(bold(drop > 0.3 ? "⚠️ Overfitting ka khatra: test ka nateeja train se kaafi kharab" : "✅ Train aur test ka nateeja qareeb — overfitting kam", 12, drop > 0.3 ? RED : GREEN));
            }
        }
        b.addView(text("⚠️ Yeh purane data par simulation hai — asli trading ka nateeja nahi. 90% accuracy ek HADAF hai, guarantee nahi; sirf bade sample (100+ trades) aur "
                + "confidence interval ke saath hi koi daawa kiya ja sakta hai. Win rate se zyada profit factor, expectancy aur drawdown dekhein.", 11, MUTED));
    }

    private void btRows(LinearLayout c, String title, JSONObject o) {
        c.addView(bold(title, 13, TEXT));
        if (o == null || o.optInt("n") == 0) { c.addView(text("0 trades (shartein poori karne wala setup nahi bana)", 12, MUTED)); return; }
        c.addView(text(String.format(Locale.US, "Trades %d · ✅ %d · ❌ %d · Win %.1f%% (95%% CI %.0f–%.0f%%)\nProfit factor %.2f · Expectancy %+.2fR · Net %+.1fR (%+.1f%% @1%% risk)\n"
                        + "Max DD %.1fR (%.1f%%) · Sharpe %.2f · avg planned R:R %.1f · lagatar jeet %d / haar %d",
                o.optInt("n"), o.optInt("wins"), o.optInt("losses"), o.optDouble("wr"), o.optDouble("lo"), o.optDouble("hi"), o.optDouble("pf"), o.optDouble("exp"),
                o.optDouble("netR"), o.optDouble("netPct"), o.optDouble("ddR"), o.optDouble("ddPct"), o.optDouble("sharpe"), o.optDouble("rr"), o.optInt("cw"), o.optInt("cl")), 12, SOFT));
    }

    private void smcRisk(LinearLayout b) {
        LinearLayout c = card(b, ACC);
        c.addView(bold("🛡️ Risk management (paper + signal sizing)", 14, TEXT));
        smcChoice(c, "Account ($)", "smcAcct", new int[]{100, 500, 1000, 5000, 10000}, new String[]{"$100", "$500", "$1K", "$5K", "$10K"}, 1000);
        smcChoice(c, "Risk per trade", "smcRisk10", new int[]{5, 10, 20}, new String[]{"0.5%", "1%", "2%"}, 10);
        smcChoice(c, "Max open positions", "smcMaxOpen", new int[]{3, 5, 8}, new String[]{"3", "5", "8"}, 5);
        smcChoice(c, "Max daily loss", "smcDailyR", new int[]{2, 3, 5}, new String[]{"2R", "3R", "5R"}, 3);
        smcChoice(c, "Lagatar loss par 12h pause", "smcPauseN", new int[]{2, 3, 4}, new String[]{"2", "3", "4"}, 3);
        smcChoice(c, "Min confidence", "smcMinScore", new int[]{60, 70, 80, 85}, new String[]{"60", "70", "80", "85"}, 70);
        smcChoice(c, "Min reward:risk (TP2)", "smcMinRR10", new int[]{15, 20, 25, 30}, new String[]{"1.5", "2.0", "2.5", "3.0"}, 20);
        smcChoice(c, "Coins scan", "smcCoins", new int[]{15, 25, 40}, new String[]{"15", "25", "40"}, 25);
        c.addView(text("Hamesha lagu: duplicate (ek coin par ek hi trade), signal expiry (6 candles), stop ki jaanch (0.3–4 ATR), TP1 par 1/3 + break-even, TP2 par trailing. "
                + "Bot kabhi asli order nahi bhejta.", 11, MUTED));
    }

    private void smcChoice(LinearLayout c, String label, final String key, final int[] vals, String[] names, int def) {
        c.addView(text(label, 12, SOFT));
        LinearLayout r = row();
        final TextView[] ch = new TextView[vals.length];
        int cur = Prefs.getInt(this, key, def);
        for (int i = 0; i < vals.length; i++) {
            final int k = i;
            ch[i] = chip(names[i], vals[i] == cur);
            ch[i].setTextSize(11);
            ch[i].setOnClickListener(v -> { Prefs.putInt(this, key, vals[k]); for (int z = 0; z < vals.length; z++) styleChip(ch[z], z == k); });
            r.addView(ch[i], chipLp());
        }
        c.addView(hscroll(r));
    }

    private void smcRejects(LinearLayout b) {
        JSONArray a = PaperBook.rejected(this);
        b.addView(text("🚫 Har NO TRADE / rejected faisla waqt ke saath (aakhri 300). Kul: " + Prefs.getLong(this, "smcRejN"), 12, MUTED));
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            b.addView(text(new SimpleDateFormat("dd MMM HH:mm", Locale.US).format(new Date(o.optLong("t"))) + " · " + o.optString("coin") + " " + o.optString("tf") + " · " + o.optString("why"), 11, SOFT));
        }
    }

    private void smcGuide(LinearLayout b) {
        LinearLayout c = card(b, CYAN_TXT);
        c.addView(bold("📚 SMC Pro kya dekhta hai", 15, TEXT));
        c.addView(text("• HH/HL = uptrend, LH/LL = downtrend. BOS = trend ki taraf break, CHoCH = pehla ulta break, MSS = CHoCH jo tez (displacement) candle se bane.\n"
                + "• BSL / SSL = swing highs ke upar / lows ke neeche pare stop-loss (liquidity). EQH / EQL = barabar highs / lows — sab se bari liquidity.\n"
                + "• Sweep / stop hunt = wick liquidity le kar wapas andar band — bade players ne stops le kar position banayi.\n"
                + "• Order block = tez move se pehle ki aakhri ulti candle (sirf jab move ne structure toda ho). Breaker = toota hua OB jo ulta kaam kare.\n"
                + "• FVG = 3 candles ka khaali gap (imbalance); IFVG = bhara hua FVG jo ulta kaam kare.\n"
                + "• Premium / discount = range ka upar / neecha aadha. Long discount mein, short premium mein behtar.\n"
                + "• Setup = HTF bias → liquidity sweep → CHoCH / BOS confirm → fresh OB / FVG par entry → stop sweep ke paar → targets agli liquidity par.\n"
                + "• Confidence 0–100 quality score hai; asal win rate sirf Backtest / Paper tab ke nateejon se pata chalta hai.\n"
                + "• Abu Cartel jaise traders ki private strategy kisi ke paas nahi — yeh public SMC concepts par apna, test hone wala system hai.", 12, SOFT));
    }

    // ============================================================ v14: ABOUT
    private void openAbout() {
        LinearLayout col = openPage("ℹ️ About");
        String ver = "?";
        try {
            ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
        }
        LinearLayout h = card(col, ACC);
        h.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView logo = bold("P", 40, INK);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(round(ACC, 24, 0));
        h.addView(logo, new LinearLayout.LayoutParams(dp(84), dp(84)));
        TextView nm = bold("ParaDox", 26, TEXT);
        nm.setGravity(Gravity.CENTER);
        nm.setLetterSpacing(0.08f);
        h.addView(nm);
        TextView tg = text("Smart Trading Signals · Crypto · Gold · Forex", 13, ACC2);
        tg.setGravity(Gravity.CENTER);
        h.addView(tg);
        TextView vv = text("Version " + ver, 12, MUTED);
        vv.setGravity(Gravity.CENTER);
        h.addView(vv);

        LinearLayout d = card(col, YELLOW);
        d.addView(text("DEVELOPER & OWNER", 11, MUTED));
        d.addView(bold("Nohman Arshid", 22, TEXT));
        d.addView(text("Founder · Product design · Trading strategy", 13, SOFT));
        d.addView(text("🇵🇰 Pakistan", 13, SOFT));
        d.addView(text("ParaDox ka idea, design aur trading logic Nohman Arshid ka hai — maqsad: aam trader ko bade players jaisa data, "
                + "saaf signals aur seekhne ka mauqa ek hi app mein dena.", 12, MUTED));

        LinearLayout ho = card(col);
        ho.addView(bold("☁️ Hosting & updates", 15, TEXT));
        ho.addView(text("• Source code: GitHub (" + Prefs.updateRepo(this) + ")\n"
                + "• Har naya version GitHub Actions par khud build hota hai aur Releases par publish hota hai\n"
                + "• App ke andar se update: Settings → App updates (fixed signing key — data mehfooz rehta hai)\n"
                + "• Signals 24/7 aap ke phone par chalne wali background service banati hai — koi beech ka server nahi", 13, SOFT));
        TextView gh = chip("🔗 GitHub Releases", true);
        gh.setOnClickListener(v -> openUrl("https://github.com/" + Prefs.updateRepo(this) + "/releases/latest"));
        LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(-2, -2);
        gl.topMargin = dp(8);
        ho.addView(gh, gl);

        LinearLayout f = card(col);
        f.addView(bold("⭐ Kya kya hai", 15, TEXT));
        f.addView(text("• Live charts 1 minute se ALL-time tak — simple chart, aur analysis par khud patterns + poora plan\n"
                + "• Scalp bot (heavy buying/selling) · Spot bot (achhi entry, 1 hafta – 1 mahina) · Gold & Forex bots\n"
                + "• ParaDox rule + backtest + accuracy mode · 12-indicator vote (ADX, Supertrend, Ichimoku, MFI, CMF...) · Moving averages · Chart patterns\n"
                + "• 10 exchanges ka volume · whales · futures · ETF · institutions · on-chain\n"
                + "• 🎯 Gainer Hunter: pre-pump / pre-dump 24/7 · 🤖 AI: Gemini (free), Groq (free), ChatGPT (free, in-app)\n"
                + "• 📊 MACD·MA·RSI probability lab (M5/M15/M30) · 🇨🇳 China pulse · BTC/USD\n"
                + "• ⚡ Mispricing radar 24/7: price errors, arbitrage (8 exchanges), triangle, funding, stablecoin peg, flash moves\n"
                + "• Market hours (forex, gold, stocks) + world volume IN/OUT · Live news radar (46 sources) · Catalyst radar (unlocks, listings, Polymarket) · Fed / CPI / NFP calendar\n"
                + "• Watch-only portfolio · AI analyst (Gemini / Groq / ChatGPT) · Academy (23 sabaq) · Trading tools", 13, SOFT));

        LinearLayout pr = card(col, GREEN);
        pr.addView(bold("🔒 Privacy", 15, TEXT));
        pr.addView(text("Aap ki API keys aur wallets sirf aap ke phone mein rehte hain. Wallet tracker sirf public address dekhta hai — "
                + "seed phrase / private key kabhi nahi maangta. Koi account ya login nahi.", 13, SOFT));

        LinearLayout ds = card(col);
        ds.addView(bold("📡 Data sources", 15, TEXT));
        ds.addView(text("Binance (spot + futures + WebSocket), Bybit, OKX, Coinbase, Kraken, KuCoin, Gate, Bitget, Farside (ETF), DefiLlama, "
                + "CoinGecko, Coin Metrics, Blockchain.com, mempool.space, Yahoo Finance (gold/forex), FRED & ForexFactory (macro), "
                + "46 news sources, Google Gemini, Groq, OpenAI ChatGPT (AI).", 12, MUTED));

        LinearLayout dc = card(col, RED);
        dc.addView(bold("⚠️ Disclaimer", 15, TEXT));
        dc.addView(text("ParaDox maloomat aur taleem ke liye hai, financial advice nahi. Koi bhi signal 100% sahi nahi hota. "
                + "Hamesha stop-loss lagayen aur utna hi lagayen jitna khona bardasht ho.", 12, SOFT));
        TextView cp = text("© 2026 Nohman Arshid · All rights reserved", 11, MUTED);
        cp.setGravity(Gravity.CENTER);
        cp.setPadding(0, dp(16), 0, 0);
        col.addView(cp);
    }

    // ============================================================ v11: ACADEMY
    private void openAcademy() {
        LinearLayout col = openPage("📚 ParaDox Academy");
        LinearLayout in = card(col, ACC);
        in.addView(bold("Trading seekhein — qadam ba qadam", 16, TEXT));
        in.addView(text("Har sabaq asaan Roman Urdu mein hai. Tarteeb se parhein: Beginner → Intermediate → Advanced. "
                + "'Essential' wale sabaq (risk, SL/TP, psychology) sab se zaroori hain — inhein zaroor parhein. "
                + "Analysis aur signals mein bhi har jagah '📖 Seekhein' daba kar wahi baat wahan seekh sakte hain.", 12, MUTED));
        for (int i = 0; i < Academy.LESSONS.length; i++) {
            final String[] l = Academy.LESSONS[i];
            final int num = i + 1;
            LinearLayout c = card(col);
            LinearLayout r = row();
            TextView ic = text(l[0], 22, TEXT);
            ic.setGravity(Gravity.CENTER);
            ic.setBackground(round((ACC & 0x00FFFFFF) | 0x22000000, 12, 0));
            r.addView(ic, new LinearLayout.LayoutParams(dp(44), dp(44)));
            LinearLayout t = column();
            t.setPadding(dp(12), 0, 0, 0);
            t.addView(bold(num + ". " + l[1], 14, TEXT));
            int lc = l[2].equals("Essential") ? RED : l[2].equals("Beginner") ? GREEN : l[2].equals("Advanced") ? CLAUDE : YELLOW;
            t.addView(bold(l[2], 11, lc));
            r.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
            r.addView(bold("›", 22, MUTED));
            c.addView(r);
            c.setOnClickListener(v -> openLesson(num - 1));
        }
    }

    private void openLesson(final int i) {
        final String[] l = Academy.LESSONS[i];
        LinearLayout col = openPage(l[0] + " Sabaq " + (i + 1), this::openAcademy);
        LinearLayout c = card(col, ACC);
        c.addView(bold(l[1], 18, TEXT));
        c.addView(bold(l[2], 12, ACC2));
        TextView body = text(l[3], 14, SOFT);
        body.setLineSpacing(dp(3), 1f);
        body.setTextIsSelectable(true);
        body.setPadding(0, dp(8), 0, 0);
        c.addView(body);
        LinearLayout nav = row();
        nav.setPadding(0, dp(12), 0, 0);
        if (i > 0) {
            TextView pv = chip("‹ Pichla", false);
            pv.setOnClickListener(v -> openLesson(i - 1));
            nav.addView(pv, chipLp());
        }
        nav.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
        TextView all = chip("☰ Sab sabaq", false);
        all.setOnClickListener(v -> openAcademy());
        nav.addView(all, chipLp());
        if (i < Academy.LESSONS.length - 1) {
            TextView nx = chip("Agla ›", true);
            nx.setOnClickListener(v -> openLesson(i + 1));
            nav.addView(nx);
        }
        col.addView(nav);
    }

    // ============================================================ v11: TRADING TOOLS (calculators)
    private EditText calcField(LinearLayout parent, String label, String value) {
        LinearLayout c = column();
        c.addView(text(label, 11, MUTED));
        EditText e = input("", value, InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        c.addView(e);
        parent.addView(c, new LinearLayout.LayoutParams(0, -2, 1));
        return e;
    }

    private LinearLayout calcRow(LinearLayout parent) {
        LinearLayout r = row();
        parent.addView(r);
        return r;
    }

    private static String n(double v) {
        if (Math.abs(v) >= 1000) return String.format(Locale.US, "%,.2f", v);
        if (Math.abs(v) >= 1) return String.format(Locale.US, "%.4f", v);
        return String.format(Locale.US, "%.8f", v);
    }

    private void openTools() {
        LinearLayout col = openPage("🧮 Trading Tools");

        // ---- 1. SL / TP calculator
        LinearLayout a = card(col, ACC);
        a.addView(bold("🎯 Stop Loss & Take Profit calculator", 16, TEXT));
        a.addView(text("Entry aur stop (price ya %) daalein — TP levels R:R ke hisaab se ban jayenge.", 12, MUTED));
        final boolean[] isLong = {true};
        LinearLayout sd = row();
        final TextView lg = chip("🟢 LONG / BUY", true), sh = chip("🔴 SHORT / SELL", false);
        sd.addView(lg, chipLp());
        sd.addView(sh, chipLp());
        a.addView(sd);
        LinearLayout r1 = calcRow(a);
        final EditText en = calcField(r1, "Entry price", "");
        r1.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        final EditText slp = calcField(r1, "Stop price (ya khali)", "");
        LinearLayout r2 = calcRow(a);
        final EditText slPct = calcField(r2, "Ya stop % door", "2");
        r2.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        final EditText rrEt = calcField(r2, "R:R targets (jaise 1,2,3)", "");
        rrEt.setInputType(InputType.TYPE_CLASS_TEXT);
        rrEt.setText("1,2,3");
        LinearLayout r3 = calcRow(a);
        final EditText amt = calcField(r3, "Position size (USDT)", "100");
        r3.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        final EditText lev = calcField(r3, "Leverage (spot = 1)", "1");
        final TextView outA = text("", 13, TEXT);
        final Runnable calcA = () -> {
            double e = parse(en, 0), s = parse(slp, 0), pct = parse(slPct, 2), size = parse(amt, 0), L = Math.max(1, parse(lev, 1));
            if (e <= 0) { outA.setText("Entry price likhen"); return; }
            if (s <= 0) s = isLong[0] ? e * (1 - pct / 100) : e * (1 + pct / 100);
            double risk = Math.abs(e - s);
            if ((isLong[0] && s >= e) || (!isLong[0] && s <= e)) { outA.setText("⚠️ " + (isLong[0] ? "LONG mein stop entry se NEECHE" : "SHORT mein stop entry se UPAR") + " hona chahiye"); return; }
            StringBuilder b = new StringBuilder();
            double qty = size * L / e;
            double lossUsd = qty * risk;
            b.append("🛑 Stop: ").append(n(s)).append(String.format(Locale.US, "  (%.2f%% · nuksan ≈ $%.2f)%n", risk / e * 100, lossUsd));
            for (String t : rrEt.getText().toString().split("[,\\s]+")) {
                double rr;
                try { rr = Double.parseDouble(t); } catch (Exception x) { continue; }
                if (rr <= 0) continue;
                double tp = isLong[0] ? e + rr * risk : e - rr * risk;
                if (tp <= 0) continue;
                b.append(String.format(Locale.US, "🎯 TP %.1fR: %s  (%+.2f%% · faida ≈ $%.2f)%n", rr, n(tp), (tp / e - 1) * 100, qty * Math.abs(tp - e)));
            }
            if (L > 1) {
                double liq = isLong[0] ? e * (1 - 1 / L * 0.95) : e * (1 + 1 / L * 0.95);
                b.append(String.format(Locale.US, "⚠️ Takreeban liquidation: %s (%.0fx) — stop is se pehle hona lazmi%n", n(liq), L));
                if (isLong[0] ? liq >= s : liq <= s) b.append("❌ Stop liquidation ke BAAD hai — leverage kam karein!\n");
            }
            b.append(String.format(Locale.US, "Coins: %s · position value $%.2f", n(qty), qty * e));
            outA.setText(b.toString());
        };
        lg.setOnClickListener(v -> { isLong[0] = true; styleChip(lg, true); styleChip(sh, false); calcA.run(); });
        sh.setOnClickListener(v -> { isLong[0] = false; styleChip(lg, false); styleChip(sh, true); calcA.run(); });
        TextView ca = chip("Calculate", true);
        ca.setOnClickListener(v -> { hideKeyboard(); calcA.run(); });
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-2, -2);
        cl.topMargin = dp(6);
        a.addView(ca, cl);
        a.addView(outA);
        learnToggle(a, "R = entry aur stop ka farq (aap ka khatra). 2R target ka matlab: jitna khatra, us ka do guna faida. "
                + "1:2 R:R par sirf 34% trades jeet kar bhi faida hota hai. Stop hamesha us jagah rakhen jahan aap ka idea ghalat ho jaye "
                + "(support ke neeche / resistance ke upar), sirf % se nahi.");

        // ---- 2. Average price / DCA calculator
        LinearLayout b = card(col, ACC2);
        b.addView(bold("➗ Average price (DCA) calculator", 16, TEXT));
        b.addView(text("Har khareed ki price aur kitne USDT lagaye (ya kitne coins) — average, breakeven aur abhi ka P/L.", 12, MUTED));
        final boolean[] byCoins = {false};
        LinearLayout md = row();
        final TextView mU = chip("USDT amount", true), mC = chip("Coins quantity", false);
        md.addView(mU, chipLp());
        md.addView(mC, chipLp());
        b.addView(md);
        final LinearLayout rows = column();
        b.addView(rows);
        final List<EditText[]> buys = new ArrayList<>();
        final Runnable addRow = () -> {
            LinearLayout r = row();
            EditText p = calcField(r, "Buy #" + (buys.size() + 1) + " price", "");
            r.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
            EditText q = calcField(r, byCoins[0] ? "Coins" : "USDT", "");
            rows.addView(r);
            buys.add(new EditText[]{p, q});
        };
        addRow.run();
        addRow.run();
        LinearLayout br = row();
        TextView add = chip("＋ Aur buy", false);
        add.setOnClickListener(v -> addRow.run());
        br.addView(add, chipLp());
        TextView rm = chip("− Aakhri hatao", false);
        rm.setOnClickListener(v -> {
            if (buys.size() <= 1) return;
            buys.remove(buys.size() - 1);
            rows.removeViewAt(rows.getChildCount() - 1);
        });
        br.addView(rm, chipLp());
        b.addView(br);
        LinearLayout r4 = calcRow(b);
        final EditText now = calcField(r4, "Abhi ki price (P/L ke liye)", "");
        r4.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        final EditText fee = calcField(r4, "Fee % (har taraf)", "0.1");
        LinearLayout r5 = calcRow(b);
        final EditText tgt = calcField(r5, "Target average (ya khali)", "");
        r5.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        final EditText nxt = calcField(r5, "Agli buy ki price", "");
        final TextView outB = text("", 13, TEXT);
        final Runnable calcB = () -> {
            double cost = 0, coins = 0;
            int cnt = 0;
            for (EditText[] e : buys) {
                double p = parse(e[0], 0), q = parse(e[1], 0);
                if (p <= 0 || q <= 0) continue;
                double c = byCoins[0] ? q : q / p;
                coins += c;
                cost += c * p;
                cnt++;
            }
            if (coins <= 0) { outB.setText("Kam az kam ek buy ki price aur amount likhen"); return; }
            double avg = cost / coins, f = parse(fee, 0.1) / 100;
            double be = avg * (1 + f) / (1 - f);
            StringBuilder s = new StringBuilder();
            s.append(String.format(Locale.US, "📍 Average price: %s%n", n(avg)));
            s.append(String.format(Locale.US, "Kul lagaya: $%.2f · kul coins: %s · %d buys%n", cost, n(coins), cnt));
            s.append(String.format(Locale.US, "⚖️ Breakeven (fees ke saath): %s%n", n(be)));
            double px = parse(now, 0);
            if (px > 0) {
                double val = coins * px * (1 - f);
                double pl = val - cost;
                s.append(String.format(Locale.US, "%s Abhi: $%.2f · P/L %+.2f$ (%+.2f%%)%n", pl >= 0 ? "🟢" : "🔴", val, pl, pl / cost * 100));
            }
            double ta = parse(tgt, 0), np = parse(nxt, 0);
            if (ta > 0 && np > 0) {
                if ((np < ta && ta < avg) || (np > ta && ta > avg)) {
                    double needCoins = coins * (avg - ta) / (ta - np);
                    s.append(String.format(Locale.US, "🎯 Average %s tak laane ke liye %s par %s coins (≈ $%.2f) aur khareedne honge%n",
                            n(ta), n(np), n(needCoins), needCoins * np));
                } else s.append("Target average agli buy ki price aur abhi ke average ke darmiyan hona chahiye\n");
            }
            outB.setText(s.toString().trim());
        };
        mU.setOnClickListener(v -> { byCoins[0] = false; styleChip(mU, true); styleChip(mC, false); toast("Ab doosre khane mein USDT likhen"); });
        mC.setOnClickListener(v -> { byCoins[0] = true; styleChip(mU, false); styleChip(mC, true); toast("Ab doosre khane mein coins likhen"); });
        TextView cb = chip("Calculate", true);
        cb.setOnClickListener(v -> { hideKeyboard(); calcB.run(); });
        LinearLayout.LayoutParams cbl = new LinearLayout.LayoutParams(-2, -2);
        cbl.topMargin = dp(6);
        b.addView(cb, cbl);
        b.addView(outB);
        learnToggle(b, "Average = kul paisa ÷ kul coins. Neeche khareedne se average neeche aata hai, magar paisa bhi zyada phans jata hai. "
                + "Sirf mazboot coins mein aur pehle se tay plan ke saath DCA karein. Futures mein harte trade mein average karna liquidation ki taraf le jata hai.");

        // ---- 3. Position size
        LinearLayout c = card(col, GREEN);
        c.addView(bold("🛡️ Position size (risk %) calculator", 16, TEXT));
        LinearLayout r6 = calcRow(c);
        final EditText bal = calcField(r6, "Balance (USDT)", String.valueOf(Prefs.balance(this)));
        r6.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        final EditText rk = calcField(r6, "Risk per trade %", String.valueOf(Prefs.riskPct(this)));
        LinearLayout r7 = calcRow(c);
        final EditText e2 = calcField(r7, "Entry", "");
        r7.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        final EditText s2 = calcField(r7, "Stop-loss", "");
        final TextView outC = text("", 13, TEXT);
        TextView cc = chip("Calculate", true);
        cc.setOnClickListener(v -> {
            hideKeyboard();
            double bb = parse(bal, 0), pct = parse(rk, 1), e = parse(e2, 0), st = parse(s2, 0);
            if (bb <= 0 || e <= 0 || st <= 0 || e == st) { outC.setText("Balance, entry aur stop likhen"); return; }
            Prefs.saveRisk(this, (float) bb, (float) pct);
            double riskUsd = bb * pct / 100, per = Math.abs(e - st), qty = riskUsd / per, pos = qty * e;
            outC.setText(String.format(Locale.US, "Risk: $%.2f (%.1f%%)\nKhareedain: %s coins ≈ $%.2f\nStop door: %.2f%%%s",
                    riskUsd, pct, n(qty), pos, per / e * 100,
                    pos > bb ? String.format(Locale.US, "\n⚠️ Position balance se badi — %.1fx leverage chahiye", pos / bb) : ""));
        });
        LinearLayout.LayoutParams ccl = new LinearLayout.LayoutParams(-2, -2);
        ccl.topMargin = dp(6);
        c.addView(cc, ccl);
        c.addView(outC);
        learnToggle(c, "Professional usool: ek trade mein balance ka 1–2% se zyada risk nahi. Position size stop ki doori se tay hota hai — "
                + "stop door ho to position chhoti, qareeb ho to bari. Is tarah har trade mein nuksan barabar rehta hai.");

        // ---- 4. Profit / loss
        LinearLayout d = card(col, YELLOW);
        d.addView(bold("💵 Profit / Loss calculator", 16, TEXT));
        LinearLayout r8 = calcRow(d);
        final EditText pe = calcField(r8, "Entry", "");
        r8.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        final EditText px = calcField(r8, "Exit", "");
        LinearLayout r9 = calcRow(d);
        final EditText pa = calcField(r9, "Amount (USDT)", "100");
        r9.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        final EditText pl = calcField(r9, "Leverage", "1");
        final TextView outD = text("", 13, TEXT);
        TextView cd = chip("LONG P/L", true), cs = chip("SHORT P/L", false);
        final java.util.function.Consumer<Boolean> calcD = lng -> {
            hideKeyboard();
            double e = parse(pe, 0), x = parse(px, 0), am = parse(pa, 0), L = Math.max(1, parse(pl, 1));
            if (e <= 0 || x <= 0 || am <= 0) { outD.setText("Entry, exit aur amount likhen"); return; }
            double move = (lng ? x / e - 1 : 1 - x / e);
            double res = am * L * move;
            outD.setText(String.format(Locale.US, "%s %s: %+.2f$ · %+.2f%% apne paise par (price move %+.2f%%)",
                    res >= 0 ? "🟢" : "🔴", lng ? "LONG" : "SHORT", res, move * L * 100, (x / e - 1) * 100));
        };
        cd.setOnClickListener(v -> calcD.accept(true));
        cs.setOnClickListener(v -> calcD.accept(false));
        LinearLayout pr = row();
        pr.setPadding(0, dp(6), 0, 0);
        pr.addView(cd, chipLp());
        pr.addView(cs, chipLp());
        d.addView(pr);
        d.addView(outD);
    }

    // ============================================================ MARKET tab
    private void buildMarket() {
        LinearLayout col = pageColumn(0);
        updateBanner = card(col, GREEN);
        updateBanner.setVisibility(View.GONE);
        LinearLayout seg = row();
        seg.setPadding(dp(4), dp(4), dp(4), dp(4));
        seg.setBackground(round(CARD, 16, STROKE));
        String[] segN = {"🪙 Crypto", "🥇 Gold", "💱 Forex", "🌐 Sab"};
        for (int i = 0; i < 4; i++) {
            final int si = i;
            mktSegChips[i] = chip(segN[i], i == 0);
            mktSegChips[i].setTextSize(12);
            mktSegChips[i].setOnClickListener(v -> setMktSeg(si));
            seg.addView(mktSegChips[i], new LinearLayout.LayoutParams(0, -2, 1));
        }
        LinearLayout.LayoutParams segLp = new LinearLayout.LayoutParams(-1, -2);
        segLp.topMargin = dp(10);
        col.addView(seg, segLp);
        assetWrap = column();
        assetWrap.setVisibility(View.GONE);
        col.addView(assetWrap);      // gold / forex (also on top in "Sab")
        cryptoWrap = column();
        col.addView(cryptoWrap);
        buildAssetMarket(assetWrap);
        LinearLayout lc = card(cryptoWrap);
        marketSearch = input("🔎 Coin search karein (jaise PEPE, SUI, WIF)", "",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        marketSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) {
                marketLimit = 50;
                renderMarket();
            }
        });
        lc.addView(marketSearch);
        LinearLayout modes = row();
        String[] names = {"🚀 Gainers", "📉 Losers", "🔥 Volume", "🔤 A–Z", "⭐ Watchlist"};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            modeChips[i] = chip(names[i], i == marketMode);
            modeChips[i].setOnClickListener(v -> {
                marketMode = marketMode == idx ? -1 : idx;   // v34: tap again = back to the normal list
                marketLimit = 50;
                for (int k = 0; k < names.length; k++) styleChip(modeChips[k], k == marketMode);
                renderMarket();
            });
            modes.addView(modeChips[i], chipLp());
        }
        lc.addView(hscroll(modes));
        marketCount = text("", 12, MUTED);
        lc.addView(marketCount);
        marketList = column();
        lc.addView(marketList);
        LinearLayout top = card(cryptoWrap);
        LinearLayout tr = row();
        tr.addView(bold("Market Overview", 18, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView rf = chip("↻ Refresh", false);
        rf.setOnClickListener(v -> loadMarket());
        tr.addView(rf);
        top.addView(tr);
        fgGauge = new GaugeView(this);
        fgGauge.set(-1, "Fear & Greed", "load ho raha hai...");
        top.addView(fgGauge, new LinearLayout.LayoutParams(-1, dp(140)));
        btcView = bold("BTC —", 16, TEXT);
        top.addView(btcView);
        usdView = bold("₿ BTC/USD (Coinbase) — load ho raha hai", 13, 0xFFF7931A);
        usdView.setOnClickListener(v -> openAssetChart(Assets.CRYPTO_USD_LIST[0]));
        top.addView(usdView);
        Button hb = button("🎯 Gainer Hunter — top gainers banne se PEHLE pakro", GREEN, INK, 0);
        hb.setOnClickListener(v -> openHunter());
        top.addView(hb);
        macroLine = bold("📅 Agla bada US event: load ho raha hai...", 13, YELLOW);
        macroLine.setOnClickListener(v -> { showTab(TAB_LISTINGS); setNewsSeg(true); });
        top.addView(macroLine);
        globalView = text("", 13, MUTED);
        top.addView(globalView);

    }

    private volatile boolean marketLoading;
    private String marketErr = "";

    private String[] mFg;
    private JSONObject mGlobal;

    /** v34: coins first (shown the moment they arrive), then Fear & Greed / global / calendar in parallel — one slow source can't blank the list. */
    private void loadMarket() {
        if (marketLoading) return;
        marketLoading = true;
        btcView.setText("Load ho raha hai...");
        btcView.setTextColor(TEXT);
        pool.execute(() -> {
            try {
                final JSONArray tick = new JSONArray(Scanner.get("/api/v3/ticker/24hr?type=MINI"));
                runOnUiThread(() -> {
                    marketLoading = false;
                    marketErr = "";
                    mk.clear();
                    for (int i = 0; i < tick.length(); i++) {
                        JSONObject o = tick.optJSONObject(i);
                        if (o == null) continue;
                        String s = o.optString("symbol");
                        if (!Scanner.isTradable(s) || o.optDouble("lastPrice", 0) <= 0) continue;
                        mk.put(s, new double[]{o.optDouble("lastPrice", 0), o.optDouble("openPrice", 0), o.optDouble("quoteVolume", 0)});
                        NewsEngine.KNOWN.add(base(s));
                    }
                    marketLoadedAt = System.currentTimeMillis();
                    renderOverview(mFg, mGlobal);
                    renderMarket();
                });
            } catch (Exception e) {
                final String msg = e.getMessage();
                runOnUiThread(() -> {
                    marketLoading = false;
                    marketErr = "Coins load nahi huay (" + msg + ") — Binance aur MEXC dono se koshish ki. Internet / VPN check karein.";
                    btcView.setText("Market load nahi hua: " + msg + "\nInternet check karke Refresh dabayen");
                    if (mk.isEmpty()) renderMarket();
                });
            }
        });
        pool.execute(() -> {
            final String[] fg = SmartMoney.fearGreed();
            runOnUiThread(() -> { if (fg != null) { mFg = fg; lastFg = fg; } renderOverview(mFg, mGlobal); });
        });
        pool.execute(() -> {
            final JSONObject g = fetchGlobal();
            runOnUiThread(() -> { if (g != null) mGlobal = g; renderOverview(mFg, mGlobal); });
        });
        pool.execute(() -> {
            try {
                final List<MacroEngine.Event> evs = MacroEngine.calendar(this, false);
                runOnUiThread(() -> updateMacroLine(evs));
            } catch (Exception ignored) {
            }
        });
    }

    private static JSONObject fetchGlobal() {
        try {
            return new JSONObject(Scanner.getAbsolute("https://api.coingecko.com/api/v3/global")).getJSONObject("data");
        } catch (Exception e) {
            return null;
        }
    }

    private static double change(double[] v) {
        return v[1] > 0 ? (v[0] / v[1] - 1) * 100 : 0;
    }

    private void renderOverview(String[] fg, JSONObject g) {
        if (fg != null) {
            int v = -1;
            try { v = Integer.parseInt(fg[0]); } catch (Exception ignored) { }
            fgGauge.set(v, fg[1], "Fear & Greed" + (fg.length > 2 ? " · " + fg[2] : "") + " (poori market ka mood)");
        } else {
            fgGauge.set(-1, "Fear & Greed", "load ho raha hai...");
        }
        updateBtcLine();
        if (g != null) {
            StringBuilder s = new StringBuilder();
            JSONObject tm = g.optJSONObject("total_market_cap");
            if (tm != null) s.append("Total market cap: ").append(Fmt.usd(tm.optDouble("usd", 0)));
            s.append(String.format(Locale.US, " (%+.2f%% 24h)", g.optDouble("market_cap_change_percentage_24h_usd", 0)));
            JSONObject mcp = g.optJSONObject("market_cap_percentage");
            if (mcp != null) s.append(String.format(Locale.US, "\nBTC dominance: %.1f%% · ETH: %.1f%%",
                    mcp.optDouble("btc", 0), mcp.optDouble("eth", 0)));
            globalView.setText(s.toString());
        } else {
            globalView.setText("CoinGecko global data abhi nahi mila");
        }
    }

    private void updateBtcLine() {
        double[] btc = mk.get("BTCUSDT");
        if (btc == null) return;
        double ch = change(btc);
        btcView.setText("₿ BTC  $" + Fmt.price(btc[0]) + "   " + Fmt.pct(ch) + " (24h)  ● live");
        btcView.setTextColor(ch >= 0 ? GREEN : RED);
    }

    private void renderMarket() {
        marketList.removeAllViews();
        rowViews.clear();
        usdRowPx.clear();
        if (mk.isEmpty()) {   // v33: never a blank list — show progress / the error, and load by itself
            marketList.addView(text(marketErr.isEmpty() ? "⏳ Coins ki list load ho rahi hai..." : "❌ " + marketErr, 13, marketErr.isEmpty() ? MUTED : RED));
            TextView rt = chip("↻ Dobara load karein", false);
            rt.setOnClickListener(v -> loadMarket());
            marketList.addView(rt);
            if (!marketLoading && marketErr.isEmpty()) loadMarket();
            return;
        }
        String q = marketSearch.getText().toString().trim().toUpperCase(Locale.US).replace("/", "").replace("USDT", "");
        List<String> list = new ArrayList<>();
        if (marketMode == 4) {
            for (String s : Prefs.watchlist(this)) if (mk.containsKey(s)) list.add(s);
        } else {
            for (Map.Entry<String, double[]> e : mk.entrySet()) {
                String s = e.getKey();
                if (!q.isEmpty()) {
                    if (!base(s).contains(q)) continue;
                } else if (marketMode != 3 && e.getValue()[2] < 1_000_000) continue;
                list.add(s);
            }
            if (marketMode == 0) Collections.sort(list, (a, b) -> Double.compare(change(mk.get(b)), change(mk.get(a))));
            else if (marketMode == 1) Collections.sort(list, (a, b) -> Double.compare(change(mk.get(a)), change(mk.get(b))));
            else if (marketMode == 2 || marketMode == -1) Collections.sort(list, (a, b) -> Double.compare(mk.get(b)[2], mk.get(a)[2]));
            else Collections.sort(list);
            if (!q.isEmpty()) {
                // exact match first
                final String qq = q;
                Collections.sort(list, (a, b) -> Boolean.compare(!base(a).equals(qq), !base(b).equals(qq)));
            }
        }
        marketCount.setText((marketMode == -1 ? "📋 Sab coins (volume ke hisaab se) · " : marketMode == 0 ? "🚀 Gainers · dobara tap = normal list · " : marketMode == 1 ? "📉 Losers · dobara tap = normal list · "
                : marketMode == 2 ? "🔥 Volume · " : marketMode == 3 ? "🔤 A–Z · " : "⭐ ") + list.size() + " coins " + ("MEXC".equals(Scanner.lastSource) ? "(MEXC backup — Binance ne roka)" : "Binance par") + (q.isEmpty() ? "" : " · search: " + q)
                + " · prices live update hoti hain");
        if (list.isEmpty()) {
            marketList.addView(text(marketMode == 4 ? "Watchlist khali hai — Analyze tab mein ☆ dabayen" : "Koi coin nahi mila", 13, MUTED));
            return;
        }
        if (marketMode != 4 && (q.isEmpty() || "BTCUSD".startsWith(q) || "BTC".equals(q) || "USD".equals(q))) marketList.addView(usdRow(Assets.CRYPTO_USD_LIST[0]));
        if (marketMode != 4 && ("ETH".equals(q) || "ETHUSD".startsWith(q) && q.length() >= 4)) marketList.addView(usdRow(Assets.CRYPTO_USD_LIST[1]));
        for (int i = 0; i < list.size() && i < marketLimit; i++) marketList.addView(coinRow(list.get(i), i + 1));
        if (list.size() > marketLimit) {
            TextView more = chip("⬇ Aur coins dikhayen (" + (list.size() - marketLimit) + " baqi)", false);
            more.setOnClickListener(v -> {
                marketLimit += 50;
                renderMarket();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(10);
            marketList.addView(more, lp);
        }
    }

    private final Map<String, Double> usdPx = new HashMap<>();
    private final Map<String, TextView> usdRowPx = new HashMap<>();

    /** Pinned BTC/USD (real US dollar, Coinbase) row on top of the crypto list. */
    private View usdRow(final Assets.Asset a) {
        LinearLayout r = row();
        r.setPadding(0, dp(10), 0, dp(10));
        r.setBackground(round(0x14F7931A, 10, 0));
        r.addView(bold(a.icon, 15, 0xFFF7931A), new LinearLayout.LayoutParams(dp(30), -2));
        LinearLayout nm = column();
        nm.addView(bold(a.short_.substring(0, 3) + "/USD", 15, TEXT));
        nm.addView(text("US dollar (Coinbase) · 24/7", 11, MUTED));
        r.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
        Double p = usdPx.get(a.sym);
        TextView pv = bold(p == null ? "—" : "$" + Fmt.price(p), 15, TEXT);
        usdRowPx.put(a.sym, pv);
        r.addView(pv);
        r.setOnClickListener(v -> openAssetChart(a));
        return r;
    }

    private View coinRow(final String sym, int rank) {
        double[] v = mk.get(sym);
        double ch = change(v);
        LinearLayout r = row();
        r.setPadding(0, dp(10), 0, dp(10));
        r.addView(text(String.valueOf(rank), 12, MUTED), new LinearLayout.LayoutParams(dp(30), -2));
        LinearLayout nm = column();
        nm.addView(bold(base(sym), 15, TEXT));
        nm.addView(text("Vol " + Fmt.usd(v[2]), 11, MUTED));
        r.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
        TextView pr = text("$" + Fmt.price(v[0]), 14, TEXT);
        pr.setPadding(dp(6), dp(3), dp(6), dp(3));
        r.addView(pr);
        TextView pc = bold(Fmt.pct(ch), 13, 0xFFFFFFFF);
        pc.setGravity(Gravity.CENTER);
        pc.setPadding(dp(6), dp(5), dp(6), dp(5));
        pc.setBackground(round(ch >= 0 ? GREEN : RED, 8, 0));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(dp(84), -2);
        plp.leftMargin = dp(4);
        r.addView(pc, plp);
        r.setOnClickListener(x -> openAnalyze(sym));
        rowViews.put(sym, new TextView[]{pr, pc});
        LinearLayout wrap = column();
        wrap.addView(r);
        wrap.addView(divider());
        return wrap;
    }

    private void startMarketFeed() {
        if (marketWs != null) return;
        marketWs = new WsStream("/ws/!miniTicker@arr", new WsStream.Callback() {
            @Override
            public void onText(String text) {
                try {
                    JSONArray a = new JSONArray(text);
                    synchronized (pendingMini) {
                        for (int i = 0; i < a.length(); i++) {
                            JSONObject o = a.getJSONObject(i);
                            String s = o.optString("s");
                            if (!s.endsWith("USDT")) continue;
                            pendingMini.put(s, new double[]{num(o, "c"), num(o, "o"), num(o, "q")});
                        }
                    }
                } catch (Exception ignored) {
                }
            }

            @Override
            public void onStatus(boolean live) { }
        }).start();
    }

    private void stopMarketFeed() {
        if (marketWs != null) marketWs.stop();
        marketWs = null;
    }

    /** Pushes live mini-ticker prices into the market list (flash green/red on change). */
    private void applyMarketLive() {
        Map<String, double[]> upd;
        synchronized (pendingMini) {
            if (pendingMini.isEmpty()) return;
            upd = new HashMap<>(pendingMini);
            pendingMini.clear();
        }
        for (Map.Entry<String, double[]> e : upd.entrySet()) {
            String s = e.getKey();
            double[] nv = e.getValue();
            double[] old = mk.get(s);
            if (old == null) {
                if (Scanner.isTradable(s) && nv[0] > 0) mk.put(s, nv);
                continue;
            }
            double prev = old[0];
            mk.put(s, nv);
            TextView hp = homePx.get(s);
            if (hp != null && nv[0] != prev) {
                hp.setText("$" + Fmt.price(nv[0]));
                hp.setTextColor(change(nv) >= 0 ? GREEN : RED);
            }
            TextView[] tv = rowViews.get(s);
            if (tv != null && nv[0] != prev) {
                final TextView pr = tv[0];
                pr.setText("$" + Fmt.price(nv[0]));
                pr.setBackground(round(nv[0] > prev ? 0x550ECB81 : 0x55F6465D, 6, 0));
                handler.postDelayed(() -> pr.setBackground(null), 350);
                double ch = change(nv);
                tv[1].setText(Fmt.pct(ch));
                tv[1].setBackground(round(ch >= 0 ? GREEN : RED, 8, 0));
            }
        }
        updateBtcLine();
    }

    // ============================================================ ANALYZE tab
    private void buildAnalyze() {
        LinearLayout col = pageColumn(1);

        LinearLayout mc = card(col, ACC);
        LinearLayout mr = row();
        for (int m = 0; m < 2; m++) {
            final int mm = m;
            TextView t = chip(Mode.label(m), m == uiMode);
            if (m == uiMode) t.setBackground(round(Mode.accent(m), 20, Mode.accent(m)));
            t.setOnClickListener(v -> switchMode(mm));
            mr.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
            if (m == 0) mr.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        }
        mc.addView(mr);
        mc.addView(text(Mode.desc(uiMode), 12, ACC2));

        LinearLayout sc = card(col);
        sc.addView(bold("🔍 Apna coin analyze karein", 17, TEXT));
        LinearLayout sr = row();
        searchEt = input("SOL, PEPE, BTC...", base(currentSym), InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        sr.addView(searchEt, new LinearLayout.LayoutParams(0, -2, 1));
        TextView go = chip("Analyze", true);
        go.setOnClickListener(v -> {
            String s = searchEt.getText().toString().trim();
            if (s.isEmpty()) return;
            hideKeyboard();
            runAnalysis(CoinReport.normalize(s));
        });
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(-2, -2);
        glp.leftMargin = dp(8);
        sr.addView(go, glp);
        starBtn = chip("☆", false);
        starBtn.setOnClickListener(v -> {
            boolean on = Prefs.toggleWatch(this, currentSym);
            updateStar();
            renderWatchRow();
            toast(on ? "Watchlist mein add — bot isay hamesha scan karega" : "Watchlist se hata diya");
        });
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-2, -2);
        slp.leftMargin = dp(8);
        sr.addView(starBtn, slp);
        TextView fb = chip("🎯", false);
        fb.setOnClickListener(v -> {
            if (Prefs.inFocus(this, currentSym)) { Prefs.removeFocus(this, currentSym); toast(base(currentSym) + " focus list se hata"); }
            else { Prefs.addFocus(this, currentSym, Assets.CRYPTO, "both"); toast("🎯 " + base(currentSym) + " focus list mein (Signals tab se Focus ON karein)"); }
            renderFocus();
        });
        LinearLayout.LayoutParams flp2 = new LinearLayout.LayoutParams(-2, -2);
        flp2.leftMargin = dp(8);
        sr.addView(fb, flp2);
        sc.addView(sr);
        sc.addView(text("⭐ Watchlist (tap = analysis):", 12, MUTED));
        watchRow = row();
        sc.addView(hscroll(watchRow));

        // ---- live chart card
        LinearLayout cc = card(col, ACC);
        LinearLayout th = row();
        chartTitle = bold(base(currentSym) + "/USDT", 16, TEXT);
        th.addView(chartTitle, new LinearLayout.LayoutParams(0, -2, 1));
        livePrice = bold("", 16, TEXT);
        th.addView(livePrice);
        cc.addView(th);
        LinearLayout tr = row();
        tr.setPadding(0, dp(6), 0, dp(4));
        for (int i = 0; i < chartTfs.length; i++) {
            final String tf = chartTfs[i];
            tfChips[i] = chip(tf, tf.equals(chartTf));
            tfChips[i].setOnClickListener(v -> selectTf(tf));
            tr.addView(tfChips[i], chipLp());
        }
        TextView fs = chip("⛶ Full screen", true);
        fs.setOnClickListener(v -> openFullscreen());
        TextView lv = chip("⏩ Live", false);
        lv.setOnClickListener(v -> chart.goLive());
        TextView zo = chip("−", false);
        zo.setOnClickListener(v -> chart.zoom(30));
        TextView zi = chip("+", false);
        zi.setOnClickListener(v -> chart.zoom(-30));
        TextView cl = chip("🧹 Simple / 🧠 Analysis", false);
        cl.setOnClickListener(v -> {
            if (chart.ind("Patterns") || chart.ind("MA Ribbon")) { cleanChart(chart); toast("Simple chart — sirf candles"); }
            else if (lastReport != null && lastReport.symbol.equals(currentSym)) { applyPlan(lastReport); toast("Analysis lines + plan"); }
            else { analysisLayers(chart); toast("Pattern lines · poora plan ke liye Analyze dabayen"); }
        });
        tr.addView(fs, chipLp());
        tr.addView(cl, chipLp());
        tr.addView(lv, chipLp());
        tr.addView(zo, chipLp());
        tr.addView(zi, chipLp());
        cc.addView(hscroll(tr));
        chart = new ChartView(this);
        chart.setAccent(ACC);
        chart.setCompact(true);
        chart.setOnTap(this::openFullscreen);
        cleanChart(chart);
        // adaptive height: ~55% of the screen (TradingView-like on any phone)
        int ch = Math.max(dp(380), Math.min(dp(640), (int) (getResources().getDisplayMetrics().heightPixels * 0.55f)));
        cc.addView(chart, new LinearLayout.LayoutParams(-1, ch));
        cc.addView(text("Pehle simple chart · 'Analyze' dabane par bot patterns, S/R, Fibonacci, moving averages aur poora plan (kahan BUY, retest, "
                + "target range) chart par khud draw karta hai · tap = full screen", 11, MUTED));

        // ---- live order flow card
        LinearLayout oc = card(col, ACC2);
        oc.addView(bold("⚡ Live order flow — whales vs retail", 16, TEXT));
        oc.addView(text("Har order usi waqt dikhta hai. 🐋 = whale, 🐬 = bada trader, 🐟 = retail. "
                + "Order book mein sunehri line = bada wall (🐋).", 12, MUTED));
        tape = new TapeView(this);
        oc.addView(tape, new LinearLayout.LayoutParams(-1, dp(250)));
        oc.addView(divider());
        book = new BookView(this);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, dp(240));
        blp.topMargin = dp(8);
        oc.addView(book, blp);

        resultBox = column();
        col.addView(resultBox);
        LinearLayout hint = card(resultBox);
        hint.addView(bold("Kya milega?", 15, TEXT));
        hint.addView(text("Coin likh kar Analyze dabayen. Bot sab mila kar hamesha ek saaf faisla deta hai — BUY ya SELL "
                + "(confidence % ke saath):\n"
                + "• Technical: " + String.join(", ", Mode.tfs(uiMode)) + "\n"
                + "• Chart patterns: triangle, wedge, channel, double top/bottom, breakout, Fibonacci, RSI divergence\n"
                + "• Paisa aa raha ya nikal raha: 10 exchanges ka volume + ETF inflow/outflow + on-chain\n"
                + "• Whales vs retail, order book walls\n"
                + "• Futures ke top traders, open interest, funding\n"
                + "• News, CoinGecko community, Fear & Greed\n"
                + "• 🤖 AI (Gemini / Groq / ChatGPT — free) se Roman Urdu mein trade plan aur sawal-jawab", 13, SOFT));
        updateStar();
        renderWatchRow();
    }

    private void selectTf(String tf) {
        chartTf = tf;
        for (int k = 0; k < chartTfs.length; k++) styleChip(tfChips[k], chartTfs[k].equals(chartTf));
        loadChart();
    }

    private void applyLayers() {
        applyLayers(chart);
    }

    /** Default indicator set (clean chart): the noisy ones start OFF. */
    static boolean indDefault(String k) {
        return !(k.equals("EMA") || k.equals("EMA200") || k.equals("VWAP") || k.equals("BB") || k.equals("MACD") || k.equals("VolProfile") || k.equals("Retail"));
    }

    private void applyLayers(ChartView cv) {
        for (String k : IND) cv.setInd(k, Prefs.layer(this, k, indDefault(k)));
        if (!Prefs.layer(this, "RSI", true) && Prefs.layer(this, "MACD", false)) cv.setInd("MACD", true);
        cv.setType(Prefs.chartType(this));
    }

    private void openFullscreen() {
        openChartFullscreen(chart, base(currentSym) + "/USDT", true);
    }

    /** TradingView-style full screen chart with indicators, chart types and drawing tools. */
    private void openChartFullscreen(final ChartView cv, final String title, final boolean tfSwitch) {
        if (fsOverlay != null) return;
        fsChart = cv;
        fsTfSwitch = tfSwitch;
        fsTitle = title;
        chartParent = (ViewGroup) cv.getParent();
        chartIndex = chartParent.indexOfChild(cv);
        chartLp = cv.getLayoutParams();
        chartParent.removeView(cv);
        cv.setCompact(false);
        cv.setOnTap(null);

        fsOverlay = column();
        fsOverlay.setBackgroundColor(Mode.bgTop(uiMode));
        fsOverlay.setPadding(dp(6), dp(6), dp(6), dp(4));

        LinearLayout bar = row();
        TextView x = chip("✕", true);
        x.setOnClickListener(v -> closeFullscreen());
        bar.addView(x, chipLp());
        bar.addView(bold(title, 15, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView rot = chip("⟳ Rotate", false);
        rot.setOnClickListener(v -> setRequestedOrientation(
                getResources().getDisplayMetrics().widthPixels > getResources().getDisplayMetrics().heightPixels
                        ? ActivityInfo.SCREEN_ORIENTATION_PORTRAIT : ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE));
        bar.addView(rot, chipLp());
        TextView lv = chip("⏩ Live", false);
        lv.setOnClickListener(v -> cv.goLive());
        bar.addView(lv, chipLp());
        TextView rs = chip("⟲ Reset", false);
        rs.setOnClickListener(v -> cv.resetView());
        bar.addView(rs, chipLp());
        fsOverlay.addView(bar);

        if (tfSwitch) {
            LinearLayout tr = row();
            tr.setPadding(0, dp(4), 0, 0);
            for (final String tf : ChartRange.ALL_TFS) {
                TextView c = chip(tf, tf.equals(chartTf));
                c.setTextSize(12);
                c.setOnClickListener(v -> {
                    selectTf(tf);
                    closeFullscreen();
                    openFullscreen();
                });
                tr.addView(c, chipLp());
            }
            fsOverlay.addView(hscroll(tr));
        }

        // indicators
        LinearLayout ir = row();
        ir.setPadding(0, dp(4), 0, 0);
        final TextView[] ic = new TextView[IND.length];
        for (int i = 0; i < IND.length; i++) {
            final int idx = i;
            ic[i] = chip(IND[i], cv.ind(IND[i]));
            ic[i].setTextSize(11);
            ic[i].setOnClickListener(v -> {
                boolean on = !cv.ind(IND[idx]);
                cv.setInd(IND[idx], on);
                Prefs.setLayer(this, IND[idx], on);
                if (on && IND[idx].equals("RSI")) Prefs.setLayer(this, "MACD", false);
                if (on && IND[idx].equals("MACD")) Prefs.setLayer(this, "RSI", false);
                for (int k = 0; k < IND.length; k++) styleChip(ic[k], cv.ind(IND[k]));
            });
            ir.addView(ic[i], chipLp());
        }
        fsOverlay.addView(hscroll(ir));

        // chart type + drawing tools
        LinearLayout dr = row();
        dr.setPadding(0, dp(4), 0, dp(4));
        final TextView type = chip("📊 " + ChartView.TYPES[cv.getType()], false);
        type.setTextSize(11);
        type.setOnClickListener(v -> {
            type.setText("📊 " + cv.cycleType());
            Prefs.setChartType(this, cv.getType());
        });
        dr.addView(type, chipLp());
        final TextView tl = chip("／ Trendline", false), hl = chip("— H-Line", false);
        tl.setTextSize(11);
        hl.setTextSize(11);
        tl.setOnClickListener(v -> { cv.setDrawMode(cv.getDrawMode() == 2 ? 0 : 2); styleChip(tl, cv.getDrawMode() == 2); styleChip(hl, false); });
        hl.setOnClickListener(v -> { cv.setDrawMode(cv.getDrawMode() == 1 ? 0 : 1); styleChip(hl, cv.getDrawMode() == 1); styleChip(tl, false); });
        dr.addView(tl, chipLp());
        dr.addView(hl, chipLp());
        TextView clr = chip("🗑 Clear", false);
        clr.setTextSize(11);
        clr.setOnClickListener(v -> cv.clearDrawings());
        dr.addView(clr, chipLp());
        TextView zo = chip("−", false), zi = chip("+", false);
        zo.setOnClickListener(v -> cv.zoom(30));
        zi.setOnClickListener(v -> cv.zoom(-30));
        dr.addView(zo, chipLp());
        dr.addView(zi, chipLp());
        fsOverlay.addView(hscroll(dr));

        fsOverlay.addView(cv, new LinearLayout.LayoutParams(-1, 0, 1));
        fsOverlay.addView(text("Khiskayen = time · price patti par upar/neeche = scale · 2 ungli = zoom · daba kar rakhen = crosshair · 2x tap = reset", 10, MUTED));
        rootFrame.addView(fsOverlay, new FrameLayout.LayoutParams(-1, -1));
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);
    }

    private void closeFullscreen() {
        if (fsOverlay == null) return;
        ChartView cv = fsChart;
        fsOverlay.removeView(cv);
        rootFrame.removeView(fsOverlay);
        fsOverlay = null;
        cv.setDrawMode(0);
        cv.setCompact(true);
        if (cv == chart) cv.setOnTap(this::openFullscreen);
        else {
            final ChartView c2 = cv;
            final String t2 = fsTitle;
            cv.setOnTap(() -> openChartFullscreen(c2, t2, false));
        }
        chartParent.addView(cv, chartIndex, chartLp);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }

    private void updateStar() {
        boolean on = Prefs.inWatchlist(this, currentSym);
        starBtn.setText(on ? "★" : "☆");
        styleChip(starBtn, on);
    }

    private void renderWatchRow() {
        watchRow.removeAllViews();
        for (String s : Prefs.watchlist(this)) {
            final String sym = s;
            TextView c = chip(base(s), false);
            c.setOnClickListener(v -> openAnalyze(sym));
            watchRow.addView(c, chipLp());
        }
    }

    /** Opens a coin with a SIMPLE chart (like TradingView / Binance). Patterns & indicators appear only after "Analyze". */
    private void openAnalyze(String sym) {
        showTab(1);
        searchEt.setText(base(sym));
        pages[1].scrollTo(0, 0);
        selectCoin(sym);
    }

    private void selectCoin(final String sym) {
        boolean newCoin = !sym.equals(currentSym) || chart.getData() == null;
        currentSym = sym;
        lastReport = null;
        Prefs.setLastCoin(this, sym);
        updateStar();
        chartTitle.setText(base(sym) + "/USDT");
        if (newCoin) loadChart();
        else cleanChart(chart);
        resultBox.removeAllViews();
        LinearLayout c = card(resultBox, ACC);
        c.addView(bold("📈 " + base(sym) + "/USDT — simple chart", 16, TEXT));
        c.addView(text("Abhi chart saaf hai (sirf candles + volume), bilkul TradingView / Binance ki tarah. Poora analysis chahiye to neeche dabayen — "
                + "bot patterns, trendlines, S/R zones, Fibonacci, moving averages, Supertrend aur 12 indicators chart par khud draw karega, "
                + "aur batayega kahan BUY / retest / target.", 13, SOFT));
        Button an = button("🧠 Analyze " + base(sym), ACC, INK, 0);
        an.setOnClickListener(v -> runAnalysis(sym));
        c.addView(an);
    }

    /** Loads candles + recent whale trades, runs the pattern engine, then switches the chart to LIVE. */
    private void loadChart() {
        final String sym = currentSym, tf = chartTf;
        final double whaleUsd = Prefs.whaleUsd(this);
        stopCoinFeed();
        chart.setMessage("Chart aur patterns load ho rahe hain...");
        chart.setPlan(false, true, 0, 0, 0, 0);
        tape.clear();
        book.set(new double[0][], new double[0][]);
        livePrice.setText("");
        pool.execute(() -> {
            try {
                final Candles c = Candles.fetch(sym, ChartRange.interval(tf), ChartRange.limit(tf), false);
                final PatternEngine.Result p = PatternEngine.analyze(c.closedOnly(), Math.min(150, c.n));
                final double[] wb = new double[c.n], ws = new double[c.n];
                final double thr = fillWhales(sym, c, wb, ws, whaleUsd, tf.endsWith("m") ? 3 : 1);
                double open24 = 0;
                try {
                    open24 = new JSONObject(Scanner.get("/api/v3/ticker/24hr?symbol=" + sym)).optDouble("openPrice", 0);
                } catch (Exception ignored) {
                }
                final double o24 = open24;
                runOnUiThread(() -> {
                    if (!sym.equals(currentSym) || !tf.equals(chartTf)) return;
                    chartWhaleThr = thr;
                    dayOpen = o24;
                    tape.setWhaleThreshold(thr);
                    chart.setTitle(base(sym) + "/USDT");
                    chart.setData(c, p, wb, ws, ChartRange.interval(tf), false);
                    chart.setVisible(ChartRange.visible(tf, c.n));
                    if (lastReport != null && lastReport.symbol.equals(sym)) applyPlan(lastReport);
                    else cleanChart(chart);
                    if (resumed) startCoinFeed();
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> chart.setMessage("Chart nahi mila: " + m));
            }
        });
    }

    /** Puts big trades (>= threshold) from the latest aggTrades pages onto their candles. Returns the threshold. */
    private static double fillWhales(String sym, Candles c, double[] wb, double[] ws, double whaleUsd, int pages) {
        double qv = 0;
        for (int i = Math.max(0, c.n - 24); i < c.n; i++) qv += c.quoteVol[i];
        double thr = Math.min(whaleUsd, Math.max(5000, qv / Math.max(1, Math.min(24, c.n)) / 40));
        try {
            long fromId = -1;
            for (int pg = 0; pg < pages; pg++) {
                String q = "/api/v3/aggTrades?symbol=" + sym + "&limit=1000" + (fromId >= 0 ? "&fromId=" + fromId : "");
                JSONArray tr = new JSONArray(Scanner.get(q));
                if (tr.length() == 0) break;
                long firstId = Long.MAX_VALUE;
                for (int i = 0; i < tr.length(); i++) {
                    JSONObject o = tr.getJSONObject(i);
                    firstId = Math.min(firstId, o.optLong("a"));
                    double usd = Double.parseDouble(o.getString("p")) * Double.parseDouble(o.getString("q"));
                    if (usd < thr) continue;
                    int idx = c.indexOf(o.optLong("T"));
                    if (idx < 0) continue;
                    if (o.optBoolean("m")) ws[idx] += usd; else wb[idx] += usd;
                }
                fromId = firstId - 1000;
                if (fromId < 0) break;
            }
        } catch (Exception ignored) {
        }
        return thr;
    }

    // ------------------------------------------------------------ live coin stream
    private void startCoinFeed() {
        stopCoinFeed();
        final String sym = currentSym, tf = chartTf;
        liveSym = sym;
        liveTf = tf;
        synchronized (liveLock) {
            pendingKline = null;
            pendingTrades.clear();
            pendingBids = pendingAsks = null;
            candleClosed = false;
        }
        String s = sym.toLowerCase(Locale.US);
        coinWs = new WsStream("/stream?streams=" + s + "@kline_" + ChartRange.interval(tf) + "/" + s + "@aggTrade/" + s + "@depth20",
                new WsStream.Callback() {
                    @Override
                    public void onText(String text) { parseCoin(text); }

                    @Override
                    public void onStatus(boolean live) { coinLive = live; }
                }).start();
    }

    private void stopCoinFeed() {
        if (coinWs != null) coinWs.stop();
        coinWs = null;
        coinLive = false;
    }

    /** Runs on the WebSocket thread: just parse and park the data; the UI applies it every 400 ms. */
    private void parseCoin(String text) {
        try {
            JSONObject o = new JSONObject(text);
            String st = o.optString("stream");
            JSONObject d = o.optJSONObject("data");
            if (d == null) return;
            if (st.contains("@kline")) {
                JSONObject k = d.optJSONObject("k");
                if (k == null) return;
                double[] kl = {k.optLong("t"), num(k, "o"), num(k, "h"), num(k, "l"), num(k, "c"), num(k, "v"),
                        num(k, "q"), num(k, "V"), num(k, "Q"), k.optLong("n"), k.optBoolean("x") ? 1 : 0};
                synchronized (liveLock) {
                    pendingKline = kl;
                    if (kl[10] == 1) candleClosed = true;
                }
            } else if (st.contains("@aggTrade")) {
                double p = num(d, "p"), q = num(d, "q");
                synchronized (liveLock) {
                    if (pendingTrades.size() < 4000) pendingTrades.add(new double[]{d.optLong("T"), p, p * q, d.optBoolean("m") ? 1 : 0});
                }
            } else if (st.contains("@depth")) {
                JSONArray b = d.optJSONArray("bids"), a = d.optJSONArray("asks");
                if (b == null || a == null) return;
                double[][] bb = new double[b.length()][], aa = new double[a.length()][];
                for (int i = 0; i < b.length(); i++) {
                    JSONArray x = b.getJSONArray(i);
                    bb[i] = new double[]{Double.parseDouble(x.getString(0)), Double.parseDouble(x.getString(1))};
                }
                for (int i = 0; i < a.length(); i++) {
                    JSONArray x = a.getJSONArray(i);
                    aa[i] = new double[]{Double.parseDouble(x.getString(0)), Double.parseDouble(x.getString(1))};
                }
                synchronized (liveLock) {
                    pendingBids = bb;
                    pendingAsks = aa;
                }
            }
        } catch (Exception ignored) {
        }
    }

    /** UI thread, every 400 ms: move live candles / trades / order book onto the screen. */
    private void applyLive() {
        double[] kl;
        List<double[]> trs;
        double[][] b, a;
        boolean closed;
        synchronized (liveLock) {
            kl = pendingKline;
            pendingKline = null;
            trs = new ArrayList<>(pendingTrades);
            pendingTrades.clear();
            b = pendingBids;
            a = pendingAsks;
            pendingBids = pendingAsks = null;
            closed = candleClosed;
            candleClosed = false;
        }
        if (coinWs == null || !currentSym.equals(liveSym) || !chartTf.equals(liveTf)) return;
        Candles cur = chart.getData();
        if (kl != null && cur != null) {
            Candles nc = cur.live((long) kl[0], kl[1], kl[2], kl[3], kl[4], kl[5], kl[6], kl[7], kl[8], kl[9]);
            if (nc != null) chart.liveCandles(nc);
            double p = kl[4];
            String ch = dayOpen > 0 ? "  " + Fmt.pct((p / dayOpen - 1) * 100) : "";
            livePrice.setText("$" + Fmt.price(p) + ch);
            livePrice.setTextColor(dayOpen > 0 && p < dayOpen ? RED : GREEN);
        }
        for (double[] t : trs) {
            boolean sell = t[3] == 1;
            if (t[2] >= chartWhaleThr) chart.liveTrade((long) t[0], t[2], sell);
            tape.add(TapeView.trade((long) t[0], t[1], t[2], sell));
        }
        tape.invalidate();
        if (b != null) book.set(b, a);
        chart.setLiveText(coinLive ? "● LIVE" : "○ connect ho raha hai...");
        if (closed && chart.getData() != null) {
            final Candles snap = chart.getData().closedOnly();
            final String sym = currentSym, tf = chartTf;
            pool.execute(() -> {
                final PatternEngine.Result p = PatternEngine.analyze(snap, Math.min(150, snap.n));
                runOnUiThread(() -> {
                    if (sym.equals(currentSym) && tf.equals(chartTf)) chart.setPatterns(p);
                });
            });
        }
    }

    // ------------------------------------------------------------ full analysis
    private void runAnalysis(String sym) {
        boolean newCoin = !sym.equals(currentSym) || chart.getData() == null;
        currentSym = sym;
        lastReport = null;
        Prefs.setLastCoin(this, sym);
        updateStar();
        chartTitle.setText(base(sym) + "/USDT");
        if (newCoin) loadChart();
        else chart.setPlan(false, true, 0, 0, 0, 0);
        resultBox.removeAllViews();
        LinearLayout wait = card(resultBox, ACC);
        wait.addView(bold("⏳ " + base(sym) + " ka " + Mode.label(uiMode) + " analysis ho raha hai...", 15, ACC));
        wait.addView(text("Binance (" + String.join(", ", Mode.tfs(uiMode)) + "), 10 exchanges ka volume, ETF flows, on-chain, "
                + "chart patterns, whales, futures, news aur sentiment se data jama ho raha hai. 15–30 second lag sakte hain.", 13, MUTED));
        final String key = Prefs.glassKey(this);
        final double wu = Prefs.whaleUsd(this);
        final int mode = uiMode;
        pool.execute(() -> {
            try {
                final CoinReport r = CoinReport.build(sym, mode, key, wu, true);
                runOnUiThread(() -> {
                    if (sym.equals(currentSym)) showReport(r);
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> {
                    if (!sym.equals(currentSym)) return;
                    resultBox.removeAllViews();
                    LinearLayout c = card(resultBox, RED);
                    c.addView(bold("❌ Analysis nahi ho saka", 15, RED));
                    c.addView(text(m == null ? "Internet check karein" : m, 13, SOFT));
                    c.addView(text("Coin ka naam sahi likhein (jaise SOL, PEPE, WIF). Market tab mein search karke bhi dhoond sakte hain.", 12, MUTED));
                });
            }
        });
    }

    private String pctFrom(double v, double p) {
        return p > 0 ? String.format(Locale.US, "  (%+.1f%%)", (v / p - 1) * 100) : "";
    }

    private void applyPlan(CoinReport r) {
        analysisLayers(chart);
        boolean showPlan = r.isBuy || r.mode == Mode.SCALP;
        double entry = r.advice != null ? r.advice.entry : r.price;
        chart.setPlan(showPlan && r.atr > 0, r.isBuy, entry, r.stop, r.target1, r.target2);
        if (r.advice != null) chart.setZone(r.advice.zoneLo, r.advice.zoneHi, (r.isBuy ? "BUY ZONE" : "SELL ZONE"), r.isBuy ? GREEN : RED);
        else chart.setZone(0, 0, "", 0);
        setScenario(chart, r.advice, r.price);
        // v38: when the Trade Agent calls a trade, ITS entry zone / stop / targets are what the chart shows (same numbers everywhere)
        try {
            TradeAgent.Verdict v = TradeAgent.decide(r);
            if (v.isTrade()) {
                boolean b = v.isBuy();
                chart.setPlan(true, b, b ? v.entryHi : v.entryLo, v.sl, v.tp1, v.tp2);
                chart.setZone(v.entryLo, v.entryHi, b ? "BUY ZONE" : "SELL ZONE", b ? GREEN : RED);
            }
        } catch (Exception ignored) {
        }
    }

    /** Plain chart: only candles + volume (no lines) — used before the user runs an analysis. */
    private void cleanChart(ChartView cv) {
        for (String k : IND) cv.setInd(k, false);
        cv.setInd("Volume", true);
        cv.setInd("Crosses", true);   // golden / death cross always visible (just labels, no clutter)
        cv.setType(Prefs.chartType(this));
        cv.setPlan(false, true, 0, 0, 0, 0);
        cv.setZone(0, 0, "", 0);
        cv.setScenario(false, "", true, 0, 0, 0, 0);
    }

    /** After an analysis: draw the patterns, S/R zones, Fibonacci, MA ribbon, crosses and ParaDox signals. */
    private void analysisLayers(ChartView cv) {
        for (String k : IND) cv.setInd(k, false);
        // v38: Fib Retrace (pivot 20/10) + Smart Money zones replace the old thin fib lines and the MA ribbon clutter
        for (String k : new String[]{"Patterns", "Zones", "FibTMF", "SMC", "Flow", "Supertrend", "Crosses", "ParaDox", "Arrows", "Volume", "RSI"}) cv.setInd(k, true);
        cv.setType(Prefs.chartType(this));
    }

    /** "Where to buy and how far it can go" drawn into the chart. */
    private void setScenario(ChartView cv, Position.Advice a, double price) {
        if (a == null) { cv.setScenario(false, "", true, 0, 0, 0, 0); return; }
        double level = Position.BREAKOUT.equals(a.type) ? (a.buy ? a.zoneLo : a.zoneHi) : a.entry;
        cv.setScenario(true, a.type, a.buy, price, Position.NOW.equals(a.type) ? 0 : level, a.tp1, a.tp2);
    }

    private void showReport(final CoinReport r) {
        lastReport = r;
        resultBox.removeAllViews();
        chartTitle.setText(r.name + " · " + r.base + "/USDT");
        boolean scalp = r.mode == Mode.SCALP;
        boolean showPlan = r.isBuy || scalp;
        applyPlan(r);
        int vc = r.isBuy ? GREEN : RED;
        try { tradeAgentCard(r); } catch (Exception ignored) { }   // v38: one clear instruction first
        try { orderFlowCard(r); } catch (Exception ignored) { }         // v39: buyers vs sellers per candle

        LinearLayout h = card(resultBox, vc);
        LinearLayout hr = row();
        hr.addView(bold("🎯 Final signal", 16, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView mb = bold(Mode.label(r.mode), 11, INK);
        mb.setPadding(dp(8), dp(3), dp(8), dp(3));
        mb.setBackground(round(ACC, 10, 0));
        hr.addView(mb);
        h.addView(hr);
        TextView big = bold((r.isBuy ? "▲ " : "▼ ") + r.verdict, 30, vc);
        big.setGravity(Gravity.CENTER);
        big.setLetterSpacing(0.05f);
        h.addView(big);
        TextView conf = bold("Confidence " + r.confidence + "%  ·  Score " + r.total + "/100", 13, TEXT);
        conf.setGravity(Gravity.CENTER);
        h.addView(conf);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, dp(10));
        clp.topMargin = dp(6);
        clp.bottomMargin = dp(6);
        h.addView(bar(r.confidence, vc, 0xFF243049), clp);
        TextView vt = text(r.verdictText, 14, SOFT);
        vt.setGravity(Gravity.CENTER);
        h.addView(vt);
        GaugeView g = new GaugeView(this);
        g.set(r.total, r.isBuy ? "BUY side" : "SELL side", "0 = full sell · 100 = full buy");
        h.addView(g, new LinearLayout.LayoutParams(-1, dp(165)));
        TextView rf = chip("↻ Dobara analysis (taaza data)", false);
        rf.setOnClickListener(v -> runAnalysis(r.symbol));
        h.addView(rf);

        positionCard(r);
        liveFlowCard(r);
        arrowLabCard(resultBox, r.symbol, false);
        flowCard(r);

        // ---- AI analyst
        aiCard(r);

        LinearLayout f = card(resultBox);
        f.addView(bold("💰 Paisa aa raha ya nikal raha? (" + Mode.flowSpan(r.mode) + ")", 16, TEXT));
        f.addView(bold(r.flowLabel, 17, r.flowSign > 0 ? GREEN : r.flowSign < 0 ? RED : YELLOW));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, dp(14));
        blp.topMargin = dp(8);
        f.addView(bar(r.buyPct, GREEN, RED), blp);
        LinearLayout lr = row();
        lr.addView(text(String.format(Locale.US, "Buyers %.0f%%", r.buyPct), 12, GREEN), new LinearLayout.LayoutParams(0, -2, 1));
        lr.addView(text(String.format(Locale.US, "Sellers %.0f%%", 100 - r.buyPct), 12, RED));
        f.addView(lr);
        f.addView(text("Live 60 second ka hisaab upar 'Live order flow' card mein har waqt update hota hai.", 12, MUTED));

        tradePlan(r, showPlan);

        paradoxCard(resultBox, r.ma, r.bt, r.bt2, r.ruleSide, r.ruleChecks, r.mtfAgree, r.patternTf, Mode.tfs(r.mode).length);
        for (CoinReport.Section s : r.sections) sectionCard(resultBox, s);
        scoreBuildCard(resultBox, r.sections, r.total, r.confidence);

        if (!r.news.isEmpty()) {
            LinearLayout n = card(resultBox);
            n.addView(bold("📰 Taaza khabrein — " + r.name, 16, TEXT));
            for (String[] it : r.news) {
                String tone = "+".equals(it[3]) ? "🟢 " : "-".equals(it[3]) ? "🔴 " : "⚪ ";
                TextView t = text(tone + it[0], 13, TEXT);
                t.setPadding(0, dp(6), 0, 0);
                final String link = it[1];
                t.setOnClickListener(v -> openUrl(link));
                n.addView(t);
                n.addView(text(it[2] + " · tap karke parhen", 11, MUTED));
            }
        }

        LinearLayout al = card(resultBox, ACC2);
        al.addView(bold("🔔 Price alert lagayen", 16, TEXT));
        al.addView(text("Price is level ko cross kare to notification aayegi (koi bhi bot ON hona chahiye).", 12, MUTED));
        LinearLayout ar = row();
        final EditText ap = input("Price", Fmt.price(r.isBuy ? r.target1 : r.stop), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        ar.addView(ap, new LinearLayout.LayoutParams(0, -2, 1));
        TextView ab = chip("Alert lagao", true);
        ab.setOnClickListener(v -> {
            double p = parse(ap, 0);
            if (p <= 0) { toast("Sahi price likhen"); return; }
            Prefs.addAlert(this, r.symbol, p, p > r.price);
            toast("Alert laga diya: " + r.base + (p > r.price ? " upar " : " neeche ") + "$" + Fmt.price(p));
            if (!Prefs.enabled(this)) toast("Yaad rahe: Signals tab se Scalp ya Spot bot ON karein");
        });
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-2, -2);
        alp.leftMargin = dp(8);
        ar.addView(ab, alp);
        al.addView(ar);

        LinearLayout act = card(resultBox);
        Button bin = button("🟡 Binance app mein " + r.base + " kholen (Spot)", 0xFFF0B90B, INK, 0);
        bin.setOnClickListener(v -> BinanceLink.open(this, r.base, false));
        act.addView(bin);
        Button binF = button("🟡 Binance Futures mein kholen", CHIP, 0xFFF0B90B, 0xFFF0B90B);
        binF.setOnClickListener(v -> BinanceLink.open(this, r.base, true));
        act.addView(binF);
        act.addView(text("⚠️ Yeh analysis maloomat ke liye hai, financial advice nahi. Chart patterns aur whale markers "
                + "computer ka andaza hain — 100% sahi nahi hote. Hamesha stop-loss lagayen aur utna hi lagayen jitna "
                + "khona bardasht ho.", 12, MUTED));
    }

    // ------------------------------------------------------------ AI analyst
    private String liveExtras() {
        StringBuilder sb = new StringBuilder("\n[LIVE ORDER FLOW right now]\n");
        double[] p = tape.pressure();
        sb.append("- Last 60s aggressive buy ").append(Fmt.usd(p[0])).append(" vs sell ").append(Fmt.usd(p[1])).append('\n');
        sb.append("- Last 5min whale buy ").append(Fmt.usd(p[4])).append(" vs whale sell ").append(Fmt.usd(p[5]))
                .append(" (whale = trade >= ").append(Fmt.usd(chartWhaleThr)).append(")\n");
        double[] s = book.sums();
        sb.append("- Order book top 10: bids ").append(Fmt.usd(s[0])).append(" vs asks ").append(Fmt.usd(s[1])).append('\n');
        Candles c = chart.getData();
        if (c != null && c.n > 0) sb.append("- Live price ").append(Fmt.price(c.close[c.n - 1])).append(" on ").append(chartTf).append(" chart\n");
        return sb.toString();
    }

    // ============================================================ v38: 🎯 TRADE AGENT (one clear instruction + chat, right under the chart)
    private void tradeAgentCard(final CoinReport r) {
        final TradeAgent.Verdict v = TradeAgent.decide(r);
        final boolean trade = v.isTrade(), buy = v.isBuy();
        int col = !trade ? YELLOW : buy ? GREEN : RED;
        LinearLayout c = card(resultBox, col);
        LinearLayout hr = row();
        hr.addView(bold("🎯 Trade Agent", 16, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        hr.addView(text("FREE · sab kuch dekh kar ek faisla", 10, MUTED));
        c.addView(hr);
        TextView big = bold(v.headline, 19, col);
        big.setTextIsSelectable(true);
        c.addView(big);
        c.addView(text(v.sub, 13, SOFT));
        if (trade) {
            double e = buy ? v.entryHi : v.entryLo, risk = Math.abs(e - v.sl);
            c.addView(bold(String.format(Locale.US, "🛑 Stop-loss: $%s (%.1f%%)", Fmt.price(v.sl), risk / e * 100), 14, RED));
            c.addView(bold((buy ? "🎯 Yahan becho: " : "🎯 Yahan cover / dobara lo: ") + String.format(Locale.US, "TP1 $%s · TP2 $%s · TP3 $%s", Fmt.price(v.tp1), Fmt.price(v.tp2), Fmt.price(v.tp3)), 14, GREEN));
            c.addView(text(String.format(Locale.US, "Reward : risk — TP1 %.1f · TP2 %.1f · TP3 %.1f. TP1 par 1/3 bech kar stop entry par le aayen, TP2 par 1/3, TP3 par baqi.",
                    Math.abs(v.tp1 - e) / risk, Math.abs(v.tp2 - e) / risk, Math.abs(v.tp3 - e) / risk), 12, MUTED));
        }
        final LinearLayout votes = column();
        votes.setVisibility(View.GONE);
        for (String s : v.votes) votes.addView(text(s, 12, SOFT));
        TextView vt = chip("⚖️ 7 judges: 🟢 " + v.buy + " · 🔴 " + v.sell + " — tafseel ▾", false);
        vt.setTextSize(11);
        vt.setOnClickListener(x -> votes.setVisibility(votes.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
        c.addView(vt);
        c.addView(votes);
        // ---- chat
        final LinearLayout chat = column();
        c.addView(chat);
        final List<String[]> history = new ArrayList<>();
        final String verdictText = TradeAgent.text(r, v);
        LinearLayout qr = row();
        final String[] quick = {"Kahan buy karun?", "Kahan sell karun?", "Abhi entry lun?", "Stop kahan?"};
        for (final String q : quick) {
            TextView qc = chip(q, false);
            qc.setTextSize(11);
            qc.setOnClickListener(x -> agentAsk(r, v, verdictText, chat, history, q));
            qr.addView(qc, chipLp());
        }
        c.addView(hscroll(qr));
        LinearLayout ir = row();
        final EditText in = input("Agent se poochen (jaise: 50$ se kitna lun?)", "", InputType.TYPE_CLASS_TEXT);
        ir.addView(in, new LinearLayout.LayoutParams(0, -2, 1));
        TextView ask = chip("Poochen", true);
        ask.setOnClickListener(x -> {
            String s = in.getText().toString().trim();
            if (s.isEmpty()) return;
            in.setText("");
            hideKeyboard();
            agentAsk(r, v, verdictText, chat, history, s);
        });
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-2, -2);
        alp.leftMargin = dp(8);
        ir.addView(ask, alp);
        c.addView(ir);
        c.addView(text("Faisla 7 alag jaanchon ke ittefaq se hota hai (kam az kam 4 haq mein, zyada se zyada 1 khilaf) — warna 'trade nahi'. "
                + "Stop wahi price hai jahan idea ghalat sabit hota hai; koi bhi trade 100% pakka nahi hota, is liye stop hamesha lagayen.", 11, MUTED));
    }

    /** Answers from the verdict itself (always), and lets the free AI explain it when a key is set. */
    private void agentAsk(CoinReport r, TradeAgent.Verdict v, String verdictText, LinearLayout chat, List<String[]> history, String q) {
        if (AiRouter.ready(this)) {
            if (history.isEmpty()) askAi(TradeAgent.aiRules() + "\n\nFAISLA:\n" + verdictText + "\n\nPOORA DATA:\n" + r.toText() + liveExtras(), chat, history, q);
            else {
                history.add(new String[]{"user", q});
                chat.addView(bubble("🙋 " + q, true));
                final TextView th = bubble("🤖 Agent soch raha hai...", false);
                chat.addView(th);
                final List<String[]> snap = new ArrayList<>(history);
                pool.execute(() -> {
                    try {
                        final String ans = AiRouter.ask(this, snap);
                        runOnUiThread(() -> { history.add(new String[]{"assistant", ans}); th.setText("🤖 " + ans); });
                    } catch (Exception e) {
                        final String m = e.getMessage();
                        runOnUiThread(() -> th.setText("🎯 " + agentReply(v, q) + "\n\n(AI se jawab nahi aaya: " + m + ")"));
                    }
                });
            }
            return;
        }
        chat.addView(bubble("🙋 " + q, true));
        chat.addView(bubble("🎯 " + agentReply(v, q), false));
    }

    /** Rule-based answer (no AI needed): picks the part of the verdict the question is about. */
    static String agentReply(TradeAgent.Verdict v, String q) {
        String l = q.toLowerCase(Locale.US);
        boolean trade = v.isTrade(), buy = v.isBuy();
        String zone = "$" + Fmt.price(v.entryLo) + " – $" + Fmt.price(v.entryHi);
        String tps = "TP1 $" + Fmt.price(v.tp1) + " · TP2 $" + Fmt.price(v.tp2) + " · TP3 $" + Fmt.price(v.tp3);
        String none = "Abhi trade nahi. BUY sirf tab jab candle $" + Fmt.price(v.buyTrigger) + " ke upar band ho; SELL / exit tab jab $" + Fmt.price(v.sellTrigger) + " ke neeche band ho.";
        if (!trade) return none;
        if (l.contains("stop") || l.contains("sl")) return "Stop-loss $" + Fmt.price(v.sl) + " par lagayen. Price wahan pohanchi to idea ghalat — foran nikal jayen.";
        if (l.contains("sell") || l.contains("bech") || l.contains("target") || l.contains("tp") || l.contains("nikal")) {
            return buy ? "Yahan becho: " + tps + ". TP1 par 1/3, TP2 par 1/3, TP3 par baqi. Stop $" + Fmt.price(v.sl) + "."
                    : (v.action.equals(TradeAgent.SELL_NOW) ? "Abhi becho: " : "Yahan becho: ") + zone + ". Stop $" + Fmt.price(v.sl) + ". Cover: " + tps + ".";
        }
        if (l.contains("buy") || l.contains("khareed") || l.contains("entry") || l.contains("lun") || l.contains("lu ")) {
            return buy ? (v.action.equals(TradeAgent.BUY_NOW) ? "Haan — abhi buy karo: " : "Abhi nahi — limit order lagao: ") + zone + ". Stop $" + Fmt.price(v.sl) + ". Becho: " + tps + "."
                    : "Buy mat karo — faisla SELL hai. " + (v.action.equals(TradeAgent.SELL_NOW) ? "Abhi becho " : "Yahan becho ") + zone + ". Buy tab sochein jab candle $"
                    + Fmt.price(v.buyTrigger) + " ke upar band ho.";
        }
        return v.headline + "\n" + v.sub + "\nStop $" + Fmt.price(v.sl) + " · " + tps + "\n(Tafseeli jawab ke liye Settings mein FREE Gemini / Groq key daalein.)";
    }

    private void aiCard(final CoinReport r) {
        LinearLayout ai = card(resultBox, CLAUDE);
        LinearLayout hr = row();
        hr.addView(bold("🤖 AI Analyst · " + AiRouter.label(this), 16, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        ai.addView(hr);
        ai.addView(text("AI (Gemini / Groq — FREE) upar ka saara live data parh kar Roman Urdu mein trade plan likhega. Aap apne sawal bhi pooch sakte hain.", 12, MUTED));
        final LinearLayout chat = column();
        ai.addView(chat);
        final List<String[]> history = new ArrayList<>();
        TextView full = chip("✨ AI se poora analysis likhwayen", true);
        full.setBackground(round(CLAUDE, 20, CLAUDE));
        full.setOnClickListener(v -> askClaude(r, chat, history,
                "Is coin ka poora analysis karo: direction (BUY/SELL), entry, stop-loss, 2 targets, risk, aur kis cheez se idea ghalat sabit hoga.", true));
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(-1, -2);
        flp.topMargin = dp(8);
        ai.addView(full, flp);
        LinearLayout qr = row();
        final EditText q = input("Sawal likhen (jaise: kya abhi entry lun?)", "", InputType.TYPE_CLASS_TEXT);
        qr.addView(q, new LinearLayout.LayoutParams(0, -2, 1));
        TextView ask = chip("Poochen", false);
        ask.setOnClickListener(v -> {
            String s = q.getText().toString().trim();
            if (s.isEmpty()) return;
            q.setText("");
            hideKeyboard();
            askClaude(r, chat, history, s, history.isEmpty());
        });
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-2, -2);
        alp.leftMargin = dp(8);
        qr.addView(ask, alp);
        ai.addView(qr);
    }

    private TextView bubble(String s, boolean user) {
        TextView t = text(s, 13, user ? TEXT : SOFT);
        t.setPadding(dp(10), dp(8), dp(10), dp(8));
        t.setBackground(round(user ? 0xFF243049 : 0x22D97757, 12, user ? 0 : 0x66D97757));
        t.setTextIsSelectable(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(8);
        t.setLayoutParams(lp);
        return t;
    }

    private void askClaude(final CoinReport r, final LinearLayout chat, final List<String[]> history, String question, boolean withData) {
        {
            if (withData || history.isEmpty()) askAi(r.toText() + liveExtras(), chat, history, question);
            else {
                if (!AiRouter.ready(this)) { askAi("", chat, history, question); return; }
                history.add(new String[]{"user", question});
                chat.addView(bubble("🙋 " + question, true));
                final TextView th = bubble("🤖 " + AiRouter.label(this) + " soch raha hai...", false);
                chat.addView(th);
                final List<String[]> snap = new ArrayList<>(history);
                pool.execute(() -> {
                    try {
                        final String ans = AiRouter.ask(this, snap);
                        runOnUiThread(() -> { history.add(new String[]{"assistant", ans}); th.setText("🤖 " + ans); });
                    } catch (Exception e) {
                        final String m = e.getMessage();
                        runOnUiThread(() -> { th.setText("❌ AI se jawab nahi aaya: " + m); th.setTextColor(RED); });
                    }
                });
            }
        }
    }

    private void tradePlan(final CoinReport r, boolean showPlan) {
        boolean scalp = r.mode == Mode.SCALP;
        LinearLayout p = card(resultBox, ACC);
        p.addView(bold("🧭 Trade plan — " + (r.isBuy ? (scalp ? "LONG scalp" : "Spot BUY") : (scalp ? "SHORT scalp (futures)" : "Spot: bechne / exit ka waqt")), 16, TEXT));
        p.addView(text("Support: $" + Fmt.price(r.support) + "   ·   Resistance: $" + Fmt.price(r.resistance), 13, SOFT));
        if (r.patterns != null && r.patterns.keyLevel > 0)
            p.addView(text("📐 Key level: $" + Fmt.price(r.patterns.keyLevel) + " · pattern target: $" + Fmt.price(r.patterns.target), 13, SOFT));
        if (!showPlan || r.atr <= 0) {
            p.addView(text("Spot mein SELL ka matlab: naya na khareedain. Holding ho to $" + Fmt.price(r.support)
                    + " ke neeche stop rakhen ya profit bacha lein. Wapas BUY tab jab score 50+ ho jaye.", 13, YELLOW));
            return;
        }
        double en = r.advice != null && r.advice.entry > 0 ? r.advice.entry : r.price;
        if (r.advice != null) p.addView(bold(r.advice.title, 14, r.isBuy ? GREEN : RED));
        p.addView(text((r.isBuy ? "🟢 Entry: ~$" : "🔴 Entry / exit: ~$") + Fmt.price(en) + (r.advice != null && r.advice.zoneLo > 0 ? "  (zone $" + Fmt.price(r.advice.zoneLo) + " – $" + Fmt.price(r.advice.zoneHi) + ")" : ""), 14, TEXT));
        p.addView(text("🛑 Stop-loss: $" + Fmt.price(r.stop) + pctFrom(r.stop, en) + (r.isBuy ? " — support ke neeche" : " — resistance ke upar"), 14, RED));
        double rk = Math.abs(en - r.stop);
        double[] tg = {r.target1, r.target2, r.target3}, pb = {r.prob1, r.prob2, r.prob3};
        for (int i = 0; i < 3; i++) {
            if (tg[i] <= 0) continue;
            p.addView(text(String.format(Locale.US, "🎯 Target %d: $%s%s  (1 : %.1f)%s", i + 1, Fmt.price(tg[i]), pctFrom(tg[i], en), rk > 0 ? Math.abs(tg[i] - en) / rk : 0,
                    Double.isNaN(pb[i]) ? "" : String.format(Locale.US, " · imkaan %.0f%%", pb[i])), 14, GREEN));
        }
        p.addView(text((r.isBuy ? "Targets = agli resistances (toot kar upar)" : "Targets = agle supports (toot kar neeche)")
                + " · imkaan = is coin ki apni pichli candles mein kitni dafa yeh target stop se PEHLE aaya. TP1 par 1/3 profit lein aur stop entry par le aayen, "
                + "TP2 par 1/3, TP3 par baqi. Lines chart par bhi bani hain.", 12, MUTED));
        p.addView(text(String.format(Locale.US, "📊 Coin ka apna data: %.0f/100 · poori market ka mood: %.0f/100 (faisle mein coin 80%%, market 20%%)", r.coinScore, r.marketScore), 12, SOFT));

        p.addView(divider());
        p.addView(bold("🧮 Position size calculator", 15, ACC2));
        LinearLayout rr = row();
        final EditText bal = input("Balance USDT", String.valueOf(Prefs.balance(this)), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        final EditText rp = input("Risk %", String.valueOf(Prefs.riskPct(this)), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        LinearLayout c1 = column();
        c1.addView(text("Balance (USDT)", 11, MUTED));
        c1.addView(bal);
        LinearLayout c2 = column();
        c2.addView(text("Risk per trade %", 11, MUTED));
        c2.addView(rp);
        rr.addView(c1, new LinearLayout.LayoutParams(0, -2, 1));
        rr.addView(new View(this), new LinearLayout.LayoutParams(dp(10), 1));
        rr.addView(c2, new LinearLayout.LayoutParams(0, -2, 1));
        p.addView(rr);
        final TextView out = text("", 13, TEXT);
        Runnable calc = () -> {
            double b = parse(bal, 0), pct = parse(rp, 1);
            Prefs.saveRisk(this, (float) b, (float) pct);
            double riskUsd = b * pct / 100;
            double perUnit = Math.abs(r.price - r.stop);
            if (perUnit <= 0 || b <= 0) { out.setText("Balance likhen"); return; }
            double qty = riskUsd / perUnit;
            double pos = qty * r.price;
            String lev = pos > b ? String.format(Locale.US, "\n⚠️ Position balance se badi hai — %.1fx leverage chahiye. Risk kam karein.", pos / b) : "";
            out.setText(String.format(Locale.US, "Agar stop lage to nuksan: $%.2f (%.1f%%)\nKhareedain: %s %s  ≈  $%.2f\nTP1 par faida ≈ $%.2f · TP2 par ≈ $%.2f%s",
                    riskUsd, pct, qty >= 1 ? String.format(Locale.US, "%.2f", qty) : String.format(Locale.US, "%.6f", qty), r.base, pos,
                    qty * Math.abs(r.target1 - r.price), qty * Math.abs(r.target2 - r.price), lev));
        };
        TextView cb = chip("Calculate", true);
        cb.setOnClickListener(v -> { hideKeyboard(); calc.run(); });
        LinearLayout.LayoutParams cblp = new LinearLayout.LayoutParams(-2, -2);
        cblp.topMargin = dp(6);
        p.addView(cb, cblp);
        p.addView(out);
        calc.run();
    }

    private void sectionCard(LinearLayout parent, CoinReport.Section s) {
        boolean pat = s.icon.equals("📐");
        LinearLayout c = card(parent, pat ? ACC2 : STROKE);
        LinearLayout hr = row();
        hr.addView(bold(s.icon + "  " + s.title, 15, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        int col = !s.available ? MUTED : s.score > 15 ? GREEN : s.score < -15 ? RED : YELLOW;
        hr.addView(bold(s.available ? String.format(Locale.US, "%+d", s.score) : "N/A", 14, col));
        c.addView(hr);
        if (s.available) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(6));
            lp.topMargin = dp(6);
            lp.bottomMargin = dp(4);
            c.addView(bar((s.score + 100) / 2.0, col, 0xFF243049), lp);
        }
        for (String l : s.lines) c.addView(text("• " + l, 13, SOFT));
        if (pat) c.addView(text("👆 Yeh sab upar chart par lines, zones aur 🎯 arrow ki shakal mein bana hai.", 12, ACC2));
        if (s.learn != null && !s.learn.isEmpty()) learnToggle(c, s.learn);
    }

    // ============================================================ in-app update
    private void checkForUpdate(final boolean manual) {
        if (manual && updStatus != null) updStatus.setText("Check ho raha hai...");
        pool.execute(() -> {
            try {
                final UpdateManager.Info in = UpdateManager.check(this);
                runOnUiThread(() -> {
                    if (in != null) {
                        showUpdate(in);
                        if (updStatus != null) updStatus.setText("🆕 Naya version available: " + in.title);
                    } else {
                        updateBanner.setVisibility(View.GONE);
                        if (updStatus != null) updStatus.setText("✅ Aap ke paas latest version hai");
                        if (manual) toast("App up to date hai ✅");
                    }
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> {
                    if (updStatus != null) updStatus.setText("Update check nahi hua: " + m + " (repo naam check karein)");
                });
            }
        });
    }

    private void showUpdate(final UpdateManager.Info in) {
        updateBanner.removeAllViews();
        updateBanner.setVisibility(View.VISIBLE);
        updateBanner.addView(bold("🆕 Naya update available!", 16, GREEN));
        String when = new SimpleDateFormat("dd MMM HH:mm", Locale.US).format(new Date(in.time));
        updateBanner.addView(text(in.title + " · " + when + " · " + Fmt.num(in.size / 1024.0) + " KB", 12, MUTED));
        final TextView prog = text("", 12, SOFT);
        updateBanner.addView(prog);
        Button b = button("⬇ Abhi install karein", GREEN, INK, 0);
        b.setOnClickListener(v -> startInstall(in, prog));
        updateBanner.addView(b);
        if (currentTab == TAB_SETTINGS) toast("🆕 Naya update — Market tab ke upar Install dabayen");
    }

    private void startInstall(final UpdateManager.Info in, final TextView prog) {
        if (installing) return;
        if (!UpdateManager.canInstall(this)) {
            prog.setText("Pehli dafa: agli screen par 'Allow from this source' ON karein, phir wapas aa kar dobara Install dabayen.");
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) {
            }
            return;
        }
        installing = true;
        prog.setText("Download ho raha hai... 0%");
        pool.execute(() -> {
            try {
                UpdateManager.install(this, in, pct -> runOnUiThread(() -> prog.setText("Download ho raha hai... " + pct + "%")));
                runOnUiThread(() -> prog.setText("✅ Download mukammal — ab Android ki screen par 'Update' dabayen"));
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> prog.setText("❌ Update nahi hua: " + m));
            } finally {
                installing = false;
            }
        });
    }

    // ============================================================ position + volume windows (analysis)
    /** Spot: multi-horizon plan with 4 targets + money in/out on ALL exchanges. Scalp: heavy-flow meter for this coin. */
    private void liveFlowCard(final CoinReport r) {
        final boolean spot = r.mode == Mode.SPOT;
        final LinearLayout c = card(resultBox, spot ? Mode.accent(Mode.SPOT) : Mode.accent(Mode.SCALP));
        c.addView(bold(spot ? "💎 Spot plan — 1 din se 2 mahine tak" : "⚡ Scalp — heavy buying / selling meter", 16, TEXT));
        final TextView wait = text("Sab exchanges se data aa raha hai...", 12, MUTED);
        c.addView(wait);
        final String sym = r.symbol;
        final double sellUsd = Prefs.spotSellUsd(this) * 1_000_000.0, minHeavy = Prefs.scalpHeavyUsd(this) * 1000.0;
        pool.execute(() -> {
            try {
                final HeavyFlow.Result hf = HeavyFlow.fetch(sym);
                final MarketFlow.Result mf = MarketFlow.fetch(r.base, hf);
                final SpotPlan.Plan sp = spot ? SpotPlan.build(sym, r.price, mf, sellUsd) : null;
                runOnUiThread(() -> {
                    if (lastReport != r) return;
                    c.removeView(wait);
                    // money flow, all exchanges
                    c.addView(bold("🌐 Paisa IN / OUT — " + mf.venues.size() + " exchanges", 14, ACC2));
                    String[] w = {"15 min", "1 ghanta", "4 ghante", "24 ghante"};
                    for (int k = 0; k < 4; k++) {
                        double n = mf.net[k];
                        c.addView(bold(String.format(Locale.US, "%s:  %s%s  %s", w[k], n >= 0 ? "+" : "−", Fmt.usd(Math.abs(n)), n >= 0 ? "🟢 IN" : "🔴 OUT"), 13, n >= 0 ? GREEN : RED));
                    }
                    StringBuilder vs = new StringBuilder();
                    for (MarketFlow.Venue v : mf.venues)
                        vs.append(v.buyPct >= 52 ? "🟢 " : v.buyPct <= 48 ? "🔴 " : "⚪ ").append(v.name).append(v.exact ? "" : "*")
                                .append(String.format(Locale.US, " %.0f%%", v.buyPct)).append("   ");
                    c.addView(text(vs.toString().trim(), 11, SOFT));
                    c.addView(text("* = taaza trades se andaza · baqi asal (Binance, OKX)", 10, MUTED));
                    c.addView(divider());
                    if (spot && sp != null) {
                        c.addView(bold(sp.ok ? "✅ Achhi spot entry ABHI — " + sp.horizon : "⏳ Abhi spot BUY nahi", 15, sp.ok ? GREEN : YELLOW));
                        c.addView(text(sp.why, 13, SOFT));
                        String[] hz = {"1–2 din", "1–2 hafte", "1–2 mahine"};
                        boolean[] ok = {sp.shortOk, sp.weekOk, sp.monthOk};
                        StringBuilder hb = new StringBuilder();
                        for (int k = 0; k < 3; k++) hb.append(ok[k] ? "✅ " : "❌ ").append(hz[k]).append("   ");
                        c.addView(bold(hb.toString().trim(), 13, TEXT));
                        c.addView(text("Entry zone: $" + Fmt.price(sp.zoneLo) + " – $" + Fmt.price(sp.zoneHi) + (sp.ok ? "" : "  ·  pullback level: $" + Fmt.price(sp.waitLevel)), 13, TEXT));
                        c.addView(text("🛑 Stop-loss: $" + Fmt.price(sp.sl) + pctFrom(sp.sl, r.price), 14, RED));
                        for (int k = 0; k < 4; k++)
                            c.addView(text("🎯 TP" + (k + 1) + " (" + sp.tpLbl[k] + "): $" + Fmt.price(sp.tp[k]) + pctFrom(sp.tp[k], r.price), 14, GREEN));
                        learnToggle(c, "Spot ke 4 targets waqt ke hisaab se hain: jitna lamba waqt, utna bara target (daily ATR × √din, aur raaste ki "
                                + "resistance se thora neeche). Har TP par 25% bech kar stop upar le aayen. Horizon bot khud chunta hai: weekly trend bhi upar ho "
                                + "to 1–2 mahine, daily upar ho to 1–2 hafte, sirf 4h upar ho to 1–2 din.\n\nChecks:\n" + String.join("\n", sp.checks));
                        if (sp.ok) {
                            chart.setPlan(true, true, r.price, sp.sl, sp.tp[0], sp.tp[1]);
                            chart.setMoreTargets(sp.tp[2], sp.tp[3], sp.tpLbl);
                            chart.setZone(sp.zoneLo, sp.zoneHi, "SPOT BUY ZONE", GREEN);
                            chart.setScenario(true, Position.NOW, true, r.price, 0, sp.tp[0], sp.tp[3]);
                        } else if (sp.waitLevel > 0 && sp.waitLevel < r.price) {
                            chart.setScenario(true, Position.RETEST, true, r.price, sp.waitLevel, sp.tp[0], sp.tp[2]);
                        }
                    } else {
                        double heavy = HeavyFlow.scalpThreshold(minHeavy, hf.gross[0]), enough = HeavyFlow.scalpEnough(hf, heavy);
                        double n15 = hf.net15();
                        c.addView(bold(String.format(Locale.US, "Binance 15 min: %s%s", n15 >= 0 ? "+" : "−", Fmt.usd(Math.abs(n15))), 15, n15 >= 0 ? GREEN : RED));
                        c.addView(text("Is coin ko hilane ke liye kaafi: " + Fmt.usd(enough) + " · Heavy (foran signal): " + Fmt.usd(heavy), 13, SOFT));
                        double pct = Math.min(100, Math.abs(n15) / Math.max(1, heavy) * 100);
                        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, dp(10));
                        bl.topMargin = dp(4);
                        c.addView(bar(pct, n15 >= 0 ? GREEN : RED, 0xFF243049), bl);
                        c.addView(bold(Math.abs(n15) >= heavy ? (n15 > 0 ? "⚡ HEAVY BUYING — scalp BUY zone" : "⚡ HEAVY SELLING — scalp SELL zone")
                                : Math.abs(n15) >= enough ? (n15 > 0 ? "🟢 Kaafi buying — price upar ja sakti hai" : "🔴 Kaafi selling — price neeche ja sakti hai")
                                : "⚪ Flow kam — abhi koi tez move ka ishara nahi", 14, Math.abs(n15) >= enough ? (n15 > 0 ? GREEN : RED) : MUTED));
                        c.addView(text(String.format(Locale.US, "Price impact: $1M net ≈ %.2f%% move · 5m ATR %.2f%% · 15 min price %+.2f%%",
                                hf.impactPerM, hf.atr5Pct, hf.move15Pct), 12, MUTED));
                        learnToggle(c, "Bot ne pichle 24 ghante se seekha ke is coin ki price kitne net paise se kitna hilti hai (price impact). "
                                + "Bare coin ko hilane ke liye bara volume chahiye, chhote coin ko kam. 'Kaafi' wala flow + candles saath hon to signal; "
                                + "'Heavy' flow par bot bina intezar foran FAST signal bhejta hai.");
                    }
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> wait.setText("Data nahi mila: " + m));
            }
        });
    }

    private void positionCard(final CoinReport r) {
        Position.Advice a = r.advice;
        if (a == null || r.atr <= 0) return;
        boolean spotSell = !r.isBuy && r.mode == Mode.SPOT;
        int col = a.buy ? GREEN : RED;
        LinearLayout c = card(resultBox, col);
        c.addView(bold("📍 Position — kahan aur kab " + (a.buy ? "BUY" : spotSell ? "SELL / EXIT" : "SELL"), 16, TEXT));
        TextView t = bold(a.title, 17, col);
        c.addView(t);
        c.addView(text(a.why, 13, SOFT));
        String kind = Position.NOW.equals(a.type) ? "Abhi entry — volume saath hai"
                : Position.RETEST.equals(a.type) ? "Retest ka intezar — chase na karein"
                : Position.BREAKOUT.equals(a.type) ? "Breakout/breakdown confirm hone ka intezar"
                : "Behtar qeemat ka intezar (zone mein limit order)";
        TextView k = bold("➡ " + kind, 13, YELLOW);
        k.setPadding(0, dp(6), 0, dp(4));
        c.addView(k);
        c.addView(text((a.buy ? "BUY" : "SELL") + " zone: $" + Fmt.price(a.zoneLo) + " – $" + Fmt.price(a.zoneHi)
                + "   (entry ~$" + Fmt.price(a.entry) + ")", 14, TEXT));
        c.addView(text("🛑 Stop-loss: $" + Fmt.price(a.sl) + pctFrom(a.sl, a.entry), 14, RED));
        c.addView(text("🎯 TP1: $" + Fmt.price(a.tp1) + pctFrom(a.tp1, a.entry) + "  ·  TP2: $" + Fmt.price(a.tp2) + pctFrom(a.tp2, a.entry), 14, GREEN));
        c.addView(bold((a.buy ? "📈 Coin yahan se yahan tak ja sakta hai: $" : "📉 Coin yahan tak gir sakta hai: $") + Fmt.price(Math.min(a.tp1, a.tp2))
                + " – $" + Fmt.price(Math.max(a.tp1, a.tp2)), 14, a.buy ? GREEN : RED));
        String steps = Position.NOW.equals(a.type) ? "1️⃣ Abhi zone mein " + (a.buy ? "BUY" : "SELL") + " → 2️⃣ SL lagayen → 3️⃣ TP1 par aadha profit, stop entry par → 4️⃣ TP2"
                : Position.BREAKOUT.equals(a.type) ? "1️⃣ Abhi intezar → 2️⃣ $" + Fmt.price(a.buy ? a.zoneLo : a.zoneHi) + (a.buy ? " ke UPAR" : " ke NEECHE")
                + " candle close + volume → 3️⃣ " + (a.buy ? "BUY" : "SELL") + " → 4️⃣ TP1 / TP2"
                : "1️⃣ Abhi chase na karein → 2️⃣ Price $" + Fmt.price(a.zoneLo) + " – $" + Fmt.price(a.zoneHi) + " tak aaye (retest) → 3️⃣ wahan "
                + (a.buy ? "BUY" : "SELL") + " (limit order) → 4️⃣ TP1 / TP2";
        c.addView(text(steps, 13, YELLOW));
        c.addView(text("👆 Yeh poora raasta chart par bana hai: peeli line = intezar wali qeemat, teer = mumkina raasta, rangeen dabba = target range.", 12, MUTED));
        TextView bin = chip("🟡 Binance app mein kholen", true);
        bin.setBackground(round(0xFFF0B90B, 20, 0));
        bin.setOnClickListener(v -> BinanceLink.open(this, r.base, r.mode == Mode.SCALP && !r.isBuy));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = dp(8);
        c.addView(bin, lp);
    }

    private void flowCard(CoinReport r) {
        FlowWindows.Result f = r.flows;
        if (f == null || f.venues.isEmpty()) return;
        LinearLayout c = card(resultBox, ACC2);
        c.addView(bold("⏱️ Volume IN vs OUT — 1 · 5 · 15 minute", 16, TEXT));
        c.addView(text(f.venues.size() + " exchanges: " + String.join(", ", f.venues), 11, MUTED));
        String[] lbl = {"1 min", "5 min", "15 min"};
        for (int k = 0; k < 3; k++) {
            double net = f.net(k);
            LinearLayout rr = row();
            rr.setPadding(0, dp(6), 0, 0);
            rr.addView(bold(lbl[k], 13, TEXT), new LinearLayout.LayoutParams(dp(56), -2));
            rr.addView(text("IN " + Fmt.usd(f.in[k]), 12, GREEN), new LinearLayout.LayoutParams(0, -2, 1));
            rr.addView(text("OUT " + Fmt.usd(f.out[k]), 12, RED), new LinearLayout.LayoutParams(0, -2, 1));
            rr.addView(bold((net >= 0 ? "+" : "") + Fmt.usd(net), 13, net >= 0 ? GREEN : RED));
            c.addView(rr);
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, dp(8));
            bl.topMargin = dp(2);
            c.addView(bar(f.buyPct(k), GREEN, RED), bl);
        }
        double b5 = f.buyPct(1);
        c.addView(bold(b5 >= 55 ? "💰 Volume AA raha hai — upar ja sakta hai" : b5 <= 45 ? "🚨 Volume NIKAL raha hai — neeche ja sakta hai"
                : "⚖️ Barabar — abhi faisla nahi", 14, b5 >= 55 ? GREEN : b5 <= 45 ? RED : YELLOW));
        if (!f.partial.isEmpty()) c.addView(text("Note: " + String.join(", ", f.partial) + " ki taaza trades sirf chhote window cover karti hain.", 11, MUTED));
    }

    // ============================================================ PORTFOLIO (watch-only wallets)
    private LinearLayout walAddCard;

    private void buildWallet() {
        LinearLayout col = pageColumn(TAB_WALLET);

        LinearLayout tot = card(col, ACC);
        LinearLayout tr = row();
        tr.addView(text("TOTAL BALANCE", 11, MUTED), new LinearLayout.LayoutParams(0, -2, 1));
        TextView rf = chip("↻ Refresh", false);
        rf.setOnClickListener(v -> loadWallets());
        tr.addView(rf);
        tot.addView(tr);
        walletTotal = bold("$0", 30, TEXT);
        tot.addView(walletTotal);
        walletNet = text("", 12, MUTED);
        tot.addView(walletNet);
        Button addBtn = button("➕ Add new wallet", ACC, INK, 0);
        addBtn.setOnClickListener(v -> {
            boolean show = walAddCard.getVisibility() != View.VISIBLE;
            walAddCard.setVisibility(show ? View.VISIBLE : View.GONE);
        });
        tot.addView(addBtn);

        walAddCard = card(col, ACC2);
        walAddCard.addView(bold("➕ New wallet", 16, TEXT));
        walLabelEt = input("Wallet name (e.g. Trust Wallet BTC)", "", InputType.TYPE_CLASS_TEXT);
        walAddCard.addView(walLabelEt);
        walAddrEt = input("Paste PUBLIC address", "", InputType.TYPE_CLASS_TEXT);
        walAddCard.addView(walAddrEt);
        final TextView det = text("Supported: Bitcoin · Ethereum (+ ERC20) · BNB Chain (BNB, USDT) · TRON (TRX, USDT TRC20) · Solana · Litecoin · Dogecoin", 11, MUTED);
        walAddCard.addView(det);
        walAddrEt.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence q, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence q, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) {
                String t = e.toString().trim();
                String bad = WalletTracker.securityCheck(t);
                if (bad != null) { det.setText(bad); det.setTextColor(RED); return; }
                String ch = t.isEmpty() ? null : WalletTracker.detect(t);
                det.setText(ch == null ? (t.isEmpty() ? "" : "Address not recognised") : "✅ Network: " + WalletTracker.chainName(ch));
                det.setTextColor(ch == null ? MUTED : GREEN);
            }
        });
        Button b = button("Save wallet", ACC, INK, 0);
        b.setOnClickListener(v -> addWallet());
        walAddCard.addView(b);
        walAddCard.addView(text("🔒 Watch-only: sirf PUBLIC address. Seed phrase / private key kabhi na daalein — app inhein khud rok deti hai. "
                + "Trust Wallet: coin → Receive → Copy address.", 11, MUTED));
        walAddCard.setVisibility(Prefs.wallets(this).length() == 0 ? View.VISIBLE : View.GONE);

        TextView mh = bold("MY WALLETS", 11, MUTED);
        mh.setLetterSpacing(0.12f);
        mh.setPadding(dp(4), dp(16), 0, 0);
        col.addView(mh);
        walletList = column();
        col.addView(walletList);

        TextView ih = bold("INSTITUTIONAL WALLETS (PUBLIC)", 11, MUTED);
        ih.setLetterSpacing(0.12f);
        ih.setPadding(dp(4), dp(18), 0, 0);
        col.addView(ih);
        LinearLayout inst = card(col);
        inst.addView(text("Publicly labelled addresses (mempool.space / Arkham / The Block). Tap View for live holdings.", 11, MUTED));
        for (final String[] k : BigPlayers.KNOWN) {
            LinearLayout r = row();
            r.setPadding(0, dp(8), 0, dp(8));
            LinearLayout t = column();
            t.addView(bold(k[0], 14, TEXT));
            String ch = WalletTracker.detect(k[1]);
            t.addView(text((ch == null ? "" : WalletTracker.chainName(ch) + " · ") + WalletTracker.shortAddr(k[1]), 11, MUTED));
            r.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
            TextView vw = chip("👁 View", false);
            vw.setOnClickListener(v -> openWalletDetail(k[0], k[1]));
            r.addView(vw);
            inst.addView(r);
            inst.addView(divider());
        }
    }

    private void addWallet() {
        String a = walAddrEt.getText().toString().trim();
        String bad = WalletTracker.securityCheck(a);
        if (bad != null) {
            walAddrEt.setText("");
            toast("⛔ Secret data! Mita diya gaya. Sirf public address daalein.");
            return;
        }
        String ch = WalletTracker.detect(a);
        if (ch == null) { toast("Valid public address daalein"); return; }
        JSONArray ws = Prefs.wallets(this);
        for (int i = 0; i < ws.length(); i++) {
            JSONObject o = ws.optJSONObject(i);
            if (o != null && a.equalsIgnoreCase(o.optString("addr"))) { toast("Yeh wallet pehle se list mein hai"); return; }
        }
        try {
            JSONObject o = new JSONObject();
            String lbl = walLabelEt.getText().toString().trim();
            o.put("label", lbl.isEmpty() ? WalletTracker.chainName(ch) + " " + WalletTracker.shortAddr(a) : lbl);
            o.put("addr", a);
            o.put("chain", ch);
            ws.put(o);
            Prefs.saveWallets(this, ws);
        } catch (Exception ignored) {
        }
        walAddrEt.setText("");
        walLabelEt.setText("");
        walAddCard.setVisibility(View.GONE);
        hideKeyboard();
        toast("Wallet added ✅");
        loadWallets();
    }

    private void loadWallets() {
        walletsLoadedAt = System.currentTimeMillis();
        renderWalletList(null);
        if (Prefs.wallets(this).length() == 0) return;
        walletNet.setText("Blockchain se balances aa rahe hain...");
        pool.execute(() -> {
            final List<WalletTracker.Result> rs = WalletWatch.check(this);
            runOnUiThread(() -> renderWalletList(rs));
        });
    }

    /** Compact list: name · network · balance with View / Edit / Delete. rs = null shows saved balances. */
    private void renderWalletList(List<WalletTracker.Result> rs) {
        walletList.removeAllViews();
        JSONArray ws = Prefs.wallets(this);
        if (ws.length() == 0) {
            walletTotal.setText("$0");
            walletNet.setText("Abhi koi wallet nahi — '➕ Add new wallet' dabayen");
            LinearLayout c = card(walletList);
            c.addView(text("Koi wallet add nahi hua. Jitne chahein wallets add kar sakte hain — BTC, ETH, USDT (TRC20/BEP20), SOL...", 13, MUTED));
            return;
        }
        double total = 0;
        for (int i = 0; i < ws.length(); i++) {
            final JSONObject w = ws.optJSONObject(i);
            if (w == null) continue;
            final int idx = i;
            WalletTracker.Result r = rs != null && i < rs.size() ? rs.get(i) : null;
            double usd = r != null ? r.totalUsd : w.optDouble("usd", 0);
            total += usd;
            final String addr = w.optString("addr"), label = w.optString("label");
            String ch = WalletTracker.detect(addr);
            LinearLayout c = card(walletList, r != null && r.error != null && r.holdings.isEmpty() ? YELLOW : STROKE);
            LinearLayout hr = row();
            TextView ic = bold(ch == null ? "?" : ch.equals(WalletTracker.EVM) ? "Ξ" : ch.equals(WalletTracker.BTC) ? "₿" : ch.substring(0, 1), 18, INK);
            ic.setGravity(Gravity.CENTER);
            ic.setBackground(round(ACC, 20, 0));
            hr.addView(ic, new LinearLayout.LayoutParams(dp(40), dp(40)));
            LinearLayout ht = column();
            ht.setPadding(dp(12), 0, 0, 0);
            ht.addView(bold(label, 15, TEXT));
            ht.addView(text((ch == null ? "?" : WalletTracker.chainName(ch)) + " · " + WalletTracker.shortAddr(addr), 11, MUTED));
            hr.addView(ht, new LinearLayout.LayoutParams(0, -2, 1));
            hr.addView(bold(Fmt.usd(usd), 16, GREEN));
            c.addView(hr);
            if (r != null && !r.holdings.isEmpty()) {
                StringBuilder sb = new StringBuilder();
                for (int k = 0; k < r.holdings.size() && k < 4; k++) {
                    if (sb.length() > 0) sb.append(" · ");
                    sb.append(r.holdings.get(k).asset);
                }
                if (r.holdings.size() > 4) sb.append(" +").append(r.holdings.size() - 4);
                c.addView(text(sb.toString(), 12, SOFT));
            } else if (r != null && r.error != null) {
                c.addView(text("⚠️ " + r.error + " — thori der baad Refresh", 11, YELLOW));
            }
            final LinearLayout edit = column();
            edit.setVisibility(View.GONE);
            c.addView(edit);
            LinearLayout br = row();
            TextView vw = chip("👁 View", true);
            vw.setOnClickListener(v -> openWalletDetail(label, addr));
            br.addView(vw, chipLp());
            TextView ed = chip("✏ Edit", false);
            ed.setOnClickListener(v -> toggleWalletEdit(edit, idx, w));
            br.addView(ed, chipLp());
            final TextView del = chip("🗑 Delete", false);
            final long[] armed = {0};
            del.setOnClickListener(v -> {
                long now = System.currentTimeMillis();
                if (now - armed[0] < 3000) {
                    JSONArray cur = Prefs.wallets(this), out = new JSONArray();
                    for (int k = 0; k < cur.length(); k++) if (k != idx) out.put(cur.opt(k));
                    Prefs.saveWallets(this, out);
                    toast("Wallet removed");
                    loadWallets();
                } else {
                    armed[0] = now;
                    del.setText("Confirm?");
                }
            });
            br.addView(del, chipLp());
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-2, -2);
            bl.topMargin = dp(8);
            c.addView(hscroll(br), bl);
        }
        walletTotal.setText(Fmt.usd(total));
        walletNet.setText(ws.length() + " wallets · " + (rs == null ? "saved balances" : "updated " + new SimpleDateFormat("HH:mm", Locale.US).format(new Date()))
                + " · alerts jab paisa aaye/jaye");
    }

    private void toggleWalletEdit(final LinearLayout edit, final int idx, final JSONObject w) {
        if (edit.getVisibility() == View.VISIBLE) {
            edit.setVisibility(View.GONE);
            return;
        }
        edit.removeAllViews();
        edit.setVisibility(View.VISIBLE);
        edit.addView(divider());
        final EditText l = input("Wallet name", w.optString("label"), InputType.TYPE_CLASS_TEXT);
        final EditText a = input("Public address", w.optString("addr"), InputType.TYPE_CLASS_TEXT);
        edit.addView(text("Name", 11, MUTED));
        edit.addView(l);
        edit.addView(text("Address", 11, MUTED));
        edit.addView(a);
        LinearLayout r = row();
        TextView save = chip("💾 Save", true);
        save.setOnClickListener(v -> {
            String na = a.getText().toString().trim();
            if (WalletTracker.securityCheck(na) != null) { a.setText(""); toast("⛔ Secret data! Sirf public address."); return; }
            String ch = WalletTracker.detect(na);
            if (ch == null) { toast("Valid public address daalein"); return; }
            try {
                JSONArray cur = Prefs.wallets(this);
                JSONObject o = cur.getJSONObject(idx);
                if (!na.equalsIgnoreCase(o.optString("addr"))) {
                    o.put("addr", na);
                    o.put("chain", ch);
                    o.remove("snap");
                    o.put("usd", 0);
                }
                String nl = l.getText().toString().trim();
                o.put("label", nl.isEmpty() ? WalletTracker.chainName(ch) + " " + WalletTracker.shortAddr(na) : nl);
                Prefs.saveWallets(this, cur);
            } catch (Exception ignored) {
            }
            hideKeyboard();
            toast("Saved ✅");
            loadWallets();
        });
        TextView cancel = chip("Cancel", false);
        cancel.setOnClickListener(v -> edit.setVisibility(View.GONE));
        r.addView(save, chipLp());
        r.addView(cancel, chipLp());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = dp(6);
        edit.addView(r, lp);
    }

    /** Full page with everything inside one wallet. */
    private void openWalletDetail(final String label, final String addr) {
        final LinearLayout c = openPage(label);
        final TextView tot = bold("…", 30, TEXT);
        String ch = WalletTracker.detect(addr);
        LinearLayout h = card(c, ACC);
        h.addView(text("TOTAL VALUE", 11, MUTED));
        h.addView(tot);
        h.addView(text((ch == null ? "" : WalletTracker.chainName(ch)) + "\n" + addr, 11, SOFT));
        LinearLayout br = row();
        TextView cp = chip("📋 Copy address", false);
        cp.setOnClickListener(v -> {
            try {
                android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(android.content.ClipData.newPlainText("address", addr));
                toast("Address copied");
            } catch (Exception ignored) {
            }
        });
        br.addView(cp, chipLp());
        final TextView ex = chip("🔗 Explorer", false);
        br.addView(ex, chipLp());
        TextView rf = chip("↻ Refresh", false);
        rf.setOnClickListener(v -> openWalletDetail(label, addr));
        br.addView(rf, chipLp());
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-2, -2);
        bl.topMargin = dp(8);
        h.addView(hscroll(br), bl);
        final LinearLayout body = column();
        c.addView(body);
        body.addView(text("⏳ Blockchain se data aa raha hai...", 13, MUTED));
        pool.execute(() -> {
            final WalletTracker.Result r = WalletTracker.fetch(addr);
            runOnUiThread(() -> {
                body.removeAllViews();
                tot.setText(Fmt.usd(r.totalUsd));
                if (r.explorer != null) ex.setOnClickListener(v -> openUrl(r.explorer));
                LinearLayout hc = card(body);
                hc.addView(bold("Assets (" + r.holdings.size() + ")", 16, TEXT));
                if (r.holdings.isEmpty()) hc.addView(text(r.error != null ? "⚠️ " + r.error : "Is wallet mein balance 0 hai", 13, r.error != null ? YELLOW : MUTED));
                List<WalletTracker.Holding> hs = new ArrayList<>(r.holdings);
                Collections.sort(hs, (a, b) -> Double.compare(b.usd, a.usd));
                for (WalletTracker.Holding x : hs) {
                    LinearLayout rr = row();
                    rr.setPadding(0, dp(8), 0, dp(4));
                    LinearLayout l = column();
                    l.addView(bold(x.asset, 15, TEXT));
                    l.addView(text(x.network, 11, MUTED));
                    rr.addView(l, new LinearLayout.LayoutParams(0, -2, 1));
                    LinearLayout rt = column();
                    String amt = x.amount >= 1000 ? Fmt.num(x.amount) : String.format(Locale.US, x.amount >= 1 ? "%.4f" : "%.8f", x.amount);
                    rt.addView(bold(Fmt.usd(x.usd), 14, TEXT));
                    rt.addView(text(amt + " " + x.asset, 11, SOFT));
                    rr.addView(rt);
                    hc.addView(rr);
                    double pct = r.totalUsd > 0 ? x.usd / r.totalUsd * 100 : 0;
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(5));
                    lp.bottomMargin = dp(4);
                    hc.addView(bar(pct, ACC, 0xFF243049), lp);
                }
                if (!r.txs.isEmpty()) {
                    LinearLayout tc = card(body);
                    tc.addView(bold("Recent activity", 16, TEXT));
                    for (String t : r.txs) {
                        TextView tv = text(t, 12, t.contains("🟢") ? GREEN : t.contains("🔴") ? RED : SOFT);
                        tv.setPadding(0, dp(4), 0, dp(4));
                        tc.addView(tv);
                    }
                }
                body.addView(text("🔒 Watch-only — yeh app is wallet se kuch bhej ya sign nahi kar sakti.", 11, MUTED));
            });
        });
    }

    // ============================================================ BIG PLAYERS tab
    private void buildBig() {
        LinearLayout col = pageColumn(TAB_BIG);
        LinearLayout h = card(col, ACC);
        LinearLayout hr = row();
        hr.addView(bold("🏛 Institutional Flow Tracker", 17, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView rf = chip("↻ Refresh", false);
        rf.setOnClickListener(v -> loadBig());
        hr.addView(rf);
        h.addView(hr);
        h.addView(text("Spot ETFs (BlackRock, Fidelity, Grayscale) · corporate treasuries (Strategy, Trump Media) · sovereign holdings · "
                + "exchange & custody wallets (Binance, Robinhood, Tether, WLFI). Accumulation ya distribution par alert.", 12, MUTED));
        toggle(h, "🔔 Buy / sell alerts", null, Prefs.notifOn(this, Prefs.N_BIG), (b, on) -> Prefs.setNotif(this, Prefs.N_BIG, on));
        h.addView(text("Minimum transaction size for alerts:", 12, SOFT));
        LinearLayout mr = row();
        String[] ml = {"$10M", "$50M", "$100M", "$500M", "$1B"};
        for (int i = 0; i < 5; i++) {
            final int idx = i;
            bigMinChips[i] = chip(ml[i], Prefs.bigMinUsd(this) == BIG_MINS[i]);
            bigMinChips[i].setOnClickListener(v -> {
                Prefs.setBigMinUsd(this, BIG_MINS[idx]);
                for (int k = 0; k < 5; k++) styleChip(bigMinChips[k], k == idx);
            });
            mr.addView(bigMinChips[i], chipLp());
        }
        h.addView(hscroll(mr));
        bigStatus = text("", 12, SOFT);
        h.addView(bigStatus);

        LinearLayout mv = card(col, ACC2);
        mv.addView(bold("⚡ Recent institutional activity", 16, TEXT));
        bigMovesBox = column();
        mv.addView(bigMovesBox);

        bigBox = column();
        col.addView(bigBox);

        LinearLayout add = card(col);
        add.addView(bold("➕ Track a custom wallet", 15, TEXT));
        add.addView(text("Arkham / Etherscan se kisi whale, fund ya company ka public address le kar yahan daalein.", 12, MUTED));
        final EditText lbl = input("Naam (jaise: Whale #1)", "", InputType.TYPE_CLASS_TEXT);
        final EditText adr = input("Public address", "", InputType.TYPE_CLASS_TEXT);
        add.addView(lbl);
        add.addView(adr);
        Button ab = button("➕ Track karein", ACC, INK, 0);
        ab.setOnClickListener(v -> {
            String a = adr.getText().toString().trim();
            if (WalletTracker.securityCheck(a) != null || WalletTracker.detect(a) == null) { toast("Sahi public address daalein"); return; }
            try {
                JSONArray arr = Prefs.bigWallets(this);
                JSONObject o = new JSONObject();
                o.put("label", lbl.getText().toString().trim().isEmpty() ? WalletTracker.shortAddr(a) : lbl.getText().toString().trim());
                o.put("addr", a);
                arr.put(o);
                Prefs.saveBigWallets(this, arr);
            } catch (Exception ignored) {
            }
            adr.setText("");
            lbl.setText("");
            toast("Track ho raha hai ✅");
            loadBig();
        });
        add.addView(ab);
        TextView ark = chip("🔎 Arkham par bade wallets dhoondein", false);
        ark.setOnClickListener(v -> openUrl("https://intel.arkm.com/"));
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(-2, -2);
        al.topMargin = dp(6);
        add.addView(ark, al);
    }

    private void renderBigMoves() {
        bigMovesBox.removeAllViews();
        JSONArray a = Prefs.bigMoves(this);
        if (a.length() == 0) {
            bigMovesBox.addView(text("Abhi koi harkat record nahi hui. Pehli dafa data save hota hai — agli dafa se jo bhi khareede/beche woh yahan aur notification mein aayega.", 12, MUTED));
            return;
        }
        SimpleDateFormat f = new SimpleDateFormat("dd MMM HH:mm", Locale.US);
        for (int i = 0; i < a.length() && i < 25; i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            boolean buy = o.optBoolean("buy");
            bigMovesBox.addView(text((buy ? "🟢 " : "🔴 ") + o.optString("text"), 13, buy ? GREEN : RED));
            bigMovesBox.addView(text(f.format(new Date(o.optLong("t"))), 10, MUTED));
        }
    }

    private void loadBig() {
        bigLoadedAt = System.currentTimeMillis();
        bigStatus.setText("ETF, companies, governments aur wallets ka data aa raha hai...");
        pool.execute(() -> {
            final BigPlayers.Report r = BigPlayers.fetch(this, true);
            runOnUiThread(() -> renderBig(r));
        });
    }

    private String mUsd(double millions) {
        return BigPlayers.m(millions);
    }

    private void etfCard(String title, String date, double total, double day, List<BigPlayers.Row> rows) {
        if (rows.isEmpty()) return;
        LinearLayout c = card(bigBox, day >= 0 ? GREEN : RED);
        c.addView(bold(title, 16, TEXT));
        c.addView(text("Taaza din: " + date + " · sab ka total: " + mUsd(day)
                + (Double.isNaN(total) ? "" : " · launch se ab tak: " + mUsd(total)), 12, SOFT));
        LinearLayout hd = row();
        hd.addView(text("Fund", 11, MUTED), new LinearLayout.LayoutParams(0, -2, 1));
        hd.addView(text("Taaza din", 11, MUTED), new LinearLayout.LayoutParams(dp(90), -2));
        hd.addView(text("Launch se", 11, MUTED), new LinearLayout.LayoutParams(dp(90), -2));
        c.addView(hd);
        for (BigPlayers.Row r : rows) {
            LinearLayout rr = row();
            rr.setPadding(0, dp(4), 0, dp(4));
            LinearLayout nm = column();
            nm.addView(bold(r.name, 13, r.name.equals("BlackRock") ? 0xFFF0B90B : TEXT));
            nm.addView(text(r.sub, 10, MUTED));
            rr.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
            rr.addView(bold(r.change == 0 ? "—" : mUsd(r.change), 12, r.change > 0 ? GREEN : r.change < 0 ? RED : MUTED), new LinearLayout.LayoutParams(dp(90), -2));
            rr.addView(text(Double.isNaN(r.value) ? "—" : mUsd(r.value), 12, r.value >= 0 ? SOFT : RED), new LinearLayout.LayoutParams(dp(90), -2));
            c.addView(rr);
        }
    }

    private void holdersCard(String title, String sym, double total, List<BigPlayers.Row> rows, int max) {
        if (rows.isEmpty()) return;
        LinearLayout c = card(bigBox);
        c.addView(bold(title, 16, TEXT));
        c.addView(text("Kul: " + Fmt.num(total) + " " + sym + " · (+/−) = pichhli check se farq", 12, SOFT));
        for (int i = 0; i < rows.size() && i < max; i++) {
            BigPlayers.Row r = rows.get(i);
            LinearLayout rr = row();
            rr.setPadding(0, dp(4), 0, dp(4));
            LinearLayout nm = column();
            nm.addView(bold(r.name, 13, r.name.toLowerCase(Locale.US).contains("trump") ? 0xFFF0B90B : TEXT));
            nm.addView(text(r.sub, 10, MUTED));
            rr.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
            LinearLayout v = column();
            v.addView(text(Fmt.num(r.value) + " " + sym, 12, TEXT));
            v.addView(text(Fmt.usd(r.usd) + (r.change != 0 ? (r.change > 0 ? "  🟢 +" : "  🔴 −") + Fmt.num(Math.abs(r.change)) : ""), 10,
                    r.change > 0 ? GREEN : r.change < 0 ? RED : MUTED));
            rr.addView(v);
            c.addView(rr);
        }
    }

    private void renderBig(BigPlayers.Report r) {
        bigBox.removeAllViews();
        bigStatus.setText("Update: " + new SimpleDateFormat("HH:mm", Locale.US).format(new Date())
                + (r.events.isEmpty() ? " · koi nayi bari harkat nahi" : " · " + r.events.size() + " nayi harkat!"));
        renderBigMoves();
        etfCard("🏦 Spot Bitcoin ETFs — net flows", r.etfBtcDate, r.etfBtcTotal, r.etfBtcDay, r.etfBtc);
        etfCard("🏦 Spot Ethereum ETFs — net flows", r.etfEthDate, r.etfEthTotal, r.etfEthDay, r.etfEth);
        etfCard("🏦 Spot Solana ETFs — net flows", r.etfSolDate, r.etfSolTotal, r.etfSolDay, r.etfSol);
        holdersCard("🏢 Corporate treasuries — BTC", "BTC", r.coBtcTotal, r.coBtc, 20);
        holdersCard("🏢 Corporate treasuries — ETH", "ETH", r.coEthTotal, r.coEth, 12);
        holdersCard("🏛️ Sovereign (government) holdings — BTC", "BTC", r.govTotal, r.gov, 12);
        if (!r.wallets.isEmpty()) {
            LinearLayout c = card(bigBox, ACC2);
            c.addView(bold("🐋 Exchange & custody wallets (on-chain)", 16, TEXT));
            for (BigPlayers.Row w : r.wallets) {
                LinearLayout rr = row();
                rr.setPadding(0, dp(4), 0, dp(4));
                LinearLayout nm = column();
                nm.addView(bold(w.name, 13, TEXT));
                nm.addView(text(w.sub, 10, MUTED));
                rr.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
                LinearLayout v = column();
                v.addView(text(Fmt.usd(w.usd), 13, TEXT));
                if (w.change != 0) v.addView(text((w.change > 0 ? "🟢 +" : "🔴 −") + Fmt.usd(Math.abs(w.change)), 10, w.change > 0 ? GREEN : RED));
                rr.addView(v);
                c.addView(rr);
            }
        }
        if (bigBox.getChildCount() == 0) {
            LinearLayout c = card(bigBox, RED);
            c.addView(text("Data nahi mila — internet check karke Refresh dabayen (CoinGecko kabhi busy hota hai).", 13, YELLOW));
        }
    }

    // ============================================================ ECONOMIC CALENDAR (macro)
    private void setNewsSeg(boolean macro) {
        showMacro = macro;
        styleChip(newsSeg[0], macro);
        styleChip(newsSeg[1], !macro);
        macroCol.setVisibility(macro ? View.VISIBLE : View.GONE);
        listCol.setVisibility(macro ? View.GONE : View.VISIBLE);
        if (macro && System.currentTimeMillis() - macroLoadedAt > 5 * 60_000L) loadMacro(false);
        if (!macro && System.currentTimeMillis() - listingsLoadedAt > 10 * 60_000L) loadListings();
    }

    private void updateMacroLine(List<MacroEngine.Event> evs) {
        if (macroLine == null) return;
        long now = System.currentTimeMillis();
        for (MacroEngine.Event e : evs) {
            if (!"High".equals(e.impact) || e.time < now - 30 * 60_000L) continue;
            long dt = e.time - now;
            macroLine.setText((dt <= 0 ? "📢 Abhi release: " : "📅 Agla bada US event: ") + e.title + (dt > 0 ? " · " + MacroEngine.mins(dt) + " baad" : "")
                    + "  (tap = detail)");
            macroLine.setTextColor(dt < 2 * 3600_000L ? RED : YELLOW);
            return;
        }
        macroLine.setText("📅 Is hafte koi bada US event baqi nahi (tap = calendar)");
        macroLine.setTextColor(MUTED);
    }

    private void buildMacro(LinearLayout col) {
        LinearLayout h = card(col, ACC);
        LinearLayout hr = row();
        hr.addView(bold("🏦 US Macro — market kya karegi?", 17, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView rf = chip("↻", false);
        rf.setOnClickListener(v -> loadMacro(true));
        hr.addView(rf);
        h.addView(hr);
        h.addView(text("Fed, mehngai (CPI/PCE), jobs (NFP) jaisi US khabrein crypto ko sab se zyada hilati hain. Yahan har event ka "
                + "waqt (aap ke time zone mein), forecast, pichli figure, asal figure aur crypto par asar milta hai.", 12, MUTED));
        pulseBox = column();
        h.addView(pulseBox);

        LinearLayout nt = card(col, YELLOW);
        nt.addView(bold("🔔 News alerts", 15, TEXT));
        toggle(nt, "Economic news notifications", "Pehle reminder · release ke baad asal figure + BUY/SELL asar · BTC ka reaction",
                Prefs.notifOn(this, Prefs.N_MACRO), (b, on) -> Prefs.setNotif(this, Prefs.N_MACRO, on));
        toggle(nt, "🛑 Bade news ke waqt signals roko (±30 min)", "Is waqt nakli moves aur stop-hunt zyada hote hain",
                Prefs.newsPause(this), (b, on) -> Prefs.setNewsPause(this, on));
        toggle(nt, "🟠 Medium events bhi (claims, ISM, sentiment...)", null, Prefs.macroMedium(this), (b, on) -> Prefs.setMacroMedium(this, on));
        nt.addView(text("Kitna pehle batayen:", 12, SOFT));
        LinearLayout lr = row();
        final int[] leads = {15, 30, 60, 120, 240};
        final TextView[] lc = new TextView[leads.length];
        for (int i = 0; i < leads.length; i++) {
            final int idx = i;
            lc[i] = chip(leads[i] >= 60 ? (leads[i] / 60) + " ghanta" : leads[i] + " min", Prefs.macroLeadMin(this) == leads[i]);
            lc[i].setOnClickListener(v -> {
                Prefs.setMacroLeadMin(this, leads[idx]);
                for (int k = 0; k < leads.length; k++) styleChip(lc[k], k == idx);
            });
            lr.addView(lc[i], chipLp());
        }
        nt.addView(hscroll(lr));

        LinearLayout fr = row();
        fr.setPadding(0, dp(10), 0, 0);
        final TextView hi = chip("🔴 Sirf bade events", macroHighOnly), all = chip("🔴🟠 Sab events", !macroHighOnly);
        hi.setOnClickListener(v -> { macroHighOnly = true; styleChip(hi, true); styleChip(all, false); loadMacro(false); });
        all.setOnClickListener(v -> { macroHighOnly = false; styleChip(hi, false); styleChip(all, true); loadMacro(false); });
        fr.addView(hi, chipLp());
        fr.addView(all, chipLp());
        col.addView(fr);
        macroBox = column();
        col.addView(macroBox);

        // knowledge table (what each release means)
        LinearLayout kn = section(col, "📘 Kaun sa data kya batata hai?", "Tap karke parhen", ACC2, false);
        String[][] k = {
                {"Fed Chair ki speech", "Agay rate cut hoga ya hike?", "Hawkish = pressure 🔴 · dovish = support 🟢"},
                {"FOMC rate decision", "Fed rates ka asal faisla", "Cut = 🟢 · hike = 🔴 · hold = speech par depend"},
                {"CPI inflation", "Mehngai kitni hai?", "Inflation kam = positive 🟢 · zyada = 🔴"},
                {"PCE / Core PCE", "Fed ka pasandeeda inflation measure", "Kam inflation = rate cuts ki umeed 🟢"},
                {"NFP / Jobs Report", "US mein kitni jobs add hui?", "Bohat strong jobs = inflation/rates ka risk 🔴"},
                {"Unemployment Rate", "Jobs market mazboot ya kamzor?", "Context ke mutabiq mixed reaction"},
                {"GDP", "US economy kitni grow kar rahi?", "Growth aur inflation dono dekhne hote hain"},
                {"FOMC Minutes", "Fed members ki andarooni discussion", "Future policy ka signal mil sakta hai"},
                {"Retail Sales", "Consumers kitna kharch kar rahe?", "Strong spending = rates high rehne ka risk 🔴"},
                {"PPI", "Factory / producer mehngai", "Zyada = aage CPI barhne ka dar 🔴"},
                {"Jobless Claims", "Har hafte berozgari claims", "Zyada claims = cut ki umeed 🟢"},
                {"JOLTS", "Khaali jobs kitni hain", "Zyada = jobs garam = rates risk 🔴"},
                {"ISM PMI", "Factories / services ki sehat (50 line)", "Mixed — growth vs mehngai"},
                {"Consumer sentiment", "Log kitne pur-umeed hain", "Zyada = risk-on 🟢"},
                {"US 10Y yield / Dollar (DXY)", "Paisa kitna mehnga / dollar kitna mazboot", "Neeche = crypto 🟢 · upar = 🔴"}};
        for (String[] r : k) {
            kn.addView(bold(r[0], 14, TEXT));
            kn.addView(text(r[1] + "\n➡ " + r[2], 12, SOFT));
            kn.addView(divider());
        }
    }

    private void loadMacro(final boolean force) {
        macroLoadedAt = System.currentTimeMillis();
        macroBox.removeAllViews();
        macroBox.addView(text("⏳ Calendar aur Fed data load ho raha hai...", 12, MUTED));
        pool.execute(() -> {
            final List<MacroEngine.Event> evs = MacroEngine.calendar(this, force);
            final MacroEngine.Pulse p = MacroEngine.pulse(force);
            // live BTC reaction for released high events (shown in the list)
            long now = System.currentTimeMillis();
            for (MacroEngine.Event e : evs) {
                if (Double.isNaN(e.reaction) && e.time < now - 5 * 60_000L && e.time > now - 3 * 86_400_000L && "High".equals(e.impact))
                    e.reaction = MacroEngine.btcReaction(e.time);
            }
            runOnUiThread(() -> renderMacro(evs, p));
        });
    }

    private void renderMacro(List<MacroEngine.Event> evs, MacroEngine.Pulse p) {
        updateMacroLine(evs);
        pulseBox.removeAllViews();
        pulseBox.addView(bold(p.mood, 16, p.score >= 20 ? GREEN : p.score <= -20 ? RED : YELLOW));
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, dp(8));
        bl.topMargin = dp(4);
        bl.bottomMargin = dp(4);
        pulseBox.addView(bar((p.score + 100) / 2.0, GREEN, RED), bl);
        for (String l : p.lines) pulseBox.addView(text("• " + l, 12, SOFT));
        if (!p.speeches.isEmpty()) {
            pulseBox.addView(text("🎤 Fed ki taaza taqreerein (official):", 12, MUTED));
            for (int i = 0; i < p.speeches.size() && i < 3; i++) {
                final String[] sp = p.speeches.get(i);
                TextView t = text("   " + sp[0], 12, CYAN_TXT);
                t.setOnClickListener(v -> openUrl(sp[1]));
                pulseBox.addView(t);
            }
        }

        macroBox.removeAllViews();
        if (evs.isEmpty()) {
            macroBox.addView(text("Calendar nahi mila — internet check karke ↻ dabayen.", 13, YELLOW));
            return;
        }
        long now = System.currentTimeMillis();
        SimpleDateFormat day = new SimpleDateFormat("EEEE, dd MMM", Locale.US), hm = new SimpleDateFormat("hh:mm a", Locale.US);
        String lastDay = "";
        int shown = 0;
        for (final MacroEngine.Event e : evs) {
            if (macroHighOnly && !"High".equals(e.impact)) continue;
            if (e.time < now - 4 * 86_400_000L) continue;
            String d = day.format(new Date(e.time));
            if (!d.equals(lastDay)) {
                lastDay = d;
                TextView dh = bold("📆 " + d, 14, ACC2);
                dh.setPadding(dp(4), dp(12), 0, 0);
                macroBox.addView(dh);
            }
            boolean high = "High".equals(e.impact);
            long dt = e.time - now;
            int border = !e.verdict.isEmpty() ? (e.verdictSign > 0 ? GREEN : e.verdictSign < 0 ? RED : YELLOW) : high ? RED : 0xFFFF8A3D;
            LinearLayout c = card(macroBox, border);
            LinearLayout hr = row();
            TextView tm = bold(hm.format(new Date(e.time)), 13, TEXT);
            hr.addView(tm, new LinearLayout.LayoutParams(dp(78), -2));
            LinearLayout tt = column();
            tt.addView(bold((high ? "🔴 " : "🟠 ") + e.title, 14, TEXT));
            tt.addView(text(e.info.urdu, 11, MUTED));
            hr.addView(tt, new LinearLayout.LayoutParams(0, -2, 1));
            String st = dt > 0 ? "⏰ " + MacroEngine.mins(dt) : !e.actual.isEmpty() ? "✅ aa gaya" : dt > -3600_000L ? "📢 abhi" : "✔ ho gaya";
            hr.addView(bold(st, 11, dt > 0 && dt < 2 * 3600_000L ? RED : dt > 0 ? YELLOW : GREEN));
            c.addView(hr);
            if (!e.forecast.isEmpty() || !e.previous.isEmpty() || !e.actual.isEmpty()) {
                LinearLayout nr = row();
                nr.setPadding(0, dp(6), 0, 0);
                nr.addView(text("Forecast\n" + (e.forecast.isEmpty() ? "—" : e.forecast), 12, SOFT), new LinearLayout.LayoutParams(0, -2, 1));
                nr.addView(text("Pichla\n" + (e.previous.isEmpty() ? "—" : e.previous), 12, SOFT), new LinearLayout.LayoutParams(0, -2, 1));
                nr.addView(bold("Asal\n" + (e.actual.isEmpty() ? (dt > 0 ? "—" : "intezar") : e.actual), 13,
                        e.verdictSign > 0 ? GREEN : e.verdictSign < 0 ? RED : TEXT), new LinearLayout.LayoutParams(0, -2, 1));
                c.addView(nr);
            }
            if (!e.verdict.isEmpty()) {
                c.addView(bold(e.verdict, 13, e.verdictSign > 0 ? GREEN : e.verdictSign < 0 ? RED : YELLOW));
            } else if (dt > 0) {
                c.addView(text("🔮 " + e.expectation, 12, YELLOW));
            }
            if (!Double.isNaN(e.reaction)) {
                c.addView(bold(String.format(Locale.US, "📊 Release ke 5 min mein BTC: %+.2f%%", e.reaction), 12, e.reaction >= 0 ? GREEN : RED));
            }
            final LinearLayout more = column();
            more.setVisibility(View.GONE);
            more.addView(text("ℹ️ " + e.info.what, 12, SOFT));
            more.addView(text("⬆ Agar zyada aaya: " + e.info.ifHigher, 12, SOFT));
            more.addView(text("⬇ Agar kam aaya: " + e.info.ifLower, 12, SOFT));
            more.addView(text(e.official ? "Source: Federal Reserve official schedule" : "Source: ForexFactory calendar · asal figure: FRED (St. Louis Fed)", 10, MUTED));
            c.addView(more);
            TextView rb = chip("🧾 Poori report + live timer", false);
            rb.setTextSize(11);
            rb.setOnClickListener(v -> openEventReport("🏛️ US macro", e.title, e.time, e.official ? "Federal Reserve" : "Economic calendar", e.expectation, "", e.verdictSign, high ? 3 : 2,
                    new ArrayList<>(), "", false, false, "", null));
            LinearLayout.LayoutParams rbl = new LinearLayout.LayoutParams(-2, -2);
            rbl.topMargin = dp(6);
            c.addView(rb, rbl);
            c.setOnClickListener(v -> more.setVisibility(more.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
            shown++;
        }
        if (shown == 0) macroBox.addView(text("Is filter mein koi event nahi.", 12, MUTED));
        macroBox.addView(text("Waqt aap ke phone ke time zone (Pakistan) mein hain. Card par tap = detail. Asal figure release ke 10–60 min "
                + "baad FRED se aati hai; BTC ka reaction 5 min baad.", 11, MUTED));
    }

    // ============================================================ LISTINGS tab
    private void buildListings() {
        LinearLayout page = pageColumn(TAB_LISTINGS);
        LinearLayout seg = row();
        seg.setPadding(0, dp(8), 0, 0);
        String[] sn = {"📅 Economic calendar (Fed, CPI, NFP)", "🆕 Nayi listings"};
        for (int i = 0; i < 2; i++) {
            final int idx = i;
            newsSeg[i] = chip(sn[i], (i == 0) == showMacro);
            newsSeg[i].setOnClickListener(v -> setNewsSeg(idx == 0));
            seg.addView(newsSeg[i], chipLp());
        }
        page.addView(hscroll(seg));
        macroCol = column();
        listCol = column();
        page.addView(macroCol);
        page.addView(listCol);
        buildMacro(macroCol);
        listCol.setVisibility(View.GONE);
        LinearLayout col = listCol;
        LinearLayout h = card(col, ACC);
        LinearLayout hr = row();
        hr.addView(bold("🆕 Nayi listings", 18, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView rf = chip("↻ Refresh", false);
        rf.setOnClickListener(v -> loadListings());
        hr.addView(rf);
        h.addView(hr);
        h.addView(text("Binance, Bybit, OKX aur KuCoin ke taaza listing announcements. Coin par tap karein: listing ka waqt, "
                + "listing se pehle ka volume, aur abhi kahan (DEX / doosre exchange) khareeda ja sakta hai.", 12, MUTED));
        listingStatus = text("", 12, SOFT);
        h.addView(listingStatus);
        listingBox = column();
        col.addView(listingBox);
        LinearLayout w = card(col);
        w.addView(text("⚠️ Nayi listing par price bahut tez upar neeche hoti hai. Listing se pehle DEX par khareedna khatarnak ho "
                + "sakta hai (nakli token, kam liquidity). Hamesha contract address exchange ke official announcement se milayen.", 12, MUTED));
    }

    private void loadListings() {
        listingStatus.setText("Load ho raha hai...");
        pool.execute(() -> {
            final List<Listings.Item> items = Listings.fetchAll();
            runOnUiThread(() -> renderListings(items));
        });
    }

    private static final int[] EX_COL = {0xFFF0B90B, 0xFFF7A600, 0xFFFFFFFF, 0xFF23AF91};

    private int exColor(String ex) {
        switch (ex) {
            case "Binance": return EX_COL[0];
            case "Bybit": return EX_COL[1];
            case "OKX": return EX_COL[2];
            default: return EX_COL[3];
        }
    }

    private void renderListings(List<Listings.Item> items) {
        listingsLoadedAt = System.currentTimeMillis();
        listingBox.removeAllViews();
        if (items.isEmpty()) {
            listingStatus.setText("Announcements nahi mile — internet check karke Refresh dabayen");
            return;
        }
        listingStatus.setText(items.size() + " announcements · " + new SimpleDateFormat("HH:mm", Locale.US).format(new Date()));
        SimpleDateFormat f = new SimpleDateFormat("dd MMM HH:mm", Locale.US);
        long now = System.currentTimeMillis();
        for (final Listings.Item it : items) {
            LinearLayout c = card(listingBox, exColor(it.exchange));
            LinearLayout hr = row();
            TextView ex = bold(it.exchange, 11, INK);
            ex.setPadding(dp(7), dp(2), dp(7), dp(2));
            ex.setBackground(round(exColor(it.exchange), 8, 0));
            hr.addView(ex);
            TextView coin = bold("  " + (it.coin.isEmpty() ? "" : it.coin), 17, TEXT);
            hr.addView(coin, new LinearLayout.LayoutParams(0, -2, 1));
            if (it.listTime > 0) {
                long left = it.listTime - now;
                String when = left > 0 ? "⏰ " + countdown(left) + " baad" : "✅ list ho chuka";
                hr.addView(bold(when, 12, left > 0 ? YELLOW : GREEN));
            }
            c.addView(hr);
            c.addView(text(it.title, 13, SOFT));
            String meta = "Announce: " + (it.announced > 0 ? f.format(new Date(it.announced)) : "?");
            if (it.listTime > 0) meta += " · Listing: " + f.format(new Date(it.listTime)) + " (aap ka waqt)";
            c.addView(text(meta, 11, MUTED));
            final LinearLayout detail = column();
            c.addView(detail);
            LinearLayout br = row();
            if (!it.coin.isEmpty()) {
                TextView d = chip("🔎 Kahan se khareedain / volume", true);
                d.setOnClickListener(v -> listingDetail(it, detail));
                br.addView(d, chipLp());
            }
            TextView an = chip("📄 Announcement", false);
            an.setOnClickListener(v -> openUrl(it.url));
            br.addView(an, chipLp());
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-2, -2);
            bl.topMargin = dp(6);
            c.addView(hscroll(br), bl);
        }
    }

    private static String countdown(long ms) {
        long m = ms / 60000;
        if (m >= 1440) return (m / 1440) + "d " + (m % 1440) / 60 + "h";
        if (m >= 60) return (m / 60) + "h " + (m % 60) + "m";
        return m + "m";
    }

    private void listingDetail(final Listings.Item it, final LinearLayout box) {
        box.removeAllViews();
        box.addView(text("⏳ " + it.coin + " ke markets dhoond raha hoon (DexScreener + CoinGecko)...", 12, MUTED));
        pool.execute(() -> {
            final List<Listings.Market> ms = Listings.markets(it.coin);
            boolean onBinance = false;
            try {
                Scanner.get("/api/v3/ticker/price?symbol=" + it.coin + "USDT");
                onBinance = true;
            } catch (Exception ignored) {
            }
            final boolean bn = onBinance;
            runOnUiThread(() -> {
                box.removeAllViews();
                double tot = 0, dexTot = 0;
                for (Listings.Market m : ms) {
                    tot += m.vol24;
                    if (m.dex) dexTot += m.vol24;
                }
                box.addView(bold(it.coin + " — abhi kahan trade ho raha hai", 14, TEXT));
                if (ms.isEmpty()) {
                    box.addView(text("Abhi kisi DEX ya exchange par nahi mila — shayad pehli dafa list ho raha hai.", 12, YELLOW));
                } else {
                    box.addView(text("24h total volume (listing se pehle/abhi): " + Fmt.usd(tot) + " · DEX par " + Fmt.usd(dexTot), 12, SOFT));
                }
                for (final Listings.Market m : ms) {
                    LinearLayout r = row();
                    r.setPadding(0, dp(6), 0, dp(6));
                    LinearLayout l = column();
                    l.addView(bold((m.dex ? "🦄 " : "🏦 ") + m.venue, 13, TEXT));
                    l.addView(text(m.pair + (m.liquidity > 0 ? " · liquidity " + Fmt.usd(m.liquidity) : ""), 11, MUTED));
                    r.addView(l, new LinearLayout.LayoutParams(0, -2, 1));
                    LinearLayout rt = column();
                    rt.addView(text(m.priceUsd > 0 ? "$" + Fmt.price(m.priceUsd) : "-", 12, TEXT));
                    rt.addView(text("vol " + Fmt.usd(m.vol24), 11, MUTED));
                    r.addView(rt);
                    if (m.url != null && !m.url.isEmpty()) r.setOnClickListener(v -> openUrl(m.url));
                    box.addView(r);
                    box.addView(divider());
                }
                if (bn) {
                    TextView a = chip("📈 " + it.coin + " ka live chart + analysis", true);
                    a.setOnClickListener(v -> openAnalyze(it.coin + "USDT"));
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
                    lp.topMargin = dp(6);
                    box.addView(a, lp);
                }
                TextView b = chip("🟡 Binance app mein kholen", false);
                b.setOnClickListener(v -> BinanceLink.open(this, it.coin, false));
                LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(-2, -2);
                lp2.topMargin = dp(6);
                box.addView(b, lp2);
                box.addView(text("Row par tap = us DEX / exchange ka page khulega.", 11, MUTED));
            });
        });
    }

    // ============================================================ SIGNAL screen (live chart for one signal)
    private void openSignalView(final JSONObject o) {
        closeSignalView();
        final String sym = o.optString("sym");
        final boolean buy = "BUY".equals(o.optString("side"));
        final int m = o.optInt("mode", Mode.SPOT);
        final String tf = o.optString("tf", m == Mode.SCALP ? "5m" : "4h");
        final double entry = o.optDouble("entry", o.optDouble("price", 0));
        final double sl = o.optDouble("sl", 0), tp1 = o.optDouble("tp", 0), tp2 = o.optDouble("tp2", 0);
        final double zlo = o.optDouble("zlo", 0), zhi = o.optDouble("zhi", 0);
        final int col = buy ? GREEN : RED;
        final Assets.Asset as = Assets.find(o.optString("asset", ""));
        final java.util.function.DoubleFunction<String> fp = v -> as != null ? Assets.fmt(as, v) : "$" + Fmt.price(v);

        sigOverlay = column();
        sigOverlay.setTag(o);
        sigOverlay.setBackgroundColor(Mode.bgTop(uiMode));
        ScrollView sv = new ScrollView(this);
        LinearLayout c = column();
        c.setPadding(dp(12), dp(10), dp(12), dp(24));
        sv.addView(c);
        sigOverlay.addView(sv, new LinearLayout.LayoutParams(-1, -1));

        LinearLayout hr = row();
        hr.addView(bold((buy ? "🟢 BUY  " : "🔴 SELL  ") + (as != null ? as.icon + " " + as.short_ : base(sym) + "/USDT"), 20, col), new LinearLayout.LayoutParams(0, -2, 1));
        TextView mb = bold((as != null ? (Assets.FOREX.equals(as.market) ? "Forex" : "Commodity") : Mode.label(m)) + " · " + tf, 11, INK);
        mb.setPadding(dp(7), dp(3), dp(7), dp(3));
        mb.setBackground(round(as != null ? YELLOW : Mode.accent(m), 10, 0));
        hr.addView(mb);
        TextView x = chip("✕", true);
        x.setOnClickListener(v -> closeSignalView());
        LinearLayout.LayoutParams xl = new LinearLayout.LayoutParams(-2, -2);
        xl.leftMargin = dp(8);
        hr.addView(x, xl);
        c.addView(hr);

        final TextView livePx = bold("Live price load ho rahi hai...", 15, TEXT);
        c.addView(livePx);
        LinearLayout tlc = card(c, ACC2);
        tlc.addView(bold("🕒 Signal kab aaya — aur wahan se coin kitna upar / neeche", 14, TEXT));
        signalTimeline(tlc, o, Prefs.signals(this), true);
        String adv = o.optString("adv", "");
        if (!adv.isEmpty()) {
            TextView at = bold(adv, 16, col);
            at.setPadding(0, dp(6), 0, 0);
            c.addView(at);
            String aw = o.optString("advWhy", "");
            if (!aw.isEmpty()) c.addView(text(aw, 13, SOFT));
            if (o.has("horizon")) c.addView(bold("⏳ Hold ka waqt: " + o.optString("horizon"), 13, YELLOW));
            if (o.has("repeat")) c.addView(bold(o.optString("repeat"), 13, CYAN_TXT));
            if (o.has("closedBy")) c.addView(text("Band: " + o.optString("closedBy"), 12, MUTED));
        }
        LinearLayout lv = card(c, col);
        if (zhi > 0) lv.addView(text((buy ? "BUY" : "SELL") + " zone: " + fp.apply(zlo) + " – " + fp.apply(zhi), 14, TEXT));
        lv.addView(text("Entry: " + fp.apply(entry), 14, TEXT));
        if (sl > 0) lv.addView(text("🛑 SL: " + fp.apply(sl) + pctFrom(sl, entry), 14, RED));
        if (tp1 > 0) lv.addView(text("🎯 TP1: " + fp.apply(tp1) + pctFrom(tp1, entry) + (o.optBoolean("acc") ? "  (1R — accuracy mode)" : ""), 14, GREEN));
        JSONArray tpl = o.optJSONArray("tpl");
        String[] tplS = {"", "", "", ""};
        if (tpl != null) for (int q = 0; q < 4 && q < tpl.length(); q++) tplS[q] = tpl.optString(q);
        if (tpl != null && tp1 > 0) {   // relabel TP1 with its time
            lv.removeViewAt(lv.getChildCount() - 1);
            lv.addView(text("🎯 TP1 (" + tplS[0] + "): " + fp.apply(tp1) + pctFrom(tp1, entry), 14, GREEN));
        }
        if (tp2 > 0) lv.addView(text("🎯 TP2" + (tplS[1].isEmpty() ? "" : " (" + tplS[1] + ")") + ": " + fp.apply(tp2) + pctFrom(tp2, entry), 14, GREEN));
        final double tp3 = o.optDouble("tp3", 0), tp4 = o.optDouble("tp4", 0);
        if (tp3 > 0) lv.addView(text("🎯 TP3 (" + tplS[2] + "): " + fp.apply(tp3) + pctFrom(tp3, entry), 14, GREEN));
        if (tp4 > 0) lv.addView(text("🎯 TP4 (" + tplS[3] + "): " + fp.apply(tp4) + pctFrom(tp4, entry), 14, GREEN));
        if (o.has("hit")) lv.addView(bold("🏁 " + o.optInt("hit") + " / 4 targets hit ho chuke", 13, GREEN));
        final String[] tpLabels = tplS;
        if (sl > 0 && tp1 > 0 && entry > 0 && Math.abs(entry - sl) > 0)
            lv.addView(text(String.format(Locale.US, "Risk : Reward = 1 : %.1f", Math.abs(tp1 - entry) / Math.abs(entry - sl)), 13, SOFT));
        String st = o.optString("st", "open");
        lv.addView(bold(st.equals("win") ? "✅ Target hit ho chuka" : st.equals("loss") ? "❌ Stop-loss hit ho chuka"
                : st.equals("expired") ? "⌛ Waqt khatam" : "⏳ Signal abhi khula hai", 13, st.equals("win") ? GREEN : st.equals("loss") ? RED : YELLOW));
        signalLearnCard(c, o, buy);

        final ChartView sc = new ChartView(this);
        sc.setAccent(Mode.accent(m));
        sc.setLayers(false, true, false, false, false, false);
        sc.setCompact(true);
        final String sigTitle = (as != null ? as.short_ : base(sym) + "/USDT") + " · " + tf + " · " + (buy ? "BUY" : "SELL") + " signal";
        sc.setOnTap(() -> openChartFullscreen(sc, sigTitle, false));
        sc.setMessage("Live chart load ho raha hai...");
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, dp(430));
        cl.topMargin = dp(10);
        c.addView(sc, cl);
        c.addView(text("Sirf zaroori cheezein: " + (buy ? "BUY" : "SELL") + " zone, SL, TP1/TP2, trendlines aur pattern · "
                + "chart par tap = full screen", 11, MUTED));

        Button an = button("📈 Poora analysis dekhen", Mode.accent(m), INK, 0);
        an.setOnClickListener(v -> {
            closeSignalView();
            if (as != null) openAssetAnalysis(as);
            else openAnalyze(sym);
        });
        c.addView(an);
        if (as == null) {
            Button bn = button("🟡 Binance app mein kholen", 0xFFF0B90B, INK, 0);
            bn.setOnClickListener(v -> BinanceLink.open(this, base(sym), m == Mode.SCALP && !buy));
            c.addView(bn);
        }
        c.addView(text(o.optString("why"), 12, SOFT));

        rootFrame.addView(sigOverlay, new FrameLayout.LayoutParams(-1, -1));

        if (as != null) {
            pool.execute(() -> {
                try {
                    final Candles cd = YahooData.fetch(as.sym, tf, false);
                    final PatternEngine.Result p = PatternEngine.analyze(cd.closedOnly(), Math.min(150, cd.n));
                    YahooData.Quote q = null;
                    try { q = YahooData.quote(as.sym); } catch (Exception ignored) { }
                    final YahooData.Quote fq = q;
                    runOnUiThread(() -> {
                        if (sigOverlay == null) return;
                        sc.setTitle(as.short_);
                        sc.setData(cd, p, new double[cd.n], new double[cd.n], tf, false);
                        for (String k : new String[]{"Fib", "Zones", "VolProfile", "Whales", "Retail", "RSI", "MACD", "BB", "EMA200", "VWAP", "EMA"}) sc.setInd(k, false);
                        sc.setInd("Patterns", true);
                        sc.setInd("MA Ribbon", true);
                        sc.setInd("ParaDox", true);
                        sc.setInd("Volume", Assets.COMMODITY.equals(as.market));
                        sc.setPlan(entry > 0, buy, entry, sl, tp1, tp2);
                        if (zhi > 0) sc.setZone(zlo, zhi, buy ? "BUY ZONE" : "SELL ZONE", col);
                        double price = fq != null && fq.price > 0 ? fq.price : cd.close[cd.n - 1];
                        String ty = o.optString("type", Position.NOW);
                        sc.setScenario(tp1 > 0, ty, buy, price, Position.NOW.equals(ty) ? 0 : (zlo + zhi) / 2, tp1, tp2 > 0 ? tp2 : tp1);
                        double pnl = entry > 0 ? (buy ? price / entry - 1 : 1 - price / entry) * 100 : 0;
                        livePx.setText(String.format(Locale.US, "Abhi %s  ·  entry se %+.2f%%  (har minute update)", Assets.fmt(as, price), pnl));
                        livePx.setTextColor(pnl >= 0 ? GREEN : RED);
                    });
                } catch (Exception e) {
                    final String msg = e.getMessage();
                    runOnUiThread(() -> sc.setMessage("Chart nahi mila: " + msg));
                }
            });
            return;
        }
        sigLive = new LiveChart(sc, handler);
        pool.execute(() -> {
            try {
                final Candles cd = Candles.fetch(sym, tf, 300, false);
                final PatternEngine.Result p = PatternEngine.analyze(cd.closedOnly(), Math.min(150, cd.n));
                runOnUiThread(() -> {
                    if (sigOverlay == null) return;
                    sc.setTitle(base(sym) + "/USDT");
                    sc.setData(cd, p, new double[cd.n], new double[cd.n], tf, false);
                    for (String k : new String[]{"Fib", "Zones", "VolProfile", "Whales", "Retail", "RSI", "MACD", "BB", "EMA200", "VWAP"}) sc.setInd(k, false);
                    sc.setInd("Patterns", true);
                    sc.setInd("EMA", true);
                    sc.setInd("Volume", true);
                    sc.setPlan(entry > 0, buy, entry, sl, tp1, tp2);
                    if (zhi > 0) sc.setZone(zlo, zhi, buy ? "BUY ZONE" : "SELL ZONE", col);
                    sc.setInd("MA Ribbon", true);
                    sc.setInd("ParaDox", true);
                    sc.setInd("EMA", false);
                    String ty = o.optString("type", Position.NOW);
                    double lvl = Position.NOW.equals(ty) || "HEAVY_SELL".equals(ty) ? 0 : (zlo + zhi) / 2;
                    sc.setScenario(tp1 > 0, ty, buy, cd.close[cd.n - 1], lvl, tp1, tp4 > 0 ? tp4 : tp2 > 0 ? tp2 : tp1);
                    if (tp3 > 0 || tp4 > 0) sc.setMoreTargets(tp3, tp4, tpLabels);
                    sigLive.start(sym, tf, Prefs.whaleUsd(this), price -> {
                        double pnl = entry > 0 ? (buy ? price / entry - 1 : 1 - price / entry) * 100 : 0;
                        livePx.setText(String.format(Locale.US, "Live $%s  ·  entry se %+.2f%%", Fmt.price(price), pnl));
                        livePx.setTextColor(pnl >= 0 ? GREEN : RED);
                    });
                });
            } catch (Exception e) {
                final String msg = e.getMessage();
                runOnUiThread(() -> sc.setMessage("Chart nahi mila: " + msg));
            }
        });
    }

    private void closeSignalView() {
        if (fsOverlay != null) closeFullscreen();
        if (sigLive != null) sigLive.stop();
        sigLive = null;
        if (sigOverlay != null) rootFrame.removeView(sigOverlay);
        sigOverlay = null;
    }

    // ============================================================ SIGNALS tab
    private void buildSignals() {
        LinearLayout col = pageColumn(2);
        focusBox = column();
        col.addView(focusBox);
        renderFocus();
        LinearLayout seg = row();
        seg.setPadding(dp(4), dp(4), dp(4), dp(4));
        seg.setBackground(round(CARD, 16, STROKE));
        String[] segN = {"🪙 Crypto", "🥇 Gold & Comm.", "💱 Forex"};
        for (int i = 0; i < 3; i++) {
            final int si = i;
            sigSegChips[i] = chip(segN[i], i == 0);
            sigSegChips[i].setTextSize(12);
            sigSegChips[i].setOnClickListener(v -> setSigSeg(si));
            seg.addView(sigSegChips[i], new LinearLayout.LayoutParams(0, -2, 1));
        }
        LinearLayout.LayoutParams segLp = new LinearLayout.LayoutParams(-1, -2);
        segLp.topMargin = dp(10);
        col.addView(seg, segLp);
        cryptoBotBox = column();
        col.addView(cryptoBotBox);
        assetBotBox = column();
        assetBotBox.setVisibility(View.GONE);
        col.addView(assetBotBox);
        LinearLayout ab = card(assetBotBox, YELLOW);
        ab.addView(bold("🤖 24/7 Market Bot", 17, TEXT));
        ab.addView(text("Har 15 minute mein poori list scan hoti hai (15m · 1h · 4h · 1d + moving averages + dollar index + news). "
                + "Market band ho (weekend) to bot intezar karta hai. Yeh signals crypto se bilkul alag rehte hain.", 12, MUTED));
        assetBotBtn = button("", YELLOW, INK, 0);
        assetBotBtn.setOnClickListener(v -> toggleMarketBot(sigSeg == 2 ? Assets.FOREX : Assets.COMMODITY));
        ab.addView(assetBotBtn);
        assetBotStatus = text("", 13, MUTED);
        ab.addView(assetBotStatus);
        LinearLayout st = card(cryptoBotBox, ACC);
        st.addView(bold("🤖 24/7 Signal Bots", 17, TEXT));
        st.addView(text("Scalp aur Spot bot alag alag ON/OFF karein. Dono saath bhi chal sakte hain.", 12, MUTED));
        scalpBtn = button("", Mode.accent(Mode.SCALP), INK, 0);
        scalpBtn.setOnClickListener(v -> toggleMode(Mode.SCALP));
        st.addView(scalpBtn);
        spotBtn = button("", Mode.accent(Mode.SPOT), INK, 0);
        spotBtn.setOnClickListener(v -> toggleMode(Mode.SPOT));
        st.addView(spotBtn);
        statusView = text("", 13, MUTED);
        st.addView(statusView);
        diagView = text("", 12, SOFT);
        diagView.setPadding(dp(10), dp(8), dp(10), dp(8));
        diagView.setBackground(round(0x14FFFFFF, 10, STROKE));
        LinearLayout.LayoutParams dgl = new LinearLayout.LayoutParams(-1, -2);
        dgl.topMargin = dp(8);
        st.addView(diagView, dgl);
        Button bat = button("🔋 Battery restriction hatayen (zaroori)", CARD, ACC, ACC);
        bat.setOnClickListener(v -> askBattery());
        st.addView(bat);

        LinearLayout ac = card(cryptoBotBox, ACC2);
        ac.addView(bold("🔔 Price alerts", 16, TEXT));
        ac.addView(text("Analyze tab se alert lagayen · hatane ke liye alert par tap karein", 12, MUTED));
        alertList = column();
        ac.addView(alertList);

        LinearLayout sc = card(col);
        LinearLayout hr = row();
        hr.addView(bold("📡 Signals", 17, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView clr = chip("Clear", false);
        clr.setOnClickListener(v -> {
            Prefs.clearSignals(this);
            renderSignals(true);
        });
        hr.addView(clr);
        sc.addView(hr);
        statsView = bold("", 13, ACC2);
        sc.addView(statsView);
        sc.addView(text("Ek coin ka signal khula ho to bot us coin ka doosra signal sirf HEAVY buying (BUY) ya HEAVY selling (SELL) par deta hai — warna dobara nahi. "
                + "Har signal ka asal nateeja bot khud check karta hai: ✅ target hit · ❌ stop hit · ⌛ waqt khatam. "
                + "Signal par tap karein — us ka apna LIVE chart khulega: BUY/SELL zone, SL, TP aur trendline.", 12, MUTED));
        signalList = column();
        sc.addView(signalList);
    }

    private void setSigSeg(int i) {
        sigSeg = i;
        for (int k = 0; k < 3; k++) styleChip(sigSegChips[k], k == i);
        cryptoBotBox.setVisibility(i == 0 ? View.VISIBLE : View.GONE);
        assetBotBox.setVisibility(i == 0 ? View.GONE : View.VISIBLE);
        refreshStatus();
        renderSignals(true);
    }

    private static String segMarket(int seg) {
        return seg == 1 ? Assets.COMMODITY : seg == 2 ? Assets.FOREX : Assets.CRYPTO;
    }

    private void toggleMarketBot(String mkt) {
        boolean on = !Prefs.mktOn(this, mkt);
        Prefs.setMktOn(this, mkt, on);
        if (on) Prefs.setLastAssetScan(this, mkt, 0);
        if (Prefs.enabled(this)) startForegroundService(new Intent(this, ScannerService.class));
        else startService(new Intent(this, ScannerService.class).setAction(ScannerService.ACTION_STOP));
        toast((Assets.FOREX.equals(mkt) ? "💱 Forex" : "🥇 Gold & Commodities") + " bot " + (on ? "ON ✅" : "OFF"));
        handler.postDelayed(this::refreshStatus, 300);
    }

    private void toggleMode(int m) {
        boolean on = !Prefs.modeOn(this, m);
        Prefs.setModeOn(this, m, on);
        if (Prefs.enabled(this)) {
            startForegroundService(new Intent(this, ScannerService.class));
        } else {
            startService(new Intent(this, ScannerService.class).setAction(ScannerService.ACTION_STOP));
        }
        toast(Mode.label(m) + " bot " + (on ? "ON ✅" : "OFF"));
        handler.postDelayed(this::refreshStatus, 300);
    }

    private void renderAlerts() {
        alertList.removeAllViews();
        JSONArray a = Prefs.alerts(this);
        if (a.length() == 0) {
            alertList.addView(text("Koi alert nahi", 13, MUTED));
            return;
        }
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            final int idx = i;
            boolean above = o.optBoolean("above");
            TextView t = bold((above ? "⬆ " : "⬇ ") + base(o.optString("sym")) + "  " + (above ? "upar jaye " : "neeche aaye ")
                    + "$" + Fmt.price(o.optDouble("price")) + "   ✕", 14, above ? GREEN : RED);
            t.setPadding(0, dp(6), 0, dp(6));
            t.setOnClickListener(v -> {
                List<Integer> l = new ArrayList<>();
                l.add(idx);
                Prefs.removeAlerts(this, l);
                renderAlerts();
            });
            alertList.addView(t);
        }
    }

    private void renderSignals(boolean force) {
        JSONArray all = Prefs.signals(this);
        String want = segMarket(sigSeg);
        JSONArray arr = new JSONArray();
        for (int i = 0; i < all.length(); i++) {
            JSONObject o = all.optJSONObject(i);
            if (o != null && want.equals(o.optString("mkt", Assets.CRYPTO))) arr.put(o);
        }
        JSONObject first = arr.optJSONObject(0);
        StringBuilder kb = new StringBuilder().append(sigSeg).append('/').append(arr.length()).append(':').append(first == null ? 0 : first.optLong("t"));
        int[] st = Scanner.signalStats(arr);
        kb.append(':').append(st[0]).append(st[1]).append(st[2]);
        String key = kb.toString();
        if (!force && key.equals(signalKey)) return;
        signalKey = key;
        int done = st[0] + st[1];
        statsView.setText(done > 0
                ? String.format(Locale.US, "🏆 Win rate %.0f%%  ·  ✅ %d  ❌ %d  ⌛ %d  ⏳ %d open", st[0] * 100.0 / done, st[0], st[1], st[2], st[3])
                : "🏆 Win rate: abhi koi signal mukammal nahi hua (" + st[3] + " open)");
        signalList.removeAllViews();
        if (arr.length() == 0) {
            signalList.addView(text(sigSeg == 0 ? "Abhi koi crypto signal nahi. Upar se Scalp ya Spot bot ON karein — signal aate hi notification aa jayegi."
                    : "Abhi koi " + (sigSeg == 1 ? "Gold / Commodities" : "Forex") + " signal nahi. Upar se bot ON karein. Accuracy mode mein sirf saaf setups aate hain — kabhi kabhi din mein ek bhi nahi.", 13, MUTED));
            return;
        }
        SimpleDateFormat f = new SimpleDateFormat("dd MMM HH:mm", Locale.US);
        for (int i = 0; i < arr.length() && i < 60; i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            final boolean buy = "BUY".equals(o.optString("side"));
            final String sym = o.optString("sym");
            int m = o.optInt("mode", Mode.SPOT);
            LinearLayout item = column();
            item.setPadding(dp(12), dp(10), dp(12), dp(10));
            item.setBackground(round(buy ? 0x1A0ECB81 : 0x1AF6465D, 12, buy ? 0x550ECB81 : 0x55F6465D));
            LinearLayout hr = row();
            final Assets.Asset as = Assets.find(o.optString("asset", ""));
            hr.addView(bold((buy ? "🟢 BUY  " : "🔴 SELL  ") + (as != null ? as.icon + " " + as.short_ : base(sym) + "/USDT"), 15, buy ? GREEN : RED),
                    new LinearLayout.LayoutParams(0, -2, 1));
            String s = o.optString("st", "");
            String res = s.equals("win") ? String.format(Locale.US, "✅ WIN %+.1f%%", o.optDouble("pnl"))
                    : s.equals("loss") ? String.format(Locale.US, "❌ LOSS %+.1f%%", o.optDouble("pnl"))
                    : s.equals("expired") ? String.format(Locale.US, "⌛ %+.1f%%", o.optDouble("pnl"))
                    : s.equals("open") ? "⏳ open" : "";
            if (!res.isEmpty()) {
                TextView rv = bold(res, 11, s.equals("win") ? GREEN : s.equals("loss") ? RED : YELLOW);
                rv.setPadding(0, 0, dp(6), 0);
                hr.addView(rv);
            }
            TextView mb = bold(as != null ? o.optString("tf", "1h") : Mode.label(m), 10, INK);
            mb.setPadding(dp(6), dp(2), dp(6), dp(2));
            mb.setBackground(round(as != null ? YELLOW : Mode.accent(m), 8, 0));
            hr.addView(mb);
            item.addView(hr);
            String wr = (o.has("repeat") ? (o.optString("repeat").startsWith("🔁") ? " · 🔁 dobara (heavy)" : " · 🔄 palta (heavy)") : "")
                    + (o.has("wr") ? " · backtest WR " + o.optInt("wr") + "%" : "") + (o.has("hit") ? " · 🎯 " + o.optInt("hit") + "/4 TP" : "")
                    + (o.has("horizon") ? " · ⏳ " + o.optString("horizon") : "");
            item.addView(text((as != null ? Assets.fmt(as, o.optDouble("price")) : "$" + Fmt.price(o.optDouble("price"))) + " · score " + o.optInt("score") + wr + " · "
                    + f.format(new Date(o.optLong("t"))), 12, MUTED));
            signalTimeline(item, o, all, false);
            if (o.optBoolean("smc") && "open".equals(o.optString("st"))) item.addView(text(o.optBoolean("filled") ? "📥 Limit entry lag chuki — trade chal raha hai"
                    : "⏳ SMC limit entry $" + Fmt.price(o.optDouble("price")) + " ka intezar — price wahan aaye to hi trade", 11, YELLOW));
            if (o.has("note")) item.addView(text("ℹ️ " + o.optString("note"), 11, MUTED));
            String advT = o.optString("adv", "");
            if (!advT.isEmpty()) item.addView(bold(advT, 13, buy ? GREEN : RED));
            String whyT = o.optString("why");
            if (!advT.isEmpty() && whyT.startsWith(advT)) whyT = whyT.substring(advT.length()).trim();
            item.addView(text(whyT, 12, SOFT));
            final JSONObject sig = o;
            item.setOnClickListener(v -> openSignalView(sig));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(8);
            signalList.addView(item, lp);
        }
    }

    private void refreshStatus() {
        boolean sc = Prefs.modeOn(this, Mode.SCALP), sp = Prefs.modeOn(this, Mode.SPOT);
        boolean on = Prefs.enabled(this);
        if (assetBotBtn != null && sigSeg != 0) {
            String mkt = segMarket(sigSeg);
            boolean ao = Prefs.mktOn(this, mkt);
            String nm = sigSeg == 2 ? "💱 FOREX" : "🥇 GOLD & COMMODITIES";
            assetBotBtn.setText(ao ? "⏹  " + nm + " bot ON — band karein" : "▶  " + nm + " bot start karein");
            assetBotBtn.setBackground(round(ao ? YELLOW : CHIP, 14, YELLOW));
            assetBotBtn.setTextColor(ao ? INK : YELLOW);
            assetBotStatus.setText((ao ? Prefs.getStr(this, "astatus_" + mkt, "Pehla scan thori der mein...") : "Bot band hai")
                    + (Prefs.accuracyMode(this) ? "\n🎯 Accuracy mode ON · sirf backtest win rate ≥ " + Prefs.minWinRate(this) + "% wale setups" : ""));
        }
        liveDot.setText(on ? "● LIVE" : "○ OFF");
        liveDot.setTextColor(on ? GREEN : MUTED);
        statusView.setText((Prefs.focusOn(this) ? "🎯 Focus mode ON — sirf focus list ke coins scan ho rahe hain\n" : "")
                + (sc || sp || Prefs.focusOn(this) ? Prefs.status(this) : "Dono crypto bots band hain")
                + (Prefs.accuracyMode(this) ? "\n🎯 Accuracy mode ON · min backtest win rate " + Prefs.minWinRate(this) + "%" : ""));
        scalpBtn.setText(sc ? "⏹  ⚡ SCALP bot ON — band karein" : "▶  ⚡ SCALP bot start karein");
        scalpBtn.setBackground(round(sc ? Mode.accent(Mode.SCALP) : CHIP, 14, Mode.accent(Mode.SCALP)));
        scalpBtn.setTextColor(sc ? INK : Mode.accent(Mode.SCALP));
        spotBtn.setText(sp ? "⏹  💎 SPOT bot ON — band karein" : "▶  💎 SPOT bot start karein");
        spotBtn.setBackground(round(sp ? Mode.accent(Mode.SPOT) : CHIP, 14, Mode.accent(Mode.SPOT)));
        spotBtn.setTextColor(sp ? INK : Mode.accent(Mode.SPOT));
        if (diagView != null) {
            StringBuilder d = new StringBuilder("🩺 Signal check — aakhri scan mein kya hua:");
            for (int m = 0; m < 2; m++) {
                if (!Prefs.modeOn(this, m) && !Prefs.focusOn(this)) continue;
                String g = Prefs.getStr(this, "diag" + m, "");
                d.append("\n\n").append(Mode.label(m)).append(": ").append(g.isEmpty() ? "pehla scan abhi mukammal nahi hua (bot ON hone ke baad kuch minute)" : g);
            }
            if (!Prefs.modeOn(this, 0) && !Prefs.modeOn(this, 1) && !Prefs.focusOn(this)) d.append("\nDono crypto bots band hain.");
            diagView.setText(d.toString());
        }
        if (currentTab == 2) renderSignals(false);
    }

    /** Fetches live prices for the crypto coins listed in the Signals tab, then redraws it. */
    private void refreshSigPx() {
        if (sigPxBusy || System.currentTimeMillis() - sigPxAt < 15_000) return;
        sigPxBusy = true;
        sigPxAt = System.currentTimeMillis();
        final JSONArray all = Prefs.signals(this);
        pool.execute(() -> {
            try {
                java.util.Set<String> syms = new java.util.LinkedHashSet<>();
                for (int i = 0; i < all.length() && i < 60; i++) {
                    JSONObject o = all.optJSONObject(i);
                    if (o != null && Assets.CRYPTO.equals(o.optString("mkt", Assets.CRYPTO)) && Scanner.isTradable(o.optString("sym"))) syms.add(o.optString("sym"));
                }
                if (syms.isEmpty()) return;
                StringBuilder q = new StringBuilder("[");
                for (String sy : syms) { if (q.length() > 1) q.append(','); q.append('"').append(sy).append('"'); }
                q.append(']');
                JSONArray a = new JSONArray(Scanner.get("/api/v3/ticker/price?symbols=" + java.net.URLEncoder.encode(q.toString(), "UTF-8")));
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    double v = o.optDouble("price", 0);
                    if (v > 0) sigPx.put(o.optString("symbol"), v);
                }
                runOnUiThread(() -> { if (currentTab == TAB_SIGNALS && sigSeg == 0) renderSignals(true); });
            } catch (Exception ignored) {
            } finally {
                sigPxBusy = false;
            }
        });
    }

    /** "+3.2% (ab $X)" from a price to the live price; good = in the signal's direction. */
    private TextView moveLine(String label, double from, double now, boolean buy) {
        double mv = (now / from - 1) * 100;
        boolean good = buy ? mv > 0 : mv < 0;
        return bold(String.format(Locale.US, "%s $%s → ab $%s  (%+.2f%%) %s", label, Fmt.price(from), Fmt.price(now), mv, Math.abs(mv) < 0.05 ? "" : good ? "✅" : "❌"),
                12, Math.abs(mv) < 0.05 ? SOFT : good ? GREEN : RED);
    }

    /** Earlier signals of the same coin + market (older first), within 7 days before `o`. */
    private List<JSONObject> earlierSignals(JSONArray all, JSONObject o) {
        List<JSONObject> l = new ArrayList<>();
        long t = o.optLong("t");
        String sym = o.optString("sym"), mkt = o.optString("mkt", Assets.CRYPTO), asset = o.optString("asset", "");
        for (int i = 0; i < all.length(); i++) {
            JSONObject x = all.optJSONObject(i);
            if (x == null || x.optLong("t") >= t || t - x.optLong("t") > 7 * 86_400_000L) continue;
            if (!sym.equals(x.optString("sym")) || !mkt.equals(x.optString("mkt", Assets.CRYPTO)) || !asset.equals(x.optString("asset", ""))) continue;
            l.add(0, x);
        }
        while (l.size() > 3) l.remove(0);
        return l;
    }

    /** Signal timeline: when given, earlier signals for the coin, and % moved since each one (live). */
    private void signalTimeline(LinearLayout item, JSONObject o, JSONArray all, boolean big) {
        SimpleDateFormat full = new SimpleDateFormat("dd MMM yyyy, HH:mm:ss", Locale.US);
        final boolean buy = "BUY".equals(o.optString("side"));
        boolean crypto = Assets.CRYPTO.equals(o.optString("mkt", Assets.CRYPTO));
        Double nowP = crypto ? sigPx.get(o.optString("sym")) : null;
        List<JSONObject> prev = earlierSignals(all, o);
        boolean rpt = o.has("repeat");
        int n = prev.size();
        for (int k = 0; k < n; k++) {
            JSONObject x = prev.get(k);
            boolean xb = "BUY".equals(x.optString("side"));
            String lbl = (k == 0 ? "1️⃣ Pehla signal" : (k + 1) + "️⃣ " + (x.has("repeat") ? "Heavy signal" : "Signal")) + " (" + x.optString("side") + "): " + full.format(new Date(x.optLong("t")));
            item.addView(text(lbl, big ? 13 : 11, SOFT));
            if (nowP != null && x.optDouble("price", 0) > 0) item.addView(moveLine("   us waqt", x.optDouble("price"), nowP, xb));
            else item.addView(text("   us waqt price $" + Fmt.price(x.optDouble("price")), big ? 12 : 11, MUTED));
        }
        String me = n > 0 ? (n + 1) + "️⃣ " + (rpt ? (o.optString("repeat").startsWith("🔄") ? "Palta heavy signal" : "Dobara heavy signal") : "Yeh signal") : "🕒 Signal diya";
        item.addView(bold(me + (n > 0 ? " (" + o.optString("side") + ")" : "") + ": " + full.format(new Date(o.optLong("t"))), big ? 14 : 12, ACC2));
        if (nowP != null && o.optDouble("price", 0) > 0 && "open".equals(o.optString("st"))) item.addView(moveLine("   signal par", o.optDouble("price"), nowP, buy));
        else if (nowP != null && o.optDouble("price", 0) > 0) item.addView(moveLine("   signal par (band ho chuka)", o.optDouble("price"), nowP, buy));
    }

    private void askBattery() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm.isIgnoringBatteryOptimizations(getPackageName())) {
                toast("Pehle se unrestricted hai ✅");
                return;
            }
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception ignored) {
            }
        }
    }

    // ============================================================ SETTINGS tab
    private EditText field(LinearLayout parent, String label, String value, int inputType) {
        parent.addView(text(label, 13, MUTED));
        EditText e = input("", value, inputType);
        parent.addView(e);
        return e;
    }

    private EditText numField(LinearLayout parent, String label, int value) {
        return field(parent, label, String.valueOf(value), InputType.TYPE_CLASS_NUMBER);
    }

    private CheckBox check(LinearLayout parent, String label, boolean on) {
        CheckBox cb = new CheckBox(this);
        cb.setText(label);
        cb.setTextColor(TEXT);
        cb.setChecked(on);
        parent.addView(cb);
        return cb;
    }

    // ------------------------------------------------------------ settings building blocks
    /** Collapsible settings section (tap the header to open / close). Returns the body. */
    private void group(LinearLayout col, String title) {
        TextView t = bold(title, 11, MUTED);
        t.setLetterSpacing(0.14f);
        t.setPadding(dp(6), dp(18), 0, 0);
        col.addView(t);
    }

    private LinearLayout section(LinearLayout col, String title, String sub, int color, boolean open) {
        LinearLayout c = card(col, STROKE);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout head = row();
        String icon = title, name = title;
        int sp = title.indexOf(' ');
        if (sp > 0 && sp <= 4) { icon = title.substring(0, sp); name = title.substring(sp + 1); }
        TextView ib = text(icon, 18, TEXT);
        ib.setGravity(Gravity.CENTER);
        ib.setBackground(round((color & 0x00FFFFFF) | 0x33000000, 12, 0));
        head.addView(ib, new LinearLayout.LayoutParams(dp(40), dp(40)));
        LinearLayout tt = column();
        tt.setPadding(dp(12), 0, 0, 0);
        tt.addView(bold(name, 15, TEXT));
        if (sub != null) tt.addView(text(sub, 11, MUTED));
        head.addView(tt, new LinearLayout.LayoutParams(0, -2, 1));
        final TextView arrow = bold(open ? "⌄" : "›", 22, MUTED);
        head.addView(arrow);
        c.addView(head);
        final LinearLayout body = column();
        body.setVisibility(open ? View.VISIBLE : View.GONE);
        c.addView(body);
        head.setOnClickListener(v -> {
            boolean o = body.getVisibility() != View.VISIBLE;
            body.setVisibility(o ? View.VISIBLE : View.GONE);
            arrow.setText(o ? "⌄" : "›");
        });
        return body;
    }

    /** A real-app style ON/OFF row that saves immediately. */
    private Switch toggle(LinearLayout parent, String label, String sub, boolean on, CompoundButton.OnCheckedChangeListener l) {
        LinearLayout r = row();
        r.setPadding(0, dp(8), 0, dp(8));
        LinearLayout t = column();
        t.addView(bold(label, 14, TEXT));
        if (sub != null) t.addView(text(sub, 11, MUTED));
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        Switch sw = new Switch(this);
        sw.setChecked(on);
        sw.setOnCheckedChangeListener(l);
        r.addView(sw);
        parent.addView(r);
        parent.addView(divider());
        return sw;
    }

    private void buildSettings() {
        LinearLayout col = pageColumn(TAB_SETTINGS);
        String ver = "?";
        try {
            ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
        }

        // ---- header / quick controls
        LinearLayout head = card(col, ACC);
        LinearLayout hr = row();
        TextView logo = bold("P", 26, INK);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(round(ACC, 14, 0));
        hr.addView(logo, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout ht = column();
        ht.setPadding(dp(12), 0, 0, 0);
        ht.addView(bold("ParaDox", 17, TEXT));
        ht.addView(text("Version " + ver + " · by Nohman Arshid", 12, MUTED));
        hr.addView(ht, new LinearLayout.LayoutParams(0, -2, 1));
        head.addView(hr);
        toggle(head, "⚡ Scalp bot", "Heavy buying = BUY · heavy selling = SELL · 24/7", Prefs.modeOn(this, Mode.SCALP), (b, on) -> {
            if (on != Prefs.modeOn(this, Mode.SCALP)) toggleMode(Mode.SCALP);
        });
        toggle(head, "💎 Spot bot", "Achhi entry par BUY · $5M+ selling par SELL · 24/7", Prefs.modeOn(this, Mode.SPOT), (b, on) -> {
            if (on != Prefs.modeOn(this, Mode.SPOT)) toggleMode(Mode.SPOT);
        });
        toggle(head, "🎯 Focus mode (sirf meri list)", "Baqi sab bots ruk jate hain · list Signals tab mein", Prefs.focusOn(this), (b, on) -> {
            if (on && Prefs.focusList(this).length() == 0) { b.setChecked(false); toast("Pehle Signals tab mein list banayen"); return; }
            Prefs.setFocusOn(this, on);
            restartService();
            renderFocus();
        });
        toggle(head, "🥇 Gold & Commodities bot", "Gold, silver, oil, gas, copper — har 15 min", Prefs.mktOn(this, Assets.COMMODITY), (b, on) -> {
            if (on != Prefs.mktOn(this, Assets.COMMODITY)) toggleMarketBot(Assets.COMMODITY);
        });
        toggle(head, "💱 Forex bot", "EURUSD, GBPUSD, USDJPY... — har 15 min", Prefs.mktOn(this, Assets.FOREX), (b, on) -> {
            if (on != Prefs.mktOn(this, Assets.FOREX)) toggleMarketBot(Assets.FOREX);
        });
        LinearLayout mr = row();
        mr.setPadding(0, dp(8), 0, 0);
        mr.addView(text("App ka rang / screens:", 13, SOFT), new LinearLayout.LayoutParams(0, -2, 1));
        for (int m = 0; m < 2; m++) {
            final int mm = m;
            TextView c = chip(Mode.label(m), m == uiMode);
            c.setOnClickListener(v -> switchMode(mm));
            mr.addView(c, chipLp());
        }
        head.addView(mr);

        // ---- per-mode bot settings
        group(col, "TRADING BOTS");
        for (int m = 0; m < 2; m++) {
            LinearLayout b = section(col, (m == Mode.SCALP ? "⚡ Scalp bot" : "💎 Spot bot"), Mode.desc(m), Mode.accent(m), false);
            modeSettings(b, m);
        }

        // ---- notifications
        group(col, "ALERTS");
        LinearLayout n = section(col, "🔔 Notifications", "Signals, price alerts, portfolio, institutions, news, quiet hours", ACC2, false);
        toggle(n, "📡 Buy / Sell signals", "Scalp aur Spot bots ke signals", Prefs.notifOn(this, Prefs.N_SIGNALS), (b, on) -> Prefs.setNotif(this, Prefs.N_SIGNALS, on));
        toggle(n, "🔔 Price alerts", "Aap ke lagaye hue price levels", Prefs.notifOn(this, Prefs.N_ALERTS), (b, on) -> Prefs.setNotif(this, Prefs.N_ALERTS, on));
        toggle(n, "💼 Mere wallets", "Balance badhe ya ghate", Prefs.notifOn(this, Prefs.N_WALLET), (b, on) -> Prefs.setNotif(this, Prefs.N_WALLET, on));
        toggle(n, "🐋 Bade log (ETF / companies / whales)", "Million/billion ki khareed-farokht", Prefs.notifOn(this, Prefs.N_BIG), (b, on) -> Prefs.setNotif(this, Prefs.N_BIG, on));
        toggle(n, "🔄 App updates", "Naya version aaye to batao", Prefs.notifOn(this, Prefs.N_UPDATE), (b, on) -> Prefs.setNotif(this, Prefs.N_UPDATE, on));
        toggle(n, "🎯 Gainer hunter alerts (pre-pump / pre-dump)", "Gainers / losers list se pehle", Prefs.notifOn(this, Prefs.N_HUNT), (b, on) -> Prefs.setNotif(this, Prefs.N_HUNT, on));
        toggle(n, "⚡ Mispricing / arbitrage alerts", "Price error, arbitrage, stablecoin depeg, flash move", Prefs.notifOn(this, Prefs.N_ARB), (b, on) -> Prefs.setNotif(this, Prefs.N_ARB, on));
        toggle(n, "📆 Catalyst reminders (unlock, listing, delisting...)", "Bare event se 24 ghante aur 1 ghanta pehle", Prefs.notifOn(this, Prefs.N_CATALYST), (b, on) -> Prefs.setNotif(this, Prefs.N_CATALYST, on));
        toggle(n, "📰 Crypto news alerts (hack, listing, ETF, SEC...)", "News radar ON ho to bari khabar par foran notification", Prefs.notifOn(this, Prefs.N_NEWS), (b, on) -> Prefs.setNotif(this, Prefs.N_NEWS, on));
        toggle(n, "📅 Economic news (Fed, CPI, NFP...)", "Pehle reminder + asal figure + BTC reaction", Prefs.notifOn(this, Prefs.N_MACRO), (b, on) -> Prefs.setNotif(this, Prefs.N_MACRO, on));
        minConfEt = numField(n, "Signal tabhi bhejo jab confidence kam az kam (%) ho — 0 = sab", Prefs.minConfidence(this));
        quietCb = check(n, "🌙 Quiet hours — is waqt koi notification nahi", Prefs.quietOn(this));
        LinearLayout qr = row();
        LinearLayout q1 = column(), q2 = column();
        q1.addView(text("Se (ghanta 0–23)", 11, MUTED));
        quietFromEt = input("", String.valueOf(Prefs.quietFrom(this)), InputType.TYPE_CLASS_NUMBER);
        q1.addView(quietFromEt);
        q2.addView(text("Tak (ghanta 0–23)", 11, MUTED));
        quietToEt = input("", String.valueOf(Prefs.quietTo(this)), InputType.TYPE_CLASS_NUMBER);
        q2.addView(quietToEt);
        qr.addView(q1, new LinearLayout.LayoutParams(0, -2, 1));
        qr.addView(new View(this), new LinearLayout.LayoutParams(dp(10), 1));
        qr.addView(q2, new LinearLayout.LayoutParams(0, -2, 1));
        n.addView(qr);
        TextView sys = chip("📱 Android notification settings (awaaz / vibration)", false);
        sys.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()));
            } catch (Exception e) {
                toast("Settings nahi khuli");
            }
        });
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-2, -2);
        sl.topMargin = dp(8);
        n.addView(sys, sl);

        // ---- signal engine
        group(col, "INTELLIGENCE");
        LinearLayout acc = section(col, "🎯 Accuracy mode (ParaDox rule)", "Sirf woh signals jin ka rule pehle kamyab raha", GREEN, true);
        accCb = check(acc, "🎯 Accuracy mode ON — backtest + moving averages + timeframes sab ek taraf hon tabhi signal", Prefs.accuracyMode(this));
        minWrEt = numField(acc, "Kam az kam backtest win rate (%) — 40 se 90 (default 55, zyada = kam magar saaf signals)", Prefs.minWinRate(this));
        acc.addView(text("Kaise kaam karta hai: har coin/asset ke chart par ParaDox rule (EMA trend + EMA9/21 trigger + RSI + MACD + volume) "
                + "pichli ~1000 candles par chala kar dekha jata hai ke kitni dafa TP1 (1R) pehle laga. Is se kam win rate wala setup nahi bheja jata. "
                + "TP1 = 1R rakha jata hai (jaldi profit, zyada hit rate).\n\n"
                + "Sach: zyada win rate (70%+) ka matlab kam signals. 95% kisi bhi bot ki guarantee nahi hoti — stop-loss hamesha lagayen.", 12, MUTED));
        LinearLayout e = section(col, "🎛️ Signal engine", "Filters, confirmation, whale size, news pause", ACC, false);
        btcCb = check(e, "BTC filter: jab BTC bearish ho to BUY signal na do", Prefs.btcFilter(this));
        smartCb = check(e, "🐋 Smart money: whale trades, top traders, open interest", Prefs.smartMoney(this));
        strongCb = check(e, "🎯 Strong signal: SAB sources (10 exchanges, ETF, on-chain, patterns) se confirm karo", Prefs.strongConfirm(this));
        whaleEt = numField(e, "Whale trade kitne USD se bada ho (e.g. 50000)", Prefs.whaleUsd(this));
        spotSellEt = field(e, "💎 Spot SELL sirf tab jab SAB exchanges par 1 ghante mein itne MILLION $ ki net selling ho (default 5)",
                String.valueOf((float) Prefs.spotSellUsd(this)), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        scalpHeavyEt = field(e, "⚡ Scalp HEAVY (foran FAST signal): 15 min mein itne HAZAR $ net (default 250 — chhote coin ke liye khud kam ho jata hai)",
                String.valueOf((int) Prefs.scalpHeavyUsd(this)), InputType.TYPE_CLASS_NUMBER);
        e.addView(text("Spot: BUY sirf achhi entry par — bot 1h/4h/1d/1w dekh kar horizon chunta hai (1–2 din · 1–2 hafte · 1–2 mahine) aur 4 targets deta hai. "
                + "SELL sirf heavy selling par (Binance, OKX, Bybit, Coinbase, KuCoin, Gate, Bitget sab mila kar).\n"
                + "Scalp: HEAVY buying/selling par foran FAST signal; kam volume par bhi signal jab woh volume is coin ki price hilane ke liye kaafi ho "
                + "(bot har coin ka price-impact khud seekhta hai).", 11, MUTED));
        toggle(e, "🛑 Bade US news ke waqt signals roko", "CPI, Fed, NFP se ±30 min pehle/baad naye signal nahi", Prefs.newsPause(this), (b, on) -> Prefs.setNewsPause(this, on));

        // ---- AI (free only: Gemini / Groq) + ChatGPT web
        LinearLayout ai = section(col, "🤖 AI Analyst (FREE)", "Gemini, Groq, ChatGPT", CLAUDE, false);
        ai.addView(bold("AI provider (kaun sa AI jawab de)", 13, TEXT));
        LinearLayout pr = row();
        final String[] pv = {AiRouter.GEMINI, AiRouter.GROQ}, pl = {"Gemini (FREE)", "Groq (FREE)"};
        final TextView[] pc = new TextView[2];
        for (int i = 0; i < 2; i++) {
            final int k = i;
            pc[i] = chip(pl[i], AiRouter.provider(this).equals(pv[i]));
            pc[i].setTextSize(11);
            pc[i].setOnClickListener(v -> { Prefs.putStr(this, "aiprov", pv[k]); for (int z = 0; z < 2; z++) styleChip(pc[z], z == k); });
            pr.addView(pc[i], chipLp());
        }
        ai.addView(hscroll(pr));
        geminiEt = field(ai, "Google Gemini API key — FREE (aistudio.google.com → Get API key)", Prefs.getStr(this, "geminikey", ""),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        groqEt = field(ai, "Groq API key — FREE (console.groq.com → API Keys)", Prefs.getStr(this, "groqkey", ""),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        ai.addView(text("Free wale ki rozana had hoti hai (Gemini / Groq) — aam istemal ke liye kaafi. AI khud market nahi dekhta: ParaDox ka jama kiya live data us ko bheja jata hai.", 11, MUTED));
        Button gpt = button("💬 ChatGPT (FREE) — email se sign up / login", 0xFF10A37F, INK, 0);
        gpt.setOnClickListener(v -> openChatGpt(null));
        ai.addView(gpt);
        ai.addView(text("ChatGPT app ke andar OpenAI ki apni website par khulta hai — aap wahin email se account banate hain, login yaad rehta hai. Gainer Hunter mein har coin par "
                + "'ChatGPT se trading plan' button hai.", 11, MUTED));

        // ---- API keys
        LinearLayout k = section(col, "🔑 API keys", "Optional paid data sources", ACC2, false);
        glassEt = field(k, "Glassnode API key (sirf paid plan par milti hai)", Prefs.glassKey(this),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        cmEt = field(k, "CoinMarketCal API key (FREE — coinmarketcal.com/en/developer/register) · crypto events calendar", Prefs.getStr(this, "cmcal", ""),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        cpEt = field(k, "CryptoPanic token (FREE — cryptopanic.com/developers/api) · 100s news sites + social", Prefs.getStr(this, "cryptopanic", ""),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        // ---- update
        group(col, "APP");
        LinearLayout up = section(col, "🔄 App updates", "Version " + ver + " · in-app install", GREEN, false);
        up.addView(text("Naya version GitHub par banta hai to app khud bata deti hai — phir sirf 'Install' dabana hai.", 12, MUTED));
        repoEt = field(up, "GitHub repo (owner/naam)", Prefs.updateRepo(this), InputType.TYPE_CLASS_TEXT);
        updStatus = text("", 13, SOFT);
        up.addView(updStatus);
        Button chk = button("🔍 Update check karein", GREEN, INK, 0);
        chk.setOnClickListener(v -> {
            Prefs.setUpdateRepo(this, repoEt.getText().toString());
            checkForUpdate(true);
        });
        up.addView(chk);

        // ---- battery & background
        LinearLayout bt = section(col, "🔋 Battery & background", "24/7 operation, autostart", YELLOW, false);
        bt.addView(text("Xiaomi, Oppo, Vivo, Infinix, Tecno, Samsung waghera mein: Battery = 'No restrictions' aur Autostart = ON karein.", 12, SOFT));
        Button bb = button("🔋 Battery restriction hatayen", CARD, YELLOW, YELLOW);
        bb.setOnClickListener(v -> askBattery());
        bt.addView(bb);
        Button ap = button("📱 App info kholen (Autostart / permissions)", CARD, TEXT, STROKE);
        ap.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:" + getPackageName())));
            } catch (Exception ex) {
                toast("Nahi khula");
            }
        });
        bt.addView(ap);

        // ---- data & privacy
        group(col, "PRIVACY & ABOUT");
        LinearLayout dpv = section(col, "🛡️ Data & privacy", "On-device storage, reset options", RED, false);
        dpv.addView(text("• Koi account / login nahi · koi data hamare server par nahi jata\n"
                + "• Wallet tracker sirf PUBLIC address dekhta hai — seed phrase / private key kabhi nahi maangta\n"
                + "• API keys sirf is phone mein save hoti hain", 12, SOFT));
        confirmButton(dpv, "🗑 Saare signals mitayen", () -> { Prefs.clearSignals(this); renderSignals(true); });
        confirmButton(dpv, "🗑 Bade log ki history mitayen", () -> { Prefs.saveBigSnap(this, new JSONObject()); });
        confirmButton(dpv, "🗑 Saare wallets hatayen", () -> { Prefs.saveWallets(this, new JSONArray()); loadWallets(); });
        confirmButton(dpv, "↺ Settings default par wapas", () -> { Prefs.resetSettings(this); recreate(); });

        // ---- about
        LinearLayout ab = section(col, "ℹ️ About", "Data sources, disclaimer", ACC2, false);
        ab.addView(text("• Binance WebSocket: live price, candles, har trade, order book\n"
                + "• 10 exchanges ka buy/sell volume: Binance, OKX, Bybit, Coinbase, Kraken, KuCoin, Gate, Bitget\n"
                + "• ETF flows (BlackRock, Fidelity ...): Farside Investors\n"
                + "• Companies / governments holdings: CoinGecko\n"
                + "• Wallets: mempool.space, Ethplorer, BNB Chain RPC, TronGrid, Solana RPC, Blockchair\n"
                + "• On-chain: DefiLlama, Blockchain.com, Coin Metrics, Coinbase premium\n"
                + "• Listings: Binance, Bybit, OKX, KuCoin announcements · DexScreener\n"
                + "• Futures: Binance open interest, top traders, funding · Fear & Greed · News", 12, SOFT));
        ab.addView(text("⚠️ Signals sirf maloomat ke liye hain, financial advice nahi. Bot khud koi trade nahi karta.", 12, MUTED));

        Button save = button("💾 Save all settings", ACC, INK, 0);
        save.setOnClickListener(v -> saveSettings());
        LinearLayout.LayoutParams svl = new LinearLayout.LayoutParams(-1, dp(54));
        svl.topMargin = dp(14);
        col.addView(save, svl);
    }

    /** Button that needs two taps (safety for destructive actions). */
    private void confirmButton(LinearLayout parent, String label, final Runnable action) {
        final Button b = button(label, CARD, RED, RED);
        final long[] armed = {0};
        b.setOnClickListener(v -> {
            long now = System.currentTimeMillis();
            if (now - armed[0] < 3000) {
                action.run();
                b.setText("✅ Ho gaya");
                armed[0] = 0;
            } else {
                armed[0] = now;
                b.setText("Pakka? Dobara dabayen");
                handler.postDelayed(() -> b.setText(label), 3000);
            }
        });
        parent.addView(b);
    }

    private void modeSettings(LinearLayout c, int m) {
        EditText[] f = new EditText[7];
        f[0] = numField(c, "Har kitne minute baad scan", Prefs.intervalMin(this, m));
        c.addView(text("Scan candle timeframe", 13, MUTED));
        String[] tfs = Mode.scanTfs(m);
        Spinner sp = new Spinner(this);
        sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, tfs));
        for (int i = 0; i < tfs.length; i++) if (tfs[i].equals(Prefs.timeframe(this, m))) sp.setSelection(i);
        c.addView(sp);
        tfSpinners[m] = sp;
        f[1] = numField(c, "Kitne top coins (volume ke hisaab se, max 400)", Prefs.topCoins(this, m));
        f[2] = numField(c, "Kam az kam 24h volume (million USDT)", Prefs.minVolMillion(this, m));
        f[3] = numField(c, "BUY score threshold (zyada = kam magar pakke)", Prefs.buyThreshold(this, m));
        f[4] = numField(c, "SELL score threshold", Prefs.sellThreshold(this, m));
        f[5] = field(c, "Volume spike = average ka kitna guna", String.valueOf(Prefs.volMult(this, m)),
                InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        f[6] = numField(c, "Ek coin ka dobara signal kitne minute baad", Prefs.cooldownMin(this, m));
        modeFields[m] = f;
        final int mm = m;
        TextView preset = chip("↺ Recommended " + (m == Mode.SCALP ? "scalp" : "spot") + " values", false);
        preset.setOnClickListener(v -> {
            int[] vals = mm == Mode.SCALP ? new int[]{1, 60, 10, 6, 4, 30} : new int[]{15, 150, 5, 7, 5, 240};
            modeFields[mm][0].setText(String.valueOf(vals[0]));
            modeFields[mm][1].setText(String.valueOf(vals[1]));
            modeFields[mm][2].setText(String.valueOf(vals[2]));
            modeFields[mm][3].setText(String.valueOf(vals[3]));
            modeFields[mm][4].setText(String.valueOf(vals[4]));
            modeFields[mm][5].setText(mm == Mode.SCALP ? "1.8" : "2.0");
            modeFields[mm][6].setText(String.valueOf(vals[5]));
            tfSpinners[mm].setSelection(2);
            toast("Recommended values bhar di — neeche Save dabayen");
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = dp(8);
        c.addView(preset, lp);
    }

    private int num(EditText e, int def) {
        try {
            return Integer.parseInt(e.getText().toString().trim());
        } catch (Exception x) {
            return def;
        }
    }

    private void saveSettings() {
        for (int m = 0; m < 2; m++) {
            EditText[] f = modeFields[m];
            float vm;
            try {
                vm = Float.parseFloat(f[5].getText().toString().trim());
            } catch (Exception x) {
                vm = 2.0f;
            }
            Prefs.saveMode(this, m, num(f[0], Prefs.intervalMin(this, m)), Mode.scanTfs(m)[tfSpinners[m].getSelectedItemPosition()],
                    num(f[1], 100), num(f[2], 5), num(f[3], 7), num(f[4], 5), vm, num(f[6], 120));
        }
        Prefs.saveCommon(this, btcCb.isChecked(), smartCb.isChecked(), strongCb.isChecked(),
                num(whaleEt, 50000), glassEt.getText().toString());
        Prefs.setUpdateRepo(this, repoEt.getText().toString());
        Prefs.setMinConfidence(this, num(minConfEt, 0));
        Prefs.saveQuiet(this, quietCb.isChecked(), num(quietFromEt, 0), num(quietToEt, 7));
        Prefs.setAccuracyMode(this, accCb.isChecked());
        Prefs.setSpotSellUsd(this, (float) parse(spotSellEt, 5));
        Prefs.setScalpHeavyUsd(this, (float) parse(scalpHeavyEt, 250));
        Prefs.putStr(this, "cryptopanic", cpEt.getText().toString().trim());
        Prefs.putStr(this, "cmcal", cmEt.getText().toString().trim());
        Prefs.putStr(this, "geminikey", geminiEt.getText().toString().trim());
        Prefs.putStr(this, "groqkey", groqEt.getText().toString().trim());
        Prefs.setMinWinRate(this, num(minWrEt, 55));
        toast("Saved ✅ — agla scan naye settings se hoga");
    }
}
