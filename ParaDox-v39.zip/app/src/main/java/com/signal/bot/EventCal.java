package com.signal.bot;

import android.content.Context;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * OCCASIONS CALENDAR — Cat Day, Dog Day, Pi Day, Pizza Day... themed coins aksar in dinon se PEHLE hype pakadte hain.
 * App har event se 7 / 3 / 1 din pehle (aur us din) alert deta hai, saath mein us coin ka pichle saalon ka haal
 * (event se 7 din pehle se event tak kitna chala). Yeh sirf mausami / theme hype hai — koi pakki cheez nahi; sample chhota hota hai.
 */
public final class EventCal {
    private EventCal() {}

    public static final class Ev {
        public final String emoji, name, note;
        public final int month, day;          // month 1-12; 0 = uses `dates`
        public final String[] coins;
        public final String[] dates;          // yyyy-MM-dd for moving dates
        Ev(String emoji, String name, int month, int day, String note, String... coins) {
            this.emoji = emoji; this.name = name; this.month = month; this.day = day; this.note = note; this.coins = coins; this.dates = null;
        }
        Ev(String emoji, String name, String[] dates, String note, String... coins) {
            this.emoji = emoji; this.name = name; this.month = 0; this.day = 0; this.note = note; this.coins = coins; this.dates = dates;
        }
    }

    public static final Ev[] EVENTS = {
            new Ev("₿", "Bitcoin Genesis Block", 1, 3, "Bitcoin ki sab se pehli block ki salgirah.", "BTC"),
            new Ev("🐸", "World Frog Day", 3, 20, "Frog-meme coins par social media hype.", "PEPE"),
            new Ev("🥧", "Pi Day", 3, 14, "3.14 — Pi community ka din.", "PI"),
            new Ev("🌿", "4/20", 4, 20, "Dogecoin / Elon culture ka din — DOGE par aksar hype.", "DOGE"),
            new Ev("🐧", "World Penguin Day", 4, 25, "Penguin-themed coin.", "PENGU"),
            new Ev("🍕", "Bitcoin Pizza Day", 5, 22, "2010 mein 10,000 BTC ka pizza — community ka din.", "BTC"),
            new Ev("🔷", "Ethereum Birthday", 7, 30, "Ethereum mainnet ki salgirah (2015).", "ETH"),
            new Ev("🟡", "Binance Anniversary", 7, 14, "Binance ki salgirah — BNB campaigns.", "BNB"),
            new Ev("🐕", "SHIB Birthday", 8, 1, "Shiba Inu ki salgirah (2020).", "SHIB"),
            new Ev("🐱", "International Cat Day", 8, 8, "Cat-themed meme coins par hype.", "POPCAT", "MEW", "CATI"),
            new Ev("🐶", "International Dog Day", 8, 26, "Dog-themed meme coins par hype.", "DOGE", "SHIB", "FLOKI", "BONK", "WIF", "NEIRO"),
            new Ev("🐱", "National Cat Day (USA)", 10, 29, "Amreeka ka Cat Day.", "POPCAT", "MEW"),
            new Ev("📄", "Bitcoin Whitepaper Day / Halloween", 10, 31, "Satoshi ka whitepaper (2008).", "BTC"),
            new Ev("🐕", "Dogecoin Birthday", 12, 6, "DOGE ki salgirah (2013).", "DOGE"),
            new Ev("🐒", "International Monkey Day", 12, 14, "Monkey-themed coin.", "APE"),
            new Ev("🎄", "Christmas / Santa Rally", 12, 25, "Saal ke aakhir ka mausami rally ka daur.", "BTC", "ETH"),
            new Ev("🧧", "Chinese New Year", new String[]{"2027-02-06", "2028-01-26", "2029-02-13", "2030-02-03"}, "China / Asia community ka bara tehwar.", "BNB", "TRX"),
            new Ev("⛏️", "Bitcoin Halving (andazan)", new String[]{"2028-04-17"}, "Agla halving — tareekh andazan hai (block count se badal sakti hai).", "BTC"),
    };

    public static final class Next {
        public Ev ev;
        public Calendar date;
        public int daysLeft;
    }

    static Calendar day(int y, int m, int d) {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(y, m - 1, d, 0, 0, 0);
        return c;
    }

    /** Next occurrence on/after `now` (null if none left). */
    public static Next next(Ev e, long nowMs) {
        Calendar today = Calendar.getInstance();
        today.setTimeInMillis(nowMs);
        Calendar t0 = day(today.get(Calendar.YEAR), today.get(Calendar.MONTH) + 1, today.get(Calendar.DAY_OF_MONTH));
        Calendar best = null;
        if (e.dates != null) {
            for (String s : e.dates) {
                String[] p = s.split("-");
                Calendar c = day(Integer.parseInt(p[0]), Integer.parseInt(p[1]), Integer.parseInt(p[2]));
                if (!c.before(t0) && (best == null || c.before(best))) best = c;
            }
        } else {
            int y = today.get(Calendar.YEAR);
            Calendar c = day(y, e.month, e.day);
            if (c.before(t0)) c = day(y + 1, e.month, e.day);
            best = c;
        }
        if (best == null) return null;
        Next n = new Next();
        n.ev = e;
        n.date = best;
        n.daysLeft = (int) Math.round((best.getTimeInMillis() - t0.getTimeInMillis()) / 86_400_000.0);
        return n;
    }

    public static List<Next> upcoming(long nowMs) {
        List<Next> l = new ArrayList<>();
        for (Ev e : EVENTS) { Next n = next(e, nowMs); if (n != null) l.add(n); }
        l.sort((a, b) -> Integer.compare(a.daysLeft, b.daysLeft));
        return l;
    }

    public static String dateText(Next n) { return new SimpleDateFormat("dd MMM yyyy", Locale.US).format(new Date(n.date.getTimeInMillis())); }

    // ------------------------------------------------------------------ what happened in past years
    public static final class Year {
        public int year;
        public double runUp7, runUp3, after3;   // % : D-7→D, D-3→D, D→D+3
    }

    /** Pure: daily candles + month/day → one row per past year that is inside the data. */
    public static List<Year> study(Candles d, int month, int day) {
        List<Year> out = new ArrayList<>();
        if (d == null || d.n < 30) return out;
        Calendar first = Calendar.getInstance(), last = Calendar.getInstance();
        first.setTimeInMillis(d.time[0]);
        last.setTimeInMillis(d.time[d.n - 1]);
        for (int y = first.get(Calendar.YEAR); y <= last.get(Calendar.YEAR); y++) {
            long t = day(y, month, day).getTimeInMillis();
            int i = d.indexOf(t + 3600_000L);
            if (i < 8 || i + 3 >= d.n || Math.abs(d.time[i] - t) > 2 * 86_400_000L) continue;
            Year r = new Year();
            r.year = y;
            r.runUp7 = (d.close[i] / d.close[i - 7] - 1) * 100;
            r.runUp3 = (d.close[i] / d.close[i - 3] - 1) * 100;
            r.after3 = (d.close[i + 3] / d.close[i] - 1) * 100;
            out.add(r);
        }
        return out;
    }

    public static List<Year> studyCoin(String coin, Ev e) throws Exception {
        Candles d = Candles.fetch(coin + "USDT", "1d", 1000, true);
        if (e.dates != null) {
            Next n = next(e, System.currentTimeMillis());
            return n == null ? new ArrayList<>() : study(d, n.date.get(Calendar.MONTH) + 1, n.date.get(Calendar.DAY_OF_MONTH));
        }
        return study(d, e.month, e.day);
    }

    // ------------------------------------------------------------------ alerts
    /** Hourly check from the service: 7 / 3 / 1 din pehle aur event wale din. */
    public static void tick(Context c) {
        long now = System.currentTimeMillis();
        if (!Prefs.getBool(c, "evOn", true) || now - Prefs.getLong(c, "evRun") < 55 * 60_000L) return;
        Prefs.putLong(c, "evRun", now);
        for (Next n : upcoming(now)) {
            int[] leads = {7, 3, 1, 0};
            for (int lead : leads) {
                if (n.daysLeft != lead) continue;
                String key = "evN_" + n.ev.name + n.date.get(Calendar.YEAR) + "_" + lead;
                if (Prefs.getLong(c, key) > 0) continue;
                Prefs.putLong(c, key, now);
                String hist = "";
                try {
                    List<Year> ys = studyCoin(n.ev.coins[0], n.ev);
                    if (!ys.isEmpty()) {
                        StringBuilder sb = new StringBuilder(" · " + n.ev.coins[0] + " pichle saal: ");
                        for (Year y : ys) sb.append(y.year).append(String.format(Locale.US, " %+.0f%%  ", y.runUp7));
                        hist = sb.toString().trim() + " (event se 7 din pehle → event)";
                    }
                } catch (Exception ignored) { }
                String when = lead == 0 ? "AAJ hai" : lead + " din baqi";
                Notify.show(c, Prefs.N_CATALYST, ("ev" + key).hashCode(), n.ev.emoji + " " + n.ev.name + " — " + when,
                        String.join(" · ", n.ev.coins) + " par nazar rakhein. " + n.ev.note + hist + " Entry se pehle chart + stop zaroor dekhein.",
                        0xFFFACC15, MainActivity.TAB_MORE);
            }
        }
    }
}
