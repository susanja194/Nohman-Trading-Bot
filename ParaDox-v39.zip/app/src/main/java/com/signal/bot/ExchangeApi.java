package com.signal.bot;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * SPOT trading API for MEXC, Binance, Bybit, OKX and Gate. Only what the AutoPilot needs:
 *   free balance · market BUY with N USDT · market SELL of N coins · public last price.
 * No withdrawal / transfer call exists in this app — and the user is told to create keys WITHOUT withdrawal permission.
 * Every request is signed on the phone; the secret never leaves it.
 */
public abstract class ExchangeApi {
    public static final String[] NAMES = {"MEXC", "Binance", "Bybit", "OKX", "Gate"};

    public static final class Fill {
        public double qty, avg, quote;
        public String id = "";
        public boolean partialOrUnknown;
    }

    public static final class ApiError extends Exception {
        public final int code;
        public ApiError(int code, String msg) { super(msg); this.code = code; }
    }

    protected final String key, secret, pass;
    protected final Map<String, Double> stepCache = new HashMap<>();

    protected ExchangeApi(String key, String secret, String pass) {
        this.key = key == null ? "" : key.trim();
        this.secret = secret == null ? "" : secret.trim();
        this.pass = pass == null ? "" : pass.trim();
    }

    public abstract String name();
    /** Free (spendable) balance of an asset. */
    public abstract double free(String asset) throws Exception;
    /** Market buy spending `usdt` of quote currency. */
    public abstract Fill marketBuy(String coin, double usdt) throws Exception;
    /** Market sell of `qty` coins (rounded down to the exchange's step; never more than the free balance). */
    public abstract Fill marketSell(String coin, double qty) throws Exception;
    /** Public last price. */
    public abstract double last(String coin) throws Exception;

    public static ExchangeApi create(String name, String key, String secret, String pass) {
        switch (name) {
            case "MEXC": return new Mexc(key, secret, pass);
            case "Binance": return new BinanceX(key, secret, pass);
            case "Bybit": return new Bybit(key, secret, pass);
            case "OKX": return new Okx(key, secret, pass);
            case "Gate": return new Gate(key, secret, pass);
            default: return null;
        }
    }

    public static boolean needsPassphrase(String name) { return "OKX".equals(name); }

    /** Read-only connection test: returns a human line. Never places an order. */
    public String test() {
        try {
            double usdt = free("USDT");
            return "✅ Connected — " + name() + " USDT balance: " + String.format(Locale.US, "%.2f", usdt);
        } catch (Exception e) {
            return "❌ " + name() + ": " + e.getMessage();
        }
    }

    // ------------------------------------------------------------------ helpers
    static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format(Locale.US, "%02x", x));
        return sb.toString();
    }

    static byte[] hmacRaw(String algo, String secret, String data) throws Exception {
        Mac m = Mac.getInstance(algo);
        m.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), algo));
        return m.doFinal(data.getBytes(StandardCharsets.UTF_8));
    }

    public static String hmac256Hex(String secret, String data) throws Exception { return hex(hmacRaw("HmacSHA256", secret, data)); }
    static String hmac512Hex(String secret, String data) throws Exception { return hex(hmacRaw("HmacSHA512", secret, data)); }
    static String sha512Hex(String s) throws Exception { return hex(MessageDigest.getInstance("SHA-512").digest(s.getBytes(StandardCharsets.UTF_8))); }

    /** Rounds DOWN to a multiple of `step` (never spends / sells more than allowed). */
    public static double floorStep(double v, double step) {
        if (step <= 0) return v;
        double q = Math.floor(v / step + 1e-9);
        return q * step;
    }

    public static String plain(double v) {
        String s = new java.math.BigDecimal(v).setScale(10, java.math.RoundingMode.DOWN).stripTrailingZeros().toPlainString();
        return s;
    }

    public static double stepFromDecimals(int dec) { return Math.pow(10, -dec); }

    static String http(String method, String url, Map<String, String> headers, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(10_000);
        c.setReadTimeout(15_000);
        c.setRequestProperty("User-Agent", "ParaDox/39.0");
        if (headers != null) for (Map.Entry<String, String> e : headers.entrySet()) c.setRequestProperty(e.getKey(), e.getValue());
        if (body != null) {
            c.setDoOutput(true);
            try (OutputStream os = c.getOutputStream()) { os.write(body.getBytes(StandardCharsets.UTF_8)); }
        }
        int code = c.getResponseCode();
        java.io.InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
        StringBuilder sb = new StringBuilder();
        if (is != null) try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String l;
            while ((l = br.readLine()) != null) sb.append(l);
        }
        if (code >= 400) throw new ApiError(code, sb.length() > 300 ? sb.substring(0, 300) : sb.toString());
        return sb.toString();
    }

    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); } }

    static boolean precisionError(String m) {
        if (m == null) return false;
        String s = m.toLowerCase(Locale.US);
        return s.contains("precision") || s.contains("lot_size") || s.contains("lot size") || s.contains("scale") || s.contains("quantity scale")
                || s.contains("step") || s.contains("-1013") || s.contains("-1111") || s.contains("30004") || s.contains("51121") || s.contains("170137") || s.contains("170136");
    }

    // ================================================================== MEXC + Binance (same REST shape)
    abstract static class BinanceStyle extends ExchangeApi {
        long skew;
        BinanceStyle(String k, String s, String p) { super(k, s, p); }
        abstract String base();
        abstract String keyHeader();

        void sync() {
            try {
                JSONObject o = new JSONObject(http("GET", base() + "/api/v3/time", null, null));
                skew = o.getLong("serverTime") - System.currentTimeMillis();
            } catch (Exception ignored) { }
        }

        String signed(String method, String path, String params) throws Exception {
            if (skew == 0) sync();
            String q = (params == null || params.isEmpty() ? "" : params + "&") + "timestamp=" + (System.currentTimeMillis() + skew) + "&recvWindow=10000";
            String sig = hmac256Hex(secret, q);
            Map<String, String> h = new HashMap<>();
            h.put(keyHeader(), key);
            h.put("Content-Type", "application/json");
            return http(method, base() + path + "?" + q + "&signature=" + sig, h, method.equals("POST") ? "" : null);
        }

        @Override public double last(String coin) throws Exception {
            return new JSONObject(http("GET", base() + "/api/v3/ticker/price?symbol=" + coin + "USDT", null, null)).getDouble("price");
        }

        @Override public double free(String asset) throws Exception {
            JSONObject o = new JSONObject(signed("GET", "/api/v3/account", ""));
            JSONArray b = o.getJSONArray("balances");
            for (int i = 0; i < b.length(); i++) if (asset.equals(b.getJSONObject(i).optString("asset"))) return Double.parseDouble(b.getJSONObject(i).optString("free", "0"));
            return 0;
        }

        double step(String coin) {
            Double c = stepCache.get(coin);
            if (c != null) return c;
            double st = 0;
            try {
                JSONObject o = new JSONObject(http("GET", base() + "/api/v3/exchangeInfo?symbol=" + coin + "USDT", null, null));
                JSONObject s = o.getJSONArray("symbols").getJSONObject(0);
                JSONArray f = s.optJSONArray("filters");
                if (f != null) for (int i = 0; i < f.length(); i++)
                    if ("LOT_SIZE".equals(f.getJSONObject(i).optString("filterType"))) st = Double.parseDouble(f.getJSONObject(i).optString("stepSize", "0"));
                if (st <= 0 && s.has("baseAssetPrecision")) st = stepFromDecimals(s.getInt("baseAssetPrecision"));
            } catch (Exception ignored) { }
            if (st <= 0) st = 1e-6;
            stepCache.put(coin, st);
            return st;
        }

        Fill order(String coin, String idStr) throws Exception {
            Fill f = new Fill();
            f.id = idStr;
            for (int t = 0; t < 6; t++) {
                try {
                    JSONObject o = new JSONObject(signed("GET", "/api/v3/order", "symbol=" + coin + "USDT&orderId=" + idStr));
                    double q = Double.parseDouble(o.optString("executedQty", "0")), cq = Double.parseDouble(o.optString("cummulativeQuoteQty", "0"));
                    String st = o.optString("status");
                    if (q > 0 && (st.equals("FILLED") || t >= 3)) {
                        f.qty = q; f.quote = cq; f.avg = cq / q;
                        f.partialOrUnknown = !st.equals("FILLED");
                        return f;
                    }
                } catch (ApiError ignored) { }
                sleep(500);
            }
            f.partialOrUnknown = true;
            return f;
        }

        @Override public Fill marketBuy(String coin, double usdt) throws Exception {
            String r = signed("POST", "/api/v3/order", "symbol=" + coin + "USDT&side=BUY&type=MARKET&quoteOrderQty=" + plain(Math.floor(usdt * 100) / 100));
            JSONObject o = new JSONObject(r);
            return order(coin, o.get("orderId").toString());
        }

        @Override public Fill marketSell(String coin, double qty) throws Exception {
            double have = free(coin);
            double q = Math.min(qty, have);
            double st = step(coin);
            ApiError last = null;
            for (int attempt = 0; attempt < 4; attempt++) {
                double use = floorStep(q, st);
                if (use <= 0) throw new Exception("Bechne ke liye " + coin + " balance bohat kam (" + plain(have) + ")");
                try {
                    String r = signed("POST", "/api/v3/order", "symbol=" + coin + "USDT&side=SELL&type=MARKET&quantity=" + plain(use));
                    return order(coin, new JSONObject(r).get("orderId").toString());
                } catch (ApiError e) {
                    last = e;
                    if (!precisionError(e.getMessage())) throw e;
                    st = st * 10;   // coarser step and retry
                    stepCache.put(coin, st);
                }
            }
            throw last;
        }
    }

    static final class Mexc extends BinanceStyle {
        Mexc(String k, String s, String p) { super(k, s, p); }
        @Override public String name() { return "MEXC"; }
        @Override String base() { return "https://api.mexc.com"; }
        @Override String keyHeader() { return "X-MEXC-APIKEY"; }
    }

    static final class BinanceX extends BinanceStyle {
        BinanceX(String k, String s, String p) { super(k, s, p); }
        @Override public String name() { return "Binance"; }
        @Override String base() { return "https://api.binance.com"; }
        @Override String keyHeader() { return "X-MBX-APIKEY"; }
    }

    // ================================================================== Bybit v5
    static final class Bybit extends ExchangeApi {
        Bybit(String k, String s, String p) { super(k, s, p); }
        @Override public String name() { return "Bybit"; }
        static final String BASE = "https://api.bybit.com";

        String call(String method, String path, String query, String body) throws Exception {
            String ts = String.valueOf(System.currentTimeMillis()), recv = "10000";
            String payload = method.equals("GET") ? query : body;
            String sig = hmac256Hex(secret, ts + key + recv + payload);
            Map<String, String> h = new HashMap<>();
            h.put("X-BAPI-API-KEY", key); h.put("X-BAPI-TIMESTAMP", ts); h.put("X-BAPI-RECV-WINDOW", recv); h.put("X-BAPI-SIGN", sig);
            h.put("Content-Type", "application/json");
            String r = http(method, BASE + path + (method.equals("GET") && !query.isEmpty() ? "?" + query : ""), h, method.equals("POST") ? body : null);
            JSONObject o = new JSONObject(r);
            if (o.optInt("retCode", 0) != 0) throw new ApiError(200, "retCode " + o.optInt("retCode") + ": " + o.optString("retMsg"));
            return r;
        }

        @Override public double last(String coin) throws Exception {
            JSONObject o = new JSONObject(http("GET", BASE + "/v5/market/tickers?category=spot&symbol=" + coin + "USDT", null, null));
            return Double.parseDouble(o.getJSONObject("result").getJSONArray("list").getJSONObject(0).getString("lastPrice"));
        }

        @Override public double free(String asset) throws Exception {
            JSONObject o;
            try { o = new JSONObject(call("GET", "/v5/account/wallet-balance", "accountType=UNIFIED", null)); }
            catch (ApiError e) { o = new JSONObject(call("GET", "/v5/account/wallet-balance", "accountType=SPOT", null)); }
            JSONArray l = o.getJSONObject("result").getJSONArray("list");
            for (int i = 0; i < l.length(); i++) {
                JSONArray coins = l.getJSONObject(i).optJSONArray("coin");
                if (coins == null) continue;
                for (int j = 0; j < coins.length(); j++) {
                    JSONObject c = coins.getJSONObject(j);
                    if (asset.equals(c.optString("coin"))) {
                        double w = num(c, "walletBalance"), lk = num(c, "locked");
                        return Math.max(0, w - lk);
                    }
                }
            }
            return 0;
        }

        static double num(JSONObject o, String k) { try { return Double.parseDouble(o.optString(k, "0")); } catch (Exception e) { return 0; } }

        double step(String coin) {
            Double c = stepCache.get(coin);
            if (c != null) return c;
            double st = 0;
            try {
                JSONObject o = new JSONObject(http("GET", BASE + "/v5/market/instruments-info?category=spot&symbol=" + coin + "USDT", null, null));
                st = Double.parseDouble(o.getJSONObject("result").getJSONArray("list").getJSONObject(0).getJSONObject("lotSizeFilter").getString("basePrecision"));
            } catch (Exception ignored) { }
            if (st <= 0) st = 1e-6;
            stepCache.put(coin, st);
            return st;
        }

        Fill order(String id) throws Exception {
            Fill f = new Fill();
            f.id = id;
            for (int t = 0; t < 6; t++) {
                try {
                    JSONObject o = new JSONObject(call("GET", "/v5/order/realtime", "category=spot&orderId=" + id, null));
                    JSONArray l = o.getJSONObject("result").getJSONArray("list");
                    if (l.length() > 0) {
                        JSONObject x = l.getJSONObject(0);
                        double q = num(x, "cumExecQty"), v = num(x, "cumExecValue");
                        if (q > 0 && (x.optString("orderStatus").equals("Filled") || t >= 3)) {
                            f.qty = q; f.quote = v; f.avg = v / q; f.partialOrUnknown = !x.optString("orderStatus").equals("Filled");
                            return f;
                        }
                    }
                } catch (ApiError ignored) { }
                sleep(500);
            }
            f.partialOrUnknown = true;
            return f;
        }

        @Override public Fill marketBuy(String coin, double usdt) throws Exception {
            String body = "{\"category\":\"spot\",\"symbol\":\"" + coin + "USDT\",\"side\":\"Buy\",\"orderType\":\"Market\",\"qty\":\"" + plain(Math.floor(usdt * 100) / 100) + "\",\"marketUnit\":\"quoteCoin\"}";
            JSONObject o = new JSONObject(call("POST", "/v5/order/create", "", body));
            return order(o.getJSONObject("result").getString("orderId"));
        }

        @Override public Fill marketSell(String coin, double qty) throws Exception {
            double q = floorStep(Math.min(qty, free(coin)), step(coin));
            if (q <= 0) throw new Exception("Bechne ke liye " + coin + " balance bohat kam");
            String body = "{\"category\":\"spot\",\"symbol\":\"" + coin + "USDT\",\"side\":\"Sell\",\"orderType\":\"Market\",\"qty\":\"" + plain(q) + "\",\"marketUnit\":\"baseCoin\"}";
            JSONObject o = new JSONObject(call("POST", "/v5/order/create", "", body));
            return order(o.getJSONObject("result").getString("orderId"));
        }
    }

    // ================================================================== OKX v5
    static final class Okx extends ExchangeApi {
        Okx(String k, String s, String p) { super(k, s, p); }
        @Override public String name() { return "OKX"; }
        static final String BASE = "https://www.okx.com";

        static String iso() {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            return f.format(new Date());
        }

        String call(String method, String path, String body) throws Exception {
            String ts = iso();
            String sig = android.util.Base64.encodeToString(hmacRaw("HmacSHA256", secret, ts + method + path + (body == null ? "" : body)), android.util.Base64.NO_WRAP);
            Map<String, String> h = new HashMap<>();
            h.put("OK-ACCESS-KEY", key); h.put("OK-ACCESS-SIGN", sig); h.put("OK-ACCESS-TIMESTAMP", ts); h.put("OK-ACCESS-PASSPHRASE", pass);
            h.put("Content-Type", "application/json");
            String r = http(method, BASE + path, h, body);
            JSONObject o = new JSONObject(r);
            if (!"0".equals(o.optString("code", "0"))) {
                String m = o.optString("msg");
                JSONArray d = o.optJSONArray("data");
                if (d != null && d.length() > 0) m += " " + d.optJSONObject(0).optString("sMsg");
                throw new ApiError(200, "code " + o.optString("code") + ": " + m);
            }
            return r;
        }

        @Override public double last(String coin) throws Exception {
            JSONObject o = new JSONObject(http("GET", BASE + "/api/v5/market/ticker?instId=" + coin + "-USDT", null, null));
            return Double.parseDouble(o.getJSONArray("data").getJSONObject(0).getString("last"));
        }

        @Override public double free(String asset) throws Exception {
            JSONObject o = new JSONObject(call("GET", "/api/v5/account/balance?ccy=" + asset, null));
            JSONArray d = o.getJSONArray("data");
            if (d.length() == 0) return 0;
            JSONArray det = d.getJSONObject(0).optJSONArray("details");
            if (det == null) return 0;
            for (int i = 0; i < det.length(); i++) if (asset.equals(det.getJSONObject(i).optString("ccy"))) {
                String a = det.getJSONObject(i).optString("availBal", "0");
                return a.isEmpty() ? 0 : Double.parseDouble(a);
            }
            return 0;
        }

        double step(String coin) {
            Double c = stepCache.get(coin);
            if (c != null) return c;
            double st = 0;
            try {
                JSONObject o = new JSONObject(http("GET", BASE + "/api/v5/public/instruments?instType=SPOT&instId=" + coin + "-USDT", null, null));
                st = Double.parseDouble(o.getJSONArray("data").getJSONObject(0).getString("lotSz"));
            } catch (Exception ignored) { }
            if (st <= 0) st = 1e-6;
            stepCache.put(coin, st);
            return st;
        }

        Fill order(String coin, String id) throws Exception {
            Fill f = new Fill();
            f.id = id;
            for (int t = 0; t < 6; t++) {
                try {
                    JSONObject o = new JSONObject(call("GET", "/api/v5/trade/order?instId=" + coin + "-USDT&ordId=" + id, null));
                    JSONObject x = o.getJSONArray("data").getJSONObject(0);
                    String fs = x.optString("accFillSz", "0"), ap = x.optString("avgPx", "0");
                    double q = fs.isEmpty() ? 0 : Double.parseDouble(fs), avg = ap.isEmpty() ? 0 : Double.parseDouble(ap);
                    if (q > 0 && avg > 0 && (x.optString("state").equals("filled") || t >= 3)) {
                        f.qty = q; f.avg = avg; f.quote = q * avg; f.partialOrUnknown = !x.optString("state").equals("filled");
                        return f;
                    }
                } catch (ApiError ignored) { }
                sleep(500);
            }
            f.partialOrUnknown = true;
            return f;
        }

        @Override public Fill marketBuy(String coin, double usdt) throws Exception {
            String body = "{\"instId\":\"" + coin + "-USDT\",\"tdMode\":\"cash\",\"side\":\"buy\",\"ordType\":\"market\",\"sz\":\"" + plain(Math.floor(usdt * 100) / 100) + "\",\"tgtCcy\":\"quote_ccy\"}";
            JSONObject o = new JSONObject(call("POST", "/api/v5/trade/order", body));
            return order(coin, o.getJSONArray("data").getJSONObject(0).getString("ordId"));
        }

        @Override public Fill marketSell(String coin, double qty) throws Exception {
            double q = floorStep(Math.min(qty, free(coin)), step(coin));
            if (q <= 0) throw new Exception("Bechne ke liye " + coin + " balance bohat kam");
            String body = "{\"instId\":\"" + coin + "-USDT\",\"tdMode\":\"cash\",\"side\":\"sell\",\"ordType\":\"market\",\"sz\":\"" + plain(q) + "\",\"tgtCcy\":\"base_ccy\"}";
            JSONObject o = new JSONObject(call("POST", "/api/v5/trade/order", body));
            return order(coin, o.getJSONArray("data").getJSONObject(0).getString("ordId"));
        }
    }

    // ================================================================== Gate v4
    static final class Gate extends ExchangeApi {
        Gate(String k, String s, String p) { super(k, s, p); }
        @Override public String name() { return "Gate"; }
        static final String BASE = "https://api.gateio.ws", PREFIX = "/api/v4";

        String call(String method, String path, String query, String body) throws Exception {
            String ts = String.valueOf(System.currentTimeMillis() / 1000);
            String b = body == null ? "" : body;
            String sig = hmac512Hex(secret, method + "\n" + PREFIX + path + "\n" + query + "\n" + sha512Hex(b) + "\n" + ts);
            Map<String, String> h = new HashMap<>();
            h.put("KEY", key); h.put("SIGN", sig); h.put("Timestamp", ts);
            h.put("Accept", "application/json"); h.put("Content-Type", "application/json");
            return http(method, BASE + PREFIX + path + (query.isEmpty() ? "" : "?" + query), h, body);
        }

        @Override public double last(String coin) throws Exception {
            JSONArray a = new JSONArray(http("GET", BASE + PREFIX + "/spot/tickers?currency_pair=" + coin + "_USDT", null, null));
            return Double.parseDouble(a.getJSONObject(0).getString("last"));
        }

        @Override public double free(String asset) throws Exception {
            JSONArray a = new JSONArray(call("GET", "/spot/accounts", "currency=" + asset, null));
            for (int i = 0; i < a.length(); i++) if (asset.equals(a.getJSONObject(i).optString("currency"))) return Double.parseDouble(a.getJSONObject(i).optString("available", "0"));
            return 0;
        }

        double step(String coin) {
            Double c = stepCache.get(coin);
            if (c != null) return c;
            double st = 0;
            try {
                JSONObject o = new JSONObject(http("GET", BASE + PREFIX + "/spot/currency_pairs/" + coin + "_USDT", null, null));
                st = stepFromDecimals(o.getInt("amount_precision"));
            } catch (Exception ignored) { }
            if (st <= 0) st = 1e-6;
            stepCache.put(coin, st);
            return st;
        }

        Fill order(String coin, String id) throws Exception {
            Fill f = new Fill();
            f.id = id;
            for (int t = 0; t < 6; t++) {
                try {
                    JSONObject x = new JSONObject(call("GET", "/spot/orders/" + id, "currency_pair=" + coin + "_USDT", null));
                    double ft = Bybit.num(x, "filled_total"), avg = Bybit.num(x, "avg_deal_price");
                    if (avg <= 0) avg = Bybit.num(x, "fill_price");
                    if (ft > 0 && avg > 0 && (x.optString("status").equals("closed") || t >= 3)) {
                        f.quote = ft; f.avg = avg; f.qty = ft / avg; f.partialOrUnknown = !x.optString("status").equals("closed");
                        return f;
                    }
                } catch (ApiError ignored) { }
                sleep(500);
            }
            f.partialOrUnknown = true;
            return f;
        }

        @Override public Fill marketBuy(String coin, double usdt) throws Exception {
            String body = "{\"currency_pair\":\"" + coin + "_USDT\",\"type\":\"market\",\"account\":\"spot\",\"side\":\"buy\",\"amount\":\"" + plain(Math.floor(usdt * 100) / 100) + "\",\"time_in_force\":\"ioc\"}";
            JSONObject o = new JSONObject(call("POST", "/spot/orders", "", body));
            return order(coin, o.getString("id"));
        }

        @Override public Fill marketSell(String coin, double qty) throws Exception {
            double q = floorStep(Math.min(qty, free(coin)), step(coin));
            if (q <= 0) throw new Exception("Bechne ke liye " + coin + " balance bohat kam");
            String body = "{\"currency_pair\":\"" + coin + "_USDT\",\"type\":\"market\",\"account\":\"spot\",\"side\":\"sell\",\"amount\":\"" + plain(q) + "\",\"time_in_force\":\"ioc\"}";
            JSONObject o = new JSONObject(call("POST", "/spot/orders", "", body));
            return order(coin, o.getString("id"));
        }
    }
}
