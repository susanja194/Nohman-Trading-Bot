package com.signal.bot;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * DIP HUNTER — woh coins jo bohat gir chuke hain lekin wapas upar jane ki nishaniyan dikha rahe hain.
 * "Girna" akela signal nahi: sirf wahi coin aate hain jin mein (1) liquid volume hai, (2) 30-din ke high se bohat neeche hain,
 * aur (3) bechne ka zor khatam hone ke saboot hain: oversold RSI, washout volume, naya low nahi bana, buyers wapas aaye (order flow),
 * hammer candle. Jo coin abhi bhi naye low bana raha ho "girta chaqu" (falling knife) likh kar score gira diya jata hai.
 * Score = reversal ka saboot (probability nahi).
 */
public final class DipHunter {
    private DipHunter() {}

    public static final class Pick {
        public String coin;
        public double price, change24h, vol24h, dropFromHigh, rsiD, rsiH, buyPct, low10, high30, stop, t1, t2, t3, rr1;
        public int score;
        public boolean knife;
        public final List<String> why = new ArrayList<>();
        public String label() { return knife ? "⚠️ Girta chaqu — abhi mat pakdein" : score >= 70 ? "🟢 Reversal ke mazboot saboot" : score >= 55 ? "🟡 Watch — thori aur tasdeeq chahiye" : "⚪ Kamzor"; }
    }

    static double ema(double[] v, int end, int p) {
        double k = 2.0 / (p + 1), e = v[Math.max(0, end - 3 * p)];
        for (int i = Math.max(0, end - 3 * p) + 1; i <= end; i++) e = v[i] * k + e * (1 - k);
        return e;
    }

    /** Pure scorer: daily candles (≥45) + hourly candles (≥48). null if it has not fallen enough / not enough data. */
    public static Pick evaluate(String coin, Candles d, Candles h, double vol24h, double change24h, double minDropPct) {
        if (d == null || h == null || d.n < 45 || h.n < 48) return null;
        int di = d.n - 1, hi = h.n - 1;
        double price = h.close[hi];
        double high30 = 0, low10 = Double.MAX_VALUE;
        for (int i = di - 29; i <= di; i++) high30 = Math.max(high30, d.high[i]);
        for (int i = di - 9; i <= di; i++) low10 = Math.min(low10, d.low[i]);
        low10 = Math.min(low10, price);
        double drop = (high30 - price) / high30 * 100;
        if (drop < minDropPct) return null;
        Pick p = new Pick();
        p.coin = coin; p.price = price; p.change24h = change24h; p.vol24h = vol24h; p.dropFromHigh = drop; p.high30 = high30; p.low10 = low10;
        p.rsiD = HistoryCompare.rsi(d.close, di, 14);
        p.rsiH = HistoryCompare.rsi(h.close, hi, 14);
        double sc = Math.min(20, (drop - minDropPct) * 0.6 + 5);
        p.why.add(String.format(Locale.US, "30-din ke high se %.0f%% neeche (high $%s → ab $%s)", drop, Fmt.price(high30), Fmt.price(price)));
        if (p.rsiD < 30) { sc += 15; p.why.add(String.format(Locale.US, "Daily RSI %.0f — bohat oversold", p.rsiD)); }
        else if (p.rsiD < 38) { sc += 8; p.why.add(String.format(Locale.US, "Daily RSI %.0f — oversold ke qareeb", p.rsiD)); }
        // washout: one very heavy daily candle in the last 5 days vs the 30-day average
        double av = 0;
        for (int i = di - 34; i < di - 4; i++) av += d.vol[i];
        av /= 30;
        double mx = 0;
        for (int i = di - 4; i <= di; i++) mx = Math.max(mx, d.vol[i]);
        if (av > 0 && mx >= 2.5 * av) { sc += 15; p.why.add(String.format(Locale.US, "Washout volume: ek din ka volume normal ka %.1fx — kamzor haath nikal gaye hon ge", mx / av)); }
        // no new low in the last 6 hours although the low was set earlier
        double l6 = Double.MAX_VALUE, lPrev = Double.MAX_VALUE;
        for (int i = hi - 5; i <= hi; i++) l6 = Math.min(l6, h.low[i]);
        for (int i = hi - 47; i < hi - 5; i++) lPrev = Math.min(lPrev, h.low[i]);
        boolean base = l6 >= lPrev * 0.999;
        if (base) { sc += 15; p.why.add("Pichle 6 ghante mein naya low nahi bana — girawat ruk gayi lagti hai"); }
        // order flow on the hourly candles
        OrderFlow.Result fl = OrderFlow.analyze(h);
        if (fl.ok && fl.real) {
            p.buyPct = fl.avg3BuyPct;
            if (fl.avg3BuyPct >= 53 || fl.action.equals("BUY")) { sc += 15; p.why.add(String.format(Locale.US, "Order flow: aakhri 3 ghante buyers %.0f%% — kharidar wapas aa rahe hain", fl.avg3BuyPct)); }
            else if (fl.avg3BuyPct <= 46) { sc -= 10; p.why.add(String.format(Locale.US, "Order flow: sellers abhi bhi haavi (buyers %.0f%%)", fl.avg3BuyPct)); }
        }
        // hammer on daily (last 3 days): long lower wick
        boolean ham = false;
        for (int i = di - 2; i <= di; i++) {
            double body = Math.abs(d.close[i] - d.open[i]), lw = Math.min(d.close[i], d.open[i]) - d.low[i], rg = d.high[i] - d.low[i];
            if (rg > 0 && lw >= 2 * Math.max(body, rg * 0.05) && lw / rg >= 0.5) ham = true;
        }
        if (ham) { sc += 10; p.why.add("Daily hammer candle — neeche se kharidari ne rad kiya"); }
        // reclaim of hourly EMA20
        double e20 = ema(h.close, hi, 20);
        if (price > e20 && h.close[hi - 3] < ema(h.close, hi - 3, 20) * 1.005) { sc += 10; p.why.add("Price 1h EMA20 ke upar wapas aa gayi"); }
        // support: price close to the 10-day low (cheap, defined risk)
        if ((price - low10) / low10 < 0.06) { sc += 5; p.why.add("Price 10-din ke low ke qareeb — stop chhota rakha ja sakta hai"); }
        // falling knife
        boolean newLow = h.low[hi] <= lPrev && !base;
        if (newLow && (!fl.real || fl.avg3BuyPct < 50)) { p.knife = true; sc -= 25; p.why.add("⚠️ Abhi bhi naye low ban rahe hain aur sellers haavi — reversal abhi saabit nahi"); }
        // levels: retracement of the drop, stop under the recent low
        p.stop = Math.min(low10, l6) * 0.985;
        double move = high30 - low10;
        p.t1 = low10 + move * 0.382;
        p.t2 = low10 + move * 0.5;
        p.t3 = low10 + move * 0.618;
        double risk = price - p.stop;
        p.rr1 = risk > 0 ? (p.t1 - price) / risk : 0;
        if (p.rr1 < 1.2) { sc -= 8; p.why.add(String.format(Locale.US, "Reward:risk TP1 par sirf %.1f — thora sa late", p.rr1)); }
        p.score = (int) Math.max(0, Math.min(100, Math.round(sc)));
        return p;
    }

    public static volatile long lastRun;
    public static volatile List<Pick> last = new ArrayList<>();

    /** Network scan of the most liquid coins. Takes ~5–15 s. */
    public static List<Pick> scan(int coins, double minDropPct) throws Exception {
        JSONArray a = new JSONArray(Scanner.get("/api/v3/ticker/24hr?type=MINI"));
        final List<JSONObject> l = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i);
            if (Scanner.isTradable(o.optString("symbol")) && o.optDouble("quoteVolume", 0) >= 3_000_000) l.add(o);
        }
        Collections.sort(l, (x, y) -> Double.compare(y.optDouble("quoteVolume", 0), x.optDouble("quoteVolume", 0)));
        ExecutorService ex = Executors.newFixedThreadPool(6);
        List<Future<Pick>> fs = new ArrayList<>();
        for (int i = 0; i < l.size() && i < coins; i++) {
            final JSONObject o = l.get(i);
            final double minDrop = minDropPct;
            fs.add(ex.submit(() -> {
                try {
                    String sym = o.optString("symbol");
                    Candles d = Candles.fetch(sym, "1d", 60, true);
                    if (d.n < 45) return null;
                    double hi = 0;
                    for (int k = d.n - 30; k < d.n; k++) hi = Math.max(hi, d.high[k]);
                    double px = o.optDouble("lastPrice", d.close[d.n - 1]);
                    if ((hi - px) / hi * 100 < minDrop) return null;   // cheap pre-filter before the hourly request
                    Candles h = Candles.fetch(sym, "1h", 100, true);
                    double open = o.optDouble("openPrice", px);
                    return evaluate(sym.substring(0, sym.length() - 4), d, h, o.optDouble("quoteVolume", 0), open > 0 ? (px / open - 1) * 100 : 0, minDrop);
                } catch (Exception e) {
                    return null;
                }
            }));
        }
        List<Pick> out = new ArrayList<>();
        for (Future<Pick> f : fs) {
            try { Pick p = f.get(40, TimeUnit.SECONDS); if (p != null) out.add(p); } catch (Exception ignored) { }
        }
        ex.shutdownNow();
        Collections.sort(out, (x, y) -> Double.compare(y.score - (y.knife ? 30 : 0), x.score - (x.knife ? 30 : 0)));
        last = out;
        lastRun = System.currentTimeMillis();
        return out;
    }

    public static boolean on(Context c) { return Prefs.getBool(c, "dipOn", true); }

    /** Background: every 45 min, alert once per coin per 24 h for strong, non-knife reversals. */
    public static void tick(Context c) {
        if (!on(c)) return;
        long now = System.currentTimeMillis();
        if (now - Prefs.getLong(c, "dipRun") < 45 * 60_000L) return;
        Prefs.putLong(c, "dipRun", now);
        try {
            for (Pick p : scan(120, 30)) {
                if (p.knife || p.score < 72) continue;
                if (now - Prefs.getLong(c, "dipN_" + p.coin) < 24 * 3600_000L) continue;
                Prefs.putLong(c, "dipN_" + p.coin, now);
                Notify.show(c, Prefs.N_HUNT, ("dip" + p.coin).hashCode(), "🩸→🟢 Dip reversal: " + p.coin,
                        String.format(Locale.US, "%.0f%% gir kar sambhal raha hai · score %d/100 · stop $%s · TP1 $%s", p.dropFromHigh, p.score, Fmt.price(p.stop), Fmt.price(p.t1)),
                        0xFF0ECB81, MainActivity.TAB_MORE);
            }
        } catch (Exception ignored) { }
    }
}
