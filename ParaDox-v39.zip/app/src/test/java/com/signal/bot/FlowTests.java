package com.signal.bot;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

import static org.junit.Assert.assertEquals;

/** v39 checks: order flow, exchange signing helpers, AutoPilot engine, entry gate, history compare, dip hunter, events, hack classifier. */
public class FlowTests {
    static int pass, fail;

    static void check(String name, boolean ok, String info) {
        if (ok) pass++; else fail++;
        System.out.println((ok ? "PASS " : "FAIL ") + name + (info.isEmpty() ? "" : " — " + info));
    }

    @Test
    public void allChecksPass() {
        pass = 0; fail = 0;
        run();
        assertEquals("failed checks", 0, fail);
    }

    public static void main(String[] a) { run(); System.out.println(pass + " pass, " + fail + " fail"); }

    static Candles series(int n, double start, double drift, double noise, long seed, long ms) {
        Random rnd = new Random(seed);
        Candles c = Candles.create(n);
        double p = start;
        for (int i = 0; i < n; i++) {
            double o = p, cl = p * (1 + drift + (rnd.nextDouble() - 0.5) * noise);
            c.time[i] = 1_600_000_000_000L + i * ms;
            c.open[i] = o; c.close[i] = cl;
            c.high[i] = Math.max(o, cl) * (1 + rnd.nextDouble() * noise / 3);
            c.low[i] = Math.min(o, cl) * (1 - rnd.nextDouble() * noise / 3);
            c.vol[i] = 1000 + rnd.nextDouble() * 200;
            c.takerBuy[i] = c.vol[i] * (0.45 + rnd.nextDouble() * 0.1);
            c.quoteVol[i] = c.vol[i] * cl;
            p = cl;
        }
        return c;
    }

    static void run() {
        // ---------------------------------------------------------------- signing helpers
        try {
            check("HMAC-SHA256 known vector", ExchangeApi.hmac256Hex("key", "The quick brown fox jumps over the lazy dog")
                    .equals("f7bc83f430538424b13298e6aa6fb143ef4d59a14946175997479dbc2d1a3cd8"), "");
            check("SHA512 hex length", ExchangeApi.sha512Hex("").length() == 128, "");
        } catch (Exception e) { check("hmac", false, e.toString()); }
        check("floorStep rounds DOWN", Math.abs(ExchangeApi.floorStep(1.2349, 0.01) - 1.23) < 1e-9 && Math.abs(ExchangeApi.floorStep(0.3, 0.1) - 0.3) < 1e-9, "");
        check("plain() has no exponent", !ExchangeApi.plain(0.00000123).contains("E") && ExchangeApi.plain(12.5).equals("12.5"), ExchangeApi.plain(0.00000123));
        check("KeyVault.mask hides the middle", KeyVault.mask("abcd1234efgh9z").equals("abcd…9z") || KeyVault.mask("abcd1234efgh9z").startsWith("abcd…"), KeyVault.mask("abcd1234efgh9z"));
        check("OrderFlow.k formats", OrderFlow.k(1234).equals("1.2K") && OrderFlow.k(2_500_000).equals("2.5M") && OrderFlow.k(0.05).equals("0.05"), OrderFlow.k(1234) + " " + OrderFlow.k(2_500_000));

        // ---------------------------------------------------------------- order flow
        Candles up = series(120, 100, 0.0005, 0.01, 1, 3600_000L);
        for (int i = 100; i < 120; i++) up.takerBuy[i] = up.vol[i] * 0.70;   // buyers dominate the last 20 candles
        OrderFlow.Result fu = OrderFlow.analyze(up);
        check("flow: buyers dominating → BUY", fu.ok && fu.real && fu.action.equals("BUY") && fu.score >= 35, fu.action + " " + fu.score);
        Candles dn = series(120, 100, -0.0005, 0.01, 2, 3600_000L);
        for (int i = 100; i < 120; i++) dn.takerBuy[i] = dn.vol[i] * 0.30;
        OrderFlow.Result fd = OrderFlow.analyze(dn);
        check("flow: sellers dominating → SELL", fd.action.equals("SELL") && fd.score <= -35, fd.action + " " + fd.score);
        Candles fake = series(120, 100, 0, 0.01, 3, 3600_000L);
        for (int i = 0; i < fake.n; i++) fake.takerBuy[i] = fake.vol[i] / 2;
        OrderFlow.Result ff = OrderFlow.analyze(fake);
        check("flow: no taker data (MEXC) → not real, no signal", !ff.real && ff.action.equals("WAIT"), ff.headline);
        // absorption: last candle heavy selling, big volume, yet it closes high with a tiny range
        Candles ab = series(60, 100, 0, 0.01, 4, 3600_000L);
        int l = ab.n - 1;
        ab.open[l] = 100; ab.close[l] = 100.05; ab.high[l] = 100.1; ab.low[l] = 99.95; ab.vol[l] = 3000; ab.takerBuy[l] = 3000 * 0.30;
        OrderFlow.Result fa = OrderFlow.analyze(ab);
        boolean absorb = false;
        for (String s : fa.lines) if (s.contains("Absorption") && s.startsWith("🟢")) absorb = true;
        check("flow: heavy selling that price absorbs → bullish absorption line", absorb, fa.score + " " + fa.lines);
        // delta array consistency
        check("flow: delta = buy − sell, CVD accumulates", Math.abs(fu.delta[5] - (fu.buy[5] - fu.sell[5])) < 1e-9
                && Math.abs(fu.cvd[5] - fu.cvd[4] - fu.delta[5]) < 1e-9, "");
        // footprint
        JSONArray tr = new JSONArray();
        try {
            double[][] t = {{100, 5, 0}, {100, 1, 1}, {101, 2, 0}, {101, 9, 0}, {102, 1, 1}, {102, 8, 1}, {103, 4, 0}, {99, 3, 1}};
            for (double[] x : t) tr.put(new JSONObject().put("p", String.valueOf(x[0])).put("q", String.valueOf(x[1])).put("m", x[2] == 1));
            OrderFlow.Footprint f = OrderFlow.footprintFrom(tr, 4);
            check("footprint: totals add up (buy 20 / sell 13)", Math.abs(f.totalBuy - 20) < 1e-9 && Math.abs(f.totalSell - 13) < 1e-9, f.totalBuy + "/" + f.totalSell);
            int pocs = 0;
            for (OrderFlow.Level lv : f.levels) if (lv.poc) pocs++;
            check("footprint: exactly one point of control, high price first", pocs == 1 && f.levels.get(0).price > f.levels.get(f.levels.size() - 1).price, "");
        } catch (Exception e) { check("footprint", false, e.toString()); }

        // ---------------------------------------------------------------- AutoPilot engine
        AutoPilot.Pos p = new AutoPilot.Pos();
        p.coin = "TST"; p.qty = 30; p.entry = 100; p.cost = 3000; p.sl = 95; p.tp1 = 105; p.tp2 = 110; p.tp3 = 120; p.openT = 0;
        AutoPilot.PaperBroker pb = new AutoPilot.PaperBroker(100);
        long now = 3600_000L;
        AutoPilot.step(p, 99, now, 72, pb);
        check("autopilot: no event between SL and TP1", !p.closed && p.stage == 0 && p.qty == 30, "");
        pb.price = 105.5;
        List<String> ev = AutoPilot.step(p, 105.5, now, 72, pb);
        check("autopilot: TP1 sells 1/3 and moves stop to break-even", p.stage == 1 && Math.abs(p.qty - 20) < 1e-9 && p.sl >= 100 && ev.size() == 1, p.stage + " qty " + p.qty + " sl " + p.sl);
        pb.price = 99.9;
        AutoPilot.step(p, 99.9, now, 72, pb);
        check("autopilot: after TP1 price back to entry → break-even exit, closed", p.closed && p.exitWhy.contains("Break-even"), p.exitWhy);
        check("autopilot: break-even exit still shows a small profit from TP1", p.pnl() > -50, String.format("%.2f", p.pnl()));
        // full run to TP3
        AutoPilot.Pos q = new AutoPilot.Pos();
        q.coin = "TST"; q.qty = 30; q.entry = 100; q.cost = 3000; q.sl = 95; q.tp1 = 105; q.tp2 = 110; q.tp3 = 120; q.openT = 0;
        for (double px : new double[]{101, 106, 111, 121}) { pb.price = px; AutoPilot.step(q, px, now, 72, pb); }
        check("autopilot: TP1→TP2→TP3 closes with profit", q.closed && q.pnl() > 0 && q.exitWhy.contains("TP3"), q.exitWhy + " " + q.pnl());
        // gap through two levels in one tick
        AutoPilot.Pos g = new AutoPilot.Pos();
        g.coin = "TST"; g.qty = 30; g.entry = 100; g.cost = 3000; g.sl = 95; g.tp1 = 105; g.tp2 = 110; g.tp3 = 120; g.openT = 0;
        pb.price = 111;
        AutoPilot.step(g, 111, now, 72, pb);
        check("autopilot: price gaps over TP1 and TP2 → both handled in order", g.stage == 2 && g.sl >= 105, g.stage + " sl " + g.sl);
        // stop-loss at once
        AutoPilot.Pos s = new AutoPilot.Pos();
        s.coin = "TST"; s.qty = 30; s.entry = 100; s.cost = 3000; s.sl = 95; s.tp1 = 105; s.tp2 = 110; s.tp3 = 120; s.openT = 0;
        pb.price = 94;
        AutoPilot.step(s, 94, now, 72, pb);
        check("autopilot: stop-loss sells everything, loss ≈ 6% + costs", s.closed && s.pnl() < -150 && s.pnl() > -230 && s.exitWhy.contains("Stop"), String.format("%.1f", s.pnl()));
        // time stop
        AutoPilot.Pos tm = new AutoPilot.Pos();
        tm.coin = "TST"; tm.qty = 30; tm.entry = 100; tm.cost = 3000; tm.sl = 95; tm.tp1 = 105; tm.tp2 = 110; tm.tp3 = 120; tm.openT = 0;
        pb.price = 101;
        AutoPilot.step(tm, 101, 73 * 3600_000L, 72, pb);
        check("autopilot: time stop after max hold", tm.closed && tm.exitWhy.contains("Time"), tm.exitWhy);
        // broker failure must not close the position and must be retried
        AutoPilot.Broker bad = new AutoPilot.Broker() {
            @Override public ExchangeApi.Fill buy(String c, double u) throws Exception { throw new Exception("down"); }
            @Override public ExchangeApi.Fill sell(String c, double qq) throws Exception { throw new Exception("exchange down"); }
        };
        AutoPilot.Pos bp = new AutoPilot.Pos();
        bp.coin = "TST"; bp.qty = 30; bp.entry = 100; bp.cost = 3000; bp.sl = 95; bp.tp1 = 105; bp.tp2 = 110; bp.tp3 = 120; bp.openT = 0;
        List<String> be = AutoPilot.step(bp, 94, now, 72, bad);
        check("autopilot: failed sell keeps the position open and counts the error", !bp.closed && bp.errs == 1 && bp.qty == 30 && be.get(0).contains("masla"), be.toString());
        // tiny leftover is sold together
        AutoPilot.Pos dust = new AutoPilot.Pos();
        dust.coin = "TST"; dust.qty = 0.05; dust.entry = 100; dust.cost = 5; dust.sl = 95; dust.tp1 = 105; dust.tp2 = 110; dust.tp3 = 120; dust.openT = 0;
        pb.price = 106;
        AutoPilot.step(dust, 106, now, 72, pb);
        check("autopilot: leftover below exchange minimum is sold in full", dust.closed || dust.qty < 0.04, dust.qty + "");
        // json round trip
        try {
            AutoPilot.Pos r = AutoPilot.Pos.from(new JSONObject(p.json().toString()));
            check("autopilot: position survives save/load", r.coin.equals("TST") && r.closed == p.closed && Math.abs(r.proceeds - p.proceeds) < 1e-6 && r.exitWhy.equals(p.exitWhy), "");
        } catch (Exception e) { check("pos json", false, e.toString()); }

        // ---------------------------------------------------------------- entry gate
        TradeAgent.Verdict v = new TradeAgent.Verdict();
        v.action = TradeAgent.BUY_NOW; v.buy = 5; v.sell = 0; v.entryLo = 99; v.entryHi = 101; v.sl = 96; v.tp1 = 104; v.tp2 = 108; v.tp3 = 112;
        OrderFlow.Result of = new OrderFlow.Result();
        of.ok = true; of.real = true; of.action = "BUY"; of.score = 40;
        check("gate: everything agrees → go", AutoPilot.entryGate(v, of, 50e6, 5, true, 100) == null, String.valueOf(AutoPilot.entryGate(v, of, 50e6, 5, true, 100)));
        check("gate: too few judges → no", AutoPilot.entryGate(v, of, 50e6, 6, true, 100) != null, "");
        of.action = "SELL"; of.score = -50;
        check("gate: order flow against → no", String.valueOf(AutoPilot.entryGate(v, of, 50e6, 5, true, 100)).contains("Order flow"), "");
        check("gate: order flow ignored when the switch is off", AutoPilot.entryGate(v, of, 50e6, 5, false, 100) == null, "");
        of.action = "BUY"; of.score = 40;
        check("gate: illiquid coin → no", AutoPilot.entryGate(v, of, 500_000, 5, true, 100) != null, "");
        check("gate: price ran away → no chase", AutoPilot.entryGate(v, of, 50e6, 5, true, 104).contains("chase"), "");
        check("gate: slightly above zone → wait", String.valueOf(AutoPilot.entryGate(v, of, 50e6, 5, true, 101.6)).startsWith("WAIT"), "");
        check("gate: below the stop → no", AutoPilot.entryGate(v, of, 50e6, 5, true, 95) != null, "");
        v.sell = 2;
        check("gate: two judges against → no", AutoPilot.entryGate(v, of, 50e6, 5, true, 100) != null, "");
        v.sell = 0; v.action = TradeAgent.NO_TRADE;
        check("gate: Agent says no trade → no", AutoPilot.entryGate(v, of, 50e6, 5, true, 100) != null, "");

        // ---------------------------------------------------------------- history compare
        Candles h = series(500, 100, 0.0004, 0.04, 7, 86_400_000L);
        HistoryCompare.Result hr = HistoryCompare.analyze("TST", h, "din", 3, 7, 14);
        boolean leak = false;
        for (HistoryCompare.Analog a : hr.top) if (a.idx + 14 >= h.n - 1) leak = true;
        check("history: finds ≥5 analogs, none uses data from the future", hr.ok && hr.n >= 5 && !leak, hr.headline);
        check("history: win% within 0..100 and best ≥ worst", hr.win2 >= 0 && hr.win2 <= 100 && hr.best2 >= hr.worst2, "");
        check("history: too little data refused", !HistoryCompare.analyze("X", series(100, 1, 0, 0.02, 1, 86_400_000L), "din", 3, 7, 14).ok, "");

        // ---------------------------------------------------------------- dip hunter
        Candles d = Candles.create(60), hh = Candles.create(100);
        for (int i = 0; i < 60; i++) {
            double px = i < 28 ? 100 : 100 - (i - 27) * 1.6;           // slide from 100 to ~48
            d.time[i] = i * 86_400_000L; d.open[i] = px + 0.8; d.close[i] = px; d.high[i] = px + 1.2; d.low[i] = px - 1.2; d.vol[i] = 1000;
            d.takerBuy[i] = 500;
        }
        d.vol[57] = 4500; d.low[59] = d.close[59] - 4; d.open[59] = d.close[59] + 0.3;   // washout + hammer
        double lastPx = d.close[59];
        for (int i = 0; i < 100; i++) {
            double px = i < 60 ? lastPx + (60 - i) * 0.12 : lastPx + 0.05 * (i - 60) * 0.1;   // lower earlier, flat base now
            hh.time[i] = i * 3600_000L; hh.open[i] = px; hh.close[i] = px + (i >= 90 ? 0.1 : -0.02); hh.high[i] = px + 0.3; hh.low[i] = px - 0.3 + (i >= 70 ? 0.15 : 0);
            hh.vol[i] = 100; hh.takerBuy[i] = i >= 94 ? 62 : 48;
        }
        DipHunter.Pick pk = DipHunter.evaluate("TST", d, hh, 20e6, -2, 25);
        check("dip: deep drop + washout + base + buyers → good score, not a knife", pk != null && pk.score >= 55 && !pk.knife, pk == null ? "null" : pk.score + " " + pk.why);
        check("dip: stop below price, targets above price", pk != null && pk.stop < pk.price && pk.t1 > pk.price && pk.t3 >= pk.t2, "");
        Candles flat = series(60, 100, 0, 0.01, 9, 86_400_000L);
        check("dip: coin that did not fall is skipped", DipHunter.evaluate("TST", flat, series(100, 100, 0, 0.01, 9, 3600_000L), 20e6, 0, 25) == null, "");
        Candles hk = Candles.create(100);
        for (int i = 0; i < 100; i++) {   // still making new lows with sellers in control
            double px = lastPx + (100 - i) * 0.3;
            hk.time[i] = i * 3600_000L; hk.open[i] = px + 0.3; hk.close[i] = px; hk.high[i] = px + 0.4; hk.low[i] = px - 0.4; hk.vol[i] = 100; hk.takerBuy[i] = 35;
        }
        DipHunter.Pick kn = DipHunter.evaluate("TST", d, hk, 20e6, -5, 25);
        check("dip: still printing new lows with sellers → flagged falling knife", kn != null && kn.knife, kn == null ? "null" : kn.score + "");

        // ---------------------------------------------------------------- events
        Calendar c0 = Calendar.getInstance();
        c0.clear(); c0.set(2026, Calendar.AUGUST, 5, 12, 0);
        EventCal.Next cat = null;
        for (EventCal.Next n : EventCal.upcoming(c0.getTimeInMillis())) if (n.ev.name.contains("International Cat Day")) cat = n;
        check("events: Cat Day is 3 days after 5 Aug", cat != null && cat.daysLeft == 3, cat == null ? "null" : cat.daysLeft + "");
        c0.set(2026, Calendar.AUGUST, 9, 12, 0);
        for (EventCal.Next n : EventCal.upcoming(c0.getTimeInMillis())) if (n.ev.name.contains("International Cat Day")) cat = n;
        check("events: after 8 Aug the next Cat Day is next year", cat.date.get(Calendar.YEAR) == 2027 && cat.daysLeft > 300, cat.daysLeft + "");
        Calendar nye = Calendar.getInstance();
        nye.clear(); nye.set(2027, Calendar.JANUARY, 1, 12, 0);
        EventCal.Next cny = null;
        for (EventCal.Next n : EventCal.upcoming(nye.getTimeInMillis())) if (n.ev.name.startsWith("Chinese")) cny = n;
        check("events: moving date (Chinese New Year 2027-02-06) found", cny != null && cny.daysLeft == 36, cny == null ? "null" : cny.daysLeft + "");
        Candles dd = Candles.create(900);
        Calendar st = Calendar.getInstance();
        st.clear(); st.set(2023, Calendar.JANUARY, 1);
        for (int i = 0; i < 900; i++) { dd.time[i] = st.getTimeInMillis() + i * 86_400_000L; dd.close[i] = 100 + i * 0.1; dd.open[i] = dd.close[i]; dd.high[i] = dd.close[i]; dd.low[i] = dd.close[i]; }
        List<EventCal.Year> ys = EventCal.study(dd, 8, 8);
        check("events: study returns one row per past year inside the data", ys.size() == 2 && ys.get(0).year == 2023 && ys.get(0).runUp7 > 0, ys.size() + "");

        // ---------------------------------------------------------------- hack watch
        HackWatch.Item i1 = HackWatch.classify("Binance hacked? Exchange suspends withdrawals after hot wallet drained", "X", 1, "");
        check("hack: exchange + hack words → critical, Binance / BNB", i1 != null && i1.sev == 3 && i1.exchange.equals("Binance") && i1.token.equals("BNB"), i1 == null ? "null" : i1.sev + " " + i1.exchange);
        check("hack: question mark / 'reportedly' → marked unconfirmed", i1.unconfirmed, "");
        check("hack: how-to articles are ignored", HackWatch.classify("How to protect your crypto from exchange hacks", "X", 1, "") == null, "");
        HackWatch.Item i2 = HackWatch.classify("Exploit drains $120 million from DeFi lending protocol", "X", 1, "");
        check("hack: big protocol exploit → severity 2", i2 != null && i2.sev == 2 && i2.exchange.isEmpty(), i2 == null ? "null" : i2.sev + "");
        check("hack: ordinary news ignored", HackWatch.classify("Bitcoin climbs as ETF inflows hit record", "X", 1, "") == null, "");
        HackWatch.Item i3 = HackWatch.classify("Kraken says no breach after rumours", "X", 1, "");
        check("hack: word 'Gate' alone does not match Gate.io", HackWatch.classify("Watergate style hack story", "X", 1, "").exchange.isEmpty(), "");
        String xml = "<rss><channel><item><title><![CDATA[OKX suspends withdrawals after security incident]]></title><link>http://x/1</link><pubDate>Thu, 19 Nov 2026 10:00:00 GMT</pubDate><source url=\"x\">CoinDesk</source></item>"
                + "<item><title>Nice weather</title><link>http://x/2</link></item></channel></rss>";
        List<HackWatch.Item> parsed = HackWatch.parseRss(xml, "feed");
        check("hack: RSS parsing keeps only hack stories with source + link", parsed.size() == 1 && parsed.get(0).exchange.equals("OKX") && parsed.get(0).source.equals("CoinDesk") && parsed.get(0).link.equals("http://x/1"), parsed.size() + "");
    }
}
