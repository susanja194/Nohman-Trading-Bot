package com.signal.bot;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * News ticker: important headlines + catalysts slide from RIGHT to LEFT in one line, forever.
 * The scroll position is static, so redrawing the home screen does not restart it.
 */
public class TickerView extends View {
    private static float offset;          // shared: survives re-creation
    private static long lastFrame;
    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<String> items = new ArrayList<>();
    private final List<Integer> colors = new ArrayList<>();
    private float total;

    public TickerView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        p.setTextSize(13 * d);
        p.setFakeBoldText(true);
    }

    public void set(List<String> texts, List<Integer> cols) {
        items.clear();
        colors.clear();
        items.addAll(texts);
        colors.addAll(cols);
        total = 0;
        for (String s : items) total += p.measureText(s + "     •     ");
        invalidate();
    }

    @Override
    protected void onDraw(Canvas cv) {
        if (items.isEmpty() || total <= 0) return;
        long now = System.currentTimeMillis();
        float dt = lastFrame == 0 ? 0 : Math.min(0.1f, (now - lastFrame) / 1000f);
        lastFrame = now;
        offset += dt * 55 * d;                    // ~55 dp per second
        offset %= total;
        float y = getHeight() / 2f + 13 * d * 0.35f;
        float x = getWidth() - offset;            // starts at the right edge, moves left
        // draw enough copies to fill the width
        while (x > -total) x -= total;
        while (x < getWidth()) {
            for (int i = 0; i < items.size(); i++) {
                String s = items.get(i) + "     •     ";
                float w = p.measureText(s);
                if (x + w > 0 && x < getWidth()) {
                    p.setColor(colors.get(i));
                    cv.drawText(s, x, y, p);
                }
                x += w;
            }
        }
        postInvalidateDelayed(16);
    }
}
