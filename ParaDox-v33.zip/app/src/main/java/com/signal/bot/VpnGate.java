package com.signal.bot;

import android.util.Base64;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Free VPN servers from VPN Gate (public academic project, University of Tsukuba, Japan — volunteer servers in many countries).
 * The list gives each server's country, speed, ping and a ready OpenVPN profile; the profile is opened in the free
 * "OpenVPN for Android" / "OpenVPN Connect" app, which makes the actual VPN connection.
 */
public final class VpnGate {
    private VpnGate() {}

    public static final class Server {
        public String host, ip, country, cc, config;
        public long speed, sessions, uptime;
        public int ping, score;
    }

    private static volatile List<Server> cache;
    private static volatile long cacheAt;

    public static List<Server> list(boolean force) throws Exception {
        if (!force && cache != null && System.currentTimeMillis() - cacheAt < 10 * 60_000L) return cache;
        String csv;
        try {
            csv = Scanner.getAbsolute("https://www.vpngate.net/api/iphone/");
        } catch (Exception e) {
            csv = Scanner.getAbsolute("http://www.vpngate.net/api/iphone/");
        }
        List<Server> out = new ArrayList<>();
        for (String line : csv.split("\n")) {
            if (line.startsWith("*") || line.startsWith("#") || line.trim().isEmpty()) continue;
            String[] p = line.trim().split(",");
            if (p.length < 15 || p[14].length() < 100) continue;
            try {
                Server s = new Server();
                s.host = p[0];
                s.ip = p[1];
                s.score = (int) Math.min(Integer.MAX_VALUE, Long.parseLong(p[2]));
                s.ping = p[3].isEmpty() ? 999 : Integer.parseInt(p[3]);
                s.speed = Long.parseLong(p[4]);
                s.country = p[5];
                s.cc = p[6];
                s.sessions = Long.parseLong(p[7]);
                s.uptime = Long.parseLong(p[8]);
                s.config = p[14];
                out.add(s);
            } catch (Exception ignored) {
            }
        }
        Collections.sort(out, (a, b) -> Long.compare(b.speed, a.speed));
        if (!out.isEmpty()) { cache = out; cacheAt = System.currentTimeMillis(); }
        return out;
    }

    /** The OpenVPN profile text, with modern cipher fallbacks so OpenVPN 2.5+ / 3 apps accept these older servers. */
    public static String profile(Server s) {
        String cfg = new String(Base64.decode(s.config, Base64.DEFAULT));
        if (!cfg.contains("data-ciphers")) cfg = cfg.replaceFirst("(?m)^cipher\\s+(\\S+)", "cipher $1\ndata-ciphers AES-128-CBC:AES-256-CBC:AES-128-GCM:AES-256-GCM:CHACHA20-POLY1305\ndata-ciphers-fallback $1");
        return cfg;
    }

    public static String flag(String cc) {
        if (cc == null || cc.length() != 2) return "🌐";
        int a = Character.codePointAt(cc.toUpperCase(), 0) - 'A' + 0x1F1E6, b = Character.codePointAt(cc.toUpperCase(), 1) - 'A' + 0x1F1E6;
        return new String(Character.toChars(a)) + new String(Character.toChars(b));
    }
}
