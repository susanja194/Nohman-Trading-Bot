package com.signal.bot;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Full report for one scheduled event (US macro release, election, unlock, listing...):
 *  • BEFORE: what it is, forecast / previous, what each outcome means for crypto, gold and the dollar
 *  • AFTER: the actual number (economic calendar / FRED), how BTC, ETH, gold, the dollar, US stocks and the 10y yield
 *    really moved (15 min, 1 h, now), the headlines published about it since (Google News + 46 crypto sources),
 *    and a final verdict built from all of it.
 */
public final class EventReport {
    private EventReport() {}

    public static final class Move {
        public final String name;
        public final double m15, m60, now;   // % change from the release time (yield: change in basis points)
        public final boolean bps;
        Move(String name, double m15, double m60, double now, boolean bps) { this.name = name; this.m15 = m15; this.m60 = m60; this.now = now; this.bps = bps; }
    }

    public static final class Report {
        public String actual = "", forecast = "", previous = "", verdict = "", market = "", action = "";
        public int verdictSign, marketSign;
        public final List<Move> moves = new ArrayList<>();
        public final List<NewsEngine.Item> news = new ArrayList<>();
        public int newsBull, newsBear;
        public long at;
    }

    private static final Map<String, Report> CACHE = new HashMap<>();

    /** The macro calendar entry for this event (same title, ±3 min), or null. */
    public static MacroEngine.Event macro(Context ctx, String title, long t) {
        String tl = title.replace("🇺🇸 ", "").toLowerCase(Locale.US);
        int cut = tl.indexOf(" · forecast");
        if (cut > 0) tl = tl.substring(0, cut);
        try {
            for (MacroEngine.Event e : MacroEngine.calendar(ctx, false))
                if (Math.abs(e.time - t) < 3 * 60_000L && (tl.contains(e.title.toLowerCase(Locale.US)) || e.title.toLowerCase(Locale.US).contains(tl))) return e;
        } catch (Exception ignored) {
        }
        return null;
    }

    /** Builds (or returns the ≤60 s old) after-release report. coin = extra coin to show (e.g. "ARB" for an unlock), may be null. */
    public static Report build(Context ctx, String title, long t, String coin) {
        String key = title + "@" + t;
        synchronized (CACHE) {
            Report c = CACHE.get(key);
            if (c != null && System.currentTimeMillis() - c.at < 60_000L) return c;
        }
        Report r = new Report();
        r.at = System.currentTimeMillis();
        // ---- the number
        MacroEngine.Event m = macro(ctx, title, t);
        if (m != null) {
            if (m.actual.isEmpty()) try { MacroEngine.calendar(ctx, true); m = macro(ctx, title, t); } catch (Exception ignored) { }
        }
        if (m != null) {
            r.actual = m.actual;
            r.forecast = m.forecast;
            r.previous = m.previous;
            if (!m.actual.isEmpty()) { MacroEngine.verdict(m); r.verdict = m.verdict; r.verdictSign = m.verdictSign; }
        }
        // ---- market reaction
        if (coin != null && !coin.isEmpty() && !coin.equals("BTC") && !coin.equals("ETH")) bin(r, coin + "USDT", coin, t);
        bin(r, "BTCUSDT", "BTC", t);
        bin(r, "ETHUSDT", "ETH", t);
        yahoo(r, "GC=F", "Gold (XAUUSD)", t, false);
        yahoo(r, "DX-Y.NYB", "Dollar index (DXY)", t, false);
        yahoo(r, "ES=F", "US stocks (S&P 500 fut.)", t, false);
        yahoo(r, "^TNX", "US 10y yield", t, true);
        double btc = find(r, "BTC"), es = find(r, "US stocks"), dxy = find(r, "Dollar"), gold = find(r, "Gold");
        int score = 0;
        if (!Double.isNaN(btc)) score += btc > 0.4 ? 2 : btc < -0.4 ? -2 : 0;
        if (!Double.isNaN(es)) score += es > 0.2 ? 1 : es < -0.2 ? -1 : 0;
        if (!Double.isNaN(dxy)) score += dxy < -0.15 ? 1 : dxy > 0.15 ? -1 : 0;
        r.marketSign = score >= 2 ? 1 : score <= -2 ? -1 : 0;
        StringBuilder mk = new StringBuilder(r.marketSign > 0 ? "🟢 RISK-ON — market ne isay ACHHA liya" : r.marketSign < 0 ? "🔴 RISK-OFF — market ne isay BURA liya" : "⚪ Market ne khaas react nahi kiya (ya ulat-palat)");
        if (!Double.isNaN(gold) && Math.abs(gold) > 0.3) mk.append(gold > 0 ? " · gold mein safe-haven khareed" : " · gold se paisa nikla");
        r.market = mk.toString();
        // ---- headlines since the event (Google News for the event + the crypto news radar)
        Set<String> kw = keywords(title);
        Set<String> seen = new LinkedHashSet<>();
        try {
            String q = String.join(" ", new ArrayList<>(kw).subList(0, Math.min(4, kw.size())));
            String xml = Scanner.getAbsolute(NewsEngine.G + java.net.URLEncoder.encode(q + " when:2d", "UTF-8"));
            for (NewsEngine.Item it : NewsEngine.rss("Google News", xml, true)) {
                if (it.time < t - 3 * 3600_000L) continue;
                NewsEngine.classify(it);
                if (seen.add(it.title.toLowerCase(Locale.US)) && r.news.size() < 10) r.news.add(it);
            }
        } catch (Exception ignored) {
        }
        for (NewsEngine.Item it : NewsEngine.cached()) {
            if (it.time < t - 30 * 60_000L || r.news.size() >= 14) continue;
            String tl = it.title.toLowerCase(Locale.US);
            int hits = 0;
            for (String k : kw) if (tl.contains(k)) hits++;
            if (hits >= 1 && seen.add(tl)) r.news.add(it);
        }
        java.util.Collections.sort(r.news, (a, b) -> Long.compare(b.time, a.time));
        for (NewsEngine.Item it : r.news) { if (it.dir > 0) r.newsBull++; else if (it.dir < 0) r.newsBear++; }
        // ---- what to do
        int all = r.verdictSign * 2 + r.marketSign * 2 + Integer.signum(r.newsBull - r.newsBear);
        r.action = all >= 2 ? "🟢 Number + market + khabrein crypto ke HAQ mein. Pullback par BUY setups behtar — bot ke confirm signal ka intezar karein, stop zaroor."
                : all <= -2 ? "🔴 Crypto ke KHILAF. Naye BUY se bachen, open trades ka stop tight / profit bacha lein. Short sirf breakdown confirm hone par."
                : "⚪ Saaf faisla nahi. Pehle 1–2 ghante ki volatility guzarne dein, phir trend ke saath trade karein.";
        synchronized (CACHE) { CACHE.put(key, r); }
        return r;
    }

    static double find(Report r, String prefix) {
        for (Move m : r.moves) if (m.name.startsWith(prefix)) return Double.isNaN(m.m60) ? m.m15 : m.m60;
        return Double.NaN;
    }

    static final Set<String> STOP = new java.util.HashSet<>(java.util.Arrays.asList("the", "and", "for", "with", "from", "this", "that", "forecast", "release",
            "data", "report", "final", "prelim", "preliminary", "flash", "change", "speaks", "meeting", "statement", "y/y", "m/m", "q/q", "us", "usd"));

    static Set<String> keywords(String title) {
        String t = title.replace("🇺🇸 ", "").toLowerCase(Locale.US);
        int cut = t.indexOf(" · forecast");
        if (cut > 0) t = t.substring(0, cut);
        Set<String> k = new LinkedHashSet<>();
        if (t.contains("election") || t.contains("congress")) { k.add("election"); k.add("midterm"); k.add("congress"); k.add("senate"); k.add("house"); }
        if (t.contains("cpi") || t.contains("inflation")) { k.add("cpi"); k.add("inflation"); }
        if (t.contains("payroll") || t.contains("nfp") || t.contains("employment")) { k.add("jobs"); k.add("payrolls"); k.add("unemployment"); }
        if (t.contains("fomc") || t.contains("fed") || t.contains("funds rate")) { k.add("fed"); k.add("powell"); k.add("rate"); }
        if (t.contains("pce")) { k.add("pce"); k.add("inflation"); }
        if (t.contains("gdp")) k.add("gdp");
        for (String w : t.replaceAll("[^a-z0-9 ]", " ").split("\\s+")) if (w.length() >= 4 && !STOP.contains(w)) k.add(w);
        if (k.isEmpty()) k.add(t.trim());
        return k;
    }

    /** Binance 5m candles from the release time. */
    static void bin(Report r, String sym, String name, long t) {
        try {
            JSONArray a = new JSONArray(Scanner.get("/api/v3/klines?symbol=" + sym + "&interval=5m&startTime=" + (t - 5 * 60_000L) + "&limit=200"));
            if (a.length() < 2) return;
            double p0 = 0;
            int i0 = 0;
            for (int i = 0; i < a.length(); i++) if (a.getJSONArray(i).getLong(0) <= t) { p0 = Double.parseDouble(a.getJSONArray(i).getString(4)); i0 = i; }
            if (p0 <= 0) { p0 = Double.parseDouble(a.getJSONArray(0).getString(1)); i0 = 0; }
            double now = Double.parseDouble(new JSONObject(Scanner.get("/api/v3/ticker/price?symbol=" + sym)).getString("price"));
            r.moves.add(new Move(name, at(a, i0 + 3, p0), at(a, i0 + 12, p0), (now / p0 - 1) * 100, false));
        } catch (Exception ignored) {
        }
    }

    static double at(JSONArray a, int i, double p0) {
        try {
            if (i >= a.length()) return Double.NaN;
            return (Double.parseDouble(a.getJSONArray(i).getString(4)) / p0 - 1) * 100;
        } catch (Exception e) {
            return Double.NaN;
        }
    }

    /** Yahoo 5m candles (stocks / dollar / gold / yields) from the release time. Markets that were closed show "—". */
    static void yahoo(Report r, String sym, String name, long t, boolean bps) {
        try {
            Candles c = YahooData.parse(YahooData.raw(sym, "5m", "5d"));
            if (c.n < 3) return;
            int i0 = -1;
            for (int i = 0; i < c.n; i++) if (c.time[i] <= t) i0 = i;
            if (i0 < 0 || t - c.time[i0] > 3 * 3600_000L) return;   // market closed at that moment
            double p0 = c.close[i0];
            double m15 = i0 + 3 < c.n ? val(c.close[i0 + 3], p0, bps) : Double.NaN, m60 = i0 + 12 < c.n ? val(c.close[i0 + 12], p0, bps) : Double.NaN;
            r.moves.add(new Move(name, m15, m60, val(c.close[c.n - 1], p0, bps), bps));
        } catch (Exception ignored) {
        }
    }

    /** % change, or for a yield (^TNX is quoted in %) the change in basis points. */
    static double val(double v, double p0, boolean bps) { return bps ? (v - p0) * 100 : (v / p0 - 1) * 100; }
}
