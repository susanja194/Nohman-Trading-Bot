package com.signal.bot;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

/** Foreground service that keeps scanning 24/7 while enabled. */
public class ScannerService extends Service {
    public static final String ACTION_STOP = "com.signal.bot.STOP";
    public static final String CH_SERVICE = "service";
    private static final int FG_ID = 1001;

    public static volatile boolean running = false;
    private Thread worker;
    private PowerManager.WakeLock wakeLock;

    public static void createChannels(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel svc = new NotificationChannel(CH_SERVICE, "Bot running status",
                NotificationManager.IMPORTANCE_LOW);
        NotificationChannel sig = new NotificationChannel(Scanner.CH_SIGNALS, "Buy / Sell signals",
                NotificationManager.IMPORTANCE_HIGH);
        sig.enableVibration(true);
        nm.createNotificationChannel(svc);
        nm.createNotificationChannel(sig);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createChannels(this);
    }

    private Notification statusNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stop = new Intent(this, ScannerService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CH_SERVICE)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Nohman Trading Bot live hai")
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setOngoing(true)
                .setContentIntent(pi)
                .addAction(new Notification.Action.Builder(null, "Stop", stopPi).build())
                .build();
    }

    private void updateStatus(String text) {
        Prefs.setStatus(this, text);
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(FG_ID, statusNotification(text));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            Prefs.setEnabled(this, false);
            Prefs.setStatus(this, "Bot band hai");
            running = false;
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        Notification n = statusNotification("Scan shuru ho raha hai...");
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(FG_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(FG_ID, n);
        }

        if (wakeLock == null) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SignalBot:scan");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire();
        }

        if (worker == null || !worker.isAlive()) {
            running = true;
            worker = new Thread(this::loop, "scanner");
            worker.start();
        }
        return START_STICKY;
    }

    private void loop() {
        while (running) {
            try {
                updateStatus("Scan chal raha hai...");
                String s = Scanner.runOnce(this);
                updateStatus(s);
            } catch (InterruptedException e) {
                break;
            } catch (Exception e) {
                updateStatus("Error: " + e.getMessage() + " — internet check karein, dobara try hoga");
            }
            try {
                Thread.sleep(Prefs.intervalMin(this) * 60_000L);
            } catch (InterruptedException e) {
                break;
            }
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        if (worker != null) worker.interrupt();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
