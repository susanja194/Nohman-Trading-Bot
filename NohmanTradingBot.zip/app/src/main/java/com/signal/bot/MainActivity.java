package com.signal.bot;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BG = Color.parseColor("#0E1117");
    private static final int CARD = Color.parseColor("#1A1F2B");
    private static final int TEXT = Color.parseColor("#E8EAED");
    private static final int MUTED = Color.parseColor("#9AA0A6");
    private static final int GOLD = Color.parseColor("#F0B90B");
    private static final int GREEN = Color.parseColor("#0ECB81");
    private static final int RED = Color.parseColor("#F6465D");

    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView statusView;
    private Button toggleBtn;
    private LinearLayout signalList;
    private EditText intervalEt, topEt, minVolEt, buyEt, sellEt, volMultEt, cooldownEt;
    private Spinner tfSpinner;
    private CheckBox btcCb, smartCb;
    private EditText whaleEt;
    private static final String[] TFS = {"5m", "15m", "30m", "1h", "4h"};

    private final Runnable refresher = new Runnable() {
        @Override
        public void run() {
            refresh();
            handler.postDelayed(this, 5000);
        }
    };

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScannerService.createChannels(this);
        getWindow().setStatusBarColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(32));
        scroll.addView(root);

        TextView title = text("Nohman Trading Bot", 24, GOLD);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);
        root.addView(text("Technical + whale / smart-money alerts · Binance USDT coins", 13, MUTED));

        // Status card
        LinearLayout statusCard = card(root);
        statusView = text("", 14, TEXT);
        statusCard.addView(statusView);
        toggleBtn = button("", GOLD, Color.BLACK);
        toggleBtn.setOnClickListener(v -> toggle());
        statusCard.addView(toggleBtn);
        Button battery = button("Battery restriction hatayen (zaroori)", CARD, GOLD);
        battery.setOnClickListener(v -> askBattery());
        statusCard.addView(battery);

        // Signals card
        LinearLayout sigCard = card(root);
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView sh = text("Signals", 18, TEXT);
        sh.setTypeface(Typeface.DEFAULT_BOLD);
        head.addView(sh, new LinearLayout.LayoutParams(0, -2, 1));
        Button clear = button("Clear", CARD, MUTED);
        clear.setOnClickListener(v -> { Prefs.clearSignals(this); refresh(); });
        head.addView(clear, new LinearLayout.LayoutParams(-2, -2));
        sigCard.addView(head);
        signalList = new LinearLayout(this);
        signalList.setOrientation(LinearLayout.VERTICAL);
        sigCard.addView(signalList);

        // Settings card
        LinearLayout set = card(root);
        TextView st = text("Settings", 18, TEXT);
        st.setTypeface(Typeface.DEFAULT_BOLD);
        set.addView(st);
        intervalEt = field(set, "Har kitne minute baad scan", Prefs.intervalMin(this));
        set.addView(text("Candle timeframe", 13, MUTED));
        tfSpinner = new Spinner(this);
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, TFS);
        tfSpinner.setAdapter(ad);
        for (int i = 0; i < TFS.length; i++) if (TFS[i].equals(Prefs.timeframe(this))) tfSpinner.setSelection(i);
        set.addView(tfSpinner);
        topEt = field(set, "Kitne top coins scan karein (volume ke hisaab se, max 400)", Prefs.topCoins(this));
        minVolEt = field(set, "Kam az kam 24h volume (million USDT)", Prefs.minVolMillion(this));
        buyEt = field(set, "BUY score threshold (zyada = kam magar strong signal)", Prefs.buyThreshold(this));
        sellEt = field(set, "SELL score threshold", Prefs.sellThreshold(this));
        volMultEt = field(set, "Volume spike = average ka kitna guna (e.g. 2.0)", -1);
        volMultEt.setText(String.valueOf(Prefs.volMult(this)));
        volMultEt.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        cooldownEt = field(set, "Ek coin ka dobara signal kitne minute baad", Prefs.cooldownMin(this));
        btcCb = new CheckBox(this);
        btcCb.setText("BTC filter: jab BTC bearish ho to BUY signal na do");
        btcCb.setTextColor(TEXT);
        btcCb.setChecked(Prefs.btcFilter(this));
        set.addView(btcCb);
        smartCb = new CheckBox(this);
        smartCb.setText("🐋 Smart money: whale trades, top traders, open interest");
        smartCb.setTextColor(TEXT);
        smartCb.setChecked(Prefs.smartMoney(this));
        set.addView(smartCb);
        whaleEt = field(set, "Whale trade kitne USD se bada ho (e.g. 50000)", Prefs.whaleUsd(this));
        Button save = button("Save settings", GOLD, Color.BLACK);
        save.setOnClickListener(v -> saveSettings());
        set.addView(save);

        LinearLayout warn = card(root);
        warn.addView(text("⚠️ Yeh signals sirf maloomat ke liye hain, financial advice nahi. Koi bhi "
                + "indicator 100% sahi nahi hota — hamesha stop-loss lagayen aur utna hi invest karein "
                + "jitna khone ki gunjaish ho. Bot khud koi trade nahi karta.", 13, MUTED));

        setContentView(scroll);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(14));
        c.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(14);
        parent.addView(c, lp);
        return c;
    }

    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setPadding(0, dp(3), 0, dp(3));
        return t;
    }

    private Button button(String s, int bg, int fg) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(fg);
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);
        g.setStroke(dp(1), GOLD);
        g.setCornerRadius(dp(10));
        b.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(8);
        b.setLayoutParams(lp);
        return b;
    }

    private EditText field(LinearLayout parent, String label, int value) {
        parent.addView(text(label, 13, MUTED));
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setTextColor(TEXT);
        if (value >= 0) e.setText(String.valueOf(value));
        parent.addView(e);
        return e;
    }

    private int num(EditText e, int def) {
        try { return Integer.parseInt(e.getText().toString().trim()); } catch (Exception x) { return def; }
    }

    private void saveSettings() {
        float vm;
        try { vm = Float.parseFloat(volMultEt.getText().toString().trim()); } catch (Exception x) { vm = 2.0f; }
        Prefs.saveSettings(this, num(intervalEt, 5), TFS[tfSpinner.getSelectedItemPosition()],
                num(topEt, 100), num(minVolEt, 5), num(buyEt, 7), num(sellEt, 5), vm,
                btcCb.isChecked(), num(cooldownEt, 120));
        Prefs.saveSmart(this, smartCb.isChecked(), num(whaleEt, 50000));
        Toast.makeText(this, "Saved — agla scan naye settings se hoga", Toast.LENGTH_SHORT).show();
    }

    private void toggle() {
        if (Prefs.enabled(this)) {
            startService(new Intent(this, ScannerService.class).setAction(ScannerService.ACTION_STOP));
            Prefs.setEnabled(this, false);
        } else {
            Prefs.setEnabled(this, true);
            startForegroundService(new Intent(this, ScannerService.class));
        }
        handler.postDelayed(this::refresh, 300);
    }

    private void askBattery() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm.isIgnoringBatteryOptimizations(getPackageName())) {
                Toast.makeText(this, "Pehle se unrestricted hai ✅", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        }
    }

    private void refresh() {
        boolean on = Prefs.enabled(this);
        statusView.setText((on ? "🟢 Bot ON\n" : "⚪ Bot OFF\n") + Prefs.status(this));
        toggleBtn.setText(on ? "Stop bot" : "Start bot (24/7)");

        signalList.removeAllViews();
        JSONArray arr = Prefs.signals(this);
        if (arr.length() == 0) {
            signalList.addView(text("Abhi koi signal nahi. Bot ON karein — signal aate hi notification aa jayegi.", 13, MUTED));
            return;
        }
        SimpleDateFormat f = new SimpleDateFormat("dd MMM HH:mm", Locale.US);
        for (int i = 0; i < arr.length() && i < 60; i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            boolean buy = "BUY".equals(o.optString("side"));
            String sym = o.optString("sym");
            TextView h = text((buy ? "🟢 BUY  " : "🔴 SELL  ") + sym.replace("USDT", "/USDT")
                    + "  @ " + Scanner.fmtPrice(o.optDouble("price")) + "   score " + o.optInt("score"), 15, buy ? GREEN : RED);
            h.setTypeface(Typeface.DEFAULT_BOLD);
            h.setPadding(0, dp(10), 0, 0);
            signalList.addView(h);
            signalList.addView(text(f.format(new Date(o.optLong("t"))) + "\n" + o.optString("why"), 12, MUTED));
            View line = new View(this);
            line.setBackgroundColor(Color.parseColor("#2A3040"));
            signalList.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(refresher);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(refresher);
    }
}
