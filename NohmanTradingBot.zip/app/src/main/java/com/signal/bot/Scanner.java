package com.signal.bot;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** One full scan of Binance spot USDT coins. Uses only public market data (no API key). */
public final class Scanner {
    private Scanner() {}

    public static final String CH_SIGNALS = "signals";

    private static final String[] HOSTS = {
            "https://data-api.binance.vision",
            "https://api.binance.com",
            "https://api1.binance.com",
            "https://api2.binance.com",
            "https://api-gcp.binance.com"
    };
    private static int hostIdx = 0;

    private static final Set<String> SKIP = new HashSet<>();
    static {
        String[] s = {"USDCUSDT", "FDUSDUSDT", "TUSDUSDT", "BUSDUSDT", "USDPUSDT", "DAIUSDT",
                "EURUSDT", "EURIUSDT", "AEURUSDT", "USDEUSDT", "XUSDUSDT", "PAXGUSDT", "BFUSDUSDT",
                "GBPUSDT", "TRYUSDT", "BRLUSDT", "USD1USDT"};
        Collections.addAll(SKIP, s);
    }

    /** Fetch a full URL (used for futures + Fear & Greed). */
    static String getAbsolute(String url) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        try {
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);
            conn.setRequestProperty("User-Agent", "SignalBot/1.0");
            int code = conn.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code);
            StringBuilder sb = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"))) {
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
            }
            return sb.toString();
        } finally {
            conn.disconnect();
        }
    }

    static String get(String path) throws IOException {
        IOException last = new IOException("No host reachable");
        for (int a = 0; a < HOSTS.length; a++) {
            int idx = (hostIdx + a) % HOSTS.length;
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(HOSTS[idx] + path).openConnection();
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(30000);
                conn.setRequestProperty("User-Agent", "SignalBot/1.0");
                int code = conn.getResponseCode();
                if (code == 200) {
                    StringBuilder sb = new StringBuilder();
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"))) {
                        String line;
                        while ((line = br.readLine()) != null) sb.append(line);
                    }
                    hostIdx = idx;
                    return sb.toString();
                }
                if (code == 429 || code == 418) throw new IOException("Binance rate limit (" + code + "), thora wait");
                last = new IOException("HTTP " + code + " from " + HOSTS[idx]);
            } catch (IOException e) {
                if (e.getMessage() != null && e.getMessage().startsWith("Binance rate limit")) throw e;
                last = e;
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
        throw last;
    }

    /** Returns {open, close, volume, takerBuyVolume} for CLOSED candles only. */
    static double[][] klines(String symbol, String tf, int limit) throws Exception {
        JSONArray arr = new JSONArray(get("/api/v3/klines?symbol=" + symbol + "&interval=" + tf + "&limit=" + limit));
        int n = Math.max(0, arr.length() - 1); // drop the still-forming candle
        double[] o = new double[n], c = new double[n], v = new double[n], tb = new double[n];
        for (int i = 0; i < n; i++) {
            JSONArray k = arr.getJSONArray(i);
            o[i] = Double.parseDouble(k.getString(1));
            c[i] = Double.parseDouble(k.getString(4));
            v[i] = Double.parseDouble(k.getString(5));
            tb[i] = k.length() > 9 ? Double.parseDouble(k.getString(9)) : v[i] / 2;
        }
        return new double[][]{o, c, v, tb};
    }

    /** Runs one scan. Returns a short status line. */
    public static String runOnce(Context ctx) throws Exception {
        String tf = Prefs.timeframe(ctx);
        int top = Prefs.topCoins(ctx);
        double minVol = Prefs.minVolMillion(ctx) * 1_000_000.0;
        int buyTh = Prefs.buyThreshold(ctx);
        int sellTh = Prefs.sellThreshold(ctx);
        double volMult = Prefs.volMult(ctx);
        boolean smart = Prefs.smartMoney(ctx);
        double whaleUsd = Prefs.whaleUsd(ctx);

        // 0) Overall market sentiment
        String[] fg = SmartMoney.fearGreed();
        int fgVal = -1;
        if (fg != null) {
            try { fgVal = Integer.parseInt(fg[0]); } catch (Exception ignored) { }
        }

        // 1) Market context: is BTC healthy? (no BUY alerts on alts while BTC is dumping)
        boolean btcBull = true;
        try {
            double[][] b = klines("BTCUSDT", "1h", 120);
            btcBull = Analyzer.isBullish(b[1]);
        } catch (Exception ignored) {
        }

        // 2) All spot coins with 24h stats
        JSONArray tick = new JSONArray(get("/api/v3/ticker/24hr?type=MINI"));
        List<JSONObject> coins = new ArrayList<>();
        for (int i = 0; i < tick.length(); i++) {
            JSONObject t = tick.getJSONObject(i);
            String s = t.optString("symbol");
            if (!s.endsWith("USDT") || SKIP.contains(s)) continue;
            String base = s.substring(0, s.length() - 4);
            if (base.endsWith("UP") || base.endsWith("DOWN") || base.endsWith("BULL") || base.endsWith("BEAR")) continue;
            double qv = t.optDouble("quoteVolume", 0);
            if (qv < minVol || t.optDouble("lastPrice", 0) <= 0) continue;
            coins.add(t);
        }
        Collections.sort(coins, (a, b2) -> Double.compare(b2.optDouble("quoteVolume", 0), a.optDouble("quoteVolume", 0)));
        if (coins.size() > top) coins = coins.subList(0, top);

        // 3) Analyse each coin
        int scanned = 0, alerts = 0;
        for (JSONObject t : coins) {
            if (!ScannerService.running) break;
            String sym = t.optString("symbol");
            try {
                double[][] k = klines(sym, tf, 200);
                Analyzer.Result r = Analyzer.analyze(k[0], k[1], k[2], k[3], volMult);
                scanned++;
                if (smart && (r.buyScore >= buyTh - 3 || r.sellScore >= sellTh - 3)) {
                    SmartMoney.enrich(sym, r, whaleUsd, true);
                }
                if (fgVal >= 80) {
                    r.buyScore -= 1;
                    r.buyReasons.add("Market Extreme Greed (" + fgVal + ") — ehtiyat");
                } else if (fgVal >= 0 && fgVal <= 20 && r.buyScore > 0) {
                    r.buyReasons.add("Market Extreme Fear (" + fgVal + ") — aksar achha entry time");
                }
                boolean buyOk = r.buyScore >= buyTh && (btcBull || !Prefs.btcFilter(ctx) || sym.equals("BTCUSDT"));
                if (buyOk && Prefs.checkAndMarkCooldown(ctx, sym, "BUY")) {
                    alert(ctx, "BUY", sym, r.price, r.buyScore, join(r.buyReasons), tf);
                    alerts++;
                } else if (r.sellScore >= sellTh && r.volumeOutflow && Prefs.checkAndMarkCooldown(ctx, sym, "SELL")) {
                    alert(ctx, "SELL", sym, r.price, r.sellScore, join(r.sellReasons), tf);
                    alerts++;
                }
            } catch (InterruptedException e) {
                throw e;
            } catch (IOException e) {
                if (e.getMessage() != null && e.getMessage().startsWith("Binance rate limit")) {
                    Thread.sleep(60_000);
                }
            } catch (Exception ignored) {
            }
            Thread.sleep(120); // stay far below Binance limits
        }

        String time = new SimpleDateFormat("HH:mm", Locale.US).format(new Date());
        return "Last scan " + time + " · " + scanned + " coins (" + tf + ") · " + alerts
                + " naye signal · BTC " + (btcBull ? "bullish ✅" : "bearish ⚠️")
                + (fg != null ? " · Fear&Greed " + fg[0] + " (" + fg[1] + ")" : "");
    }

    private static String join(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (String s : l) { if (sb.length() > 0) sb.append("\n• "); else sb.append("• "); sb.append(s); }
        return sb.toString();
    }

    static String fmtPrice(double p) {
        if (p >= 100) return String.format(Locale.US, "%.2f", p);
        if (p >= 1) return String.format(Locale.US, "%.4f", p);
        return String.format(Locale.US, "%.8f", p);
    }

    private static void alert(Context ctx, String side, String sym, double price, int score, String why, String tf) {
        Prefs.addSignal(ctx, side, sym, price, score, why);
        String base = sym.substring(0, sym.length() - 4);
        Intent open = new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.binance.com/en/trade/" + base + "_USDT?type=spot"));
        PendingIntent pi = PendingIntent.getActivity(ctx, sym.hashCode(), open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String title = ("BUY".equals(side) ? "🟢 BUY signal: " : "🔴 SELL signal (volume nikal raha): ")
                + base + "/USDT";
        String text = "Price " + fmtPrice(price) + " · Score " + score + " · " + tf;
        Notification n = new Notification.Builder(ctx, CH_SIGNALS)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text + "\n" + why))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify((sym + side).hashCode(), n);
    }
}
