package com.signal.bot;

import org.json.JSONArray;

/** OHLCV candles from Binance klines, oldest first. */
public final class Candles {
    public final int n;
    public final long[] time;
    public final double[] open, high, low, close, vol, takerBuy, quoteVol, takerBuyQuote, trades;

    private Candles(int n) {
        this.n = n;
        time = new long[n];
        open = new double[n];
        high = new double[n];
        low = new double[n];
        close = new double[n];
        vol = new double[n];
        takerBuy = new double[n];
        quoteVol = new double[n];
        takerBuyQuote = new double[n];
        trades = new double[n];
    }

    public static Candles parse(String json, boolean closedOnly) throws Exception {
        JSONArray arr = new JSONArray(json);
        int n = closedOnly ? Math.max(0, arr.length() - 1) : arr.length();
        Candles c = new Candles(n);
        for (int i = 0; i < n; i++) {
            JSONArray k = arr.getJSONArray(i);
            c.time[i] = k.getLong(0);
            c.open[i] = Double.parseDouble(k.getString(1));
            c.high[i] = Double.parseDouble(k.getString(2));
            c.low[i] = Double.parseDouble(k.getString(3));
            c.close[i] = Double.parseDouble(k.getString(4));
            c.vol[i] = Double.parseDouble(k.getString(5));
            c.quoteVol[i] = k.length() > 7 ? Double.parseDouble(k.getString(7)) : c.vol[i] * c.close[i];
            c.trades[i] = k.length() > 8 ? k.getLong(8) : 0;
            c.takerBuy[i] = k.length() > 9 ? Double.parseDouble(k.getString(9)) : c.vol[i] / 2;
            c.takerBuyQuote[i] = k.length() > 10 ? Double.parseDouble(k.getString(10)) : c.quoteVol[i] / 2;
        }
        return c;
    }

    /** closedOnly = drop the still-forming candle (for analysis). */
    public static Candles fetch(String symbol, String tf, int limit, boolean closedOnly) throws Exception {
        return parse(Scanner.get("/api/v3/klines?symbol=" + symbol + "&interval=" + tf + "&limit=" + limit), closedOnly);
    }

    /** Index of the candle that contains time t (ms), or -1. */
    public int indexOf(long t) {
        int lo = 0, hi = n - 1, ans = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (time[mid] <= t) { ans = mid; lo = mid + 1; } else hi = mid - 1;
        }
        return ans;
    }
}
