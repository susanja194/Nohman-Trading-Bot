package com.signal.bot;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Trading chart that draws the analysis on top of the candles, like a hand-marked TradingView chart:
 * Fibonacci levels, trendlines + pattern label + projected arrow, support/resistance zones,
 * volume profile (buy blue / sell yellow), whale + retail markers, candle patterns,
 * EMA20/50, VWAP, entry/stop/target lines, buy/sell volume and an RSI panel with divergence.
 */
public class ChartView extends View {
    private static final int UP = 0xFF0ECB81, DOWN = 0xFFF6465D, GRID = 0xFF1E2840, TXT = 0xFF8B95A7,
            EMA20 = 0xFF22D3EE, EMA50 = 0xFFA855F7, VWAP = 0xFFFF8A3D, WHITE = 0xFFE8EAED;
    private static final int[] FIB_COL = {0xFF9CA3AF, 0xFFF6465D, 0xFF9BE15D, 0xFF22C55E, 0xFF14B8A6, 0xFF3B82F6, 0xFF9CA3AF};
    private static final int FUTURE = 14;

    private Candles data;
    private PatternEngine.Result pat;
    private double[] ema20, ema50, vwap, wBuy, wSell;
    private String tf = "1h";
    private int visible = 90, touchIdx = -1, accent = 0xFFA855F7;
    private boolean fib = true, lines = true, zones = true, vp = true, whales = true, rsiOn = true, vwapOn;
    private boolean planOn, planBuy;
    private double pEntry, pSl, pTp1, pTp2;
    private String message = "Chart load ho raha hai...";
    private final float d;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), stroke = new Paint(Paint.ANTI_ALIAS_FLAG),
            text = new Paint(Paint.ANTI_ALIAS_FLAG), dash = new Paint(Paint.ANTI_ALIAS_FLAG), grid = new Paint();

    public ChartView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        stroke.setStyle(Paint.Style.STROKE);
        dash.setStyle(Paint.Style.STROKE);
        dash.setPathEffect(new DashPathEffect(new float[]{6 * d, 4 * d}, 0));
        grid.setColor(GRID);
        grid.setStrokeWidth(1);
        text.setTextSize(10 * d);
    }

    // ------------------------------------------------------------ public API
    public void setMessage(String m) {
        message = m;
        data = null;
        invalidate();
    }

    public void setAccent(int c) { accent = c; invalidate(); }

    public void setLayers(boolean fib, boolean lines, boolean zones, boolean vp, boolean whales, boolean rsi) {
        this.fib = fib; this.lines = lines; this.zones = zones; this.vp = vp; this.whales = whales; this.rsiOn = rsi;
        invalidate();
    }

    public void zoom(int delta) {
        visible = Math.max(30, Math.min(250, visible + delta));
        invalidate();
    }

    public void setData(Candles c, PatternEngine.Result p, double[] whaleBuy, double[] whaleSell, String tf, boolean showVwap) {
        data = c;
        pat = p;
        wBuy = whaleBuy;
        wSell = whaleSell;
        this.tf = tf;
        vwapOn = showVwap;
        ema20 = Indicators.ema(c.close, 20);
        ema50 = Indicators.ema(c.close, 50);
        vwap = new double[c.n];
        double pv = 0, vv = 0;
        long day = -1;
        for (int i = 0; i < c.n; i++) {
            long dd = c.time[i] / 86_400_000L;
            if (dd != day) { day = dd; pv = 0; vv = 0; }
            double tp = (c.high[i] + c.low[i] + c.close[i]) / 3;
            pv += tp * c.vol[i];
            vv += c.vol[i];
            vwap[i] = vv > 0 ? pv / vv : tp;
        }
        touchIdx = -1;
        invalidate();
    }

    public void setPlan(boolean on, boolean buy, double entry, double sl, double tp1, double tp2) {
        planOn = on; planBuy = buy; pEntry = entry; pSl = sl; pTp1 = tp1; pTp2 = tp2;
        invalidate();
    }

    // ------------------------------------------------------------ geometry
    private float top, priceBottom, volTop, volBottom, rsiTop, rsiBottom, plotW, cw;
    private int start;
    private double max, min, range;

    private float rightPad() { return 58 * d; }
    private float x(double i) { return (float) ((i - start) * cw + cw / 2); }
    private float y(double v) { return (float) (top + (max - v) / range * (priceBottom - top)); }

    private void layout(float w, float h) {
        top = 20 * d;
        float axisH = 14 * d, gap = 6 * d;
        float rsiH = rsiOn ? h * 0.15f : 0;
        float volH = h * 0.11f;
        rsiBottom = h - axisH;
        rsiTop = rsiBottom - rsiH;
        volBottom = rsiOn ? rsiTop - gap : rsiBottom;
        volTop = volBottom - volH;
        priceBottom = volTop - gap;
        plotW = w - rightPad();
        int vis = Math.min(visible, data.n);
        start = data.n - vis;
        cw = plotW / (vis + FUTURE);
        max = -Double.MAX_VALUE;
        min = Double.MAX_VALUE;
        for (int i = start; i < data.n; i++) {
            max = Math.max(max, data.high[i]);
            min = Math.min(min, data.low[i]);
        }
        double r0 = Math.max(max - min, max * 0.002);
        if (pat != null && pat.target > 0 && lines) {
            if (pat.target > max && pat.target < max + r0 * 0.6) max = pat.target;
            if (pat.target < min && pat.target > min - r0 * 0.6) min = pat.target;
        }
        range = Math.max(max - min, max * 0.002);
        max += range * 0.05;
        min -= range * 0.05;
        range = max - min;
    }

    private void paint(Paint p, int color, float width) {
        p.setColor(color);
        p.setStrokeWidth(width);
    }

    private void label(Canvas cv, String s, float x, float y, int color, float size, boolean bold) {
        text.setColor(color);
        text.setTextSize(size * d);
        text.setFakeBoldText(bold);
        cv.drawText(s, x, y, text);
        text.setFakeBoldText(false);
        text.setTextSize(10 * d);
    }

    private void tag(Canvas cv, String s, float x, float y, int bg, int fg) {
        text.setTextSize(9.5f * d);
        text.setFakeBoldText(true);
        float tw = text.measureText(s);
        fill.setColor(bg);
        cv.drawRoundRect(new RectF(x, y - 7 * d, x + tw + 6 * d, y + 7 * d), 3 * d, 3 * d, fill);
        text.setColor(fg);
        cv.drawText(s, x + 3 * d, y + 3.5f * d, text);
        text.setFakeBoldText(false);
        text.setTextSize(10 * d);
    }

    // ------------------------------------------------------------ draw
    @Override
    protected void onDraw(Canvas cv) {
        super.onDraw(cv);
        float w = getWidth(), h = getHeight();
        if (data == null || data.n < 2) {
            label(cv, message, 12 * d, h / 2, TXT, 12, false);
            return;
        }
        layout(w, h);

        for (int g = 0; g <= 4; g++) {
            float yy = top + (priceBottom - top) * g / 4f;
            cv.drawLine(0, yy, plotW, yy, grid);
            label(cv, Fmt.price(max - range * g / 4.0), plotW + 4 * d, yy + 4 * d, TXT, 9.5f, false);
        }

        if (pat != null && zones) drawZones(cv);
        if (pat != null && vp) drawVolumeProfile(cv);
        if (pat != null && fib) drawFib(cv);
        drawCandles(cv);
        drawSeries(cv, ema20, EMA20, 1.4f);
        drawSeries(cv, ema50, EMA50, 1.4f);
        if (vwapOn) drawSeries(cv, vwap, VWAP, 1.2f);
        if (pat != null && lines) drawPattern(cv);
        if (planOn) drawPlan(cv);
        if (whales) drawWhales(cv);
        if (pat != null) drawCandleMarks(cv);

        double lp = data.close[data.n - 1];
        float ly = y(lp);
        paint(dash, 0xAAF0B90B, 1);
        cv.drawLine(0, ly, plotW, ly, dash);
        boolean upC = data.close[data.n - 1] >= data.open[data.n - 1];
        tag(cv, Fmt.price(lp), plotW + 1 * d, ly, upC ? UP : DOWN, 0xFFFFFFFF);

        drawVolume(cv);
        if (rsiOn && pat != null && pat.rsi != null) drawRsi(cv);
        drawTimeAxis(cv, h);
        drawLegend(cv);
        if (touchIdx >= start && touchIdx < data.n) drawTouch(cv, w);
    }

    private void drawZones(Canvas cv) {
        double hw = Math.max(pat.atr * 0.3, range * 0.006);
        for (PatternEngine.Zone z : pat.zones) {
            float y1 = y(z.price + hw), y2 = y(z.price - hw);
            if (y2 < top || y1 > priceBottom) continue;
            fill.setColor(z.support ? 0x2A0ECB81 : 0x2AF6465D);
            cv.drawRect(0, Math.max(top, y1), plotW, Math.min(priceBottom, y2), fill);
            tag(cv, (z.support ? "S " : "R ") + z.touches + "x  " + Fmt.price(z.price), 2 * d, (y1 + y2) / 2,
                    z.support ? 0xCC0B5E44 : 0xCC7A1F2B, 0xFFFFFFFF);
        }
    }

    private void drawVolumeProfile(Canvas cv) {
        if (pat.vpBuy == null) return;
        int bins = pat.vpBuy.length;
        double mx = 0;
        for (int b = 0; b < bins; b++) mx = Math.max(mx, pat.vpBuy[b] + pat.vpSell[b]);
        if (mx <= 0) return;
        float vpW = plotW * 0.22f;
        double step = (pat.vpHi - pat.vpLo) / bins;
        for (int b = 0; b < bins; b++) {
            float y1 = y(pat.vpLo + (b + 1) * step), y2 = y(pat.vpLo + b * step);
            if (y2 < top || y1 > priceBottom) continue;
            float lb = (float) (pat.vpBuy[b] / mx * vpW), ls = (float) (pat.vpSell[b] / mx * vpW);
            float yy1 = y1 + 0.6f * d, yy2 = Math.max(yy1 + 1, y2 - 0.6f * d);
            fill.setColor(b == pat.poc ? 0x9938BDF8 : 0x5538BDF8);
            cv.drawRect(plotW - lb, yy1, plotW, yy2, fill);
            fill.setColor(b == pat.poc ? 0x99F0B90B : 0x55F0B90B);
            cv.drawRect(plotW - lb - ls, yy1, plotW - lb, yy2, fill);
        }
        if (pat.poc >= 0) {
            double pp = pat.vpLo + (pat.poc + 0.5) * step;
            float yy = y(pp);
            paint(dash, 0x99F0B90B, 1);
            cv.drawLine(0, yy, plotW, yy, dash);
            label(cv, "POC", plotW - vpW - 22 * d, yy - 2 * d, 0xFFF0B90B, 9, true);
        }
    }

    private void drawFib(Canvas cv) {
        if (!pat.hasFib) return;
        double hi = pat.fibHi, lo = pat.fibLo, rng = hi - lo;
        int from = Math.max(start, Math.min(pat.fibHiIdx, pat.fibLoIdx));
        float x0 = x(from);
        for (int k = 0; k < PatternEngine.FIB.length; k++) {
            double r = PatternEngine.FIB[k];
            double pr = pat.fibUp ? hi - rng * r : lo + rng * r;
            float yy = y(pr);
            if (yy < top || yy > priceBottom) continue;
            paint(stroke, (FIB_COL[k] & 0x00FFFFFF) | 0xAA000000, 1.1f * d);
            cv.drawLine(x0, yy, plotW, yy, stroke);
            label(cv, String.format(Locale.US, "%s(%s)", trimFib(r), Fmt.price(pr)), x0 + 2 * d, yy - 2 * d, FIB_COL[k], 9, false);
        }
        // golden pocket shading
        double a = pat.fibUp ? hi - rng * 0.5 : lo + rng * 0.5, b = pat.fibUp ? hi - rng * 0.618 : lo + rng * 0.618;
        fill.setColor(0x1A14B8A6);
        cv.drawRect(x0, Math.min(y(a), y(b)), plotW, Math.max(y(a), y(b)), fill);
    }

    private static String trimFib(double r) {
        if (r == 0) return "0";
        if (r == 1) return "1";
        String s = String.format(Locale.US, "%.3f", r);
        while (s.endsWith("0")) s = s.substring(0, s.length() - 1);
        return s;
    }

    private void drawCandles(Canvas cv) {
        float half = Math.max(1, cw * 0.36f);
        for (int i = start; i < data.n; i++) {
            float xx = x(i);
            boolean up = data.close[i] >= data.open[i];
            fill.setColor(up ? UP : DOWN);
            paint(stroke, up ? UP : DOWN, Math.max(1, 1.1f * d));
            cv.drawLine(xx, y(data.high[i]), xx, y(data.low[i]), stroke);
            float yo = y(data.open[i]), yc = y(data.close[i]);
            float bt = Math.min(yo, yc), bb = Math.max(Math.max(yo, yc), bt + 1.2f * d);
            cv.drawRect(xx - half, bt, xx + half, bb, fill);
        }
    }

    private void drawSeries(Canvas cv, double[] e, int color, float width) {
        if (e == null) return;
        Path path = new Path();
        boolean first = true;
        for (int i = start; i < data.n; i++) {
            float yy = y(e[i]);
            if (yy < top || yy > priceBottom) { first = true; continue; }
            if (first) { path.moveTo(x(i), yy); first = false; } else path.lineTo(x(i), yy);
        }
        paint(stroke, color, width * d);
        cv.drawPath(path, stroke);
    }

    private void drawPattern(Canvas cv) {
        int lastI = data.n - 1;
        float xEnd = x(lastI + FUTURE - 1);
        if (pat.res != null) drawTrend(cv, pat.res, 0xFFF6465D, xEnd);
        if (pat.sup != null) drawTrend(cv, pat.sup, 0xFF0ECB81, xEnd);

        // divergence line on price
        if (pat.divType != 0 && pat.divA >= start) {
            boolean bull = pat.divType > 0;
            double pa = bull ? data.low[pat.divA] : data.high[pat.divA], pb = bull ? data.low[pat.divB] : data.high[pat.divB];
            paint(stroke, bull ? 0xFF9BE15D : 0xFFFF8A3D, 1.6f * d);
            cv.drawLine(x(pat.divA), y(pa), x(pat.divB), y(pb), stroke);
        }

        // projected move arrow (like the dashed arrow on hand-drawn charts)
        int bias = pat.bias;
        int col = bias > 0 ? UP : DOWN;
        if (pat.target > 0 && bias != 0) {
            float x1 = x(lastI), y1 = y(data.close[lastI]);
            float x2 = x(lastI + FUTURE - 3), y2 = Math.max(top + 4 * d, Math.min(priceBottom - 4 * d, y(pat.target)));
            paint(dash, col, 2 * d);
            Path p = new Path();
            p.moveTo(x1, y1);
            p.lineTo(x2, y2);
            cv.drawPath(p, dash);
            paint(stroke, col, 2 * d);
            double ang = Math.atan2(y2 - y1, x2 - x1);
            float hl = 8 * d;
            cv.drawLine(x2, y2, (float) (x2 - hl * Math.cos(ang - 0.45)), (float) (y2 - hl * Math.sin(ang - 0.45)), stroke);
            cv.drawLine(x2, y2, (float) (x2 - hl * Math.cos(ang + 0.45)), (float) (y2 - hl * Math.sin(ang + 0.45)), stroke);
            tag(cv, "🎯 " + Fmt.price(pat.target), Math.min(x2 - 20 * d, plotW - 70 * d), y2 + (bias > 0 ? -11 : 11) * d, col, 0xFF0A0E17);
        }

        // callout box with the pattern name + what has to happen next
        List<String> ls = new ArrayList<>();
        ls.add(pat.name);
        ls.addAll(wrap(pat.note, plotW * 0.62f));
        text.setTextSize(10 * d);
        float bw = 0;
        for (String s : ls) bw = Math.max(bw, text.measureText(s));
        bw += 12 * d;
        float bh = ls.size() * 13 * d + 8 * d;
        float bx = 6 * d, by = top + 18 * d;
        fill.setColor(0xE6141B2B);
        RectF box = new RectF(bx, by, bx + bw, by + bh);
        cv.drawRoundRect(box, 8 * d, 8 * d, fill);
        paint(stroke, col, 1.5f * d);
        cv.drawRoundRect(box, 8 * d, 8 * d, stroke);
        for (int i = 0; i < ls.size(); i++) {
            label(cv, ls.get(i), bx + 6 * d, by + 15 * d + i * 13 * d, i == 0 ? col : WHITE, i == 0 ? 11 : 9.5f, i == 0);
        }
    }

    private List<String> wrap(String s, float maxW) {
        List<String> out = new ArrayList<>();
        if (s == null || s.isEmpty()) return out;
        text.setTextSize(9.5f * d);
        StringBuilder line = new StringBuilder();
        for (String word : s.split(" ")) {
            String t = line.length() == 0 ? word : line + " " + word;
            if (text.measureText(t) > maxW && line.length() > 0) {
                out.add(line.toString());
                line = new StringBuilder(word);
                if (out.size() == 2) break;
            } else {
                line = new StringBuilder(t);
            }
        }
        if (out.size() < 3 && line.length() > 0) out.add(line.toString());
        text.setTextSize(10 * d);
        return out;
    }

    private void drawTrend(Canvas cv, PatternEngine.Line l, int color, float xEnd) {
        int i0 = Math.max(start, l.i1);
        double endIdx = (xEnd - cw / 2) / cw + start;
        float x1 = x(i0), y1 = y(l.at(i0)), x2 = xEnd, y2 = y(l.at(endIdx));
        paint(stroke, color, 2 * d);
        cv.drawLine(x1, y1, x2, y2, stroke);
        fill.setColor(color);
        if (l.i1 >= start) cv.drawCircle(x(l.i1), y(l.p1), 3 * d, fill);
        if (l.i2 >= start) cv.drawCircle(x(l.i2), y(l.p2), 3 * d, fill);
    }

    private void drawPlan(Canvas cv) {
        double[] v = {pEntry, pSl, pTp1, pTp2};
        String[] n = {"ENTRY", "STOP", "TP1", "TP2"};
        int[] c = {accent, DOWN, UP, UP};
        float xs = x(data.n - 1);
        for (int k = 0; k < 4; k++) {
            if (v[k] <= 0) continue;
            float yy = y(v[k]);
            if (yy < top || yy > priceBottom) continue;
            paint(dash, c[k], 1.4f * d);
            cv.drawLine(xs, yy, plotW, yy, dash);
            tag(cv, n[k] + " " + Fmt.price(v[k]), Math.max(xs - 2 * d, plotW - 92 * d), yy, c[k], 0xFF0A0E17);
        }
    }

    private void drawWhales(Canvas cv) {
        double mx = 0;
        if (wBuy != null) for (int i = start; i < data.n && i < wBuy.length; i++) mx = Math.max(mx, Math.max(wBuy[i], wSell[i]));
        int bigI = -1;
        double big = 0;
        for (int i = start; i < data.n; i++) {
            float xx = x(i);
            float yl = y(data.low[i]) + 7 * d, yh = y(data.high[i]) - 7 * d;
            int cr = pat != null && pat.crowd != null && i < pat.crowd.length ? pat.crowd[i] : 0;
            boolean exact = false;
            if (wBuy != null && i < wBuy.length && mx > 0) {
                if (wBuy[i] > 0) {
                    float r = (float) Math.max(2.5 * d, Math.sqrt(wBuy[i] / mx) * Math.max(cw, 6 * d) * 0.9);
                    fill.setColor(0xCC0ECB81);
                    cv.drawCircle(xx, yl + r, r, fill);
                    paint(stroke, 0xFFFFFFFF, 1);
                    cv.drawCircle(xx, yl + r, r, stroke);
                    exact = true;
                    if (wBuy[i] > big) { big = wBuy[i]; bigI = i; }
                }
                if (wSell[i] > 0) {
                    float r = (float) Math.max(2.5 * d, Math.sqrt(wSell[i] / mx) * Math.max(cw, 6 * d) * 0.9);
                    fill.setColor(0xCCF6465D);
                    cv.drawCircle(xx, yh - r, r, fill);
                    paint(stroke, 0xFFFFFFFF, 1);
                    cv.drawCircle(xx, yh - r, r, stroke);
                    exact = true;
                    if (wSell[i] > big) { big = wSell[i]; bigI = -i - 2; }
                }
            }
            if (!exact) {
                if (cr == 2) label(cv, "W", xx - 3 * d, yl + 7 * d, UP, 9, true);
                else if (cr == -2) label(cv, "W", xx - 3 * d, yh, DOWN, 9, true);
            }
            if (cr == 1) { fill.setColor(0xCC38BDF8); cv.drawCircle(xx, yl + (exact ? 14 : 3) * d, 1.8f * d, fill); }
            else if (cr == -1) { fill.setColor(0xCCFF8A3D); cv.drawCircle(xx, yh - (exact ? 14 : 3) * d, 1.8f * d, fill); }
        }
        if (bigI != -1 && big > 0) {
            boolean buy = bigI >= 0;
            int i = buy ? bigI : -bigI - 2;
            float yy = buy ? y(data.low[i]) + 30 * d : y(data.high[i]) - 26 * d;
            tag(cv, "🐋 " + (buy ? "BUY " : "SELL ") + Fmt.usd(big), Math.min(x(i) - 20 * d, plotW - 90 * d),
                    Math.max(top + 8 * d, Math.min(priceBottom - 8 * d, yy)), buy ? 0xDD0B5E44 : 0xDD7A1F2B, 0xFFFFFFFF);
        }
    }

    private void drawCandleMarks(Canvas cv) {
        for (PatternEngine.Mark m : pat.marks) {
            if (m.idx < start || m.idx >= data.n) continue;
            float xx = x(m.idx);
            if (m.side > 0) label(cv, m.label, xx - 12 * d, y(data.low[m.idx]) + 22 * d, 0xFF9BE15D, 8, true);
            else label(cv, m.label, xx - 12 * d, y(data.high[m.idx]) - 16 * d, 0xFFFF8A3D, 8, true);
        }
    }

    private void drawVolume(Canvas cv) {
        double mv = 0;
        for (int i = start; i < data.n; i++) mv = Math.max(mv, data.vol[i]);
        cv.drawLine(0, volTop - 3 * d, plotW, volTop - 3 * d, grid);
        label(cv, "Volume: green = buyers · red = sellers", 3 * d, volTop + 8 * d, TXT, 8.5f, false);
        if (mv <= 0) return;
        float half = Math.max(1, cw * 0.36f), vh = volBottom - volTop;
        for (int i = start; i < data.n; i++) {
            float xx = x(i);
            float total = (float) (data.vol[i] / mv * vh);
            float buy = data.vol[i] > 0 ? (float) (data.takerBuy[i] / data.vol[i]) * total : 0;
            fill.setColor(0xAA0ECB81);
            cv.drawRect(xx - half, volBottom - buy, xx + half, volBottom, fill);
            fill.setColor(0xAAF6465D);
            cv.drawRect(xx - half, volBottom - total, xx + half, volBottom - buy, fill);
        }
    }

    private void drawRsi(Canvas cv) {
        float h = rsiBottom - rsiTop;
        cv.drawLine(0, rsiTop - 3 * d, plotW, rsiTop - 3 * d, grid);
        float y70 = rsiTop + h * 0.3f, y30 = rsiTop + h * 0.7f, y50 = rsiTop + h * 0.5f;
        paint(stroke, 0x55F6465D, 1);
        cv.drawLine(0, y70, plotW, y70, stroke);
        paint(stroke, 0x550ECB81, 1);
        cv.drawLine(0, y30, plotW, y30, stroke);
        paint(dash, 0x33FFFFFF, 1);
        cv.drawLine(0, y50, plotW, y50, dash);
        label(cv, "70", plotW + 4 * d, y70 + 3 * d, DOWN, 9, false);
        label(cv, "30", plotW + 4 * d, y30 + 3 * d, UP, 9, false);
        Path p = new Path();
        boolean first = true;
        for (int i = Math.max(start, 14); i < data.n && i < pat.rsi.length; i++) {
            float yy = rsiTop + (float) ((100 - pat.rsi[i]) / 100.0 * h);
            if (first) { p.moveTo(x(i), yy); first = false; } else p.lineTo(x(i), yy);
        }
        paint(stroke, accent, 1.5f * d);
        cv.drawPath(p, stroke);
        int li = Math.min(data.n, pat.rsi.length) - 1;
        label(cv, String.format(Locale.US, "RSI %.0f", pat.rsi[li]), 3 * d, rsiTop + 9 * d, accent, 9, true);
        if (pat.divType != 0 && pat.divA >= start && pat.divB < pat.rsi.length) {
            boolean bull = pat.divType > 0;
            paint(stroke, bull ? 0xFF9BE15D : 0xFFFF8A3D, 1.8f * d);
            float ya = rsiTop + (float) ((100 - pat.rsi[pat.divA]) / 100.0 * h), yb = rsiTop + (float) ((100 - pat.rsi[pat.divB]) / 100.0 * h);
            cv.drawLine(x(pat.divA), ya, x(pat.divB), yb, stroke);
            label(cv, bull ? "Bull div" : "Bear div", x(pat.divB) + 4 * d, yb, bull ? 0xFF9BE15D : 0xFFFF8A3D, 9, true);
        }
    }

    private void drawTimeAxis(Canvas cv, float h) {
        boolean intraday = tf.endsWith("m") || tf.equals("1h");
        SimpleDateFormat f = new SimpleDateFormat(intraday ? "dd MMM HH:mm" : "dd MMM yy", Locale.US);
        int vis = data.n - start;
        for (int k = 0; k < 4; k++) {
            int i = start + (int) (vis * (k + 0.5) / 4);
            if (i >= data.n) continue;
            label(cv, f.format(new Date(data.time[i])), x(i) - 22 * d, h - 3 * d, TXT, 8.5f, false);
        }
    }

    private void drawLegend(Canvas cv) {
        float xx = 4 * d, yy = 13 * d;
        String[] n = {"EMA20", "EMA50", vwapOn ? "VWAP" : null};
        int[] c = {EMA20, EMA50, VWAP};
        for (int k = 0; k < 3; k++) {
            if (n[k] == null) continue;
            label(cv, n[k], xx, yy, c[k], 9.5f, true);
            xx += 44 * d;
        }
        if (whales) label(cv, "🟢🔴 whale orders · W = whale candle · • retail", xx, yy, TXT, 9, false);
    }

    private void drawTouch(Canvas cv, float w) {
        int i = touchIdx;
        paint(stroke, 0x88FFFFFF, 1);
        cv.drawLine(x(i), top, x(i), rsiBottom, stroke);
        double chg = data.open[i] > 0 ? (data.close[i] / data.open[i] - 1) * 100 : 0;
        double bp = data.vol[i] > 0 ? data.takerBuy[i] / data.vol[i] * 100 : 50;
        String when = new SimpleDateFormat("dd MMM HH:mm", Locale.US).format(new Date(data.time[i]));
        StringBuilder s = new StringBuilder(when).append("  O ").append(Fmt.price(data.open[i]))
                .append(" H ").append(Fmt.price(data.high[i])).append(" L ").append(Fmt.price(data.low[i]))
                .append(" C ").append(Fmt.price(data.close[i]))
                .append(String.format(Locale.US, "  %+.2f%%  Buy %.0f%%", chg, bp));
        int cr = pat != null && pat.crowd != null && i < pat.crowd.length ? pat.crowd[i] : 0;
        String extra = "";
        if (wBuy != null && i < wBuy.length && (wBuy[i] > 0 || wSell[i] > 0))
            extra = "🐋 Whale buy " + Fmt.usd(wBuy[i]) + " · sell " + Fmt.usd(wSell[i]);
        else if (cr == 2) extra = "W: is candle mein bade (whale) buyers";
        else if (cr == -2) extra = "W: is candle mein bade (whale) sellers";
        else if (cr == 1) extra = "Retail crowd khareed raha tha";
        else if (cr == -1) extra = "Retail crowd bech raha tha";
        fill.setColor(0xF0141B2B);
        cv.drawRect(0, 0, w, extra.isEmpty() ? 18 * d : 31 * d, fill);
        label(cv, s.toString(), 4 * d, 12.5f * d, WHITE, 9.5f, false);
        if (!extra.isEmpty()) label(cv, extra, 4 * d, 26 * d, 0xFFF0B90B, 9.5f, true);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (data == null || data.n == 0 || cw <= 0) return false;
        int idx = start + (int) (e.getX() / cw);
        idx = Math.max(start, Math.min(data.n - 1, idx));
        int a = e.getAction();
        boolean end = a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL;
        touchIdx = end ? -1 : idx;
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(!end);
        invalidate();
        return true;
    }
}
