package com.signal.bot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Finds chart structure the way a trader would draw it by hand:
 * swing pivots, trendlines (triangle / wedge / channel / range), breakouts, double top/bottom,
 * Fibonacci retracement, support/resistance zones, volume profile, candle patterns,
 * RSI divergence and whale vs retail activity per candle. Pure Java (no Android).
 */
public final class PatternEngine {
    private PatternEngine() {}

    public static final class Line {
        public final int i1, i2;
        public final double p1, p2;

        Line(int i1, double p1, int i2, double p2) {
            this.i1 = i1; this.p1 = p1; this.i2 = i2; this.p2 = p2;
        }

        public double at(double i) { return p1 + (p2 - p1) * (i - i1) / (double) (i2 - i1); }
        public double slope() { return (p2 - p1) / (i2 - i1); }
    }

    public static final class Mark {
        public final int idx, side;   // side +1 bullish (drawn below), -1 bearish (drawn above)
        public final String label;

        Mark(int idx, String label, int side) { this.idx = idx; this.label = label; this.side = side; }
    }

    public static final class Zone {
        public final double price;
        public final int touches;
        public final boolean support;

        Zone(double price, int touches, boolean support) { this.price = price; this.touches = touches; this.support = support; }
    }

    public static final class Result {
        public Line res, sup;
        public String name = "Koi saaf pattern nahi";
        public String note = "";
        public int bias;               // +1 bullish, -1 bearish
        public boolean breakout;
        public double keyLevel, target;
        public boolean hasFib, fibUp;
        public double fibHi, fibLo;
        public int fibHiIdx, fibLoIdx;
        public final List<Zone> zones = new ArrayList<>();
        public double vpLo, vpHi;
        public double[] vpBuy, vpSell;
        public int poc = -1;
        public final List<Mark> marks = new ArrayList<>();
        public double[] rsi;
        public int divA = -1, divB = -1, divType;   // divType +1 bullish, -1 bearish
        public int[] crowd;            // +2 whale buy, -2 whale sell, +1 retail buy crowd, -1 retail sell crowd
        public double atr;
        public int score;              // -100..+100
        public final List<String> notes = new ArrayList<>();
    }

    public static final double[] FIB = {0, 0.236, 0.382, 0.5, 0.618, 0.786, 1};

    private static String p(double v) { return Fmt.price(v); }

    public static Result analyze(Candles c, int window) {
        Result r = new Result();
        int n = c.n;
        r.rsi = Indicators.rsi(c.close, 14);
        r.crowd = new int[n];
        if (n < 40) {
            r.name = "Data kam hai";
            return r;
        }
        int from = Math.max(0, n - window);
        int li = n - 1;
        double last = c.close[li];
        r.atr = Indicators.atr(c.high, c.low, c.close, 14);
        if (r.atr <= 0) r.atr = last * 0.01;
        double[] ema20 = Indicators.ema(c.close, 20);
        double score = 0;

        // ---------- swing pivots
        int k = window >= 120 ? 4 : 3;
        List<Integer> ph = new ArrayList<>(), pl = new ArrayList<>();
        for (int i = from + k; i < n - k; i++) {
            boolean hi = true, lo = true;
            for (int j = i - k; j <= i + k; j++) {
                if (j == i) continue;
                if (c.high[j] > c.high[i] || (j > i && c.high[j] == c.high[i])) hi = false;
                if (c.low[j] < c.low[i] || (j > i && c.low[j] == c.low[i])) lo = false;
            }
            if (hi) ph.add(i);
            if (lo) pl.add(i);
        }

        // ---------- trendlines through the last two swing highs / lows
        if (ph.size() >= 2) {
            int a = ph.get(ph.size() - 2), b = ph.get(ph.size() - 1);
            if (b - a < 5 && ph.size() >= 3) a = ph.get(ph.size() - 3);
            r.res = new Line(a, c.high[a], b, c.high[b]);
        }
        if (pl.size() >= 2) {
            int a = pl.get(pl.size() - 2), b = pl.get(pl.size() - 1);
            if (b - a < 5 && pl.size() >= 3) a = pl.get(pl.size() - 3);
            r.sup = new Line(a, c.low[a], b, c.low[b]);
        }

        boolean up = last > ema20[li];
        if (r.res != null && r.sup != null) {
            double rs = r.res.slope() / r.atr, ss = r.sup.slope() / r.atr, flat = 0.03;
            int rd = Math.abs(rs) < flat ? 0 : (rs > 0 ? 1 : -1);
            int sd = Math.abs(ss) < flat ? 0 : (ss > 0 ? 1 : -1);
            double resNow = r.res.at(li), supNow = r.sup.at(li);
            if (rd == 0 && sd == 1) { r.name = "Ascending triangle"; r.bias = 1; }
            else if (rd == -1 && sd == 0) { r.name = "Descending triangle"; r.bias = -1; }
            else if (rd == -1 && sd == 1) { r.name = "Symmetrical triangle"; r.bias = up ? 1 : -1; }
            else if (rd == 1 && sd == 1) {
                if (ss > rs * 1.3) { r.name = "Rising wedge"; r.bias = -1; }
                else { r.name = "Rising channel"; r.bias = 1; }
            } else if (rd == -1 && sd == -1) {
                if (rs < ss * 1.3) { r.name = "Falling wedge"; r.bias = 1; }
                else { r.name = "Falling channel"; r.bias = -1; }
            } else if (rd == 0 && sd == 0) { r.name = "Range (sideways box)"; r.bias = last > (resNow + supNow) / 2 ? 1 : -1; }
            else if (rd == 1 && sd == -1) { r.name = "Broadening pattern"; r.bias = up ? 1 : -1; }
            else { r.name = (rd + sd) > 0 ? "Uptrend structure" : "Downtrend structure"; r.bias = (rd + sd) > 0 ? 1 : -1; }

            double height = Math.max(Math.abs(resNow - supNow), r.atr * 2);
            if (last > resNow + 0.1 * r.atr) {
                r.breakout = true;
                r.bias = 1;
                r.keyLevel = resNow;
                r.target = resNow + height;
                r.name = r.name + " → BREAKOUT ⬆";
                r.note = "Resistance $" + p(resNow) + " toot gaya. Retest par buy zone, target ~$" + p(r.target);
            } else if (last < supNow - 0.1 * r.atr) {
                r.breakout = true;
                r.bias = -1;
                r.keyLevel = supNow;
                r.target = supNow - height;
                r.name = r.name + " → BREAKDOWN ⬇";
                r.note = "Support $" + p(supNow) + " toot gaya. Target ~$" + p(r.target) + " — wapas upar aaye bina buy nahi";
            } else if (r.bias > 0) {
                r.keyLevel = resNow;
                r.target = resNow + height;
                r.note = "Continuation ke liye $" + p(resNow) + " todna zaroori · phir target ~$" + p(r.target);
            } else {
                r.keyLevel = supNow;
                r.target = supNow - height;
                r.note = "$" + p(supNow) + " toota to girawat ~$" + p(r.target) + " tak · upar ke liye $" + p(resNow) + " todna hoga";
            }
        } else {
            r.bias = up ? 1 : -1;
            r.name = up ? "Uptrend (EMA20 ke upar)" : "Downtrend (EMA20 ke neeche)";
            r.keyLevel = ema20[li];
            r.note = up ? "Jab tak price $" + p(ema20[li]) + " ke upar hai, buyers control mein"
                    : "Upar jaane ke liye $" + p(ema20[li]) + " (EMA20) wapas lena hoga";
        }

        // ---------- double top / bottom (overrides when recent)
        if (ph.size() >= 2) {
            int a = ph.get(ph.size() - 2), b = ph.get(ph.size() - 1);
            if (li - b <= 25 && b - a >= 6 && Math.abs(c.high[a] - c.high[b]) <= 0.5 * r.atr + 0.003 * c.high[b]) {
                double neck = Double.MAX_VALUE;
                for (int i = a; i <= b; i++) neck = Math.min(neck, c.low[i]);
                double top = Math.max(c.high[a], c.high[b]);
                if (last < neck) {
                    r.name = "Double top (confirmed) ⬇"; r.bias = -1; r.breakout = true;
                    r.keyLevel = neck; r.target = neck - (top - neck);
                    r.note = "Neckline $" + p(neck) + " toot gayi · target ~$" + p(r.target);
                } else if (!r.breakout && last < top && !(r.sup != null && r.sup.slope() / r.atr > 0.03)) {
                    r.name = "Double top ban raha"; r.bias = -1;
                    r.keyLevel = neck; r.target = neck - (top - neck);
                    r.note = "$" + p(top) + " par 2 dafa rejection · neckline $" + p(neck) + " par nazar rakhen";
                }
            }
        }
        if (pl.size() >= 2) {
            int a = pl.get(pl.size() - 2), b = pl.get(pl.size() - 1);
            if (li - b <= 25 && b - a >= 6 && Math.abs(c.low[a] - c.low[b]) <= 0.5 * r.atr + 0.003 * c.low[b]) {
                double neck = 0;
                for (int i = a; i <= b; i++) neck = Math.max(neck, c.high[i]);
                double bot = Math.min(c.low[a], c.low[b]);
                if (last > neck) {
                    r.name = "Double bottom (confirmed) ⬆"; r.bias = 1; r.breakout = true;
                    r.keyLevel = neck; r.target = neck + (neck - bot);
                    r.note = "Neckline $" + p(neck) + " toot gayi · target ~$" + p(r.target);
                } else if (!r.breakout && last > bot && !r.name.startsWith("Double top")
                        && !(r.res != null && r.res.slope() / r.atr < -0.03)) {
                    r.name = "Double bottom ban raha"; r.bias = 1;
                    r.keyLevel = neck; r.target = neck + (neck - bot);
                    r.note = "$" + p(bot) + " par 2 dafa support · neckline $" + p(neck) + " todna zaroori";
                }
            }
        }
        score += r.bias * 35 + (r.breakout ? r.bias * 20 : 0);
        r.notes.add("Pattern: " + r.name);
        if (!r.note.isEmpty()) r.notes.add(r.note);

        // ---------- Fibonacci on the window's main swing
        int hiI = from, loI = from;
        for (int i = from; i < n; i++) {
            if (c.high[i] > c.high[hiI]) hiI = i;
            if (c.low[i] < c.low[loI]) loI = i;
        }
        r.fibHi = c.high[hiI];
        r.fibLo = c.low[loI];
        r.fibHiIdx = hiI;
        r.fibLoIdx = loI;
        r.fibUp = loI < hiI;
        r.hasFib = r.fibHi > r.fibLo;
        if (r.hasFib) {
            double rng = r.fibHi - r.fibLo;
            double pos = r.fibUp ? (r.fibHi - last) / rng : (last - r.fibLo) / rng;
            if (pos >= 0.5 && pos <= 0.65) {
                r.notes.add("Fibonacci golden pocket (0.5–0.618) mein — " + (r.fibUp ? "bounce / buy zone" : "rejection / sell zone"));
                score += r.fibUp ? 12 : -12;
            } else {
                r.notes.add(String.format(Locale.US, "Fibonacci: price %.0f%% retrace par (%s move ke baad)", pos * 100, r.fibUp ? "upar" : "neeche"));
            }
        }

        // ---------- support / resistance zones from clustered pivots
        List<double[]> pts = new ArrayList<>();
        for (int i : ph) pts.add(new double[]{c.high[i]});
        for (int i : pl) pts.add(new double[]{c.low[i]});
        Collections.sort(pts, (x, y) -> Double.compare(x[0], y[0]));
        List<double[]> clusters = new ArrayList<>(); // {sum, count}
        for (double[] q : pts) {
            if (!clusters.isEmpty()) {
                double[] cl = clusters.get(clusters.size() - 1);
                if (q[0] - cl[0] / cl[1] <= 0.6 * r.atr) { cl[0] += q[0]; cl[1]++; continue; }
            }
            clusters.add(new double[]{q[0], 1});
        }
        List<Zone> sup = new ArrayList<>(), res = new ArrayList<>();
        for (double[] cl : clusters) {
            if (cl[1] < 2) continue;
            double pr = cl[0] / cl[1];
            if (pr < last) sup.add(new Zone(pr, (int) cl[1], true)); else res.add(new Zone(pr, (int) cl[1], false));
        }
        Collections.sort(sup, (x, y) -> Double.compare(y.price, x.price));
        Collections.sort(res, (x, y) -> Double.compare(x.price, y.price));
        for (int i = 0; i < sup.size() && i < 2; i++) r.zones.add(sup.get(i));
        for (int i = 0; i < res.size() && i < 2; i++) r.zones.add(res.get(i));
        if (!sup.isEmpty() && last - sup.get(0).price <= 0.8 * r.atr) {
            r.notes.add("Strong support ke qareeb $" + p(sup.get(0).price) + " (" + sup.get(0).touches + " dafa chhua)");
            score += 10;
        }
        if (!res.isEmpty() && res.get(0).price - last <= 0.8 * r.atr) {
            r.notes.add("Resistance ke qareeb $" + p(res.get(0).price) + " (" + res.get(0).touches + " dafa rejection)");
            score -= 10;
        }

        // ---------- volume profile (buy vs sell volume at each price)
        int bins = 28;
        double lo = Double.MAX_VALUE, hi = 0;
        for (int i = from; i < n; i++) { lo = Math.min(lo, c.low[i]); hi = Math.max(hi, c.high[i]); }
        if (hi > lo) {
            r.vpLo = lo;
            r.vpHi = hi;
            r.vpBuy = new double[bins];
            r.vpSell = new double[bins];
            for (int i = from; i < n; i++) {
                double tp = (c.high[i] + c.low[i] + c.close[i]) / 3;
                int b = (int) Math.min(bins - 1, Math.max(0, (tp - lo) / (hi - lo) * bins));
                r.vpBuy[b] += c.takerBuy[i];
                r.vpSell[b] += c.vol[i] - c.takerBuy[i];
            }
            double best = -1;
            for (int b = 0; b < bins; b++) if (r.vpBuy[b] + r.vpSell[b] > best) { best = r.vpBuy[b] + r.vpSell[b]; r.poc = b; }
            double pocPrice = lo + (r.poc + 0.5) * (hi - lo) / bins;
            if (last > pocPrice) { r.notes.add("Price POC $" + p(pocPrice) + " ke upar — buyers control mein"); score += 8; }
            else { r.notes.add("Price POC $" + p(pocPrice) + " ke neeche — sellers control mein"); score -= 8; }
        }

        // ---------- candle patterns (last 40 candles)
        for (int i = Math.max(from + 1, n - 40); i < n; i++) {
            double o = c.open[i], cl = c.close[i], h = c.high[i], l = c.low[i];
            double body = Math.abs(cl - o), rng = h - l;
            if (rng <= 0) continue;
            double upW = h - Math.max(o, cl), dnW = Math.min(o, cl) - l;
            double po = c.open[i - 1], pc = c.close[i - 1];
            String lab = null;
            int side = 0;
            if (pc < po && cl > o && o <= pc && cl >= po && body > Math.abs(pc - po)) { lab = "Engulf"; side = 1; }
            else if (pc > po && cl < o && o >= pc && cl <= po && body > Math.abs(pc - po)) { lab = "Engulf"; side = -1; }
            else if (dnW >= 2 * body && upW <= Math.max(body * 0.6, rng * 0.1) && cl < ema20[i] * 1.01) { lab = "Hammer"; side = 1; }
            else if (upW >= 2 * body && dnW <= Math.max(body * 0.6, rng * 0.1) && cl > ema20[i] * 0.99) { lab = "Star"; side = -1; }
            if (lab != null) {
                r.marks.add(new Mark(i, lab, side));
                if (i >= n - 2) {
                    score += side * 12;
                    r.notes.add("Taaza candle: " + (side > 0 ? "bullish " : "bearish ") + lab
                            + (lab.equals("Star") ? " (shooting star)" : ""));
                }
            }
        }

        // ---------- RSI divergence
        double[] rsi = r.rsi;
        if (pl.size() >= 2) {
            int a = pl.get(pl.size() - 2), b = pl.get(pl.size() - 1);
            if (li - b <= 15 && c.low[b] < c.low[a] && rsi[b] > rsi[a] + 2) { r.divA = a; r.divB = b; r.divType = 1; }
        }
        if (ph.size() >= 2) {
            int a = ph.get(ph.size() - 2), b = ph.get(ph.size() - 1);
            if (li - b <= 15 && c.high[b] > c.high[a] && rsi[b] < rsi[a] - 2 && (r.divType == 0 || b > r.divB)) {
                r.divA = a; r.divB = b; r.divType = -1;
            }
        }
        if (r.divType > 0) { r.notes.add("RSI bullish divergence — price neeche, RSI upar (reversal ka ishara)"); score += 20; }
        if (r.divType < 0) { r.notes.add("RSI bearish divergence — price upar, RSI neeche (kamzori)"); score -= 20; }

        // ---------- whale vs retail per candle (average trade size)
        double[] avgT = new double[n];
        List<Double> at = new ArrayList<>(), tc = new ArrayList<>();
        double volSum = 0;
        for (int i = from; i < n; i++) {
            avgT[i] = c.trades[i] > 0 ? c.quoteVol[i] / c.trades[i] : 0;
            if (avgT[i] > 0) at.add(avgT[i]);
            tc.add(c.trades[i]);
            volSum += c.vol[i];
        }
        double medAvg = median(at), medTr = median(tc), avgVol = volSum / Math.max(1, n - from);
        int wb = 0, ws = 0;
        if (medAvg > 0) {
            for (int i = from; i < n; i++) {
                double tbq = c.quoteVol[i] > 0 ? c.takerBuyQuote[i] / c.quoteVol[i] : 0.5;
                if (avgT[i] >= 1.8 * medAvg && c.vol[i] >= avgVol) r.crowd[i] = tbq >= 0.52 ? 2 : tbq <= 0.48 ? -2 : 0;
                else if (avgT[i] <= 0.65 * medAvg && c.trades[i] >= 1.5 * medTr) r.crowd[i] = tbq >= 0.52 ? 1 : tbq <= 0.48 ? -1 : 0;
                if (i >= n - 20) {
                    if (r.crowd[i] == 2) wb++;
                    if (r.crowd[i] == -2) ws++;
                }
            }
        }
        if (wb + ws > 0) {
            r.notes.add("Pichhli 20 candles: " + wb + " whale-buy candles · " + ws + " whale-sell candles");
            score += Math.max(-12, Math.min(12, (wb - ws) * 4));
        }

        r.score = (int) Math.round(Math.max(-100, Math.min(100, score)));
        return r;
    }

    private static double median(List<Double> l) {
        if (l.isEmpty()) return 0;
        double[] a = new double[l.size()];
        for (int i = 0; i < a.length; i++) a[i] = l.get(i);
        Arrays.sort(a);
        return a[a.length / 2];
    }
}
