package com.signal.bot;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Separate bots for Gold & Commodities and for Forex. Each scans its own list every 15 minutes
 * (only while the market is open), and saves signals tagged with "mkt" so they never mix with crypto.
 */
public final class AssetScanner {
    private AssetScanner() {}

    static final long EVERY = 15 * 60_000L;
    static final long COOLDOWN = 4 * 3600_000L;

    /** Called from the service loop; runs a scan when it is due. */
    public static void tick(Context ctx, String mkt) {
        if (!Prefs.mktOn(ctx, mkt)) return;
        long now = System.currentTimeMillis();
        if (now - Prefs.lastAssetScan(ctx, mkt) < EVERY) return;
        Prefs.setLastAssetScan(ctx, mkt, now);
        String label = Assets.FOREX.equals(mkt) ? "💱 Forex" : "🥇 Gold & Commodities";
        if (!Assets.marketOpen(now)) {
            Prefs.putStr(ctx, "astatus_" + mkt, label + " · market band hai (weekend) — Sunday raat dobara khulegi");
            return;
        }
        int scanned = 0, sent = 0;
        boolean acc = Prefs.accuracyMode(ctx);
        int minWr = Prefs.minWinRate(ctx), minConf = Prefs.minConfidence(ctx);
        for (Assets.Asset a : Assets.list(mkt)) {
            if (!ScannerService.running) break;
            try {
                AssetReport r = AssetReport.build(ctx, a);
                scanned++;
                boolean buy = r.total >= 62, sell = r.total <= 38;
                if (!buy && !sell) continue;
                if (r.confidence < minConf || r.newsNear) continue;
                if (acc && !ok(r, buy, minWr)) continue;
                String side = buy ? "BUY" : "SELL";
                String cdKey = "acd_" + a.sym + "_" + side;
                if (now - Prefs.getLong(ctx, cdKey) < COOLDOWN) continue;
                Prefs.putLong(ctx, cdKey, now);
                save(ctx, r, buy, acc);
                sent++;
                Thread.sleep(300);
            } catch (InterruptedException e) {
                return;
            } catch (Exception ignored) {
            }
        }
        String time = new SimpleDateFormat("HH:mm", Locale.US).format(new Date());
        Prefs.putStr(ctx, "astatus_" + mkt, label + " · last scan " + time + " · " + scanned + " assets · " + sent + " naye signal");
    }

    static boolean ok(AssetReport r, boolean buy, int minWr) {
        if (r.ma == null || r.bt == null) return false;
        if (buy ? r.ma.score < 20 : r.ma.score > -20) return false;
        if (buy ? r.mtfAgree <= 0 : r.mtfAgree >= 0) return false;
        if (r.ruleSide != 0 && r.ruleSide != (buy ? 1 : -1)) return false;
        return r.bt.enough() && r.bt.winRate >= minWr;
    }

    static void save(Context ctx, AssetReport r, boolean buy, boolean acc) throws Exception {
        Assets.Asset a = r.asset;
        double sl = r.stop, tp = r.target1;
        if (acc && sl > 0) {
            double rk = Math.abs(r.price - sl);
            tp = buy ? r.price + rk : r.price - rk;
        }
        JSONObject ex = new JSONObject();
        ex.put("mkt", a.market);
        ex.put("asset", a.sym);
        ex.put("name", a.name);
        ex.put("tf", "1h");
        ex.put("acc", acc);
        if (r.advice != null) {
            ex.put("adv", r.advice.title);
            ex.put("advWhy", r.advice.why);
            ex.put("type", r.advice.type);
            ex.put("zlo", r.advice.zoneLo);
            ex.put("zhi", r.advice.zoneHi);
            ex.put("entry", r.advice.entry);
            ex.put("tp2", r.advice.tp2);
        }
        JSONArray checks = new JSONArray();
        checks.put("✅ All-source score " + r.total + "/100 (" + r.verdict + ") · confidence " + r.confidence + "%");
        for (CoinReport.Section s : r.sections) {
            if (!s.available) continue;
            boolean agree = buy ? s.score > 0 : s.score < 0;
            checks.put((s.score == 0 ? "➖ " : agree ? "✅ " : "❌ ") + s.icon + " " + s.title + " — score " + (s.score > 0 ? "+" : "") + s.score + " (weight " + s.weight + ")");
        }
        if (r.ma != null) checks.put("〰️ " + r.ma.trend);
        for (String c : r.ruleChecks) checks.put("   " + c);
        if (r.bt != null && r.bt.trades > 0)
            checks.put(String.format(Locale.US, "%s Backtest: %d trades, win rate %.0f%% (1R), avg %.2fR", r.bt.winRate >= 55 ? "✅" : "⚠️",
                    r.bt.trades, r.bt.winRate, r.bt.avgR));
        checks.put((buy ? r.mtfAgree > 0 : r.mtfAgree < 0) ? "✅ Timeframes agree (" + r.mtfAgree + "/4)" : "⚠️ Timeframes mixed (" + r.mtfAgree + "/4)");
        if (r.patterns != null) checks.put("📐 Pattern: " + r.patterns.name);
        for (String e : r.events) checks.put("📅 " + e);
        ex.put("checks", checks);
        if (r.bt != null) { ex.put("wr", Math.round(r.bt.winRate)); ex.put("bt", r.bt.trades); }

        String why = (r.advice != null ? r.advice.title + "\n" : "") + "✅ Score " + r.total + "/100 (" + r.verdict + ", confidence " + r.confidence + "%)\n"
                + r.verdictText + "\n🎯 TP " + Assets.fmt(a, tp) + " · 🛑 SL " + Assets.fmt(a, sl);
        Prefs.addSignal(ctx, Mode.SPOT, buy ? "BUY" : "SELL", a.short_, r.price, r.total, why, sl, tp, ex);
        String title = a.icon + " " + (r.confidence >= 50 ? "STRONG " : "") + (buy ? "BUY: " : "SELL: ") + a.short_ + " (" + a.name + ")";
        String text = "Price " + Assets.fmt(a, r.price) + " · Score " + r.total + "/100 · TP " + Assets.fmt(a, tp) + " · SL " + Assets.fmt(a, sl)
                + (r.bt != null && r.bt.trades > 0 ? String.format(Locale.US, " · Backtest WR %.0f%%", r.bt.winRate) : "");
        Notify.show(ctx, Prefs.N_SIGNALS, (a.sym + (buy ? "B" : "S")).hashCode(), title, text, buy ? 0xFF0ECB81 : 0xFFF6465D, 2);
    }

    /** WIN / LOSS / EXPIRED tracking for commodity & forex signals using Yahoo prices. */
    public static void track(Context ctx) {
        JSONArray arr = Prefs.signals(ctx);
        boolean changed = false;
        long now = System.currentTimeMillis();
        java.util.Map<String, Double> px = new java.util.HashMap<>();
        for (int i = 0; i < arr.length() && i < 100; i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null || !"open".equals(o.optString("st", ""))) continue;
            String mkt = o.optString("mkt", Assets.CRYPTO);
            if (Assets.CRYPTO.equals(mkt)) continue;
            String sym = o.optString("asset");
            if (sym.isEmpty()) continue;
            Double p = px.get(sym);
            if (p == null) {
                try { p = YahooData.quote(sym).price; } catch (Exception e) { p = 0.0; }
                px.put(sym, p);
            }
            if (p <= 0) continue;
            boolean buy = "BUY".equals(o.optString("side"));
            double entry = o.optDouble("price", 0), sl = o.optDouble("sl", 0), tp = o.optDouble("tp", 0);
            if (entry <= 0 || tp <= 0) continue;
            String st = null;
            if (buy ? p >= tp : p <= tp) st = "win";
            else if (sl > 0 && (buy ? p <= sl : p >= sl)) st = "loss";
            else if (now - o.optLong("t") > 72 * 3600_000L) st = "expired";
            if (st != null) {
                try {
                    o.put("st", st);
                    o.put("exit", p);
                    o.put("pnl", (buy ? p / entry - 1 : 1 - p / entry) * 100);
                    changed = true;
                } catch (Exception ignored) { }
            }
        }
        if (changed) Prefs.saveSignals(ctx, arr);
    }
}
