package com.signal.bot;

/** Non-crypto markets: gold & commodities, forex. Yahoo symbols. */
public final class Assets {
    private Assets() {}

    public static final String CRYPTO = "crypto", COMMODITY = "commodity", FOREX = "forex";

    public static final class Asset {
        public final String sym, name, short_, icon, market;
        public final int decimals;
        Asset(String sym, String short_, String name, String icon, String market, int decimals) {
            this.sym = sym; this.short_ = short_; this.name = name; this.icon = icon; this.market = market; this.decimals = decimals;
        }
    }

    public static final Asset[] COMMODITIES = {
            new Asset("GC=F", "XAUUSD", "Gold (Sona)", "🥇", COMMODITY, 2),
            new Asset("SI=F", "XAGUSD", "Silver (Chandi)", "🥈", COMMODITY, 3),
            new Asset("CL=F", "WTI", "Crude Oil WTI", "🛢️", COMMODITY, 2),
            new Asset("BZ=F", "BRENT", "Brent Oil", "🛢️", COMMODITY, 2),
            new Asset("NG=F", "NATGAS", "Natural Gas", "🔥", COMMODITY, 3),
            new Asset("HG=F", "COPPER", "Copper (Tamba)", "🟠", COMMODITY, 4),
            new Asset("PL=F", "PLATINUM", "Platinum", "⚪", COMMODITY, 2),
    };

    public static final Asset[] FOREX_PAIRS = {
            new Asset("EURUSD=X", "EURUSD", "Euro / US Dollar", "🇪🇺", FOREX, 5),
            new Asset("GBPUSD=X", "GBPUSD", "British Pound / US Dollar", "🇬🇧", FOREX, 5),
            new Asset("USDJPY=X", "USDJPY", "US Dollar / Japanese Yen", "🇯🇵", FOREX, 3),
            new Asset("AUDUSD=X", "AUDUSD", "Australian Dollar / USD", "🇦🇺", FOREX, 5),
            new Asset("USDCAD=X", "USDCAD", "US Dollar / Canadian Dollar", "🇨🇦", FOREX, 5),
            new Asset("USDCHF=X", "USDCHF", "US Dollar / Swiss Franc", "🇨🇭", FOREX, 5),
            new Asset("NZDUSD=X", "NZDUSD", "New Zealand Dollar / USD", "🇳🇿", FOREX, 5),
            new Asset("EURJPY=X", "EURJPY", "Euro / Japanese Yen", "🇪🇺", FOREX, 3),
            new Asset("GBPJPY=X", "GBPJPY", "British Pound / Yen", "🇬🇧", FOREX, 3),
            new Asset("EURGBP=X", "EURGBP", "Euro / British Pound", "🇪🇺", FOREX, 5),
            new Asset("PKR=X", "USDPKR", "US Dollar / Pakistani Rupee", "🇵🇰", FOREX, 2),
    };

    public static final String DXY = "DX-Y.NYB";

    public static Asset[] list(String market) {
        return FOREX.equals(market) ? FOREX_PAIRS : COMMODITIES;
    }

    public static Asset find(String sym) {
        for (Asset a : COMMODITIES) if (a.sym.equals(sym) || a.short_.equals(sym)) return a;
        for (Asset a : FOREX_PAIRS) if (a.sym.equals(sym) || a.short_.equals(sym)) return a;
        return null;
    }

    public static String fmt(Asset a, double p) {
        return String.format(java.util.Locale.US, "%." + (a == null ? 4 : a.decimals) + "f", p);
    }

    /** Pip size for forex (JPY pairs 0.01, others 0.0001). */
    public static double pip(Asset a) {
        if (a == null || !FOREX.equals(a.market)) return 0;
        return a.short_.endsWith("JPY") ? 0.01 : a.short_.endsWith("PKR") ? 0.01 : 0.0001;
    }

    /** Forex / CME futures are shut from Friday ~22:00 UTC to Sunday ~22:00 UTC. */
    public static boolean marketOpen(long now) {
        java.util.Calendar c = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));
        c.setTimeInMillis(now);
        int d = c.get(java.util.Calendar.DAY_OF_WEEK), h = c.get(java.util.Calendar.HOUR_OF_DAY);
        if (d == java.util.Calendar.SATURDAY) return false;
        if (d == java.util.Calendar.FRIDAY && h >= 22) return false;
        if (d == java.util.Calendar.SUNDAY && h < 22) return false;
        return true;
    }
}
