package com.signal.bot;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Full analysis for gold / commodities / forex (Yahoo data):
 * multi-timeframe technicals, moving-average system, chart patterns, ParaDox rule backtest,
 * US dollar & yields (macro drivers) and the week's high-impact news for the currencies involved.
 * Always gives one direction (BUY or SELL) with a confidence, plus a position plan.
 */
public final class AssetReport {

    public Assets.Asset asset;
    public double price, change, weekChange;
    public int total = 50, confidence;
    public boolean isBuy;
    public String verdict = "WAIT", verdictText = "";
    public final List<CoinReport.Section> sections = new ArrayList<>();
    public MaSystem.Result ma;
    public ParadoxRule.Backtest bt, bt2;
    public int ruleSide, mtfAgree;
    public List<String> ruleChecks = new ArrayList<>();
    public PatternEngine.Result patterns;
    public Position.Advice advice;
    public double support, resistance, atr, stop, target1, target2;
    public Candles chart;       // 1h candles (closed) for the chart
    public String chartTf = "1h";
    public final List<String> events = new ArrayList<>();
    public boolean newsNear;

    private AssetReport() {}

    public static AssetReport build(Context ctx, Assets.Asset a) throws Exception {
        AssetReport r = new AssetReport();
        r.asset = a;
        Candles m15 = YahooData.fetch(a.sym, "15m", true);
        Candles h1 = YahooData.fetch(a.sym, "1h", true);
        Candles h4 = YahooData.group(h1, 4);
        Candles d1 = YahooData.fetch(a.sym, "1d", true);
        r.chart = h1;
        try {
            YahooData.Quote q = YahooData.quote(a.sym);
            r.price = q.price;
            r.change = q.change;
        } catch (Exception e) {
            r.price = h1.n > 0 ? h1.close[h1.n - 1] : 0;
        }
        if (r.price <= 0 && h1.n > 0) r.price = h1.close[h1.n - 1];
        if (d1.n > 6) r.weekChange = (r.price / d1.close[d1.n - 6] - 1) * 100;

        r.technical(new String[]{"15m", "1h", "4h", "1d"}, new int[]{1, 3, 2, 2}, new Candles[]{m15, h1, h4, d1});
        r.maSection(h1, new Candles[]{m15, h1, h4, d1});
        r.patternSection(h1);
        r.momentum(d1);
        r.macro(ctx, a);
        r.levels(h1);
        r.finish();
        for (CoinReport.Section s : r.sections) if (s.learn.isEmpty()) s.learn = Academy.sectionTip(s.title);
        return r;
    }

    private void technical(String[] tfs, int[] w, Candles[] cs) {
        CoinReport.Section s = new CoinReport.Section("📈", "Technical (" + String.join(" · ", tfs) + ")", 25);
        double sum = 0, ws = 0;
        for (int i = 0; i < cs.length; i++) {
            Candles c = cs[i];
            if (c == null || c.n < 60) { s.add(tfs[i] + ": data kam hai"); continue; }
            double[] rsi = Indicators.rsi(c.close, 14), h = Indicators.macdHist(c.close);
            int li = c.n - 1;
            boolean up = Analyzer.isBullish(c.close);
            double v = (up ? 0.5 : -0.5) + (h[li] > 0 ? 0.25 : -0.25) + Fmt.clamp((rsi[li] - 50) / 40, -0.25, 0.25);
            s.add(String.format(Locale.US, "%s: %s · RSI %.0f · MACD %s", tfs[i], up ? "Uptrend ⬆️" : "Downtrend ⬇️",
                    rsi[li], h[li] > 0 ? "bullish" : "bearish"));
            if (rsi[li] >= 70) s.add("   " + tfs[i] + " RSI overbought (70+) — upar thakawat ho sakti hai");
            if (rsi[li] <= 30) s.add("   " + tfs[i] + " RSI oversold (30-) — neeche thakawat ho sakti hai");
            sum += v * w[i];
            ws += w[i];
        }
        s.available = ws > 0;
        s.score = ws > 0 ? (int) Math.round(Fmt.clamp(sum / ws, -1, 1) * 100) : 0;
        sections.add(s);
    }

    private void maSection(Candles c, Candles[] all) {
        CoinReport.Section s = new CoinReport.Section("〰️", "Moving averages (EMA 9·21·50·100·200) + ParaDox rule", 20);
        if (c.n < 60) { s.available = false; s.add("Data kam hai"); sections.add(s); return; }
        ma = MaSystem.analyze(c.close);
        for (String l : ma.lines) s.add(l);
        ParadoxRule.Ind x = ParadoxRule.prepare(c);
        int li = c.n - 1;
        ruleSide = ParadoxRule.signalAt(x, li);
        if (ruleSide == 0) ruleSide = ParadoxRule.signalAt(x, li - 1);
        ruleChecks = ParadoxRule.checklist(x, li, ruleSide != 0 ? ruleSide : (ma.score >= 0 ? 1 : -1));
        bt = ParadoxRule.backtest(c, 1.5, 1.0);
        bt2 = ParadoxRule.backtest(c, 1.5, 2.0);
        mtfAgree = 0;
        for (Candles k : all) if (k != null && k.n >= 50) mtfAgree += Analyzer.isBullish(k.close) ? 1 : -1;
        s.add(ruleSide > 0 ? "⚡ ParaDox rule: BUY setup abhi bana hai (1h)" : ruleSide < 0 ? "⚡ ParaDox rule: SELL setup abhi bana hai (1h)"
                : "ParaDox rule: abhi taaza setup nahi");
        if (bt.trades > 0) s.add(String.format(Locale.US, "Backtest (%d candles 1h): %d trades · win %.0f%% @1R · %.0f%% @2R",
                c.n, bt.trades, bt.winRate, bt2.winRate));
        s.add("Timeframes agreement: " + (mtfAgree > 0 ? "+" : "") + mtfAgree + " / 4");
        s.score = (int) Math.round(Fmt.clamp(ma.score + ruleSide * 25, -100, 100));
        sections.add(s);
    }

    private void patternSection(Candles c) {
        CoinReport.Section s = new CoinReport.Section("📐", "Chart patterns (1h)", 15);
        patterns = PatternEngine.analyze(c, 150);
        if (c.n < 40) { s.available = false; s.add("Data kam hai"); }
        else { for (String l : patterns.notes) s.add(l); s.score = patterns.score; }
        sections.add(s);
    }

    private void momentum(Candles d) {
        CoinReport.Section s = new CoinReport.Section("🚀", "Momentum (din · hafta · 20-din range)", 10);
        if (d.n < 25) { s.available = false; s.add("Data kam hai"); sections.add(s); return; }
        double hi = 0, lo = Double.MAX_VALUE;
        for (int i = d.n - 20; i < d.n; i++) { hi = Math.max(hi, d.high[i]); lo = Math.min(lo, d.low[i]); }
        double pos = hi > lo ? (price - lo) / (hi - lo) : 0.5;
        s.add(String.format(Locale.US, "Aaj: %+.2f%% · Hafta: %+.2f%%", change, weekChange));
        s.add(String.format(Locale.US, "20-din range mein jagah: %.0f%% (0 = neeche, 100 = upar)", pos * 100));
        if (pos > 0.9) s.add("Price 20-din ki bulandi ke qareeb — breakout ya rukawat");
        if (pos < 0.1) s.add("Price 20-din ki kam tareen satah ke qareeb — breakdown ya support");
        s.score = (int) Math.round(Fmt.clamp(weekChange * 10, -50, 50) + (pos - 0.5) * 60);
        sections.add(s);
    }

    /** US dollar (DXY) and 10Y yield drive gold and USD pairs. */
    private void macro(Context ctx, Assets.Asset a) {
        CoinReport.Section s = new CoinReport.Section("🏦", "US dollar (DXY) · yields · news", 20);
        int dir = usdDirection(a);   // +1 asset rises when USD rises, -1 falls when USD rises, 0 unrelated
        double sc = 0;
        try {
            Candles dx = YahooData.fetch(Assets.DXY, "1d", true);
            if (dx.n > 30) {
                boolean dUp = Analyzer.isBullish(dx.close);
                double ch5 = (dx.close[dx.n - 1] / dx.close[dx.n - 6] - 1) * 100;
                s.add(String.format(Locale.US, "Dollar index DXY %.2f · 5 din %+.2f%% · %s", dx.close[dx.n - 1], ch5, dUp ? "mazboot ⬆️" : "kamzor ⬇️"));
                if (dir != 0) {
                    sc += dir * ((dUp ? 40 : -40) + Fmt.clamp(ch5 * 20, -30, 30));
                    s.add(dir > 0 ? "Is pair mein USD pehle hai → dollar mazboot = pair UPAR" : "Is mein USD doosre number par → dollar mazboot = price NEECHE");
                } else s.add("Is asset par dollar ka asar kam / milajula");
            }
        } catch (Exception e) { s.add("DXY data nahi mila"); }
        if (Assets.COMMODITY.equals(a.market) && (a.sym.equals("GC=F") || a.sym.equals("SI=F"))) {
            try {
                Candles tn = YahooData.fetch("^TNX", "1d", true);
                if (tn.n > 10) {
                    double ch = tn.close[tn.n - 1] - tn.close[tn.n - 6];
                    s.add(String.format(Locale.US, "US 10Y yield %.2f%% · 5 din %+.2f — %s", tn.close[tn.n - 1], ch,
                            ch > 0 ? "yield barh rahi = sone par dabao" : "yield gir rahi = sone ko sahara"));
                    sc += ch > 0.05 ? -25 : ch < -0.05 ? 25 : 0;
                }
            } catch (Exception ignored) { }
        }
        // high-impact news this week for the currencies involved
        List<String> ccy = currencies(a);
        long now = System.currentTimeMillis();
        String[] weeks = {"thisweek", "nextweek"};
        for (String w : weeks) {
            String raw = ctx != null ? Prefs.getStr(ctx, "ffcal_" + w, null) : null;
            if (raw == null) {
                try { raw = Scanner.getAbsolute("https://nfs.faireconomy.media/ff_calendar_" + w + ".json"); if (ctx != null) Prefs.putStr(ctx, "ffcal_" + w, raw); }
                catch (Exception ignored) { }
            }
            if (raw == null) continue;
            try {
                JSONArray arr = new JSONArray(raw);
                for (int i = 0; i < arr.length() && events.size() < 6; i++) {
                    JSONObject o = arr.getJSONObject(i);
                    if (!"High".equals(o.optString("impact")) || !ccy.contains(o.optString("country"))) continue;
                    long t = MacroEngine.iso(o.optString("date"));
                    if (t < now - 3600_000L || t > now + 7 * 86_400_000L) continue;
                    events.add("🔴 " + o.optString("country") + " · " + o.optString("title") + " · " + MacroEngine.pkt(t)
                            + (o.optString("forecast").isEmpty() ? "" : " · forecast " + o.optString("forecast")));
                    if (Math.abs(t - now) < 45 * 60_000L) newsNear = true;
                }
            } catch (Exception ignored) { }
        }
        if (events.isEmpty()) s.add("Is hafte koi bari (High impact) news nahi in currencies ki");
        else { s.add("Bari news (" + String.join("/", ccy) + "):"); for (String e : events) s.add("  " + e); }
        if (newsNear) s.add("⚠️ Bari news 45 min ke andar — fake move ka khatra, naya trade na lein");
        s.available = dir != 0 || s.lines.size() > 1;
        s.score = (int) Math.round(Fmt.clamp(sc, -100, 100));
        sections.add(s);
    }

    static int usdDirection(Assets.Asset a) {
        String s = a.short_;
        if (Assets.FOREX.equals(a.market)) {
            if (s.startsWith("USD")) return 1;
            if (s.endsWith("USD")) return -1;
            return 0;
        }
        if (a.sym.equals("GC=F") || a.sym.equals("SI=F") || a.sym.equals("PL=F") || a.sym.equals("HG=F")) return -1;
        if (a.sym.equals("CL=F") || a.sym.equals("BZ=F")) return -1;
        return 0;
    }

    static List<String> currencies(Assets.Asset a) {
        List<String> l = new ArrayList<>();
        l.add("USD");
        if (Assets.FOREX.equals(a.market) && a.short_.length() >= 6) {
            String b = a.short_.substring(0, 3), q = a.short_.substring(3, 6);
            if (!l.contains(b)) l.add(b);
            if (!l.contains(q)) l.add(q);
        }
        return l;
    }

    private void levels(Candles c) {
        atr = Indicators.atr(c.high, c.low, c.close, 14);
        if (patterns != null) {
            for (PatternEngine.Zone z : patterns.zones) {
                if (z.support && z.price < price && (support == 0 || z.price > support)) support = z.price;
                if (!z.support && z.price > price && (resistance == 0 || z.price < resistance)) resistance = z.price;
            }
        }
        double lo = Double.MAX_VALUE, hi = 0;
        for (int i = Math.max(0, c.n - 40); i < c.n; i++) { lo = Math.min(lo, c.low[i]); hi = Math.max(hi, c.high[i]); }
        if (support == 0) support = lo == Double.MAX_VALUE ? price : lo;
        if (resistance == 0) resistance = hi == 0 ? price : hi;
    }

    private void finish() {
        double s = 0, w = 0;
        for (CoinReport.Section sec : sections) {
            if (!sec.available) continue;
            s += sec.score * sec.weight;
            w += sec.weight;
        }
        double avg = w > 0 ? s / w : 0;
        total = (int) Math.round(Fmt.clamp(50 + avg / 2, 0, 100));
        isBuy = total >= 50;
        confidence = (int) Math.min(100, Math.abs(total - 50) * 2.5);
        verdict = (confidence >= 50 ? "STRONG " : "") + (isBuy ? "BUY" : "SELL");
        verdictText = isBuy
                ? (confidence >= 50 ? "Trend, moving averages aur dollar sab upar ka ishara de rahe hain." : "Buyers thore aage — chhoti position, stop zaroor.")
                : (confidence >= 50 ? "Trend neeche, MAs bearish aur dollar ka dabao — sell side behtar." : "Sellers thore aage — chhota sell ya intezar.");
        if (confidence < 20) verdictText += " (Confidence kam — market faisla nahi kar raha.)";
        if (newsNear) verdictText += " ⚠️ Bari news qareeb hai.";
        advice = Position.compute(isBuy, price, atr, 1.5, patterns, support, resistance, Double.NaN, Double.NaN);
        if (advice != null) { stop = advice.sl; target1 = advice.tp1; target2 = advice.tp2; }
    }

    public String toText() {
        StringBuilder sb = new StringBuilder();
        sb.append("ASSET: ").append(asset.name).append(" (").append(asset.short_).append(", market ").append(asset.market).append(")\n");
        sb.append(String.format(Locale.US, "PRICE %s  day %+.2f%%  week %+.2f%%%n", Assets.fmt(asset, price), change, weekChange));
        sb.append("VERDICT: ").append(verdict).append(" score ").append(total).append("/100 confidence ").append(confidence).append("%\n");
        if (advice != null) sb.append("PLAN: ").append(advice.title).append(" SL ").append(Assets.fmt(asset, stop))
                .append(" TP1 ").append(Assets.fmt(asset, target1)).append(" TP2 ").append(Assets.fmt(asset, target2)).append('\n');
        for (CoinReport.Section s : sections) {
            sb.append("\n[").append(s.title).append("] score ").append(s.score).append('\n');
            for (String l : s.lines) sb.append("- ").append(l).append('\n');
        }
        return sb.toString();
    }
}
