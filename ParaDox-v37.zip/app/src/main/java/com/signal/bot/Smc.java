package com.signal.bot;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Smart Money Concepts on ONE timeframe, using only CLOSED candles 0..end (no look-ahead, no repainting):
 *  • swings (fractals, confirmed only `K` candles later) labelled HH / HL / LH / LL
 *  • BOS (break in trend direction), CHoCH (first break against the trend), MSS (CHoCH made by a displacement candle)
 *  • buy-side / sell-side liquidity (unswept swing highs / lows), equal highs / lows, liquidity sweeps (stop hunts)
 *  • premium / discount of the current dealing range
 *  • order blocks (validated: the move away must break structure WITH displacement), mitigation, breaker blocks
 *  • fair value gaps, inverse FVGs, rejection blocks, displacement candles
 * Strict rules: a pattern that is not confirmed by later candles is NOT reported.
 */
public final class Smc {
    private Smc() {}

    public static final int K = 3;   // fractal strength (left / right)

    public static final class Swing {
        public final int i;
        public final double p;
        public final boolean high;
        public String label = "";
        public boolean swept, broken;
        Swing(int i, double p, boolean high) { this.i = i; this.p = p; this.high = high; }
    }

    public static final class Event {
        public final int i;
        public final String type;   // BOS, CHOCH, MSS, SWEEP
        public final boolean bull;
        public final double level;
        Event(int i, String type, boolean bull, double level) { this.i = i; this.type = type; this.bull = bull; this.level = level; }
    }

    public static final class Zone {
        public final int i;          // candle that created it
        public double lo, hi;
        public boolean bull;
        public String type;          // OB, FVG, IFVG, BREAKER, REJECTION
        public boolean mitigated;    // price came back into it
        public boolean invalid;      // price closed through it
        public int brokeAt = -1;     // structure break this zone belongs to (OB)
        Zone(int i, double lo, double hi, boolean bull, String type) { this.i = i; this.lo = lo; this.hi = hi; this.bull = bull; this.type = type; }
        public double mid() { return (lo + hi) / 2; }
    }

    public static final class Result {
        public int start, end, trend;          // trend +1 bull structure, −1 bear, 0 unknown
        public double atr, rangeHi, rangeLo, close;
        public final List<Swing> swings = new ArrayList<>();
        public final List<Event> events = new ArrayList<>();
        public final List<Zone> zones = new ArrayList<>();
        public final List<double[]> eqh = new ArrayList<>(), eql = new ArrayList<>();   // {price, i1, i2}

        /** 0 = deepest discount (range low), 1 = top of premium (range high). */
        public double rangePos() { return rangeHi > rangeLo ? (close - rangeLo) / (rangeHi - rangeLo) : 0.5; }

        public Event last(String type, Boolean bull) {
            for (int k = events.size() - 1; k >= 0; k--) {
                Event e = events.get(k);
                if (e.type.equals(type) && (bull == null || e.bull == bull)) return e;
            }
            return null;
        }

        public Swing lastSwing(boolean high) {
            for (int k = swings.size() - 1; k >= 0; k--) if (swings.get(k).high == high) return swings.get(k);
            return null;
        }

        /** Unswept liquidity: highs above `px` (buy-side) or lows below (sell-side), nearest first. */
        public List<Swing> liquidity(boolean buySide, double px) {
            List<Swing> l = new ArrayList<>();
            for (Swing s : swings) if (s.high == buySide && !s.swept && !s.broken && (buySide ? s.p > px : s.p < px)) l.add(s);
            l.sort((a, b) -> buySide ? Double.compare(a.p, b.p) : Double.compare(b.p, a.p));
            return l;
        }
    }

    static boolean isDisplacement(Candles c, int i, double atr) {
        double body = Math.abs(c.close[i] - c.open[i]), range = c.high[i] - c.low[i];
        return atr > 0 && body >= 1.2 * atr && range > 0 && body / range >= 0.6;
    }

    /** Analyses candles [max(0, end − window) .. end]; all candles in that range are treated as CLOSED. */
    public static Result analyze(Candles c, int end, int window) {
        Result r = new Result();
        int st = Math.max(0, end - window + 1);
        r.start = st;
        r.end = end;
        r.close = c.close[end];
        // ATR (Wilder-like average of true range) up to `end`
        double tr = 0;
        int cnt = 0;
        for (int i = Math.max(st + 1, end - 13); i <= end; i++) {
            tr += Math.max(c.high[i] - c.low[i], Math.max(Math.abs(c.high[i] - c.close[i - 1]), Math.abs(c.low[i] - c.close[i - 1])));
            cnt++;
        }
        r.atr = cnt > 0 ? tr / cnt : 0;
        double atr = r.atr;

        // ---- confirmed swings (pivot at i is only known at i + K <= end)
        Swing lastH = null, lastL = null;
        for (int i = st + K; i <= end - K; i++) {
            boolean ph = true, pl = true;
            for (int j = i - K; j <= i + K; j++) {
                if (j == i) continue;
                if (j < i ? c.high[j] >= c.high[i] : c.high[j] > c.high[i]) ph = false;
                if (j < i ? c.low[j] <= c.low[i] : c.low[j] < c.low[i]) pl = false;
            }
            if (ph) {
                Swing s = new Swing(i, c.high[i], true);
                s.label = lastH == null ? "H" : s.p > lastH.p ? "HH" : "LH";
                r.swings.add(s);
                lastH = s;
            }
            if (pl) {
                Swing s = new Swing(i, c.low[i], false);
                s.label = lastL == null ? "L" : s.p > lastL.p ? "HL" : "LL";
                r.swings.add(s);
                lastL = s;
            }
        }
        r.swings.sort((a, b) -> Integer.compare(a.i, b.i));

        // ---- walk forward candle by candle: structure breaks, sweeps, order blocks (only swings confirmed BEFORE j are used)
        int trend = 0;
        Swing curH = null, curL = null;
        int sw = 0;
        List<Swing> known = new ArrayList<>();
        for (int j = st + K + 1; j <= end; j++) {
            while (sw < r.swings.size() && r.swings.get(sw).i + K <= j - 1) {
                Swing s = r.swings.get(sw++);
                known.add(s);
                if (s.high) curH = s; else curL = s;
            }
            // liquidity sweeps: wick through an older unswept swing, close back inside
            for (Swing s : known) {
                if (s.swept || s.broken || j - s.i > 80) continue;
                if (s.high && c.high[j] > s.p) {
                    if (c.close[j] < s.p) { s.swept = true; r.events.add(new Event(j, "SWEEP", false, s.p)); }   // buy-side taken -> bearish
                    else s.broken = true;
                } else if (!s.high && c.low[j] < s.p) {
                    if (c.close[j] > s.p) { s.swept = true; r.events.add(new Event(j, "SWEEP", true, s.p)); }   // sell-side taken -> bullish
                    else s.broken = true;
                }
            }
            // structure breaks on CLOSE beyond the latest confirmed swing
            if (curH != null && !curH.label.equals("used") && c.close[j] > curH.p) {
                boolean disp = false;
                for (int k = Math.max(curH.i, j - 6); k <= j; k++) if (c.close[k] > c.open[k] && isDisplacement(c, k, atr)) disp = true;
                String t = trend >= 0 ? "BOS" : (disp ? "MSS" : "CHOCH");
                r.events.add(new Event(j, t, true, curH.p));
                trend = 1;
                if (disp) addOb(r, c, j, true, curL != null ? curL.i : j - 15);
                curH.label = curH.label + "";   // keep label
                curH = new Swing(curH.i, Double.MAX_VALUE, true);   // consumed: wait for the next swing high
                curH.label = "used";
            }
            if (curL != null && !curL.label.equals("used") && c.close[j] < curL.p) {
                boolean disp = false;
                for (int k = Math.max(curL.i, j - 6); k <= j; k++) if (c.close[k] < c.open[k] && isDisplacement(c, k, atr)) disp = true;
                String t = trend <= 0 ? "BOS" : (disp ? "MSS" : "CHOCH");
                r.events.add(new Event(j, t, false, curL.p));
                trend = -1;
                if (disp) addOb(r, c, j, false, curH != null && curH.p != Double.MAX_VALUE ? curH.i : j - 15);
                curL = new Swing(curL.i, -Double.MAX_VALUE, false);
                curL.label = "used";
            }
        }
        r.trend = trend;
        r.events.sort((a, b) -> Integer.compare(a.i, b.i));

        // ---- fair value gaps (3-candle imbalance with a real middle candle)
        for (int i = st + 2; i <= end; i++) {
            double mb = Math.abs(c.close[i - 1] - c.open[i - 1]);
            if (c.low[i] > c.high[i - 2] && c.low[i] - c.high[i - 2] >= 0.1 * atr && mb >= 0.5 * atr)
                r.zones.add(new Zone(i, c.high[i - 2], c.low[i], true, "FVG"));
            if (c.high[i] < c.low[i - 2] && c.low[i - 2] - c.high[i] >= 0.1 * atr && mb >= 0.5 * atr)
                r.zones.add(new Zone(i, c.high[i], c.low[i - 2], false, "FVG"));
        }
        // ---- rejection blocks: long wick at a confirmed swing
        for (Swing s : r.swings) {
            double rg = c.high[s.i] - c.low[s.i];
            if (rg <= 0) continue;
            double up = c.high[s.i] - Math.max(c.open[s.i], c.close[s.i]), dn = Math.min(c.open[s.i], c.close[s.i]) - c.low[s.i];
            if (s.high && up / rg >= 0.6) r.zones.add(new Zone(s.i, Math.max(c.open[s.i], c.close[s.i]), c.high[s.i], false, "REJECTION"));
            if (!s.high && dn / rg >= 0.6) r.zones.add(new Zone(s.i, c.low[s.i], Math.min(c.open[s.i], c.close[s.i]), true, "REJECTION"));
        }
        // ---- life of every zone after it formed: mitigation, invalidation -> IFVG / breaker
        List<Zone> flips = new ArrayList<>();
        for (Zone z : r.zones) {
            for (int j = z.i + 1; j <= end; j++) {
                if (z.bull) {
                    if (c.low[j] <= z.hi) z.mitigated = true;
                    if (c.close[j] < z.lo) { z.invalid = true; flips.add(flip(z, j)); break; }
                } else {
                    if (c.high[j] >= z.lo) z.mitigated = true;
                    if (c.close[j] > z.hi) { z.invalid = true; flips.add(flip(z, j)); break; }
                }
            }
        }
        for (Zone f : flips) {
            if (f == null) continue;
            for (int j = f.i + 1; j <= end; j++) {
                if (f.bull ? c.low[j] <= f.hi : c.high[j] >= f.lo) f.mitigated = true;
                if (f.bull ? c.close[j] < f.lo : c.close[j] > f.hi) { f.invalid = true; break; }
            }
            r.zones.add(f);
        }
        // ---- equal highs / lows (resting liquidity)
        for (int a = 0; a < r.swings.size(); a++)
            for (int b = a + 1; b < r.swings.size(); b++) {
                Swing x = r.swings.get(a), y = r.swings.get(b);
                if (x.high != y.high || Math.abs(x.p - y.p) > 0.12 * atr || x.broken || y.broken || x.swept || y.swept) continue;
                (x.high ? r.eqh : r.eql).add(new double[]{(x.p + y.p) / 2, x.i, y.i});
            }
        // ---- dealing range: latest confirmed swing high and low
        Swing h = r.lastSwing(true), l = r.lastSwing(false);
        r.rangeHi = h != null ? Math.max(h.p, c.close[end]) : c.high[end];
        r.rangeLo = l != null ? Math.min(l.p, c.close[end]) : c.low[end];
        return r;
    }

    /** Order block = last opposite candle before the displacement that broke structure. */
    static void addOb(Result r, Candles c, int brk, boolean bull, int from) {
        for (int k = brk - 1; k >= Math.max(from, brk - 15) && k >= r.start; k--) {
            if (bull ? c.close[k] < c.open[k] : c.close[k] > c.open[k]) {
                Zone z = new Zone(k, c.low[k], c.high[k], bull, "OB");
                z.brokeAt = brk;
                r.zones.add(z);
                return;
            }
        }
    }

    static Zone flip(Zone z, int j) {
        String t = z.type.equals("FVG") ? "IFVG" : z.type.equals("OB") ? "BREAKER" : null;
        if (t == null) return null;
        return new Zone(j, z.lo, z.hi, !z.bull, t);
    }

    /** Short human summary for the screen. */
    public static List<String> describe(Result r) {
        List<String> l = new ArrayList<>();
        l.add("Structure: " + (r.trend > 0 ? "🟢 Bullish (HH/HL)" : r.trend < 0 ? "🔴 Bearish (LH/LL)" : "⚪ Saaf nahi"));
        Event e = r.events.isEmpty() ? null : r.events.get(r.events.size() - 1);
        if (e != null) l.add(String.format(Locale.US, "Aakhri event: %s %s @ %s (%d candles pehle)", e.bull ? "bullish" : "bearish", e.type, Fmt.price(e.level), r.end - e.i));
        l.add(String.format(Locale.US, "Dealing range: %s – %s · price %s mein (%.0f%%)", Fmt.price(r.rangeLo), Fmt.price(r.rangeHi),
                r.rangePos() > 0.5 ? "PREMIUM" : "DISCOUNT", r.rangePos() * 100));
        return l;
    }

    /** Aggregates candles by `factor` (e.g. 1h × 4 = 4h); out[k] holds the index of the last base candle of group k. */
    public static Candles aggregate(Candles c, int factor, long baseMs, int[][] lastIdxOut) {
        long gms = baseMs * factor;
        List<int[]> groups = new ArrayList<>();
        int s = 0;
        while (s < c.n) {
            long g = c.time[s] / gms;
            int e = s;
            while (e + 1 < c.n && c.time[e + 1] / gms == g) e++;
            if (e - s + 1 == factor) groups.add(new int[]{s, e});   // only complete groups
            s = e + 1;
        }
        Candles a = Candles.create(groups.size());
        int[] last = new int[groups.size()];
        for (int k = 0; k < groups.size(); k++) {
            int f = groups.get(k)[0], t = groups.get(k)[1];
            a.time[k] = c.time[f];
            a.open[k] = c.open[f];
            a.close[k] = c.close[t];
            double hi = -Double.MAX_VALUE, lo = Double.MAX_VALUE, v = 0, qv = 0, tb = 0;
            for (int i = f; i <= t; i++) { hi = Math.max(hi, c.high[i]); lo = Math.min(lo, c.low[i]); v += c.vol[i]; qv += c.quoteVol[i]; tb += c.takerBuyQuote[i]; }
            a.high[k] = hi; a.low[k] = lo; a.vol[k] = v; a.quoteVol[k] = qv; a.takerBuyQuote[k] = tb;
            last[k] = t;
        }
        if (lastIdxOut != null) lastIdxOut[0] = last;
        return a;
    }
}
