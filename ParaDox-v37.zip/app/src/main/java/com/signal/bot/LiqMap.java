package com.signal.bot;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Liquidation MAP (where the liquidation price levels are sitting) — the same idea Coinglass-style heatmaps use:
 *  every hour where futures open interest ROSE, new positions were opened near that hour's average price; they are split
 *  long / short with the real long/short account ratio and spread over typical leverage (5x … 100x). Each one gets a
 *  liquidation price (long: below entry, short: above). Positions whose liquidation price was already crossed are removed,
 *  and open interest that left the market shrinks the rest. What remains = the clusters the price can still "hunt".
 * Data: Binance Futures (open interest, 1 h candles, long/short ratio) with Bybit as the backup.
 */
public final class LiqMap {
    private LiqMap() {}

    public static final class Map2 {
        public String coin = "", source = "";
        public double price, lo, hi, step;
        public double[] longUsd, shortUsd;   // per price bin
        public double totalLong, totalShort, oiUsd, longRatio = Double.NaN;
        public final List<double[]> topLong = new ArrayList<>(), topShort = new ArrayList<>();   // {price, usd}
        public long at;
    }

    static final double[] LEV = {5, 10, 25, 50, 100};
    static final double[] W = {0.10, 0.30, 0.30, 0.20, 0.10};

    public static Map2 build(String coin, int hours) throws Exception {
        String sym = coin + "USDT";
        int n = Math.max(24, Math.min(500, hours));
        double[] o, h, l, c, oi, lr;
        long[] t;
        String src;
        try {
            JSONArray k = new JSONArray(Scanner.getAbsolute("https://fapi.binance.com/fapi/v1/klines?symbol=" + sym + "&interval=1h&limit=" + n));
            JSONArray oa = new JSONArray(Scanner.getAbsolute("https://fapi.binance.com/futures/data/openInterestHist?symbol=" + sym + "&period=1h&limit=" + Math.min(500, n)));
            JSONArray ra = null;
            try { ra = new JSONArray(Scanner.getAbsolute("https://fapi.binance.com/futures/data/globalLongShortAccountRatio?symbol=" + sym + "&period=1h&limit=" + Math.min(500, n))); } catch (Exception ignored) { }
            int m = k.length();
            o = new double[m]; h = new double[m]; l = new double[m]; c = new double[m]; oi = new double[m]; lr = new double[m]; t = new long[m];
            for (int i = 0; i < m; i++) {
                JSONArray x = k.getJSONArray(i);
                t[i] = x.getLong(0); o[i] = x.getDouble(1); h[i] = x.getDouble(2); l[i] = x.getDouble(3); c[i] = x.getDouble(4);
                oi[i] = Double.NaN; lr[i] = Double.NaN;
            }
            fill(t, oi, oa, "timestamp", "sumOpenInterestValue", 1);
            if (ra != null) fill(t, lr, ra, "timestamp", "longAccount", 1);
            src = "Binance Futures";
        } catch (Exception e) {
            String b = "https://api.bybit.com/v5/market/";
            JSONArray k = new JSONObject(Scanner.getAbsolute(b + "kline?category=linear&symbol=" + sym + "&interval=60&limit=" + Math.min(1000, n))).getJSONObject("result").getJSONArray("list");
            JSONArray oa = new JSONObject(Scanner.getAbsolute(b + "open-interest?category=linear&symbol=" + sym + "&intervalTime=1h&limit=200")).getJSONObject("result").getJSONArray("list");
            JSONArray ra = null;
            try { ra = new JSONObject(Scanner.getAbsolute(b + "account-ratio?category=linear&symbol=" + sym + "&period=1h&limit=500")).getJSONObject("result").getJSONArray("list"); } catch (Exception ignored) { }
            int m = k.length();
            o = new double[m]; h = new double[m]; l = new double[m]; c = new double[m]; oi = new double[m]; lr = new double[m]; t = new long[m];
            for (int i = 0; i < m; i++) {   // Bybit lists newest first
                JSONArray x = k.getJSONArray(m - 1 - i);
                t[i] = x.getLong(0); o[i] = x.getDouble(1); h[i] = x.getDouble(2); l[i] = x.getDouble(3); c[i] = x.getDouble(4);
                oi[i] = Double.NaN; lr[i] = Double.NaN;
            }
            fill(t, oi, oa, "timestamp", "openInterest", 0);   // in coins -> $ below
            for (int i = 0; i < m; i++) if (!Double.isNaN(oi[i])) oi[i] *= c[i];
            if (ra != null) fill(t, lr, ra, "timestamp", "buyRatio", 1);
            src = "Bybit (Binance nahi mila)";
        }
        int m = c.length;
        if (m < 12) throw new Exception("data kam hai");
        // carry missing OI / ratio values forward
        double lastOi = Double.NaN, lastR = 0.5;
        for (int i = 0; i < m; i++) {
            if (Double.isNaN(oi[i])) oi[i] = lastOi; else lastOi = oi[i];
            if (Double.isNaN(lr[i])) lr[i] = lastR; else lastR = lr[i];
        }
        // ---- simulate the positions
        List<double[]> pos = new ArrayList<>();   // {liqPrice, usd, isLong(1/0)}
        for (int i = 1; i < m; i++) {
            // 1) this hour's candle liquidates what it crossed
            for (int k = pos.size() - 1; k >= 0; k--) {
                double[] p = pos.get(k);
                if (p[2] == 1 ? l[i] <= p[0] : h[i] >= p[0]) pos.remove(k);
            }
            if (Double.isNaN(oi[i]) || Double.isNaN(oi[i - 1]) || oi[i - 1] <= 0) continue;
            double d = oi[i] - oi[i - 1];
            if (d > 0) {   // 2) new positions opened near the hour's average price
                double ep = (h[i] + l[i] + c[i]) / 3, ls = Math.max(0.2, Math.min(0.8, lr[i]));
                for (int j = 0; j < LEV.length; j++) {
                    pos.add(new double[]{ep * (1 - 1 / LEV[j] + 0.005), d * ls * W[j], 1});
                    pos.add(new double[]{ep * (1 + 1 / LEV[j] - 0.005), d * (1 - ls) * W[j], 0});
                }
            } else if (d < 0) {   // 3) positions closed: shrink the rest
                double f = oi[i] / oi[i - 1];
                for (double[] p : pos) p[1] *= f;
            }
        }
        Map2 r = new Map2();
        r.coin = coin;
        r.source = src;
        r.price = c[m - 1];
        r.oiUsd = oi[m - 1];
        r.longRatio = lr[m - 1];
        r.lo = r.price * 0.75;
        r.hi = r.price * 1.25;
        int bins = 50;
        r.step = (r.hi - r.lo) / bins;
        r.longUsd = new double[bins];
        r.shortUsd = new double[bins];
        for (double[] p : pos) {
            if (p[0] < r.lo || p[0] >= r.hi) continue;
            int b = (int) ((p[0] - r.lo) / r.step);
            if (p[2] == 1) { r.longUsd[b] += p[1]; r.totalLong += p[1]; } else { r.shortUsd[b] += p[1]; r.totalShort += p[1]; }
        }
        for (int i = 0; i < bins; i++) {
            double mid = r.lo + (i + 0.5) * r.step;
            if (r.longUsd[i] > 0) r.topLong.add(new double[]{mid, r.longUsd[i]});
            if (r.shortUsd[i] > 0) r.topShort.add(new double[]{mid, r.shortUsd[i]});
        }
        r.topLong.sort((a, b) -> Double.compare(b[1], a[1]));
        r.topShort.sort((a, b) -> Double.compare(b[1], a[1]));
        r.at = System.currentTimeMillis();
        return r;
    }

    /** Copies a time series onto the candle times (nearest earlier timestamp). */
    static void fill(long[] t, double[] dst, JSONArray a, String tk, String vk, int unused) throws Exception {
        List<long[]> ts = new ArrayList<>();
        List<Double> vs = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i);
            ts.add(new long[]{o.optLong(tk)});
            vs.add(o.optDouble(vk, Double.NaN));
        }
        // sort ascending by time
        Integer[] idx = new Integer[ts.size()];
        for (int i = 0; i < idx.length; i++) idx[i] = i;
        java.util.Arrays.sort(idx, (x, y) -> Long.compare(ts.get(x)[0], ts.get(y)[0]));
        int j = 0;
        for (int i = 0; i < t.length; i++) {
            while (j + 1 < idx.length && ts.get(idx[j + 1])[0] <= t[i] + 3600_000L - 1) j++;
            if (idx.length > 0 && ts.get(idx[j])[0] <= t[i] + 3600_000L - 1) dst[i] = vs.get(idx[j]);
        }
    }

    static String pct(double p, double ref) { return String.format(Locale.US, "%+.1f%%", (p / ref - 1) * 100); }
}
