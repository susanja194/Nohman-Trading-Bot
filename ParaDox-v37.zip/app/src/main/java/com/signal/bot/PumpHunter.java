package com.signal.bot;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * 🎯 Gainer / Loser hunter — finds coins BEFORE they reach the top-gainers / top-losers list.
 * Pumps almost always leave footprints first:
 *   1. Unusual volume (RVOL): last 5 / 15 / 60 min volume many times its normal pace, while the price has NOT moved much yet
 *      (price-volume divergence = accumulation / distribution)
 *   2. Aggressive buyers (taker buy %) take over · bid side of the order book thicker than asks
 *   3. Futures: open interest building · taker buy/sell ratio · top-trader (whale) positioning · funding
 *   4. Tight range (squeeze) just breaking
 *   5. Korea first: Upbit / Bithumb / Coinone / Korbit (KRW) volume spikes + kimchi premium
 *   6. Every other exchange (OKX, Bybit, Bitget, KuCoin, Gate, MEXC, HTX, Bitfinex, Binance Futures) — volume there first
 *   7. Attention: CoinGecko trending searches · DexScreener paid boosts · news / X mentions · catalysts / listings
 * Mirror logic finds dumps. Every hunt is time-stamped and tracked: did the coin really move 5%+ within 4 h?
 */
public final class PumpHunter {
    private PumpHunter() {}

    public static final class Pick {
        public String sym, base;
        public boolean pump;            // true = likely gainer, false = likely loser
        public int score;               // 0..100
        public int feat;                // feature bitmask (for learning)
        public String venue = "Binance";
        public String stage = "";       // EARLY / BREAKOUT / LATE
        public double venueSpike = Double.NaN;
        public double price, ch15, ch1h, ch24, rvol5 = Double.NaN, rvol15, rvol1h, buyPct = 50, bookImb = Double.NaN, oiCh = Double.NaN, funding = Double.NaN,
                upbitRvol = Double.NaN, kimchi = Double.NaN, takerRatio = Double.NaN, whaleLs = Double.NaN, vol24, vol5 = Double.NaN, vol15, vol1h, squeeze, bull, bear,
                fromHi = Double.NaN, fromLo = Double.NaN;   // v32: % below the 1h high / above the 1h low (is the move HOLDING?)
        public boolean momentum;                            // v32: picked by the momentum lane (already +3..18% in 1h)
        public final List<String> why = new ArrayList<>();
        public final List<String> raw = new ArrayList<>();     // evidence collected by deep checks / other exchanges
        public final List<String> src = new ArrayList<>();     // "where it was seen" lines
        public long at, firstAt;
        public double firstPrice;
        public int bestScore;
        public int volConf;              // v31: 0..100 how solid the VOLUME evidence is (size, persistence, direction, other exchanges)

        public String key() { return venue + ":" + base + (pump ? ":U" : ":D"); }

        JSONObject toJson() {
            JSONObject o = new JSONObject();
            try {
                o.put("sym", sym); o.put("base", base); o.put("pump", pump); o.put("score", score); o.put("feat", feat); o.put("venue", venue);
                o.put("stage", stage); o.put("price", price); o.put("ch15", ch15); o.put("ch1h", ch1h); o.put("ch24", ch24);
                o.put("rvol15", rvol15); o.put("rvol1h", rvol1h); o.put("buyPct", buyPct); o.put("vol24", vol24); o.put("vol15", vol15); o.put("vol1h", vol1h);
                o.put("bull", bull); o.put("bear", bear); o.put("at", at); o.put("firstAt", firstAt); o.put("firstPrice", firstPrice); o.put("best", bestScore); o.put("vc", volConf);
                putNum(o, "rvol5", rvol5); putNum(o, "vol5", vol5); putNum(o, "venueSpike", venueSpike); putNum(o, "bookImb", bookImb); putNum(o, "oiCh", oiCh);
                putNum(o, "funding", funding); putNum(o, "upbitRvol", upbitRvol); putNum(o, "kimchi", kimchi); putNum(o, "takerRatio", takerRatio); putNum(o, "whaleLs", whaleLs);
                JSONArray w = new JSONArray(); for (String s : why) w.put(s); o.put("why", w);
                JSONArray s2 = new JSONArray(); for (String s : src) s2.put(s); o.put("src", s2);
            } catch (Exception ignored) {
            }
            return o;
        }

        static Pick fromJson(JSONObject o) {
            Pick p = new Pick();
            p.sym = o.optString("sym"); p.base = o.optString("base"); p.pump = o.optBoolean("pump"); p.score = o.optInt("score"); p.feat = o.optInt("feat");
            p.venue = o.optString("venue", "Binance"); p.stage = o.optString("stage"); p.price = o.optDouble("price", 0); p.ch15 = o.optDouble("ch15", 0);
            p.ch1h = o.optDouble("ch1h", 0); p.ch24 = o.optDouble("ch24", 0); p.rvol15 = o.optDouble("rvol15", 0); p.rvol1h = o.optDouble("rvol1h", 0);
            p.buyPct = o.optDouble("buyPct", 50); p.vol24 = o.optDouble("vol24", 0); p.vol15 = o.optDouble("vol15", 0); p.vol1h = o.optDouble("vol1h", 0);
            p.bull = o.optDouble("bull", 0); p.bear = o.optDouble("bear", 0); p.at = o.optLong("at"); p.firstAt = o.optLong("firstAt"); p.firstPrice = o.optDouble("firstPrice", 0);
            p.bestScore = o.optInt("best", p.score);
            p.volConf = o.optInt("vc", 0);
            p.rvol5 = num(o, "rvol5"); p.vol5 = num(o, "vol5"); p.venueSpike = num(o, "venueSpike"); p.bookImb = num(o, "bookImb"); p.oiCh = num(o, "oiCh");
            p.funding = num(o, "funding"); p.upbitRvol = num(o, "upbitRvol"); p.kimchi = num(o, "kimchi"); p.takerRatio = num(o, "takerRatio"); p.whaleLs = num(o, "whaleLs");
            JSONArray w = o.optJSONArray("why");
            if (w != null) for (int i = 0; i < w.length(); i++) p.why.add(w.optString(i));
            JSONArray s = o.optJSONArray("src");
            if (s != null) for (int i = 0; i < s.length(); i++) p.src.add(s.optString(i));
            return p;
        }
    }

    static void putNum(JSONObject o, String k, double v) throws Exception { if (!Double.isNaN(v) && !Double.isInfinite(v)) o.put(k, v); }

    static double num(JSONObject o, String k) { return o.has(k) ? o.optDouble(k, Double.NaN) : Double.NaN; }

    public static final class Result {
        public final List<Pick> pumps = new ArrayList<>(), dumps = new ArrayList<>();
        public int scanned, venues;
        /** Today's biggest Binance movers {base, change24 %, price, quote volume} — to check what the hunter caught or missed. */
        public final List<Object[]> topGainers = new ArrayList<>(), topLosers = new ArrayList<>();
        public long ms, at;
        public String note = "";
    }

    /** Live progress for the screen: stage text + every pick the moment it is scored. */
    public interface Listener {
        void stage(String text, int done, int total);
        void found(Pick p);
    }

    private static volatile Result cache;
    private static final Object LOCK = new Object();
    private static final ExecutorService POOL = Executors.newFixedThreadPool(6);
    /** Latest known price per "venue:BASE" (USD) — used to show how far a hunted coin went since it was caught. */
    static final Map<String, Double> LAST_PX = new ConcurrentHashMap<>();
    static volatile double usdKrw = 1400;

    public static Result cached() { return cache; }

    public static boolean busy() { return busy; }
    private static volatile boolean busy;

    static double d(String s) {
        try { return Double.parseDouble(s); } catch (Exception e) { return 0; }
    }

    static String when(long t) { return new SimpleDateFormat("dd MMM yyyy, HH:mm:ss", Locale.US).format(new Date(t)); }

    /** Binance rolling-window stats for many symbols (100 per request). {sym -> {quoteVol, change%}} */
    static Map<String, double[]> window(List<String> syms, String w) {
        Map<String, double[]> out = new HashMap<>();
        for (int i = 0; i < syms.size(); i += 100) {
            List<String> part = syms.subList(i, Math.min(syms.size(), i + 100));
            StringBuilder q = new StringBuilder("[");
            for (String s : part) { if (q.length() > 1) q.append(','); q.append('"').append(s).append('"'); }
            q.append(']');
            try {
                JSONArray a = new JSONArray(Scanner.get("/api/v3/ticker?type=MINI&windowSize=" + w + "&symbols=" + java.net.URLEncoder.encode(q.toString(), "UTF-8")));
                for (int k = 0; k < a.length(); k++) {
                    JSONObject o = a.getJSONObject(k);
                    double open = d(o.optString("openPrice")), last = d(o.optString("lastPrice"));
                    out.put(o.optString("symbol"), new double[]{d(o.optString("quoteVolume")), open > 0 ? (last / open - 1) * 100 : 0});
                }
            } catch (Exception ignored) {
            }
        }
        return out;
    }

    public static Result scan(Context ctx) { return scan(ctx, null); }

    public static Result scan(Context ctx, final Listener ls) {
        synchronized (LOCK) {
            busy = true;
            try {
                return doScan(ctx, ls);
            } finally {
                busy = false;
            }
        }
    }

    private static void st(Listener ls, String t, int a, int b) { if (ls != null) try { ls.stage(t, a, b); } catch (Exception ignored) { } }

    private static Result doScan(Context ctx, final Listener ls) {
        long t0 = System.currentTimeMillis();
        Result r = new Result();
        if (Scanner.weightHigh(2600)) {   // signals first: hunter waits when Binance is near its per-minute limit
            r.note = "Binance busy — signal scan ko pehle mauqa, hunter thori der mein";
            Result c = cache;
            if (c != null) { c.note = r.note; return c; }
            return r;
        }
        if (ctx != null) FEAT_ADJ = Track.featureAdj(ctx);
        st(ls, "🔥 CoinGecko trending + DexScreener promotions...", 0, 6);
        loadHype();
        st(ls, "📡 Binance: saare coins ka 24h data...", 1, 6);
        Map<String, double[]> day = new HashMap<>();   // sym -> {last, change24, quoteVol24}
        try {
            JSONArray a = new JSONArray(Scanner.get("/api/v3/ticker/24hr?type=MINI"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                String s = o.optString("symbol");
                if (!Scanner.isTradable(s)) continue;
                double last = d(o.optString("lastPrice")), open = d(o.optString("openPrice")), qv = d(o.optString("quoteVolume"));
                if (last <= 0 || qv < 300_000) continue;
                day.put(s, new double[]{last, open > 0 ? (last / open - 1) * 100 : 0, qv});
                LAST_PX.put("Binance:" + s.substring(0, s.length() - 4), last);
            }
        } catch (Exception e) {
            r.note = "Binance tak pohanch nahi hui";
            return r;
        }
        List<String> syms = new ArrayList<>(day.keySet());
        {
            List<String> bych = new ArrayList<>();
            for (String s0 : syms) if (day.get(s0)[2] >= 1_000_000) bych.add(s0);
            Collections.sort(bych, (x, y) -> Double.compare(day.get(y)[1], day.get(x)[1]));
            for (int i = 0; i < bych.size() && i < 10; i++) { String s0 = bych.get(i); double[] v = day.get(s0); r.topGainers.add(new Object[]{s0.substring(0, s0.length() - 4), v[1], v[0], v[2]}); }
            for (int i = bych.size() - 1; i >= 0 && r.topLosers.size() < 10; i--) { String s0 = bych.get(i); double[] v = day.get(s0); r.topLosers.add(new Object[]{s0.substring(0, s0.length() - 4), v[1], v[0], v[2]}); }
        }
        st(ls, "📊 " + syms.size() + " coins ka 15 min + 1 ghanta Relative Volume (RVOL)...", 2, 6);
        Map<String, double[]> w15 = window(syms, "15m"), w1h = window(syms, "1h");
        if (w15.isEmpty() || w1h.isEmpty()) {
            // v34: rolling windows are Binance-only — when Binance is blocked, rebuild 15 m / 1 h from 5 m candles (MEXC backup)
            final Map<String, double[]> f15 = new ConcurrentHashMap<>(), f1 = new ConcurrentHashMap<>();
            List<String> pick = new ArrayList<>(syms);
            Collections.sort(pick, (x, y) -> Double.compare(day.get(y)[2], day.get(x)[2]));
            List<String> sel = new ArrayList<>(pick.subList(0, Math.min(90, pick.size())));
            List<String> mv = new ArrayList<>(syms);
            Collections.sort(mv, (x, y) -> Double.compare(Math.abs(day.get(y)[1]), Math.abs(day.get(x)[1])));
            for (int i = 0; i < mv.size() && i < 40; i++) if (!sel.contains(mv.get(i))) sel.add(mv.get(i));
            st(ls, "📊 Binance ruka hua — " + sel.size() + " coins ka volume backup exchange (MEXC) se...", 2, 6);
            List<Callable<Void>> jb = new ArrayList<>();
            for (final String sy : sel) jb.add(() -> {
                try {
                    Candles c = Candles.fetch(sy, "5m", 13, false);
                    if (c.n >= 12) {
                        double q3 = 0, q12 = 0;
                        for (int i = c.n - 3; i < c.n; i++) q3 += c.quoteVol[i];
                        for (int i = c.n - 12; i < c.n; i++) q12 += c.quoteVol[i];
                        f15.put(sy, new double[]{q3, (c.close[c.n - 1] / c.open[c.n - 3] - 1) * 100});
                        f1.put(sy, new double[]{q12, (c.close[c.n - 1] / c.open[c.n - 12] - 1) * 100});
                    }
                } catch (Exception ignored) {
                }
                return null;
            });
            try { POOL.invokeAll(jb, 40, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
            if (w15.isEmpty()) w15 = f15;
            if (w1h.isEmpty()) w1h = f1;
        }
        r.scanned = syms.size();
        // ---- stage 1: cheap screen on volume pace vs price move
        List<Pick> cands = new ArrayList<>();
        for (String s : syms) {
            double[] dd = day.get(s), a15 = w15.get(s), a1 = w1h.get(s);
            if (a15 == null || a1 == null) continue;
            double pace15 = dd[2] / 96.0, pace1h = dd[2] / 24.0;
            double rv15 = pace15 > 0 ? a15[0] / pace15 : 0, rv1 = pace1h > 0 ? a1[0] / pace1h : 0;
            if (rv15 < 2.0 && rv1 < 1.7) continue;
            Pick p = new Pick();
            p.sym = s;
            p.base = s.substring(0, s.length() - 4);
            p.price = dd[0];
            p.ch24 = dd[1];
            p.vol24 = dd[2];
            p.ch15 = a15[1];
            p.ch1h = a1[1];
            p.rvol15 = rv15;
            p.rvol1h = rv1;
            p.vol15 = a15[0];
            p.vol1h = a1[0];
            p.src.add(String.format(Locale.US, "🟡 Binance Spot — Relative Volume 15m %.1fx · 1h %.1fx", rv15, rv1));
            cands.add(p);
        }
        // early = volume woke up but price has not run yet
        Collections.sort(cands, (x, y) -> Double.compare(early(y), early(x)));
        List<Pick> allC = cands;
        if (cands.size() > 28) cands = new ArrayList<>(cands.subList(0, 28));
        // v32: MOMENTUM lane — coins already up / down 3–18% in the last hour on heavy volume often keep going to +20–50%
        // (the top-gainers list). The early sort above pushes them out, so they get their own 12 slots.
        {
            List<Pick> mom = new ArrayList<>();
            for (Pick p : allC) {
                if (cands.contains(p)) continue;
                double a1 = Math.abs(p.ch1h);
                if (a1 >= 3 && a1 <= 18 && p.rvol1h >= 2 && Math.abs(p.ch24) < 45 && Math.signum(p.ch15) != -Math.signum(p.ch1h)) mom.add(p);
            }
            Collections.sort(mom, (x, y) -> Double.compare(Math.abs(y.ch1h) * 0.4 + y.rvol1h + y.rvol15 * 0.5, Math.abs(x.ch1h) * 0.4 + x.rvol1h + x.rvol15 * 0.5));
            for (int i = 0; i < mom.size() && i < 12; i++) { mom.get(i).momentum = true; cands.add(mom.get(i)); }
        }
        // ---- stage 2: deep checks in parallel; each pick is scored + shown the moment its checks finish
        final Map<String, JSONObject> upTk = upbitPrep(cands);
        final int total = cands.size();
        final int[] done = {0};
        st(ls, "🔬 Gehri jaanch 0/" + total + ": order book, buyers, futures, whales, Korea...", 3, 6);
        List<Callable<Void>> jobs = new ArrayList<>();
        for (final Pick p : cands) jobs.add(() -> {
            deep(p);
            upbitOne(p, upTk);
            score(p);
            int k;
            synchronized (done) { k = ++done[0]; }
            st(ls, "🔬 Gehri jaanch " + k + "/" + total + ": " + p.base + " · order book, buyers, futures, whales, Korea...", 3, 6);
            if (ls != null && p.score >= 40) try { ls.found(p); } catch (Exception ignored) { }
            return null;
        });
        try { POOL.invokeAll(jobs, 30, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
        // ---- every other exchange: volume waking up there first (also coins NOT on Binance)
        st(ls, "🌐 " + VENUES.length + " doosre exchanges (Korea, OKX, Bybit, Bitget, KuCoin, Gate, MEXC, HTX, Bitfinex, Futures)...", 4, 6);
        Map<String, Pick> bySym = new HashMap<>();
        for (Pick p : cands) bySym.put(p.base, p);
        List<Pick> outside = multiVenue(bySym, day.keySet());
        r.venues = VENUES.length + 1;
        for (Pick p : cands) if (p.at == -1 || p.why.isEmpty()) {
            score(p);
            if (ls != null && p.score >= 40) try { ls.found(p); } catch (Exception ignored) { }
        }
        for (Pick p : outside) { score(p); if (ls != null && p.score >= 40) try { ls.found(p); } catch (Exception ignored) { } }
        cands.addAll(outside);
        st(ls, "🧮 Score + time stamp...", 5, 6);
        long now = System.currentTimeMillis();
        for (Pick p : cands) {
            p.at = now;
            if (p.score < 40) continue;
            if (p.pump) r.pumps.add(p); else r.dumps.add(p);
        }
        Collections.sort(r.pumps, (x, y) -> y.score - x.score);
        Collections.sort(r.dumps, (x, y) -> y.score - x.score);
        if (ctx != null) {
            HuntLog.merge(ctx, r);
            Pure.update(ctx, r, ls);
        }
        r.ms = System.currentTimeMillis() - t0;
        r.at = now;
        cache = r;
        st(ls, "✅ Mukammal", 6, 6);
        return r;
    }

    static double early(Pick p) {
        double moved = Math.abs(p.ch1h);
        return p.rvol15 * 1.2 + p.rvol1h - moved * 0.6 - Math.max(0, Math.abs(p.ch24) - 12) * 0.3;
    }

    /** 5m candles (taker buy %, 5m RVOL, squeeze), order book imbalance, futures OI + funding + taker ratio + whale positioning. */
    static void deep(Pick p) {
        try {
            Candles c = Candles.fetch(p.sym, "5m", 60, false);
            int n = c.n;
            if (n > 20) {
                double tb = 0, q = 0;
                for (int i = n - 3; i < n; i++) { tb += c.takerBuyQuote[i]; q += c.quoteVol[i]; }
                p.buyPct = q > 0 ? tb / q * 100 : 50;
                // freshest footprint: last two 5m candles vs the 3 hours before
                double base = 0;
                int bn = 0;
                for (int i = Math.max(0, n - 40); i < n - 2; i++) { base += c.quoteVol[i]; bn++; }
                base = bn > 0 ? base / bn : 0;
                double last = Math.max(c.quoteVol[n - 1], c.quoteVol[n - 2]);
                if (base > 0) { p.rvol5 = last / base; p.vol5 = last; }
                double hi = 0, lo = Double.MAX_VALUE;
                for (int i = n - 40; i < n - 4; i++) { hi = Math.max(hi, c.high[i]); lo = Math.min(lo, c.low[i]); }
                p.squeeze = lo > 0 ? (hi / lo - 1) * 100 : 99;   // % range of the 3 hours before
                double h1 = 0, l1 = Double.MAX_VALUE;
                for (int i = n - 12; i < n; i++) { h1 = Math.max(h1, c.high[i]); l1 = Math.min(l1, c.low[i]); }
                if (h1 > 0) p.fromHi = (1 - c.close[n - 1] / h1) * 100;
                if (l1 > 0 && l1 < Double.MAX_VALUE) p.fromLo = (c.close[n - 1] / l1 - 1) * 100;
                if (c.close[n - 1] > hi && p.squeeze < 4) p.raw.add(String.format(Locale.US, "📐 Consolidation breakout: %.1f%% ki tight range (3 ghante) UPAR se tooti", p.squeeze));
                if (c.close[n - 1] < lo && p.squeeze < 4) p.raw.add(String.format(Locale.US, "📐 Consolidation breakdown: %.1f%% ki tight range (3 ghante) NEECHE se tooti", p.squeeze));
            }
        } catch (Exception ignored) {
        }
        try {
            JSONObject o = new JSONObject(Scanner.get("/api/v3/depth?symbol=" + p.sym + "&limit=100"));
            JSONArray b = o.getJSONArray("bids"), a = o.getJSONArray("asks");
            double mid = p.price, bs = 0, as = 0;
            for (int i = 0; i < b.length(); i++) { JSONArray x = b.getJSONArray(i); double pr = d(x.getString(0)); if (pr >= mid * 0.98) bs += pr * d(x.getString(1)); }
            for (int i = 0; i < a.length(); i++) { JSONArray x = a.getJSONArray(i); double pr = d(x.getString(0)); if (pr <= mid * 1.02) as += pr * d(x.getString(1)); }
            if (bs + as > 0) p.bookImb = (bs - as) / (bs + as) * 100;
        } catch (Exception ignored) {
        }
        try {
            JSONArray oi = new JSONArray(Scanner.getAbsolute("https://fapi.binance.com/futures/data/openInterestHist?symbol=" + p.sym + "&period=5m&limit=13"));
            if (oi.length() >= 12) {
                double o0 = oi.getJSONObject(0).optDouble("sumOpenInterestValue", 0), o1 = oi.getJSONObject(oi.length() - 1).optDouble("sumOpenInterestValue", 0);
                if (o0 > 0) p.oiCh = (o1 / o0 - 1) * 100;
            }
            JSONArray f = new JSONArray(Scanner.getAbsolute("https://fapi.binance.com/fapi/v1/fundingRate?symbol=" + p.sym + "&limit=1"));
            if (f.length() > 0) p.funding = f.getJSONObject(0).optDouble("fundingRate", 0) * 100;
            // taker buy/sell volume ratio on futures (last 15 min) — aggressive futures buyers
            JSONArray tr = new JSONArray(Scanner.getAbsolute("https://fapi.binance.com/futures/data/takerlongshortRatio?symbol=" + p.sym + "&period=5m&limit=3"));
            double bv = 0, sv = 0;
            for (int i = 0; i < tr.length(); i++) { bv += tr.getJSONObject(i).optDouble("buyVol", 0); sv += tr.getJSONObject(i).optDouble("sellVol", 0); }
            if (sv > 0) p.takerRatio = bv / sv;
            // top traders (biggest accounts) long/short position ratio change over the last hour
            JSONArray wl = new JSONArray(Scanner.getAbsolute("https://fapi.binance.com/futures/data/topLongShortPositionRatio?symbol=" + p.sym + "&period=5m&limit=13"));
            if (wl.length() >= 12) {
                double a0 = wl.getJSONObject(0).optDouble("longShortRatio", 0), a1 = wl.getJSONObject(wl.length() - 1).optDouble("longShortRatio", 0);
                if (a0 > 0) p.whaleLs = (a1 / a0 - 1) * 100;
            }
        } catch (Exception ignored) {
        }
    }

    /** Korea (Upbit): KRW market list + one ticker call for all candidates. */
    static Map<String, JSONObject> upbitPrep(List<Pick> l) {
        Map<String, JSONObject> tk = new HashMap<>();
        try {
            JSONArray mk = new JSONArray(Scanner.getAbsolute("https://api.upbit.com/v1/market/all"));
            java.util.Set<String> krw = new java.util.HashSet<>();
            for (int i = 0; i < mk.length(); i++) {
                String m = mk.getJSONObject(i).optString("market");
                if (m.startsWith("KRW-")) krw.add(m.substring(4));
            }
            StringBuilder q = new StringBuilder("KRW-USDT");
            for (Pick p : l) if (krw.contains(p.base)) q.append(",KRW-").append(p.base);
            JSONArray t = new JSONArray(Scanner.getAbsolute("https://api.upbit.com/v1/ticker?markets=" + q));
            for (int i = 0; i < t.length(); i++) {
                JSONObject o = t.getJSONObject(i);
                String m = o.optString("market").substring(4);
                if (m.equals("USDT")) { double u = o.optDouble("trade_price", 0); if (u > 500) usdKrw = u; } else tk.put(m, o);
            }
        } catch (Exception ignored) {
        }
        return tk;
    }

    static void upbitOne(Pick p, Map<String, JSONObject> tk) {
        JSONObject o = tk.get(p.base);
        if (o == null) return;
        if (usdKrw > 0 && p.price > 0) p.kimchi = (o.optDouble("trade_price", 0) / (p.price * usdKrw) - 1) * 100;
        try {
            JSONArray cs = new JSONArray(Scanner.getAbsolute("https://api.upbit.com/v1/candles/minutes/15?market=KRW-" + p.base + "&count=2"));
            double v15 = cs.getJSONObject(0).optDouble("candle_acc_trade_price", 0);
            double day = o.optDouble("acc_trade_price_24h", 0);
            if (day > 0) p.upbitRvol = v15 / (day / 96.0);
            if (!Double.isNaN(p.upbitRvol) && p.upbitRvol >= 2)
                p.src.add(String.format(Locale.US, "🇰🇷 Upbit (KRW) — 15 min volume %.1fx (₩%s)", p.upbitRvol, Fmt.num(v15 / 1e6) + "M"));
        } catch (Exception ignored) {
        }
    }

    // ------------------------------------------------------------------ other exchanges (snapshots of 24h volume)
    static final String[] VENUES = {"Binance Futures", "Upbit", "Bithumb", "Coinone", "Korbit", "OKX", "Bybit", "Bitget", "KuCoin", "Gate", "MEXC", "HTX", "Bitfinex"};
    static final java.util.Set<String> KRW_VENUES = new java.util.HashSet<>(java.util.Arrays.asList("Upbit", "Bithumb", "Coinone", "Korbit"));
    private static final Map<String, Map<String, double[]>> SNAP = new HashMap<>();   // venue -> base -> {vol24 (quote), price}
    private static long snapAt;

    /** {base -> {24h quote volume in the venue's quote currency, last price}} */
    static Map<String, double[]> loadVenue(String v) throws Exception {
        Map<String, double[]> m = new HashMap<>();
        switch (v) {
            case "Bithumb": {
                JSONObject d = new JSONObject(Scanner.getAbsolute("https://api.bithumb.com/public/ticker/ALL_KRW")).getJSONObject("data");
                java.util.Iterator<String> it = d.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    JSONObject o = d.optJSONObject(k);
                    if (o == null) continue;
                    m.put(k.toUpperCase(Locale.US), new double[]{d(o.optString("acc_trade_value_24H")), d(o.optString("closing_price"))});
                }
                return m;
            }
            case "Upbit": {
                JSONArray mk = new JSONArray(Scanner.getAbsolute("https://api.upbit.com/v1/market/all"));
                StringBuilder q = new StringBuilder();
                for (int i = 0; i < mk.length(); i++) {
                    String s = mk.getJSONObject(i).optString("market");
                    if (s.startsWith("KRW-")) { if (q.length() > 0) q.append(','); q.append(s); }
                }
                JSONArray t = new JSONArray(Scanner.getAbsolute("https://api.upbit.com/v1/ticker?markets=" + q));
                for (int i = 0; i < t.length(); i++) {
                    JSONObject o = t.getJSONObject(i);
                    String b = o.optString("market").substring(4);
                    if (b.equals("USDT")) { double u = o.optDouble("trade_price", 0); if (u > 500) usdKrw = u; continue; }
                    m.put(b, new double[]{o.optDouble("acc_trade_price_24h", 0), o.optDouble("trade_price", 0)});
                }
                return m;
            }
            case "Coinone": {
                JSONArray t = new JSONObject(Scanner.getAbsolute("https://api.coinone.co.kr/public/v2/ticker_new/KRW")).getJSONArray("tickers");
                for (int i = 0; i < t.length(); i++) {
                    JSONObject o = t.getJSONObject(i);
                    m.put(o.optString("target_currency").toUpperCase(Locale.US), new double[]{d(o.optString("quote_volume")), d(o.optString("last"))});
                }
                return m;
            }
            case "Korbit": {
                JSONObject t = new JSONObject(Scanner.getAbsolute("https://api.korbit.co.kr/v1/ticker/detailed/all"));
                java.util.Iterator<String> it = t.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    if (!k.endsWith("_krw")) continue;
                    JSONObject o = t.optJSONObject(k);
                    if (o == null) continue;
                    double last = d(o.optString("last"));
                    m.put(k.substring(0, k.length() - 4).toUpperCase(Locale.US), new double[]{d(o.optString("volume")) * last, last});
                }
                return m;
            }
            case "Bitfinex": {
                JSONArray t = new JSONArray(Scanner.getAbsolute("https://api-pub.bitfinex.com/v2/tickers?symbols=ALL"));
                for (int i = 0; i < t.length(); i++) {
                    JSONArray o = t.optJSONArray(i);
                    if (o == null || o.length() < 11) continue;
                    String s = o.optString(0);
                    if (!s.startsWith("t")) continue;
                    String b;
                    if (s.endsWith(":USD")) b = s.substring(1, s.length() - 4);
                    else if (s.length() == 7 && s.endsWith("USD")) b = s.substring(1, 4);
                    else continue;
                    double last = o.optDouble(7, 0);
                    m.put(b.toUpperCase(Locale.US), new double[]{Math.abs(o.optDouble(8, 0)) * last, last});
                }
                return m;
            }
            case "Binance Futures": {
                JSONArray t = new JSONArray(Scanner.getAbsolute("https://fapi.binance.com/fapi/v1/ticker/24hr"));
                for (int i = 0; i < t.length(); i++) {
                    JSONObject o = t.getJSONObject(i);
                    String s = o.optString("symbol");
                    if (!s.endsWith("USDT")) continue;
                    m.put(s.substring(0, s.length() - 4), new double[]{d(o.optString("quoteVolume")), d(o.optString("lastPrice"))});
                }
                return m;
            }
            default:
                for (Map.Entry<String, Mispricing.Quote> e : Mispricing.load(v).entrySet())
                    m.put(e.getKey(), new double[]{e.getValue().vol24, e.getValue().last > 0 ? e.getValue().last : e.getValue().mid()});
                return m;
        }
    }

    /**
     * Compares each exchange's rolling 24h volume with the previous snapshot (3–16 min ago): the volume added per minute vs the
     * normal per-minute pace = a volume spike on THAT exchange. Binance coins get extra evidence; coins only listed elsewhere become picks.
     */
    static List<Pick> multiVenue(Map<String, Pick> binPicks, java.util.Set<String> binanceSyms) {
        List<Pick> out = new ArrayList<>();
        long now = System.currentTimeMillis();
        if (now - snapAt < 3 * 60_000L && !SNAP.isEmpty()) return out;
        final Map<String, Map<String, double[]>> fresh = new ConcurrentHashMap<>();
        List<Callable<Void>> jobs = new ArrayList<>();
        for (final String v : VENUES) jobs.add(() -> { try { fresh.put(v, loadVenue(v)); } catch (Exception ignored) { } return null; });
        try { POOL.invokeAll(jobs, 25, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
        boolean have = !SNAP.isEmpty() && now - snapAt < 16 * 60_000L;
        double mins = Math.max(1, (now - snapAt) / 60_000.0);
        Map<String, Pick> outsideBest = new HashMap<>();
        for (Map.Entry<String, Map<String, double[]>> e : fresh.entrySet()) {
            boolean krw = KRW_VENUES.contains(e.getKey());
            for (Map.Entry<String, double[]> c : e.getValue().entrySet())
                if (c.getValue()[1] > 0) LAST_PX.put(e.getKey() + ":" + c.getKey(), krw ? c.getValue()[1] / usdKrw : c.getValue()[1]);
        }
        if (have) {
            for (Map.Entry<String, Map<String, double[]>> e : fresh.entrySet()) {
                Map<String, double[]> old = SNAP.get(e.getKey());
                if (old == null) continue;
                String ven = e.getKey();
                boolean krw = KRW_VENUES.contains(ven);
                for (Map.Entry<String, double[]> c : e.getValue().entrySet()) {
                    double[] o = old.get(c.getKey()), nw = c.getValue();
                    if (o == null || o[0] <= 0 || nw[0] <= 0) continue;
                    double usdVol = krw ? nw[0] / usdKrw : nw[0];
                    if (usdVol < 150_000) continue;
                    double added = (nw[0] - o[0]) / mins, pace = nw[0] / 1440.0;
                    if (added <= 0 || pace <= 0) continue;
                    double spike = added / pace;   // >1 = faster than normal (lower bound: the dropped old volume is ignored)
                    if (spike < 3) continue;
                    double pch = o[1] > 0 ? (nw[1] / o[1] - 1) * 100 : 0;
                    double addedUsd = (krw ? (nw[0] - o[0]) / usdKrw : nw[0] - o[0]);
                    String base = c.getKey();
                    String line = String.format(Locale.US, "%s %s — pichle %.0f min mein normal se %.1fx tez volume ($%s trade), price %+.1f%%",
                            krw ? "🇰🇷" : "🌐", ven, mins, spike, Fmt.num(addedUsd / 1000) + "K", pch);
                    Pick bp = binPicks.get(base);
                    if (bp != null) {
                        if (Double.isNaN(bp.venueSpike) || spike > bp.venueSpike) bp.venueSpike = spike;
                        if (krw && (Double.isNaN(bp.upbitRvol) || spike > bp.upbitRvol)) bp.upbitRvol = Math.max(Double.isNaN(bp.upbitRvol) ? 0 : bp.upbitRvol, spike);
                        bp.src.add(line);
                        bp.raw.add(line);
                        bp.at = -1;   // marker: re-score with the new evidence
                    } else if (!binanceSyms.contains(base + "USDT") && !Mispricing.isStable(base)) {
                        Pick p = outsideBest.get(base);
                        if (p != null) {
                            p.src.add(line);
                            if (p.venueSpike >= spike) continue;
                        } else {
                            p = new Pick();
                            p.src.add(line);
                        }
                        p.sym = base;
                        p.base = base;
                        p.venue = ven;
                        p.price = krw ? nw[1] / usdKrw : nw[1];
                        p.vol24 = usdVol;
                        p.venueSpike = spike;
                        p.rvol15 = spike;
                        p.rvol1h = spike;
                        p.vol15 = Math.max(0, addedUsd) / mins * 15;
                        p.vol1h = p.vol15 * 4;
                        p.ch15 = pch;
                        p.ch1h = pch;
                        p.buyPct = pch > 0.3 ? 60 : pch < -0.3 ? 40 : 50;
                        if (krw) p.upbitRvol = spike;
                        outsideBest.put(base, p);
                    }
                }
            }
        }
        SNAP.clear();
        SNAP.putAll(fresh);
        snapAt = now;
        out.addAll(outsideBest.values());
        Collections.sort(out, (a, b) -> Double.compare(b.venueSpike, a.venueSpike));
        if (out.size() > 14) out = new ArrayList<>(out.subList(0, 14));
        return out;
    }

    // ------------------------------------------------------------------ hype: what people search / promote right now
    static volatile java.util.Map<String, Integer> TRENDING = new HashMap<>();
    static volatile java.util.Set<String> BOOSTED = new java.util.HashSet<>();
    private static long hypeAt;

    static void loadHype() {
        if (System.currentTimeMillis() - hypeAt < 10 * 60_000L) return;
        hypeAt = System.currentTimeMillis();
        try {
            JSONArray c = new JSONObject(Scanner.getAbsolute("https://api.coingecko.com/api/v3/search/trending")).getJSONArray("coins");
            Map<String, Integer> m = new HashMap<>();
            for (int i = 0; i < c.length(); i++) {
                JSONObject it = c.getJSONObject(i).optJSONObject("item");
                if (it != null) m.put(it.optString("symbol").toUpperCase(Locale.US), i + 1);
            }
            if (!m.isEmpty()) TRENDING = m;
        } catch (Exception ignored) {
        }
        try {
            JSONArray b = new JSONArray(Scanner.getAbsolute("https://api.dexscreener.com/token-boosts/top/v1"));
            java.util.Set<String> addrs = new java.util.LinkedHashSet<>();
            for (int i = 0; i < b.length() && i < 30; i++) {
                JSONObject o = b.getJSONObject(i);
                addrs.add(o.optString("chainId") + ":" + o.optString("tokenAddress"));
            }
            java.util.Set<String> syms = new java.util.HashSet<>();
            int n = 0;
            for (String a : addrs) {
                if (n++ >= 12) break;
                try {
                    String[] ca = a.split(":", 2);
                    JSONObject r = new JSONObject(Scanner.getAbsolute("https://api.dexscreener.com/latest/dex/tokens/" + ca[1]));
                    JSONArray pairs = r.optJSONArray("pairs");
                    if (pairs != null && pairs.length() > 0) syms.add(pairs.getJSONObject(0).getJSONObject("baseToken").optString("symbol").toUpperCase(Locale.US));
                } catch (Exception ignored) {
                }
            }
            if (!syms.isEmpty()) BOOSTED = syms;
        } catch (Exception ignored) {
        }
    }

    /** Feature bits, also used to learn which footprints really worked. */
    static final int F_RVOL = 1, F_BUY = 2, F_BOOK = 4, F_OI = 8, F_KOREA = 16, F_TREND = 32, F_VENUE = 64, F_NEWS = 128;
    static final String[] F_NAMES = {"Volume 4x+", "Buyers 60%+", "Order book", "Futures OI", "Korea", "CoinGecko trending", "Doosre exchange", "News"};
    static volatile double[] FEAT_ADJ = new double[8];

    /** Builds the score and the full evidence list from scratch (safe to call again after new evidence arrives). */
    static synchronized void score(Pick p) {
        p.why.clear();
        p.feat = 0;
        double bull = 0, bear = 0;
        boolean bin = "Binance".equals(p.venue);
        double rv = Math.max(p.rvol15, p.rvol1h * 0.9);
        if (!Double.isNaN(p.rvol5) && p.rvol5 >= 3) rv = Math.max(rv, Math.min(p.rvol5, 12) * 0.85);   // freshest 5m burst counts too
        double vScore = Math.min(30, (rv - 1.5) * 8);   // volume is the main footprint
        boolean notRun = Math.abs(p.ch1h) < 6 && Math.abs(p.ch24) < 20;
        double dirFlow = (p.buyPct - 50) / 50;          // −1..1
        if (p.buyPct >= 55) bull += vScore; else if (p.buyPct <= 45) bear += vScore; else { bull += vScore / 2; bear += vScore / 2; }
        if (rv >= 4) p.feat |= F_RVOL;
        if (p.buyPct >= 60 || p.buyPct <= 40) p.feat |= F_BUY;
        if (!Double.isNaN(p.bookImb) && Math.abs(p.bookImb) > 15) p.feat |= F_BOOK;
        if (!Double.isNaN(p.oiCh) && Math.abs(p.oiCh) >= 3) p.feat |= F_OI;
        if ((!Double.isNaN(p.upbitRvol) && p.upbitRvol >= 2) || (!Double.isNaN(p.kimchi) && Math.abs(p.kimchi) >= 1.5)) p.feat |= F_KOREA;
        if (!bin) p.why.add("📍 Exchange: " + p.venue + " (Binance Spot par listed nahi)");
        else p.why.add(String.format(Locale.US, "📊 Unusual Volume (RVOL) — 15m: %.1fx · 1h: %.1fx%s", p.rvol15, p.rvol1h,
                Double.isNaN(p.rvol5) ? "" : String.format(Locale.US, " · 5m: %.1fx", p.rvol5)));
        if (bin) p.why.add(String.format(Locale.US, "🧾 Order flow: aggressive %s %.0f%% (taker buy, last 15 min)", p.buyPct >= 50 ? "buyers" : "sellers",
                p.buyPct >= 50 ? p.buyPct : 100 - p.buyPct));
        if (dirFlow > 0) bull += dirFlow * 25; else bear += -dirFlow * 25;
        // price-volume divergence: heavy volume, price barely moved = someone is building a position quietly
        boolean diverg = rv >= 3 && Math.abs(p.ch15) < 1.5 && Math.abs(p.ch1h) < 3;
        if (diverg) {
            if (p.buyPct >= 53 || (!Double.isNaN(p.bookImb) && p.bookImb > 10)) bull += 8;
            else if (p.buyPct <= 47) bear += 8;
            p.why.add(String.format(Locale.US, "🎯 Price-Volume Divergence: volume %.1fx magar price sirf %+.1f%% (1h) — %s, price ne abhi react nahi kiya",
                    rv, p.ch1h, p.buyPct <= 47 ? "chupke se maal nikala ja raha (distribution)" : "koi chupke se position bana raha (accumulation)"));
        }
        if (!Double.isNaN(p.bookImb)) {
            if (p.bookImb > 15) { bull += Math.min(12, p.bookImb / 4); p.why.add(String.format(Locale.US, "📗 Order book imbalance: BUY side %+.0f%% bhari (±2%% ke andar)", p.bookImb)); }
            else if (p.bookImb < -15) { bear += Math.min(12, -p.bookImb / 4); p.why.add(String.format(Locale.US, "📕 Order book imbalance: SELL side %.0f%% bhari (±2%% ke andar)", -p.bookImb)); }
        }
        if (!Double.isNaN(p.oiCh) && Math.abs(p.oiCh) >= 3) {
            double s = Math.min(12, Math.abs(p.oiCh));
            if (p.ch1h >= 0) bull += s; else bear += s;
            p.why.add(String.format(Locale.US, "📈 Futures Open Interest 1 ghante mein %+.1f%% — naye positions khul rahe", p.oiCh));
        }
        if (!Double.isNaN(p.takerRatio) && (p.takerRatio >= 1.3 || p.takerRatio <= 0.77)) {
            if (p.takerRatio >= 1.3) bull += Math.min(8, (p.takerRatio - 1) * 10); else bear += Math.min(8, (1 / p.takerRatio - 1) * 10);
            p.why.add(String.format(Locale.US, "⚡ Futures taker buy/sell ratio %.2f — %s", p.takerRatio, p.takerRatio >= 1.3 ? "futures mein market-buy zyada" : "futures mein market-sell zyada"));
        }
        if (!Double.isNaN(p.whaleLs) && Math.abs(p.whaleLs) >= 4) {
            if (p.whaleLs > 0) bull += Math.min(7, p.whaleLs / 2); else bear += Math.min(7, -p.whaleLs / 2);
            p.why.add(String.format(Locale.US, "🐋 Top traders (bare accounts) ka long/short ratio 1 ghante mein %+.1f%% — %s", p.whaleLs, p.whaleLs > 0 ? "whales long barha rahe" : "whales short / long kam kar rahe"));
        }
        if (!Double.isNaN(p.funding) && Math.abs(p.funding) >= 0.05) {
            if (p.funding < 0) { bull += 6; p.why.add(String.format(Locale.US, "💱 Funding %.3f%% — shorts bhare (short squeeze ka imkaan)", p.funding)); }
            else { bear += 6; p.why.add(String.format(Locale.US, "💱 Funding %.3f%% — longs bhare (girawat par liquidations)", p.funding)); }
        }
        if (bin && !Double.isNaN(p.upbitRvol) && p.upbitRvol >= 2) {
            bull += Math.min(12, p.upbitRvol * 2.5);
            p.why.add(String.format(Locale.US, "🇰🇷 Korea volume %.1fx normal se (Korean retail khareed — Asian pumps aksar yahin se)", p.upbitRvol));
        }
        if (!Double.isNaN(p.kimchi) && Math.abs(p.kimchi) >= 1.5) {
            if (p.kimchi > 0) bull += Math.min(8, p.kimchi * 2); else bear += Math.min(8, -p.kimchi * 2);
            p.why.add(String.format(Locale.US, "🇰🇷 Kimchi premium %+.1f%% (Korea mein price %s)", p.kimchi, p.kimchi > 0 ? "mehngi — wahan demand" : "sasti — wahan selling"));
        }
        p.why.addAll(p.raw);
        // hype: CoinGecko trending (people searching) · DexScreener boosts · many fresh mentions in the news radar / X feed
        Integer tr = TRENDING.get(p.base);
        if (tr != null) {
            bull += Math.max(4, 14 - tr); p.feat |= F_TREND;
            p.why.add("🔥 CoinGecko trending #" + tr + " — log is coin ko sab se zyada search kar rahe hain");
            addSrc(p, "🔥 CoinGecko Trending #" + tr);
        }
        if (BOOSTED.contains(p.base)) { bull += 4; p.why.add("💸 DexScreener par paid promotion / boost (hype — ehtiyat)"); addSrc(p, "💸 DexScreener Boost"); }
        List<NewsEngine.Item> ment = NewsEngine.about(p.base, 6 * 3600_000L, 20);
        if (ment.size() >= 3) {
            bull += 3; bear += 3; p.feat |= F_NEWS;
            p.why.add("🗣️ Social / news buzz: pichle 6 ghante mein " + ment.size() + " khabrein / X posts");
            addSrc(p, "🗣️ News + X feed (" + ment.size() + " mentions)");
        }
        if (!Double.isNaN(p.venueSpike) && p.venueSpike >= 3) {
            double vs = Math.min(10, p.venueSpike * 1.5);
            if (p.ch15 >= 0) bull += vs; else bear += vs;
            p.feat |= F_VENUE;
        }
        // news / catalysts for this coin
        for (NewsEngine.Item it : NewsEngine.about(p.base, 6 * 3600_000L, 2)) {
            if (it.dir > 0) bull += 6 * it.severity; else if (it.dir < 0) bear += 6 * it.severity;
            p.why.add("📰 " + it.category + ": " + it.title + (it.source.isEmpty() ? "" : " (" + it.source + ")"));
            addSrc(p, "📰 " + (it.source.isEmpty() ? "News" : it.source));
        }
        for (CatalystEngine.Event e : CatalystEngine.forCoin(p.base, 3L * 86_400_000L)) {
            if (e.dir > 0) bull += 5 * e.severity; else if (e.dir < 0) bear += 5 * e.severity;
            p.why.add("📆 " + CatalystEngine.label(e) + ": " + e.title);
            addSrc(p, "📆 Catalyst Radar");
        }
        if (p.squeeze > 0 && p.squeeze < 4) { bull += 3; bear += 3; }
        if (bin) {
            if (!Double.isNaN(p.bookImb) || !Double.isNaN(p.buyPct)) addSrc(p, "🟡 Binance order book + trades (taker flow)");
            if (!Double.isNaN(p.oiCh) || !Double.isNaN(p.takerRatio)) addSrc(p, "🟡 Binance Futures (OI, funding, taker ratio, top traders)");
        }
        p.pump = bull >= bear;
        p.bull = bull;
        p.bear = bear;
        double s = Math.max(bull, bear) - Math.min(bull, bear) * 0.4;
        // v32: momentum continuation — already +3..18% in 1h, volume still heavy, buyers in control and the price HOLDS near its high
        boolean up = bull >= bear;
        double hold = up ? p.fromHi : p.fromLo;
        boolean contin = Math.abs(p.ch1h) >= 3 && Math.abs(p.ch1h) <= 18 && Math.abs(p.ch24) < 45 && p.rvol1h >= 2
                && !Double.isNaN(hold) && hold <= 1.8 && (up ? p.ch1h > 0 && p.buyPct >= 55 : p.ch1h < 0 && p.buyPct <= 45);
        if (contin) {
            s += 10 + Math.min(12, (p.rvol1h - 2) * 3);   // heavier volume behind the move = stronger continuation
            p.stage = "MOMENTUM";
            p.why.add(String.format(Locale.US, "🔥 Momentum continuation: 1h %+.1f%% · 1h ke %s se sirf %.1f%% door (move TIKA hua) · %s %.0f%% · volume 1h %.1fx — "
                    + "5–15%% ke baad bhi aksar top %s tak jata hai", p.ch1h, up ? "high" : "low", hold, up ? "buyers" : "sellers", up ? p.buyPct : 100 - p.buyPct, p.rvol1h,
                    up ? "gainers" : "losers"));
        } else if (!notRun) {
            s *= 0.6;   // already moved a lot: late
            p.stage = "LATE";
            p.why.add(String.format(Locale.US, "⚠️ Late: pehle hi chal chuka — 1h %+.1f%% · 24h %+.1f%%, entry ka risk zyada", p.ch1h, p.ch24));
        } else if (diverg) {
            p.stage = "EARLY";
            p.why.add(String.format(Locale.US, "✅ Early detection: price abhi tak sirf 15m %+.1f%% · 1h %+.1f%% — move shuru hone se pehle pakra", p.ch15, p.ch1h));
        } else {
            p.stage = "BREAKOUT";
            p.why.add(String.format(Locale.US, "⚡ Momentum shuru: 15m %+.1f%% · 1h %+.1f%% — move abhi taaza hai", p.ch15, p.ch1h));
        }
        // learning: footprints that really led to moves on this phone's history get extra weight (and failed ones less)
        double adj = 0;
        for (int b = 0; b < 8; b++) if ((p.feat & (1 << b)) != 0) adj += FEAT_ADJ[b];
        if (Math.abs(adj) >= 1) p.why.add(String.format(Locale.US, "🧠 Machine learning wazan: %+.0f (is phone ke pichle nateejon se)", adj));
        s += adj;
        p.score = (int) Math.round(Math.max(0, Math.min(100, s)));
        p.volConf = volConf(p);
        p.why.add(1, String.format(Locale.US, "✔️ Volume confirmation %d%% (size, 1h persistence, %s side, doosre exchanges)", p.volConf, p.pump ? "buy" : "sell"));
    }

    /**
     * Volume confirmation 0..100:
     *  35 size of the burst (RVOL 15m / 5m) · 20 it lasted (1h RVOL) · 20 one side dominates (taker buy / sell %) ·
     *  25 confirmed elsewhere (other exchanges, Korea, order book on the same side).
     */
    static int volConf(Pick p) {
        double rvA = Math.max(p.rvol15, p.rvol1h * 0.9);
        if (!Double.isNaN(p.rvol5)) rvA = Math.max(rvA, p.rvol5 * 0.8);
        double a = clamp01((rvA - 1.5) / 4.5) * 35;
        double b = clamp01((p.rvol1h - 1) / 2.5) * 20;
        double dir = p.pump ? p.buyPct - 50 : 50 - p.buyPct;
        double c = clamp01(dir / 20) * 20;
        int other = 0;
        for (String s : p.src) if (s.startsWith("🌐") || s.startsWith("🇰🇷")) other++;
        if (!"Binance".equals(p.venue)) other++;
        double d = other >= 2 ? 15 : other == 1 ? 10 : 0;
        if (!Double.isNaN(p.bookImb) && (p.pump ? p.bookImb > 15 : p.bookImb < -15)) d += 10;
        if (!Double.isNaN(p.takerRatio) && (p.pump ? p.takerRatio >= 1.2 : p.takerRatio <= 0.83)) d += 5;
        return (int) Math.round(Math.min(100, a + b + c + Math.min(25, d)));
    }

    static double clamp01(double v) { return v < 0 ? 0 : v > 1 ? 1 : v; }

    static void addSrc(Pick p, String s) { if (!p.src.contains(s)) p.src.add(s); }

    // ------------------------------------------------------------------ hunt log: every hunted coin with date + time
    public static final class HuntLog {
        private static List<Pick> mem;

        public static synchronized List<Pick> all(Context ctx) {
            if (mem == null) {
                mem = new ArrayList<>();
                try {
                    JSONArray a = new JSONArray(Prefs.getStr(ctx, "huntlog", "[]"));
                    for (int i = 0; i < a.length(); i++) mem.add(Pick.fromJson(a.getJSONObject(i)));
                } catch (Exception ignored) {
                }
            }
            return new ArrayList<>(mem);
        }

        public static synchronized Pick find(Context ctx, String key) {
            for (Pick p : all(ctx)) if (p.key().equals(key)) return p;
            return null;
        }

        /** Adds new hunts (score ≥ 50) with the moment they were FIRST caught; updates ones still showing up. */
        static synchronized void merge(Context ctx, Result r) {
            all(ctx);
            long now = System.currentTimeMillis();
            List<Pick> l = new ArrayList<>(r.pumps);
            l.addAll(r.dumps);
            for (Pick p : l) {
                if (p.score < 50) continue;
                Pick old = null;
                for (Pick o : mem) if (o.key().equals(p.key()) && now - o.at < 6 * 3600_000L) { old = o; break; }
                if (old != null) {
                    p.firstAt = old.firstAt;
                    p.firstPrice = old.firstPrice;
                    p.bestScore = Math.max(old.bestScore, p.score);
                    mem.remove(old);
                } else {
                    p.firstAt = now;
                    p.firstPrice = p.price;
                    p.bestScore = p.score;
                }
                p.at = now;
                mem.add(0, p);
            }
            Collections.sort(mem, (a, b) -> Long.compare(b.firstAt, a.firstAt));
            while (mem.size() > 80) mem.remove(mem.size() - 1);
            JSONArray a = new JSONArray();
            for (Pick p : mem) a.put(p.toJson());
            Prefs.putStr(ctx, "huntlog", a.toString());
        }
    }

    /** Price now (USD) for a hunted coin, from the last scan / exchange snapshot; 0 if unknown. */
    public static double priceNow(Pick p) {
        Double v = LAST_PX.get(p.venue + ":" + p.base);
        return v == null ? 0 : v;
    }

    // ------------------------------------------------------------------ track record (honest): built on PURE hunts only
    public static final class Track {
        static void record(Context ctx, Result r) { }   // v29: raw picks are no longer graded — only confirmed (pure) hunts with a real plan

        public static void resolve(Context ctx) { Pure.resolve(ctx); }

        /** Per-feature score adjustment from pure-hunt outcomes: (TP1 rate with feature − overall) × 40, needs 8+ samples. */
        static double[] featureAdj(Context ctx) {
            double[] adj = new double[8];
            try {
                List<JSONObject> a = Pure.all(ctx);
                int tot = 0, hits = 0;
                int[] n = new int[8], h = new int[8];
                for (JSONObject o : a) {
                    if ("open".equals(o.optString("st"))) continue;
                    boolean hit = o.optInt("hit") >= 1;
                    tot++;
                    if (hit) hits++;
                    int f = o.optInt("feat");
                    for (int b = 0; b < 8; b++) if ((f & (1 << b)) != 0) { n[b]++; if (hit) h[b]++; }
                }
                if (tot < 12) return adj;
                double base = hits / (double) tot;
                for (int b = 0; b < 8; b++) if (n[b] >= 6) adj[b] = Math.max(-12, Math.min(12, (h[b] / (double) n[b] - base) * 40));
            } catch (Exception ignored) {
            }
            return adj;
        }

        public static String featureReport(Context ctx) {
            double[] adj = featureAdj(ctx);
            StringBuilder sb = new StringBuilder();
            for (int b = 0; b < 8; b++) if (adj[b] != 0) sb.append(adj[b] > 0 ? "🟢 " : "🔴 ").append(F_NAMES[b]).append(String.format(Locale.US, " %+.0f   ", adj[b]));
            return sb.toString().trim();
        }

        /** {resolved, TP1+ hits, stop losses, avg best move %, open} */
        public static double[] stats(Context ctx) {
            double[] s = new double[5];
            for (JSONObject o : Pure.all(ctx)) {
                if ("open".equals(o.optString("st"))) { s[4]++; continue; }
                s[0]++;
                if (o.optInt("hit") >= 1) s[1]++;
                else if ("sl".equals(o.optString("st"))) s[2]++;
                s[3] += o.optDouble("best", 0);
            }
            if (s[0] > 0) s[3] /= s[0];
            return s;
        }
    }

    // ------------------------------------------------------------------ 24/7
    public static void tick(Context ctx) {
        if (!Prefs.huntOn(ctx)) return;
        if (System.currentTimeMillis() - Prefs.getLong(ctx, "hunttick") < Prefs.huntEverySec(ctx) * 1000L) return;
        Prefs.putLong(ctx, "hunttick", System.currentTimeMillis());
        scan(ctx);
        Track.resolve(ctx);
    }

    /** v29: raw picks no longer notify (they come and go) — only CONFIRMED pure hunts do (see Pure). */
    public static void alert(Context ctx, Result r) { }

    // ------------------------------------------------------------------ PURE hunts: confirmed, researched, with a full plan
    /**
     * A raw pick only becomes a PURE hunt when it:
     *  1. shows up in 3+ scans over at least 10 minutes, same direction, average score 58+ (not a one-scan blip)
     *  2. is a real Binance coin with $2M+ daily volume, not already late, and price did not break the idea while watching
     *  3. passes research: no big unlock / delisting right ahead, fundamentals + news + events (CoinIntel)
     *  4. has a structure plan: entry zone, stop beyond support, targets beyond resistances with reward ≥ 1.5× risk
     *  5. this coin's own history gives a real probability for each target within 10 days
     * Result: TP1 = resistance BROKEN, SL = support lost — not ±0.3% noise. Tracked until a target / stop / 10 days.
     */
    public static final class Pure {
        static final class Watch { long first; int seen; double sum, vcSum, firstPrice; String firstStage; Pick last; String note = ""; }

        static final Map<String, Watch> WATCH = new ConcurrentHashMap<>();
        private static List<JSONObject> mem;

        public static synchronized List<JSONObject> all(Context ctx) {
            if (mem == null) {
                mem = new ArrayList<>();
                try {
                    JSONArray a = new JSONArray(Prefs.getStr(ctx, "huntconf", "[]"));
                    for (int i = 0; i < a.length(); i++) mem.add(a.getJSONObject(i));
                } catch (Exception ignored) {
                }
            }
            return new ArrayList<>(mem);
        }

        static synchronized void save(Context ctx) {
            JSONArray a = new JSONArray();
            for (int i = 0; i < mem.size() && i < 120; i++) a.put(mem.get(i));
            Prefs.putStr(ctx, "huntconf", a.toString());
        }

        public static synchronized JSONObject find(Context ctx, String id) {
            for (JSONObject o : all(ctx)) if (id.equals(o.optString("id"))) return o;
            return null;
        }

        /** Coins still being checked (seen < 3 or not yet 10 min), newest activity first. */
        public static List<Object[]> watching() {
            List<Object[]> l = new ArrayList<>();
            long now = System.currentTimeMillis();
            for (Watch w : WATCH.values()) if (w.last != null && now - w.last.at < 20 * 60_000L) l.add(new Object[]{w.last, w.seen, w.first, w.sum / Math.max(1, w.seen), w.note, w.vcSum / Math.max(1, w.seen)});
            Collections.sort(l, (a, b) -> Double.compare((Double) b[3], (Double) a[3]));
            return l;
        }

        static boolean openFor(String sym) {
            if (mem == null) return false;
            for (JSONObject o : mem) if (sym.equals(o.optString("sym")) && "open".equals(o.optString("st"))) return true;
            return false;
        }

        static synchronized void update(Context ctx, Result r, Listener ls) {
            all(ctx);
            long now = System.currentTimeMillis();
            List<Pick> l = new ArrayList<>(r.pumps);
            l.addAll(r.dumps);
            for (Pick p : l) {
                if (p.score < 50 || !"Binance".equals(p.venue)) continue;
                Watch w = WATCH.get(p.key());
                if (w == null || now - w.last.at > 20 * 60_000L) {
                    w = new Watch();
                    w.first = now;
                    w.firstPrice = p.price;
                    w.firstStage = p.stage;
                    WATCH.put(p.key(), w);
                }
                w.seen++;
                w.sum += p.score;
                w.vcSum += p.volConf;
                w.last = p;
                // the move went the wrong way while we were watching -> the idea is dead
                if (p.pump ? p.price < w.firstPrice * 0.975 : p.price > w.firstPrice * 1.025) { WATCH.remove(p.key()); continue; }
                double avg = w.sum / w.seen, vc = w.vcSum / w.seen;
                int vcMin = Prefs.huntVolConf(ctx);
                // fast lane: very strong volume (vcMin + 10) needs 2 scans / 5 min; normal: 3 scans / 10 min
                boolean fast = vc >= Math.min(95, vcMin + 10) && w.seen >= 2 && now - w.first >= 5 * 60_000L;
                if (!fast && (w.seen < 3 || now - w.first < 10 * 60_000L)) { w.note = "⏳ " + w.seen + "/3 scan · " + Math.max(0, 10 - (now - w.first) / 60_000L) + " min aur jaanch"; continue; }
                if (vc < vcMin) { w.note = String.format(Locale.US, "Volume confirmation %.0f%% — %d%% chahiye", vc, vcMin); continue; }
                if (avg < 55) { w.note = String.format(Locale.US, "Ausat score %.0f — 55 chahiye", avg); continue; }
                if ("LATE".equals(w.firstStage)) { w.note = "Pehli dafa hi LATE tha — chhod diya"; continue; }
                if (p.vol24 < 2_000_000) { w.note = "24h volume $2M se kam — patla coin"; continue; }
                if (openFor(p.sym)) { w.note = "Pehle se pure hunt open hai"; continue; }
                if (now - Prefs.getLong(ctx, "pure_" + p.key()) < 24 * 3600_000L) { w.note = "24 ghante mein pehle confirm ho chuka"; continue; }
                if (now - Prefs.getLong(ctx, "pureTry_" + p.key()) < 15 * 60_000L) continue;   // research failed recently
                Prefs.putLong(ctx, "pureTry_" + p.key(), now);
                if (ls != null) try { ls.stage("🧪 " + p.base + ": research — fundamentals, unlocks, events, news, plan, probability...", 5, 6); } catch (Exception ignored) { }
                JSONObject o = research(ctx, p, w, avg);
                if (o == null) continue;
                mem.add(0, o);
                save(ctx);
                Prefs.putLong(ctx, "pure_" + p.key(), now);
                WATCH.remove(p.key());
                notifyPure(ctx, o);
            }
            for (Map.Entry<String, Watch> e : new ArrayList<>(WATCH.entrySet())) if (now - e.getValue().last.at > 25 * 60_000L) WATCH.remove(e.getKey());
        }

        /** Full research + plan. Returns the pure hunt, or null (with the reason in the watch note). */
        static JSONObject research(Context ctx, Pick p, Watch w, double avg) {
            try {
                Candles h4 = Candles.fetch(p.sym, "4h", 300, false), d1 = Candles.fetch(p.sym, "1d", 400, false);
                double price = h4.close[h4.n - 1];
                Levels.Structure s = Levels.plan(h4, d1, price, p.pump, 1.5);
                if (!s.ok) { w.note = String.format(Locale.US, "Plan kamzor: reward sirf %.1fx risk (resistance qareeb)", s.rr); return null; }
                CoinIntel.Intel in = CoinIntel.get(ctx, p.base);
                if (p.pump && in.blocker) { w.note = "⛔ Bara unlock / delisting aage — buy hunt cancel"; return null; }
                double slPct = Math.abs(price - s.sl) / price * 100;
                double[] tps = {s.tp1, s.tp2, s.tp3};
                double[][] pr = new double[3][];
                for (int i = 0; i < 3; i++) pr[i] = Levels.hitRate(d1, slPct, Math.abs(tps[i] - price) / price * 100, 10, p.pump, false);
                double[] spike = Levels.hitRate(d1, slPct, Math.abs(tps[0] - price) / price * 100, 10, p.pump, true);
                double p1 = spike[1] >= 8 ? (pr[0][0] + spike[0]) / 2 : pr[0][0];
                // daily golden / death cross regime (EMA50 vs EMA200) — big multi-day moves usually go WITH it
                int cross = 0;
                String crossTxt = "";
                if (d1.n >= 210) {
                    double[] e50 = Indicators.ema(d1.close, 50), e200 = Indicators.ema(d1.close, 200);
                    int li = d1.n - 1;
                    boolean golden = e50[li] > e200[li], above = d1.close[li] > e200[li];
                    if (p.pump) cross = golden && above ? 5 : !golden && !above ? -8 : 0;
                    else cross = !golden && !above ? 5 : golden && above ? -8 : 0;
                    crossTxt = (golden ? "✨ Daily golden cross (EMA50 > EMA200)" : "☠️ Daily death cross (EMA50 < EMA200)") + ", price EMA200 ke " + (above ? "upar" : "neeche")
                            + (cross > 0 ? " — move ke haq mein" : cross < 0 ? " — move ke khilaf (ehtiyat)" : "");
                }
                int fin = (int) Math.round(Math.max(0, Math.min(100, avg + in.bias / 2.0 + (p1 - 40) / 3 + cross)));
                if (fin < 60) { w.note = "Research ke baad score " + fin + " — 60 chahiye (" + in.potential + ")"; return null; }
                double atr = s.atr;
                double elo, ehi;
                if (p.pump) { ehi = price * 1.003; elo = Math.max(s.support + atr * 0.25, price - atr * 0.6); if (elo >= ehi) elo = price * 0.99; }
                else { elo = price * 0.997; ehi = Math.min(s.resistance - atr * 0.25, price + atr * 0.6); if (ehi <= elo) ehi = price * 1.01; }
                JSONObject o = new JSONObject();
                o.put("id", p.key() + ":" + System.currentTimeMillis());
                o.put("key", p.key()); o.put("sym", p.sym); o.put("base", p.base); o.put("pump", p.pump); o.put("score", fin); o.put("raw", (int) Math.round(avg));
                o.put("feat", p.feat); o.put("t", w.first); o.put("ct", System.currentTimeMillis()); o.put("p", price); o.put("p0", w.firstPrice);
                o.put("elo", elo); o.put("ehi", ehi); o.put("sl", s.sl); o.put("tp1", s.tp1); o.put("tp2", s.tp2); o.put("tp3", s.tp3);
                o.put("sup", s.support); o.put("res", s.resistance); o.put("rr", s.rr); o.put("atr", atr);
                o.put("pr1", pr[0][0]); o.put("pr2", pr[1][0]); o.put("pr3", pr[2][0]); o.put("prn", pr[0][1]); o.put("prd", pr[0][2]);
                o.put("sp1", spike[0]); o.put("spn", spike[1]);
                o.put("seen", w.seen); o.put("st", "open"); o.put("hit", 0); o.put("best", 0);
                o.put("why", CoinIntel.arr(p.why)); o.put("src", CoinIntel.arr(p.src));
                o.put("info", CoinIntel.arr(CoinIntel.lines(in))); o.put("intel", in.toJson());
                o.put("plan", s.why);
                if (!crossTxt.isEmpty()) { JSONArray inf = o.optJSONArray("info"); if (inf != null) inf.put("📉 " + crossTxt); }
                return o;
            } catch (Exception e) {
                w.note = "Research data load nahi hua — agle scan mein dobara";
                return null;
            }
        }

        static void notifyPure(Context ctx, JSONObject o) {
            if (o.optInt("score") < Prefs.huntMinScore(ctx)) return;
            boolean up = o.optBoolean("pump");
            String title = (up ? "🏆 PURE HUNT BUY: " : "🏆 PURE HUNT SELL: ") + o.optString("base") + " · " + o.optInt("score") + "/100";
            String b = "🕒 " + when(o.optLong("ct")) + " · " + o.optInt("seen") + " scans + research se confirm\n"
                    + (up ? "Buy zone" : "Sell zone") + " $" + Fmt.price(o.optDouble("elo")) + " – $" + Fmt.price(o.optDouble("ehi"))
                    + "\n🛑 SL $" + Fmt.price(o.optDouble("sl")) + " · 🎯 TP1 $" + Fmt.price(o.optDouble("tp1")) + String.format(Locale.US, " (%.0f%% · 10 din)", o.optDouble("pr1"))
                    + " · TP2 $" + Fmt.price(o.optDouble("tp2")) + " · TP3 $" + Fmt.price(o.optDouble("tp3"))
                    + "\nTap: poori research — use case, unlocks, events, news, probability";
            Notify.showHunt(ctx, o.optString("id").hashCode(), title, b, up ? 0xFF0ECB81 : 0xFFF6465D, "pure:" + o.optString("id"));
        }

        /** Replays 1h candles since confirmation: TP1/2/3 hits, stop (moved to entry after TP1), 10-day expiry. */
        public static synchronized void resolve(Context ctx) {
            all(ctx);
            if (System.currentTimeMillis() - Prefs.getLong(ctx, "pureres") < 5 * 60_000L) return;
            Prefs.putLong(ctx, "pureres", System.currentTimeMillis());
            boolean ch = false;
            int done = 0;
            long now = System.currentTimeMillis();
            for (JSONObject o : mem) {
                if (!"open".equals(o.optString("st")) || done >= 12) continue;
                done++;
                try {
                    Candles c = Candles.parse(Scanner.get("/api/v3/klines?symbol=" + o.optString("sym") + "&interval=1h&startTime=" + o.optLong("ct") + "&limit=240"), false);
                    boolean up = o.optBoolean("pump");
                    double e = o.optDouble("p"), sl = o.optDouble("sl");
                    double[] tp = {o.optDouble("tp1"), o.optDouble("tp2"), o.optDouble("tp3")};
                    int hit = 0;
                    String st = "open";
                    double best = 0, exit = 0;
                    for (int k = 0; k < c.n; k++) {
                        double stop = hit >= 1 ? e : sl;   // after TP1 the stop moves to entry (profit protected)
                        boolean stopped = up ? c.low[k] <= stop : c.high[k] >= stop;
                        if (stopped) { st = hit >= 1 ? "tp" + hit : "sl"; exit = stop; break; }
                        best = Math.max(best, up ? (c.high[k] / e - 1) * 100 : (1 - c.low[k] / e) * 100);
                        while (hit < 3 && (up ? c.high[k] >= tp[hit] : c.low[k] <= tp[hit])) hit++;
                        if (hit == 3) { st = "tp3"; exit = tp[2]; break; }
                    }
                    if ("open".equals(st) && now - o.optLong("ct") > 10 * 86_400_000L) { st = hit >= 1 ? "tp" + hit : "exp"; exit = c.n > 0 ? c.close[c.n - 1] : e; }
                    int oldHit = o.optInt("hit");
                    String oldSt = o.optString("st");
                    o.put("hit", hit);
                    o.put("best", best);
                    if (!"open".equals(st)) { o.put("st", st); o.put("exit", exit); o.put("pnl", up ? (exit / e - 1) * 100 : (1 - exit / e) * 100); o.put("et", now); }
                    if (hit > oldHit || !st.equals(oldSt)) {
                        ch = true;
                        String b = o.optString("base");
                        String msg = hit > oldHit ? "🎯 TP" + hit + " hit: " + b + " $" + Fmt.price(tp[hit - 1]) + " — resistance toot gayi" + (hit == 1 ? ", stop ab entry par" : "")
                                : "sl".equals(st) ? "🛑 Stop loss: " + b + " support ke neeche $" + Fmt.price(sl) : "⌛ " + b + " pure hunt band (10 din)";
                        Notify.showHunt(ctx, (o.optString("id") + st + hit).hashCode(), msg, String.format(Locale.US, "Entry $%s · ab tak sab se zyada %+.1f%%", Fmt.price(e), best),
                                hit > oldHit ? 0xFF0ECB81 : 0xFFF6465D, "pure:" + o.optString("id"));
                    }
                } catch (Exception ignored) {
                }
            }
            if (ch) save(ctx);
        }
    }
}
