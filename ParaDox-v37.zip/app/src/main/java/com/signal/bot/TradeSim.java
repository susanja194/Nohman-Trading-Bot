package com.signal.bot;

import java.util.List;
import java.util.Locale;

/**
 * Trade execution model shared by the BACKTEST and the PAPER (forward) trader — candle by candle:
 *  • limit entry at `entry`, valid `expiry` candles; cancelled if TP1 is reached before a fill (missed move)
 *  • stop and target touched in the SAME candle → the STOP is assumed first (conservative)
 *  • 1/3 closed at TP1 (stop → break-even), 1/3 at TP2 (stop → TP1, trailing), last 1/3 at TP3; max hold `maxHold` candles
 *  • costs: fee per side, slippage on every stop / time exit, futures funding per 8 h held
 * Result in R (risk units) net of all costs.
 */
public final class TradeSim {

    public static final class Costs {
        public double fee = 0.0005, slip = 0.0005, fundingPer8h = 0.0001;
        public boolean futures = true;
        public Costs() {}
        public static Costs spot() { Costs c = new Costs(); c.fee = 0.001; c.fundingPer8h = 0; c.futures = false; return c; }
    }

    public String status = "pending";   // pending, open, closed, expired, missed
    public boolean isLong;
    public double entry, sl, tp1, tp2, tp3, stop;
    public int expiry, maxHold, waited, held, hits;
    public double left = 1.0, realized;   // realized = Σ portion × return (fraction of price), before costs
    public double costs;                  // total costs as a fraction of price × size
    public long fillT, exitT;
    public double exitPx, best;           // best favourable excursion (in R)
    public String exitWhy = "";
    final long candleMs;
    final Costs cs;

    public TradeSim(boolean isLong, double entry, double sl, double tp1, double tp2, double tp3, int expiry, int maxHold, long candleMs, Costs cs) {
        this.isLong = isLong; this.entry = entry; this.sl = sl; this.tp1 = tp1; this.tp2 = tp2; this.tp3 = tp3;
        this.expiry = expiry; this.maxHold = maxHold; this.candleMs = candleMs; this.cs = cs;
        this.stop = sl;
    }

    double ret(double px) { return isLong ? (px - entry) / entry : (entry - px) / entry; }

    double risk() { return Math.abs(entry - sl) / entry; }

    /** Net result in R (only meaningful once closed; for an open trade this is the realized part). */
    public double resultR() { return risk() > 0 ? (realized - costs) / risk() : 0; }

    /** Unrealized R at price `px` for the part still open (after costs paid so far). */
    public double openR(double px) { return risk() > 0 ? (realized + left * ret(px) - costs - (cs.fee + cs.slip) * left) / risk() : 0; }

    void close(double portion, double px, boolean market, long t) {
        realized += portion * ret(px);
        costs += portion * (cs.fee + (market ? cs.slip : 0));
        left -= portion;
        if (left <= 1e-9) { left = 0; status = "closed"; exitT = t; exitPx = px; }
    }

    /** Feeds one CLOSED candle. */
    public void step(long t, double o, double h, double l, double c) {
        if (status.equals("closed") || status.equals("expired") || status.equals("missed")) return;
        if (status.equals("pending")) {
            boolean filled = isLong ? l <= entry : h >= entry;
            boolean ranAway = isLong ? h >= tp1 : l <= tp1;
            if (!filled) {
                if (ranAway) { status = "missed"; exitWhy = "TP1 entry se pehle aa gaya — fill nahi hua"; return; }
                if (++waited >= expiry) { status = "expired"; exitWhy = "entry " + expiry + " candles mein fill nahi hui"; }
                return;
            }
            status = "open";
            fillT = t;
            costs += cs.fee;   // entry fee (limit)
            // the fill candle can also hit the stop (conservative: yes if its low/high touches it)
            if (isLong ? l <= stop : h >= stop) { close(left, stop, true, t); exitWhy = "stop (fill wali candle)"; return; }
            return;   // targets only from the next candle on (we cannot know the order inside the fill candle)
        }
        held++;
        if (cs.futures) costs += cs.fundingPer8h * left * (candleMs / (8 * 3600_000.0));
        best = Math.max(best, ret(isLong ? h : l) / risk());
        // stop first (conservative when both are inside the same candle)
        if (isLong ? l <= stop : h >= stop) {
            close(left, stop, true, t);
            exitWhy = hits == 0 ? "stop loss" : hits == 1 ? "break-even stop (TP1 ke baad)" : "trailing stop (TP2 ke baad)";
            return;
        }
        double[] tp = {tp1, tp2, tp3};
        while (hits < 3 && (isLong ? h >= tp[hits] : l <= tp[hits])) {
            double portion = hits < 2 ? 1.0 / 3 : left;
            close(Math.min(portion, left), tp[hits], false, t);
            hits++;
            if (hits == 1) stop = entry;          // break-even
            else if (hits == 2) stop = tp1;       // trail
            if (status.equals("closed")) { exitWhy = "TP3"; return; }
        }
        if (held >= maxHold) { close(left, c, true, t); exitWhy = "time exit (" + maxHold + " candles)"; }
    }

    public String label() {
        switch (status) {
            case "pending": return "⏳ entry ka intezar";
            case "open": return hits > 0 ? "🎯 TP" + hits + " · chal raha" : "🟢 open";
            case "expired": return "⌛ fill nahi";
            case "missed": return "↗️ miss (fill se pehle chala gaya)";
            default: return String.format(Locale.US, "%s %+.2fR · %s", resultR() > 0 ? "✅" : "❌", resultR(), exitWhy);
        }
    }

    // ------------------------------------------------------------------ statistics (same for backtest and paper)
    public static final class Stats {
        public int n, wins, losses, maxWinStreak, maxLossStreak;
        public double winRate, wilsonLo, wilsonHi, profitFactor, expectancyR, netR, maxDdR, netPct, maxDdPct, sharpe, avgPlannedRR, avgWinR, avgLossR;

        public String line() {
            if (n == 0) return "0 trades";
            return String.format(Locale.US, "%d trades · win %.0f%% (95%%: %.0f–%.0f%%) · PF %s · expectancy %+.2fR · net %+.1fR (%+.1f%% @1%% risk) · max DD %.1fR (%.1f%%) · Sharpe %.2f",
                    n, winRate, wilsonLo, wilsonHi, Double.isInfinite(profitFactor) ? "∞" : String.format(Locale.US, "%.2f", profitFactor), expectancyR, netR, netPct, maxDdR, maxDdPct, sharpe);
        }
    }

    /** rs = net R of each closed trade in time order; plannedRR may be null. */
    public static Stats stats(List<Double> rs, List<Double> plannedRR, double riskPct) {
        Stats s = new Stats();
        s.n = rs.size();
        if (s.n == 0) return s;
        double pos = 0, neg = 0, eqR = 0, peakR = 0, eq = 1, peak = 1, sum = 0, sq = 0;
        int ws = 0, ls = 0;
        for (double r : rs) {
            if (r > 0) { s.wins++; pos += r; ws++; ls = 0; } else { s.losses++; neg += -r; ls++; ws = 0; }
            s.maxWinStreak = Math.max(s.maxWinStreak, ws);
            s.maxLossStreak = Math.max(s.maxLossStreak, ls);
            eqR += r;
            peakR = Math.max(peakR, eqR);
            s.maxDdR = Math.max(s.maxDdR, peakR - eqR);
            eq *= 1 + r * riskPct / 100;
            peak = Math.max(peak, eq);
            s.maxDdPct = Math.max(s.maxDdPct, (peak - eq) / peak * 100);
            sum += r;
            sq += r * r;
        }
        s.netR = eqR;
        s.netPct = (eq - 1) * 100;
        s.winRate = s.wins * 100.0 / s.n;
        double z = 1.96, p = s.wins / (double) s.n, d = 1 + z * z / s.n;
        double centre = (p + z * z / (2 * s.n)) / d, half = z * Math.sqrt(p * (1 - p) / s.n + z * z / (4.0 * s.n * s.n)) / d;
        s.wilsonLo = Math.max(0, (centre - half) * 100);
        s.wilsonHi = Math.min(100, (centre + half) * 100);
        s.profitFactor = neg > 0 ? pos / neg : (pos > 0 ? Double.POSITIVE_INFINITY : 0);
        s.expectancyR = sum / s.n;
        double var = s.n > 1 ? (sq - sum * sum / s.n) / (s.n - 1) : 0;
        s.sharpe = var > 0 ? s.expectancyR / Math.sqrt(var) * Math.sqrt(s.n) : 0;   // per-trade Sharpe × √N (t-stat style)
        s.avgWinR = s.wins > 0 ? pos / s.wins : 0;
        s.avgLossR = s.losses > 0 ? -neg / s.losses : 0;
        if (plannedRR != null && !plannedRR.isEmpty()) { double a = 0; for (double v : plannedRR) a += v; s.avgPlannedRR = a / plannedRR.size(); }
        return s;
    }
}
