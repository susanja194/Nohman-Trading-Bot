package com.signal.bot;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * SMC Pro signal engine — ONE deterministic function used by the live scanner, the backtest and the paper trader,
 * so what is tested is exactly what runs live.
 *
 * Timeframes are relative to the entry timeframe E (only CLOSED candles, higher timeframes built from E so a higher
 * candle is used only after it has fully closed — no look-ahead):
 *   E = 1h  → bias 4h (×4) and 1D (×24) · entry / confirmation 1h
 *   E = 15m → bias 1h (×4) and 4h (×16) · entry / confirmation 15m
 *
 * LONG (SHORT is the mirror):
 *   1. Bias: 4h structure bullish and 1D not bearish (conflict = NO TRADE)
 *   2. Liquidity: sell-side liquidity swept (stop hunt below a swing low) OR a higher-timeframe bullish OB/FVG tapped, last 20 candles
 *   3. Confirmation: bullish CHoCH / MSS / BOS on E AFTER that sweep / tap (last 12 candles)
 *   4. Entry: a fresh bullish order block / FVG / breaker created by that move, at or below price
 *   5. Stop: below the swept low / zone low (− 0.15 ATR) · Targets: the next buy-side liquidity pools (swing highs, equal highs, 4h highs)
 *   6. Weighted confidence (0–100) + minimum reward:risk — otherwise NO TRADE with the reason.
 * The confidence score is a quality score, NOT a win probability (win rates come only from the backtest / paper results).
 */
public final class SmcEngine {
    private SmcEngine() {}

    public static final class Params {
        public int minScore = 70;
        public double minRR = 2.0;     // reward:risk measured at TP2
        public int expiry = 6;         // candles a limit entry stays valid
        public Params() {}
        public Params(int s, double rr) { minScore = s; minRR = rr; }
    }

    public static final class Setup {
        public boolean ok, isLong;
        public String noTrade = "";
        public int end, score, bias, bias2;
        public long t;
        public double entry, zoneLo, zoneHi, sl, tp1, tp2, tp3, rr1, rr2, atr, close;
        public String zoneType = "", confType = "", liqType = "", regime = "", vol = "";
        public int[] parts = new int[8];   // MTF, structure, liquidity, OB/FVG, volume, momentum, regime(P/D), RR
        public final List<String> why = new ArrayList<>();
    }

    public static final String[] PART_NAMES = {"Multi-timeframe", "Market structure", "Liquidity sweep", "OB / FVG", "Volume / order flow", "Momentum", "Premium / discount", "Reward : risk"};
    public static final int[] PART_MAX = {20, 15, 15, 15, 10, 10, 5, 10};

    public static final class Ctx {
        public Candles base, h1, h2;
        public int[] l1, l2;
        public double[] rsi, ema20, ema50h1, ema50h2, atrPct;
        public String tf;
        int cI1 = -1, cI2 = -1;            // cache: higher-timeframe analysis only changes when a new higher candle closes
        Smc.Result cR1, cR2;
    }

    public static Ctx prepare(Candles base, String tf) {
        long ms = tf.equals("15m") ? 15 * 60_000L : tf.equals("5m") ? 5 * 60_000L : 3600_000L;
        int f1 = 4, f2 = tf.equals("1h") ? 24 : 16;
        Ctx x = new Ctx();
        x.tf = tf;
        x.base = base;
        int[][] o1 = new int[1][], o2 = new int[1][];
        x.h1 = Smc.aggregate(base, f1, ms, o1);
        x.h2 = Smc.aggregate(base, f2, ms, o2);
        x.l1 = o1[0];
        x.l2 = o2[0];
        x.rsi = Indicators.rsi(base.close, 14);
        x.ema20 = Indicators.ema(base.close, 20);
        x.ema50h1 = x.h1.n > 0 ? Indicators.ema(x.h1.close, 50) : new double[0];
        x.ema50h2 = x.h2.n > 0 ? Indicators.ema(x.h2.close, 50) : new double[0];
        // rolling ATR% (14) for the volatility regime — uses data up to each index only
        x.atrPct = new double[base.n];
        double s = 0;
        for (int i = 1; i < base.n; i++) {
            double tr = Math.max(base.high[i] - base.low[i], Math.max(Math.abs(base.high[i] - base.close[i - 1]), Math.abs(base.low[i] - base.close[i - 1])));
            s += tr;
            if (i > 14) s -= Math.max(base.high[i - 14] - base.low[i - 14], Math.max(Math.abs(base.high[i - 14] - base.close[i - 15]), Math.abs(base.low[i - 14] - base.close[i - 15])));
            x.atrPct[i] = base.close[i] > 0 ? s / Math.min(i, 14) / base.close[i] * 100 : 0;
        }
        return x;
    }

    /** Number of fully closed higher-timeframe candles available at base index `end`. */
    static int closedUpTo(int[] last, int end) {
        int lo = 0, hi = last.length - 1, ans = -1;
        while (lo <= hi) { int m = (lo + hi) >>> 1; if (last[m] <= end) { ans = m; lo = m + 1; } else hi = m - 1; }
        return ans;
    }

    /** Market regime at `end` (for reporting): trend from the higher-higher timeframe EMA50 slope, volatility from ATR% vs its median. */
    public static String regime(Ctx x, int end) {
        int i2 = closedUpTo(x.l2, end);
        String tr = "sideways";
        if (i2 >= 55) {
            double e = x.ema50h2[i2], e5 = x.ema50h2[i2 - 5], c = x.h2.close[i2];
            double slope = (e / e5 - 1) * 100;
            if (c > e && slope > 0.5) tr = "bull"; else if (c < e && slope < -0.5) tr = "bear";
        }
        int from = Math.max(1, end - 500);
        double[] w = new double[end - from + 1];
        for (int i = from; i <= end; i++) w[i - from] = x.atrPct[i];
        java.util.Arrays.sort(w);
        double med = w[w.length / 2];
        return tr + (x.atrPct[end] > med * 1.3 ? "/high-vol" : x.atrPct[end] < med * 0.75 ? "/low-vol" : "/normal-vol");
    }

    public static Setup evaluate(Ctx x, int end, Params p) {
        Setup s = new Setup();
        s.end = end;
        s.t = x.base.time[end];
        s.close = x.base.close[end];
        int i1 = closedUpTo(x.l1, end), i2 = closedUpTo(x.l2, end);
        if (i1 < 40 || end < 120) { s.noTrade = "Data kam (higher timeframe history)"; return s; }
        if (x.cI1 != i1) { x.cR1 = Smc.analyze(x.h1, i1, 150); x.cI1 = i1; }
        if (x.cI2 != i2) { x.cR2 = i2 >= 20 ? Smc.analyze(x.h2, i2, 120) : null; x.cI2 = i2; }
        Smc.Result r1 = x.cR1, r2 = x.cR2;
        s.bias = r1.trend;
        s.bias2 = r2 == null ? 0 : r2.trend;
        if (s.bias == 0) { s.noTrade = "Higher timeframe (" + htfName(x.tf, 1) + ") ka structure saaf nahi"; return s; }
        if (s.bias2 == -s.bias) { s.noTrade = "Timeframes takra rahe hain: " + htfName(x.tf, 1) + " " + dir(s.bias) + " magar " + htfName(x.tf, 2) + " " + dir(s.bias2); return s; }
        boolean L = s.bias > 0;
        s.isLong = L;
        Smc.Result r = Smc.analyze(x.base, end, 160);
        s.atr = r.atr;
        double atr = r.atr;
        if (atr <= 0) { s.noTrade = "ATR nahi"; return s; }
        Candles c = x.base;

        // ---- 2. liquidity: sweep on E, or a tap of a higher-timeframe zone
        Smc.Event sweep = null;
        for (int k = r.events.size() - 1; k >= 0; k--) {
            Smc.Event e = r.events.get(k);
            if (e.i < end - 20) break;
            if (e.type.equals("SWEEP") && e.bull == L) { sweep = e; break; }
        }
        int tapIdx = -1;
        Smc.Zone htfZone = null;
        for (Smc.Zone z : r1.zones) {
            if (z.bull != L || z.invalid || !(z.type.equals("OB") || z.type.equals("FVG") || z.type.equals("BREAKER"))) continue;
            for (int k = Math.max(r.start, end - 20); k <= end; k++) {
                if (L ? c.low[k] <= z.hi && c.close[k] >= z.lo : c.high[k] >= z.lo && c.close[k] <= z.hi) { tapIdx = Math.max(tapIdx, k); htfZone = z; }
            }
        }
        if (sweep == null && tapIdx < 0) { s.noTrade = (L ? "Sell-side" : "Buy-side") + " liquidity sweep / higher-timeframe zone ka tap nahi (pichle 20 candles)"; return s; }
        int ref = sweep != null ? sweep.i : tapIdx;
        if (sweep != null && tapIdx > ref) ref = Math.min(ref, tapIdx);
        s.liqType = sweep != null ? (L ? "SSL sweep" : "BSL sweep") + (htfZone != null ? " + " + htfName(x.tf, 1) + " " + htfZone.type + " tap" : "") : htfName(x.tf, 1) + " " + htfZone.type + " tap";

        // ---- 3. confirmation: structure break in our direction after the sweep / tap
        Smc.Event conf = null;
        for (Smc.Event e : r.events) {
            if (e.i <= ref || e.i < end - 12 || e.bull != L) continue;
            if (e.type.equals("CHOCH") || e.type.equals("MSS") || e.type.equals("BOS")) conf = e;
        }
        if (conf == null) { s.noTrade = s.liqType + " hua magar us ke baad " + (L ? "bullish" : "bearish") + " CHoCH / BOS confirm nahi"; return s; }
        s.confType = conf.type;

        // ---- 4. entry zone: fresh OB / FVG / breaker made by this move, on the right side of price
        Smc.Zone best = null;
        for (Smc.Zone z : r.zones) {
            if (z.bull != L || z.invalid || z.i < ref - 3) continue;
            if (!(z.type.equals("OB") || z.type.equals("FVG") || z.type.equals("BREAKER") || z.type.equals("IFVG"))) continue;
            if (L ? z.lo > s.close + 0.1 * atr : z.hi < s.close - 0.1 * atr) continue;
            if (best == null || (L ? z.hi > best.hi : z.lo < best.lo)) best = z;
        }
        if (best == null) { s.noTrade = conf.type + " confirm hua magar entry ke liye fresh order block / FVG nahi bana"; return s; }
        s.zoneType = best.type;
        s.zoneLo = best.lo;
        s.zoneHi = best.hi;
        boolean overlap = false;
        for (Smc.Zone z : r.zones) if (z != best && z.bull == L && !z.invalid && z.lo < best.hi && z.hi > best.lo && !z.type.equals(best.type)) overlap = true;
        double edge = L ? (best.hi + best.mid()) / 2 : (best.lo + best.mid()) / 2;
        s.entry = L ? Math.min(s.close, edge) : Math.max(s.close, edge);

        // ---- 5. stop and targets from liquidity
        double extreme = sweep != null ? (L ? c.low[sweep.i] : c.high[sweep.i]) : (L ? best.lo : best.hi);
        s.sl = L ? Math.min(extreme, best.lo) - 0.15 * atr : Math.max(extreme, best.hi) + 0.15 * atr;
        double R = Math.abs(s.entry - s.sl);
        if (R < 0.3 * atr) { s.sl = L ? s.entry - 0.3 * atr : s.entry + 0.3 * atr; R = 0.3 * atr; }
        if (R > 4 * atr) { s.noTrade = "Stop bohat door (" + String.format(Locale.US, "%.1f", R / atr) + " ATR) — risk zyada"; return s; }
        List<Double> liq = new ArrayList<>();
        for (Smc.Swing w : r.liquidity(L, s.entry)) liq.add(w.p);
        for (double[] e : L ? r.eqh : r.eql) if (L ? e[0] > s.entry : e[0] < s.entry) liq.add(e[0]);
        for (Smc.Swing w : r1.liquidity(L, s.entry)) liq.add(w.p);
        liq.sort((a, b) -> L ? Double.compare(a, b) : Double.compare(b, a));
        List<Double> tps = new ArrayList<>();
        for (double v : liq) {
            double d = L ? v - s.entry : s.entry - v;
            if (d < R) continue;   // TP1 at least 1R
            if (!tps.isEmpty() && Math.abs(v - tps.get(tps.size() - 1)) < 0.5 * R) continue;
            tps.add(v);
            if (tps.size() == 3) break;
        }
        boolean rTarget = tps.size() < 3;
        while (tps.size() < 3) {
            double lastD = tps.isEmpty() ? 0 : Math.abs(tps.get(tps.size() - 1) - s.entry);
            double d = Math.max(lastD + R, (tps.size() + 1) * 1.5 * R);
            tps.add(L ? s.entry + d : s.entry - d);
        }
        s.tp1 = tps.get(0);
        s.tp2 = tps.get(1);
        s.tp3 = tps.get(2);
        s.rr1 = Math.abs(s.tp1 - s.entry) / R;
        s.rr2 = Math.abs(s.tp2 - s.entry) / R;

        // ---- 6. weighted confidence
        int[] pt = s.parts;
        pt[0] = 10 + (s.bias2 == s.bias ? 6 : 3);
        if (i1 >= 50 && x.ema50h1.length > i1 && (L ? x.h1.close[i1] > x.ema50h1[i1] : x.h1.close[i1] < x.ema50h1[i1])) pt[0] += 4;
        pt[1] = conf.type.equals("MSS") ? 15 : conf.type.equals("CHOCH") ? 12 : 9;
        int lq = sweep != null ? 10 : 0;
        if (sweep != null) for (double[] e : L ? r.eql : r.eqh) if (Math.abs(e[0] - sweep.level) < 0.2 * atr) lq += 3;
        if (htfZone != null) lq += 5;
        pt[2] = Math.min(15, lq);
        pt[3] = Math.min(15, (best.type.equals("OB") ? 8 : best.type.equals("BREAKER") ? 7 : 6) + (overlap ? 4 : 0) + (!best.mitigated ? 3 : 0));
        double avgQ = 0;
        for (int k = Math.max(0, end - 24); k < end - 3; k++) avgQ += c.quoteVol[k];
        avgQ /= Math.max(1, Math.min(end, 21));
        double maxQ = 0;
        for (int k = ref; k <= end; k++) maxQ = Math.max(maxQ, c.quoteVol[k]);
        double rv = avgQ > 0 ? maxQ / avgQ : 0;
        int vp = rv >= 1.5 ? 6 : rv >= 1.2 ? 3 : 0;
        double tb = 0, tq = 0;
        for (int k = end - 2; k <= end; k++) { tb += c.takerBuyQuote[k]; tq += c.quoteVol[k]; }
        double share = tq > 0 && tb > 0 ? tb / tq : 0.5;
        if (L ? share >= 0.52 : share <= 0.48) vp += 4;
        pt[4] = vp;
        s.vol = String.format(Locale.US, "move par volume %.1fx ausat%s", rv, tb > 0 ? String.format(Locale.US, " · aggressive %s %.0f%%", L ? "buyers" : "sellers", (L ? share : 1 - share) * 100) : "");
        double rsi = x.rsi[end];
        pt[5] = (L ? rsi >= 45 && rsi <= 70 : rsi <= 55 && rsi >= 30) ? 5 : 0;
        if (L ? c.close[end] > x.ema20[end] : c.close[end] < x.ema20[end]) pt[5] += 5;
        double pos = r.rangePos();
        pt[6] = L ? (pos < 0.5 ? 5 : pos < 0.62 ? 3 : 0) : (pos > 0.5 ? 5 : pos > 0.38 ? 3 : 0);
        pt[7] = s.rr2 >= 3 ? 10 : s.rr2 >= 2.5 ? 8 : s.rr2 >= 2 ? 6 : s.rr2 >= 1.5 ? 3 : 0;
        int sc = 0;
        for (int v : pt) sc += v;
        s.score = sc;
        s.regime = regime(x, end);

        // ---- explanation
        s.why.add("🧭 Bias: " + htfName(x.tf, 1) + " " + dir(s.bias) + " · " + htfName(x.tf, 2) + " " + (s.bias2 == 0 ? "neutral" : dir(s.bias2)) + " (koi takrao nahi)");
        s.why.add("💧 Liquidity: " + s.liqType + (sweep != null ? " @ " + Fmt.price(sweep.level) + " (" + (end - sweep.i) + " candles pehle)" : ""));
        s.why.add("🏗️ Structure: " + (L ? "bullish " : "bearish ") + conf.type + " @ " + Fmt.price(conf.level) + " (" + (end - conf.i) + " candles pehle)");
        s.why.add("📦 Entry zone: " + best.type + (overlap ? " + overlapping FVG/OB" : "") + (best.mitigated ? " (pehle chhua gaya)" : " (fresh)") + " $" + Fmt.price(best.lo) + " – $" + Fmt.price(best.hi));
        s.why.add("📊 Volume: " + s.vol);
        s.why.add(String.format(Locale.US, "📐 %s zone (range ka %.0f%%) · RSI %.0f · regime %s", pos > 0.5 ? "Premium" : "Discount", pos * 100, rsi, s.regime));
        s.why.add(String.format(Locale.US, "🎯 TP1 %.1fR · TP2 %.1fR · TP3 %.1fR%s", s.rr1, s.rr2, Math.abs(s.tp3 - s.entry) / R, rTarget ? " (kuch targets R-multiple — upar liquidity kam)" : " (liquidity pools)"));

        if (s.rr1 < 1.0) { s.noTrade = "TP1 1R se kam"; return s; }
        if (s.rr2 < p.minRR) { s.noTrade = String.format(Locale.US, "Reward:risk %.1f — minimum %.1f chahiye", s.rr2, p.minRR); return s; }
        if (s.score < p.minScore) { s.noTrade = "Confidence " + s.score + " — minimum " + p.minScore + " chahiye"; return s; }
        s.ok = true;
        return s;
    }

    static String dir(int b) { return b > 0 ? "bullish" : b < 0 ? "bearish" : "neutral"; }

    static String htfName(String tf, int k) {
        if (tf.equals("15m")) return k == 1 ? "1h" : "4h";
        return k == 1 ? "4h" : "1D";
    }
}
