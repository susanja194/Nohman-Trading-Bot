package com.signal.bot;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * LIVE SMC Pro scanner: once per newly CLOSED candle (1h and 15m) it runs the same SmcEngine used by the backtest on the
 * top coins by volume. A valid setup that also passes the risk manager → Signals tab + notification + paper trade.
 * Everything else → NO TRADE with the reason (logged).
 */
public final class SmcScanner {
    private SmcScanner() {}

    public static final Map<String, SmcEngine.Setup> LAST = new ConcurrentHashMap<>();   // "COIN|tf" -> last evaluation
    public static volatile long lastRun;
    public static volatile String status = "";

    public static boolean on(Context c) { return Prefs.getBool(c, "smcOn", true); }

    public static SmcEngine.Params params(Context c) {
        return new SmcEngine.Params(Prefs.getInt(c, "smcMinScore", 70), Prefs.getInt(c, "smcMinRR10", 20) / 10.0);
    }

    static List<String> coins(int n) {
        List<String> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(Scanner.get("/api/v3/ticker/24hr?type=MINI"));
            List<JSONObject> l = new ArrayList<>();
            for (int i = 0; i < a.length(); i++) { JSONObject o = a.getJSONObject(i); if (Scanner.isTradable(o.optString("symbol"))) l.add(o); }
            Collections.sort(l, (x, y) -> Double.compare(y.optDouble("quoteVolume", 0), x.optDouble("quoteVolume", 0)));
            for (int i = 0; i < l.size() && out.size() < n; i++) { String s = l.get(i).optString("symbol"); out.add(s.substring(0, s.length() - 4)); }
        } catch (Exception e) {
            Collections.addAll(out, SmcBacktest.COINS);
        }
        return out;
    }

    /** Called from the background service loop. */
    public static void tick(Context c) {
        if (!on(c)) return;
        long now = System.currentTimeMillis();
        if (now - Prefs.getLong(c, "smcPaperUpd") > 2 * 60_000L) {
            Prefs.putLong(c, "smcPaperUpd", now);
            try { PaperBook.update(c); } catch (Exception ignored) { }
        }
        for (String tf : new String[]{"1h", "15m"}) {
            long ms = tf.equals("1h") ? 3600_000L : 15 * 60_000L;
            long slot = (now - 20_000L) / ms;   // run ~20 s after each candle closes
            if (Prefs.getLong(c, "smcSlot" + tf) == slot) continue;
            Prefs.putLong(c, "smcSlot" + tf, slot);
            scan(c, tf, null);
        }
    }

    public interface Progress { void on(String msg); }

    public static synchronized List<SmcEngine.Setup> scan(Context c, String tf, Progress pg) {
        List<SmcEngine.Setup> found = new ArrayList<>();
        SmcEngine.Params p = params(c);
        List<String> list = coins(Prefs.getInt(c, "smcCoins", 25));
        int i = 0, nt = 0;
        for (String coin : list) {
            i++;
            if (pg != null) pg.on("🧠 " + tf + " · " + coin + " (" + i + "/" + list.size() + ")");
            try {
                Candles k = Candles.fetch(coin + "USDT", tf, 1000, true);
                if (k.n < 400) continue;
                SmcEngine.Ctx x = SmcEngine.prepare(k, tf);
                SmcEngine.Setup s = SmcEngine.evaluate(x, k.n - 1, p);
                LAST.put(coin + "|" + tf, s);
                if (!s.ok) { nt++; if (s.score > 0) PaperBook.reject(c, coin, tf, "NO TRADE · " + s.noTrade); continue; }
                String block = PaperBook.riskCheck(c, coin);
                if (block != null) { PaperBook.reject(c, coin, tf, "🛡️ Risk manager: " + block); continue; }
                found.add(s);
                PaperBook.open(c, coin, tf, s);
                publish(c, coin, tf, s);
            } catch (Exception ignored) {
            }
        }
        lastRun = System.currentTimeMillis();
        status = String.format(Locale.US, "%s scan %s · %d coins · %d setup · %d NO TRADE", tf,
                new java.text.SimpleDateFormat("HH:mm", Locale.US).format(new java.util.Date()), list.size(), found.size(), nt);
        Prefs.putStr(c, "smcStatus" + tf, status);
        return found;
    }

    /** Signals tab + notification (same tracking as the other signals). */
    static void publish(Context c, String coin, String tf, SmcEngine.Setup s) {
        try {
            double R = Math.abs(s.entry - s.sl);
            double riskUsd = PaperBook.account(c) * PaperBook.riskPct(c) / 100;
            double qty = R > 0 ? riskUsd / R : 0;
            JSONObject ex = new JSONObject();
            ex.put("smc", true);
            ex.put("tf", tf);
            ex.put("entry", s.entry);
            ex.put("zlo", s.zoneLo);
            ex.put("zhi", s.zoneHi);
            ex.put("tp2", s.tp2);
            ex.put("tp3", s.tp3);
            ex.put("ntitle", "🧠 SMC PRO " + (s.isLong ? "LONG" : "SHORT") + ": " + coin + "/USDT · " + s.score + "/100");
            StringBuilder w = new StringBuilder();
            w.append(String.format(Locale.US, "🧠 SMC Pro %s · %s · confidence %d/100 (quality score, win %% nahi)\n", s.isLong ? "LONG" : "SHORT", tf, s.score));
            w.append(String.format(Locale.US, "📥 Entry zone $%s – $%s (limit ~$%s) · 🛑 SL $%s\n🎯 TP1 $%s (%.1fR) · TP2 $%s (%.1fR) · TP3 $%s\n",
                    Fmt.price(s.zoneLo), Fmt.price(s.zoneHi), Fmt.price(s.entry), Fmt.price(s.sl), Fmt.price(s.tp1), s.rr1, Fmt.price(s.tp2), s.rr2, Fmt.price(s.tp3)));
            w.append(String.format(Locale.US, "💼 %.1f%% risk ($%.0f of $%.0f) → size ~%s %s (~$%.0f) · TP1 par 1/3 + stop entry par\n",
                    PaperBook.riskPct(c), riskUsd, PaperBook.account(c), Fmt.num(qty), coin, qty * s.entry));
            for (String x : s.why) w.append(x).append('\n');
            w.append("⌛ Entry " + 6 + " candles mein na lage to signal khatam");
            Scanner.alert(c, Mode.SCALP, s.isLong ? "BUY" : "SELL", coin + "USDT", s.entry, s.score, w.toString(), tf, true, s.sl, s.tp1, ex);
        } catch (Exception ignored) {
        }
    }
}
