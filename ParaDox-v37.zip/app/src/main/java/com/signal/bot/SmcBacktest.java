package com.signal.bot;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * HISTORICAL BACKTEST + WALK-FORWARD of the SMC Pro engine, run on the phone on real exchange candles.
 *  • Data: Binance (MEXC backup) 1h ≈ 250 days and 15m ≈ 52 days per coin, oldest → newest
 *  • Every candle is evaluated with ONLY the candles before it (the engine never sees the future); signals act from the NEXT candle
 *  • Execution = TradeSim (limit entry, conservative same-candle rule, partials, BE, trailing, fees, slippage, funding)
 *  • One position per coin at a time (duplicate prevention)
 *  • Walk-forward: parameters (min confidence × min R:R) are chosen on TRAIN (first 60 %), checked on VALIDATION (next 20 %)
 *    and reported ONCE on the untouched TEST (last 20 %). Plus 4 anchored walk-forward folds → out-of-sample total.
 * Results are simulations on past data — not live trading performance.
 */
public final class SmcBacktest {
    private SmcBacktest() {}

    public interface Progress { void on(String msg, int done, int total); }

    public static final String[] COINS = {"BTC", "ETH", "SOL", "BNB", "XRP", "DOGE", "ADA", "LINK", "AVAX", "SUI"};
    static final int[] SCORES = {55, 65, 75, 85};
    static final double[] RRS = {1.5, 2.0, 2.5};

    static final class Cand {
        String coin, tf, regime;
        int end, score;
        long t;
        double rr2;
        SmcEngine.Setup s;
    }

    static final class Trade {
        String coin, tf, regime;
        long t;
        double r, rr;
    }

    /** Pages back through klines (1000 per call) to get `total` candles, oldest first. */
    static Candles history(String sym, String tf, int total) throws Exception {
        List<JSONArray> pages = new ArrayList<>();
        long endTime = 0;
        int got = 0;
        while (got < total) {
            String path = "/api/v3/klines?symbol=" + sym + "&interval=" + tf + "&limit=1000" + (endTime > 0 ? "&endTime=" + endTime : "");
            JSONArray a = new JSONArray(Scanner.get(path));
            if (a.length() == 0) break;
            pages.add(0, a);
            got += a.length();
            endTime = a.getJSONArray(0).getLong(0) - 1;
            if (a.length() < 1000) break;
        }
        JSONArray all = new JSONArray();
        for (JSONArray p : pages) for (int i = 0; i < p.length(); i++) all.put(p.get(i));
        return Candles.parse(all.toString(), true);   // drop the still-open last candle
    }

    public static JSONObject run(Context ctx, TradeSim.Costs costs, Progress pg) throws Exception {
        String[] tfs = {"1h", "15m"};
        int[] totals = {6000, 5000};
        List<Cand> cands = new ArrayList<>();
        Map<String, Candles> data = new HashMap<>();
        Map<String, long[]> span = new HashMap<>();
        int step = 0, steps = COINS.length * tfs.length;
        for (String coin : COINS) {
            for (int ti = 0; ti < tfs.length; ti++) {
                String tf = tfs[ti];
                if (pg != null) pg.on("📥 " + coin + " " + tf + " ka history data...", step, steps);
                Candles c;
                try { c = history(coin + "USDT", tf, totals[ti]); } catch (Exception e) { step++; continue; }
                if (c.n < 800) { step++; continue; }
                data.put(coin + "|" + tf, c);
                span.put(coin + "|" + tf, new long[]{c.time[0], c.time[c.n - 1]});
                SmcEngine.Ctx x = SmcEngine.prepare(c, tf);
                SmcEngine.Params all = new SmcEngine.Params(0, 0);
                if (pg != null) pg.on("🧠 " + coin + " " + tf + ": har candle par engine (bina future data)...", step, steps);
                int warm = tf.equals("1h") ? 24 * 45 : 16 * 45;
                for (int end = warm; end < c.n - 1; end++) {
                    SmcEngine.Setup s = SmcEngine.evaluate(x, end, all);
                    if (s.score <= 0 || s.rr1 < 1.0) continue;   // no structural setup at all
                    Cand k = new Cand();
                    k.coin = coin; k.tf = tf; k.end = end; k.t = s.t; k.score = s.score; k.rr2 = s.rr2; k.s = s; k.regime = s.regime;
                    cands.add(k);
                }
                step++;
            }
        }
        if (pg != null) pg.on("📊 Walk-forward + reports...", steps, steps);
        JSONObject rep = new JSONObject();
        rep.put("at", System.currentTimeMillis());
        rep.put("coins", COINS.length);
        rep.put("candidates", cands.size());
        rep.put("costs", String.format(Locale.US, "fee %.2f%%/side · slippage %.2f%% · funding %.3f%%/8h", costs.fee * 100, costs.slip * 100, costs.fundingPer8h * 100));
        long mn = Long.MAX_VALUE, mx = 0;
        for (long[] s : span.values()) { mn = Math.min(mn, s[0]); mx = Math.max(mx, s[1]); }
        rep.put("from", mn);
        rep.put("to", mx);
        // ---- default parameters, full period
        SmcEngine.Params def = new SmcEngine.Params(Prefs.getInt(ctx, "smcMinScore", 70), Prefs.getInt(ctx, "smcMinRR10", 20) / 10.0);
        List<Trade> full = simulate(cands, data, def, costs, 0, 1);
        rep.put("full", report(full, def));
        rep.put("byCoin", group(full, 0));
        rep.put("byTf", group(full, 1));
        rep.put("byRegime", group(full, 2));
        // ---- train / validation / test with parameters chosen on TRAIN only
        SmcEngine.Params bestP = choose(cands, data, costs, 0, 0.6);
        JSONObject wf = new JSONObject();
        wf.put("chosen", "min confidence " + bestP.minScore + " · min R:R " + bestP.minRR);
        wf.put("train", report(simulate(cands, data, bestP, costs, 0, 0.6), bestP));
        wf.put("validation", report(simulate(cands, data, bestP, costs, 0.6, 0.8), bestP));
        wf.put("test", report(simulate(cands, data, bestP, costs, 0.8, 1), bestP));
        // ---- anchored walk-forward folds on the last 80 %
        JSONArray folds = new JSONArray();
        List<Trade> oos = new ArrayList<>();
        double[] fs = {0.2, 0.4, 0.6, 0.8, 1.0};
        for (int f = 0; f < 4; f++) {
            SmcEngine.Params fp = choose(cands, data, costs, 0, fs[f]);
            List<Trade> t = simulate(cands, data, fp, costs, fs[f], fs[f + 1]);
            oos.addAll(t);
            JSONObject o = report(t, fp);
            o.put("fold", String.format(Locale.US, "train 0–%.0f%% → test %.0f–%.0f%% · params %d / %.1f", fs[f] * 100, fs[f] * 100, fs[f + 1] * 100, fp.minScore, fp.minRR));
            folds.put(o);
        }
        wf.put("folds", folds);
        wf.put("oos", report(oos, null));
        rep.put("wf", wf);
        Prefs.putStr(ctx, "smcbt", rep.toString());
        return rep;
    }

    /** Grid search on the time window [a, b) of every series; best expectancy with ≥ 15 trades (ties: profit factor). */
    static SmcEngine.Params choose(List<Cand> cands, Map<String, Candles> data, TradeSim.Costs cs, double a, double b) {
        SmcEngine.Params best = new SmcEngine.Params(70, 2.0);
        double bestE = -1e9, bestPf = 0;
        for (int sc : SCORES) for (double rr : RRS) {
            SmcEngine.Params p = new SmcEngine.Params(sc, rr);
            List<Trade> t = simulate(cands, data, p, cs, a, b);
            if (t.size() < 15) continue;
            TradeSim.Stats s = stats(t);
            double pf = Double.isInfinite(s.profitFactor) ? 99 : s.profitFactor;
            if (s.expectancyR > bestE + 1e-9 || (Math.abs(s.expectancyR - bestE) < 1e-9 && pf > bestPf)) { bestE = s.expectancyR; bestPf = pf; best = p; }
        }
        return best;
    }

    /** Runs TradeSim for every candidate that passes `p`, inside the fraction [a, b) of each series' time span. */
    static List<Trade> simulate(List<Cand> cands, Map<String, Candles> data, SmcEngine.Params p, TradeSim.Costs cs, double a, double b) {
        List<Trade> out = new ArrayList<>();
        Map<String, Integer> busyUntil = new HashMap<>();
        for (Cand k : cands) {
            String key = k.coin + "|" + k.tf;
            Candles c = data.get(key);
            if (c == null) continue;
            long t0 = c.time[0], t1 = c.time[c.n - 1];
            double f = (k.t - t0) / (double) Math.max(1, t1 - t0);
            if (f < a || f >= b) continue;
            if (k.score < p.minScore || k.rr2 < p.minRR) continue;
            Integer bu = busyUntil.get(key);
            if (bu != null && k.end <= bu) continue;   // one position per coin / timeframe
            SmcEngine.Setup s = k.s;
            long ms = k.tf.equals("15m") ? 15 * 60_000L : 3600_000L;
            TradeSim ts = new TradeSim(s.isLong, s.entry, s.sl, s.tp1, s.tp2, s.tp3, p.expiry, k.tf.equals("15m") ? 96 : 72, ms, cs);
            int i = k.end + 1;
            for (; i < c.n; i++) {
                ts.step(c.time[i], c.open[i], c.high[i], c.low[i], c.close[i]);
                if (!ts.status.equals("pending") && !ts.status.equals("open")) break;
            }
            busyUntil.put(key, i);
            if (!ts.status.equals("closed")) continue;   // expired / missed / still open at data end: no trade
            Trade t = new Trade();
            t.coin = k.coin; t.tf = k.tf; t.regime = k.regime; t.t = k.t; t.r = ts.resultR(); t.rr = s.rr2;
            out.add(t);
        }
        out.sort((x, y) -> Long.compare(x.t, y.t));
        return out;
    }

    static TradeSim.Stats stats(List<Trade> t) {
        List<Double> r = new ArrayList<>(), rr = new ArrayList<>();
        for (Trade x : t) { r.add(x.r); rr.add(x.rr); }
        return TradeSim.stats(r, rr, 1.0);
    }

    static JSONObject report(List<Trade> t, SmcEngine.Params p) {
        TradeSim.Stats s = stats(t);
        JSONObject o = new JSONObject();
        try {
            o.put("n", s.n); o.put("wins", s.wins); o.put("losses", s.losses); o.put("wr", s.winRate); o.put("lo", s.wilsonLo); o.put("hi", s.wilsonHi);
            o.put("pf", Double.isInfinite(s.profitFactor) ? 999 : s.profitFactor); o.put("exp", s.expectancyR); o.put("netR", s.netR); o.put("netPct", s.netPct);
            o.put("ddR", s.maxDdR); o.put("ddPct", s.maxDdPct); o.put("sharpe", s.sharpe); o.put("rr", s.avgPlannedRR); o.put("cw", s.maxWinStreak); o.put("cl", s.maxLossStreak);
            o.put("line", s.line());
            if (p != null) o.put("params", p.minScore + " / " + p.minRR);
        } catch (Exception ignored) {
        }
        return o;
    }

    /** by: 0 coin, 1 timeframe, 2 regime */
    static JSONObject group(List<Trade> t, int by) {
        Map<String, List<Trade>> m = new LinkedHashMap<>();
        for (Trade x : t) {
            String k = by == 0 ? x.coin : by == 1 ? x.tf : x.regime;
            if (by == 2 && k != null) {   // split "bull/high-vol" into both labels
                for (String part : k.split("/")) { List<Trade> l = m.get(part); if (l == null) { l = new ArrayList<>(); m.put(part, l); } l.add(x); }
                continue;
            }
            List<Trade> l = m.get(k);
            if (l == null) { l = new ArrayList<>(); m.put(k, l); }
            l.add(x);
        }
        JSONObject o = new JSONObject();
        for (Map.Entry<String, List<Trade>> e : m.entrySet()) try { o.put(e.getKey(), report(e.getValue(), null)); } catch (Exception ignored) { }
        return o;
    }
}
