package com.signal.bot;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/**
 * LIVE FORWARD TEST — PAPER TRADING ONLY (no order is ever sent to an exchange).
 * Every SMC Pro signal is recorded with a timestamp, then followed on real 5-minute candles with the SAME execution model as
 * the backtest (TradeSim: limit entry, conservative same-candle rule, partials, break-even, trailing, fees, slippage, funding).
 * A closed trade is final — results are never edited afterwards. Rejected signals / NO TRADE decisions are logged too.
 * Risk manager: risk per trade, max open positions, max daily loss, consecutive-loss pause, duplicate prevention, signal expiry.
 */
public final class PaperBook {
    private PaperBook() {}

    static final String KEY = "smcpaper", REJ = "smcrej";

    public static synchronized List<JSONObject> all(Context c) {
        List<JSONObject> l = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(Prefs.getStr(c, KEY, "[]"));
            for (int i = 0; i < a.length(); i++) l.add(a.getJSONObject(i));
        } catch (Exception ignored) {
        }
        return l;
    }

    static synchronized void save(Context c, List<JSONObject> l) {
        JSONArray a = new JSONArray();
        for (int i = Math.max(0, l.size() - 600); i < l.size(); i++) a.put(l.get(i));
        Prefs.putStr(c, KEY, a.toString());
    }

    // ------------------------------------------------------------------ risk manager
    public static double riskPct(Context c) { return Prefs.getInt(c, "smcRisk10", 10) / 10.0; }
    public static double account(Context c) { return Prefs.getInt(c, "smcAcct", 1000); }
    public static int maxOpen(Context c) { return Prefs.getInt(c, "smcMaxOpen", 5); }
    public static double maxDailyLossR(Context c) { return Prefs.getInt(c, "smcDailyR", 3); }
    public static int pauseAfter(Context c) { return Prefs.getInt(c, "smcPauseN", 3); }

    static boolean active(JSONObject o) { String s = o.optString("st"); return s.equals("pending") || s.equals("open"); }

    static long dayStart() {
        Calendar k = Calendar.getInstance();
        k.set(Calendar.HOUR_OF_DAY, 0); k.set(Calendar.MINUTE, 0); k.set(Calendar.SECOND, 0); k.set(Calendar.MILLISECOND, 0);
        return k.getTimeInMillis();
    }

    /** null = allowed, otherwise the reason it is blocked. */
    public static String riskCheck(Context c, String coin) {
        List<JSONObject> l = all(c);
        int open = 0;
        double today = 0;
        long ds = dayStart();
        for (JSONObject o : l) {
            if (active(o)) {
                open++;
                if (coin.equals(o.optString("coin"))) return "Duplicate: " + coin + " ka paper trade pehle se khula / pending";
            }
            if ("closed".equals(o.optString("st")) && o.optLong("exitT") >= ds) today += o.optDouble("r", 0);
        }
        if (open >= maxOpen(c)) return "Max open positions (" + maxOpen(c) + ") poori";
        if (today <= -maxDailyLossR(c)) return String.format(Locale.US, "Aaj ka max loss (%.0fR) poora — kal tak naye trade band", maxDailyLossR(c));
        int streak = 0;
        long lastLoss = 0;
        for (int i = l.size() - 1; i >= 0; i--) {
            JSONObject o = l.get(i);
            if (!"closed".equals(o.optString("st"))) continue;
            if (o.optDouble("r", 0) > 0) break;
            streak++;
            lastLoss = Math.max(lastLoss, o.optLong("exitT"));
        }
        if (streak >= pauseAfter(c) && System.currentTimeMillis() - lastLoss < 12 * 3600_000L)
            return streak + " loss lagatar — 12 ghante ka pause (consecutive-loss protection)";
        return null;
    }

    public static void reject(Context c, String coin, String tf, String why) {
        try {
            JSONArray a = new JSONArray(Prefs.getStr(c, REJ, "[]"));
            JSONArray b = new JSONArray();
            b.put(new JSONObject().put("t", System.currentTimeMillis()).put("coin", coin).put("tf", tf).put("why", why));
            for (int i = 0; i < a.length() && i < 299; i++) b.put(a.get(i));
            Prefs.putStr(c, REJ, b.toString());
            Prefs.putLong(c, "smcRejN", Prefs.getLong(c, "smcRejN") + 1);
        } catch (Exception ignored) {
        }
    }

    public static JSONArray rejected(Context c) {
        try { return new JSONArray(Prefs.getStr(c, REJ, "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    // ------------------------------------------------------------------ book keeping
    public static JSONObject open(Context c, String coin, String tf, SmcEngine.Setup s) {
        try {
            JSONObject o = new JSONObject();
            o.put("id", coin + tf + s.t);
            o.put("t", System.currentTimeMillis());
            o.put("ct", s.t);
            o.put("coin", coin); o.put("tf", tf); o.put("long", s.isLong);
            o.put("entry", s.entry); o.put("sl", s.sl); o.put("tp1", s.tp1); o.put("tp2", s.tp2); o.put("tp3", s.tp3);
            o.put("score", s.score); o.put("rr", s.rr2); o.put("regime", s.regime);
            o.put("st", "pending");
            o.put("last", System.currentTimeMillis());   // follow candles from now on
            o.put("riskPct", riskPct(c));
            o.put("acct", account(c));
            JSONArray w = new JSONArray();
            for (String x : s.why) w.put(x);
            o.put("why", w);
            List<JSONObject> l = all(c);
            l.add(o);
            save(c, l);
            return o;
        } catch (Exception e) {
            return null;
        }
    }

    static TradeSim simFor(JSONObject o) {
        boolean fut = !o.optBoolean("spot", false);
        TradeSim.Costs cs = fut ? new TradeSim.Costs() : TradeSim.Costs.spot();
        long ms = "15m".equals(o.optString("tf")) ? 15 * 60_000L : 3600_000L;
        int expiryCandles = 6, hold = "15m".equals(o.optString("tf")) ? 96 : 72;
        // the paper trader steps on 5m candles: scale the expiry / hold windows to 5m candles
        int f = (int) (ms / (5 * 60_000L));
        return new TradeSim(o.optBoolean("long"), o.optDouble("entry"), o.optDouble("sl"), o.optDouble("tp1"), o.optDouble("tp2"), o.optDouble("tp3"),
                expiryCandles * f, hold * f, 5 * 60_000L, cs);
    }

    /**
     * Re-plays every 5m candle since the trade was recorded (deterministic: the stored state is rebuilt from candles each time,
     * and a CLOSED trade is never touched again).
     */
    public static synchronized void update(Context c) {
        List<JSONObject> l = all(c);
        boolean ch = false;
        for (JSONObject o : l) {
            if (!active(o)) continue;
            try {
                long from = o.optLong("t");
                String sym = o.optString("coin") + "USDT";
                Candles k = Candles.parse(Scanner.get("/api/v3/klines?symbol=" + sym + "&interval=5m&startTime=" + from + "&limit=1000"), true);
                TradeSim ts = simFor(o);
                for (int i = 0; i < k.n; i++) {
                    if (k.time[i] < from) continue;
                    ts.step(k.time[i] + 5 * 60_000L, k.open[i], k.high[i], k.low[i], k.close[i]);
                    if (!ts.status.equals("pending") && !ts.status.equals("open")) break;
                }
                double px = k.n > 0 ? k.close[k.n - 1] : o.optDouble("entry");
                String old = o.optString("st");
                int oldHits = o.optInt("hits");
                o.put("st", ts.status);
                o.put("hits", ts.hits);
                o.put("best", ts.best);
                o.put("px", px);
                o.put("upd", System.currentTimeMillis());
                if (ts.fillT > 0) o.put("fillT", ts.fillT);
                if (ts.status.equals("open")) o.put("ur", ts.openR(px));
                if (ts.status.equals("closed")) { o.put("r", ts.resultR()); o.put("exitT", ts.exitT); o.put("exitPx", ts.exitPx); o.put("exitWhy", ts.exitWhy); o.remove("ur"); }
                if (ts.status.equals("expired") || ts.status.equals("missed")) { o.put("exitT", System.currentTimeMillis()); o.put("exitWhy", ts.exitWhy); }
                if (!old.equals(ts.status) || oldHits != ts.hits) {
                    ch = true;
                    String b = o.optString("coin");
                    String msg = ts.status.equals("open") && old.equals("pending") ? "📥 Paper fill: " + b + " @ $" + Fmt.price(o.optDouble("entry"))
                            : ts.status.equals("closed") ? String.format(Locale.US, "%s Paper %s: %+.2fR (%s)", ts.resultR() > 0 ? "✅" : "❌", b, ts.resultR(), ts.exitWhy)
                            : ts.hits > oldHits ? "🎯 Paper " + b + " TP" + ts.hits + " hit" : "⌛ Paper " + b + ": " + ts.exitWhy;
                    Notify.show(c, Prefs.N_SIGNALS, (o.optString("id") + ts.status + ts.hits).hashCode(), "🧠 SMC Pro · " + msg, "Paper trading (forward test) — asli paisa nahi",
                            ts.status.equals("closed") && ts.resultR() <= 0 ? 0xFFF6465D : 0xFF0ECB81, MainActivity.TAB_SIGNALS);
                }
                ch = true;
            } catch (Exception ignored) {
            }
        }
        if (ch) save(c, l);
    }

    /** Closed paper trades (time order) -> stats. */
    public static TradeSim.Stats stats(Context c, String coin, String tf) {
        List<Double> r = new ArrayList<>(), rr = new ArrayList<>();
        for (JSONObject o : all(c)) {
            if (!"closed".equals(o.optString("st"))) continue;
            if (coin != null && !coin.equals(o.optString("coin"))) continue;
            if (tf != null && !tf.equals(o.optString("tf"))) continue;
            r.add(o.optDouble("r", 0));
            rr.add(o.optDouble("rr", 0));
        }
        return TradeSim.stats(r, rr, riskPct(c));
    }
}
