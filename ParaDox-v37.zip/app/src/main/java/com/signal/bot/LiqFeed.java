package com.signal.bot;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

/**
 * REAL liquidations, live, from the exchanges' own public WebSocket feeds (no key):
 *  • Binance Futures  !forceOrder@arr      (Binance sends the largest liquidation per coin each second)
 *  • Bybit            allLiquidation.{coin} (top 40 coins by turnover)
 *  • OKX              liquidation-orders    (all perpetual swaps; contracts converted to $ with each contract's size)
 * Every liquidation is kept for 24 h (hourly totals per exchange / coin / side are saved on the phone, so totals survive a restart).
 */
public final class LiqFeed {
    private LiqFeed() {}

    public static final class Liq {
        public final long t;
        public final String ex, coin;
        public final boolean longLiq;   // true = a LONG position was liquidated (forced SELL)
        public final double price, usd;
        Liq(long t, String ex, String coin, boolean longLiq, double price, double usd) { this.t = t; this.ex = ex; this.coin = coin; this.longLiq = longLiq; this.price = price; this.usd = usd; }
    }

    public static final String[] EXCHANGES = {"Binance", "Bybit", "OKX", "Gate", "HTX"};
    private static final OkHttpClient CLIENT = new OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build();
    private static final ScheduledExecutorService EX = Executors.newSingleThreadScheduledExecutor();
    private static final ScheduledExecutorService POLL = Executors.newSingleThreadScheduledExecutor();
    private static final Map<String, Double> GATE_MULT = new HashMap<>();
    private static final java.util.Set<String> SEEN = java.util.Collections.synchronizedSet(new java.util.LinkedHashSet<>());
    private static long gateFrom;
    private static final LinkedList<Liq> RECENT = new LinkedList<>();               // last 400 for the live list
    /** hour (epoch/3600000) -> "ex|coin" -> {longUsd, shortUsd, count} */
    private static final Map<Long, Map<String, double[]>> HOURS = new HashMap<>();
    private static final Map<String, Double> OKX_CT = new HashMap<>();             // instId -> contract value
    private static final java.util.Set<String> OKX_USD = new java.util.HashSet<>(); // coin-margined (contract value in USD)
    private static final Map<String, Boolean> LIVE = new HashMap<>();
    private static final Map<String, WebSocket> SOCK = new HashMap<>();
    private static volatile boolean started;
    private static volatile long since;
    private static Context app;

    public static boolean live(String ex) { Boolean b = LIVE.get(ex); return b != null && b; }

    public static long since() { return since; }

    public static synchronized void start(Context c) {
        if (started) return;
        started = true;
        app = c.getApplicationContext() != null ? c.getApplicationContext() : c;
        load();
        if (since == 0) since = System.currentTimeMillis();
        EX.execute(() -> {
            okxSetup();
            okxBackfill();
            connectBinance();
            connectOkx();
            connectBybit();
        });
        EX.scheduleWithFixedDelay(LiqFeed::save, 2, 2, TimeUnit.MINUTES);
        // v36: Gate + HTX publish liquidations on public REST (no public socket) — polled every minute, 1–2 min behind real time
        POLL.scheduleWithFixedDelay(LiqFeed::pollGate, 5, 60, TimeUnit.SECONDS);
        POLL.scheduleWithFixedDelay(LiqFeed::pollHtx, 15, 60, TimeUnit.SECONDS);
        EX.scheduleWithFixedDelay(() -> {   // app-level pings (Bybit / OKX close idle sockets)
            WebSocket b = SOCK.get("Bybit"), o = SOCK.get("OKX");
            try { if (b != null) b.send("{\"op\":\"ping\"}"); } catch (Exception ignored) { }
            try { if (o != null) o.send("ping"); } catch (Exception ignored) { }
        }, 20, 20, TimeUnit.SECONDS);
    }

    // ------------------------------------------------------------------ store
    static void add(String ex, String coin, boolean longLiq, double price, double usd, long t) {
        if (usd <= 0 || coin.isEmpty()) return;
        Liq l = new Liq(t > 0 ? t : System.currentTimeMillis(), ex, coin, longLiq, price, usd);
        synchronized (RECENT) {
            RECENT.addFirst(l);
            while (RECENT.size() > 1500) RECENT.removeLast();
        }
        synchronized (HOURS) {
            long h = l.t / 3600_000L;
            Map<String, double[]> m = HOURS.get(h);
            if (m == null) { m = new HashMap<>(); HOURS.put(h, m); }
            String k = ex + "|" + coin;
            double[] v = m.get(k);
            if (v == null) { v = new double[3]; m.put(k, v); }
            v[longLiq ? 0 : 1] += usd;
            v[2]++;
            long cut = System.currentTimeMillis() / 3600_000L - 25;
            Iterator<Long> it = HOURS.keySet().iterator();
            while (it.hasNext()) if (it.next() < cut) it.remove();
        }
    }

    /** Latest liquidations of ONE exchange (ex = null: any), optionally one coin. */
    public static List<Liq> recentEx(String ex, String coin, int max) {
        List<Liq> out = new ArrayList<>();
        synchronized (RECENT) {
            for (Liq l : RECENT) {
                if (ex != null && !ex.equals(l.ex)) continue;
                if (coin != null && !coin.equals(l.coin)) continue;
                out.add(l);
                if (out.size() >= max) break;
            }
        }
        return out;
    }

    public static List<Liq> recent(String coin, int max) {
        List<Liq> out = new ArrayList<>();
        synchronized (RECENT) {
            for (Liq l : RECENT) {
                if (coin != null && !coin.equals(l.coin)) continue;
                out.add(l);
                if (out.size() >= max) break;
            }
        }
        return out;
    }

    /** Totals over the last `hours`: "ex|coin" -> {long $, short $, count}. */
    public static Map<String, double[]> totals(int hours) {
        Map<String, double[]> out = new HashMap<>();
        long from = System.currentTimeMillis() / 3600_000L - hours + 1;
        synchronized (HOURS) {
            for (Map.Entry<Long, Map<String, double[]>> e : HOURS.entrySet()) {
                if (e.getKey() < from) continue;
                for (Map.Entry<String, double[]> x : e.getValue().entrySet()) {
                    double[] v = out.get(x.getKey());
                    if (v == null) { v = new double[3]; out.put(x.getKey(), v); }
                    for (int i = 0; i < 3; i++) v[i] += x.getValue()[i];
                }
            }
        }
        return out;
    }

    static void save() {
        if (app == null) return;
        try {
            JSONObject o = new JSONObject();
            synchronized (HOURS) {
                for (Map.Entry<Long, Map<String, double[]>> e : HOURS.entrySet()) {
                    JSONObject h = new JSONObject();
                    for (Map.Entry<String, double[]> x : e.getValue().entrySet())
                        h.put(x.getKey(), new JSONArray().put(Math.round(x.getValue()[0])).put(Math.round(x.getValue()[1])).put((long) x.getValue()[2]));
                    o.put(String.valueOf(e.getKey()), h);
                }
            }
            o.put("_since", since);
            Prefs.putStr(app, "liqhours", o.toString());
        } catch (Exception ignored) {
        }
    }

    static void load() {
        try {
            JSONObject o = new JSONObject(Prefs.getStr(app, "liqhours", "{}"));
            long cut = System.currentTimeMillis() / 3600_000L - 25;
            Iterator<String> it = o.keys();
            synchronized (HOURS) {
                while (it.hasNext()) {
                    String k = it.next();
                    if (k.startsWith("_")) continue;
                    long h = Long.parseLong(k);
                    if (h < cut) continue;
                    JSONObject m = o.getJSONObject(k);
                    Map<String, double[]> mm = new HashMap<>();
                    Iterator<String> i2 = m.keys();
                    while (i2.hasNext()) {
                        String x = i2.next();
                        JSONArray a = m.getJSONArray(x);
                        mm.put(x, new double[]{a.optDouble(0, 0), a.optDouble(1, 0), a.optDouble(2, 0)});
                    }
                    HOURS.put(h, mm);
                }
            }
            long s = o.optLong("_since", 0);
            if (s > System.currentTimeMillis() - 25 * 3600_000L) since = s;
        } catch (Exception ignored) {
        }
    }

    // ------------------------------------------------------------------ sockets
    interface OnOpen { void run(WebSocket w); }

    interface OnText { void on(String text) throws Exception; }

    static void open(final String ex, final String url, final OnOpen onOpen, final OnText onText, final int[] fails) {
        WebSocket w = CLIENT.newWebSocket(new Request.Builder().url(url).build(), new WebSocketListener() {
            @Override
            public void onOpen(WebSocket ws, Response r) {
                fails[0] = 0;
                LIVE.put(ex, true);
                if (onOpen != null) try { onOpen.run(ws); } catch (Exception ignored) { }
            }

            @Override
            public void onMessage(WebSocket ws, String text) {
                try { onText.on(text); } catch (Exception ignored) { }
            }

            @Override
            public void onFailure(WebSocket ws, Throwable t, Response r) { again(); }

            @Override
            public void onClosed(WebSocket ws, int code, String reason) { again(); }

            void again() {
                LIVE.put(ex, false);
                fails[0]++;
                EX.schedule(() -> open(ex, url, onOpen, onText, fails), Math.min(60, 3L * fails[0]), TimeUnit.SECONDS);
            }
        });
        SOCK.put(ex, w);
    }

    static String base(String sym) {
        String s = sym.toUpperCase();
        for (String q : new String[]{"USDT", "USDC", "USD"}) if (s.endsWith(q)) return s.substring(0, s.length() - q.length());
        return s;
    }

    static void connectBinance() {
        open("Binance", "wss://fstream.binance.com/ws/!forceOrder@arr", null, txt -> {
            JSONObject o = new JSONObject(txt).optJSONObject("o");
            if (o == null) return;
            double q = o.optDouble("z", 0) > 0 ? o.optDouble("z", 0) : o.optDouble("q", 0);
            double p = o.optDouble("ap", 0) > 0 ? o.optDouble("ap", 0) : o.optDouble("p", 0);
            add("Binance", base(o.optString("s")), "SELL".equals(o.optString("S")), p, p * q, o.optLong("T"));
        }, new int[1]);
    }

    static void connectBybit() {
        final List<String> syms = new ArrayList<>();
        try {
            JSONArray l = new JSONObject(Scanner.getAbsolute("https://api.bybit.com/v5/market/tickers?category=linear")).getJSONObject("result").getJSONArray("list");
            List<JSONObject> all = new ArrayList<>();
            for (int i = 0; i < l.length(); i++) if (l.getJSONObject(i).optString("symbol").endsWith("USDT")) all.add(l.getJSONObject(i));
            Collections.sort(all, (a, b) -> Double.compare(b.optDouble("turnover24h", 0), a.optDouble("turnover24h", 0)));
            for (int i = 0; i < all.size() && i < 40; i++) syms.add(all.get(i).optString("symbol"));
        } catch (Exception e) {
            for (String s : new String[]{"BTC", "ETH", "SOL", "XRP", "DOGE", "BNB", "ADA", "SUI", "LINK", "AVAX", "LTC", "TRX", "PEPE", "WIF", "HYPE"}) syms.add(s + "USDT");
        }
        open("Bybit", "wss://stream.bybit.com/v5/public/linear", w -> {
            for (int i = 0; i < syms.size(); i += 10) {
                JSONArray args = new JSONArray();
                for (int k = i; k < Math.min(syms.size(), i + 10); k++) args.put("allLiquidation." + syms.get(k));
                try { w.send(new JSONObject().put("op", "subscribe").put("args", args).toString()); } catch (Exception ignored) { }
            }
        }, txt -> {
            JSONObject o = new JSONObject(txt);
            if (!o.optString("topic").startsWith("allLiquidation")) return;
            JSONArray d = o.optJSONArray("data");
            if (d == null) return;
            for (int i = 0; i < d.length(); i++) {
                JSONObject x = d.getJSONObject(i);
                double p = x.optDouble("p", 0), v = x.optDouble("v", 0);
                // Bybit: S = "Buy" means a LONG position was liquidated
                add("Bybit", base(x.optString("s")), "Buy".equals(x.optString("S")), p, p * v, x.optLong("T"));
            }
        }, new int[1]);
    }

    static void okxSetup() {
        try {
            for (String type : new String[]{"SWAP"}) {
                JSONArray a = new JSONObject(Scanner.getAbsolute("https://www.okx.com/api/v5/public/instruments?instType=" + type)).getJSONArray("data");
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    OKX_CT.put(o.optString("instId"), o.optDouble("ctVal", 0));
                    if ("USD".equals(o.optString("ctValCcy"))) OKX_USD.add(o.optString("instId"));
                }
            }
        } catch (Exception ignored) {
        }
    }

    static void okxDetail(String instId, JSONObject x) {
        double ct = OKX_CT.containsKey(instId) ? OKX_CT.get(instId) : 0;
        double px = x.optDouble("bkPx", 0), sz = x.optDouble("sz", 0);
        if (ct <= 0 || px <= 0) return;
        double usd = OKX_USD.contains(instId) ? sz * ct : sz * ct * px;
        String pos = x.optString("posSide");
        boolean longLiq = "long".equals(pos) || ("net".equals(pos) || pos.isEmpty()) && "sell".equals(x.optString("side"));
        add("OKX", instId.split("-")[0], longLiq, px, usd, x.optLong("ts"));
    }

    static void connectOkx() {
        open("OKX", "wss://ws.okx.com:8443/ws/v5/public", w -> {
            try {
                w.send(new JSONObject().put("op", "subscribe").put("args", new JSONArray().put(new JSONObject().put("channel", "liquidation-orders").put("instType", "SWAP"))).toString());
            } catch (Exception ignored) {
            }
        }, txt -> {
            if (!txt.startsWith("{")) return;
            JSONObject o = new JSONObject(txt);
            JSONArray d = o.optJSONArray("data");
            if (d == null) return;
            for (int i = 0; i < d.length(); i++) {
                JSONObject g = d.getJSONObject(i);
                JSONArray det = g.optJSONArray("details");
                if (det == null) continue;
                for (int k = 0; k < det.length(); k++) okxDetail(g.optString("instId"), det.getJSONObject(k));
            }
        }, new int[1]);
    }

    static boolean seen(String id) {
        synchronized (SEEN) {
            if (!SEEN.add(id)) return true;
            if (SEEN.size() > 20000) { Iterator<String> it = SEEN.iterator(); for (int i = 0; i < 5000 && it.hasNext(); i++) { it.next(); it.remove(); } }
            return false;
        }
    }

    static long ms(long t) { return t < 100_000_000_000L ? t * 1000 : t; }

    /** Gate USDT perpetuals: public liquidation history (contracts × multiplier × fill price = $). */
    static void pollGate() {
        try {
            if (GATE_MULT.isEmpty()) {
                JSONArray c = new JSONArray(Scanner.getAbsolute("https://api.gateio.ws/api/v4/futures/usdt/contracts"));
                for (int i = 0; i < c.length(); i++) GATE_MULT.put(c.getJSONObject(i).optString("name"), c.getJSONObject(i).optDouble("quanto_multiplier", 0));
            }
            long now = System.currentTimeMillis() / 1000;
            long from = gateFrom > 0 ? gateFrom - 120 : now - 24 * 3600;
            JSONArray a = new JSONArray(Scanner.getAbsolute("https://api.gateio.ws/api/v4/futures/usdt/liq_orders?from=" + from + "&to=" + now + "&limit=1000"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                String ct = o.optString("contract");
                long sz = o.optLong("size");
                long t = ms(o.optLong("time"));
                if (seen("G" + ct + t + sz + o.optString("fill_price"))) continue;
                double px = o.optDouble("fill_price", 0) > 0 ? o.optDouble("fill_price", 0) : o.optDouble("order_price", 0);
                double mult = GATE_MULT.containsKey(ct) ? GATE_MULT.get(ct) : 0;
                if (mult <= 0 || px <= 0) continue;
                add("Gate", ct.split("_")[0], sz > 0, px, Math.abs(sz) * mult * px, t);   // positive size = a LONG position was liquidated
            }
            gateFrom = now;
            LIVE.put("Gate", true);
        } catch (Exception e) {
            LIVE.put("Gate", false);
        }
    }

    static final String[] HTX_COINS = {"BTC", "ETH", "SOL", "XRP", "DOGE", "ADA", "LTC", "LINK", "SUI", "AVAX", "BNB", "TRX", "PEPE", "TON", "WIF", "DOT", "FIL", "APT", "ARB", "OP"};

    /** HTX USDT perpetuals: public liquidation orders per contract (trade_turnover is already in USDT). */
    static void pollHtx() {
        boolean ok = false;
        long cut = System.currentTimeMillis() - 24 * 3600_000L;
        for (String c : HTX_COINS) {
            try {
                JSONObject r = new JSONObject(Scanner.getAbsolute("https://api.hbdm.com/linear-swap-api/v3/swap_liquidation_orders?contract=" + c + "-USDT&trade_type=0"));
                Object d = r.opt("data");
                JSONArray a = d instanceof JSONArray ? (JSONArray) d : d instanceof JSONObject ? ((JSONObject) d).optJSONArray("orders") : null;
                if (a == null) continue;
                ok = true;
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    long t = ms(o.optLong("created_at"));
                    if (t < cut || seen("H" + o.optString("query_id") + t + o.optString("volume"))) continue;
                    double px = o.optDouble("price", 0), usd = o.optDouble("trade_turnover", 0);
                    if (usd <= 0) usd = o.optDouble("amount", 0) * px;
                    add("HTX", o.optString("contract_code", c + "-USDT").split("-")[0], "sell".equalsIgnoreCase(o.optString("direction")), px, usd, t);
                }
            } catch (Exception ignored) {
            }
        }
        LIVE.put("HTX", ok);
    }

    /** OKX keeps recent liquidation orders on REST — fills the first hours right away (big coins). */
    static void okxBackfill() {
        long cut = System.currentTimeMillis() - 24 * 3600_000L;
        boolean any = false;
        synchronized (HOURS) { for (Map<String, double[]> m : HOURS.values()) for (String k : m.keySet()) if (k.startsWith("OKX|")) any = true; }
        if (any) return;   // already have saved OKX history
        for (String f : new String[]{"BTC-USDT", "ETH-USDT", "SOL-USDT", "XRP-USDT", "DOGE-USDT"}) {
            try {
                JSONArray d = new JSONObject(Scanner.getAbsolute("https://www.okx.com/api/v5/public/liquidation-orders?instType=SWAP&state=filled&instFamily=" + f + "&limit=100"))
                        .getJSONArray("data");
                for (int i = 0; i < d.length(); i++) {
                    JSONObject g = d.getJSONObject(i);
                    JSONArray det = g.optJSONArray("details");
                    if (det == null) continue;
                    String inst = g.optString("instId", f + "-SWAP");
                    for (int k = 0; k < det.length(); k++) if (det.getJSONObject(k).optLong("ts") > cut) okxDetail(inst, det.getJSONObject(k));
                }
            } catch (Exception ignored) {
            }
        }
    }
}
