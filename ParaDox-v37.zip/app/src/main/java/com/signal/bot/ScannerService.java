package com.signal.bot;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

/** Foreground service: scans Scalp and/or Spot on their own schedules and checks price alerts every 30s. */
public class ScannerService extends Service {
    public static final String ACTION_STOP = "com.signal.bot.STOP";
    public static final String CH_SERVICE = "service";
    public static final String CH_HUNT = "hunter_alerts";
    private static final int FG_ID = 1001;

    public static volatile boolean running = false;
    private Thread worker;
    private PowerManager.WakeLock wakeLock;
    private final String[] lines = {"", ""};

    public static void createChannels(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel svc = new NotificationChannel(CH_SERVICE, "Bot running status",
                NotificationManager.IMPORTANCE_LOW);
        NotificationChannel sig = new NotificationChannel(Scanner.CH_SIGNALS, "Buy / Sell signals + price alerts",
                NotificationManager.IMPORTANCE_HIGH);
        sig.enableVibration(true);
        nm.createNotificationChannel(svc);
        nm.createNotificationChannel(sig);
        NotificationChannel hunt = new NotificationChannel(CH_HUNT, "🎯 Gainer Hunter alerts (pre-pump / pre-dump)",
                NotificationManager.IMPORTANCE_HIGH);
        hunt.enableVibration(true);
        hunt.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(hunt);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createChannels(this);
    }

    private Notification statusNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stop = new Intent(this, ScannerService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CH_SERVICE)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("ParaDox live hai")
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setOngoing(true)
                .setColor(0xFFA855F7)
                .setContentIntent(pi)
                .addAction(new Notification.Action.Builder(null, "Stop", stopPi).build())
                .build();
    }

    private void updateStatus(String text) {
        Prefs.setStatus(this, text);
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(FG_ID, statusNotification(text));
    }

    private String joined() {
        StringBuilder sb = new StringBuilder();
        for (String l : lines) {
            if (l.isEmpty()) continue;
            if (sb.length() > 0) sb.append('\n');
            sb.append(l);
        }
        return sb.length() == 0 ? "Scan shuru ho raha hai..." : sb.toString();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            Prefs.setEnabled(this, false);
            Prefs.setStatus(this, "Bot band hai");
            running = false;
            if (worker != null) worker.interrupt();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        Notification n = statusNotification("Scan shuru ho raha hai...");
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(FG_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(FG_ID, n);
        }

        if (wakeLock == null) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SignalBot:scan");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire();
        }

        try { LiqFeed.start(this); } catch (Exception ignored) { }   // v35: live liquidations collected 24/7 (light WebSocket feeds)
        if (worker == null || !worker.isAlive()) {
            running = true;
            worker = new Thread(this::loop, "scanner");
            worker.start();
        }
        return START_STICKY;
    }

    private Thread side;

    private void loop() {
        long[] next = {0, 0};
        while (running) {
            try {
                Scanner.checkAlerts(this);
                Scanner.trackSignals(this);
                checkUpdateQuietly();
                if (System.currentTimeMillis() - Prefs.lastWalletCheck(this) > 15 * 60_000L) {
                    Prefs.setLastWalletCheck(this, System.currentTimeMillis());
                    WalletWatch.check(this);
                }
                if (System.currentTimeMillis() - Prefs.lastMacroCheck(this) > 2 * 60_000L) {
                    Prefs.setLastMacroCheck(this, System.currentTimeMillis());
                    try {
                        MacroEngine.tick(this);
                    } catch (Exception ignored) {
                    }
                }
                if (System.currentTimeMillis() - Prefs.lastBigCheck(this) > 30 * 60_000L) {
                    Prefs.setLastBigCheck(this, System.currentTimeMillis());
                    BigPlayers.fetch(this, true);
                }
                if (!Prefs.enabled(this)) {
                    running = false;
                    stopForeground(true);
                    stopSelf();
                    break;
                }
                // hunter + price-gap radar run on their OWN thread: a long hunt can never hold up the buy / sell signal scan
                if (side == null || !side.isAlive()) {
                    side = new Thread(() -> {
                        try { PumpHunter.tick(this); } catch (Exception ignored) { }   // 24/7 gainer / loser hunter (own interval)
                        try { Mispricing.tick(this); } catch (Exception ignored) { }   // 24/7 price-gap radar (own interval)
                        try { SmcScanner.tick(this); } catch (Exception ignored) { }   // v37: SMC Pro signals + paper forward test
                    }, "hunter");
                    side.start();
                }
                if (System.currentTimeMillis() - Prefs.getLong(this, "cattick") > 5 * 60_000L) {
                    Prefs.putLong(this, "cattick", System.currentTimeMillis());
                    try {
                        CatalystEngine.tick(this);
                    } catch (Exception ignored) {
                    }
                }
                if (System.currentTimeMillis() - Prefs.getLong(this, "newstick") > 60_000L) {
                    Prefs.putLong(this, "newstick", System.currentTimeMillis());
                    try {
                        NewsEngine.tick(this);
                    } catch (Exception ignored) {
                    }
                }
                for (String mkt : new String[]{Assets.COMMODITY, Assets.FOREX}) {
                    if (!running) break;
                    try {
                        AssetScanner.tick(this, mkt);
                    } catch (Exception ignored) {
                    }
                }
                if (System.currentTimeMillis() - Prefs.getLong(this, "atrack") > 5 * 60_000L) {
                    Prefs.putLong(this, "atrack", System.currentTimeMillis());
                    try {
                        AssetScanner.track(this);
                    } catch (Exception ignored) {
                    }
                }
                boolean focus = Prefs.focusOn(this);
                for (int m = 0; m < 2 && running; m++) {
                    boolean on = focus ? !Prefs.focusCrypto(this, m).isEmpty() : Prefs.modeOn(this, m);
                    if (!on) {
                        lines[m] = Mode.label(m) + (focus ? " · focus list mein koi coin nahi" : " bot OFF");
                        next[m] = 0;
                        continue;
                    }
                    if (System.currentTimeMillis() < next[m]) continue;
                    lines[m] = Mode.label(m) + " scan chal raha hai...";
                    updateStatus(joined());
                    try {
                        lines[m] = Scanner.runOnce(this, m);
                    } catch (InterruptedException e) {
                        throw e;
                    } catch (Exception e) {
                        lines[m] = Mode.label(m) + " error: " + e.getMessage() + " — dobara try hoga";
                    }
                    next[m] = System.currentTimeMillis() + Prefs.intervalMin(this, m) * 60_000L;
                    updateStatus(joined());
                }
                Thread.sleep(Prefs.arbOn(this) && Prefs.arbEverySec(this) < 30 ? 15_000 : 20_000);   // v32: faster loop
            } catch (InterruptedException e) {
                break;
            } catch (Exception e) {
                updateStatus("Error: " + e.getMessage() + " — internet check karein");
                try {
                    Thread.sleep(30_000);
                } catch (InterruptedException ie) {
                    break;
                }
            }
        }
    }

    /** Every 6 hours: if a newer APK is on GitHub, show a notification once. */
    private void checkUpdateQuietly() {
        if (System.currentTimeMillis() - Prefs.lastUpdateCheck(this) < 6 * 3600_000L) return;
        try {
            UpdateManager.Info in = UpdateManager.check(this);
            if (in != null && in.time != Prefs.notifiedUpdate(this) && Notify.allowed(this, Prefs.N_UPDATE)) {
                Prefs.setNotifiedUpdate(this, in.time);
                Intent open = new Intent(this, MainActivity.class);
                open.putExtra("update", true);
                open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                PendingIntent pi = PendingIntent.getActivity(this, 4244, open,
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
                Notification n = new Notification.Builder(this, Scanner.CH_SIGNALS)
                        .setSmallIcon(R.drawable.ic_stat)
                        .setContentTitle("🆕 ParaDox ka naya update")
                        .setContentText("Tap karein → Install dabayen (dobara GitHub se download ki zaroorat nahi)")
                        .setContentIntent(pi)
                        .setAutoCancel(true)
                        .build();
                ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).notify(4245, n);
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        if (worker != null) worker.interrupt();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
