package com.signal.bot;

import java.util.*;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class SmcTests {
    @Test
    public void allChecksPass() {
        pass = 0; fail = 0;
        main(new String[0]);
        assertEquals("failed checks", 0, fail);
    }

    static int pass = 0, fail = 0;
    static void check(String name, boolean ok, String info) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + name + (info.isEmpty() ? "" : " — " + info)); }

    /** candles from a list of {o,h,l,c} */
    static Candles mk(double[][] b, long ms) {
        Candles c = Candles.create(b.length);
        for (int i = 0; i < b.length; i++) { c.time[i] = i * ms; c.open[i] = b[i][0]; c.high[i] = b[i][1]; c.low[i] = b[i][2]; c.close[i] = b[i][3]; c.vol[i] = 100; c.quoteVol[i] = 100 * b[i][3]; c.takerBuyQuote[i] = 50 * b[i][3]; }
        return c;
    }

    /** smooth path through waypoints, 1 candle per step */
    static double[][] path(double[] pts, int per, double wick) {
        List<double[]> l = new ArrayList<>();
        double prev = pts[0];
        for (int k = 1; k < pts.length; k++) for (int s = 1; s <= per; s++) {
            double v = pts[k - 1] + (pts[k] - pts[k - 1]) * s / per;
            l.add(new double[]{prev, Math.max(prev, v) + wick, Math.min(prev, v) - wick, v});
            prev = v;
        }
        return l.toArray(new double[0][]);
    }

    public static void main(String[] a) {
        // 1) bullish structure: HL/HH zig-zag up -> BOS up, trend +1
        Candles up = mk(path(new double[]{100, 110, 104, 116, 109, 123, 115, 130}, 6, 0.3), 3600_000L);
        Smc.Result r = Smc.analyze(up, up.n - 1, 200);
        boolean bos = false; for (Smc.Event e : r.events) if (e.bull && (e.type.equals("BOS") || e.type.equals("CHOCH") || e.type.equals("MSS"))) bos = true;
        StringBuilder lab = new StringBuilder(); for (Smc.Swing s : r.swings) lab.append(s.label).append(' ');
        check("bullish structure + BOS detected", r.trend == 1 && bos, "trend " + r.trend + " swings " + lab);
        // 2) bearish
        Candles dn = mk(path(new double[]{130, 120, 126, 114, 121, 107, 115, 100}, 6, 0.3), 3600_000L);
        Smc.Result rd = Smc.analyze(dn, dn.n - 1, 200);
        check("bearish structure", rd.trend == -1, "trend " + rd.trend);
        // 3) sell-side sweep: swing low at ~100 then a candle wicks to 98 and closes back at 102
        List<double[]> b = new ArrayList<>(Arrays.asList(path(new double[]{110, 100, 108, 104}, 5, 0.2)));
        b.add(new double[]{104, 104.5, 98, 103});
        b.add(new double[]{103, 106, 102.5, 105.5}); b.add(new double[]{105.5, 107, 105, 106.8}); b.add(new double[]{106.8, 107.5, 106.2, 107.2});
        Candles sw = mk(b.toArray(new double[0][]), 3600_000L);
        Smc.Result rs = Smc.analyze(sw, sw.n - 1, 200);
        Smc.Event se = rs.last("SWEEP", true);
        check("sell-side liquidity sweep", se != null && se.i == 15, se == null ? "none" : "at " + se.i + " level " + se.level);
        // 4) bullish FVG: low[i] > high[i-2] with a big middle candle
        double[][] f = {{100, 101, 99, 100.5}, {100.5, 101, 100, 100.8}, {100.8, 101.2, 100.4, 101}, {101, 101.3, 100.7, 101.1}, {101.1, 101.4, 100.8, 101.2},
                {101.2, 101.5, 100.9, 101.3}, {101.3, 101.6, 101.0, 101.4}, {101.4, 101.7, 101.1, 101.5}, {101.5, 101.8, 101.2, 101.6}, {101.6, 101.8, 101.2, 101.6},
                {101.6, 101.9, 101.3, 101.7}, {101.7, 101.9, 101.4, 101.8}, {101.8, 106, 101.7, 105.8}, {105.8, 107, 103.0, 106.5}, {106.5, 107.2, 106, 106.8}};
        Candles fv = mk(f, 3600_000L);
        Smc.Result rf = Smc.analyze(fv, fv.n - 1, 200);
        boolean fvg = false; for (Smc.Zone z : rf.zones) if (z.type.equals("FVG") && z.bull && z.i == 13) fvg = true;
        check("bullish FVG", fvg, "zones " + rf.zones.size());
        // 5) NO LOOK-AHEAD: engine output at `end` must not change when future candles change
        Random rnd = new Random(42);
        int n = 3000;
        double[][] rw = new double[n][]; double p = 100;
        for (int i = 0; i < n; i++) { double o = p; p *= 1 + rnd.nextGaussian() * 0.008; rw[i] = new double[]{o, Math.max(o, p) * (1 + rnd.nextDouble() * 0.004), Math.min(o, p) * (1 - rnd.nextDouble() * 0.004), p}; }
        Candles A = mk(rw, 3600_000L);
        double[][] rw2 = new double[n][]; for (int i = 0; i < n; i++) rw2[i] = rw[i].clone();
        for (int i = 2000; i < n; i++) { rw2[i][1] *= 1.5; rw2[i][3] *= 1.3; }   // wildly different future
        Candles B = mk(rw2, 3600_000L);
        SmcEngine.Ctx xa = SmcEngine.prepare(A, "1h"), xb = SmcEngine.prepare(B, "1h");
        boolean same = true; int compared = 0;
        for (int end = 1500; end < 1999; end += 7) {
            SmcEngine.Setup sa = SmcEngine.evaluate(xa, end, new SmcEngine.Params(0, 0)), sb = SmcEngine.evaluate(xb, end, new SmcEngine.Params(0, 0));
            compared++;
            if (sa.score != sb.score || sa.entry != sb.entry || !sa.noTrade.equals(sb.noTrade)) { same = false; System.out.println("  diff at " + end + ": " + sa.noTrade + " | " + sb.noTrade); break; }
        }
        check("no look-ahead (future candles changed, past signals identical)", same, compared + " candles compared");
        // 6) TradeSim: same candle touches SL and TP -> stop first
        TradeSim.Costs zero = new TradeSim.Costs(); zero.fee = 0; zero.slip = 0; zero.fundingPer8h = 0;
        TradeSim t1 = new TradeSim(true, 100, 90, 110, 120, 130, 5, 50, 3600_000L, zero);
        t1.step(1, 101, 101, 99.5, 100);      // fill
        t1.step(2, 100, 111, 89, 100);        // both SL and TP1 inside -> SL
        check("same-candle SL+TP = stop (conservative)", t1.status.equals("closed") && Math.abs(t1.resultR() + 1) < 1e-9, t1.label());
        // 7) partials: TP1, TP2, TP3 in order -> (0.1+0.2+0.3)/3 / 0.1 = 2R before costs
        TradeSim t2 = new TradeSim(true, 100, 90, 110, 120, 130, 5, 50, 3600_000L, zero);
        t2.step(1, 101, 101, 99.9, 100); t2.step(2, 100, 110.5, 100.2, 110); t2.step(3, 110, 120.5, 109, 120); t2.step(4, 120, 131, 119, 130);
        check("partials 1/3 each → +2.00R", t2.status.equals("closed") && Math.abs(t2.resultR() - 2) < 1e-9, String.format(Locale.US, "%.4fR", t2.resultR()));
        // 8) break-even after TP1
        TradeSim t3 = new TradeSim(true, 100, 90, 110, 120, 130, 5, 50, 3600_000L, zero);
        t3.step(1, 101, 101, 99.9, 100); t3.step(2, 100, 110.5, 100.2, 110); t3.step(3, 110, 110, 99, 100);
        check("break-even stop after TP1 → +0.33R", Math.abs(t3.resultR() - 1.0 / 3) < 1e-9, String.format(Locale.US, "%.4fR", t3.resultR()));
        // 9) costs reduce the result: fee 0.05% x2 + slippage 0.05% on a stop
        TradeSim.Costs cs = new TradeSim.Costs(); cs.fundingPer8h = 0;
        TradeSim t4 = new TradeSim(true, 100, 99, 110, 120, 130, 5, 50, 3600_000L, cs);
        t4.step(1, 101, 101, 99.9, 100); t4.step(2, 100, 100.5, 98, 99);
        check("fees + slippage counted (−1R − 0.15R)", Math.abs(t4.resultR() + 1.15) < 1e-6, String.format(Locale.US, "%.4fR", t4.resultR()));
        // 10) entry not filled + TP1 reached first -> missed (no trade)
        TradeSim t5 = new TradeSim(true, 100, 90, 110, 120, 130, 5, 50, 3600_000L, zero);
        t5.step(1, 105, 111, 101, 110);
        check("TP1 before fill = missed, not a win", t5.status.equals("missed"), t5.status);
        // 11) stats: Wilson CI + profit factor
        TradeSim.Stats st = TradeSim.stats(Arrays.asList(2.0, -1.0, 2.0, -1.0, 1.0), null, 1.0);
        check("stats: win 60%, PF 2.5, expectancy 0.6R", Math.abs(st.winRate - 60) < 1e-9 && Math.abs(st.profitFactor - 2.5) < 1e-9 && Math.abs(st.expectancyR - 0.6) < 1e-9,
                String.format(Locale.US, "Wilson %.0f–%.0f%%, DD %.1fR", st.wilsonLo, st.wilsonHi, st.maxDdR));
        // 12) aggregation: 24 x 1h = 1 day, only complete groups
        int[][] li = new int[1][];
        Candles agg = Smc.aggregate(A, 24, 3600_000L, li);
        check("aggregation 1h→1D complete candles only", agg.n == n / 24 && li[0][0] == 23, agg.n + " days");
        // 13) pipeline on pure random walk: should show NO edge (sanity, not performance)
        SmcEngine.Ctx x = SmcEngine.prepare(A, "1h");
        List<Double> rr = new ArrayList<>(); int cand = 0;
        int busy = -1;
        long t0 = System.currentTimeMillis();
        for (int end = 24 * 45; end < n - 1; end++) {
            SmcEngine.Setup s = SmcEngine.evaluate(x, end, new SmcEngine.Params(60, 1.5));
            if (!s.ok || end <= busy) continue;
            cand++;
            TradeSim ts = new TradeSim(s.isLong, s.entry, s.sl, s.tp1, s.tp2, s.tp3, 6, 72, 3600_000L, new TradeSim.Costs());
            int i = end + 1;
            for (; i < n; i++) { ts.step(A.time[i], A.open[i], A.high[i], A.low[i], A.close[i]); if (!ts.status.equals("pending") && !ts.status.equals("open")) break; }
            busy = i;
            if (ts.status.equals("closed")) rr.add(ts.resultR());
        }
        TradeSim.Stats rs2 = TradeSim.stats(rr, null, 1.0);
        System.out.println("INFO random-walk sanity run (" + (System.currentTimeMillis() - t0) + " ms, " + cand + " signals): " + rs2.line());
        check("random walk gives no fake edge (expectancy < +0.3R)", rs2.n == 0 || rs2.expectancyR < 0.3, String.format(Locale.US, "%+.2fR", rs2.expectancyR));
        System.out.println("\n" + pass + " passed, " + fail + " failed");
    }
}
