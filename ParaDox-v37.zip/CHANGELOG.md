# Changelog

## v37.0 — SMC Pro
- New: Smart Money Concepts engine: BOS, CHoCH, MSS, HH/HL/LH/LL, BSL/SSL, EQH/EQL, sweeps, premium/discount,
  order blocks with validation and mitigation, FVG, IFVG, breaker and rejection blocks, displacement.
- New: multi-timeframe signal engine. Bias comes from 4h + 1D (or 1h + 4h); entry is confirmed on 1h (or 15m).
  It returns NO TRADE when conditions conflict.
- New: weighted confidence score (8 parts). Minimum reward:risk check. Every signal carries full fields and an explanation.
- New: risk manager: risk %, position size, max open positions, daily loss limit, consecutive-loss pause, duplicate block,
  expiry, partial exits, break-even and trailing stop.
- New: historical backtest on real candles, run on the phone. Includes fees, slippage, funding, the conservative
  same-candle rule and reports by coin, timeframe and regime.
- New: walk-forward: 60/20/20 split, 4 anchored folds and an out-of-sample total.
- New: live forward test (paper only) with immutable history, NO TRADE log and a live-vs-backtest comparison.
- New: AI review (Gemini / Groq) that explains a setup and cannot change it.
- New: market narrative card (BTC dominance, total market cap, alt share, AI/RWA/DePIN/DeFi/Gaming sectors) and an
  MTF structure table (5m → 1W).
- Tests: 13 unit checks (JUnit), run in CI as a non-blocking step.

## v36.0
- Gate and HTX liquidations added. Each exchange shown separately.
