# ParaDox v37 — SMC Pro (Smart Money Concepts engine)

## 1. Audit of the existing bot (before the upgrade)
- **Architecture:** Android app (Java, programmatic UI), `ScannerService` foreground loop, `Scanner` (Spot/Scalp signals),
  `CoinReport` (all-source analysis), `PumpHunter`, `AssetScanner` (gold/forex), data from Binance REST/WS with MEXC fallback.
- **Weaknesses found:**
  - The old signal tracker (`Scanner.trackSignals`) marks a WIN when TP1 is touched, with no fees, no slippage and no partial exits,
    so its win rate cannot be compared with a real trading result. The new paper book was built for that reason.
  - The old "accuracy" backtest (`Backtest`) tests one rule on one coin. It has no walk-forward split and no out-of-sample check.
  - Signals had no explicit liquidity or market-structure model (BOS, CHoCH, sweeps, OB, FVG).
- **Kept as they were:** every existing feature. SMC Pro is an additional engine with its own Prefs keys.

## 2. Modules
| File | What it does |
|---|---|
| `Smc.java` | Swings (HH/HL/LH/LL, confirmed K=3 candles later), BOS / CHoCH / MSS, sweeps, BSL/SSL, EQH/EQL, OB, FVG, IFVG, breaker, rejection blocks, premium/discount, aggregation 1h→4h/1D |
| `SmcEngine.java` | One deterministic signal function (live = backtest = paper). Multi-timeframe bias, sweep → CHoCH/BOS confirmation → fresh OB/FVG entry. Stop beyond the sweep, targets at liquidity, 8-part confidence (0–100), NO TRADE with a reason |
| `TradeSim.java` | Execution model: limit entry + expiry, same-candle SL+TP = stop first, 1/3 partials, break-even, trailing, fees, slippage, funding. Stats: win rate + Wilson 95% CI, PF, expectancy, max DD, Sharpe, streaks |
| `SmcBacktest.java` | Real candles (10 coins, 1h ≈ 250 days, 15m ≈ 52 days). Evaluation at every candle without future data. Results by coin, timeframe and regime. 60/20/20 train/validation/test split, 4 anchored walk-forward folds, out-of-sample total |
| `PaperBook.java` | Live forward test, PAPER ONLY. Timestamped signals followed on 5m candles with the same TradeSim. Closed results are never edited. Risk manager, NO TRADE log |
| `SmcScanner.java` | Runs after every closed 1h / 15m candle on the top coins. Signal → Signals tab + notification + paper trade |
| UI | More → 🧠 SMC Pro Lab, with seven tabs: Live setups (+ narrative, MTF 5m–1W), Paper, Backtest, Walk-forward, Risk, NO TRADE log, Guide |

## 3. No look-ahead rules
- Swings count only once K candles have closed after them.
- Higher timeframes are built from closed base candles, and a 4h/1D candle is used only after its last base candle closed.
- EMA, RSI and ATR are prefix-only.
- Signals act from the next candle. A limit entry fills only if price reaches it.
- On the fill candle only the stop is checked. If the stop and a target fall in the same candle, the stop is counted.

## 4. Tests (run in the build environment, synthetic data)
`app/src/test/java/com/signal/bot/SmcTests.java`: 13 checks, all passing:
- bullish / bearish structure
- liquidity sweep
- FVG
- **no look-ahead** (future candles changed, past outputs identical)
- conservative same-candle rule
- partials = +2.00R
- break-even = +0.33R
- fees and slippage = −1.15R
- missed fill ≠ win
- stats (win rate, PF, expectancy, Wilson CI)
- aggregation 1h→1D
- random-walk sanity run (no fake edge)

**On real market data no backtest has been run yet.** The build machine has no access to exchange APIs. The real backtest,
walk-forward and paper results are produced on the phone (SMC Pro Lab → Run) and are never pre-filled.

## 5. Accuracy target
90% is a target, not a promise. Judge the system on profit factor, expectancy and drawdown over 100+ out-of-sample and
forward trades, with the confidence interval shown in the app. Do not judge it on a single win-rate number.
