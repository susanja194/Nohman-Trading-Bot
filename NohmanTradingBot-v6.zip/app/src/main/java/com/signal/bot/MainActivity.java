package com.signal.bot;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    static final int CARD = 0xFF141B2B, CHIP = 0xFF1C2638, STROKE = 0xFF263352,
            TEXT = 0xFFE8EAED, SOFT = 0xFFC9D1DC, MUTED = 0xFF8B95A7,
            GREEN = 0xFF0ECB81, RED = 0xFFF6465D, YELLOW = 0xFFFFC94D, INK = 0xFF0A0E17, CLAUDE = 0xFFD97757;

    private int uiMode;
    private int ACC, ACC2;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private final View[] pages = new View[4];
    private final TextView[] tabs = new TextView[4];
    private int currentTab = -1;
    private TextView liveDot;
    private FrameLayout rootFrame;
    private boolean resumed;

    // in-app update
    private LinearLayout updateBanner;
    private TextView updStatus;
    private EditText repoEt;
    private volatile boolean installing;

    // Market
    private GaugeView fgGauge;
    private TextView btcView, globalView, marketCount;
    private EditText marketSearch;
    private LinearLayout marketList;
    private final TextView[] modeChips = new TextView[5];
    private int marketMode = 0, marketLimit = 50;
    private final Map<String, double[]> mk = new HashMap<>();          // sym -> {last, open, quoteVol}
    private final Map<String, TextView[]> rowViews = new HashMap<>();  // sym -> {price, pct}
    private WsStream marketWs;
    private final Map<String, double[]> pendingMini = new HashMap<>();
    private long marketLoadedAt;

    // Analyze
    private EditText searchEt;
    private TextView starBtn, chartTitle, livePrice;
    private String[] chartTfs;
    private TextView[] tfChips;
    private String chartTf;
    private String currentSym = "BTCUSDT";
    private ChartView chart;
    private BookView book;
    private TapeView tape;
    private LinearLayout watchRow, resultBox, fsOverlay;
    private ViewGroup chartParent;
    private int chartIndex;
    private ViewGroup.LayoutParams chartLp;
    private static final String[] LAYERS = {"Fib", "Lines", "Zones", "VolProfile", "Whales", "RSI"};
    private final TextView[] layerChips = new TextView[LAYERS.length];
    private CoinReport lastReport;

    // live coin stream
    private WsStream coinWs;
    private final Object liveLock = new Object();
    private double[] pendingKline;
    private final List<double[]> pendingTrades = new ArrayList<>();
    private double[][] pendingBids, pendingAsks;
    private boolean candleClosed;
    private volatile boolean coinLive;
    private String liveSym = "", liveTf = "";
    private double chartWhaleThr = 50000;
    private double dayOpen;

    // Signals
    private TextView statusView, statsView;
    private Button scalpBtn, spotBtn;
    private LinearLayout signalList, alertList;
    private String signalKey = "";

    // Settings
    private final EditText[][] modeFields = new EditText[2][];
    private final Spinner[] tfSpinners = new Spinner[2];
    private CheckBox btcCb, smartCb, strongCb;
    private EditText whaleEt, glassEt, claudeEt;
    private Spinner modelSpinner;

    private final Runnable refresher = new Runnable() {
        @Override
        public void run() {
            refreshStatus();
            handler.postDelayed(this, 5000);
        }
    };

    private final Runnable liveTick = new Runnable() {
        @Override
        public void run() {
            applyLive();
            applyMarketLive();
            handler.postDelayed(this, 400);
        }
    };

    // ============================================================ lifecycle
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        uiMode = Prefs.uiMode(this);
        ACC = Mode.accent(uiMode);
        ACC2 = Mode.accent2(uiMode);
        chartTfs = Mode.chartTfs(uiMode);
        chartTf = Mode.defaultChartTf(uiMode);
        tfChips = new TextView[chartTfs.length];
        ScannerService.createChannels(this);
        getWindow().setStatusBarColor(Mode.bgTop(uiMode));
        getWindow().setNavigationBarColor(CARD);
        currentSym = Prefs.lastCoin(this);

        rootFrame = new FrameLayout(this);
        LinearLayout root = column();
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Mode.bgTop(uiMode), Mode.bgBottom(uiMode)}));
        root.addView(header());
        FrameLayout content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));
        buildMarket();
        buildAnalyze();
        buildSignals();
        buildSettings();
        for (View p : pages) content.addView(p, new FrameLayout.LayoutParams(-1, -1));
        root.addView(bottomNav());
        rootFrame.addView(root, new FrameLayout.LayoutParams(-1, -1));
        setContentView(rootFrame);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        int startTab = savedInstanceState != null ? savedInstanceState.getInt("tab", 0) : 0;
        if (!handleIntent(getIntent())) showTab(startTab);
        loadChart();
        if (System.currentTimeMillis() - Prefs.lastUpdateCheck(this) > 3 * 3600_000L) checkForUpdate(false);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt("tab", currentTab);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private boolean handleIntent(Intent i) {
        if (i == null) return false;
        if (i.getBooleanExtra("update", false)) {
            i.removeExtra("update");
            showTab(3);
            checkForUpdate(true);
            return true;
        }
        String coin = i.getStringExtra("coin");
        if (coin == null || coin.isEmpty()) return false;
        i.removeExtra("coin");
        openAnalyze(coin);
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        handler.post(refresher);
        handler.post(liveTick);
        if (chart.getData() != null) startCoinFeed();
        if (currentTab == 0) startMarketFeed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumed = false;
        handler.removeCallbacks(refresher);
        handler.removeCallbacks(liveTick);
        stopCoinFeed();
        stopMarketFeed();
    }

    @Override
    protected void onDestroy() {
        stopCoinFeed();
        stopMarketFeed();
        pool.shutdownNow();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (fsOverlay != null) closeFullscreen();
        else if (currentTab != 0) showTab(0);
        else super.onBackPressed();
    }

    private void switchMode(int m) {
        if (m == uiMode) return;
        Prefs.setUiMode(this, m);
        recreate();
    }

    // ============================================================ ui helpers
    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable round(int color, float radiusDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) g.setStroke(dp(1), strokeColor);
        return g;
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setPadding(0, dp(2), 0, dp(2));
        return t;
    }

    private TextView bold(String s, float sp, int color) {
        TextView t = text(s, sp, color);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private LinearLayout card(LinearLayout parent) {
        return card(parent, STROKE);
    }

    private LinearLayout card(LinearLayout parent, int border) {
        LinearLayout c = column();
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        c.setBackground(round(CARD, 18, border));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        parent.addView(c, lp);
        return c;
    }

    private LinearLayout pageColumn(int idx) {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout col = column();
        col.setPadding(dp(12), 0, dp(12), dp(28));
        sv.addView(col);
        pages[idx] = sv;
        return col;
    }

    private TextView chip(String s, boolean on) {
        TextView t = bold(s, 13, TEXT);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(13), dp(8), dp(13), dp(8));
        styleChip(t, on);
        return t;
    }

    private void styleChip(TextView t, boolean on) {
        t.setTextColor(on ? INK : TEXT);
        t.setBackground(round(on ? ACC : CHIP, 20, on ? ACC : STROKE));
    }

    private LinearLayout.LayoutParams chipLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dp(8);
        return lp;
    }

    private HorizontalScrollView hscroll(LinearLayout inner) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(inner);
        return hs;
    }

    private Button button(String s, int bg, int fg, int stroke) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(fg);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(round(bg, 14, stroke));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(50));
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    private View bar(double leftPct, int leftColor, int rightColor) {
        LinearLayout b = row();
        b.setBackground(round(rightColor, 6, 0));
        float l = (float) Math.max(0, Math.min(100, leftPct));
        View a = new View(this);
        a.setBackground(round(leftColor, 6, 0));
        b.addView(a, new LinearLayout.LayoutParams(0, -1, l));
        b.addView(new View(this), new LinearLayout.LayoutParams(0, -1, 100 - l));
        return b;
    }

    private View divider() {
        View d = new View(this);
        d.setBackgroundColor(STROKE);
        d.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1)));
        return d;
    }

    private EditText input(String hint, String value, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(MUTED);
        e.setTextColor(TEXT);
        e.setSingleLine(true);
        e.setInputType(type);
        e.setText(value);
        return e;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void openUrl(String url) {
        if (url == null || url.isEmpty()) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            toast("Link nahi khula");
        }
    }

    private static String base(String sym) {
        return sym.endsWith("USDT") ? sym.substring(0, sym.length() - 4) : sym;
    }

    private static double parse(EditText e, double def) {
        try {
            return Double.parseDouble(e.getText().toString().trim().replace(",", ""));
        } catch (Exception x) {
            return def;
        }
    }

    private static double num(JSONObject o, String k) {
        try {
            return Double.parseDouble(o.optString(k, "0"));
        } catch (Exception e) {
            return 0;
        }
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null && getCurrentFocus() != null) imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        } catch (Exception ignored) {
        }
    }

    // ============================================================ frame
    private View header() {
        LinearLayout h = row();
        h.setPadding(dp(16), dp(14), dp(16), dp(6));
        TextView a = bold("NOHMAN", 19, ACC);
        a.setLetterSpacing(0.08f);
        TextView b = bold(" TRADING BOT", 19, ACC2);
        b.setLetterSpacing(0.08f);
        h.addView(a);
        h.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
        TextView mode = bold(Mode.label(uiMode), 11, INK);
        mode.setPadding(dp(9), dp(4), dp(9), dp(4));
        mode.setBackground(round(ACC, 12, 0));
        mode.setOnClickListener(v -> switchMode(uiMode == Mode.SCALP ? Mode.SPOT : Mode.SCALP));
        h.addView(mode);
        liveDot = bold("○ OFF", 11, MUTED);
        liveDot.setPadding(dp(9), dp(4), dp(9), dp(4));
        liveDot.setBackground(round(CHIP, 12, STROKE));
        liveDot.setOnClickListener(v -> showTab(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = dp(6);
        h.addView(liveDot, lp);
        return h;
    }

    private View bottomNav() {
        LinearLayout nav = row();
        nav.setBackground(round(CARD, 0, STROKE));
        nav.setPadding(0, dp(6), 0, dp(6));
        String[] labels = {"📊\nMarket", "🔍\nAnalyze", "🔔\nSignals", "⚙️\nSettings"};
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            TextView t = text(labels[i], 12, MUTED);
            t.setGravity(Gravity.CENTER);
            t.setOnClickListener(v -> showTab(idx));
            tabs[i] = t;
            nav.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        }
        return nav;
    }

    private void showTab(int i) {
        currentTab = i;
        for (int k = 0; k < 4; k++) {
            pages[k].setVisibility(k == i ? View.VISIBLE : View.GONE);
            tabs[k].setTextColor(k == i ? ACC : MUTED);
            tabs[k].setTypeface(k == i ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        }
        if (i == 0) {
            if (mk.isEmpty() || System.currentTimeMillis() - marketLoadedAt > 10 * 60_000) loadMarket();
            if (resumed) startMarketFeed();
        } else {
            stopMarketFeed();
        }
        if (i == 2) {
            renderSignals(true);
            renderAlerts();
        }
        refreshStatus();
    }

    // ============================================================ MARKET tab
    private void buildMarket() {
        LinearLayout col = pageColumn(0);
        updateBanner = card(col, GREEN);
        updateBanner.setVisibility(View.GONE);
        LinearLayout top = card(col);
        LinearLayout tr = row();
        tr.addView(bold("Market Overview", 18, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView rf = chip("↻ Refresh", false);
        rf.setOnClickListener(v -> loadMarket());
        tr.addView(rf);
        top.addView(tr);
        fgGauge = new GaugeView(this);
        fgGauge.set(-1, "Fear & Greed", "load ho raha hai...");
        top.addView(fgGauge, new LinearLayout.LayoutParams(-1, dp(170)));
        btcView = bold("BTC —", 16, TEXT);
        top.addView(btcView);
        globalView = text("", 13, MUTED);
        top.addView(globalView);

        LinearLayout lc = card(col);
        marketSearch = input("🔎 Coin search karein (jaise PEPE, SUI, WIF)", "",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        marketSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) {
                marketLimit = 50;
                renderMarket();
            }
        });
        lc.addView(marketSearch);
        LinearLayout modes = row();
        String[] names = {"🚀 Gainers", "📉 Losers", "🔥 Volume", "🔤 A–Z", "⭐ Watchlist"};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            modeChips[i] = chip(names[i], i == marketMode);
            modeChips[i].setOnClickListener(v -> {
                marketMode = idx;
                marketLimit = 50;
                for (int k = 0; k < names.length; k++) styleChip(modeChips[k], k == marketMode);
                renderMarket();
            });
            modes.addView(modeChips[i], chipLp());
        }
        lc.addView(hscroll(modes));
        marketCount = text("", 12, MUTED);
        lc.addView(marketCount);
        marketList = column();
        lc.addView(marketList);
    }

    private void loadMarket() {
        btcView.setText("Load ho raha hai...");
        btcView.setTextColor(TEXT);
        pool.execute(() -> {
            try {
                final JSONArray tick = new JSONArray(Scanner.get("/api/v3/ticker/24hr?type=MINI"));
                final String[] fg = SmartMoney.fearGreed();
                final JSONObject global = fetchGlobal();
                runOnUiThread(() -> {
                    mk.clear();
                    for (int i = 0; i < tick.length(); i++) {
                        JSONObject o = tick.optJSONObject(i);
                        if (o == null) continue;
                        String s = o.optString("symbol");
                        if (!Scanner.isTradable(s) || o.optDouble("lastPrice", 0) <= 0) continue;
                        mk.put(s, new double[]{o.optDouble("lastPrice", 0), o.optDouble("openPrice", 0), o.optDouble("quoteVolume", 0)});
                    }
                    marketLoadedAt = System.currentTimeMillis();
                    renderOverview(fg, global);
                    renderMarket();
                });
            } catch (Exception e) {
                final String msg = e.getMessage();
                runOnUiThread(() -> btcView.setText("Market load nahi hua: " + msg + "\nInternet check karke Refresh dabayen"));
            }
        });
    }

    private static JSONObject fetchGlobal() {
        try {
            return new JSONObject(Scanner.getAbsolute("https://api.coingecko.com/api/v3/global")).getJSONObject("data");
        } catch (Exception e) {
            return null;
        }
    }

    private static double change(double[] v) {
        return v[1] > 0 ? (v[0] / v[1] - 1) * 100 : 0;
    }

    private void renderOverview(String[] fg, JSONObject g) {
        if (fg != null) {
            int v = -1;
            try { v = Integer.parseInt(fg[0]); } catch (Exception ignored) { }
            fgGauge.set(v, fg[1], "Fear & Greed Index (poori market ka mood)");
        } else {
            fgGauge.set(-1, "Fear & Greed", "data nahi mila");
        }
        updateBtcLine();
        if (g != null) {
            StringBuilder s = new StringBuilder();
            JSONObject tm = g.optJSONObject("total_market_cap");
            if (tm != null) s.append("Total market cap: ").append(Fmt.usd(tm.optDouble("usd", 0)));
            s.append(String.format(Locale.US, " (%+.2f%% 24h)", g.optDouble("market_cap_change_percentage_24h_usd", 0)));
            JSONObject mcp = g.optJSONObject("market_cap_percentage");
            if (mcp != null) s.append(String.format(Locale.US, "\nBTC dominance: %.1f%% · ETH: %.1f%%",
                    mcp.optDouble("btc", 0), mcp.optDouble("eth", 0)));
            globalView.setText(s.toString());
        } else {
            globalView.setText("CoinGecko global data abhi nahi mila");
        }
    }

    private void updateBtcLine() {
        double[] btc = mk.get("BTCUSDT");
        if (btc == null) return;
        double ch = change(btc);
        btcView.setText("₿ BTC  $" + Fmt.price(btc[0]) + "   " + Fmt.pct(ch) + " (24h)  ● live");
        btcView.setTextColor(ch >= 0 ? GREEN : RED);
    }

    private void renderMarket() {
        marketList.removeAllViews();
        rowViews.clear();
        if (mk.isEmpty()) return;
        String q = marketSearch.getText().toString().trim().toUpperCase(Locale.US).replace("/", "").replace("USDT", "");
        List<String> list = new ArrayList<>();
        if (marketMode == 4) {
            for (String s : Prefs.watchlist(this)) if (mk.containsKey(s)) list.add(s);
        } else {
            for (Map.Entry<String, double[]> e : mk.entrySet()) {
                String s = e.getKey();
                if (!q.isEmpty()) {
                    if (!base(s).contains(q)) continue;
                } else if (marketMode != 3 && e.getValue()[2] < 1_000_000) continue;
                list.add(s);
            }
            if (marketMode == 0) Collections.sort(list, (a, b) -> Double.compare(change(mk.get(b)), change(mk.get(a))));
            else if (marketMode == 1) Collections.sort(list, (a, b) -> Double.compare(change(mk.get(a)), change(mk.get(b))));
            else if (marketMode == 2) Collections.sort(list, (a, b) -> Double.compare(mk.get(b)[2], mk.get(a)[2]));
            else Collections.sort(list);
            if (!q.isEmpty()) {
                // exact match first
                final String qq = q;
                Collections.sort(list, (a, b) -> Boolean.compare(!base(a).equals(qq), !base(b).equals(qq)));
            }
        }
        marketCount.setText(list.size() + " coins Binance par" + (q.isEmpty() ? "" : " · search: " + q)
                + " · prices live update hoti hain");
        if (list.isEmpty()) {
            marketList.addView(text(marketMode == 4 ? "Watchlist khali hai — Analyze tab mein ☆ dabayen" : "Koi coin nahi mila", 13, MUTED));
            return;
        }
        for (int i = 0; i < list.size() && i < marketLimit; i++) marketList.addView(coinRow(list.get(i), i + 1));
        if (list.size() > marketLimit) {
            TextView more = chip("⬇ Aur coins dikhayen (" + (list.size() - marketLimit) + " baqi)", false);
            more.setOnClickListener(v -> {
                marketLimit += 50;
                renderMarket();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(10);
            marketList.addView(more, lp);
        }
    }

    private View coinRow(final String sym, int rank) {
        double[] v = mk.get(sym);
        double ch = change(v);
        LinearLayout r = row();
        r.setPadding(0, dp(10), 0, dp(10));
        r.addView(text(String.valueOf(rank), 12, MUTED), new LinearLayout.LayoutParams(dp(30), -2));
        LinearLayout nm = column();
        nm.addView(bold(base(sym), 15, TEXT));
        nm.addView(text("Vol " + Fmt.usd(v[2]), 11, MUTED));
        r.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
        TextView pr = text("$" + Fmt.price(v[0]), 14, TEXT);
        pr.setPadding(dp(6), dp(3), dp(6), dp(3));
        r.addView(pr);
        TextView pc = bold(Fmt.pct(ch), 13, 0xFFFFFFFF);
        pc.setGravity(Gravity.CENTER);
        pc.setPadding(dp(6), dp(5), dp(6), dp(5));
        pc.setBackground(round(ch >= 0 ? GREEN : RED, 8, 0));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(dp(84), -2);
        plp.leftMargin = dp(4);
        r.addView(pc, plp);
        r.setOnClickListener(x -> openAnalyze(sym));
        rowViews.put(sym, new TextView[]{pr, pc});
        LinearLayout wrap = column();
        wrap.addView(r);
        wrap.addView(divider());
        return wrap;
    }

    private void startMarketFeed() {
        if (marketWs != null) return;
        marketWs = new WsStream("/ws/!miniTicker@arr", new WsStream.Callback() {
            @Override
            public void onText(String text) {
                try {
                    JSONArray a = new JSONArray(text);
                    synchronized (pendingMini) {
                        for (int i = 0; i < a.length(); i++) {
                            JSONObject o = a.getJSONObject(i);
                            String s = o.optString("s");
                            if (!s.endsWith("USDT")) continue;
                            pendingMini.put(s, new double[]{num(o, "c"), num(o, "o"), num(o, "q")});
                        }
                    }
                } catch (Exception ignored) {
                }
            }

            @Override
            public void onStatus(boolean live) { }
        }).start();
    }

    private void stopMarketFeed() {
        if (marketWs != null) marketWs.stop();
        marketWs = null;
    }

    /** Pushes live mini-ticker prices into the market list (flash green/red on change). */
    private void applyMarketLive() {
        Map<String, double[]> upd;
        synchronized (pendingMini) {
            if (pendingMini.isEmpty()) return;
            upd = new HashMap<>(pendingMini);
            pendingMini.clear();
        }
        for (Map.Entry<String, double[]> e : upd.entrySet()) {
            String s = e.getKey();
            double[] nv = e.getValue();
            double[] old = mk.get(s);
            if (old == null) {
                if (Scanner.isTradable(s) && nv[0] > 0) mk.put(s, nv);
                continue;
            }
            double prev = old[0];
            mk.put(s, nv);
            TextView[] tv = rowViews.get(s);
            if (tv != null && nv[0] != prev) {
                final TextView pr = tv[0];
                pr.setText("$" + Fmt.price(nv[0]));
                pr.setBackground(round(nv[0] > prev ? 0x550ECB81 : 0x55F6465D, 6, 0));
                handler.postDelayed(() -> pr.setBackground(null), 350);
                double ch = change(nv);
                tv[1].setText(Fmt.pct(ch));
                tv[1].setBackground(round(ch >= 0 ? GREEN : RED, 8, 0));
            }
        }
        updateBtcLine();
    }

    // ============================================================ ANALYZE tab
    private void buildAnalyze() {
        LinearLayout col = pageColumn(1);

        LinearLayout mc = card(col, ACC);
        LinearLayout mr = row();
        for (int m = 0; m < 2; m++) {
            final int mm = m;
            TextView t = chip(Mode.label(m), m == uiMode);
            if (m == uiMode) t.setBackground(round(Mode.accent(m), 20, Mode.accent(m)));
            t.setOnClickListener(v -> switchMode(mm));
            mr.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
            if (m == 0) mr.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        }
        mc.addView(mr);
        mc.addView(text(Mode.desc(uiMode), 12, ACC2));

        LinearLayout sc = card(col);
        sc.addView(bold("🔍 Apna coin analyze karein", 17, TEXT));
        LinearLayout sr = row();
        searchEt = input("SOL, PEPE, BTC...", base(currentSym), InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        sr.addView(searchEt, new LinearLayout.LayoutParams(0, -2, 1));
        TextView go = chip("Analyze", true);
        go.setOnClickListener(v -> {
            String s = searchEt.getText().toString().trim();
            if (s.isEmpty()) return;
            hideKeyboard();
            runAnalysis(CoinReport.normalize(s));
        });
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(-2, -2);
        glp.leftMargin = dp(8);
        sr.addView(go, glp);
        starBtn = chip("☆", false);
        starBtn.setOnClickListener(v -> {
            boolean on = Prefs.toggleWatch(this, currentSym);
            updateStar();
            renderWatchRow();
            toast(on ? "Watchlist mein add — bot isay hamesha scan karega" : "Watchlist se hata diya");
        });
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-2, -2);
        slp.leftMargin = dp(8);
        sr.addView(starBtn, slp);
        sc.addView(sr);
        sc.addView(text("⭐ Watchlist (tap = analysis):", 12, MUTED));
        watchRow = row();
        sc.addView(hscroll(watchRow));

        // ---- live chart card
        LinearLayout cc = card(col, ACC);
        LinearLayout th = row();
        chartTitle = bold(base(currentSym) + "/USDT", 16, TEXT);
        th.addView(chartTitle, new LinearLayout.LayoutParams(0, -2, 1));
        livePrice = bold("", 16, TEXT);
        th.addView(livePrice);
        cc.addView(th);
        LinearLayout tr = row();
        tr.setPadding(0, dp(6), 0, dp(4));
        for (int i = 0; i < chartTfs.length; i++) {
            final String tf = chartTfs[i];
            tfChips[i] = chip(tf, tf.equals(chartTf));
            tfChips[i].setOnClickListener(v -> selectTf(tf));
            tr.addView(tfChips[i], chipLp());
        }
        TextView fs = chip("⛶ Full", false);
        fs.setOnClickListener(v -> openFullscreen());
        TextView lv = chip("⏩ Live", false);
        lv.setOnClickListener(v -> chart.goLive());
        TextView zo = chip("−", false);
        zo.setOnClickListener(v -> chart.zoom(30));
        TextView zi = chip("+", false);
        zi.setOnClickListener(v -> chart.zoom(-30));
        tr.addView(fs, chipLp());
        tr.addView(lv, chipLp());
        tr.addView(zo, chipLp());
        tr.addView(zi, chipLp());
        cc.addView(hscroll(tr));
        LinearLayout lr = row();
        lr.setPadding(0, 0, 0, dp(6));
        for (int i = 0; i < LAYERS.length; i++) {
            final int idx = i;
            layerChips[i] = chip(LAYERS[i], Prefs.layer(this, LAYERS[i]));
            layerChips[i].setTextSize(11);
            layerChips[i].setOnClickListener(v -> {
                boolean on = !Prefs.layer(this, LAYERS[idx]);
                Prefs.setLayer(this, LAYERS[idx], on);
                styleChip(layerChips[idx], on);
                applyLayers();
            });
            lr.addView(layerChips[i], chipLp());
        }
        cc.addView(hscroll(lr));
        chart = new ChartView(this);
        chart.setAccent(ACC);
        applyLayers();
        cc.addView(chart, new LinearLayout.LayoutParams(-1, dp(480)));
        cc.addView(text("👆 Ungli se khiskayen = purane candles · 2 ungliyon se zoom · daba kar rakhen = candle detail · "
                + "🟢🔴 bubbles = whale orders (live) · W = whale candle · neeli/narangi bindi = retail crowd", 11, MUTED));

        // ---- live order flow card
        LinearLayout oc = card(col, ACC2);
        oc.addView(bold("⚡ Live order flow — whales vs retail", 16, TEXT));
        oc.addView(text("Har order usi waqt dikhta hai. 🐋 = whale, 🐬 = bada trader, 🐟 = retail. "
                + "Order book mein sunehri line = bada wall (🐋).", 12, MUTED));
        tape = new TapeView(this);
        oc.addView(tape, new LinearLayout.LayoutParams(-1, dp(250)));
        oc.addView(divider());
        book = new BookView(this);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, dp(240));
        blp.topMargin = dp(8);
        oc.addView(book, blp);

        resultBox = column();
        col.addView(resultBox);
        LinearLayout hint = card(resultBox);
        hint.addView(bold("Kya milega?", 15, TEXT));
        hint.addView(text("Coin likh kar Analyze dabayen. Bot sab mila kar hamesha ek saaf faisla deta hai — BUY ya SELL "
                + "(confidence % ke saath):\n"
                + "• Technical: " + String.join(", ", Mode.tfs(uiMode)) + "\n"
                + "• Chart patterns: triangle, wedge, channel, double top/bottom, breakout, Fibonacci, RSI divergence\n"
                + "• Paisa aa raha ya nikal raha: 10 exchanges ka volume + ETF inflow/outflow + on-chain\n"
                + "• Whales vs retail, order book walls\n"
                + "• Futures ke top traders, open interest, funding\n"
                + "• News, CoinGecko community, Fear & Greed\n"
                + "• 🤖 Claude AI se Roman Urdu mein trade plan aur sawal-jawab", 13, SOFT));
        updateStar();
        renderWatchRow();
    }

    private void selectTf(String tf) {
        chartTf = tf;
        for (int k = 0; k < chartTfs.length; k++) styleChip(tfChips[k], chartTfs[k].equals(chartTf));
        loadChart();
    }

    private void applyLayers() {
        chart.setLayers(Prefs.layer(this, "Fib"), Prefs.layer(this, "Lines"), Prefs.layer(this, "Zones"),
                Prefs.layer(this, "VolProfile"), Prefs.layer(this, "Whales"), Prefs.layer(this, "RSI"));
    }

    private void openFullscreen() {
        if (fsOverlay != null) return;
        chartParent = (ViewGroup) chart.getParent();
        chartIndex = chartParent.indexOfChild(chart);
        chartLp = chart.getLayoutParams();
        chartParent.removeView(chart);

        fsOverlay = column();
        fsOverlay.setBackgroundColor(Mode.bgTop(uiMode));
        fsOverlay.setPadding(dp(6), dp(6), dp(6), dp(6));
        LinearLayout bar = row();
        bar.addView(bold(base(currentSym) + "/USDT", 15, TEXT), new LinearLayout.LayoutParams(-2, -2));
        LinearLayout chips = row();
        chips.setPadding(dp(8), 0, 0, 0);
        for (String tf : chartTfs) {
            final String t = tf;
            TextView c = chip(tf, tf.equals(chartTf));
            c.setOnClickListener(v -> {
                selectTf(t);
                closeFullscreen();
                openFullscreen();
            });
            chips.addView(c, chipLp());
        }
        TextView lv = chip("⏩ Live", false);
        lv.setOnClickListener(v -> chart.goLive());
        TextView rot = chip("⟳ Ghumayen", false);
        rot.setOnClickListener(v -> setRequestedOrientation(
                getResources().getDisplayMetrics().widthPixels > getResources().getDisplayMetrics().heightPixels
                        ? ActivityInfo.SCREEN_ORIENTATION_PORTRAIT : ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE));
        TextView x = chip("✕", true);
        x.setOnClickListener(v -> closeFullscreen());
        chips.addView(lv, chipLp());
        chips.addView(rot, chipLp());
        chips.addView(x, chipLp());
        bar.addView(hscroll(chips), new LinearLayout.LayoutParams(0, -2, 1));
        fsOverlay.addView(bar);
        fsOverlay.addView(chart, new LinearLayout.LayoutParams(-1, 0, 1));
        rootFrame.addView(fsOverlay, new FrameLayout.LayoutParams(-1, -1));
    }

    private void closeFullscreen() {
        if (fsOverlay == null) return;
        fsOverlay.removeView(chart);
        rootFrame.removeView(fsOverlay);
        fsOverlay = null;
        chartParent.addView(chart, chartIndex, chartLp);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }

    private void updateStar() {
        boolean on = Prefs.inWatchlist(this, currentSym);
        starBtn.setText(on ? "★" : "☆");
        styleChip(starBtn, on);
    }

    private void renderWatchRow() {
        watchRow.removeAllViews();
        for (String s : Prefs.watchlist(this)) {
            final String sym = s;
            TextView c = chip(base(s), false);
            c.setOnClickListener(v -> openAnalyze(sym));
            watchRow.addView(c, chipLp());
        }
    }

    private void openAnalyze(String sym) {
        showTab(1);
        searchEt.setText(base(sym));
        pages[1].scrollTo(0, 0);
        runAnalysis(sym);
    }

    /** Loads candles + recent whale trades, runs the pattern engine, then switches the chart to LIVE. */
    private void loadChart() {
        final String sym = currentSym, tf = chartTf;
        final double whaleUsd = Prefs.whaleUsd(this);
        stopCoinFeed();
        chart.setMessage("Chart aur patterns load ho rahe hain...");
        chart.setPlan(false, true, 0, 0, 0, 0);
        tape.clear();
        book.set(new double[0][], new double[0][]);
        livePrice.setText("");
        pool.execute(() -> {
            try {
                final Candles c = Candles.fetch(sym, tf, 300, false);
                final PatternEngine.Result p = PatternEngine.analyze(c.closedOnly(), Math.min(150, c.n));
                final double[] wb = new double[c.n], ws = new double[c.n];
                final double thr = fillWhales(sym, c, wb, ws, whaleUsd, tf.endsWith("m") ? 3 : 1);
                double open24 = 0;
                try {
                    open24 = new JSONObject(Scanner.get("/api/v3/ticker/24hr?symbol=" + sym)).optDouble("openPrice", 0);
                } catch (Exception ignored) {
                }
                final double o24 = open24;
                runOnUiThread(() -> {
                    if (!sym.equals(currentSym) || !tf.equals(chartTf)) return;
                    chartWhaleThr = thr;
                    dayOpen = o24;
                    tape.setWhaleThreshold(thr);
                    chart.setData(c, p, wb, ws, tf, tf.endsWith("m"));
                    if (lastReport != null && lastReport.symbol.equals(sym)) applyPlan(lastReport);
                    if (resumed) startCoinFeed();
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> chart.setMessage("Chart nahi mila: " + m));
            }
        });
    }

    /** Puts big trades (>= threshold) from the latest aggTrades pages onto their candles. Returns the threshold. */
    private static double fillWhales(String sym, Candles c, double[] wb, double[] ws, double whaleUsd, int pages) {
        double qv = 0;
        for (int i = Math.max(0, c.n - 24); i < c.n; i++) qv += c.quoteVol[i];
        double thr = Math.min(whaleUsd, Math.max(5000, qv / Math.max(1, Math.min(24, c.n)) / 40));
        try {
            long fromId = -1;
            for (int pg = 0; pg < pages; pg++) {
                String q = "/api/v3/aggTrades?symbol=" + sym + "&limit=1000" + (fromId >= 0 ? "&fromId=" + fromId : "");
                JSONArray tr = new JSONArray(Scanner.get(q));
                if (tr.length() == 0) break;
                long firstId = Long.MAX_VALUE;
                for (int i = 0; i < tr.length(); i++) {
                    JSONObject o = tr.getJSONObject(i);
                    firstId = Math.min(firstId, o.optLong("a"));
                    double usd = Double.parseDouble(o.getString("p")) * Double.parseDouble(o.getString("q"));
                    if (usd < thr) continue;
                    int idx = c.indexOf(o.optLong("T"));
                    if (idx < 0) continue;
                    if (o.optBoolean("m")) ws[idx] += usd; else wb[idx] += usd;
                }
                fromId = firstId - 1000;
                if (fromId < 0) break;
            }
        } catch (Exception ignored) {
        }
        return thr;
    }

    // ------------------------------------------------------------ live coin stream
    private void startCoinFeed() {
        stopCoinFeed();
        final String sym = currentSym, tf = chartTf;
        liveSym = sym;
        liveTf = tf;
        synchronized (liveLock) {
            pendingKline = null;
            pendingTrades.clear();
            pendingBids = pendingAsks = null;
            candleClosed = false;
        }
        String s = sym.toLowerCase(Locale.US);
        coinWs = new WsStream("/stream?streams=" + s + "@kline_" + tf + "/" + s + "@aggTrade/" + s + "@depth20",
                new WsStream.Callback() {
                    @Override
                    public void onText(String text) { parseCoin(text); }

                    @Override
                    public void onStatus(boolean live) { coinLive = live; }
                }).start();
    }

    private void stopCoinFeed() {
        if (coinWs != null) coinWs.stop();
        coinWs = null;
        coinLive = false;
    }

    /** Runs on the WebSocket thread: just parse and park the data; the UI applies it every 400 ms. */
    private void parseCoin(String text) {
        try {
            JSONObject o = new JSONObject(text);
            String st = o.optString("stream");
            JSONObject d = o.optJSONObject("data");
            if (d == null) return;
            if (st.contains("@kline")) {
                JSONObject k = d.optJSONObject("k");
                if (k == null) return;
                double[] kl = {k.optLong("t"), num(k, "o"), num(k, "h"), num(k, "l"), num(k, "c"), num(k, "v"),
                        num(k, "q"), num(k, "V"), num(k, "Q"), k.optLong("n"), k.optBoolean("x") ? 1 : 0};
                synchronized (liveLock) {
                    pendingKline = kl;
                    if (kl[10] == 1) candleClosed = true;
                }
            } else if (st.contains("@aggTrade")) {
                double p = num(d, "p"), q = num(d, "q");
                synchronized (liveLock) {
                    if (pendingTrades.size() < 4000) pendingTrades.add(new double[]{d.optLong("T"), p, p * q, d.optBoolean("m") ? 1 : 0});
                }
            } else if (st.contains("@depth")) {
                JSONArray b = d.optJSONArray("bids"), a = d.optJSONArray("asks");
                if (b == null || a == null) return;
                double[][] bb = new double[b.length()][], aa = new double[a.length()][];
                for (int i = 0; i < b.length(); i++) {
                    JSONArray x = b.getJSONArray(i);
                    bb[i] = new double[]{Double.parseDouble(x.getString(0)), Double.parseDouble(x.getString(1))};
                }
                for (int i = 0; i < a.length(); i++) {
                    JSONArray x = a.getJSONArray(i);
                    aa[i] = new double[]{Double.parseDouble(x.getString(0)), Double.parseDouble(x.getString(1))};
                }
                synchronized (liveLock) {
                    pendingBids = bb;
                    pendingAsks = aa;
                }
            }
        } catch (Exception ignored) {
        }
    }

    /** UI thread, every 400 ms: move live candles / trades / order book onto the screen. */
    private void applyLive() {
        double[] kl;
        List<double[]> trs;
        double[][] b, a;
        boolean closed;
        synchronized (liveLock) {
            kl = pendingKline;
            pendingKline = null;
            trs = new ArrayList<>(pendingTrades);
            pendingTrades.clear();
            b = pendingBids;
            a = pendingAsks;
            pendingBids = pendingAsks = null;
            closed = candleClosed;
            candleClosed = false;
        }
        if (coinWs == null || !currentSym.equals(liveSym) || !chartTf.equals(liveTf)) return;
        Candles cur = chart.getData();
        if (kl != null && cur != null) {
            Candles nc = cur.live((long) kl[0], kl[1], kl[2], kl[3], kl[4], kl[5], kl[6], kl[7], kl[8], kl[9]);
            if (nc != null) chart.liveCandles(nc);
            double p = kl[4];
            String ch = dayOpen > 0 ? "  " + Fmt.pct((p / dayOpen - 1) * 100) : "";
            livePrice.setText("$" + Fmt.price(p) + ch);
            livePrice.setTextColor(dayOpen > 0 && p < dayOpen ? RED : GREEN);
        }
        for (double[] t : trs) {
            boolean sell = t[3] == 1;
            if (t[2] >= chartWhaleThr) chart.liveTrade((long) t[0], t[2], sell);
            tape.add(TapeView.trade((long) t[0], t[1], t[2], sell));
        }
        tape.invalidate();
        if (b != null) book.set(b, a);
        chart.setLiveText(coinLive ? "● LIVE" : "○ connect ho raha hai...");
        if (closed && chart.getData() != null) {
            final Candles snap = chart.getData().closedOnly();
            final String sym = currentSym, tf = chartTf;
            pool.execute(() -> {
                final PatternEngine.Result p = PatternEngine.analyze(snap, Math.min(150, snap.n));
                runOnUiThread(() -> {
                    if (sym.equals(currentSym) && tf.equals(chartTf)) chart.setPatterns(p);
                });
            });
        }
    }

    // ------------------------------------------------------------ full analysis
    private void runAnalysis(String sym) {
        boolean newCoin = !sym.equals(currentSym) || chart.getData() == null;
        currentSym = sym;
        lastReport = null;
        Prefs.setLastCoin(this, sym);
        updateStar();
        chartTitle.setText(base(sym) + "/USDT");
        if (newCoin) loadChart();
        else chart.setPlan(false, true, 0, 0, 0, 0);
        resultBox.removeAllViews();
        LinearLayout wait = card(resultBox, ACC);
        wait.addView(bold("⏳ " + base(sym) + " ka " + Mode.label(uiMode) + " analysis ho raha hai...", 15, ACC));
        wait.addView(text("Binance (" + String.join(", ", Mode.tfs(uiMode)) + "), 10 exchanges ka volume, ETF flows, on-chain, "
                + "chart patterns, whales, futures, news aur sentiment se data jama ho raha hai. 15–30 second lag sakte hain.", 13, MUTED));
        final String key = Prefs.glassKey(this);
        final double wu = Prefs.whaleUsd(this);
        final int mode = uiMode;
        pool.execute(() -> {
            try {
                final CoinReport r = CoinReport.build(sym, mode, key, wu, true);
                runOnUiThread(() -> {
                    if (sym.equals(currentSym)) showReport(r);
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> {
                    if (!sym.equals(currentSym)) return;
                    resultBox.removeAllViews();
                    LinearLayout c = card(resultBox, RED);
                    c.addView(bold("❌ Analysis nahi ho saka", 15, RED));
                    c.addView(text(m == null ? "Internet check karein" : m, 13, SOFT));
                    c.addView(text("Coin ka naam sahi likhein (jaise SOL, PEPE, WIF). Market tab mein search karke bhi dhoond sakte hain.", 12, MUTED));
                });
            }
        });
    }

    private String pctFrom(double v, double p) {
        return p > 0 ? String.format(Locale.US, "  (%+.1f%%)", (v / p - 1) * 100) : "";
    }

    private void applyPlan(CoinReport r) {
        boolean showPlan = r.isBuy || r.mode == Mode.SCALP;
        chart.setPlan(showPlan && r.atr > 0, r.isBuy, r.price, r.stop, r.target1, r.target2);
    }

    private void showReport(final CoinReport r) {
        lastReport = r;
        resultBox.removeAllViews();
        chartTitle.setText(r.name + " · " + r.base + "/USDT");
        boolean scalp = r.mode == Mode.SCALP;
        boolean showPlan = r.isBuy || scalp;
        applyPlan(r);
        int vc = r.isBuy ? GREEN : RED;

        LinearLayout h = card(resultBox, vc);
        LinearLayout hr = row();
        hr.addView(bold("🎯 Final signal", 16, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView mb = bold(Mode.label(r.mode), 11, INK);
        mb.setPadding(dp(8), dp(3), dp(8), dp(3));
        mb.setBackground(round(ACC, 10, 0));
        hr.addView(mb);
        h.addView(hr);
        TextView big = bold((r.isBuy ? "▲ " : "▼ ") + r.verdict, 30, vc);
        big.setGravity(Gravity.CENTER);
        big.setLetterSpacing(0.05f);
        h.addView(big);
        TextView conf = bold("Confidence " + r.confidence + "%  ·  Score " + r.total + "/100", 13, TEXT);
        conf.setGravity(Gravity.CENTER);
        h.addView(conf);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, dp(10));
        clp.topMargin = dp(6);
        clp.bottomMargin = dp(6);
        h.addView(bar(r.confidence, vc, 0xFF243049), clp);
        TextView vt = text(r.verdictText, 14, SOFT);
        vt.setGravity(Gravity.CENTER);
        h.addView(vt);
        GaugeView g = new GaugeView(this);
        g.set(r.total, r.isBuy ? "BUY side" : "SELL side", "0 = full sell · 100 = full buy");
        h.addView(g, new LinearLayout.LayoutParams(-1, dp(165)));
        TextView rf = chip("↻ Dobara analysis (taaza data)", false);
        rf.setOnClickListener(v -> runAnalysis(r.symbol));
        h.addView(rf);

        // ---- Claude AI
        aiCard(r);

        LinearLayout f = card(resultBox);
        f.addView(bold("💰 Paisa aa raha ya nikal raha? (" + Mode.flowSpan(r.mode) + ")", 16, TEXT));
        f.addView(bold(r.flowLabel, 17, r.flowSign > 0 ? GREEN : r.flowSign < 0 ? RED : YELLOW));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, dp(14));
        blp.topMargin = dp(8);
        f.addView(bar(r.buyPct, GREEN, RED), blp);
        LinearLayout lr = row();
        lr.addView(text(String.format(Locale.US, "Buyers %.0f%%", r.buyPct), 12, GREEN), new LinearLayout.LayoutParams(0, -2, 1));
        lr.addView(text(String.format(Locale.US, "Sellers %.0f%%", 100 - r.buyPct), 12, RED));
        f.addView(lr);
        f.addView(text("Live 60 second ka hisaab upar 'Live order flow' card mein har waqt update hota hai.", 12, MUTED));

        tradePlan(r, showPlan);

        for (CoinReport.Section s : r.sections) sectionCard(s);

        if (!r.news.isEmpty()) {
            LinearLayout n = card(resultBox);
            n.addView(bold("📰 Taaza khabrein — " + r.name, 16, TEXT));
            for (String[] it : r.news) {
                String tone = "+".equals(it[3]) ? "🟢 " : "-".equals(it[3]) ? "🔴 " : "⚪ ";
                TextView t = text(tone + it[0], 13, TEXT);
                t.setPadding(0, dp(6), 0, 0);
                final String link = it[1];
                t.setOnClickListener(v -> openUrl(link));
                n.addView(t);
                n.addView(text(it[2] + " · tap karke parhen", 11, MUTED));
            }
        }

        LinearLayout al = card(resultBox, ACC2);
        al.addView(bold("🔔 Price alert lagayen", 16, TEXT));
        al.addView(text("Price is level ko cross kare to notification aayegi (koi bhi bot ON hona chahiye).", 12, MUTED));
        LinearLayout ar = row();
        final EditText ap = input("Price", Fmt.price(r.isBuy ? r.target1 : r.stop), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        ar.addView(ap, new LinearLayout.LayoutParams(0, -2, 1));
        TextView ab = chip("Alert lagao", true);
        ab.setOnClickListener(v -> {
            double p = parse(ap, 0);
            if (p <= 0) { toast("Sahi price likhen"); return; }
            Prefs.addAlert(this, r.symbol, p, p > r.price);
            toast("Alert laga diya: " + r.base + (p > r.price ? " upar " : " neeche ") + "$" + Fmt.price(p));
            if (!Prefs.enabled(this)) toast("Yaad rahe: Signals tab se Scalp ya Spot bot ON karein");
        });
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-2, -2);
        alp.leftMargin = dp(8);
        ar.addView(ab, alp);
        al.addView(ar);

        LinearLayout act = card(resultBox);
        Button bin = button("Binance par " + r.base + " kholen", ACC, INK, 0);
        bin.setOnClickListener(v -> openUrl("https://www.binance.com/en/trade/" + r.base + "_USDT?type=spot"));
        act.addView(bin);
        act.addView(text("⚠️ Yeh analysis maloomat ke liye hai, financial advice nahi. Chart patterns aur whale markers "
                + "computer ka andaza hain — 100% sahi nahi hote. Hamesha stop-loss lagayen aur utna hi lagayen jitna "
                + "khona bardasht ho.", 12, MUTED));
    }

    // ------------------------------------------------------------ Claude AI
    private String liveExtras() {
        StringBuilder sb = new StringBuilder("\n[LIVE ORDER FLOW right now]\n");
        double[] p = tape.pressure();
        sb.append("- Last 60s aggressive buy ").append(Fmt.usd(p[0])).append(" vs sell ").append(Fmt.usd(p[1])).append('\n');
        sb.append("- Last 5min whale buy ").append(Fmt.usd(p[4])).append(" vs whale sell ").append(Fmt.usd(p[5]))
                .append(" (whale = trade >= ").append(Fmt.usd(chartWhaleThr)).append(")\n");
        double[] s = book.sums();
        sb.append("- Order book top 10: bids ").append(Fmt.usd(s[0])).append(" vs asks ").append(Fmt.usd(s[1])).append('\n');
        Candles c = chart.getData();
        if (c != null && c.n > 0) sb.append("- Live price ").append(Fmt.price(c.close[c.n - 1])).append(" on ").append(chartTf).append(" chart\n");
        return sb.toString();
    }

    private void aiCard(final CoinReport r) {
        LinearLayout ai = card(resultBox, CLAUDE);
        LinearLayout hr = row();
        hr.addView(bold("🤖 Claude AI Analyst", 16, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView m = bold(Prefs.claudeModel(this).replace("claude-", ""), 10, INK);
        m.setPadding(dp(6), dp(2), dp(6), dp(2));
        m.setBackground(round(CLAUDE, 8, 0));
        hr.addView(m);
        ai.addView(hr);
        ai.addView(text("Claude upar ka saara live data parh kar Roman Urdu mein trade plan likhega. Aap apne sawal bhi pooch sakte hain.", 12, MUTED));
        final LinearLayout chat = column();
        ai.addView(chat);
        final List<String[]> history = new ArrayList<>();
        TextView full = chip("✨ Claude se poora analysis likhwayen", true);
        full.setBackground(round(CLAUDE, 20, CLAUDE));
        full.setOnClickListener(v -> askClaude(r, chat, history,
                "Is coin ka poora analysis karo: direction (BUY/SELL), entry, stop-loss, 2 targets, risk, aur kis cheez se idea ghalat sabit hoga.", true));
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(-1, -2);
        flp.topMargin = dp(8);
        ai.addView(full, flp);
        LinearLayout qr = row();
        final EditText q = input("Sawal likhen (jaise: kya abhi entry lun?)", "", InputType.TYPE_CLASS_TEXT);
        qr.addView(q, new LinearLayout.LayoutParams(0, -2, 1));
        TextView ask = chip("Poochen", false);
        ask.setOnClickListener(v -> {
            String s = q.getText().toString().trim();
            if (s.isEmpty()) return;
            q.setText("");
            hideKeyboard();
            askClaude(r, chat, history, s, history.isEmpty());
        });
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-2, -2);
        alp.leftMargin = dp(8);
        qr.addView(ask, alp);
        ai.addView(qr);
    }

    private TextView bubble(String s, boolean user) {
        TextView t = text(s, 13, user ? TEXT : SOFT);
        t.setPadding(dp(10), dp(8), dp(10), dp(8));
        t.setBackground(round(user ? 0xFF243049 : 0x22D97757, 12, user ? 0 : 0x66D97757));
        t.setTextIsSelectable(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(8);
        t.setLayoutParams(lp);
        return t;
    }

    private void askClaude(final CoinReport r, final LinearLayout chat, final List<String[]> history, String question, boolean withData) {
        final String key = Prefs.claudeKey(this);
        if (key.isEmpty()) {
            chat.addView(bubble("🔑 Pehle ⚙️ Settings mein apni Claude API key daalein.\nKey console.anthropic.com se milti hai "
                    + "(Anthropic ka developer account — is ka kharcha alag se lagta hai, har sawal par thore cents).", false));
            return;
        }
        String content = withData || history.isEmpty()
                ? "LIVE DATA REPORT:\n" + r.toText() + liveExtras() + "\n\nSAWAL: " + question
                : question;
        history.add(new String[]{"user", content});
        chat.addView(bubble("🙋 " + question, true));
        final TextView thinking = bubble("🤖 Claude soch raha hai...", false);
        chat.addView(thinking);
        final String model = Prefs.claudeModel(this);
        final List<String[]> snap = new ArrayList<>(history);
        pool.execute(() -> {
            try {
                final String ans = ClaudeAI.ask(key, model, snap);
                runOnUiThread(() -> {
                    history.add(new String[]{"assistant", ans});
                    thinking.setText("🤖 " + ans);
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> {
                    if (!history.isEmpty()) history.remove(history.size() - 1);
                    thinking.setText("❌ Claude se jawab nahi aaya: " + m);
                    thinking.setTextColor(RED);
                });
            }
        });
    }

    private void tradePlan(final CoinReport r, boolean showPlan) {
        boolean scalp = r.mode == Mode.SCALP;
        LinearLayout p = card(resultBox, ACC);
        p.addView(bold("🧭 Trade plan — " + (r.isBuy ? (scalp ? "LONG scalp" : "Spot BUY") : (scalp ? "SHORT scalp (futures)" : "Spot: bechne / exit ka waqt")), 16, TEXT));
        p.addView(text("Support: $" + Fmt.price(r.support) + "   ·   Resistance: $" + Fmt.price(r.resistance), 13, SOFT));
        if (r.patterns != null && r.patterns.keyLevel > 0)
            p.addView(text("📐 Key level: $" + Fmt.price(r.patterns.keyLevel) + " · pattern target: $" + Fmt.price(r.patterns.target), 13, SOFT));
        if (!showPlan || r.atr <= 0) {
            p.addView(text("Spot mein SELL ka matlab: naya na khareedain. Holding ho to $" + Fmt.price(r.support)
                    + " ke neeche stop rakhen ya profit bacha lein. Wapas BUY tab jab score 50+ ho jaye.", 13, YELLOW));
            return;
        }
        p.addView(text("Entry: ~$" + Fmt.price(r.price), 14, TEXT));
        p.addView(text("Stop-loss: $" + Fmt.price(r.stop) + pctFrom(r.stop, r.price), 14, RED));
        p.addView(text("Target 1: $" + Fmt.price(r.target1) + pctFrom(r.target1, r.price) + "  (1 : 1.5)", 14, GREEN));
        p.addView(text("Target 2: $" + Fmt.price(r.target2) + pctFrom(r.target2, r.price) + "  (1 : 3)", 14, GREEN));
        p.addView(text("TP1 par aadha profit lein aur stop ko entry par le aayen. Yeh lines chart par bhi bani hain.", 12, MUTED));

        p.addView(divider());
        p.addView(bold("🧮 Position size calculator", 15, ACC2));
        LinearLayout rr = row();
        final EditText bal = input("Balance USDT", String.valueOf(Prefs.balance(this)), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        final EditText rp = input("Risk %", String.valueOf(Prefs.riskPct(this)), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        LinearLayout c1 = column();
        c1.addView(text("Balance (USDT)", 11, MUTED));
        c1.addView(bal);
        LinearLayout c2 = column();
        c2.addView(text("Risk per trade %", 11, MUTED));
        c2.addView(rp);
        rr.addView(c1, new LinearLayout.LayoutParams(0, -2, 1));
        rr.addView(new View(this), new LinearLayout.LayoutParams(dp(10), 1));
        rr.addView(c2, new LinearLayout.LayoutParams(0, -2, 1));
        p.addView(rr);
        final TextView out = text("", 13, TEXT);
        Runnable calc = () -> {
            double b = parse(bal, 0), pct = parse(rp, 1);
            Prefs.saveRisk(this, (float) b, (float) pct);
            double riskUsd = b * pct / 100;
            double perUnit = Math.abs(r.price - r.stop);
            if (perUnit <= 0 || b <= 0) { out.setText("Balance likhen"); return; }
            double qty = riskUsd / perUnit;
            double pos = qty * r.price;
            String lev = pos > b ? String.format(Locale.US, "\n⚠️ Position balance se badi hai — %.1fx leverage chahiye. Risk kam karein.", pos / b) : "";
            out.setText(String.format(Locale.US, "Agar stop lage to nuksan: $%.2f (%.1f%%)\nKhareedain: %s %s  ≈  $%.2f\nTP1 par faida ≈ $%.2f · TP2 par ≈ $%.2f%s",
                    riskUsd, pct, qty >= 1 ? String.format(Locale.US, "%.2f", qty) : String.format(Locale.US, "%.6f", qty), r.base, pos,
                    qty * Math.abs(r.target1 - r.price), qty * Math.abs(r.target2 - r.price), lev));
        };
        TextView cb = chip("Calculate", true);
        cb.setOnClickListener(v -> { hideKeyboard(); calc.run(); });
        LinearLayout.LayoutParams cblp = new LinearLayout.LayoutParams(-2, -2);
        cblp.topMargin = dp(6);
        p.addView(cb, cblp);
        p.addView(out);
        calc.run();
    }

    private void sectionCard(CoinReport.Section s) {
        boolean pat = s.icon.equals("📐");
        LinearLayout c = card(resultBox, pat ? ACC2 : STROKE);
        LinearLayout hr = row();
        hr.addView(bold(s.icon + "  " + s.title, 15, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        int col = !s.available ? MUTED : s.score > 15 ? GREEN : s.score < -15 ? RED : YELLOW;
        hr.addView(bold(s.available ? String.format(Locale.US, "%+d", s.score) : "N/A", 14, col));
        c.addView(hr);
        if (s.available) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(6));
            lp.topMargin = dp(6);
            lp.bottomMargin = dp(4);
            c.addView(bar((s.score + 100) / 2.0, col, 0xFF243049), lp);
        }
        for (String l : s.lines) c.addView(text("• " + l, 13, SOFT));
        if (pat) c.addView(text("👆 Yeh sab upar chart par lines, zones aur 🎯 arrow ki shakal mein bana hai.", 12, ACC2));
    }

    // ============================================================ in-app update
    private void checkForUpdate(final boolean manual) {
        if (manual && updStatus != null) updStatus.setText("Check ho raha hai...");
        pool.execute(() -> {
            try {
                final UpdateManager.Info in = UpdateManager.check(this);
                runOnUiThread(() -> {
                    if (in != null) {
                        showUpdate(in);
                        if (updStatus != null) updStatus.setText("🆕 Naya version available: " + in.title);
                    } else {
                        updateBanner.setVisibility(View.GONE);
                        if (updStatus != null) updStatus.setText("✅ Aap ke paas latest version hai");
                        if (manual) toast("App up to date hai ✅");
                    }
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> {
                    if (updStatus != null) updStatus.setText("Update check nahi hua: " + m + " (repo naam check karein)");
                });
            }
        });
    }

    private void showUpdate(final UpdateManager.Info in) {
        updateBanner.removeAllViews();
        updateBanner.setVisibility(View.VISIBLE);
        updateBanner.addView(bold("🆕 Naya update available!", 16, GREEN));
        String when = new SimpleDateFormat("dd MMM HH:mm", Locale.US).format(new Date(in.time));
        updateBanner.addView(text(in.title + " · " + when + " · " + Fmt.num(in.size / 1024.0) + " KB", 12, MUTED));
        final TextView prog = text("", 12, SOFT);
        updateBanner.addView(prog);
        Button b = button("⬇ Abhi install karein", GREEN, INK, 0);
        b.setOnClickListener(v -> startInstall(in, prog));
        updateBanner.addView(b);
        if (currentTab == 3) toast("🆕 Naya update — Market tab ke upar Install dabayen");
    }

    private void startInstall(final UpdateManager.Info in, final TextView prog) {
        if (installing) return;
        if (!UpdateManager.canInstall(this)) {
            prog.setText("Pehli dafa: agli screen par 'Allow from this source' ON karein, phir wapas aa kar dobara Install dabayen.");
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) {
            }
            return;
        }
        installing = true;
        prog.setText("Download ho raha hai... 0%");
        pool.execute(() -> {
            try {
                UpdateManager.install(this, in, pct -> runOnUiThread(() -> prog.setText("Download ho raha hai... " + pct + "%")));
                runOnUiThread(() -> prog.setText("✅ Download mukammal — ab Android ki screen par 'Update' dabayen"));
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> prog.setText("❌ Update nahi hua: " + m));
            } finally {
                installing = false;
            }
        });
    }

    // ============================================================ SIGNALS tab
    private void buildSignals() {
        LinearLayout col = pageColumn(2);
        LinearLayout st = card(col, ACC);
        st.addView(bold("🤖 24/7 Signal Bots", 17, TEXT));
        st.addView(text("Scalp aur Spot bot alag alag ON/OFF karein. Dono saath bhi chal sakte hain.", 12, MUTED));
        scalpBtn = button("", Mode.accent(Mode.SCALP), INK, 0);
        scalpBtn.setOnClickListener(v -> toggleMode(Mode.SCALP));
        st.addView(scalpBtn);
        spotBtn = button("", Mode.accent(Mode.SPOT), INK, 0);
        spotBtn.setOnClickListener(v -> toggleMode(Mode.SPOT));
        st.addView(spotBtn);
        statusView = text("", 13, MUTED);
        st.addView(statusView);
        Button bat = button("🔋 Battery restriction hatayen (zaroori)", CARD, ACC, ACC);
        bat.setOnClickListener(v -> askBattery());
        st.addView(bat);

        LinearLayout ac = card(col, ACC2);
        ac.addView(bold("🔔 Price alerts", 16, TEXT));
        ac.addView(text("Analyze tab se alert lagayen · hatane ke liye alert par tap karein", 12, MUTED));
        alertList = column();
        ac.addView(alertList);

        LinearLayout sc = card(col);
        LinearLayout hr = row();
        hr.addView(bold("📡 Signals", 17, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView clr = chip("Clear", false);
        clr.setOnClickListener(v -> {
            Prefs.clearSignals(this);
            renderSignals(true);
        });
        hr.addView(clr);
        sc.addView(hr);
        statsView = bold("", 13, ACC2);
        sc.addView(statsView);
        sc.addView(text("Har signal ka asal nateeja bot khud check karta hai: ✅ target hit · ❌ stop hit · ⌛ waqt khatam. "
                + "Signal par tap karein — live chart aur analysis khulega.", 12, MUTED));
        signalList = column();
        sc.addView(signalList);
    }

    private void toggleMode(int m) {
        boolean on = !Prefs.modeOn(this, m);
        Prefs.setModeOn(this, m, on);
        if (Prefs.enabled(this)) {
            startForegroundService(new Intent(this, ScannerService.class));
        } else {
            startService(new Intent(this, ScannerService.class).setAction(ScannerService.ACTION_STOP));
        }
        toast(Mode.label(m) + " bot " + (on ? "ON ✅" : "OFF"));
        handler.postDelayed(this::refreshStatus, 300);
    }

    private void renderAlerts() {
        alertList.removeAllViews();
        JSONArray a = Prefs.alerts(this);
        if (a.length() == 0) {
            alertList.addView(text("Koi alert nahi", 13, MUTED));
            return;
        }
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            final int idx = i;
            boolean above = o.optBoolean("above");
            TextView t = bold((above ? "⬆ " : "⬇ ") + base(o.optString("sym")) + "  " + (above ? "upar jaye " : "neeche aaye ")
                    + "$" + Fmt.price(o.optDouble("price")) + "   ✕", 14, above ? GREEN : RED);
            t.setPadding(0, dp(6), 0, dp(6));
            t.setOnClickListener(v -> {
                List<Integer> l = new ArrayList<>();
                l.add(idx);
                Prefs.removeAlerts(this, l);
                renderAlerts();
            });
            alertList.addView(t);
        }
    }

    private void renderSignals(boolean force) {
        JSONArray arr = Prefs.signals(this);
        JSONObject first = arr.optJSONObject(0);
        StringBuilder kb = new StringBuilder().append(arr.length()).append(':').append(first == null ? 0 : first.optLong("t"));
        int[] st = Scanner.signalStats(arr);
        kb.append(':').append(st[0]).append(st[1]).append(st[2]);
        String key = kb.toString();
        if (!force && key.equals(signalKey)) return;
        signalKey = key;
        int done = st[0] + st[1];
        statsView.setText(done > 0
                ? String.format(Locale.US, "🏆 Win rate %.0f%%  ·  ✅ %d  ❌ %d  ⌛ %d  ⏳ %d open", st[0] * 100.0 / done, st[0], st[1], st[2], st[3])
                : "🏆 Win rate: abhi koi signal mukammal nahi hua (" + st[3] + " open)");
        signalList.removeAllViews();
        if (arr.length() == 0) {
            signalList.addView(text("Abhi koi signal nahi. Upar se Scalp ya Spot bot ON karein — signal aate hi notification aa jayegi.", 13, MUTED));
            return;
        }
        SimpleDateFormat f = new SimpleDateFormat("dd MMM HH:mm", Locale.US);
        for (int i = 0; i < arr.length() && i < 60; i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            final boolean buy = "BUY".equals(o.optString("side"));
            final String sym = o.optString("sym");
            int m = o.optInt("mode", Mode.SPOT);
            LinearLayout item = column();
            item.setPadding(dp(12), dp(10), dp(12), dp(10));
            item.setBackground(round(buy ? 0x1A0ECB81 : 0x1AF6465D, 12, buy ? 0x550ECB81 : 0x55F6465D));
            LinearLayout hr = row();
            hr.addView(bold((buy ? "🟢 BUY  " : "🔴 SELL  ") + base(sym) + "/USDT", 15, buy ? GREEN : RED),
                    new LinearLayout.LayoutParams(0, -2, 1));
            String s = o.optString("st", "");
            String res = s.equals("win") ? String.format(Locale.US, "✅ WIN %+.1f%%", o.optDouble("pnl"))
                    : s.equals("loss") ? String.format(Locale.US, "❌ LOSS %+.1f%%", o.optDouble("pnl"))
                    : s.equals("expired") ? String.format(Locale.US, "⌛ %+.1f%%", o.optDouble("pnl"))
                    : s.equals("open") ? "⏳ open" : "";
            if (!res.isEmpty()) {
                TextView rv = bold(res, 11, s.equals("win") ? GREEN : s.equals("loss") ? RED : YELLOW);
                rv.setPadding(0, 0, dp(6), 0);
                hr.addView(rv);
            }
            TextView mb = bold(Mode.label(m), 10, INK);
            mb.setPadding(dp(6), dp(2), dp(6), dp(2));
            mb.setBackground(round(Mode.accent(m), 8, 0));
            hr.addView(mb);
            item.addView(hr);
            item.addView(text("$" + Fmt.price(o.optDouble("price")) + " · score " + o.optInt("score") + " · "
                    + f.format(new Date(o.optLong("t"))), 12, MUTED));
            item.addView(text(o.optString("why"), 12, SOFT));
            item.setOnClickListener(v -> openAnalyze(sym));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(8);
            signalList.addView(item, lp);
        }
    }

    private void refreshStatus() {
        boolean sc = Prefs.modeOn(this, Mode.SCALP), sp = Prefs.modeOn(this, Mode.SPOT);
        boolean on = sc || sp;
        liveDot.setText(on ? "● LIVE" : "○ OFF");
        liveDot.setTextColor(on ? GREEN : MUTED);
        statusView.setText(on ? Prefs.status(this) : "Dono bots band hain");
        scalpBtn.setText(sc ? "⏹  ⚡ SCALP bot ON — band karein" : "▶  ⚡ SCALP bot start karein");
        scalpBtn.setBackground(round(sc ? Mode.accent(Mode.SCALP) : CHIP, 14, Mode.accent(Mode.SCALP)));
        scalpBtn.setTextColor(sc ? INK : Mode.accent(Mode.SCALP));
        spotBtn.setText(sp ? "⏹  💎 SPOT bot ON — band karein" : "▶  💎 SPOT bot start karein");
        spotBtn.setBackground(round(sp ? Mode.accent(Mode.SPOT) : CHIP, 14, Mode.accent(Mode.SPOT)));
        spotBtn.setTextColor(sp ? INK : Mode.accent(Mode.SPOT));
        if (currentTab == 2) renderSignals(false);
    }

    private void askBattery() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm.isIgnoringBatteryOptimizations(getPackageName())) {
                toast("Pehle se unrestricted hai ✅");
                return;
            }
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception ignored) {
            }
        }
    }

    // ============================================================ SETTINGS tab
    private EditText field(LinearLayout parent, String label, String value, int inputType) {
        parent.addView(text(label, 13, MUTED));
        EditText e = input("", value, inputType);
        parent.addView(e);
        return e;
    }

    private EditText numField(LinearLayout parent, String label, int value) {
        return field(parent, label, String.valueOf(value), InputType.TYPE_CLASS_NUMBER);
    }

    private CheckBox check(LinearLayout parent, String label, boolean on) {
        CheckBox cb = new CheckBox(this);
        cb.setText(label);
        cb.setTextColor(TEXT);
        cb.setChecked(on);
        parent.addView(cb);
        return cb;
    }

    private void buildSettings() {
        LinearLayout col = pageColumn(3);

        LinearLayout up = card(col, GREEN);
        up.addView(bold("🔄 App update (andar se)", 16, TEXT));
        String ver = "?";
        try {
            ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
        }
        up.addView(text("Aap ka version: " + ver + ". Naya version GitHub par banta hai to app khud bata deti hai — "
                + "phir sirf 'Install' dabana hai, browser se download ki zaroorat nahi.", 12, MUTED));
        repoEt = field(up, "GitHub repo (owner/naam)", Prefs.updateRepo(this), InputType.TYPE_CLASS_TEXT);
        updStatus = text("", 13, SOFT);
        up.addView(updStatus);
        Button chk = button("🔍 Update check karein", GREEN, INK, 0);
        chk.setOnClickListener(v -> {
            Prefs.setUpdateRepo(this, repoEt.getText().toString());
            checkForUpdate(true);
        });
        up.addView(chk);

        LinearLayout ai = card(col, CLAUDE);
        ai.addView(bold("🤖 Claude AI Analyst", 16, TEXT));
        ai.addView(text("Analyze tab mein Claude aap ke coin ka live data parh kar Roman Urdu mein trade plan likhta hai aur "
                + "sawalon ke jawab deta hai. Is ke liye apni Claude API key chahiye.", 12, MUTED));
        claudeEt = field(ai, "Claude API key (sk-ant-...)", Prefs.claudeKey(this),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        ai.addView(text("Model", 13, MUTED));
        modelSpinner = new Spinner(this);
        modelSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, ClaudeAI.MODELS));
        for (int i = 0; i < ClaudeAI.MODELS.length; i++) if (ClaudeAI.MODELS[i].equals(Prefs.claudeModel(this))) modelSpinner.setSelection(i);
        ai.addView(modelSpinner);
        ai.addView(text("Sonnet = behtareen balance · Opus = sab se gehri soch (mehenga) · Haiku = sab se tez aur sasta", 11, MUTED));
        TextView link = chip("🔑 Key kahan se milegi? (console.anthropic.com)", false);
        link.setOnClickListener(v -> openUrl("https://console.anthropic.com/settings/keys"));
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(-2, -2);
        llp.topMargin = dp(6);
        ai.addView(link, llp);

        for (int m = 0; m < 2; m++) modeSettings(col, m);

        LinearLayout set = card(col);
        set.addView(bold("🎛️ Common settings", 16, TEXT));
        btcCb = check(set, "BTC filter: jab BTC bearish ho to BUY signal na do", Prefs.btcFilter(this));
        smartCb = check(set, "🐋 Smart money: whale trades, top traders, open interest", Prefs.smartMoney(this));
        strongCb = check(set, "🎯 Strong signal: notification se pehle SAB sources + chart patterns se confirm karo",
                Prefs.strongConfirm(this));
        whaleEt = numField(set, "Whale trade kitne USD se bada ho (e.g. 50000)", Prefs.whaleUsd(this));
        glassEt = field(set, "Glassnode API key (optional — sirf paid plan par milti hai)", Prefs.glassKey(this),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        Button save = button("💾 Save all settings", ACC, INK, 0);
        save.setOnClickListener(v -> saveSettings());
        set.addView(save);

        LinearLayout info = card(col);
        info.addView(bold("📡 Data sources (live)", 15, TEXT));
        info.addView(text("• Binance WebSocket: live price, live candles, har trade (whale/retail), live order book\n"
                + "• Binance spot REST: candles, buyers/sellers volume, trade count, order book\n"
                + "• 10 exchanges ka buy/sell volume: Binance spot+futures, OKX spot+futures, Bybit, Coinbase, Kraken, KuCoin, Gate, Bitget\n"
                + "• ETF inflow/outflow: Farside Investors (BTC, ETH, SOL, HYPE, ZEC)\n"
                + "• On-chain: DefiLlama (stablecoins, chain TVL), Blockchain.com (BTC), Coinbase premium, Coin Metrics\n"
                + "• Binance Futures: open interest, top traders, retail long/short, funding\n"
                + "• CoinGecko: market cap, community sentiment, BTC dominance\n"
                + "• Alternative.me: Fear & Greed Index\n"
                + "• News: Cointelegraph, CoinDesk, Decrypt\n"
                + "• Claude AI (apni key se) · Glassnode (apni key se)", 13, SOFT));
        info.addView(text("⚠️ Signals sirf maloomat ke liye hain, financial advice nahi. Bot khud koi trade nahi karta.", 12, MUTED));
    }

    private void modeSettings(LinearLayout col, int m) {
        LinearLayout c = card(col, Mode.accent(m));
        c.addView(bold(Mode.label(m) + " bot settings", 16, Mode.accent(m)));
        c.addView(text(Mode.desc(m), 12, MUTED));
        EditText[] f = new EditText[7];
        f[0] = numField(c, "Har kitne minute baad scan", Prefs.intervalMin(this, m));
        c.addView(text("Scan candle timeframe", 13, MUTED));
        String[] tfs = Mode.scanTfs(m);
        Spinner sp = new Spinner(this);
        sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, tfs));
        for (int i = 0; i < tfs.length; i++) if (tfs[i].equals(Prefs.timeframe(this, m))) sp.setSelection(i);
        c.addView(sp);
        tfSpinners[m] = sp;
        f[1] = numField(c, "Kitne top coins (volume ke hisaab se, max 400)", Prefs.topCoins(this, m));
        f[2] = numField(c, "Kam az kam 24h volume (million USDT)", Prefs.minVolMillion(this, m));
        f[3] = numField(c, "BUY score threshold (zyada = kam magar pakke)", Prefs.buyThreshold(this, m));
        f[4] = numField(c, "SELL score threshold", Prefs.sellThreshold(this, m));
        f[5] = field(c, "Volume spike = average ka kitna guna", String.valueOf(Prefs.volMult(this, m)),
                InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        f[6] = numField(c, "Ek coin ka dobara signal kitne minute baad", Prefs.cooldownMin(this, m));
        modeFields[m] = f;
        final int mm = m;
        TextView preset = chip("↺ Recommended " + (m == Mode.SCALP ? "scalp" : "spot") + " settings", false);
        preset.setOnClickListener(v -> {
            int[] vals = mm == Mode.SCALP ? new int[]{1, 60, 10, 6, 4, 30} : new int[]{15, 150, 5, 7, 5, 240};
            modeFields[mm][0].setText(String.valueOf(vals[0]));
            modeFields[mm][1].setText(String.valueOf(vals[1]));
            modeFields[mm][2].setText(String.valueOf(vals[2]));
            modeFields[mm][3].setText(String.valueOf(vals[3]));
            modeFields[mm][4].setText(String.valueOf(vals[4]));
            modeFields[mm][5].setText(mm == Mode.SCALP ? "1.8" : "2.0");
            modeFields[mm][6].setText(String.valueOf(vals[5]));
            tfSpinners[mm].setSelection(2);
            toast("Recommended values bhar di — Save dabayen");
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = dp(8);
        c.addView(preset, lp);
    }

    private int num(EditText e, int def) {
        try {
            return Integer.parseInt(e.getText().toString().trim());
        } catch (Exception x) {
            return def;
        }
    }

    private void saveSettings() {
        for (int m = 0; m < 2; m++) {
            EditText[] f = modeFields[m];
            float vm;
            try {
                vm = Float.parseFloat(f[5].getText().toString().trim());
            } catch (Exception x) {
                vm = 2.0f;
            }
            Prefs.saveMode(this, m, num(f[0], Prefs.intervalMin(this, m)), Mode.scanTfs(m)[tfSpinners[m].getSelectedItemPosition()],
                    num(f[1], 100), num(f[2], 5), num(f[3], 7), num(f[4], 5), vm, num(f[6], 120));
        }
        Prefs.saveCommon(this, btcCb.isChecked(), smartCb.isChecked(), strongCb.isChecked(),
                num(whaleEt, 50000), glassEt.getText().toString());
        Prefs.saveClaude(this, claudeEt.getText().toString(), ClaudeAI.MODELS[modelSpinner.getSelectedItemPosition()]);
        Prefs.setUpdateRepo(this, repoEt.getText().toString());
        toast("Saved ✅ — agla scan naye settings se hoga");
    }
}
