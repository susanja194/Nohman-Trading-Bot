package com.signal.bot;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Full analysis of ONE coin. Combines every free source into one 0-100 score:
 *  1. Technical on 4 timeframes (Binance klines)            weight 30
 *  2. Money flow: taker buy/sell, CVD, OBV, volume change     weight 20
 *  3. Whales: big trades + order book walls                   weight 20
 *  4. Futures smart money: OI, top traders, funding, retail   weight 15
 *  5. Sentiment: Fear&Greed, CoinGecko votes, news tone       weight 10
 *  6. On-chain: Glassnode exchange flow (only with API key)   weight 10
 * Sections that fail or are not available are left out of the average.
 */
public final class CoinReport {

    public static final class Section {
        public final String icon, title;
        public final int weight;
        public int score;               // -100 .. +100
        public boolean available = true;
        public final List<String> lines = new ArrayList<>();
        public String learn = "";       // "Seekhein" explanation shown under the section

        Section(String icon, String title, int weight) {
            this.icon = icon;
            this.title = title;
            this.weight = weight;
        }

        void add(String s) { lines.add(s); }
    }

    public String symbol, base, name;
    public double price, change24h, quoteVol24h, high24h, low24h;
    public int total = 50;
    public String verdict = "WAIT", verdictText = "";
    public double buyPct = 50;
    public String flowLabel = "⚖️ Mixed";
    public int flowSign = 0;
    public double support, resistance, atr, stop, target1, target2;
    public int mode = Mode.SPOT;
    public int confidence;          // 0..100 how far from 50 the score is
    public boolean isBuy;
    public PatternEngine.Result patterns;
    public CrossExchange.Result cross;
    public EtfFlows.Result etf;
    public FlowWindows.Result flows;
    public Institutions.Result inst;
    public Position.Advice advice;
    public String patternTf;
    public MaSystem.Result ma;
    public ParadoxRule.Backtest bt, bt2;
    /** ParaDox rule on the last closed candle of the pattern timeframe: +1 buy, -1 sell, 0 none. */
    public int ruleSide;
    public List<String> ruleChecks = new ArrayList<>();
    /** 1h/4h/1d trend agreement (+n bullish TFs minus bearish). */
    public int mtfAgree;
    public final List<Section> sections = new ArrayList<>();
    /** {title, link, source, tone(+,-,"")} */
    public final List<String[]> news = new ArrayList<>();
    private int newsPos, newsNeg;
    private double recentChange;

    private CoinReport() {}

    /** "sol", "SOL/USDT", "solusdt" -> "SOLUSDT" */
    public static String normalize(String in) {
        String s = in == null ? "" : in.toUpperCase(Locale.US).replaceAll("[^A-Z0-9]", "");
        if (s.endsWith("USDT") && s.length() > 4) return s;
        return s + "USDT";
    }

    /** full = also CoinGecko, news, Glassnode (slower; used when the user analyses a coin). */
    public static CoinReport build(String symbol, int mode, String glassKey, double whaleUsd, boolean full) throws Exception {
        CoinReport r = new CoinReport();
        r.mode = mode;
        r.symbol = symbol;
        r.base = symbol.substring(0, symbol.length() - 4);
        r.name = r.base;

        JSONObject t = new JSONObject(Scanner.get("/api/v3/ticker/24hr?symbol=" + symbol));
        r.price = t.optDouble("lastPrice", 0);
        r.change24h = t.optDouble("priceChangePercent", 0);
        r.quoteVol24h = t.optDouble("quoteVolume", 0);
        r.high24h = t.optDouble("highPrice", 0);
        r.low24h = t.optDouble("lowPrice", 0);

        String[] tfs = Mode.tfs(mode);
        java.util.Map<String, Candles> cs = new java.util.HashMap<>();
        for (String tf : tfs) cs.put(tf, Candles.fetch(symbol, tf, 300, true));
        String ptf = Mode.patternTf(mode);
        if (!cs.containsKey(ptf)) cs.put(ptf, Candles.fetch(symbol, ptf, 300, true));
        String ftf = Mode.flowTf(mode);
        if (!cs.containsKey(ftf)) cs.put(ftf, Candles.fetch(symbol, ftf, 300, true));
        Candles[] arr = new Candles[tfs.length];
        for (int i = 0; i < tfs.length; i++) arr[i] = cs.get(tfs[i]);

        r.patternTf = ptf;
        r.technical(tfs, Mode.tfWeights(mode), arr);
        r.moneyFlow(cs.get(ftf), Mode.flowCandles(mode), Mode.flowSpan(mode));
        r.patterns(cs.get(ptf));
        Candles longer = null;
        try {
            longer = Candles.fetch(symbol, ptf, 1000, true);   // bigger sample for the backtest
        } catch (Exception ignored) {
        }
        r.maSystem(longer != null && longer.n > cs.get(ptf).n ? longer : cs.get(ptf), arr, tfs);
        r.crossExchange();
        r.flowWindows();
        r.whales(whaleUsd);
        r.futures();
        r.etf();
        if (full) r.institutions();
        r.onChain(full ? glassKey : "", full);
        r.sentiment(full);
        r.newsRadar();
        r.catalysts();
        r.macro();
        r.levels(cs.get(ptf));
        r.finish();
        for (Section sec : r.sections) if (sec.learn.isEmpty()) sec.learn = Academy.sectionTip(sec.title);
        return r;
    }

    // ------------------------------------------------------------------ 1. technical
    private void technical(String[] tfs, int[] w, Candles[] cs) {
        Section s = new Section("📈", "Technical (" + String.join(" · ", tfs) + ")", 25);
        double sum = 0, ws = 0;
        Analyzer.Result main = null;
        for (int i = 0; i < cs.length; i++) {
            Candles c = cs[i];
            if (c.n < 60) {
                s.add(tfs[i] + ": data kam hai (naya coin)");
                continue;
            }
            Analyzer.Result a = Analyzer.analyze(c.open, c.close, c.vol, c.takerBuy, 2.0);
            int net = a.buyScore - a.sellScore;
            boolean up = Analyzer.isBullish(c.close);
            s.add(String.format(Locale.US, "%s: %s · RSI %.0f · net %+d", tfs[i],
                    up ? "Uptrend ⬆️" : "Downtrend ⬇️", a.rsi, net));
            double v = Fmt.clamp(net / 6.0 + (up ? 0.2 : -0.2), -1, 1);
            sum += v * w[i];
            ws += w[i];
            if (w[i] == 3) main = a;
        }
        if (main != null) {
            List<String> rs = main.buyScore >= main.sellScore ? main.buyReasons : main.sellReasons;
            String mt = tfs[1];
            for (int k = 0; k < rs.size() && k < 4; k++) s.add(mt + ": " + rs.get(k));
        }
        s.available = ws > 0;
        s.score = ws > 0 ? (int) Math.round(sum / ws * 100) : 0;
        sections.add(s);
    }

    // ------------------------------------------------------------------ 2. money flow
    private void moneyFlow(Candles c, int span, String spanLabel) {
        Section s = new Section("💰", "Binance money flow (CVD · OBV)", 15);
        int n = c.n;
        if (n < span * 2 + 5) {
            s.available = false;
            s.add("Data kam hai");
            sections.add(s);
            return;
        }
        int from = n - span;
        double v = 0, b = 0, cvd = 0, prev = 0, v4 = 0, b4 = 0;
        for (int i = from; i < n; i++) {
            v += c.vol[i];
            b += c.takerBuy[i];
            cvd += (2 * c.takerBuy[i] - c.vol[i]) * c.close[i];
        }
        for (int i = Math.max(0, n - 2 * span); i < from; i++) prev += c.vol[i];
        int recent = Math.max(3, span / 6);
        for (int i = n - recent; i < n; i++) {
            v4 += c.vol[i];
            b4 += c.takerBuy[i];
        }
        buyPct = v > 0 ? b / v * 100 : 50;
        recentChange = c.close[from] > 0 ? (c.close[n - 1] / c.close[from] - 1) * 100 : 0;
        double buy4 = v4 > 0 ? b4 / v4 * 100 : 50;
        double volChg = prev > 0 ? (v / prev - 1) * 100 : 0;
        double[] obv = Indicators.obv(c.close, c.vol);
        boolean obvUp = obv[n - 1] > obv[from];

        double sc = Fmt.clamp((buyPct - 50) / 6.0, -1, 1) * 0.5
                + Fmt.clamp((buy4 - 50) / 8.0, -1, 1) * 0.25
                + (obvUp ? 0.25 : -0.25);
        if (volChg > 30) sc *= 1.2;
        s.score = (int) Math.round(Fmt.clamp(sc, -1, 1) * 100);

        if (buyPct >= 52.5 && obvUp) {
            flowLabel = "💰 Paisa AA raha hai (accumulation)";
            flowSign = 1;
        } else if (buyPct <= 47.5 && !obvUp) {
            flowLabel = "🚨 Paisa NIKAL raha hai (distribution)";
            flowSign = -1;
        } else {
            flowLabel = "⚖️ Mixed — abhi saaf direction nahi";
            flowSign = 0;
        }
        s.add(String.format(Locale.US, "%s: Buyers %.0f%% · Sellers %.0f%%", spanLabel, buyPct, 100 - buyPct));
        s.add(String.format(Locale.US, "Bilkul taaza (%d candles): Buyers %.0f%%", recent, buy4));
        s.add("Net buy − sell (CVD " + spanLabel + "): " + (cvd >= 0 ? "+" : "") + Fmt.usd(cvd));
        s.add(String.format(Locale.US, "Volume %s vs pichhle %s: %+.0f%%", spanLabel, spanLabel, volChg));
        s.add("OBV: " + (obvUp ? "upar ja raha (accumulation)" : "neeche ja raha (distribution)"));
        sections.add(s);
    }

    // ------------------------------------------------------------------ 3. whales
    private void whales(double whaleUsd) {
        Section s = new Section("🐋", "Whales & order book", 15);
        double thr = Math.min(whaleUsd, Math.max(5000, quoteVol24h / 2000));
        double part1 = 0, part2 = 0;
        boolean got1 = false, got2 = false;
        try {
            JSONArray tr = new JSONArray(Scanner.get("/api/v3/aggTrades?symbol=" + symbol + "&limit=1000"));
            double wb = 0, wsl = 0;
            int cb = 0, csl = 0;
            long t0 = Long.MAX_VALUE, t1 = 0;
            for (int i = 0; i < tr.length(); i++) {
                JSONObject o = tr.getJSONObject(i);
                double usd = Double.parseDouble(o.getString("p")) * Double.parseDouble(o.getString("q"));
                long tt = o.optLong("T");
                t0 = Math.min(t0, tt);
                t1 = Math.max(t1, tt);
                if (usd < thr) continue;
                if (o.optBoolean("m")) { wsl += usd; csl++; } else { wb += usd; cb++; }
            }
            long mins = tr.length() > 1 ? Math.max(1, (t1 - t0) / 60000) : 0;
            s.add("Pichhle ~" + mins + " min ke " + tr.length() + " trades mein " + Fmt.usd(thr) + "+ ke orders:");
            s.add("🟢 Whale BUY: " + cb + " orders · " + Fmt.usd(wb));
            s.add("🔴 Whale SELL: " + csl + " orders · " + Fmt.usd(wsl));
            if (wb + wsl > 0) {
                part1 = (wb - wsl) / (wb + wsl);
                got1 = true;
            } else {
                s.add("Is waqt koi bada whale order nahi");
            }
        } catch (Exception e) {
            s.add("Whale trades load nahi huay");
        }
        try {
            JSONObject d = new JSONObject(Scanner.get("/api/v3/depth?symbol=" + symbol + "&limit=500"));
            JSONArray bids = d.getJSONArray("bids"), asks = d.getJSONArray("asks");
            double lo = price * 0.98, hi = price * 1.02;
            double bidUsd = 0, askUsd = 0, bw = 0, bwp = 0, aw = 0, awp = 0;
            for (int i = 0; i < bids.length(); i++) {
                JSONArray x = bids.getJSONArray(i);
                double p = Double.parseDouble(x.getString(0)), q = Double.parseDouble(x.getString(1));
                if (p < lo) break;
                double u = p * q;
                bidUsd += u;
                if (u > bw) { bw = u; bwp = p; }
            }
            for (int i = 0; i < asks.length(); i++) {
                JSONArray x = asks.getJSONArray(i);
                double p = Double.parseDouble(x.getString(0)), q = Double.parseDouble(x.getString(1));
                if (p > hi) break;
                double u = p * q;
                askUsd += u;
                if (u > aw) { aw = u; awp = p; }
            }
            s.add("Order book ±2%: Buy side " + Fmt.usd(bidUsd) + " · Sell side " + Fmt.usd(askUsd));
            if (bw > 0) s.add("Sab se bada BUY wall: " + Fmt.usd(bw) + " @ $" + Fmt.price(bwp));
            if (aw > 0) s.add("Sab se bada SELL wall: " + Fmt.usd(aw) + " @ $" + Fmt.price(awp));
            if (bidUsd + askUsd > 0) {
                part2 = (bidUsd - askUsd) / (bidUsd + askUsd);
                got2 = true;
            }
        } catch (Exception e) {
            s.add("Order book load nahi hua");
        }
        double sc = 0, w = 0;
        if (got1) { sc += part1 * 0.6; w += 0.6; }
        if (got2) { sc += part2 * 0.4; w += 0.4; }
        s.available = w > 0;
        s.score = w > 0 ? (int) Math.round(Fmt.clamp(sc / w, -1, 1) * 100) : 0;
        sections.add(s);
    }

    // ------------------------------------------------------------------ 4. futures
    private void futures() {
        Section s = new Section("👑", "Futures smart money (bade traders)", 15);
        final String F = "https://fapi.binance.com";
        final String fp = Mode.futPeriod(mode);
        final boolean sc5 = mode == Mode.SCALP;
        double sc = 0, w = 0;
        try {
            JSONObject p = new JSONObject(Scanner.getAbsolute(F + "/fapi/v1/premiumIndex?symbol=" + symbol));
            double fr = p.optDouble("lastFundingRate", 0) * 100;
            s.add(String.format(Locale.US, "Funding rate: %.4f%% %s", fr,
                    fr > 0.05 ? "(longs bahut zyada — khatra)" : fr < -0.01 ? "(shorts zyada — short squeeze ho sakta)" : "(normal)"));
            sc += -Fmt.clamp(fr / 0.05, -1, 1) * 0.15;
            w += 0.15;
        } catch (Exception e) {
            s.available = false;
            s.add("Is coin ka Binance Futures market nahi — yeh hissa skip");
            sections.add(s);
            return;
        }
        try {
            JSONArray a = new JSONArray(Scanner.getAbsolute(F + "/futures/data/openInterestHist?symbol=" + symbol + "&period=" + fp + "&limit=" + (sc5 ? 13 : 25)));
            if (a.length() >= 2) {
                double first = a.getJSONObject(0).optDouble("sumOpenInterestValue", 0);
                double last = a.getJSONObject(a.length() - 1).optDouble("sumOpenInterestValue", 0);
                if (first > 0) {
                    double ch = (last / first - 1) * 100;
                    double v;
                    String m;
                    double pc = sc5 ? recentChange : change24h;
                    double th = sc5 ? 1 : 2;
                    if (ch >= th && pc > 0) { v = 1; m = "naya paisa LONG mein aa raha ✅"; }
                    else if (ch >= th && pc < 0) { v = -1; m = "naye SHORTS aa rahe ⚠️"; }
                    else if (ch <= -th && pc < 0) { v = -0.5; m = "paisa futures se nikal raha"; }
                    else if (ch <= -th && pc > 0) { v = 0.3; m = "shorts band ho rahe (short squeeze)"; }
                    else { v = 0; m = "koi bada farq nahi"; }
                    s.add(String.format(Locale.US, "Open interest %s: %+.1f%% (%s) — %s", sc5 ? "1h" : "24h", ch, Fmt.usd(last), m));
                    sc += v * 0.3;
                    w += 0.3;
                }
            }
        } catch (Exception ignored) {
        }
        try {
            JSONArray a = new JSONArray(Scanner.getAbsolute(F + "/futures/data/topLongShortPositionRatio?symbol=" + symbol + "&period=" + fp + "&limit=" + (sc5 ? 12 : 24)));
            if (a.length() >= 2) {
                double first = a.getJSONObject(0).optDouble("longShortRatio", 0);
                double last = a.getJSONObject(a.length() - 1).optDouble("longShortRatio", 0);
                if (first > 0) {
                    s.add(String.format(Locale.US, "Top traders long/short: %.2f → %.2f %s", first, last,
                            last > first * 1.03 ? "(long badha rahe ✅)" : last < first * 0.97 ? "(long kam kar rahe ⚠️)" : "(same)"));
                    double v = Fmt.clamp((last - first) / first / 0.08, -1, 1) * 0.7 + (last > 1.2 ? 0.3 : last < 0.9 ? -0.3 : 0);
                    sc += v * 0.3;
                    w += 0.3;
                }
            }
        } catch (Exception ignored) {
        }
        try {
            JSONArray a = new JSONArray(Scanner.getAbsolute(F + "/futures/data/globalLongShortAccountRatio?symbol=" + symbol + "&period=" + fp + "&limit=1"));
            if (a.length() > 0) {
                double g = a.getJSONObject(0).optDouble("longShortRatio", 1);
                s.add(String.format(Locale.US, "Aam traders (retail) long/short: %.2f %s", g,
                        g > 2.5 ? "(sab long — aksar ulta hota hai)" : g < 0.8 ? "(sab short — squeeze mumkin)" : ""));
                sc += (g > 2.5 ? -0.5 : g < 0.8 ? 0.5 : 0) * 0.1;
                w += 0.1;
            }
        } catch (Exception ignored) {
        }
        try {
            JSONArray a = new JSONArray(Scanner.getAbsolute(F + "/futures/data/takerlongshortRatio?symbol=" + symbol + "&period=" + fp + "&limit=6"));
            if (a.length() > 0) {
                double sum = 0;
                for (int i = 0; i < a.length(); i++) sum += a.getJSONObject(i).optDouble("buySellRatio", 1);
                double avg = sum / a.length();
                s.add(String.format(Locale.US, "Futures taker buy/sell (" + (sc5 ? "30m" : "6h") + "): %.2f %s", avg,
                        avg > 1.05 ? "(buyers aggressive)" : avg < 0.95 ? "(sellers aggressive)" : ""));
                sc += Fmt.clamp((avg - 1) / 0.15, -1, 1) * 0.15;
                w += 0.15;
            }
        } catch (Exception ignored) {
        }
        s.score = w > 0 ? (int) Math.round(Fmt.clamp(sc / w, -1, 1) * 100) : 0;
        sections.add(s);
    }

    // ------------------------------------------------------------------ 5. sentiment
    private void sentiment(boolean full) {
        Section s = new Section("🧠", "Market ki raaye (sentiment · news · community)", mode == Mode.SCALP ? 5 : 10);
        double sc = 0, w = 0;
        String[] fg = SmartMoney.fearGreed();
        if (fg != null) {
            int v = 50;
            try { v = Integer.parseInt(fg[0]); } catch (Exception ignored) { }
            s.add("Fear & Greed: " + v + " (" + fg[1] + ")"
                    + (v <= 25 ? " — dar ka mahol, smart money aksar yahan khareedti hai"
                    : v >= 75 ? " — lalach zyada, correction ka khatra" : ""));
            sc += (v <= 25 ? 0.4 : v >= 75 ? -0.4 : 0) * 0.3;
            w += 0.3;
        }
        if (full) {
            try {
                JSONObject sr = new JSONObject(Scanner.getAbsolute(
                        "https://api.coingecko.com/api/v3/search?query=" + URLEncoder.encode(base, "UTF-8")));
                JSONArray coins = sr.getJSONArray("coins");
                String id = null;
                int best = Integer.MAX_VALUE;
                for (int i = 0; i < coins.length(); i++) {
                    JSONObject o = coins.getJSONObject(i);
                    if (!base.equalsIgnoreCase(o.optString("symbol"))) continue;
                    int rank = o.optInt("market_cap_rank", 0);
                    if (rank <= 0) rank = 100000;
                    if (rank < best) {
                        best = rank;
                        id = o.optString("id");
                        name = o.optString("name", base);
                    }
                }
                if (id != null) {
                    JSONObject cg = new JSONObject(Scanner.getAbsolute("https://api.coingecko.com/api/v3/coins/" + id
                            + "?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false&sparkline=false"));
                    double up = cg.optDouble("sentiment_votes_up_percentage", -1);
                    int rank = cg.optInt("market_cap_rank", 0);
                    if (rank > 0) s.add("Market cap rank: #" + rank);
                    if (up >= 0) {
                        s.add(String.format(Locale.US, "CoinGecko community: %.0f%% bullish · %.0f%% bearish", up, 100 - up));
                        sc += Fmt.clamp((up - 50) / 30, -1, 1) * 0.3;
                        w += 0.3;
                    }
                    JSONObject md = cg.optJSONObject("market_data");
                    if (md != null) {
                        s.add(String.format(Locale.US, "7 din: %+.1f%% · 30 din: %+.1f%%",
                                md.optDouble("price_change_percentage_7d", 0), md.optDouble("price_change_percentage_30d", 0)));
                        JSONObject ath = md.optJSONObject("ath_change_percentage");
                        if (ath != null) s.add(String.format(Locale.US, "All-time high se: %.0f%%", ath.optDouble("usd", 0)));
                    }
                }
            } catch (Exception e) {
                s.add("CoinGecko abhi busy hai (thori der baad dobara try karein)");
            }
        }
        {   // coin news is used by the background scanner too (cached feeds)
            fetchNews();
            if (!news.isEmpty()) {
                s.add("News: " + news.size() + " khabrein · " + newsPos + " positive · " + newsNeg + " negative");
                if (newsPos + newsNeg > 0) {
                    sc += Fmt.clamp((newsPos - newsNeg) / (double) (newsPos + newsNeg), -1, 1) * 0.4;
                    w += 0.4;
                }
            } else {
                s.add("Is coin ki koi taaza khabar nahi mili");
            }
        }
        s.available = w > 0;
        s.score = w > 0 ? (int) Math.round(Fmt.clamp(sc / w, -1, 1) * 100) : 0;
        sections.add(s);
    }

    private static final String[] FEEDS = {
            "https://cointelegraph.com/rss",
            "https://www.coindesk.com/arc/outboundfeeds/rss/",
            "https://decrypt.co/feed"
    };
    private static final String[] POS = {"surge", "soar", "rally", "jump", "gain", "bull", "record", "approv",
            "partnership", "launch", "upgrade", "adopt", "inflow", "breakout", "listing", "etf", "rebound", "climb"};
    private static final String[] NEG = {"drop", "plunge", "crash", "fall", "bear", "hack", "exploit", "lawsuit",
            "delist", "outflow", "dump", "sell-off", "selloff", "banned", "fraud", "slump", "liquidat", "warn", "decline"};

    private static final java.util.Map<String, String> FEED_CACHE = new java.util.HashMap<>();
    private static final java.util.Map<String, Long> FEED_T = new java.util.HashMap<>();

    /** News RSS with a 10-minute cache (the background scanner checks many coins). */
    private static String feed(String url) throws Exception {
        synchronized (FEED_CACHE) {
            Long t = FEED_T.get(url);
            if (t != null && System.currentTimeMillis() - t < 10 * 60_000L) return FEED_CACHE.get(url);
        }
        String x = Scanner.getAbsolute(url);
        synchronized (FEED_CACHE) {
            FEED_CACHE.put(url, x);
            FEED_T.put(url, System.currentTimeMillis());
        }
        return x;
    }

    private void fetchNews() {
        List<Pattern> pats = new ArrayList<>();
        if (name != null && name.length() >= 3)
            pats.add(Pattern.compile("\\b" + Pattern.quote(name) + "\\b", Pattern.CASE_INSENSITIVE));
        if (base.length() >= 3) pats.add(Pattern.compile("\\b" + Pattern.quote(base) + "\\b"));
        if (pats.isEmpty()) return;
        Pattern item = Pattern.compile("<item>(.*?)</item>", Pattern.DOTALL);
        Pattern title = Pattern.compile("<title>(?:<!\\[CDATA\\[)?(.*?)(?:\\]\\]>)?</title>", Pattern.DOTALL);
        Pattern link = Pattern.compile("<link>(?:<!\\[CDATA\\[)?(.*?)(?:\\]\\]>)?</link>", Pattern.DOTALL);
        for (String f : FEEDS) {
            if (news.size() >= 8) break;
            try {
                String xml = feed(f);
                String src = f.contains("cointelegraph") ? "Cointelegraph" : f.contains("coindesk") ? "CoinDesk" : "Decrypt";
                Matcher m = item.matcher(xml);
                while (m.find() && news.size() < 8) {
                    String it = m.group(1);
                    Matcher tm = title.matcher(it);
                    if (!tm.find()) continue;
                    String tt = unescape(tm.group(1).trim());
                    boolean hit = false;
                    for (Pattern p : pats) if (p.matcher(tt).find()) { hit = true; break; }
                    if (!hit) continue;
                    Matcher lm = link.matcher(it);
                    String ln = lm.find() ? lm.group(1).trim() : "";
                    String low = tt.toLowerCase(Locale.US);
                    int p = 0, q = 0;
                    for (String k : POS) if (low.contains(k)) p++;
                    for (String k : NEG) if (low.contains(k)) q++;
                    String tone = p > q ? "+" : q > p ? "-" : "";
                    if (p > q) newsPos++;
                    else if (q > p) newsNeg++;
                    news.add(new String[]{tt, ln, src, tone});
                }
            } catch (Exception ignored) {
            }
        }
    }

    private static String unescape(String s) {
        return s.replace("&amp;", "&").replace("&#039;", "'").replace("&#39;", "'").replace("&quot;", "\"")
                .replace("&lt;", "<").replace("&gt;", ">").replace("&#8217;", "'").replace("&#8216;", "'")
                .replace("&#8220;", "\"").replace("&#8221;", "\"").replace("&#8211;", "–");
    }

    // ------------------------------------------------------------------ cross-exchange volume
    private void crossExchange() {
        Section s = new Section("🌐", "Sab exchanges ka volume (paisa aa raha / nikal raha)", 20);
        cross = CrossExchange.fetch(base);
        int n = cross.venues.size();
        if (n == 0) {
            s.available = false;
            s.add("Doosre exchanges se data nahi mila");
            sections.add(s);
            return;
        }
        s.add(String.format(Locale.US, "%d exchanges ka mila-jula hisaab: Buyers %.0f%% · Sellers %.0f%%", n, cross.buyPct, 100 - cross.buyPct));
        s.add(cross.bull + " exchanges par buyers aage · " + cross.bear + " par sellers aage");
        if (cross.netUsd != 0) s.add("Net taker buy − sell (jin ka USD maloom): " + (cross.netUsd >= 0 ? "+" : "") + Fmt.usd(cross.netUsd));
        for (CrossExchange.Venue v : cross.venues) {
            String usd = v.buyUsd >= 0 ? " · " + Fmt.usd(v.buyUsd + v.sellUsd) : "";
            s.add(String.format(Locale.US, "%s %s (%s): buy %.0f%%%s", v.buyPct >= 52 ? "🟢" : v.buyPct <= 48 ? "🔴" : "⚪",
                    v.name, v.window, v.buyPct, usd));
        }
        s.score = cross.score;
        // the headline "money coming in / going out" now uses ALL exchanges
        if (n >= 3) {
            double combined = (buyPct + cross.buyPct * 2) / 3;
            buyPct = combined;
            if (combined >= 52.5 && cross.bull > cross.bear) { flowLabel = "💰 Paisa AA raha hai (" + n + " exchanges)"; flowSign = 1; }
            else if (combined <= 47.5 && cross.bear > cross.bull) { flowLabel = "🚨 Paisa NIKAL raha hai (" + n + " exchanges)"; flowSign = -1; }
            else { flowLabel = "⚖️ Mixed — exchanges mein ittifaq nahi"; flowSign = 0; }
        }
        sections.add(s);
    }

    // ------------------------------------------------------------------ 1m / 5m / 15m volume in-out
    private void flowWindows() {
        Section s = new Section("⏱️", "Volume IN / OUT — 1 · 5 · 15 minute", mode == Mode.SCALP ? 15 : 5);
        flows = FlowWindows.fetch(base);
        if (flows.venues.isEmpty()) {
            s.available = false;
            s.add("Taaza trades nahi milin");
            sections.add(s);
            return;
        }
        String[] lbl = {"1 min ", "5 min ", "15 min"};
        for (int k = 0; k < 3; k++) {
            double net = flows.net(k);
            s.add(String.format(Locale.US, "%s  IN %s · OUT %s · net %s%s %s", lbl[k], Fmt.usd(flows.in[k]), Fmt.usd(flows.out[k]),
                    net >= 0 ? "+" : "", Fmt.usd(net), net >= 0 ? "🟢" : "🔴"));
        }
        s.add("Exchanges: " + String.join(", ", flows.venues));
        if (!flows.partial.isEmpty()) s.add("Note: " + String.join(", ", flows.partial) + " ki taaza trades sirf chhote window cover karti hain");
        double sc = Fmt.clamp((flows.buyPct(1) - 50) / 8.0, -1, 1) * 0.5 + Fmt.clamp((flows.buyPct(2) - 50) / 6.0, -1, 1) * 0.35
                + Fmt.clamp((flows.buyPct(0) - 50) / 10.0, -1, 1) * 0.15;
        s.score = (int) Math.round(Fmt.clamp(sc, -1, 1) * 100);
        sections.add(s);
    }

    // ------------------------------------------------------------------ big institutions
    private void institutions() {
        inst = Institutions.fetch(base);
        Section s = new Section("🏛️", "Bade players — BlackRock · companies · Trump (WLFI)", inst.score == Integer.MIN_VALUE ? 0 : 10);
        for (String l : inst.lines) s.add(l);
        if (inst.score == Integer.MIN_VALUE) {
            s.available = false;
            s.score = 0;
        } else {
            s.score = inst.score;
        }
        if (inst.lines.isEmpty()) s.add("Data abhi nahi mila");
        sections.add(s);
    }

    // ------------------------------------------------------------------ US macro (Fed, CPI, jobs ...)
    private void macro() {
        Section s = new Section("🏦", "US macro — Fed, CPI, jobs (poori market)", 5);
        try {
            int[] sc = new int[1];
            for (String l : MacroEngine.reportLines(sc)) s.add(l);
            s.score = sc[0];
        } catch (Exception e) {
            s.available = false;
            s.add("Macro data abhi nahi mila");
        }
        sections.add(s);
    }

    // ------------------------------------------------------------------ ETF flows
    private void etf() {
        Section s = new Section("🏦", "ETF inflow / outflow (Amrika ke spot ETFs)", mode == Mode.SCALP ? 5 : 10);
        etf = EtfFlows.fetch(base);
        if (etf == null) {
            s.available = false;
            s.add("ETF data abhi nahi mila (farside.co.uk)");
            sections.add(s);
            return;
        }
        if (etf.marketWide) s.add(base + " ka apna ETF nahi — " + etf.asset + " ETF flow poori market ka mood batata hai");
        int n = etf.totals.size();
        for (int i = Math.max(0, n - 5); i < n; i++) {
            double v = etf.totals.get(i);
            s.add(String.format(Locale.US, "%s  %s %s $%.1fM", etf.dates.get(i), v >= 0 ? "🟢 inflow" : "🔴 outflow", v >= 0 ? "+" : "−", Math.abs(v)));
        }
        s.add(String.format(Locale.US, "Pichhle 5 din total: %s$%.1fM · aam din ka average ±$%.1fM", etf.sum5 >= 0 ? "+" : "−",
                Math.abs(etf.sum5), etf.avgAbs));
        s.add(etf.sum5 > 0 ? "Institutions khareed rahe hain (paisa aa raha) ✅" : "Institutions nikal rahe hain (paisa ja raha) ⚠️");
        s.score = etf.marketWide ? (int) (etf.score * 0.6) : etf.score;
        sections.add(s);
    }

    // ------------------------------------------------------------------ on-chain (free sources + optional Glassnode)
    private void onChain(String key, boolean full) {
        Section s = new Section("⛓️", "On-chain & naya paisa (DefiLlama · Blockchain · Coinbase)", mode == Mode.SCALP ? 5 : 10);
        double sc = 0, w = 0;

        double[] st = OnChainFree.stablecoins();
        if (st != null) {
            s.add(String.format(Locale.US, "Stablecoin supply %s: 7d %+.2f%% · 30d %+.2f%% %s", Fmt.usd(st[0]), st[1], st[2],
                    st[1] > 0.3 ? "(naye dollar crypto mein aa rahe ✅)" : st[1] < -0.3 ? "(dollar crypto se nikal rahe ⚠️)" : "(flat)"));
            sc += Fmt.clamp(st[1] / 1.0, -1, 1) * 0.25;
            w += 0.25;
        }
        String chain = OnChainFree.CHAINS.get(base);
        if (chain != null) {
            double[] tvl = OnChainFree.chainTvl(chain);
            if (tvl != null) {
                s.add(String.format(Locale.US, "%s chain TVL %s: 7d %+.1f%% · 30d %+.1f%%", chain, Fmt.usd(tvl[0]), tvl[1], tvl[2]));
                sc += Fmt.clamp(tvl[1] / 8.0, -1, 1) * 0.3;
                w += 0.3;
            }
            double[] cs = OnChainFree.chainStables(chain);
            if (cs != null) {
                s.add(String.format(Locale.US, "%s par stablecoins %s: 7d %+.1f%% %s", chain, Fmt.usd(cs[0]), cs[1],
                        cs[1] > 1 ? "(chain par paisa aa raha)" : cs[1] < -1 ? "(chain se paisa nikal raha)" : ""));
                sc += Fmt.clamp(cs[1] / 5.0, -1, 1) * 0.25;
                w += 0.25;
            }
        }
        if (base.equals("BTC")) {
            double[] bv = OnChainFree.btcChainVolume();
            if (bv != null) {
                s.add(String.format(Locale.US, "Bitcoin on-chain volume (7d avg) %s/din: %+.0f%% pichhle hafte se", Fmt.usd(bv[0]), bv[1]));
                sc += Fmt.clamp(bv[1] / 25.0, -1, 1) * 0.15;
                w += 0.15;
            }
        }
        double prem = OnChainFree.coinbasePremium(base, price);
        if (!Double.isNaN(prem)) {
            s.add(String.format(Locale.US, "Coinbase premium: %+.3f%% %s", prem,
                    prem > 0.05 ? "(Amrika ke buyers zyada de rahe — demand ✅)" : prem < -0.05 ? "(Amrika mein selling pressure ⚠️)" : "(normal)"));
            sc += Fmt.clamp(prem / 0.15, -1, 1) * 0.3;
            w += 0.3;
        }
        if (full) {
            double[] ef = OnChainFree.exchangeFlow(base);
            if (ef != null) {
                s.add("Exchange flow 7d (Coin Metrics): in " + Fmt.usd(ef[1]) + " · out " + Fmt.usd(ef[2]) + " → net "
                        + (ef[0] >= 0 ? "+" : "") + Fmt.usd(ef[0]) + (ef[0] < 0 ? " (coins exchange se nikal rahe — holding ✅)" : " (coins exchange par aa rahe — bechne ka khatra ⚠️)"));
                double tot = ef[1] + ef[2];
                sc += (tot > 0 ? -Fmt.clamp(ef[0] / (tot * 0.05), -1, 1) : 0) * 0.35;
                w += 0.35;
            }
        }
        if (full && key != null && !key.trim().isEmpty()) {
            try {
                long since = System.currentTimeMillis() / 1000 - 8 * 86400L;
                String q = "?a=" + base + "&i=24h&s=" + since + "&api_key=" + URLEncoder.encode(key.trim(), "UTF-8");
                JSONArray arr = new JSONArray(Scanner.getAbsolute("https://api.glassnode.com/v1/metrics/transactions/transfers_volume_exchanges_net" + q));
                if (arr.length() > 0) {
                    double sum = 0;
                    for (int i = 0; i < arr.length(); i++) sum += arr.getJSONObject(i).optDouble("v", 0);
                    s.add("Glassnode exchange net flow 7d: " + Fmt.num(sum) + " " + base
                            + (sum < 0 ? " — exchanges se NIKAL rahe ✅" : " — exchanges par AA rahe ⚠️"));
                    sc += (sum < 0 ? 0.5 : -0.5);
                    w += 0.5;
                }
            } catch (Exception e) {
                s.add("Glassnode: data nahi mila (key/plan check karein)");
            }
        }
        if (w == 0) {
            s.available = false;
            s.add("Is coin ka free on-chain data nahi mila");
        }
        s.score = w > 0 ? (int) Math.round(Fmt.clamp(sc / w, -1, 1) * 100) : 0;
        sections.add(s);
    }

    // ------------------------------------------------------------------ chart patterns
    private void patterns(Candles c) {
        Section s = new Section("📐", "Chart patterns (" + patternTf + ")", 15);
        patterns = PatternEngine.analyze(c, 150);
        if (c.n < 40) {
            s.available = false;
            s.add("Data kam hai");
        } else {
            for (String l : patterns.notes) s.add(l);
            s.score = patterns.score;
        }
        sections.add(s);
    }

    // ------------------------------------------------------------------ upcoming catalysts
    private void catalysts() {
        Section s = new Section("📆", "Catalyst radar — aane wale events (7 din)", 8);
        List<CatalystEngine.Event> l = CatalystEngine.forCoin(base, 7L * 86_400_000L);
        if (l.isEmpty()) {
            s.available = !CatalystEngine.cached().isEmpty();
            s.add(CatalystEngine.cached().isEmpty() ? "Catalyst radar abhi load nahi hua" : base + " ka koi bara scheduled event (unlock, listing, delisting) agle 7 din mein nahi mila");
        } else {
            for (CatalystEngine.Event e : l)
                s.add((e.dir > 0 ? "🟢 " : e.dir < 0 ? "🔴 " : "⚪ ") + e.icon() + " " + CatalystEngine.label(e) + " · " + MacroEngine.pkt(e.time)
                        + (e.estimated ? " (andaza)" : "") + " — " + e.title);
            CatalystEngine.Event b = CatalystEngine.buyBlocker(base);
            if (b != null) s.add("⛔ Is event ki wajah se bot is coin ke BUY signals rok raha hai");
        }
        s.score = CatalystEngine.score(base);
        sections.add(s);
    }

    // ------------------------------------------------------------------ live news radar (40+ sources)
    private void newsRadar() {
        Section s = new Section("📰", "News radar — " + NewsEngine.sourceCount() + "+ sources (24h)", mode == Mode.SCALP ? 10 : 12);
        List<NewsEngine.Item> l = NewsEngine.about(base, 24 * 3600_000L, 6);
        int[] cs = NewsEngine.coinScore(base, 24 * 3600_000L);
        NewsEngine.Item risk = NewsEngine.marketRisk(3 * 3600_000L);
        double sc = cs[0];
        if (risk != null) {
            sc = Math.min(sc, 0) - 35;
            s.add("🚨 Market risk: " + risk.category + " — " + risk.title + " (" + risk.sources.size() + " sources)");
        }
        if (cs[1] == 0 && risk == null) {
            s.available = NewsEngine.cached().size() > 0;
            s.add(NewsEngine.cached().isEmpty() ? "News radar abhi load nahi hua" : "Pichle 24 ghante mein " + base + " ki koi khaas khabar nahi");
        } else {
            if (cs[1] > 0) s.add(cs[1] + " khabrein · net tone " + (cs[0] > 0 ? "+" : "") + cs[0]);
            for (NewsEngine.Item it : l)
                s.add(NewsEngine.dirLabel(it) + " " + it.category + " · " + it.title + " (" + it.source
                        + (it.sources.size() > 1 ? " +" + (it.sources.size() - 1) : "") + ")");
        }
        s.score = (int) Math.round(Fmt.clamp(sc, -100, 100));
        sections.add(s);
    }

    // ------------------------------------------------------------------ moving averages + ParaDox rule
    private void maSystem(Candles c, Candles[] all, String[] tfs) {
        Section s = new Section("〰️", "Moving averages (EMA 9·21·50·100·200) + ParaDox rule", 15);
        if (c == null || c.n < 60) {
            s.available = false;
            s.add("Data kam hai");
            sections.add(s);
            return;
        }
        ma = MaSystem.analyze(c.close);
        for (String l : ma.lines) s.add(l);
        ParadoxRule.Ind x = ParadoxRule.prepare(c);
        int li = c.n - 1;
        ruleSide = ParadoxRule.signalAt(x, li);
        if (ruleSide == 0 && li > 0) ruleSide = ParadoxRule.signalAt(x, li - 1);
        ruleChecks = ParadoxRule.checklist(x, li, ruleSide != 0 ? ruleSide : (ma.score >= 0 ? 1 : -1));
        bt = ParadoxRule.backtest(c, 1.5, 1.0);
        bt2 = ParadoxRule.backtest(c, 1.5, 2.0);
        mtfAgree = 0;
        for (Candles k : all) if (k != null && k.n >= 50) mtfAgree += Analyzer.isBullish(k.close) ? 1 : -1;
        s.add(ruleSide > 0 ? "⚡ ParaDox rule: BUY setup ABHI bana hai (" + patternTf + ")"
                : ruleSide < 0 ? "⚡ ParaDox rule: SELL setup ABHI bana hai (" + patternTf + ")"
                : "ParaDox rule: abhi koi taaza setup nahi (intezar behtar)");
        if (bt.trades > 0) s.add(String.format(Locale.US, "Backtest (pichli %d candles): %d trades · win rate %.0f%% @1R · %.0f%% @2R",
                c.n, bt.trades, bt.winRate, bt2.winRate));
        s.add("Timeframes agreement: " + (mtfAgree > 0 ? "+" : "") + mtfAgree + " / " + all.length + " (" + String.join("·", tfs) + ")");
        double sc = ma.score;
        if (ruleSide != 0) sc += ruleSide * 25;
        s.score = (int) Math.round(Fmt.clamp(sc, -100, 100));
        sections.add(s);
    }

    // ------------------------------------------------------------------ levels + final
    private void levels(Candles c) {
        atr = Indicators.atr(c.high, c.low, c.close, 14);
        support = 0;
        resistance = 0;
        if (patterns != null) {
            for (PatternEngine.Zone z : patterns.zones) {
                if (z.support && (support == 0 || z.price > support)) support = z.price;
                if (!z.support && (resistance == 0 || z.price < resistance)) resistance = z.price;
            }
        }
        double lo = Double.MAX_VALUE, hi = 0;
        for (int i = Math.max(0, c.n - 30); i < c.n; i++) {
            lo = Math.min(lo, c.low[i]);
            hi = Math.max(hi, c.high[i]);
        }
        if (support == 0) support = lo == Double.MAX_VALUE ? low24h : lo;
        if (resistance == 0) resistance = hi == 0 ? high24h : hi;
    }

    private void finish() {
        double s = 0, w = 0;
        for (Section sec : sections) {
            if (!sec.available) continue;
            s += sec.score * sec.weight;
            w += sec.weight;
        }
        double avg = w > 0 ? s / w : 0;
        total = (int) Math.round(Fmt.clamp(50 + avg / 2, 0, 100));
        // Always give a direction: >= 50 BUY, < 50 SELL. Strength from distance to 50.
        isBuy = total >= 50;
        confidence = (int) Math.min(100, Math.abs(total - 50) * 2.5);
        String strength = confidence >= 50 ? "STRONG " : "";
        verdict = strength + (isBuy ? "BUY" : "SELL");
        boolean scalp = mode == Mode.SCALP;
        if (isBuy) {
            verdictText = confidence >= 50
                    ? "Zyada tar sources upar ka ishara de rahe hain — volume, smart money aur structure saath hain."
                    : "Buyers thore aage hain. Entry chhoti rakhen aur stop-loss zaroor lagayen.";
        } else {
            verdictText = confidence >= 50
                    ? "Paisa nikal raha hai aur structure kamzor hai — " + (scalp ? "short ka setup / long se door rahein." : "khareedne se door rahein, holding ho to profit bacha lein.")
                    : "Sellers thore aage hain — " + (scalp ? "chhota short ya intezar." : "naya khareedna theek nahi.");
        }
        if (confidence < 20) verdictText += " (Confidence kam hai — market abhi faisla nahi kar raha.)";
        double f5 = flows != null && !flows.venues.isEmpty() ? flows.buyPct(1) : Double.NaN;
        double f15 = flows != null && !flows.venues.isEmpty() ? flows.net(2) : Double.NaN;
        advice = Position.compute(isBuy, price, atr, Mode.stopAtr(mode), patterns, support, resistance, f5, f15);
        if (atr > 0 && advice != null) {
            stop = advice.sl;
            target1 = advice.tp1;
            target2 = advice.tp2;
        } else if (atr > 0) {
            double risk = Mode.stopAtr(mode) * atr;
            if (isBuy) {
                stop = Math.max(price - risk, price * 0.3);
                target1 = price + 1.5 * risk;
                target2 = price + 3 * risk;
            } else {
                stop = price + risk;
                target1 = Math.max(price - 1.5 * risk, price * 0.05);
                target2 = Math.max(price - 3 * risk, price * 0.05);
            }
        }
    }

    /** Plain-text summary of the whole report (sent to Claude AI). */
    public String toText() {
        StringBuilder sb = new StringBuilder();
        sb.append("COIN: ").append(name).append(" (").append(symbol).append(")  MODE: ")
                .append(mode == Mode.SCALP ? "SCALP (short-term 1m-15m)" : "SPOT (swing 1h-1d)").append('\n');
        sb.append(String.format(Locale.US, "PRICE: %s  24h change: %+.2f%%  24h range: %s - %s  24h volume: %s%n",
                Fmt.price(price), change24h, Fmt.price(low24h), Fmt.price(high24h), Fmt.usd(quoteVol24h)));
        sb.append("BOT VERDICT: ").append(verdict).append("  score ").append(total).append("/100  confidence ")
                .append(confidence).append("%\n");
        sb.append("MONEY FLOW: ").append(flowLabel).append(String.format(Locale.US, " (buyers %.0f%%)%n", buyPct));
        sb.append("SUPPORT: ").append(Fmt.price(support)).append("  RESISTANCE: ").append(Fmt.price(resistance))
                .append("  ATR: ").append(Fmt.price(atr)).append('\n');
        if (advice != null) sb.append("POSITION ADVICE: ").append(advice.title).append(" — ").append(advice.why)
                .append(" zone ").append(Fmt.price(advice.zoneLo)).append("-").append(Fmt.price(advice.zoneHi)).append('\n');
        if (atr > 0) sb.append("BOT PLAN: entry ").append(Fmt.price(price)).append(" stop ").append(Fmt.price(stop))
                .append(" tp1 ").append(Fmt.price(target1)).append(" tp2 ").append(Fmt.price(target2)).append('\n');
        for (Section s : sections) {
            sb.append("\n[").append(s.title).append("] score ").append(s.available ? String.valueOf(s.score) : "n/a").append('\n');
            for (String l : s.lines) sb.append("- ").append(l).append('\n');
        }
        if (!news.isEmpty()) {
            sb.append("\n[News headlines]\n");
            for (String[] n : news) sb.append("- ").append(n[0]).append(" (").append(n[2]).append(")\n");
        }
        return sb.toString();
    }
}
