package com.signal.bot;

/**
 * ParaDox Academy — trading lessons in simple Roman Urdu, plus the short "Seekhein" tips
 * shown under every analysis section.
 */
public final class Academy {
    private Academy() {}

    /** {icon, title, level, body} */
    public static final String[][] LESSONS = {
            {"🧭", "Trading ki bunyaad — market kaise chalti hai", "Beginner",
                    "Market mein price sirf ek wajah se hilti hai: KHAREEDNE aur BECHNE walon ka tawazun.\n\n"
                            + "• Jab khareedne wale zyada jaldi mein hon (market order se khareedein) to price upar jaati hai.\n"
                            + "• Jab bechne wale jaldi mein hon to price neeche aati hai.\n\n"
                            + "SPOT trading: aap asal coin khareedte hain. Price barhe to faida, gire to nuksan — magar liquidation nahi hoti.\n"
                            + "FUTURES trading: aap sirf price ke upar/neeche jaane par shart lagate hain (LONG = upar, SHORT = neeche). Leverage se faida aur nuksan dono barh jaate hain aur liquidation ho sakti hai.\n\n"
                            + "Timeframe: 1m, 5m, 15m chhote (scalp) hain — tez magar shor wale. 1h, 4h, 1d bade (swing/spot) hain — dheemay magar zyada qabil-e-aitbaar.\n\n"
                            + "Sunehra usool: bade timeframe ki direction mein chhote timeframe par entry lein."},
            {"🕯️", "Candlestick parhna", "Beginner",
                    "Har candle ek waqt (maslan 15 minute) ki kahani hai: Open, High, Low, Close (OHLC).\n\n"
                            + "🟢 Hari candle: close > open (buyers jeete). 🔴 Laal candle: close < open (sellers jeete).\n"
                            + "Body = open se close tak. Wick (saya) = high/low tak — wick dikhati hai ke price wahan gayi magar ruki nahi.\n\n"
                            + "Ahem candles:\n"
                            + "• Hammer: neeche lambi wick, chhoti body — neeche se khareed aayi (bullish, support par zyada taqatwar).\n"
                            + "• Shooting star: upar lambi wick — upar se bikwali (bearish, resistance par).\n"
                            + "• Engulfing: nayi candle pichli ko poora dhaanp le — direction badalne ka ishara.\n"
                            + "• Doji: open ≈ close — confusion, agli candle ka intezar karein.\n\n"
                            + "Yaad rakhein: candle tab tak final nahi jab tak close na ho. ParaDox hamesha CLOSED candles par signal banata hai."},
            {"🧱", "Support aur Resistance", "Beginner",
                    "Support = woh satah jahan pehle price giri aur khareedar aa gaye (farsh).\n"
                            + "Resistance = woh satah jahan price upar ja kar ruki aur bechne wale aaye (chhat).\n\n"
                            + "• Jitni zyada baar koi level chhua gaya, utna mazboot.\n"
                            + "• Resistance toot jaye to aksar wohi naya support banta hai (role reversal) — yahi RETEST entry hai.\n"
                            + "• Breakout tab sacha hai jab candle level ke upar CLOSE ho aur volume average se zyada ho.\n\n"
                            + "ParaDox chart par yeh zones halki patti (band) ki shakal mein dikhata hai, aur position plan mein 'RETEST ka wait' isi usool par hai."},
            {"📏", "Trendlines aur channels", "Beginner",
                    "Uptrend: har neeche wala point (low) pichle se upar — in lows ko milane se upar jaati trendline banti hai.\n"
                            + "Downtrend: har high pichle se neeche.\n\n"
                            + "• Trendline jitni dafa chhui jaye, utni mazboot. 3 touch achha hai.\n"
                            + "• Channel: do mutawazi lines — neeche khareedein, upar profit lein.\n"
                            + "• Triangle / wedge: lines aapas mein mil rahi hon to bara move qareeb hota hai — jidhar toote udhar chalein.\n\n"
                            + "ParaDox khud swing highs/lows dhoond kar lines draw karta hai aur pattern ka naam batata hai (Ascending triangle, Double bottom waghera)."},
            {"〰️", "Moving Averages — trend ki asal pehchan", "Intermediate",
                    "Moving average (MA) pichli N candles ki average price hai — shor hata kar trend dikhati hai. EMA (Exponential) naye data ko zyada wazan deti hai, is liye tez react karti hai.\n\n"
                            + "ParaDox ka EMA RIBBON: 9 · 21 · 50 · 100 · 200\n"
                            + "• EMA 9/21 = short-term raftaar (entry timing)\n"
                            + "• EMA 50 = darmiyani trend\n"
                            + "• EMA 100/200 = lamba trend (institutions isay dekhte hain)\n\n"
                            + "BULLISH alignment: 9 > 21 > 50 > 100 > 200 aur price sab se upar = mazboot uptrend.\n"
                            + "BEARISH alignment: 9 < 21 < 50 < 100 < 200 = mazboot downtrend.\n"
                            + "Uljhi hui MAs = sideways market — yahan signals aksar fail hote hain.\n\n"
                            + "CROSSES:\n"
                            + "• Fast cross: EMA9 ne EMA21 ko upar kata = momentum upar (entry trigger).\n"
                            + "• ✨ Golden cross: EMA50 ne EMA200 ko upar kata = lambi bull trend shuru.\n"
                            + "• ☠️ Death cross: EMA50 ne EMA200 ko neeche kata = lambi bear trend.\n\n"
                            + "Ahem: cross akela signal nahi — sideways mein bar bar cross hote hain (whipsaw). Is liye ParaDox cross ko trend, RSI, MACD aur volume ke saath milata hai."},
            {"⚡", "ParaDox rule — signal kaise banta hai", "Intermediate",
                    "ParaDox ka confluence rule sirf tab BUY deta hai jab SAB ek saath sach hon:\n\n"
                            + "1️⃣ Trend: EMA21 > EMA50 aur price EMA50 (aur EMA200) ke upar\n"
                            + "2️⃣ Trigger: EMA9 ne abhi (3 candles ke andar) EMA21 ko upar kata, ya price EMA21 tak wapas aa kar (pullback) upar uchhli\n"
                            + "3️⃣ Momentum: RSI 50–72 (taqat hai magar overbought nahi) aur MACD histogram positive\n"
                            + "4️⃣ Volume: average ke barabar ya zyada (kam az kam 0.9x — khaali move nahi)\n\n"
                            + "SELL is ka ulta hai.\n\n"
                            + "Phir all-source score dekha jata hai: sab exchanges ka volume, whales ke orders, futures, ETF, news, macro. Score ≥ 62 BUY aur ≤ 38 SELL.\n\n"
                            + "ACCURACY MODE (Settings mein): yahi rule pichli ~300+ candles par chala kar dekha jata hai (backtest). Agar us coin par is rule ka win rate aapki set ki hui had (maslan 60%) se kam ho to signal NAHI bheja jata. Saath mein timeframes aur MA trend ka ek direction mein hona zaroori hai.\n\n"
                            + "Sach baat: koi bhi bot 95% guarantee nahi de sakta. Kam magar saaf signals + sahi risk management hi lambay arsay mein faida deta hai."},
            {"📊", "RSI — taqat aur thakawat", "Intermediate",
                    "RSI (0–100) batata hai ke haal hi mein khareed zyada taqatwar thi ya bikwali.\n\n"
                            + "• 70 se upar = overbought (bahut tez upar gaya — thakawat/pullback mumkin)\n"
                            + "• 30 se neeche = oversold (bahut gira — bounce mumkin)\n"
                            + "• 50 ke upar = buyers control mein, 50 ke neeche = sellers.\n\n"
                            + "Divergence (bahut ahem): price naya high banaye magar RSI kam high banaye = bearish divergence (taqat khatam ho rahi). Ulta = bullish divergence. ParaDox chart par yeh lines draw karta hai.\n\n"
                            + "Ghalti mat karein: mazboot uptrend mein RSI kaafi der 70 ke upar reh sakta hai — sirf overbought dekh kar short na karein."},
            {"📉", "MACD", "Intermediate",
                    "MACD = EMA12 − EMA26. Signal line = MACD ki EMA9. Histogram = MACD − signal.\n\n"
                            + "• Histogram zero se upar aur barh raha = upar ki raftaar tez ho rahi\n"
                            + "• Histogram chhota hota ja raha = raftaar kam (trend thak raha)\n"
                            + "• Zero line cross = trend change ka ishara\n\n"
                            + "ParaDox rule mein MACD histogram ka sign confirmation ke taur par istemal hota hai."},
            {"🌊", "Volume aur Order Flow — paisa aa raha ya nikal raha", "Intermediate",
                    "Price jhooti ho sakti hai, volume kam jhoot bolta hai.\n\n"
                            + "• Taker BUY volume = jo log market price par khareed rahe hain (jaldi mein) — yeh asal demand hai.\n"
                            + "• CVD (Cumulative Volume Delta) = buy volume − sell volume ka jor. Price flat ho magar CVD barhe = chupke se khareed (accumulation).\n"
                            + "• OBV = volume ke saath trend.\n\n"
                            + "ParaDox 10 exchanges (Binance, Bybit, OKX, Coinbase, Kraken, KuCoin, Gate, Bitget…) ka volume jor kar 1, 5 aur 15 minute mein kitna paisa IN aur kitna OUT hua batata hai. Sirf ek exchange par bharosa ghalat nateeja de sakta hai.\n\n"
                            + "Usool: breakout + barhta volume = sacha. Breakout + kam volume = aksar fake (trap)."},
            {"🐋", "Whales aur smart money", "Advanced",
                    "Whales = bade players (funds, exchanges, amir traders) jin ke orders price hila dete hain.\n\n"
                            + "ParaDox kya dekhta hai:\n"
                            + "• Bade trades (maslan $100k+) — khareed zyada ya bikwali\n"
                            + "• Order book ki deewarein (bari limit orders) — support/resistance ka kaam karti hain, magar hata bhi di jaati hain (spoofing)\n"
                            + "• Futures: top traders ka long/short ratio, funding rate, open interest\n"
                            + "• Institutions: ETF inflow/outflow, companies ke treasury, bade wallets\n\n"
                            + "Retail (aam log) aksar ghalat waqt par jaate hain: jab sab long hon aur funding bahut zyada ho, to neeche ka jhatka (long squeeze) aksar aata hai."},
            {"🌀", "Fibonacci retracement", "Intermediate",
                    "Bara move hone ke baad price aksar kuch wapas aati hai (retrace) phir trend mein chalti hai.\n\n"
                            + "Ahem levels: 38.2%, 50%, 61.8% (golden pocket 61.8–65%).\n"
                            + "• Uptrend mein price 50–61.8% tak wapas aaye aur wahan hammer/volume dikhe = achhi entry.\n"
                            + "• 78.6% toot jaye to trend kamzor.\n\n"
                            + "ParaDox swing low se high tak khud Fib draw karta hai."},
            {"🔺", "Chart patterns", "Intermediate",
                    "• Double top (M) / Double bottom (W): do baar ek hi level se ruk jaana — neckline tootne par direction confirm.\n"
                            + "• Head & Shoulders: teen chotiyan, beech wali sab se oonchi — bearish reversal.\n"
                            + "• Ascending triangle: flat chhat + upar uthte lows — aksar upar tootta hai.\n"
                            + "• Descending triangle: flat farsh + girte highs — aksar neeche.\n"
                            + "• Flag: tez move ke baad chhota consolidation — usi direction mein jaari.\n\n"
                            + "Target: pattern ki unchai ko breakout point se aage naapein. Hamesha close + volume ka intezar."},
            {"🛡️", "Risk management — sab se ahem sabaq", "Essential",
                    "Professional trader pehle sochta hai 'kitna kho sakta hoon', baad mein 'kitna kamaunga'.\n\n"
                            + "• 1–2% usool: ek trade mein apne total balance ka 1–2% se zyada risk na karein.\n"
                            + "• Har trade mein STOP LOSS lazmi. Stop ke baghair ek bura trade account khatam kar sakta hai.\n"
                            + "• Stop ko kabhi door na karein (nuksan barhane ke liye). Faide mein ho to breakeven par la sakte hain.\n"
                            + "• Lagataar 3 loss ke baad us din trading band.\n\n"
                            + "Misaal: balance $1000, risk 1% = $10. Entry $100, stop $95 (5% door) → position = $10 ÷ 5% = $200 ka.\n"
                            + "ParaDox ke Trading Tools mein position size calculator yahi hisaab karta hai."},
            {"🎯", "Stop Loss, Take Profit aur Risk:Reward", "Essential",
                    "Risk (R) = entry aur stop ka farq.\n"
                            + "Reward = entry aur target ka farq.\n"
                            + "R:R = reward ÷ risk. 1:2 ka matlab: $1 khatre par $2 ka target.\n\n"
                            + "Win rate aur R:R ka rishta:\n"
                            + "• 1:1 par breakeven ke liye 50% win rate chahiye\n"
                            + "• 1:2 par sirf 34% win rate se bhi faida\n"
                            + "• 1:3 par 25% se bhi faida\n\n"
                            + "Is liye 'win rate 90%' se zyada ahem hai ke jeetne wale trades harne walon se bade hon.\n\n"
                            + "Stop kahan lagayein: support ke neeche (buy) / resistance ke upar (sell), ya ATR ka 1.5x. ATR = ek candle ki ausat harkat — is se stop shor se bahar rehta hai.\n"
                            + "ParaDox: TP1 = 1R (half profit + stop breakeven), TP2 = 2–3R."},
            {"➗", "Average price / DCA", "Beginner",
                    "DCA (Dollar Cost Averaging) = ek hi coin thora thora mukhtalif qeemat par khareedna.\n\n"
                            + "Average price = kul lagaya paisa ÷ kul coins.\n"
                            + "Misaal: $100 par 1 coin + $80 par 1 coin → average $90. Ab price $90 se upar = faida.\n\n"
                            + "• Spot mein strong coins ke liye DCA theek hai.\n"
                            + "• Futures mein harte trade mein average karna (martingale) bahut khatarnak hai — liquidation jaldi.\n"
                            + "• Pehle se plan banayein: kitne hisse, kin levels par, aur kul kitna.\n\n"
                            + "Trading Tools → Average price calculator mein apne saare buys daal kar average, breakeven (fees ke saath) aur abhi ka P/L dekhein."},
            {"🏦", "Macro — Fed, CPI, NFP aur market", "Advanced",
                    "US dollar duniya ki market ko chalata hai.\n\n"
                            + "• Fed rate barhaye / hawkish = dollar mazboot = crypto, gold, stocks par dabao\n"
                            + "• Fed rate ghataye / dovish = dollar kamzor = risk assets aur gold upar\n"
                            + "• CPI (mehngai) forecast se zyada = rate cut door = bearish risk\n"
                            + "• NFP (jobs) bahut mazboot = dollar upar\n\n"
                            + "News se 30 min pehle aur baad market mein fake moves aate hain. ParaDox in waqton mein naye signals rok deta hai (News pause)."},
            {"🥇", "Gold aur commodities ki bunyaad", "Intermediate",
                    "Gold (XAUUSD) = mehngai aur dar ke waqt ki 'mehfooz jagah'.\n\n"
                            + "Gold upar jaata hai jab:\n"
                            + "• Dollar (DXY) kamzor ho\n"
                            + "• US yields (10Y) gir rahi hon (real yield kam)\n"
                            + "• Jang / bohran / central banks khareed rahe hon\n\n"
                            + "Oil (WTI/Brent): OPEC faisle, jang, inventory data se hilta hai.\n"
                            + "Silver: gold jaisa magar zyada tez aur industrial demand se bhi.\n\n"
                            + "Trading timings: Sunday raat se Friday raat tak (weekend band). London + New York session sab se zyada harkat."},
            {"💱", "Forex ki bunyaad — pairs, pips, sessions", "Intermediate",
                    "Forex pair = ek currency ko doosri mein naapna. EURUSD 1.0850 = 1 Euro = 1.085 dollar.\n"
                            + "Pehli = base, doosri = quote. EURUSD BUY = Euro khareedna, dollar bechna.\n\n"
                            + "Pip = chhoti tabdeeli: zyada tar pairs mein 0.0001, JPY pairs mein 0.01.\n\n"
                            + "Dollar ka asar:\n"
                            + "• EURUSD, GBPUSD, AUDUSD: dollar mazboot = pair NEECHE\n"
                            + "• USDJPY, USDCAD, USDCHF: dollar mazboot = pair UPAR\n\n"
                            + "Sessions (Pakistan time, takreeban): Tokyo 5am–2pm, London 12pm–9pm, New York 5pm–2am. London-NY overlap (5–9pm) sab se tez.\n"
                            + "Forex mein volume ka asal data nahi hota, is liye ParaDox yahan trend, MAs, dollar index aur news par zyada wazan deta hai."},
            {"📰", "News trading — khabar se pump aur dump", "Advanced",
                    "Crypto mein khabar seconds mein price hila deti hai. ParaDox ka News radar 45 sources (news sites, Google News, Binance, X posts) dekhta hai.\n\n"
                            + "Sab se khatarnak (BEARISH) khabrein:\n"
                            + "• 🚨 Hack / exploit — mutasira coin/exchange 5–30% gir sakta hai, poori market mein dar\n"
                            + "• ⛔ Withdrawals band — exchange par bharosa khatam\n"
                            + "• 💥 Stablecoin depeg — DeFi mein liquidations\n"
                            + "• 📤 Delisting — coin 20–50% gir sakta hai\n"
                            + "• ⚖️ SEC lawsuit / ban\n\n"
                            + "Ahem BULLISH khabrein:\n"
                            + "• 🆕 Binance/Coinbase/Upbit listing — tez pump (aksar phir wapas)\n"
                            + "• 🏦 ETF approval / bara inflow\n"
                            + "• 🏢 Company ya hukumat ki khareed (treasury)\n"
                            + "• 🏛️ Fed rate cut\n\n"
                            + "Usool:\n"
                            + "1. Pehle tasdeeq: kitne sources? Ek X post afwah bhi ho sakti hai.\n"
                            + "2. Khabar ke foran baad ki pehli candle aksar dhoka hoti hai — 5–15 min intezar.\n"
                            + "3. 'Buy the rumor, sell the news' — achhi khabar ke din bhi price gir sakti hai.\n"
                            + "4. Hack/delisting par kabhi 'sasta hai' soch kar foran BUY na karein.\n"
                            + "5. Khabar ki tafseel mein 'Asal asar' dekhein: 5 min, 15 min, 1 ghante mein price kitni hili.\n\n"
                            + "ParaDox bot critical bearish khabar wale coin ke BUY signals 2 ghante ke liye khud rok deta hai."},
            {"📆", "Catalysts — pehle se pata events (aur 'insider' ka sach)", "Advanced",
                    "Bade traders aane wale events ke hisaab se pehle position lete hain. Yeh sab PUBLIC hota hai:\n\n"
                            + "• 🔓 Token unlock: naye coins market mein aate hain → aksar unlock se pehle dabao. Bara unlock (market cap ka 1–3%+) zyada khatarnak.\n"
                            + "• 🆕 Listing ka elaan (Binance/Coinbase/Upbit): elaan se listing tak aksar pump, listing ke waqt 'sell the news'.\n"
                            + "• 📤 Delisting: tareekh tak giraawat.\n"
                            + "• 🎁 Airdrop / Launchpool: pehle demand, milne ke baad bikwali.\n"
                            + "• 🚀 Mainnet / upgrade: 'buy the rumor, sell the news'.\n"
                            + "• 🏦 ETF ki deadline, 🏛️ Fed / CPI: poori market.\n"
                            + "• 🎲 Polymarket odds: log asal paisa laga kar shart lagate hain — odds achanak badlein to aksar kisi ko pehle kuch pata hota hai.\n"
                            + "• 📊 Futures build-up: open interest tez barhe aur price ruki ho = bara move qareeb.\n\n"
                            + "'Insider news' ka sach: kisi ki chhupi khareed ki khabar koi free ya legal jagah nahi deti. Jo groups 'insider signal' bechte hain "
                            + "woh aksar pump-and-dump karte hain — pehle khud khareed kar aap ko bechte hain. Chhupi maloomat par trade kai mulkon mein jurm hai.\n\n"
                            + "ParaDox ka Catalyst Radar yeh sab events dikhata hai, 24 ghante aur 1 ghanta pehle yaad dilata hai, aur bara unlock ya delisting "
                            + "3 din ke andar ho to us coin ke BUY signals rok deta hai."},
            {"🧠", "Trading psychology", "Essential",
                    "Zyada tar log strategy se nahi, jazbaat se haarte hain.\n\n"
                            + "• FOMO: tez upar gaye coin ke peeche bhaagna — aksar top par entry. Retest ka intezar karein.\n"
                            + "• Revenge trading: loss ke foran baad bara trade — sab se bura faisla.\n"
                            + "• Overtrading: har signal lena zaroori nahi. Accuracy mode isi liye hai.\n"
                            + "• Journal rakhein: har trade ki wajah, entry, stop, nateeja. Signals tab ka win/loss record bhi yahi kaam karta hai.\n\n"
                            + "Yaad rakhein: koi signal guarantee nahi. Bot aapka madadgar hai, faisla aur zimmedari aapki."},
            {"🔁", "Multi-timeframe analysis", "Advanced",
                    "Ek hi waqt mein teen timeframe dekhein:\n"
                            + "1. Bara (1d / 4h): direction kya hai?\n"
                            + "2. Darmiyana (1h): setup kahan ban raha?\n"
                            + "3. Chhota (15m / 5m): entry ka trigger.\n\n"
                            + "Jab teeno ek taraf hon to win rate kaafi behtar hota hai. ParaDox 'Timeframes agreement' mein yahi ginta hai (+4 = sab bullish, −4 = sab bearish). Accuracy mode mein agreement zaroori hai."},
    };

    /** Short teaching tip for an analysis section, matched by its title. */
    public static String sectionTip(String title) {
        String t = title == null ? "" : title.toLowerCase(java.util.Locale.US);
        if (t.startsWith("technical"))
            return "Har timeframe par trend (EMA21/50), RSI aur MACD dekhe gaye. Bade timeframes ko zyada wazan milta hai. "
                    + "Sab timeframes ek taraf hon to signal mazboot; mile jule hon to intezar behtar.";
        if (t.contains("moving average"))
            return "EMA 9·21·50·100·200 ki tarteeb trend batati hai: 9>21>50>200 = uptrend. EMA9/21 cross entry ka trigger, "
                    + "EMA50/200 golden/death cross lamba trend. Backtest batata hai ke yeh rule isi chart par pehle kitni dafa kamyab hua.";
        if (t.contains("money flow"))
            return "CVD = khareed volume − bech volume. Price flat magar CVD upar = chupke se khareed. OBV volume ke saath trend dikhata hai.";
        if (t.contains("whale"))
            return "Bade trades aur order book ki deewarein dikhati hain ke bade players kidhar hain. Bari buy wall support ka kaam karti hai — magar hata di jaye to dhoka.";
        if (t.contains("futures"))
            return "Funding zyada positive = log bahut long (squeeze ka khatra). Top traders ka ratio aur open interest batata hai ke naya paisa kis taraf aa raha.";
        if (t.startsWith("catalyst"))
            return "Pehle se public events: token unlock (supply barhti hai = dabao), Binance listing ka elaan (aksar pump), delisting (dump), airdrop, "
                    + "mainnet, ETF faisle, Polymarket odds ka achanak badalna aur futures mein positions jama hona. Jitna qareeb aur bara event, utna zyada wazan. "
                    + "Bara unlock ya delisting 3 din ke andar ho to bot BUY signal nahi bhejta.";
        if (t.startsWith("news radar"))
            return "40+ news sources (crypto sites, Google News, Binance, X posts) ki pichle 24 ghante ki khabrein. Har khabar ka wazan: shiddat × kitne "
                    + "outlets ne chhapi × kitni taaza (4 ghante mein aadha). Bari exchange hack ya stablecoin depeg = poori market ke liye 'market risk' — "
                    + "accuracy mode mein us waqt BUY signals ruk jate hain.";
        if (t.contains("sentiment") || t.contains("raaye"))
            return "Fear & Greed aur news ka mood. Extreme greed par ehtiyat, extreme fear aksar khareed ka mauqa — magar akela kabhi signal nahi.";
        if (t.contains("exchanges"))
            return "10 exchanges ka volume jor kar dekha jata hai — sirf Binance par bharosa ghalat ho sakta hai. Sab jagah buyers aage = asal demand.";
        if (t.contains("volume in"))
            return "1, 5, 15 minute mein kitna paisa aaya (IN) aur gaya (OUT). Scalp ke liye sab se tez ishara.";
        if (t.contains("bade players") || t.contains("institution"))
            return "ETF, companies aur bade wallets ki khareed/farokht. Lambay arsay ka paisa — spot trades ke liye ahem.";
        if (t.contains("etf"))
            return "Amrika ke spot ETFs mein inflow = institutions khareed rahe. Kai din ka lagataar inflow bullish hota hai.";
        if (t.contains("macro") || t.contains("dollar"))
            return "Dollar mazboot (DXY upar) = gold, EURUSD, crypto par dabao. Yields upar = gold par dabao. Bari news ke qareeb fake moves aate hain.";
        if (t.contains("on-chain"))
            return "Stablecoin supply barhna = naya paisa market mein. Exchanges se coins nikalna = log hold kar rahe (bullish).";
        if (t.contains("pattern"))
            return "Bot khud swing highs/lows se trendlines, triangle, double top/bottom aur S/R zones banata hai. Breakout tab sacha jab close + volume ho.";
        if (t.contains("momentum"))
            return "Din aur hafte ki tabdeeli aur 20-din range mein jagah. Range ke upar = taqat, magar resistance ke qareeb bhi.";
        return "Yeh section score −100 se +100 deta hai; final score sab sections ka wazni ausat hai.";
    }
}
