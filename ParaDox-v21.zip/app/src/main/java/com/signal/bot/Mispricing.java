package com.signal.bot;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * ⚡ Mispricing radar — pure logic, no prediction: finds PRICE GAPS that usually close within seconds/minutes.
 *  1. Cross-exchange: the same coin cheaper on one exchange than another (bid/ask, after fees) — 8 exchanges, all USDT pairs
 *  2. Price errors: one exchange's price far away from the median of all others (fat finger, broken book, stale feed)
 *  3. Triangular (Binance): USDT → coin → BTC/ETH/BNB → USDT loops that end with more USDT than they started
 *  4. Futures vs spot (Binance): perp price far from index, extreme funding (cash-and-carry)
 *  5. Stablecoin pegs: USDC / FDUSD / TUSD / USDP away from $1
 *  6. Flash moves: liquid coins jumping > 1.5% between two scans (seconds)
 * Each gap is "paper-tracked": the bot re-checks it on later scans to learn how fast such gaps really close.
 */
public final class Mispricing {
    private Mispricing() {}

    public static final class Quote {
        public String venue, base;
        public double bid, ask, last, vol24;
        double mid() { return bid > 0 && ask > 0 ? (bid + ask) / 2 : last; }
    }

    public static final class Gap {
        public String kind, base, buyVenue = "", sellVenue = "", title = "", detail = "";
        public double grossPct, netPct, buyPrice, sellPrice, sizeUsd, minVol;
        public long firstSeen, lastSeen;
        public int seen = 1;
        public boolean suspicious;   // probably a different token with the same ticker / deposits closed
        public String key() { return kind + "|" + base + "|" + buyVenue + "|" + sellVenue; }
    }

    public static final class Result {
        public final List<Gap> cross = new ArrayList<>(), errors = new ArrayList<>(), tri = new ArrayList<>(),
                basis = new ArrayList<>(), pegs = new ArrayList<>(), flash = new ArrayList<>();
        public final List<String> venuesOk = new ArrayList<>(), venuesFail = new ArrayList<>();
        public int coins, scanNo;
        public long ms, at;
    }

    public static final String CROSS = "cross", ERROR = "error", TRI = "tri", BASIS = "basis", PEG = "peg", FLASH = "flash";
    public static final String[] VENUES = {"Binance", "OKX", "Bybit", "Bitget", "KuCoin", "Gate", "MEXC", "HTX"};
    static final String[] FAST = {"Binance", "OKX", "Bybit", "Bitget"};

    private static final ExecutorService POOL = Executors.newFixedThreadPool(8);
    private static final Map<String, Map<String, Quote>> LAST = new ConcurrentHashMap<>();
    private static final Map<String, Long> LAST_AT = new ConcurrentHashMap<>();
    private static final Map<String, Double> PREV_MID = new ConcurrentHashMap<>();
    private static volatile long prevMidAt;
    private static volatile Result cache;
    private static int scans;
    private static final Object LOCK = new Object();

    // paper tracking: how long gaps stay open
    private static final Map<String, Gap> LIVE = new ConcurrentHashMap<>();
    public static final List<long[]> CLOSED = Collections.synchronizedList(new ArrayList<>());   // {lifetime ms, net bp*100}

    public static Result cached() { return cache; }

    static double d(String s) {
        try { return Double.parseDouble(s); } catch (Exception e) { return 0; }
    }

    // ------------------------------------------------------------------ bulk tickers (one request per exchange)
    static Map<String, Quote> load(String v) throws Exception {
        Map<String, Quote> m = new HashMap<>();
        switch (v) {
            case "Binance": {
                JSONArray b = new JSONArray(Scanner.get("/api/v3/ticker/bookTicker"));
                Map<String, Double> vol = binanceVol();
                for (int i = 0; i < b.length(); i++) {
                    JSONObject o = b.getJSONObject(i);
                    String s = o.optString("symbol");
                    Quote q = new Quote();
                    q.bid = d(o.optString("bidPrice"));
                    q.ask = d(o.optString("askPrice"));
                    q.last = q.mid();
                    Double vv = vol.get(s);
                    q.vol24 = vv == null ? 0 : vv;
                    q.base = s;               // full symbol for Binance (needed for triangles)
                    put(m, "Binance", s, q);
                }
                break;
            }
            case "OKX": {
                JSONArray a = new JSONObject(Scanner.getAbsolute("https://www.okx.com/api/v5/market/tickers?instType=SPOT")).getJSONArray("data");
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    String id = o.optString("instId");
                    if (!id.endsWith("-USDT")) continue;
                    Quote q = q(d(o.optString("bidPx")), d(o.optString("askPx")), d(o.optString("last")), d(o.optString("volCcy24h")));
                    put(m, v, id.substring(0, id.length() - 5), q);
                }
                break;
            }
            case "Bybit": {
                JSONArray a = new JSONObject(Scanner.getAbsolute("https://api.bybit.com/v5/market/tickers?category=spot")).getJSONObject("result").getJSONArray("list");
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    String s = o.optString("symbol");
                    if (!s.endsWith("USDT")) continue;
                    put(m, v, s.substring(0, s.length() - 4), q(d(o.optString("bid1Price")), d(o.optString("ask1Price")), d(o.optString("lastPrice")), d(o.optString("turnover24h"))));
                }
                break;
            }
            case "Bitget": {
                JSONArray a = new JSONObject(Scanner.getAbsolute("https://api.bitget.com/api/v2/spot/market/tickers")).getJSONArray("data");
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    String s = o.optString("symbol");
                    if (!s.endsWith("USDT")) continue;
                    put(m, v, s.substring(0, s.length() - 4), q(d(o.optString("bidPr")), d(o.optString("askPr")), d(o.optString("lastPr")), d(o.optString("usdtVolume", o.optString("quoteVolume")))));
                }
                break;
            }
            case "KuCoin": {
                JSONArray a = new JSONObject(Scanner.getAbsolute("https://api.kucoin.com/api/v1/market/allTickers")).getJSONObject("data").getJSONArray("ticker");
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    String s = o.optString("symbol");
                    if (!s.endsWith("-USDT")) continue;
                    put(m, v, s.substring(0, s.length() - 5), q(d(o.optString("buy")), d(o.optString("sell")), d(o.optString("last")), d(o.optString("volValue"))));
                }
                break;
            }
            case "Gate": {
                JSONArray a = new JSONArray(Scanner.getAbsolute("https://api.gateio.ws/api/v4/spot/tickers"));
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    String s = o.optString("currency_pair");
                    if (!s.endsWith("_USDT")) continue;
                    put(m, v, s.substring(0, s.length() - 5), q(d(o.optString("highest_bid")), d(o.optString("lowest_ask")), d(o.optString("last")), d(o.optString("quote_volume"))));
                }
                break;
            }
            case "MEXC": {
                JSONArray a = new JSONArray(Scanner.getAbsolute("https://api.mexc.com/api/v3/ticker/24hr"));
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    String s = o.optString("symbol");
                    if (!s.endsWith("USDT")) continue;
                    put(m, v, s.substring(0, s.length() - 4), q(d(o.optString("bidPrice")), d(o.optString("askPrice")), d(o.optString("lastPrice")), d(o.optString("quoteVolume"))));
                }
                break;
            }
            case "HTX": {
                JSONArray a = new JSONObject(Scanner.getAbsolute("https://api.huobi.pro/market/tickers")).getJSONArray("data");
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    String s = o.optString("symbol");
                    if (!s.endsWith("usdt")) continue;
                    put(m, v, s.substring(0, s.length() - 4).toUpperCase(Locale.US), q(o.optDouble("bid", 0), o.optDouble("ask", 0), o.optDouble("close", 0), o.optDouble("vol", 0)));
                }
                break;
            }
            default:
                break;
        }
        return m;
    }

    static Quote q(double bid, double ask, double last, double vol) {
        Quote q = new Quote();
        q.bid = bid; q.ask = ask; q.last = last; q.vol24 = vol;
        return q;
    }

    static void put(Map<String, Quote> m, String v, String base, Quote q) {
        if (q.bid <= 0 || q.ask <= 0 || q.ask < q.bid) return;
        q.venue = v;
        if (q.base == null) q.base = base;
        m.put(base, q);
    }

    private static volatile Map<String, Double> bVol = new HashMap<>();
    private static volatile long bVolAt;

    static Map<String, Double> binanceVol() {
        if (System.currentTimeMillis() - bVolAt < 5 * 60_000L && !bVol.isEmpty()) return bVol;
        try {
            JSONArray a = new JSONArray(Scanner.get("/api/v3/ticker/24hr?type=MINI"));
            Map<String, Double> m = new HashMap<>();
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                m.put(o.optString("symbol"), d(o.optString("quoteVolume")));
            }
            bVol = m;
            bVolAt = System.currentTimeMillis();
        } catch (Exception ignored) {
        }
        return bVol;
    }

    // ------------------------------------------------------------------ the scan
    /**
     * @param fastOnly  only the 4 fastest exchanges this time (others reuse their last snapshot if < 60 s old)
     * @param feePct    taker fee per trade (%)
     * @param minVolUsd both sides need this 24h volume
     */
    public static Result scan(boolean fastOnly, double feePct, double minVolUsd) {
        synchronized (LOCK) {
            long t0 = System.currentTimeMillis();
            final Result r = new Result();
            List<java.util.concurrent.Callable<Void>> jobs = new ArrayList<>();
            for (final String v : VENUES) {
                boolean fast = false;
                for (String f : FAST) if (f.equals(v)) fast = true;
                Long at = LAST_AT.get(v);
                if (fastOnly && !fast && at != null && t0 - at < 60_000L) { r.venuesOk.add(v + "*"); continue; }
                jobs.add(() -> {
                    try {
                        Map<String, Quote> m = load(v);
                        if (!m.isEmpty()) {
                            LAST.put(v, m);
                            LAST_AT.put(v, System.currentTimeMillis());
                            synchronized (r) { r.venuesOk.add(v); }
                        }
                    } catch (Exception e) {
                        synchronized (r) { r.venuesFail.add(v); }
                    }
                    return null;
                });
            }
            try { POOL.invokeAll(jobs, 15, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
            long now = System.currentTimeMillis();
            Map<String, Quote> bin = LAST.get("Binance");

            // ---- per coin across venues (USDT pairs)
            Map<String, List<Quote>> byCoin = new HashMap<>();
            for (Map.Entry<String, Map<String, Quote>> e : LAST.entrySet()) {
                Long at = LAST_AT.get(e.getKey());
                if (at == null || now - at > 90_000L) continue;   // stale snapshot: never compare
                for (Quote q : e.getValue().values()) {
                    String base = e.getKey().equals("Binance") ? (q.base.endsWith("USDT") ? q.base.substring(0, q.base.length() - 4) : null) : q.base;
                    if (base == null || base.isEmpty()) continue;
                    byCoin.computeIfAbsent(base, k -> new ArrayList<>()).add(q);
                }
            }
            r.coins = byCoin.size();
            for (Map.Entry<String, List<Quote>> e : byCoin.entrySet()) {
                List<Quote> l = e.getValue();
                if (l.size() < 2) continue;
                String base = e.getKey();
                if (isStable(base)) continue;
                // median mid
                List<Double> mids = new ArrayList<>();
                for (Quote q : l) mids.add(q.mid());
                Collections.sort(mids);
                double med = mids.get(mids.size() / 2);
                // cross-exchange: buy at the lowest ask, sell at the highest bid
                Quote lo = null, hi = null;
                for (Quote q : l) {
                    if (q.vol24 < minVolUsd) continue;
                    if (lo == null || q.ask < lo.ask) lo = q;
                    if (hi == null || q.bid > hi.bid) hi = q;
                }
                if (lo != null && hi != null && lo != hi && hi.bid > lo.ask) {
                    double gross = (hi.bid / lo.ask - 1) * 100, net = gross - 2 * feePct;
                    if (net > 0) {
                        Gap g = new Gap();
                        g.kind = CROSS;
                        g.base = base;
                        g.buyVenue = lo.venue;
                        g.sellVenue = hi.venue;
                        g.buyPrice = lo.ask;
                        g.sellPrice = hi.bid;
                        g.grossPct = gross;
                        g.netPct = net;
                        g.minVol = Math.min(lo.vol24, hi.vol24);
                        g.suspicious = gross > 12;
                        g.title = base + ": " + lo.venue + " par khareedo $" + Fmt.price(lo.ask) + " → " + hi.venue + " par becho $" + Fmt.price(hi.bid);
                        g.detail = String.format(Locale.US, "Gross %.2f%% · fees −%.2f%% · NET %.2f%% · %d exchanges par listed", gross, 2 * feePct, net, l.size());
                        r.cross.add(g);
                    }
                }
                // price errors: one venue far from the others (need 3+ venues)
                if (l.size() >= 3 && med > 0) {
                    for (Quote q : l) {
                        if (q.vol24 < minVolUsd * 0.5) continue;
                        double dev = (q.mid() / med - 1) * 100;
                        if (Math.abs(dev) < 1.5) continue;
                        int agree = 0;
                        for (Quote o : l) if (o != q && Math.abs(o.mid() / med - 1) * 100 < 0.5) agree++;
                        if (agree < 2) continue;
                        Gap g = new Gap();
                        g.kind = ERROR;
                        g.base = base;
                        g.buyVenue = dev < 0 ? q.venue : "";
                        g.sellVenue = dev > 0 ? q.venue : "";
                        g.grossPct = Math.abs(dev);
                        g.netPct = Math.abs(dev) - 2 * feePct;
                        g.minVol = q.vol24;
                        g.suspicious = Math.abs(dev) > 12;
                        g.title = base + " ki price " + q.venue + " par GHALAT lag rahi: $" + Fmt.price(q.mid()) + " jab ke baqi " + agree + " exchanges ~$" + Fmt.price(med);
                        g.detail = String.format(Locale.US, "%s %.2f%% %s median se · %s", q.venue, Math.abs(dev), dev > 0 ? "UPAR" : "NEECHE",
                                dev < 0 ? "wahan sasta (khareed ka mauqa)" : "wahan mehnga (bechne ka mauqa)");
                        r.errors.add(g);
                    }
                }
            }
            // ---- Binance triangles + pegs + flash
            if (bin != null) {
                triangles(bin, feePct, r);
                pegs(bin, r);
                flash(bin, r, now);
            }
            // ---- futures basis / funding
            try { basis(r, bin); } catch (Exception ignored) { }

            Collections.sort(r.cross, (a, b) -> Double.compare(b.netPct, a.netPct));
            Collections.sort(r.errors, (a, b) -> Double.compare(b.grossPct, a.grossPct));
            Collections.sort(r.tri, (a, b) -> Double.compare(b.netPct, a.netPct));
            Collections.sort(r.basis, (a, b) -> Double.compare(Math.abs(b.netPct), Math.abs(a.netPct)));
            trim(r.cross, 60);
            trim(r.errors, 40);
            trim(r.tri, 40);
            trim(r.basis, 40);
            track(r, now);
            r.ms = System.currentTimeMillis() - t0;
            r.at = now;
            r.scanNo = ++scans;
            cache = r;
            return r;
        }
    }

    static void trim(List<Gap> l, int n) { if (l.size() > n) l.subList(n, l.size()).clear(); }

    static boolean isStable(String b) {
        return b.equals("USDC") || b.equals("FDUSD") || b.equals("TUSD") || b.equals("USDP") || b.equals("DAI") || b.equals("BUSD") || b.equals("USDE")
                || b.equals("PYUSD") || b.equals("USD1") || b.equals("EUR") || b.equals("EURI") || b.equals("USDS") || b.equals("RLUSD");
    }

    static final String[] HUBS = {"BTC", "ETH", "BNB"};

    /** USDT → X → HUB → USDT and USDT → HUB → X → USDT, at bid/ask, after 3 fees. */
    static void triangles(Map<String, Quote> b, double fee, Result r) {
        for (String hub : HUBS) {
            Quote hubUsdt = b.get(hub + "USDT");
            if (hubUsdt == null) continue;
            for (Quote xh : b.values()) {
                if (!xh.base.endsWith(hub) || xh.base.length() <= hub.length()) continue;
                String x = xh.base.substring(0, xh.base.length() - hub.length());
                Quote xu = b.get(x + "USDT");
                if (xu == null || xu.vol24 < 200_000) continue;
                double f = Math.pow(1 - fee / 100, 3);
                // A: buy X with USDT, sell X for HUB, sell HUB for USDT
                double a = (1 / xu.ask) * xh.bid * hubUsdt.bid * f;
                // B: buy HUB with USDT, buy X with HUB, sell X for USDT
                double bb = (1 / hubUsdt.ask) / xh.ask * xu.bid * f;
                double best = Math.max(a, bb);
                if (best <= 1.0005) continue;
                boolean isA = a >= bb;
                Gap g = new Gap();
                g.kind = TRI;
                g.base = x;
                g.buyVenue = "Binance";
                g.sellVenue = "Binance";
                g.netPct = (best - 1) * 100;
                g.grossPct = g.netPct + 3 * fee;
                g.minVol = xu.vol24;
                g.title = isA ? "USDT → " + x + " → " + hub + " → USDT" : "USDT → " + hub + " → " + x + " → USDT";
                g.detail = String.format(Locale.US, "%sUSDT %s · %s%s %s · %sUSDT %s · NET %+.3f%% (3 fees −%.2f%%)",
                        x, Fmt.price(isA ? xu.ask : xu.bid), x, hub, Fmt.price(isA ? xh.bid : xh.ask), hub, Fmt.price(isA ? hubUsdt.bid : hubUsdt.ask), g.netPct, 3 * fee);
                g.suspicious = g.netPct > 3;
                r.tri.add(g);
            }
        }
    }

    static void pegs(Map<String, Quote> b, Result r) {
        for (String s : new String[]{"USDC", "FDUSD", "TUSD", "USDP", "USDE", "USD1", "PYUSD", "RLUSD"}) {
            Quote q = b.get(s + "USDT");
            if (q == null) continue;
            double dev = (q.mid() - 1) * 100;
            Gap g = new Gap();
            g.kind = PEG;
            g.base = s;
            g.buyPrice = q.ask;
            g.sellPrice = q.bid;
            g.grossPct = dev;
            g.netPct = Math.abs(dev);
            g.title = s + "/USDT = " + String.format(Locale.US, "%.4f", q.mid());
            g.detail = Math.abs(dev) >= 0.3 ? (dev < 0 ? "⚠️ $1 se NEECHE — depeg ka khatra / sasta khareed" : "⚠️ $1 se UPAR — demand / bechne ka mauqa")
                    : "✅ Peg theek (" + String.format(Locale.US, "%+.3f%%", dev) + ")";
            g.suspicious = Math.abs(dev) >= 0.3;
            r.pegs.add(g);
        }
    }

    static void flash(Map<String, Quote> b, Result r, long now) {
        boolean have = !PREV_MID.isEmpty() && now - prevMidAt < 5 * 60_000L;
        long dt = now - prevMidAt;
        for (Quote q : b.values()) {
            if (!q.base.endsWith("USDT") || q.vol24 < 2_000_000) continue;
            double m = q.mid();
            Double p = PREV_MID.get(q.base);
            if (have && p != null && p > 0) {
                double ch = (m / p - 1) * 100;
                if (Math.abs(ch) >= 1.5) {
                    Gap g = new Gap();
                    g.kind = FLASH;
                    g.base = q.base.substring(0, q.base.length() - 4);
                    g.grossPct = ch;
                    g.netPct = Math.abs(ch);
                    g.minVol = q.vol24;
                    g.title = g.base + String.format(Locale.US, " %+.2f%% sirf %d second mein", ch, dt / 1000);
                    g.detail = (ch > 0 ? "Tez UPAR — koi bara buyer / khabar / short squeeze" : "Tez NEECHE — bara seller / liquidations / khabar") + " · 24h vol " + Fmt.usd(q.vol24);
                    r.flash.add(g);
                }
            }
            PREV_MID.put(q.base, m);
        }
        prevMidAt = now;
        Collections.sort(r.flash, (a, c) -> Double.compare(c.netPct, a.netPct));
    }

    static void basis(Result r, Map<String, Quote> bin) throws Exception {
        JSONArray a = new JSONArray(Scanner.getAbsolute("https://fapi.binance.com/fapi/v1/premiumIndex"));
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i);
            String s = o.optString("symbol");
            if (!s.endsWith("USDT")) continue;
            double mark = d(o.optString("markPrice")), idx = d(o.optString("indexPrice")), fr = d(o.optString("lastFundingRate")) * 100;
            if (idx <= 0) continue;
            Quote sq = bin != null ? bin.get(s) : null;
            if (sq == null || sq.vol24 < 1_000_000) continue;
            double bas = (mark / idx - 1) * 100;
            double apr = fr * 3 * 365;
            if (Math.abs(fr) < 0.05 && Math.abs(bas) < 0.5) continue;
            Gap g = new Gap();
            g.kind = BASIS;
            g.base = s.substring(0, s.length() - 4);
            g.grossPct = bas;
            g.netPct = apr;
            g.minVol = sq.vol24;
            g.buyVenue = fr > 0 ? "Binance Spot" : "Binance Futures";
            g.sellVenue = fr > 0 ? "Binance Futures" : "Binance Spot";
            g.title = g.base + String.format(Locale.US, ": funding %+.3f%% / 8h (≈ %+.0f%% saalana) · futures %+.2f%% index se", fr, apr, bas);
            g.detail = fr > 0 ? "Longs bahut bhare hue: spot KHAREEDO + futures SHORT = har 8 ghante funding milti hai (cash-and-carry). Squeeze-down ka khatra bhi."
                    : "Shorts bahut bhare hue: funding shorts dete hain · short squeeze (tez upar) ka imkaan";
            r.basis.add(g);
        }
    }

    // ------------------------------------------------------------------ paper tracking (how fast do gaps close?)
    static void track(Result r, long now) {
        Set<String> alive = new LinkedHashSet<>();
        for (List<Gap> l : java.util.Arrays.asList(r.cross, r.tri, r.errors)) {
            for (Gap g : l) {
                if (g.suspicious) continue;
                String k = g.key();
                alive.add(k);
                Gap old = LIVE.get(k);
                if (old == null) {
                    g.firstSeen = now;
                    g.lastSeen = now;
                    LIVE.put(k, g);
                } else {
                    g.firstSeen = old.firstSeen;
                    g.seen = old.seen + 1;
                    g.lastSeen = now;
                    LIVE.put(k, g);
                }
            }
        }
        for (String k : new ArrayList<>(LIVE.keySet())) {
            if (alive.contains(k)) continue;
            Gap g = LIVE.remove(k);
            if (g == null) continue;
            CLOSED.add(new long[]{Math.max(0, g.lastSeen - g.firstSeen), Math.round(g.netPct * 100)});
            if (CLOSED.size() > 500) CLOSED.remove(0);
        }
    }

    /** {count, median lifetime ms, % gone after the first scan, avg net bp} */
    public static double[] paperStats() {
        List<long[]> c;
        synchronized (CLOSED) { c = new ArrayList<>(CLOSED); }
        if (c.isEmpty()) return new double[]{0, 0, 0, 0};
        List<Long> life = new ArrayList<>();
        int once = 0;
        double net = 0;
        for (long[] x : c) {
            life.add(x[0]);
            if (x[0] == 0) once++;
            net += x[1];
        }
        Collections.sort(life);
        return new double[]{c.size(), life.get(life.size() / 2), once * 100.0 / c.size(), net / c.size()};
    }

    // ------------------------------------------------------------------ background alerts
    public static void tick(Context ctx) {
        if (!Prefs.arbOn(ctx)) return;
        long every = Prefs.arbEverySec(ctx) * 1000L;
        if (System.currentTimeMillis() - Prefs.getLong(ctx, "arbtick") < every) return;
        Prefs.putLong(ctx, "arbtick", System.currentTimeMillis());
        Result r = scan(false, Prefs.arbFee(ctx), Prefs.arbMinVol(ctx));
        double min = Prefs.arbMinNet(ctx);
        int sent = 0;
        List<Gap> all = new ArrayList<>();
        all.addAll(r.errors);
        all.addAll(r.cross);
        all.addAll(r.tri);
        for (Gap g : r.pegs) if (g.suspicious) all.add(g);
        for (Gap g : r.flash) if (g.netPct >= 3) all.add(g);
        for (Gap g : all) {
            if (sent >= 3) break;
            if (g.suspicious && !g.kind.equals(PEG)) continue;
            if ((g.kind.equals(CROSS) || g.kind.equals(TRI) || g.kind.equals(ERROR)) && g.netPct < min) continue;
            String k = "arb_" + g.key();
            if (System.currentTimeMillis() - Prefs.getLong(ctx, k) < 30 * 60_000L) continue;
            Prefs.putLong(ctx, k, System.currentTimeMillis());
            String t = (g.kind.equals(ERROR) ? "🎯 PRICE ERROR: " : g.kind.equals(CROSS) ? "⚡ ARBITRAGE: " : g.kind.equals(TRI) ? "🔺 TRIANGLE: "
                    : g.kind.equals(PEG) ? "💵 STABLECOIN PEG: " : "💥 FLASH MOVE: ") + g.base
                    + (g.kind.equals(FLASH) || g.kind.equals(PEG) ? "" : String.format(Locale.US, " · NET %+.2f%%", g.netPct));
            Notify.showPage(ctx, Prefs.N_ARB, k.hashCode(), t, g.title + "\n" + g.detail + "\n⏱ Aise gaps aksar seconds mein band ho jate hain — check karke hi trade karein.",
                    0xFFF0B90B, "arb");
            sent++;
        }
    }
}
