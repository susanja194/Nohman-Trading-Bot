package com.signal.bot;

/**
 * Chart buttons can be a candle interval (1m … 1w, 1M) or a time RANGE (1Y, 2Y, 3Y, 4Y, 5Y, ALL).
 * A range is mapped to a Binance interval + number of candles.
 */
public final class ChartRange {
    private ChartRange() {}

    public static final String[] ALL_TFS = {"1m", "3m", "5m", "15m", "30m", "1h", "4h", "1d", "1w", "1M", "1Y", "2Y", "3Y", "4Y", "5Y", "ALL"};
    public static final String[] RANGES = {"1Y", "2Y", "3Y", "4Y", "5Y", "ALL"};

    public static boolean isRange(String tf) {
        for (String r : RANGES) if (r.equals(tf)) return true;
        return false;
    }

    /** Binance kline interval for this button. */
    public static String interval(String tf) {
        switch (tf) {
            case "1Y": case "2Y": return "1d";
            case "3Y": case "4Y": case "5Y": return "1w";
            case "ALL": return "1M";
            default: return tf;
        }
    }

    /** Number of candles to load. */
    public static int limit(String tf) {
        switch (tf) {
            case "1Y": return 365;
            case "2Y": return 730;
            case "3Y": return 157;
            case "4Y": return 209;
            case "5Y": return 261;
            case "ALL": return 1000;
            case "1M": return 300;
            default: return 300;
        }
    }

    /** Candles shown on screen at once (ranges show everything). */
    public static int visible(String tf, int n) {
        return isRange(tf) || "1M".equals(tf) ? n : 90;
    }
}
