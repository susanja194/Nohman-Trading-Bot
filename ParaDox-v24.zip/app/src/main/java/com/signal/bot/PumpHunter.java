package com.signal.bot;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * 🎯 Gainer / Loser hunter — finds coins BEFORE they reach the top-gainers / top-losers list.
 * Pumps almost always leave footprints first:
 *   1. Volume wakes up: last 15 min volume many times its normal pace (RVOL), while the price has NOT moved much yet
 *   2. Aggressive buyers (taker buy %) take over · bid side of the order book thicker than asks
 *   3. Futures positions build (open interest up) · funding not yet crowded
 *   4. Tight range (squeeze) just breaking
 *   5. Korea first: Upbit (KRW) volume spike / kimchi premium often starts Asian pumps
 *   6. News / listing / catalyst for the coin
 * Mirror logic finds dumps. Every alert is tracked: did the coin really move 5%+ within 4 h?
 */
public final class PumpHunter {
    private PumpHunter() {}

    public static final class Pick {
        public String sym, base;
        public boolean pump;            // true = likely gainer, false = likely loser
        public int score;               // 0..100
        public double price, ch15, ch1h, ch24, rvol15, rvol1h, buyPct, bookImb = Double.NaN, oiCh = Double.NaN, funding = Double.NaN,
                upbitRvol = Double.NaN, kimchi = Double.NaN, vol24, squeeze;
        public final List<String> why = new ArrayList<>();
        public long at;
    }

    public static final class Result {
        public final List<Pick> pumps = new ArrayList<>(), dumps = new ArrayList<>();
        public int scanned;
        public long ms, at;
        public String note = "";
    }

    private static volatile Result cache;
    private static final Object LOCK = new Object();
    private static final ExecutorService POOL = Executors.newFixedThreadPool(6);

    public static Result cached() { return cache; }

    static double d(String s) {
        try { return Double.parseDouble(s); } catch (Exception e) { return 0; }
    }

    /** Binance rolling-window stats for many symbols (100 per request). {sym -> {quoteVol, change%}} */
    static Map<String, double[]> window(List<String> syms, String w) {
        Map<String, double[]> out = new HashMap<>();
        for (int i = 0; i < syms.size(); i += 100) {
            List<String> part = syms.subList(i, Math.min(syms.size(), i + 100));
            StringBuilder q = new StringBuilder("[");
            for (String s : part) { if (q.length() > 1) q.append(','); q.append('"').append(s).append('"'); }
            q.append(']');
            try {
                JSONArray a = new JSONArray(Scanner.get("/api/v3/ticker?type=MINI&windowSize=" + w + "&symbols=" + java.net.URLEncoder.encode(q.toString(), "UTF-8")));
                for (int k = 0; k < a.length(); k++) {
                    JSONObject o = a.getJSONObject(k);
                    double open = d(o.optString("openPrice")), last = d(o.optString("lastPrice"));
                    out.put(o.optString("symbol"), new double[]{d(o.optString("quoteVolume")), open > 0 ? (last / open - 1) * 100 : 0});
                }
            } catch (Exception ignored) {
            }
        }
        return out;
    }

    public static Result scan(Context ctx) {
        synchronized (LOCK) {
            long t0 = System.currentTimeMillis();
            Result r = new Result();
            Map<String, double[]> day = new HashMap<>();   // sym -> {last, change24, quoteVol24}
            try {
                JSONArray a = new JSONArray(Scanner.get("/api/v3/ticker/24hr?type=MINI"));
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    String s = o.optString("symbol");
                    if (!Scanner.isTradable(s)) continue;
                    double last = d(o.optString("lastPrice")), open = d(o.optString("openPrice")), qv = d(o.optString("quoteVolume"));
                    if (last <= 0 || qv < 300_000) continue;
                    day.put(s, new double[]{last, open > 0 ? (last / open - 1) * 100 : 0, qv});
                }
            } catch (Exception e) {
                r.note = "Binance tak pohanch nahi hui";
                return r;
            }
            List<String> syms = new ArrayList<>(day.keySet());
            Map<String, double[]> w15 = window(syms, "15m"), w1h = window(syms, "1h");
            r.scanned = syms.size();
            // ---- stage 1: cheap screen on volume pace vs price move
            List<Pick> cands = new ArrayList<>();
            for (String s : syms) {
                double[] dd = day.get(s), a15 = w15.get(s), a1 = w1h.get(s);
                if (a15 == null || a1 == null) continue;
                double pace15 = dd[2] / 96.0, pace1h = dd[2] / 24.0;
                double rv15 = pace15 > 0 ? a15[0] / pace15 : 0, rv1 = pace1h > 0 ? a1[0] / pace1h : 0;
                if (rv15 < 2.2 && rv1 < 1.8) continue;
                Pick p = new Pick();
                p.sym = s;
                p.base = s.substring(0, s.length() - 4);
                p.price = dd[0];
                p.ch24 = dd[1];
                p.vol24 = dd[2];
                p.ch15 = a15[1];
                p.ch1h = a1[1];
                p.rvol15 = rv15;
                p.rvol1h = rv1;
                cands.add(p);
            }
            // early = volume woke up but price has not run yet
            Collections.sort(cands, (x, y) -> Double.compare(early(y), early(x)));
            if (cands.size() > 24) cands = new ArrayList<>(cands.subList(0, 24));
            // ---- stage 2: deep checks in parallel
            List<Callable<Void>> jobs = new ArrayList<>();
            for (final Pick p : cands) jobs.add(() -> { deep(p); return null; });
            try { POOL.invokeAll(jobs, 25, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
            upbit(cands);
            long now = System.currentTimeMillis();
            for (Pick p : cands) {
                score(p);
                p.at = now;
                if (p.score < 40) continue;
                if (p.pump) r.pumps.add(p); else r.dumps.add(p);
            }
            Collections.sort(r.pumps, (x, y) -> y.score - x.score);
            Collections.sort(r.dumps, (x, y) -> y.score - x.score);
            r.ms = System.currentTimeMillis() - t0;
            r.at = now;
            cache = r;
            if (ctx != null) Track.record(ctx, r);
            return r;
        }
    }

    static double early(Pick p) {
        double moved = Math.abs(p.ch1h);
        return p.rvol15 * 1.2 + p.rvol1h - moved * 0.6 - Math.max(0, Math.abs(p.ch24) - 12) * 0.3;
    }

    /** 5m candles (taker buy %, squeeze), order book imbalance, futures OI + funding. */
    static void deep(Pick p) {
        try {
            Candles c = Candles.fetch(p.sym, "5m", 60, false);
            int n = c.n;
            if (n > 20) {
                double tb = 0, q = 0;
                for (int i = n - 3; i < n; i++) { tb += c.takerBuyQuote[i]; q += c.quoteVol[i]; }
                p.buyPct = q > 0 ? tb / q * 100 : 50;
                double hi = 0, lo = Double.MAX_VALUE, hi2 = 0, lo2 = Double.MAX_VALUE;
                for (int i = n - 40; i < n - 4; i++) { hi = Math.max(hi, c.high[i]); lo = Math.min(lo, c.low[i]); }
                for (int i = n - 4; i < n; i++) { hi2 = Math.max(hi2, c.high[i]); lo2 = Math.min(lo2, c.low[i]); }
                p.squeeze = lo > 0 ? (hi / lo - 1) * 100 : 99;   // % range of the 3 hours before
                if (c.close[n - 1] > hi && p.squeeze < 4) p.why.add(String.format(Locale.US, "Tight range (%.1f%%) se UPAR breakout", p.squeeze));
                if (c.close[n - 1] < lo && p.squeeze < 4) p.why.add(String.format(Locale.US, "Tight range (%.1f%%) se NEECHE breakdown", p.squeeze));
            }
        } catch (Exception ignored) {
        }
        try {
            JSONObject o = new JSONObject(Scanner.get("/api/v3/depth?symbol=" + p.sym + "&limit=100"));
            JSONArray b = o.getJSONArray("bids"), a = o.getJSONArray("asks");
            double mid = p.price, bs = 0, as = 0;
            for (int i = 0; i < b.length(); i++) { JSONArray x = b.getJSONArray(i); double pr = d(x.getString(0)); if (pr >= mid * 0.98) bs += pr * d(x.getString(1)); }
            for (int i = 0; i < a.length(); i++) { JSONArray x = a.getJSONArray(i); double pr = d(x.getString(0)); if (pr <= mid * 1.02) as += pr * d(x.getString(1)); }
            if (bs + as > 0) p.bookImb = (bs - as) / (bs + as) * 100;
        } catch (Exception ignored) {
        }
        try {
            JSONArray oi = new JSONArray(Scanner.getAbsolute("https://fapi.binance.com/futures/data/openInterestHist?symbol=" + p.sym + "&period=5m&limit=13"));
            if (oi.length() >= 12) {
                double o0 = oi.getJSONObject(0).optDouble("sumOpenInterestValue", 0), o1 = oi.getJSONObject(oi.length() - 1).optDouble("sumOpenInterestValue", 0);
                if (o0 > 0) p.oiCh = (o1 / o0 - 1) * 100;
            }
            JSONArray f = new JSONArray(Scanner.getAbsolute("https://fapi.binance.com/fapi/v1/fundingRate?symbol=" + p.sym + "&limit=1"));
            if (f.length() > 0) p.funding = f.getJSONObject(0).optDouble("fundingRate", 0) * 100;
        } catch (Exception ignored) {
        }
    }

    /** Korea: Upbit KRW volume spike + kimchi premium for the candidates listed there. */
    static void upbit(List<Pick> l) {
        try {
            JSONArray mk = new JSONArray(Scanner.getAbsolute("https://api.upbit.com/v1/market/all"));
            java.util.Set<String> krw = new java.util.HashSet<>();
            for (int i = 0; i < mk.length(); i++) {
                String m = mk.getJSONObject(i).optString("market");
                if (m.startsWith("KRW-")) krw.add(m.substring(4));
            }
            StringBuilder q = new StringBuilder("KRW-USDT");
            for (Pick p : l) if (krw.contains(p.base)) q.append(",KRW-").append(p.base);
            JSONArray t = new JSONArray(Scanner.getAbsolute("https://api.upbit.com/v1/ticker?markets=" + q));
            double usdtKrw = 0;
            Map<String, JSONObject> tk = new HashMap<>();
            for (int i = 0; i < t.length(); i++) {
                JSONObject o = t.getJSONObject(i);
                String m = o.optString("market").substring(4);
                if (m.equals("USDT")) usdtKrw = o.optDouble("trade_price", 0); else tk.put(m, o);
            }
            for (Pick p : l) {
                JSONObject o = tk.get(p.base);
                if (o == null) continue;
                if (usdtKrw > 0 && p.price > 0) p.kimchi = (o.optDouble("trade_price", 0) / (p.price * usdtKrw) - 1) * 100;
                try {
                    JSONArray cs = new JSONArray(Scanner.getAbsolute("https://api.upbit.com/v1/candles/minutes/15?market=KRW-" + p.base + "&count=2"));
                    double v15 = cs.getJSONObject(0).optDouble("candle_acc_trade_price", 0);
                    double day = o.optDouble("acc_trade_price_24h", 0);
                    if (day > 0) p.upbitRvol = v15 / (day / 96.0);
                } catch (Exception ignored) {
                }
            }
        } catch (Exception ignored) {
        }
    }

    static void score(Pick p) {
        double bull = 0, bear = 0;
        double rv = Math.max(p.rvol15, p.rvol1h * 0.9);
        double vScore = Math.min(30, (rv - 1.5) * 8);   // volume is the main footprint
        boolean notRun = Math.abs(p.ch1h) < 6 && Math.abs(p.ch24) < 20;
        double dirFlow = (p.buyPct - 50) / 50;          // −1..1
        if (p.buyPct >= 55) bull += vScore; else if (p.buyPct <= 45) bear += vScore; else { bull += vScore / 2; bear += vScore / 2; }
        p.why.add(0, String.format(Locale.US, "Volume jaag gaya: 15 min %.1fx · 1 ghanta %.1fx normal se", p.rvol15, p.rvol1h));
        p.why.add(1, String.format(Locale.US, "Aggressive buyers %.0f%% (5m×3)", p.buyPct));
        if (dirFlow > 0) bull += dirFlow * 25; else bear += -dirFlow * 25;
        if (!Double.isNaN(p.bookImb)) {
            if (p.bookImb > 15) { bull += Math.min(12, p.bookImb / 4); p.why.add(String.format(Locale.US, "Order book: BUY side %+.0f%% bhari (2%% ke andar)", p.bookImb)); }
            else if (p.bookImb < -15) { bear += Math.min(12, -p.bookImb / 4); p.why.add(String.format(Locale.US, "Order book: SELL side %.0f%% bhari", -p.bookImb)); }
        }
        if (!Double.isNaN(p.oiCh) && Math.abs(p.oiCh) >= 3) {
            double s = Math.min(12, Math.abs(p.oiCh));
            if (p.ch1h >= 0) bull += s; else bear += s;
            p.why.add(String.format(Locale.US, "Futures positions 1 ghante mein %+.1f%%", p.oiCh));
        }
        if (!Double.isNaN(p.funding) && Math.abs(p.funding) >= 0.05) {
            if (p.funding < 0) { bull += 6; p.why.add(String.format(Locale.US, "Funding %.3f%% — shorts bhare (short squeeze ka imkaan)", p.funding)); }
            else { bear += 6; p.why.add(String.format(Locale.US, "Funding %.3f%% — longs bhare (girawat par liquidations)", p.funding)); }
        }
        if (!Double.isNaN(p.upbitRvol) && p.upbitRvol >= 2) {
            bull += Math.min(12, p.upbitRvol * 2.5);
            p.why.add(String.format(Locale.US, "🇰🇷 Upbit par volume %.1fx (Korea mein khareed)", p.upbitRvol));
        }
        if (!Double.isNaN(p.kimchi) && Math.abs(p.kimchi) >= 1.5) {
            if (p.kimchi > 0) bull += Math.min(8, p.kimchi * 2); else bear += Math.min(8, -p.kimchi * 2);
            p.why.add(String.format(Locale.US, "Kimchi premium %+.1f%%", p.kimchi));
        }
        // news / catalysts for this coin
        for (NewsEngine.Item it : NewsEngine.about(p.base, 6 * 3600_000L, 2)) {
            if (it.dir > 0) bull += 6 * it.severity; else if (it.dir < 0) bear += 6 * it.severity;
            p.why.add("📰 " + it.category + ": " + it.title);
        }
        for (CatalystEngine.Event e : CatalystEngine.forCoin(p.base, 3L * 86_400_000L)) {
            if (e.dir > 0) bull += 5 * e.severity; else if (e.dir < 0) bear += 5 * e.severity;
            p.why.add("📆 " + CatalystEngine.label(e) + ": " + e.title);
        }
        if (p.squeeze > 0 && p.squeeze < 4) { bull += 3; bear += 3; }
        p.pump = bull >= bear;
        double s = Math.max(bull, bear) - Math.min(bull, bear) * 0.4;
        if (!notRun) {
            s *= 0.6;   // already moved a lot: late
            p.why.add(String.format(Locale.US, "⚠️ Pehle hi chal chuka: 1h %+.1f%% · 24h %+.1f%% — der ho sakti hai", p.ch1h, p.ch24));
        } else p.why.add(String.format(Locale.US, "✅ Price abhi zyada nahi hili: 15m %+.1f%% · 1h %+.1f%% — jaldi pakra", p.ch15, p.ch1h));
        p.score = (int) Math.round(Math.max(0, Math.min(100, s)));
    }

    // ------------------------------------------------------------------ track record (honest hit rate)
    public static final class Track {
        /** Saves the strongest picks; later checks whether they really moved 5%+ the predicted way within 4 h. */
        static void record(Context ctx, Result r) {
            try {
                JSONArray a = new JSONArray(Prefs.getStr(ctx, "hunttrack", "[]"));
                long now = System.currentTimeMillis();
                java.util.Set<String> open = new java.util.HashSet<>();
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    if (!o.has("res")) open.add(o.optString("s"));
                }
                List<Pick> top = new ArrayList<>();
                for (Pick p : r.pumps) if (p.score >= 60 && top.size() < 5) top.add(p);
                for (Pick p : r.dumps) if (p.score >= 60 && top.size() < 8) top.add(p);
                for (Pick p : top) {
                    if (open.contains(p.sym)) continue;
                    JSONObject o = new JSONObject();
                    o.put("s", p.sym);
                    o.put("t", now);
                    o.put("p", p.price);
                    o.put("up", p.pump);
                    o.put("sc", p.score);
                    a.put(o);
                }
                JSONArray keep = new JSONArray();
                for (int i = Math.max(0, a.length() - 300); i < a.length(); i++) keep.put(a.get(i));
                Prefs.putStr(ctx, "hunttrack", keep.toString());
            } catch (Exception ignored) {
            }
        }

        /** Resolves picks older than 4 h using 15m candles: hit = moved 5%+ the right way before moving 5% the wrong way. */
        public static void resolve(Context ctx) {
            try {
                JSONArray a = new JSONArray(Prefs.getStr(ctx, "hunttrack", "[]"));
                long now = System.currentTimeMillis();
                boolean ch = false;
                int done = 0;
                for (int i = 0; i < a.length() && done < 10; i++) {
                    JSONObject o = a.getJSONObject(i);
                    if (o.has("res") || now - o.optLong("t") < 4 * 3600_000L) continue;
                    Candles c = Candles.parse(Scanner.get("/api/v3/klines?symbol=" + o.optString("s") + "&interval=15m&startTime=" + o.optLong("t") + "&limit=17"), false);
                    double p0 = o.optDouble("p"), best = 0, worst = 0;
                    boolean up = o.optBoolean("up");
                    String res = "miss";
                    for (int k = 0; k < c.n; k++) {
                        double fav = up ? (c.high[k] / p0 - 1) * 100 : (1 - c.low[k] / p0) * 100;
                        double adv = up ? (1 - c.low[k] / p0) * 100 : (c.high[k] / p0 - 1) * 100;
                        best = Math.max(best, fav);
                        worst = Math.max(worst, adv);
                        if (adv >= 5 && fav < 5) { res = "wrong"; break; }
                        if (fav >= 5) { res = "hit"; break; }
                    }
                    o.put("res", res);
                    o.put("best", best);
                    done++;
                    ch = true;
                }
                if (ch) Prefs.putStr(ctx, "hunttrack", a.toString());
            } catch (Exception ignored) {
            }
        }

        /** {resolved, hits, wrong, avg best move %} */
        public static double[] stats(Context ctx) {
            double[] s = new double[4];
            try {
                JSONArray a = new JSONArray(Prefs.getStr(ctx, "hunttrack", "[]"));
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    if (!o.has("res")) continue;
                    s[0]++;
                    if ("hit".equals(o.optString("res"))) s[1]++;
                    if ("wrong".equals(o.optString("res"))) s[2]++;
                    s[3] += o.optDouble("best", 0);
                }
                if (s[0] > 0) s[3] /= s[0];
            } catch (Exception ignored) {
            }
            return s;
        }
    }

    // ------------------------------------------------------------------ 24/7 alerts
    public static void tick(Context ctx) {
        if (!Prefs.huntOn(ctx)) return;
        if (System.currentTimeMillis() - Prefs.getLong(ctx, "hunttick") < Prefs.huntEverySec(ctx) * 1000L) return;
        Prefs.putLong(ctx, "hunttick", System.currentTimeMillis());
        Result r = scan(ctx);
        Track.resolve(ctx);
        int min = Prefs.huntMinScore(ctx), sent = 0;
        List<Pick> all = new ArrayList<>(r.pumps);
        all.addAll(r.dumps);
        Collections.sort(all, (x, y) -> y.score - x.score);
        for (Pick p : all) {
            if (p.score < min || sent >= 3) break;
            String k = "hunt_" + p.sym + (p.pump ? "U" : "D");
            if (System.currentTimeMillis() - Prefs.getLong(ctx, k) < 2 * 3600_000L) continue;
            Prefs.putLong(ctx, k, System.currentTimeMillis());
            String title = (p.pump ? "🚀 PRE-PUMP: " : "🩸 PRE-DUMP: ") + p.base + " · score " + p.score + "/100";
            StringBuilder b = new StringBuilder(String.format(Locale.US, "Price $%s · 15m %+.1f%% · 1h %+.1f%%\n", Fmt.price(p.price), p.ch15, p.ch1h));
            for (int i = 0; i < p.why.size() && i < 5; i++) b.append("• ").append(p.why.get(i)).append('\n');
            b.append(p.pump ? "Gainers list mein aane se PEHLE ka ishara — chart dekh kar, stop ke saath." : "Losers list mein jaane se PEHLE ka ishara — holding ho to ehtiyat.");
            Notify.showPage(ctx, Prefs.N_HUNT, k.hashCode(), title, b.toString(), p.pump ? 0xFF0ECB81 : 0xFFF6465D, "hunt");
            sent++;
        }
    }
}
