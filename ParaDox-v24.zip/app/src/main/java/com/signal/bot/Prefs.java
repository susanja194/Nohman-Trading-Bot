package com.signal.bot;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Settings (separate for Scalp and Spot), watchlist, alerts and saved signals. */
public final class Prefs {
    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("signalbot", Context.MODE_PRIVATE);
    }

    private static String k(int m, String key) { return "m" + m + "_" + key; }

    // defaults per mode: {SCALP, SPOT}
    private static final int[] D_INTERVAL = {1, 15}, D_TOP = {60, 150}, D_MINVOL = {10, 5},
            D_BUY = {6, 7}, D_SELL = {4, 5}, D_COOL = {30, 240};
    private static final String[] D_TF = {"5m", "4h"};
    private static final float[] D_VOLM = {1.8f, 2.0f};

    /** Scalp bot and Spot bot are switched ON/OFF separately. */
    public static boolean modeOn(Context c, int m) { return sp(c).getBoolean("on_" + m, false); }
    public static void setModeOn(Context c, int m, boolean v) { sp(c).edit().putBoolean("on_" + m, v).apply(); }
    /** True when at least one bot is ON. */
    public static boolean enabled(Context c) {
        return modeOn(c, Mode.SCALP) || modeOn(c, Mode.SPOT) || mktOn(c, Assets.COMMODITY) || mktOn(c, Assets.FOREX) || newsOn(c)
                || (focusOn(c) && focusList(c).length() > 0) || arbOn(c) || huntOn(c);
    }
    public static void setEnabled(Context c, boolean v) {
        if (!v) sp(c).edit().putBoolean("on_0", false).putBoolean("on_1", false)
                .putBoolean("on_mkt_commodity", false).putBoolean("on_mkt_forex", false).putBoolean("newson", false).apply();
    }
    /** Spot SELL only when net selling >= this many MILLION USD in 1 hour (or 2x in 4 hours). */
    public static double spotSellUsd(Context c) { return sp(c).getFloat("spotsell", 5f); }
    public static void setSpotSellUsd(Context c, float v) { sp(c).edit().putFloat("spotsell", Math.max(0.5f, v)).apply(); }
    /** Scalp heavy buying/selling floor in THOUSAND USD of net flow in 15 minutes. */
    public static double scalpHeavyUsd(Context c) { return sp(c).getFloat("scalpheavy", 250f); }
    public static void setScalpHeavyUsd(Context c, float v) { sp(c).edit().putFloat("scalpheavy", Math.max(10f, v)).apply(); }
    // ---------------- 🎯 Gainer / loser hunter
    public static boolean huntOn(Context c) { return sp(c).getBoolean("hunton", false); }
    public static void setHuntOn(Context c, boolean v) { sp(c).edit().putBoolean("hunton", v).apply(); }
    public static int huntEverySec(Context c) { return sp(c).getInt("huntevery", 120); }
    public static void setHuntEverySec(Context c, int v) { sp(c).edit().putInt("huntevery", Math.max(60, v)).apply(); }
    public static int huntMinScore(Context c) { return sp(c).getInt("huntmin", 65); }
    public static void setHuntMinScore(Context c, int v) { sp(c).edit().putInt("huntmin", Math.max(40, Math.min(95, v))).apply(); }

    // ---------------- ⚡ Mispricing radar (arbitrage / price errors)
    public static boolean arbOn(Context c) { return sp(c).getBoolean("arbon", false); }
    public static void setArbOn(Context c, boolean v) { sp(c).edit().putBoolean("arbon", v).apply(); }
    public static int arbEverySec(Context c) { return sp(c).getInt("arbevery", 60); }
    public static void setArbEverySec(Context c, int v) { sp(c).edit().putInt("arbevery", Math.max(15, v)).apply(); }
    public static double arbFee(Context c) { return sp(c).getFloat("arbfee", 0.1f); }
    public static void setArbFee(Context c, float v) { sp(c).edit().putFloat("arbfee", Math.max(0f, v)).apply(); }
    public static double arbMinNet(Context c) { return sp(c).getFloat("arbmin", 0.5f); }
    public static void setArbMinNet(Context c, float v) { sp(c).edit().putFloat("arbmin", Math.max(0.05f, v)).apply(); }
    /** Radar display filter: only show gaps of at least this % (0 = all). */
    public static double arbShowMin(Context c) { return sp(c).getFloat("arbshow", 0f); }
    public static void setArbShowMin(Context c, float v) { sp(c).edit().putFloat("arbshow", Math.max(0f, v)).apply(); }
    public static double arbMinVol(Context c) { return sp(c).getFloat("arbvol", 500_000f); }
    public static void setArbMinVol(Context c, float v) { sp(c).edit().putFloat("arbvol", Math.max(0f, v)).apply(); }

    // ---------------- 🎯 Focus mode: signals ONLY for the user's chosen coins / gold / forex
    public static boolean focusOn(Context c) { return sp(c).getBoolean("focuson", false); }
    public static void setFocusOn(Context c, boolean v) { sp(c).edit().putBoolean("focuson", v).apply(); }

    /** [{s: "BTCUSDT" | "GC=F", k: crypto|commodity|forex, m: "scalp"|"spot"|"both"}] */
    public static JSONArray focusList(Context c) {
        try {
            return new JSONArray(sp(c).getString("focus", "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    public static synchronized void saveFocus(Context c, JSONArray a) { sp(c).edit().putString("focus", a.toString()).apply(); }

    public static boolean inFocus(Context c, String sym) {
        JSONArray a = focusList(c);
        for (int i = 0; i < a.length(); i++) if (sym.equals(a.optJSONObject(i) != null ? a.optJSONObject(i).optString("s") : "")) return true;
        return false;
    }

    public static synchronized void addFocus(Context c, String sym, String kind, String mode) {
        if (inFocus(c, sym)) return;
        JSONArray a = focusList(c);
        try {
            JSONObject o = new JSONObject();
            o.put("s", sym);
            o.put("k", kind);
            o.put("m", mode);
            a.put(o);
        } catch (Exception ignored) {
        }
        saveFocus(c, a);
    }

    public static synchronized void removeFocus(Context c, String sym) {
        JSONArray a = focusList(c), b = new JSONArray();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && !sym.equals(o.optString("s"))) b.put(o);
        }
        saveFocus(c, b);
    }

    public static synchronized void setFocusMode(Context c, String sym, String mode) {
        JSONArray a = focusList(c);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && sym.equals(o.optString("s"))) {
                try { o.put("m", mode); } catch (Exception ignored) { }
            }
        }
        saveFocus(c, a);
    }

    /** Focus crypto symbols scanned by a crypto mode (0 scalp / 1 spot). */
    public static List<String> focusCrypto(Context c, int mode) {
        List<String> out = new ArrayList<>();
        JSONArray a = focusList(c);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null || !Assets.CRYPTO.equals(o.optString("k"))) continue;
            String m = o.optString("m", "both");
            if (m.equals("both") || (mode == Mode.SCALP ? m.equals("scalp") : m.equals("spot"))) out.add(o.optString("s"));
        }
        return out;
    }

    public static List<String> focusAssets(Context c, String mkt) {
        List<String> out = new ArrayList<>();
        JSONArray a = focusList(c);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && mkt.equals(o.optString("k"))) out.add(o.optString("s"));
        }
        return out;
    }

    /** Live news radar (background) + its notifications. */
    public static boolean newsOn(Context c) { return sp(c).getBoolean("newson", false); }
    public static void setNewsOn(Context c, boolean v) { sp(c).edit().putBoolean("newson", v).apply(); }
    /** 1 = all news, 2 = important + critical, 3 = only critical. */
    public static int newsMinSev(Context c) { return sp(c).getInt("newssev", 2); }
    public static void setNewsMinSev(Context c, int v) { sp(c).edit().putInt("newssev", Math.max(1, Math.min(3, v))).apply(); }
    /** Gold/commodities and forex bots (separate from the crypto scalp/spot bots). */
    public static boolean mktOn(Context c, String mkt) { return sp(c).getBoolean("on_mkt_" + mkt, false); }
    public static void setMktOn(Context c, String mkt, boolean v) { sp(c).edit().putBoolean("on_mkt_" + mkt, v).apply(); }
    /** Accuracy mode: only signals whose rule has a good backtest + timeframe & MA agreement. */
    public static boolean accuracyMode(Context c) { return sp(c).getBoolean("accmode", true); }
    public static void setAccuracyMode(Context c, boolean v) { sp(c).edit().putBoolean("accmode", v).apply(); }
    public static int minWinRate(Context c) { return sp(c).getInt("minwr", 55); }
    public static void setMinWinRate(Context c, int v) { sp(c).edit().putInt("minwr", Math.max(40, Math.min(90, v))).apply(); }
    public static long lastAssetScan(Context c, String mkt) { return sp(c).getLong("ascan_" + mkt, 0); }
    public static void setLastAssetScan(Context c, String mkt, long t) { sp(c).edit().putLong("ascan_" + mkt, t).apply(); }

    // ---------------- notifications (real-app style toggles + quiet hours)
    public static final String N_SIGNALS = "signals", N_ALERTS = "alerts", N_WALLET = "wallet", N_BIG = "big", N_UPDATE = "update",
            N_MACRO = "macro", N_NEWS = "news", N_CATALYST = "catalyst", N_ARB = "arb", N_HUNT = "hunt";

    // generic small storage
    public static String getStr(Context c, String k, String def) { return sp(c).getString(k, def); }
    public static void putStr(Context c, String k, String v) { sp(c).edit().putString(k, v).apply(); }
    public static long getLong(Context c, String k) { return sp(c).getLong(k, 0); }
    public static void putLong(Context c, String k, long v) { sp(c).edit().putLong(k, v).apply(); }

    // ---------------- macro / economic news
    /** Minutes before a high-impact event to send the reminder. */
    public static int macroLeadMin(Context c) { return sp(c).getInt("macrolead", 60); }
    public static void setMacroLeadMin(Context c, int v) { sp(c).edit().putInt("macrolead", Math.max(5, Math.min(720, v))).apply(); }
    /** Also notify medium-impact events (claims, ISM, sentiment...). */
    public static boolean macroMedium(Context c) { return sp(c).getBoolean("macromed", false); }
    public static void setMacroMedium(Context c, boolean v) { sp(c).edit().putBoolean("macromed", v).apply(); }
    /** Pause new BUY/SELL signals around high-impact US news. */
    public static boolean newsPause(Context c) { return sp(c).getBoolean("newspause", true); }
    public static void setNewsPause(Context c, boolean v) { sp(c).edit().putBoolean("newspause", v).apply(); }
    public static long lastMacroCheck(Context c) { return sp(c).getLong("macrocheck", 0); }
    public static void setLastMacroCheck(Context c, long t) { sp(c).edit().putLong("macrocheck", t).apply(); }

    public static boolean notifOn(Context c, String type) { return sp(c).getBoolean("notif_" + type, true); }
    public static void setNotif(Context c, String type, boolean on) { sp(c).edit().putBoolean("notif_" + type, on).apply(); }
    public static boolean quietOn(Context c) { return sp(c).getBoolean("quiet", false); }
    public static int quietFrom(Context c) { return sp(c).getInt("quietfrom", 0); }
    public static int quietTo(Context c) { return sp(c).getInt("quietto", 7); }
    public static void saveQuiet(Context c, boolean on, int from, int to) {
        sp(c).edit().putBoolean("quiet", on).putInt("quietfrom", Math.max(0, Math.min(23, from))).putInt("quietto", Math.max(0, Math.min(23, to))).apply();
    }
    /** Minimum USD size for "big player bought/sold" notifications. */
    public static long bigMinUsd(Context c) { return sp(c).getLong("bigmin", 50_000_000L); }
    public static void setBigMinUsd(Context c, long v) { sp(c).edit().putLong("bigmin", Math.max(1_000_000L, v)).apply(); }
    /** Minimum confidence % for a signal notification (0 = all). */
    public static int minConfidence(Context c) { return sp(c).getInt("minconf", 0); }
    public static void setMinConfidence(Context c, int v) { sp(c).edit().putInt("minconf", Math.max(0, Math.min(90, v))).apply(); }
    public static boolean vibrate(Context c) { return sp(c).getBoolean("vibrate", true); }
    public static void setVibrate(Context c, boolean v) { sp(c).edit().putBoolean("vibrate", v).apply(); }

    // ---------------- my wallets (watch-only)
    public static synchronized JSONArray wallets(Context c) {
        try { return new JSONArray(sp(c).getString("wallets", "[]")); } catch (Exception e) { return new JSONArray(); }
    }
    public static synchronized void saveWallets(Context c, JSONArray a) { sp(c).edit().putString("wallets", a.toString()).apply(); }

    // ---------------- big players
    public static synchronized JSONObject bigSnap(Context c) {
        try { return new JSONObject(sp(c).getString("bigsnap", "{}")); } catch (Exception e) { return new JSONObject(); }
    }
    public static synchronized void saveBigSnap(Context c, JSONObject o) { sp(c).edit().putString("bigsnap", o.toString()).apply(); }
    public static synchronized JSONArray bigMoves(Context c) {
        try { return new JSONArray(sp(c).getString("bigmoves", "[]")); } catch (Exception e) { return new JSONArray(); }
    }
    public static synchronized void addBigMove(Context c, String text, boolean buy) {
        try {
            JSONArray old = bigMoves(c), arr = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("t", System.currentTimeMillis());
            o.put("text", text);
            o.put("buy", buy);
            arr.put(o);
            for (int i = 0; i < old.length() && i < 79; i++) arr.put(old.get(i));
            sp(c).edit().putString("bigmoves", arr.toString()).apply();
        } catch (Exception ignored) {
        }
    }
    public static synchronized JSONArray bigWallets(Context c) {
        try { return new JSONArray(sp(c).getString("bigwallets", "[]")); } catch (Exception e) { return new JSONArray(); }
    }
    public static synchronized void saveBigWallets(Context c, JSONArray a) { sp(c).edit().putString("bigwallets", a.toString()).apply(); }
    public static long lastBigCheck(Context c) { return sp(c).getLong("bigcheck", 0); }
    public static void setLastBigCheck(Context c, long t) { sp(c).edit().putLong("bigcheck", t).apply(); }
    public static long lastWalletCheck(Context c) { return sp(c).getLong("walletcheck", 0); }
    public static void setLastWalletCheck(Context c, long t) { sp(c).edit().putLong("walletcheck", t).apply(); }

    /** Restore every setting to default (keeps wallets, keys, signals). */
    public static void resetSettings(Context c) {
        SharedPreferences.Editor e = sp(c).edit();
        for (String k : sp(c).getAll().keySet()) {
            if (k.startsWith("m0_") || k.startsWith("m1_") || k.startsWith("notif_") || k.startsWith("layer_")
                    || k.equals("btcfilter") || k.equals("smart") || k.equals("strong") || k.equals("whaleusd")
                    || k.equals("quiet") || k.equals("quietfrom") || k.equals("quietto") || k.equals("bigmin")
                    || k.equals("minconf") || k.equals("vibrate")) e.remove(k);
        }
        e.apply();
    }

    // ---------------- in-app updates
    public static String updateRepo(Context c) { return sp(c).getString("repo", "susanja194/Nohman-Trading-Bot"); }
    public static void setUpdateRepo(Context c, String r) { sp(c).edit().putString("repo", r == null ? "" : r.trim()).apply(); }
    public static long lastUpdateCheck(Context c) { return sp(c).getLong("updcheck", 0); }
    public static void setLastUpdateCheck(Context c, long t) { sp(c).edit().putLong("updcheck", t).apply(); }
    public static long notifiedUpdate(Context c) { return sp(c).getLong("updnotified", 0); }
    public static void setNotifiedUpdate(Context c, long t) { sp(c).edit().putLong("updnotified", t).apply(); }

    // ---------------- Claude AI
    public static String claudeKey(Context c) { return sp(c).getString("claudekey", ""); }
    public static String claudeModel(Context c) { return sp(c).getString("claudemodel", "claude-sonnet-5-5"); }
    public static void saveClaude(Context c, String key, String model) {
        sp(c).edit().putString("claudekey", key == null ? "" : key.trim()).putString("claudemodel", model).apply();
    }

    /** Which mode the app screens show. */
    public static int uiMode(Context c) { return sp(c).getInt("uimode", Mode.SCALP); }
    public static void setUiMode(Context c, int m) { sp(c).edit().putInt("uimode", m).apply(); }

    public static int intervalMin(Context c, int m) { return sp(c).getInt(k(m, "interval"), D_INTERVAL[m]); }
    public static String timeframe(Context c, int m) { return sp(c).getString(k(m, "tf"), D_TF[m]); }
    public static int topCoins(Context c, int m) { return sp(c).getInt(k(m, "top"), D_TOP[m]); }
    public static int minVolMillion(Context c, int m) { return sp(c).getInt(k(m, "minvol"), D_MINVOL[m]); }
    public static int buyThreshold(Context c, int m) { return sp(c).getInt(k(m, "buyth"), D_BUY[m]); }
    public static int sellThreshold(Context c, int m) { return sp(c).getInt(k(m, "sellth"), D_SELL[m]); }
    public static float volMult(Context c, int m) { return sp(c).getFloat(k(m, "volmult"), D_VOLM[m]); }
    public static int cooldownMin(Context c, int m) { return sp(c).getInt(k(m, "cooldown"), D_COOL[m]); }

    public static void saveMode(Context c, int m, int interval, String tf, int top, int minVol,
                                int buyTh, int sellTh, float volMult, int cooldown) {
        sp(c).edit()
                .putInt(k(m, "interval"), Math.max(1, interval))
                .putString(k(m, "tf"), tf)
                .putInt(k(m, "top"), Math.max(5, Math.min(400, top)))
                .putInt(k(m, "minvol"), Math.max(0, minVol))
                .putInt(k(m, "buyth"), Math.max(1, buyTh))
                .putInt(k(m, "sellth"), Math.max(1, sellTh))
                .putFloat(k(m, "volmult"), Math.max(1.1f, volMult))
                .putInt(k(m, "cooldown"), Math.max(0, cooldown))
                .apply();
    }

    public static boolean btcFilter(Context c) { return sp(c).getBoolean("btcfilter", true); }
    public static boolean smartMoney(Context c) { return sp(c).getBoolean("smart", true); }
    public static boolean strongConfirm(Context c) { return sp(c).getBoolean("strong", true); }
    public static int whaleUsd(Context c) { return sp(c).getInt("whaleusd", 50000); }
    public static String glassKey(Context c) { return sp(c).getString("glass", ""); }

    public static void saveCommon(Context c, boolean btc, boolean smart, boolean strong, int whaleUsd, String glass) {
        sp(c).edit().putBoolean("btcfilter", btc).putBoolean("smart", smart).putBoolean("strong", strong)
                .putInt("whaleusd", Math.max(1000, whaleUsd)).putString("glass", glass == null ? "" : glass.trim()).apply();
    }

    public static String lastCoin(Context c) { return sp(c).getString("lastcoin", "BTCUSDT"); }
    public static void setLastCoin(Context c, String s) { sp(c).edit().putString("lastcoin", s).apply(); }

    // ---------------- chart layers + risk calculator
    public static boolean layer(Context c, String name) { return sp(c).getBoolean("layer_" + name, true); }
    public static boolean layer(Context c, String name, boolean def) { return sp(c).getBoolean("layer_" + name, def); }
    public static int chartType(Context c) { return sp(c).getInt("charttype", 0); }
    public static void setChartType(Context c, int t) { sp(c).edit().putInt("charttype", t).apply(); }
    public static void setLayer(Context c, String name, boolean on) { sp(c).edit().putBoolean("layer_" + name, on).apply(); }
    public static float balance(Context c) { return sp(c).getFloat("balance", 100f); }
    public static float riskPct(Context c) { return sp(c).getFloat("riskpct", 1f); }
    public static void saveRisk(Context c, float bal, float pct) {
        sp(c).edit().putFloat("balance", Math.max(0, bal)).putFloat("riskpct", Math.max(0.1f, Math.min(20, pct))).apply();
    }

    // ---------------- watchlist
    public static List<String> watchlist(Context c) {
        List<String> out = new ArrayList<>();
        for (String s : sp(c).getString("watch", "BTCUSDT,ETHUSDT,SOLUSDT").split(",")) {
            s = s.trim();
            if (!s.isEmpty() && !out.contains(s)) out.add(s);
        }
        return out;
    }

    public static boolean inWatchlist(Context c, String sym) { return watchlist(c).contains(sym); }

    public static boolean toggleWatch(Context c, String sym) {
        List<String> l = watchlist(c);
        boolean now;
        if (l.contains(sym)) { l.remove(sym); now = false; } else { l.add(0, sym); now = true; }
        StringBuilder sb = new StringBuilder();
        for (String s : l) { if (sb.length() > 0) sb.append(','); sb.append(s); }
        sp(c).edit().putString("watch", sb.toString()).apply();
        return now;
    }

    // ---------------- price alerts
    public static synchronized JSONArray alerts(Context c) {
        try { return new JSONArray(sp(c).getString("alerts", "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    public static synchronized void addAlert(Context c, String sym, double price, boolean above) {
        try {
            JSONArray a = alerts(c);
            JSONObject o = new JSONObject();
            o.put("sym", sym);
            o.put("price", price);
            o.put("above", above);
            a.put(o);
            sp(c).edit().putString("alerts", a.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    /** Removes the alerts at the given indexes. */
    public static synchronized void removeAlerts(Context c, List<Integer> idx) {
        JSONArray a = alerts(c), out = new JSONArray();
        for (int i = 0; i < a.length(); i++) {
            if (idx.contains(i)) continue;
            try { out.put(a.get(i)); } catch (Exception ignored) { }
        }
        sp(c).edit().putString("alerts", out.toString()).apply();
    }

    // ---------------- status + cooldown
    public static String status(Context c) { return sp(c).getString("status", "Bot abhi band hai"); }
    public static void setStatus(Context c, String s) { sp(c).edit().putString("status", s).apply(); }

    public static boolean cooldownOk(Context c, int m, String symbol, String side) {
        long last = sp(c).getLong("cd" + m + "_" + symbol + "_" + side, 0);
        return System.currentTimeMillis() - last >= cooldownMin(c, m) * 60_000L;
    }

    public static void markCooldown(Context c, int m, String symbol, String side) {
        sp(c).edit().putLong("cd" + m + "_" + symbol + "_" + side, System.currentTimeMillis()).apply();
    }

    // ---------------- signals
    public static synchronized void addSignal(Context c, int mode, String side, String symbol, double price,
                                              int score, String reasons, double sl, double tp, JSONObject extra) {
        try {
            JSONArray old = new JSONArray(sp(c).getString("signals", "[]"));
            JSONArray arr = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("t", System.currentTimeMillis());
            o.put("mode", mode);
            o.put("side", side);
            o.put("sym", symbol);
            o.put("price", price);
            o.put("score", score);
            o.put("why", reasons);
            o.put("sl", sl);
            o.put("tp", tp);
            o.put("st", "open");
            if (extra != null) {
                java.util.Iterator<String> it = extra.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    o.put(k, extra.get(k));
                }
            }
            arr.put(o);
            for (int i = 0; i < old.length() && i < 199; i++) arr.put(old.get(i));
            sp(c).edit().putString("signals", arr.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    public static JSONArray signals(Context c) {
        try {
            return new JSONArray(sp(c).getString("signals", "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    public static synchronized void saveSignals(Context c, JSONArray arr) {
        sp(c).edit().putString("signals", arr.toString()).apply();
    }

    public static void clearSignals(Context c) { sp(c).edit().putString("signals", "[]").apply(); }
}
