package com.signal.bot;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

import java.util.Locale;

/** Live order book (top 20 bids / asks) with depth bars and highlighted whale walls. */
public class BookView extends View {
    private double[][] bids = new double[0][], asks = new double[0][];
    private final float d;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), text = new Paint(Paint.ANTI_ALIAS_FLAG),
            stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final int ROWS = 10;

    public BookView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        text.setTextSize(10.5f * d);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(1.5f * d);
        stroke.setColor(0xFFF0B90B);
    }

    /** {bid USD, ask USD} in the top rows. */
    public double[] sums() {
        double b = 0, a = 0;
        for (int i = 0; i < bids.length && i < ROWS; i++) b += bids[i][0] * bids[i][1];
        for (int i = 0; i < asks.length && i < ROWS; i++) a += asks[i][0] * asks[i][1];
        return new double[]{b, a};
    }

    public void set(double[][] b, double[][] a) {
        bids = b;
        asks = a;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas cv) {
        super.onDraw(cv);
        float w = getWidth(), h = getHeight();
        if (bids.length == 0 || asks.length == 0) {
            text.setColor(0xFF8B95A7);
            cv.drawText("Order book live load ho raha hai...", 8 * d, h / 2, text);
            return;
        }
        double bidSum = 0, askSum = 0, mx = 0, avg = 0;
        int cnt = 0;
        for (int i = 0; i < bids.length && i < ROWS; i++) { double u = bids[i][0] * bids[i][1]; bidSum += u; mx = Math.max(mx, u); avg += u; cnt++; }
        for (int i = 0; i < asks.length && i < ROWS; i++) { double u = asks[i][0] * asks[i][1]; askSum += u; mx = Math.max(mx, u); avg += u; cnt++; }
        avg = cnt > 0 ? avg / cnt : 0;

        float headH = 34 * d;
        double bp = bidSum + askSum > 0 ? bidSum / (bidSum + askSum) : 0.5;
        text.setFakeBoldText(true);
        text.setColor(0xFFE8EAED);
        cv.drawText(String.format(Locale.US, "Order book (top %d)   Buy %s  vs  Sell %s", ROWS, Fmt.usd(bidSum), Fmt.usd(askSum)), 4 * d, 12 * d, text);
        text.setFakeBoldText(false);
        fill.setColor(0xFF0ECB81);
        cv.drawRoundRect(new RectF(0, 18 * d, (float) (w * bp), 26 * d), 4 * d, 4 * d, fill);
        fill.setColor(0xFFF6465D);
        cv.drawRoundRect(new RectF((float) (w * bp), 18 * d, w, 26 * d), 4 * d, 4 * d, fill);

        float half = w / 2 - 3 * d;
        float rowH = (h - headH) / ROWS;
        text.setTextSize(10 * d);
        for (int i = 0; i < ROWS; i++) {
            float y = headH + i * rowH;
            if (i < bids.length) drawRow(cv, bids[i], 0, y, half, rowH, mx, avg, true);
            if (i < asks.length) drawRow(cv, asks[i], w - half, y, half, rowH, mx, avg, false);
        }
        text.setTextSize(10.5f * d);
    }

    private void drawRow(Canvas cv, double[] r, float x, float y, float wd, float rh, double mx, double avg, boolean bid) {
        double usd = r[0] * r[1];
        float bw = (float) (usd / mx * wd);
        fill.setColor(bid ? 0x400ECB81 : 0x40F6465D);
        if (bid) cv.drawRect(x + wd - bw, y + 1, x + wd, y + rh - 1, fill);
        else cv.drawRect(x, y + 1, x + bw, y + rh - 1, fill);
        boolean wall = avg > 0 && usd >= 3 * avg;
        if (wall) cv.drawRect(x + 1, y + 1.5f, x + wd - 1, y + rh - 1.5f, stroke);
        text.setColor(bid ? 0xFF0ECB81 : 0xFFF6465D);
        String p = Fmt.price(r[0]);
        String u = (wall ? "🐋" : "") + Fmt.usd(usd);
        float ty = y + rh / 2 + 3.5f * d;
        if (bid) {
            text.setColor(0xFFC9D1DC);
            cv.drawText(u, x + 3 * d, ty, text);
            text.setColor(0xFF0ECB81);
            cv.drawText(p, x + wd - text.measureText(p) - 3 * d, ty, text);
        } else {
            text.setColor(0xFFF6465D);
            cv.drawText(p, x + 3 * d, ty, text);
            text.setColor(0xFFC9D1DC);
            cv.drawText(u, x + wd - text.measureText(u) - 3 * d, ty, text);
        }
    }
}
