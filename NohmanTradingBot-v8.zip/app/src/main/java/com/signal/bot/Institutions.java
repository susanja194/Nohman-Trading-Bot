package com.signal.bot;

import org.json.JSONArray;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * What the big players are doing (all free, no key):
 *  - BlackRock (Larry Fink), Fidelity, Grayscale ... : per-fund spot ETF flows (Farside)
 *  - Public companies (Strategy/Saylor, Trump Media, Tesla ...): crypto treasuries (CoinGecko)
 *  - Trump family's World Liberty Financial: on-chain wallet holdings + latest transfers (Ethplorer)
 */
public final class Institutions {
    private Institutions() {}

    /** World Liberty Financial wallet as reported by The Block (Etherscan-labelled). */
    public static final String WLFI_WALLET = "0x5be9a4959308A0D0c7bC0870E319314d8D957dBB";

    public static final class Result {
        public final List<String> lines = new ArrayList<>();
        public int score;
        public boolean available;
        public final List<String[]> links = new ArrayList<>();   // {label, url}
    }

    static String coinGeckoId(String base) {
        switch (base) {
            case "BTC": return "bitcoin";
            case "ETH": return "ethereum";
            case "SOL": return "solana";
            case "BNB": return "binancecoin";
            default: return null;
        }
    }

    /** Token symbols on Ethereum that represent the coin (for WLFI wallet checks). */
    static String[] wrapped(String base) {
        switch (base) {
            case "BTC": return new String[]{"WBTC", "CBBTC", "TBTC"};
            case "ETH": return new String[]{"ETH", "WETH", "STETH", "WSTETH"};
            default: return new String[]{base};
        }
    }

    public static Result fetch(String base) {
        Result r = new Result();
        double sc = 0, w = 0;

        // ---- 1. ETF issuers (BlackRock etc.)
        EtfFlows.Result etf = EtfFlows.fetch(base);
        if (etf != null && !etf.funds.isEmpty()) {
            String head = etf.marketWide ? "BTC ETFs (poori market)" : etf.asset + " ETFs";
            r.lines.add("🏦 " + head + " — " + (etf.dates.isEmpty() ? "" : etf.dates.get(etf.dates.size() - 1)) + " aur 5 din:");
            List<double[]> ranked = new ArrayList<>();
            for (int i = 0; i < etf.funds.size(); i++) {
                double[] f = EtfFlows.fundFlow(etf, etf.funds.get(i));
                if (f != null && (f[0] != 0 || f[1] != 0)) ranked.add(new double[]{i, f[0], f[1]});
            }
            ranked.sort((a, b) -> Double.compare(Math.abs(b[2]), Math.abs(a[2])));
            for (int j = 0; j < ranked.size() && j < 5; j++) {
                double[] f = ranked.get(j);
                String t = etf.funds.get((int) f[0]);
                r.lines.add(String.format(Locale.US, "   %s %s (%s): kal %s · 5 din %s", f[2] >= 0 ? "🟢" : "🔴",
                        EtfFlows.issuer(t), t, m(f[1]), m(f[2])));
            }
            double[] blk = null;
            for (String t : new String[]{"IBIT", "ETHA"}) {
                double[] f = EtfFlows.fundFlow(etf, t);
                if (f != null) { blk = f; break; }
            }
            if (blk != null) {
                r.lines.add(blk[1] >= 0 ? "BlackRock (Larry Fink) pichhle 5 din se KHAREED raha hai ✅" : "BlackRock (Larry Fink) pichhle 5 din se BECH raha hai ⚠️");
                double scale = Math.max(1, etf.avgAbs);
                sc += Fmt.clamp(blk[1] / (2.5 * scale), -1, 1) * (etf.marketWide ? 0.25 : 0.5);
                w += etf.marketWide ? 0.25 : 0.5;
            }
            r.links.add(new String[]{"Farside ETF table", "https://farside.co.uk/" + (EtfFlows.pageFor(base) == null ? "btc" : EtfFlows.pageFor(base)) + "/"});
        }

        // ---- 2. Public company treasuries (Strategy, Trump Media ...)
        String cg = coinGeckoId(base);
        if (cg != null) {
            try {
                JSONObject o = new JSONObject(Scanner.getAbsolute("https://api.coingecko.com/api/v3/companies/public_treasury/" + cg));
                JSONArray cs = o.getJSONArray("companies");
                r.lines.add(String.format(Locale.US, "🏢 Public companies ke paas: %s %s (%s · supply ka %.2f%%)",
                        Fmt.num(o.optDouble("total_holdings", 0)), base, Fmt.usd(o.optDouble("total_value_usd", 0)),
                        o.optDouble("market_cap_dominance", 0)));
                int shown = 0;
                for (int i = 0; i < cs.length() && shown < 5; i++) {
                    JSONObject c = cs.getJSONObject(i);
                    r.lines.add(String.format(Locale.US, "   %s (%s): %s %s", c.optString("name"), c.optString("country"),
                            Fmt.num(c.optDouble("total_holdings", 0)), base));
                    shown++;
                }
                for (int i = 0; i < cs.length(); i++) {
                    String n = cs.getJSONObject(i).optString("name");
                    if (n.toLowerCase(Locale.US).contains("trump")) {
                        r.lines.add("   🇺🇸 " + n + ": " + Fmt.num(cs.getJSONObject(i).optDouble("total_holdings", 0)) + " " + base);
                        break;
                    }
                }
                r.available = true;
            } catch (Exception e) {
                r.lines.add("🏢 Company holdings abhi nahi mili (CoinGecko busy)");
            }
        }

        // ---- 3. Trump family — World Liberty Financial wallet
        try {
            JSONObject h = new JSONObject(Scanner.getAbsolute("https://api.ethplorer.io/getAddressHistory/" + WLFI_WALLET
                    + "?apiKey=freekey&type=transfer&limit=50"));
            JSONArray ops = h.getJSONArray("operations");
            String[] mine = wrapped(base);
            double inUsd = 0, outUsd = 0;
            int cnt = 0;
            List<String> recent = new ArrayList<>();
            for (int i = 0; i < ops.length(); i++) {
                JSONObject op = ops.getJSONObject(i);
                JSONObject ti = op.optJSONObject("tokenInfo");
                if (ti == null) continue;
                String sym = ti.optString("symbol").toUpperCase(Locale.US);
                double amt = units(op.optString("value"), ti.optInt("decimals", 18));
                JSONObject pr = ti.optJSONObject("price");
                double usd = pr != null ? amt * pr.optDouble("rate", 0) : 0;
                boolean in = WLFI_WALLET.equalsIgnoreCase(op.optString("to"));
                if (recent.size() < 4 && usd >= 10000) {
                    String when = new java.text.SimpleDateFormat("dd MMM", Locale.US).format(new java.util.Date(op.optLong("timestamp") * 1000));
                    recent.add(String.format(Locale.US, "   %s %s %s %s (%s)", when, in ? "🟢 aaya" : "🔴 gaya", Fmt.num(amt), sym, Fmt.usd(usd)));
                }
                for (String m : mine) {
                    if (m.equals(sym)) {
                        if (in) inUsd += usd; else outUsd += usd;
                        cnt++;
                    }
                }
            }
            r.lines.add("🇺🇸 Trump family — World Liberty Financial wallet (taaza transfers):");
            if (recent.isEmpty()) r.lines.add("   Haal mein koi bada transfer nahi");
            else r.lines.addAll(recent);
            if (cnt > 0) {
                r.lines.add(String.format(Locale.US, "   %s mein: aaya %s · gaya %s %s", base, Fmt.usd(inUsd), Fmt.usd(outUsd),
                        inUsd > outUsd ? "→ WLFI khareed/jama kar raha ✅" : "→ WLFI nikal raha ⚠️"));
                double t = inUsd + outUsd;
                if (t > 0) {
                    sc += (inUsd - outUsd) / t * 0.25;
                    w += 0.25;
                }
            }
            r.available = true;
            r.links.add(new String[]{"WLFI wallet (Etherscan)", "https://etherscan.io/address/" + WLFI_WALLET});
            r.links.add(new String[]{"WLFI wallet (Arkham)", "https://intel.arkm.com/explorer/address/" + WLFI_WALLET});
        } catch (Exception e) {
            r.lines.add("🇺🇸 WLFI wallet data abhi nahi mila (Ethplorer busy)");
        }

        if (!r.lines.isEmpty() && etf != null) r.available = true;
        r.score = w > 0 ? (int) Math.round(Fmt.clamp(sc / w, -1, 1) * 100) : 0;
        if (w == 0) r.score = Integer.MIN_VALUE;   // informative only, not scored
        return r;
    }

    private static String m(double v) {
        return String.format(Locale.US, "%s$%.1fM", v >= 0 ? "+" : "−", Math.abs(v));
    }

    static double units(String raw, int decimals) {
        try {
            return new BigDecimal(raw).movePointLeft(decimals).doubleValue();
        } catch (Exception e) {
            return 0;
        }
    }
}
