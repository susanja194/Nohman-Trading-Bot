package com.signal.bot;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;

/**
 * Live trade tape: buying vs selling pressure (last 60 s and 5 min) and the latest
 * whale / dolphin / retail orders in different colours.
 */
public class TapeView extends View {
    public static final class Trade {
        final long t;
        final double price, usd;
        final boolean sell;

        Trade(long t, double price, double usd, boolean sell) { this.t = t; this.price = price; this.usd = usd; this.sell = sell; }
    }

    private final ArrayDeque<Trade> shown = new ArrayDeque<>();
    // per-second buckets for the last 5 minutes: buy, sell, whale buy, whale sell
    private final long[] bSec = new long[300];
    private final double[][] bucket = new double[300][4];
    private double whaleThr = 50000;
    private final float d;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final SimpleDateFormat fmt = new SimpleDateFormat("HH:mm:ss", Locale.US);
    private static final int ROWS = 9;

    public TapeView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        text.setTextSize(10.5f * d);
    }

    public void setWhaleThreshold(double t) { whaleThr = Math.max(1000, t); }

    public void clear() {
        shown.clear();
        java.util.Arrays.fill(bSec, 0);
        invalidate();
    }

    /** Called on the UI thread with a batch of trades. */
    public void add(Trade tr) {
        long sec = tr.t / 1000;
        int k = (int) (sec % 300);
        if (bSec[k] != sec) {
            bSec[k] = sec;
            bucket[k][0] = bucket[k][1] = bucket[k][2] = bucket[k][3] = 0;
        }
        bucket[k][tr.sell ? 1 : 0] += tr.usd;
        if (tr.usd >= whaleThr) bucket[k][tr.sell ? 3 : 2] += tr.usd;
        if (tr.usd >= whaleThr / 20) {
            shown.addFirst(tr);
            while (shown.size() > ROWS) shown.removeLast();
        }
    }

    public static Trade trade(long t, double price, double usd, boolean sell) { return new Trade(t, price, usd, sell); }

    /** {buy60, sell60, buy5m, sell5m, whaleBuy5m, whaleSell5m} */
    public double[] pressure() {
        long now = System.currentTimeMillis() / 1000;
        double[] r = new double[6];
        for (int k = 0; k < 300; k++) {
            long age = now - bSec[k];
            if (bSec[k] == 0 || age < 0 || age >= 300) continue;
            r[2] += bucket[k][0];
            r[3] += bucket[k][1];
            r[4] += bucket[k][2];
            r[5] += bucket[k][3];
            if (age < 60) { r[0] += bucket[k][0]; r[1] += bucket[k][1]; }
        }
        return r;
    }

    @Override
    protected void onDraw(Canvas cv) {
        super.onDraw(cv);
        float w = getWidth(), h = getHeight();
        double[] p = pressure();
        text.setFakeBoldText(true);
        double b1 = p[0], s1 = p[1];
        double share = b1 + s1 > 0 ? b1 / (b1 + s1) : 0.5;
        String mood = share >= 0.58 ? "💰 Paisa AA raha (buyers aggressive)" : share <= 0.42 ? "🚨 Paisa NIKAL raha (sellers aggressive)" : "⚖️ Barabar";
        text.setColor(share >= 0.58 ? 0xFF0ECB81 : share <= 0.42 ? 0xFFF6465D : 0xFFFFC94D);
        cv.drawText("Live 60 sec: " + mood, 4 * d, 12 * d, text);
        text.setFakeBoldText(false);
        fill.setColor(0xFF0ECB81);
        cv.drawRoundRect(new RectF(0, 17 * d, (float) (w * share), 25 * d), 4 * d, 4 * d, fill);
        fill.setColor(0xFFF6465D);
        cv.drawRoundRect(new RectF((float) (w * share), 17 * d, w, 25 * d), 4 * d, 4 * d, fill);
        text.setColor(0xFF8B95A7);
        text.setTextSize(9.5f * d);
        cv.drawText(String.format(Locale.US, "60s: buy %s · sell %s   |   5 min 🐋 whale buy %s · whale sell %s",
                Fmt.usd(b1), Fmt.usd(s1), Fmt.usd(p[4]), Fmt.usd(p[5])), 4 * d, 37 * d, text);

        float top = 44 * d;
        float rowH = (h - top) / ROWS;
        text.setTextSize(10.5f * d);
        if (shown.isEmpty()) {
            cv.drawText("Live orders ka intezar...", 4 * d, top + 14 * d, text);
            return;
        }
        int i = 0;
        for (Trade t : shown) {
            float y = top + i * rowH;
            String kind;
            int bg;
            if (t.usd >= whaleThr) { kind = "🐋 WHALE"; bg = t.sell ? 0x55F6465D : 0x550ECB81; }
            else if (t.usd >= whaleThr / 5) { kind = "🐬 bada"; bg = t.sell ? 0x30F6465D : 0x300ECB81; }
            else { kind = "🐟 retail"; bg = 0x00000000; }
            fill.setColor(bg);
            cv.drawRect(0, y + 1, w, y + rowH - 1, fill);
            float ty = y + rowH / 2 + 3.5f * d;
            text.setColor(0xFF8B95A7);
            cv.drawText(fmt.format(new Date(t.t)), 4 * d, ty, text);
            text.setColor(t.sell ? 0xFFF6465D : 0xFF0ECB81);
            text.setFakeBoldText(true);
            cv.drawText(t.sell ? "SELL" : "BUY", 62 * d, ty, text);
            text.setFakeBoldText(false);
            cv.drawText(Fmt.price(t.price), 98 * d, ty, text);
            text.setColor(0xFFE8EAED);
            String u = Fmt.usd(t.usd) + "  " + kind;
            cv.drawText(u, w - text.measureText(u) - 4 * d, ty, text);
            i++;
        }
    }
}
