package com.signal.bot;

import java.util.Locale;

/**
 * Turns a BUY/SELL view into a concrete position: enter NOW, wait for a RETEST, or wait for the
 * BREAKOUT — with the entry zone, stop-loss and two targets.
 */
public final class Position {
    private Position() {}

    public static final String NOW = "NOW", RETEST = "RETEST", BREAKOUT = "BREAKOUT", PULLBACK = "PULLBACK";

    public static final class Advice {
        public boolean buy;
        public String type, title, why;
        public double entry, zoneLo, zoneHi, sl, tp1, tp2;
    }

    private static String p(double v) { return Fmt.price(v); }

    /**
     * @param flow5buy buyers % over the last 5 minutes (NaN if unknown)
     * @param flow15net net USD in(+)/out(-) over 15 minutes (NaN if unknown)
     */
    public static Advice compute(boolean buy, double price, double atr, double stopAtr, PatternEngine.Result pat,
                                 double support, double resistance, double flow5buy, double flow15net) {
        Advice a = new Advice();
        a.buy = buy;
        if (atr <= 0) atr = price * 0.01;
        boolean hasFlow = !Double.isNaN(flow5buy);
        boolean volIn = hasFlow && flow5buy >= 55 && (Double.isNaN(flow15net) || flow15net > 0);
        boolean volOut = hasFlow && flow5buy <= 45 && (Double.isNaN(flow15net) || flow15net < 0);
        double key = pat != null ? pat.keyLevel : 0;
        boolean brk = pat != null && pat.breakout;
        String flowTxt = hasFlow ? String.format(Locale.US, " (5 min: buyers %.0f%%)", flow5buy) : "";

        if (buy) {
            if (brk && key > 0 && price - key > 0.8 * atr) {
                a.type = RETEST;
                a.zoneLo = key - 0.2 * atr;
                a.zoneHi = key + 0.3 * atr;
                a.title = "⏳ RETEST KA WAIT — $" + p(a.zoneLo) + " – $" + p(a.zoneHi) + " par buy";
                a.why = "Breakout ho chuka hai magar price level se door nikal gayi hai. Peechay aa kar $" + p(key)
                        + " ko chhoo kar wapas uthe to wahan entry mehfooz hai.";
            } else if (support > 0 && price - support <= 0.8 * atr && price >= support && volIn) {
                a.type = NOW;
                a.zoneLo = support;
                a.zoneHi = price;
                a.title = "✅ ABHI BUY — support par volume aa raha" + flowTxt;
                a.why = "Price support $" + p(support) + " ke qareeb hai aur buyers aggressive hain.";
            } else if (!brk && key > price && key - price < 1.5 * atr) {
                a.type = BREAKOUT;
                a.zoneLo = key;
                a.zoneHi = key + 0.3 * atr;
                a.title = "🚀 BREAKOUT KA WAIT — $" + p(key) + " ke upar candle close + volume par buy";
                a.why = "Resistance abhi toota nahi. Upar band ho aur volume aaye to entry, warna intezar.";
            } else if (volIn) {
                a.type = NOW;
                a.zoneLo = price - 0.3 * atr;
                a.zoneHi = price;
                a.title = "✅ ABHI BUY — volume aa raha, upar ja sakta hai" + flowTxt;
                a.why = "Saare exchanges par khareedne wale aage hain. Chhoti entry abhi, baqi dip par.";
            } else {
                a.type = PULLBACK;
                a.zoneLo = Math.max(support > 0 && support < price ? support : 0, price - 1.2 * atr);
                a.zoneHi = price - 0.4 * atr;
                a.title = "⏳ DIP KA WAIT — $" + p(a.zoneLo) + " – $" + p(a.zoneHi) + " par buy";
                a.why = "Trend upar hai magar abhi volume kamzor hai" + flowTxt + ". Neeche zone mein behtar qeemat milegi.";
            }
        } else {
            if (brk && key > 0 && key - price > 0.8 * atr) {
                a.type = RETEST;
                a.zoneLo = key - 0.3 * atr;
                a.zoneHi = key + 0.2 * atr;
                a.title = "⏳ RETEST KA WAIT — $" + p(a.zoneLo) + " – $" + p(a.zoneHi) + " par sell";
                a.why = "Support toot chuka hai. Price wapas $" + p(key) + " tak aa kar ruke to wahan sell / exit.";
            } else if (resistance > 0 && resistance - price <= 0.8 * atr && price <= resistance && volOut) {
                a.type = NOW;
                a.zoneLo = price;
                a.zoneHi = resistance;
                a.title = "🔻 ABHI SELL — resistance par volume nikal raha" + flowTxt;
                a.why = "Price resistance $" + p(resistance) + " ke paas ruk rahi hai aur sellers aggressive hain.";
            } else if (!brk && key > 0 && key < price && price - key < 1.5 * atr) {
                a.type = BREAKOUT;
                a.zoneLo = key - 0.3 * atr;
                a.zoneHi = key;
                a.title = "📉 BREAKDOWN KA WAIT — $" + p(key) + " ke neeche close par sell";
                a.why = "Support abhi toota nahi. Neeche band ho aur volume nikle to sell / exit.";
            } else if (volOut) {
                a.type = NOW;
                a.zoneLo = price;
                a.zoneHi = price + 0.3 * atr;
                a.title = "🔻 ABHI SELL — volume nikal raha, neeche ja sakta hai" + flowTxt;
                a.why = "Saare exchanges par bechne wale aage hain. Holding ho to bech dein / short ka setup.";
            } else {
                a.type = PULLBACK;
                a.zoneLo = price + 0.4 * atr;
                a.zoneHi = Math.min(resistance > price ? resistance : Double.MAX_VALUE, price + 1.2 * atr);
                a.title = "⏳ BOUNCE KA WAIT — $" + p(a.zoneLo) + " – $" + p(a.zoneHi) + " par sell";
                a.why = "Trend neeche hai magar selling abhi dheemi hai" + flowTxt + ". Upar bounce par behtar sell milega.";
            }
        }
        a.entry = (a.zoneLo + a.zoneHi) / 2;
        double risk = stopAtr * atr;
        if (buy) {
            a.sl = a.zoneLo - risk * 0.8;
            if (support > 0 && support < a.zoneLo && a.zoneLo - support < 2.5 * atr) a.sl = Math.min(a.sl, support - 0.2 * atr);
            double r = a.entry - a.sl;
            a.tp1 = a.entry + 1.5 * r;
            a.tp2 = a.entry + 3 * r;
        } else {
            a.sl = a.zoneHi + risk * 0.8;
            if (resistance > a.zoneHi && resistance - a.zoneHi < 2.5 * atr) a.sl = Math.max(a.sl, resistance + 0.2 * atr);
            double r = a.sl - a.entry;
            a.tp1 = Math.max(a.entry - 1.5 * r, a.entry * 0.05);
            a.tp2 = Math.max(a.entry - 3 * r, a.entry * 0.05);
        }
        return a;
    }
}
