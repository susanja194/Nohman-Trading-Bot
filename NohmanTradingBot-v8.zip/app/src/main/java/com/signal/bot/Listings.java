package com.signal.bot;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * New-listing announcements from Binance, Bybit, OKX and KuCoin (public endpoints, no key),
 * plus "where is it trading BEFORE the listing" from DexScreener (DEX pairs) and CoinGecko (CEX tickers).
 */
public final class Listings {
    private Listings() {}

    public static final class Item {
        public String exchange, title, url, coin = "", code;
        public long announced, listTime;   // ms; listTime 0 = unknown
    }

    public static final class Market {
        public String venue, pair, url, chain;
        public double priceUsd, vol24, liquidity;
        public boolean dex;
    }

    private static final ExecutorService POOL = Executors.newFixedThreadPool(4);
    private static final Pattern PAREN = Pattern.compile("\\(([A-Z0-9]{2,12})\\)");
    private static final Pattern UTC = Pattern.compile("(20\\d\\d-\\d\\d-\\d\\d) (\\d\\d:\\d\\d) ?\\(UTC\\)");

    public static List<Item> fetchAll() {
        List<Callable<List<Item>>> jobs = new ArrayList<>();
        jobs.add(Listings::binance);
        jobs.add(Listings::bybit);
        jobs.add(Listings::okx);
        jobs.add(Listings::kucoin);
        List<Item> all = new ArrayList<>();
        try {
            for (Future<List<Item>> f : POOL.invokeAll(jobs, 25, TimeUnit.SECONDS)) {
                try {
                    List<Item> l = f.get();
                    if (l != null) all.addAll(l);
                } catch (Exception ignored) {
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        Collections.sort(all, (a, b) -> Long.compare(b.announced, a.announced));
        return all;
    }

    static String coinFrom(String title) {
        Matcher m = PAREN.matcher(title);
        String last = "";
        while (m.find()) {
            String c = m.group(1);
            if (!c.equals("USDT") && !c.equals("USDC") && !c.equals("UTC")) { last = c; break; }
        }
        return last;
    }

    static long parseUtc(String text) {
        Matcher m = UTC.matcher(text);
        if (!m.find()) return 0;
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            return f.parse(m.group(1) + " " + m.group(2)).getTime();
        } catch (Exception e) {
            return 0;
        }
    }

    // ---------------- Binance (CMS catalog 48 = "New Cryptocurrency Listing")
    private static List<Item> binance() throws Exception {
        JSONObject o = new JSONObject(Scanner.getAbsolute(
                "https://www.binance.com/bapi/composite/v1/public/cms/article/list/query?type=1&catalogId=48&pageNo=1&pageSize=15"));
        JSONArray cats = o.getJSONObject("data").getJSONArray("catalogs");
        List<Item> out = new ArrayList<>();
        for (int c = 0; c < cats.length(); c++) {
            JSONArray arts = cats.getJSONObject(c).getJSONArray("articles");
            for (int i = 0; i < arts.length(); i++) {
                JSONObject a = arts.getJSONObject(i);
                Item it = new Item();
                it.exchange = "Binance";
                it.title = a.optString("title");
                it.code = a.optString("code");
                it.announced = a.optLong("releaseDate");
                it.url = "https://www.binance.com/en/support/announcement/" + it.code;
                it.coin = coinFrom(it.title);
                out.add(it);
            }
        }
        // listing time is inside the article: fetch details for the newest few
        for (int i = 0; i < out.size() && i < 6; i++) {
            try {
                String d = Scanner.getAbsolute("https://www.binance.com/bapi/composite/v1/public/cms/article/detail/query?articleCode="
                        + out.get(i).code);
                out.get(i).listTime = parseUtc(d);
            } catch (Exception ignored) {
            }
        }
        return out;
    }

    // ---------------- Bybit
    private static List<Item> bybit() throws Exception {
        JSONObject o = new JSONObject(Scanner.getAbsolute("https://api.bybit.com/v5/announcements/index?locale=en-US&type=new_crypto&limit=15"));
        JSONArray l = o.getJSONObject("result").getJSONArray("list");
        List<Item> out = new ArrayList<>();
        for (int i = 0; i < l.length(); i++) {
            JSONObject a = l.getJSONObject(i);
            Item it = new Item();
            it.exchange = "Bybit";
            it.title = a.optString("title");
            it.url = a.optString("url");
            it.announced = a.optLong("publishTime", a.optLong("dateTimestamp"));
            long st = a.optLong("startDateTimestamp");
            it.listTime = st > 0 ? st : parseUtc(a.optString("description"));
            it.coin = coinFrom(it.title);
            out.add(it);
        }
        return out;
    }

    // ---------------- OKX
    private static List<Item> okx() throws Exception {
        JSONObject o = new JSONObject(Scanner.getAbsolute("https://www.okx.com/api/v5/support/announcements?annType=announcements-new-listings"));
        JSONArray data = o.getJSONArray("data");
        List<Item> out = new ArrayList<>();
        for (int d = 0; d < data.length(); d++) {
            JSONArray det = data.getJSONObject(d).optJSONArray("details");
            if (det == null) continue;
            for (int i = 0; i < det.length() && i < 15; i++) {
                JSONObject a = det.getJSONObject(i);
                Item it = new Item();
                it.exchange = "OKX";
                it.title = a.optString("title");
                it.url = a.optString("url");
                it.announced = (long) Double.parseDouble(a.optString("pTime", "0"));
                it.coin = coinFrom(it.title);
                out.add(it);
            }
        }
        return out;
    }

    // ---------------- KuCoin
    private static List<Item> kucoin() throws Exception {
        JSONObject o = new JSONObject(Scanner.getAbsolute("https://api.kucoin.com/api/v3/announcements?annType=new-listings&lang=en_US&pageSize=15"));
        JSONArray l = o.getJSONObject("data").getJSONArray("items");
        List<Item> out = new ArrayList<>();
        for (int i = 0; i < l.length(); i++) {
            JSONObject a = l.getJSONObject(i);
            Item it = new Item();
            it.exchange = "KuCoin";
            it.title = a.optString("annTitle");
            it.url = a.optString("annUrl");
            it.announced = a.optLong("cTime");
            it.listTime = parseUtc(a.optString("annDesc"));
            it.coin = coinFrom(it.title);
            out.add(it);
        }
        return out;
    }

    // ---------------- where is it trading right now (before / after listing)
    public static List<Market> markets(String coin) {
        List<Market> out = new ArrayList<>();
        try {
            JSONObject o = new JSONObject(Scanner.getAbsolute("https://api.dexscreener.com/latest/dex/search?q=" + URLEncoder.encode(coin, "UTF-8")));
            JSONArray pairs = o.optJSONArray("pairs");
            if (pairs != null) {
                for (int i = 0; i < pairs.length() && out.size() < 8; i++) {
                    JSONObject p = pairs.getJSONObject(i);
                    JSONObject bt = p.optJSONObject("baseToken");
                    if (bt == null || !coin.equalsIgnoreCase(bt.optString("symbol"))) continue;
                    Market m = new Market();
                    m.dex = true;
                    m.chain = p.optString("chainId");
                    m.venue = p.optString("dexId") + " (" + m.chain + ")";
                    JSONObject qt = p.optJSONObject("quoteToken");
                    m.pair = coin + "/" + (qt == null ? "?" : qt.optString("symbol"));
                    m.url = p.optString("url");
                    m.priceUsd = p.optDouble("priceUsd", 0);
                    JSONObject v = p.optJSONObject("volume");
                    m.vol24 = v == null ? 0 : v.optDouble("h24", 0);
                    JSONObject liq = p.optJSONObject("liquidity");
                    m.liquidity = liq == null ? 0 : liq.optDouble("usd", 0);
                    out.add(m);
                }
            }
        } catch (Exception ignored) {
        }
        try {
            JSONObject sr = new JSONObject(Scanner.getAbsolute("https://api.coingecko.com/api/v3/search?query=" + URLEncoder.encode(coin, "UTF-8")));
            JSONArray coins = sr.getJSONArray("coins");
            String id = null;
            for (int i = 0; i < coins.length(); i++) {
                JSONObject c = coins.getJSONObject(i);
                if (coin.equalsIgnoreCase(c.optString("symbol"))) { id = c.optString("id"); break; }
            }
            if (id != null) {
                JSONObject t = new JSONObject(Scanner.getAbsolute("https://api.coingecko.com/api/v3/coins/" + id + "/tickers?order=volume_desc"));
                JSONArray tk = t.getJSONArray("tickers");
                for (int i = 0; i < tk.length() && i < 10; i++) {
                    JSONObject x = tk.getJSONObject(i);
                    JSONObject mk = x.optJSONObject("market");
                    Market m = new Market();
                    m.dex = false;
                    m.venue = mk == null ? "?" : mk.optString("name");
                    m.pair = x.optString("base") + "/" + x.optString("target");
                    m.url = x.optString("trade_url", "");
                    JSONObject cl = x.optJSONObject("converted_last");
                    m.priceUsd = cl == null ? 0 : cl.optDouble("usd", 0);
                    JSONObject cv = x.optJSONObject("converted_volume");
                    m.vol24 = cv == null ? 0 : cv.optDouble("usd", 0);
                    out.add(m);
                }
            }
        } catch (Exception ignored) {
        }
        Collections.sort(out, (a, b) -> Double.compare(b.vol24, a.vol24));
        return out;
    }
}
