package com.signal.bot;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * How much money came IN (aggressive buys) and went OUT (aggressive sells) in the last
 * 1, 5 and 15 minutes — summed over several exchanges:
 *  Binance spot + Binance futures (exact, from 1-minute candles),
 *  Bybit futures, OKX spot, Coinbase (from their latest trades; counted only for windows the trades cover).
 */
public final class FlowWindows {
    private FlowWindows() {}

    public static final int[] WIN = {1, 5, 15};

    public static final class Result {
        public final double[] in = new double[3], out = new double[3];
        public final List<String> venues = new ArrayList<>();
        public final List<String> partial = new ArrayList<>();

        public double net(int k) { return in[k] - out[k]; }
        public double buyPct(int k) { double t = in[k] + out[k]; return t > 0 ? in[k] / t * 100 : 50; }
    }

    private static final ExecutorService POOL = Executors.newFixedThreadPool(5);

    private static double d(String s) {
        try { return Double.parseDouble(s); } catch (Exception e) { return 0; }
    }

    // each venue returns {in1, in5, in15, out1, out5, out15, minutesCovered}

    public static Result fetch(final String base) {
        final String sym = base + "USDT";
        final long now = System.currentTimeMillis();
        final String[] names = {"Binance Spot", "Binance Futures", "Bybit", "OKX", "Coinbase"};
        List<Callable<double[]>> jobs = new ArrayList<>();
        jobs.add(() -> klines(Scanner.get("/api/v3/klines?symbol=" + sym + "&interval=1m&limit=16"), now));
        jobs.add(() -> klines(Scanner.getAbsolute("https://fapi.binance.com/fapi/v1/klines?symbol=" + sym + "&interval=1m&limit=16"), now));
        jobs.add(() -> bybit(sym, now));
        jobs.add(() -> okx(base, now));
        jobs.add(() -> coinbase(base, now));
        Result r = new Result();
        try {
            List<Future<double[]>> fs = POOL.invokeAll(jobs, 15, TimeUnit.SECONDS);
            for (int j = 0; j < fs.size(); j++) {
                try {
                    double[] v = fs.get(j).get();
                    if (v == null) continue;
                    r.venues.add(names[j]);
                    for (int k = 0; k < 3; k++) {
                        if (v[6] + 0.01 < WIN[k]) {
                            // this venue's latest trades don't reach back that far: leave it out of this window
                            if (!r.partial.contains(names[j])) r.partial.add(names[j]);
                            continue;
                        }
                        r.in[k] += v[k];
                        r.out[k] += v[3 + k];
                    }
                } catch (Exception ignored) {
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return r;
    }

    private static void add(double[] v, long age, double usd, boolean buy) {
        for (int k = 0; k < 3; k++) {
            if (age <= WIN[k] * 60_000L) v[(buy ? 0 : 3) + k] += usd;
        }
    }

    /** Binance 1-minute klines: the last closed 15 + the live one. */
    private static double[] klines(String json, long now) throws Exception {
        JSONArray a = new JSONArray(json);
        double[] v = new double[7];
        for (int i = 0; i < a.length(); i++) {
            JSONArray k = a.getJSONArray(i);
            long age = now - k.getLong(0);          // since the candle OPENED
            double q = d(k.getString(7)), tb = d(k.getString(10));
            for (int w = 0; w < 3; w++) {
                if (age < WIN[w] * 60_000L) {
                    v[w] += tb;
                    v[3 + w] += q - tb;
                }
            }
        }
        v[6] = 15;
        return v;
    }

    private static double[] trades(List<double[]> ts, long now) {
        double[] v = new double[7];
        long oldest = now;
        for (double[] t : ts) {
            long tt = (long) t[0];
            oldest = Math.min(oldest, tt);
            add(v, Math.max(0, now - tt), t[1], t[2] > 0);
        }
        v[6] = (now - oldest) / 60_000.0;
        return v;
    }

    private static double[] bybit(String sym, long now) throws Exception {
        JSONObject o = new JSONObject(Scanner.getAbsolute("https://api.bybit.com/v5/market/recent-trade?category=linear&symbol=" + sym + "&limit=1000"));
        JSONArray a = o.getJSONObject("result").getJSONArray("list");
        List<double[]> ts = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject t = a.getJSONObject(i);
            ts.add(new double[]{d(t.optString("time")), d(t.optString("price")) * d(t.optString("size")),
                    "Buy".equalsIgnoreCase(t.optString("side")) ? 1 : 0});
        }
        return ts.isEmpty() ? null : trades(ts, now);
    }

    private static double[] okx(String base, long now) throws Exception {
        JSONObject o = new JSONObject(Scanner.getAbsolute("https://www.okx.com/api/v5/market/trades?instId=" + base + "-USDT&limit=500"));
        JSONArray a = o.getJSONArray("data");
        List<double[]> ts = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject t = a.getJSONObject(i);
            ts.add(new double[]{d(t.optString("ts")), d(t.optString("px")) * d(t.optString("sz")),
                    "buy".equals(t.optString("side")) ? 1 : 0});
        }
        return ts.isEmpty() ? null : trades(ts, now);
    }

    private static double[] coinbase(String base, long now) throws Exception {
        JSONArray a = new JSONArray(Scanner.getAbsolute("https://api.exchange.coinbase.com/products/" + base + "-USD/trades?limit=1000"));
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US);
        f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
        List<double[]> ts = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject t = a.getJSONObject(i);
            String tm = t.optString("time");
            if (tm.length() < 19) continue;
            long ms = f.parse(tm.substring(0, 19)).getTime();
            // Coinbase "side" = maker side; maker sell = taker BUY
            ts.add(new double[]{ms, d(t.optString("price")) * d(t.optString("size")), "sell".equals(t.optString("side")) ? 1 : 0});
        }
        return ts.isEmpty() ? null : trades(ts, now);
    }
}
