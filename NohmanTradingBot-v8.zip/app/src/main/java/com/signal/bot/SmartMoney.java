package com.signal.bot;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

/**
 * "Smart money" checks using free, public Binance data (no API key):
 *  - Whale trades: large spot trades and whether they were buys or sells
 *  - Futures top traders' long/short position ratio (what the biggest accounts are doing)
 *  - Futures open interest (new money entering or leaving)
 *  - Crypto Fear & Greed index (overall market sentiment)
 * Every call fails quietly: a coin without futures simply gets no futures points.
 */
public final class SmartMoney {
    private SmartMoney() {}

    private static String usd(double v) {
        if (v >= 1_000_000) return String.format(Locale.US, "$%.1fM", v / 1_000_000);
        return String.format(Locale.US, "$%.0fK", v / 1000);
    }

    /** Adds whale / top-trader / open-interest evidence to the result. */
    public static void enrich(String sym, Analyzer.Result r, double whaleUsd, boolean useFutures)
            throws InterruptedException {
        // 1) Whale trades on spot (last 1000 trades)
        try {
            JSONArray tr = new JSONArray(Scanner.get("/api/v3/aggTrades?symbol=" + sym + "&limit=1000"));
            double wBuy = 0, wSell = 0;
            int cBuy = 0, cSell = 0;
            for (int i = 0; i < tr.length(); i++) {
                JSONObject t = tr.getJSONObject(i);
                double usd = Double.parseDouble(t.getString("p")) * Double.parseDouble(t.getString("q"));
                if (usd < whaleUsd) continue;
                // m = true -> buyer was maker -> the aggressive side SOLD
                if (t.optBoolean("m")) { wSell += usd; cSell++; } else { wBuy += usd; cBuy++; }
            }
            if (wBuy >= whaleUsd * 2 && wBuy > wSell * 2) {
                r.buyScore += 2;
                r.buyReasons.add("🐋 Whales BUY: " + cBuy + " bade orders " + usd(wBuy) + " vs sell " + usd(wSell));
            } else if (wSell >= whaleUsd * 2 && wSell > wBuy * 2) {
                r.sellScore += 2;
                r.volumeOutflow = true;
                r.sellReasons.add("🐋 Whales SELL: " + cSell + " bade orders " + usd(wSell) + " vs buy " + usd(wBuy));
            }
        } catch (Exception ignored) {
        }
        Thread.sleep(100);

        if (!useFutures) return;

        // 2) Top traders' long/short position ratio (futures)
        try {
            JSONArray a = new JSONArray(Scanner.getAbsolute(
                    "https://fapi.binance.com/futures/data/topLongShortPositionRatio?symbol=" + sym + "&period=15m&limit=4"));
            if (a.length() >= 2) {
                double first = a.getJSONObject(0).optDouble("longShortRatio", 0);
                double last = a.getJSONObject(a.length() - 1).optDouble("longShortRatio", 0);
                String s = String.format(Locale.US, "%.2f→%.2f", first, last);
                if (last > 1.0 && last > first * 1.03) {
                    r.buyScore += 1;
                    r.buyReasons.add("Top traders long badha rahe (L/S " + s + ")");
                } else if (last < first * 0.97) {
                    r.sellScore += 1;
                    r.sellReasons.add("Top traders long kam kar rahe (L/S " + s + ")");
                }
            }
        } catch (Exception ignored) {
        }
        Thread.sleep(100);

        // 3) Open interest: new money in futures
        try {
            JSONArray a = new JSONArray(Scanner.getAbsolute(
                    "https://fapi.binance.com/futures/data/openInterestHist?symbol=" + sym + "&period=15m&limit=5"));
            if (a.length() >= 2) {
                double first = a.getJSONObject(0).optDouble("sumOpenInterestValue", 0);
                double last = a.getJSONObject(a.length() - 1).optDouble("sumOpenInterestValue", 0);
                if (first > 0) {
                    double ch = (last / first - 1) * 100;
                    String s = String.format(Locale.US, "%+.1f%%", ch);
                    if (ch >= 3 && r.priceChange5 > 0) {
                        r.buyScore += 1;
                        r.buyReasons.add("Open interest " + s + " — naya paisa aa raha");
                    } else if (ch >= 3 && r.priceChange5 < 0) {
                        r.sellScore += 1;
                        r.sellReasons.add("Open interest " + s + " jab price gir rahi — shorts aa rahe");
                    } else if (ch <= -3 && r.priceChange5 < 0) {
                        r.sellScore += 1;
                        r.volumeOutflow = true;
                        r.sellReasons.add("Open interest " + s + " — paisa futures se nikal raha");
                    }
                }
            }
        } catch (Exception ignored) {
        }
    }

    /** Returns {value, label} e.g. {"34","Fear"}, or null. */
    public static String[] fearGreed() {
        try {
            JSONObject o = new JSONObject(Scanner.getAbsolute("https://api.alternative.me/fng/?limit=1"));
            JSONObject d = o.getJSONArray("data").getJSONObject(0);
            return new String[]{d.getString("value"), d.getString("value_classification")};
        } catch (Exception e) {
            return null;
        }
    }
}
