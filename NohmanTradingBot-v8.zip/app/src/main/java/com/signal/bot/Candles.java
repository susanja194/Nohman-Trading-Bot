package com.signal.bot;

import org.json.JSONArray;

/** OHLCV candles from Binance klines, oldest first. */
public final class Candles {
    public final int n;
    public final long[] time;
    public final double[] open, high, low, close, vol, takerBuy, quoteVol, takerBuyQuote, trades;

    private Candles(int n) {
        this.n = n;
        time = new long[n];
        open = new double[n];
        high = new double[n];
        low = new double[n];
        close = new double[n];
        vol = new double[n];
        takerBuy = new double[n];
        quoteVol = new double[n];
        takerBuyQuote = new double[n];
        trades = new double[n];
    }

    public static Candles parse(String json, boolean closedOnly) throws Exception {
        JSONArray arr = new JSONArray(json);
        int n = closedOnly ? Math.max(0, arr.length() - 1) : arr.length();
        Candles c = new Candles(n);
        for (int i = 0; i < n; i++) {
            JSONArray k = arr.getJSONArray(i);
            c.time[i] = k.getLong(0);
            c.open[i] = Double.parseDouble(k.getString(1));
            c.high[i] = Double.parseDouble(k.getString(2));
            c.low[i] = Double.parseDouble(k.getString(3));
            c.close[i] = Double.parseDouble(k.getString(4));
            c.vol[i] = Double.parseDouble(k.getString(5));
            c.quoteVol[i] = k.length() > 7 ? Double.parseDouble(k.getString(7)) : c.vol[i] * c.close[i];
            c.trades[i] = k.length() > 8 ? k.getLong(8) : 0;
            c.takerBuy[i] = k.length() > 9 ? Double.parseDouble(k.getString(9)) : c.vol[i] / 2;
            c.takerBuyQuote[i] = k.length() > 10 ? Double.parseDouble(k.getString(10)) : c.quoteVol[i] / 2;
        }
        return c;
    }

    /** closedOnly = drop the still-forming candle (for analysis). */
    public static Candles fetch(String symbol, String tf, int limit, boolean closedOnly) throws Exception {
        return parse(Scanner.get("/api/v3/klines?symbol=" + symbol + "&interval=" + tf + "&limit=" + limit), closedOnly);
    }

    /** Index of the candle that contains time t (ms), or -1. */
    public int indexOf(long t) {
        int lo = 0, hi = n - 1, ans = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (time[mid] <= t) { ans = mid; lo = mid + 1; } else hi = mid - 1;
        }
        return ans;
    }

    private void set(int i, long t, double o, double h, double l, double c, double v, double q,
                     double tbv, double tbq, double tr) {
        time[i] = t; open[i] = o; high[i] = h; low[i] = l; close[i] = c; vol[i] = v;
        quoteVol[i] = q; takerBuy[i] = tbv; takerBuyQuote[i] = tbq; trades[i] = tr;
    }

    /**
     * Applies a live kline from the WebSocket. Updates the last candle in place and returns this,
     * or returns a NEW Candles shifted by one when a new candle has opened, or null for stale data.
     */
    public Candles live(long t, double o, double h, double l, double c, double v, double q,
                        double tbv, double tbq, double tr) {
        if (n == 0) return null;
        int li = n - 1;
        if (t == time[li]) {
            set(li, t, o, h, l, c, v, q, tbv, tbq, tr);
            return this;
        }
        if (t < time[li]) return null;
        Candles x = new Candles(n);
        System.arraycopy(time, 1, x.time, 0, li);
        System.arraycopy(open, 1, x.open, 0, li);
        System.arraycopy(high, 1, x.high, 0, li);
        System.arraycopy(low, 1, x.low, 0, li);
        System.arraycopy(close, 1, x.close, 0, li);
        System.arraycopy(vol, 1, x.vol, 0, li);
        System.arraycopy(quoteVol, 1, x.quoteVol, 0, li);
        System.arraycopy(takerBuy, 1, x.takerBuy, 0, li);
        System.arraycopy(takerBuyQuote, 1, x.takerBuyQuote, 0, li);
        System.arraycopy(trades, 1, x.trades, 0, li);
        x.set(li, t, o, h, l, c, v, q, tbv, tbq, tr);
        return x;
    }

    /** Copy without the last (still forming) candle — for analysis on closed candles only. */
    public Candles closedOnly() {
        Candles x = new Candles(Math.max(0, n - 1));
        for (int i = 0; i < x.n; i++) x.set(i, time[i], open[i], high[i], low[i], close[i], vol[i], quoteVol[i], takerBuy[i], takerBuyQuote[i], trades[i]);
        return x;
    }
}
