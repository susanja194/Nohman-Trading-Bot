package com.signal.bot;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Semicircle score meter (0..100): red -> yellow -> green. */
public class GaugeView extends View {
    private static final int[] COLORS = {0xFFF6465D, 0xFFFF8A3D, 0xFFF0B90B, 0xFF9BE15D, 0xFF0ECB81};
    private int value = -1;
    private String label = "", sub = "";
    private final float d;
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG), big = new Paint(Paint.ANTI_ALIAS_FLAG),
            mid = new Paint(Paint.ANTI_ALIAS_FLAG), small = new Paint(Paint.ANTI_ALIAS_FLAG),
            dot = new Paint(Paint.ANTI_ALIAS_FLAG), track = new Paint(Paint.ANTI_ALIAS_FLAG);

    public GaugeView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeWidth(14 * d);
        track.setStyle(Paint.Style.STROKE);
        track.setStrokeWidth(14 * d);
        track.setColor(0xFF1E2840);
        big.setTextAlign(Paint.Align.CENTER);
        big.setTextSize(34 * d);
        big.setFakeBoldText(true);
        big.setColor(0xFFE8EAED);
        mid.setTextAlign(Paint.Align.CENTER);
        mid.setTextSize(15 * d);
        mid.setFakeBoldText(true);
        small.setTextAlign(Paint.Align.CENTER);
        small.setTextSize(11 * d);
        small.setColor(0xFF8B95A7);
    }

    public void set(int value, String label, String sub) {
        this.value = value;
        this.label = label == null ? "" : label;
        this.sub = sub == null ? "" : sub;
        invalidate();
    }

    static int colorFor(int v) {
        if (v < 0) return 0xFF8B95A7;
        return COLORS[Math.min(4, v / 20)];
    }

    @Override
    protected void onDraw(Canvas cv) {
        super.onDraw(cv);
        float w = getWidth(), h = getHeight();
        float stroke = 14 * d;
        float r = Math.min(w / 2 - stroke, h - 50 * d - stroke);
        if (r <= 0) return;
        float cx = w / 2, cy = stroke + r + 4 * d;
        RectF oval = new RectF(cx - r, cy - r, cx + r, cy + r);
        cv.drawArc(oval, 180, 180, false, track);
        for (int i = 0; i < 5; i++) {
            arc.setColor(COLORS[i]);
            cv.drawArc(oval, 180 + i * 36 + 1, 34, false, arc);
        }
        if (value >= 0) {
            double ang = Math.toRadians(180 + 180.0 * Math.min(100, value) / 100.0);
            float px = (float) (cx + r * Math.cos(ang)), py = (float) (cy + r * Math.sin(ang));
            dot.setColor(0xFFFFFFFF);
            cv.drawCircle(px, py, stroke * 0.75f, dot);
            dot.setColor(colorFor(value));
            cv.drawCircle(px, py, stroke * 0.45f, dot);
        }
        cv.drawText(value >= 0 ? String.valueOf(value) : "--", cx, cy - 8 * d, big);
        mid.setColor(colorFor(value));
        cv.drawText(label, cx, cy + 18 * d, mid);
        cv.drawText(sub, cx, cy + 34 * d, small);
    }
}
