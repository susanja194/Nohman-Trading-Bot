package com.signal.bot;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

/** Auto-reconnecting Binance WebSocket stream (public market data, no key). */
public final class WsStream {
    public interface Callback {
        void onText(String text);
        void onStatus(boolean live);
    }

    private static final OkHttpClient CLIENT = new OkHttpClient.Builder()
            .pingInterval(20, TimeUnit.SECONDS)
            .build();
    private static final ScheduledExecutorService RETRY = Executors.newSingleThreadScheduledExecutor();
    private static final String[] HOSTS = {"wss://stream.binance.com:9443", "wss://data-stream.binance.vision"};

    private final String path;
    private final Callback cb;
    private volatile boolean stopped;
    private volatile WebSocket ws;
    private int host, fails;

    public WsStream(String path, Callback cb) {
        this.path = path;
        this.cb = cb;
    }

    public WsStream start() {
        connect();
        return this;
    }

    private void connect() {
        if (stopped) return;
        String url = HOSTS[host % HOSTS.length] + path;
        ws = CLIENT.newWebSocket(new Request.Builder().url(url).build(), new WebSocketListener() {
            @Override
            public void onOpen(WebSocket w, Response r) {
                fails = 0;
                if (!stopped) cb.onStatus(true);
            }

            @Override
            public void onMessage(WebSocket w, String text) {
                if (stopped) return;
                try {
                    cb.onText(text);
                } catch (Exception ignored) {
                }
            }

            @Override
            public void onFailure(WebSocket w, Throwable t, Response r) {
                retry();
            }

            @Override
            public void onClosed(WebSocket w, int code, String reason) {
                retry();
            }
        });
    }

    private synchronized void retry() {
        if (stopped) return;
        cb.onStatus(false);
        fails++;
        host++;
        long delay = Math.min(30, 2L * fails);
        RETRY.schedule(this::connect, delay, TimeUnit.SECONDS);
    }

    public void stop() {
        stopped = true;
        WebSocket w = ws;
        if (w != null) w.cancel();
    }
}
