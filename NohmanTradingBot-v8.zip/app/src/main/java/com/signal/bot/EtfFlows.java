package com.signal.bot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Daily spot-ETF net flows (US$ millions) from Farside Investors' public tables (no key).
 * Pages: BTC, ETH, SOL, HYPE, ZEC. Other coins use the BTC ETF flow as the market-wide mood.
 */
public final class EtfFlows {
    private EtfFlows() {}

    public static final class Result {
        public String asset;                       // which ETF table was used
        public boolean marketWide;                 // true when the coin has no ETF of its own
        public final List<String> dates = new ArrayList<>();
        public final List<Double> totals = new ArrayList<>();  // oldest -> newest, US$m
        public double last, sum5, avgAbs;
        public final List<String> funds = new ArrayList<>();     // tickers e.g. IBIT, FBTC ...
        public final List<double[]> rows = new ArrayList<>();    // per date: value per fund (NaN = not reported)
        public double[] fundTotal;                               // net flow since launch per fund (US$m)
        public double grandTotal = Double.NaN;
        public int score;                          // -100..100
    }

    private static final Map<String, Object[]> CACHE = new HashMap<>();   // page -> {time, Result}

    /** Who runs each ETF ticker. */
    public static String issuer(String t) {
        switch (t) {
            case "IBIT": case "ETHA": case "ETHB": return "BlackRock";
            case "FBTC": case "FETH": return "Fidelity";
            case "GBTC": case "ETHE": case "BTC": case "ETH": case "GSOL": return "Grayscale";
            case "BITB": case "ETHW": case "BSOL": return "Bitwise";
            case "ARKB": case "CETH": return "ARK 21Shares";
            case "HODL": case "ETHV": case "VSOL": return "VanEck";
            case "BTCO": case "QETH": return "Invesco";
            case "EZBC": case "EZET": return "Franklin";
            case "BRRR": return "Valkyrie";
            case "BTCW": return "WisdomTree";
            case "MSBT": return "Morgan Stanley";
            case "FSOL": return "Fidelity";
            default: return t;
        }
    }

    public static double[] fundFlow(Result r, String ticker) {
        int k = r.funds.indexOf(ticker);
        if (k < 0 || r.rows.isEmpty()) return null;
        double last = Double.NaN, sum = 0;
        int n = r.rows.size();
        for (int i = Math.max(0, n - 5); i < n; i++) {
            double[] row = r.rows.get(i);
            if (k >= row.length || Double.isNaN(row[k])) continue;
            sum += row[k];
            if (i == n - 1) last = row[k];
        }
        return new double[]{Double.isNaN(last) ? 0 : last, sum};
    }

    static String pageFor(String base) {
        switch (base) {
            case "BTC": return "btc";
            case "ETH": return "eth";
            case "SOL": return "sol";
            case "HYPE": return "hyp";
            case "ZEC": return "zec";
            default: return null;
        }
    }

    public static Result fetch(String base) {
        String page = pageFor(base);
        boolean wide = page == null;
        if (wide) page = "btc";
        Result r = cached(page);
        if (r == null) {
            try {
                r = parse(Scanner.getAbsolute("https://farside.co.uk/" + page + "/"));
                r.asset = page.toUpperCase(Locale.US).replace("HYP", "HYPE");
                synchronized (CACHE) {
                    CACHE.put(page, new Object[]{System.currentTimeMillis(), r});
                }
            } catch (Exception e) {
                return null;
            }
        }
        if (r == null || r.totals.isEmpty()) return null;
        Result out = copy(r);
        out.marketWide = wide;
        return out;
    }

    private static Result cached(String page) {
        synchronized (CACHE) {
            Object[] c = CACHE.get(page);
            if (c != null && System.currentTimeMillis() - (Long) c[0] < 30 * 60_000L) return (Result) c[1];
        }
        return null;
    }

    private static Result copy(Result a) {
        Result b = new Result();
        b.asset = a.asset;
        b.dates.addAll(a.dates);
        b.totals.addAll(a.totals);
        b.last = a.last;
        b.sum5 = a.sum5;
        b.avgAbs = a.avgAbs;
        b.score = a.score;
        b.funds.addAll(a.funds);
        b.rows.addAll(a.rows);
        b.fundTotal = a.fundTotal;
        b.grandTotal = a.grandTotal;
        return b;
    }

    private static final Pattern ROW = Pattern.compile("<tr[^>]*>(.*?)</tr>", Pattern.DOTALL | Pattern.CASE_INSENSITIVE);
    private static final Pattern CELL = Pattern.compile("<t[dh][^>]*>(.*?)</t[dh]>", Pattern.DOTALL | Pattern.CASE_INSENSITIVE);
    private static final Pattern DATE = Pattern.compile("^\\d{1,2} [A-Z][a-z]{2} \\d{4}$");

    static String clean(String s) {
        return s.replaceAll("<[^>]+>", "").replace("&nbsp;", " ").replace("&#160;", " ").replace(",", "").trim();
    }

    /** "(207.7)" -> -207.7, "12.5" -> 12.5, "-" -> NaN */
    static double value(String s) {
        s = s.trim();
        if (s.isEmpty() || s.equals("-") || s.equals("–")) return Double.NaN;
        boolean neg = s.startsWith("(") && s.endsWith(")");
        if (neg) s = s.substring(1, s.length() - 1);
        try {
            double v = Double.parseDouble(s);
            return neg ? -v : v;
        } catch (Exception e) {
            return Double.NaN;
        }
    }

    /** Parses a Farside flow table. Rows where every fund is "-" (not reported yet) are skipped. */
    public static Result parse(String html) {
        Result r = new Result();
        Matcher rm = ROW.matcher(html);
        while (rm.find()) {
            List<String> cells = new ArrayList<>();
            Matcher cm = CELL.matcher(rm.group(1));
            while (cm.find()) cells.add(clean(cm.group(1)));
            if (r.funds.isEmpty() && cells.size() >= 3 && cells.get(0).isEmpty()) {
                int tick = 0;
                for (int i = 1; i < cells.size(); i++) if (cells.get(i).matches("[A-Z]{2,5}")) tick++;
                if (tick >= 2) {
                    for (int i = 1; i < cells.size() - 1; i++) r.funds.add(cells.get(i));
                    continue;
                }
            }
            if (r.fundTotal == null && cells.size() >= 3 && cells.get(0).equalsIgnoreCase("Total")) {
                r.fundTotal = new double[cells.size() - 2];
                for (int i = 1; i < cells.size() - 1; i++) r.fundTotal[i - 1] = value(cells.get(i));
                r.grandTotal = value(cells.get(cells.size() - 1));
                continue;
            }
            if (cells.size() < 3 || !DATE.matcher(cells.get(0)).matches()) continue;
            int reported = 0;
            for (int i = 1; i < cells.size() - 1; i++) if (!Double.isNaN(value(cells.get(i)))) reported++;
            double total = value(cells.get(cells.size() - 1));
            if (reported == 0 || Double.isNaN(total)) continue;
            r.dates.add(cells.get(0));
            r.totals.add(total);
            double[] fv = new double[cells.size() - 2];
            for (int i = 1; i < cells.size() - 1; i++) fv[i - 1] = value(cells.get(i));
            r.rows.add(fv);
        }
        int n = r.totals.size();
        if (n == 0) return r;
        r.last = r.totals.get(n - 1);
        for (int i = Math.max(0, n - 5); i < n; i++) r.sum5 += r.totals.get(i);
        int c = 0;
        for (int i = Math.max(0, n - 30); i < n; i++) { r.avgAbs += Math.abs(r.totals.get(i)); c++; }
        r.avgAbs = c > 0 ? r.avgAbs / c : 0;
        if (r.avgAbs > 0) {
            double sc = Fmt.clamp(r.sum5 / (5 * r.avgAbs), -1, 1) * 0.6 + Fmt.clamp(r.last / (2 * r.avgAbs), -1, 1) * 0.4;
            r.score = (int) Math.round(Fmt.clamp(sc * 1.3, -1, 1) * 100);
        }
        return r;
    }
}
