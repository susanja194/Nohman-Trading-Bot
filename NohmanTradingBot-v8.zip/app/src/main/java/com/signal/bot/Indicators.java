package com.signal.bot;

/** Pure-Java technical indicators (no Android dependencies). */
public final class Indicators {
    private Indicators() {}

    /** Exponential moving average, seeded with the first value. */
    public static double[] ema(double[] v, int period) {
        double[] out = new double[v.length];
        if (v.length == 0) return out;
        double k = 2.0 / (period + 1);
        out[0] = v[0];
        for (int i = 1; i < v.length; i++) {
            out[i] = v[i] * k + out[i - 1] * (1 - k);
        }
        return out;
    }

    /** Wilder RSI. Values before enough data are 50. */
    public static double[] rsi(double[] c, int period) {
        double[] out = new double[c.length];
        for (int i = 0; i < out.length; i++) out[i] = 50;
        if (c.length <= period) return out;
        double gain = 0, loss = 0;
        for (int i = 1; i <= period; i++) {
            double d = c[i] - c[i - 1];
            if (d > 0) gain += d; else loss -= d;
        }
        gain /= period;
        loss /= period;
        out[period] = loss == 0 ? 100 : 100 - 100 / (1 + gain / loss);
        for (int i = period + 1; i < c.length; i++) {
            double d = c[i] - c[i - 1];
            double up = d > 0 ? d : 0;
            double dn = d < 0 ? -d : 0;
            gain = (gain * (period - 1) + up) / period;
            loss = (loss * (period - 1) + dn) / period;
            out[i] = loss == 0 ? 100 : 100 - 100 / (1 + gain / loss);
        }
        return out;
    }

    /** MACD histogram (12, 26, 9). */
    public static double[] macdHist(double[] c) {
        double[] fast = ema(c, 12);
        double[] slow = ema(c, 26);
        double[] line = new double[c.length];
        for (int i = 0; i < c.length; i++) line[i] = fast[i] - slow[i];
        double[] signal = ema(line, 9);
        double[] hist = new double[c.length];
        for (int i = 0; i < c.length; i++) hist[i] = line[i] - signal[i];
        return hist;
    }

    /** On-balance volume. */
    public static double[] obv(double[] c, double[] vol) {
        double[] out = new double[c.length];
        for (int i = 1; i < c.length; i++) {
            if (c[i] > c[i - 1]) out[i] = out[i - 1] + vol[i];
            else if (c[i] < c[i - 1]) out[i] = out[i - 1] - vol[i];
            else out[i] = out[i - 1];
        }
        return out;
    }

    /** Average of v[from..to) . */
    public static double mean(double[] v, int from, int to) {
        if (from < 0) from = 0;
        if (to <= from) return 0;
        double s = 0;
        for (int i = from; i < to; i++) s += v[i];
        return s / (to - from);
    }

    /** Average true range over the last `period` candles. */
    public static double atr(double[] h, double[] l, double[] c, int period) {
        int n = c.length;
        if (n < period + 1) return 0;
        double s = 0;
        for (int i = n - period; i < n; i++) {
            double tr = Math.max(h[i] - l[i], Math.max(Math.abs(h[i] - c[i - 1]), Math.abs(l[i] - c[i - 1])));
            s += tr;
        }
        return s / period;
    }
}
