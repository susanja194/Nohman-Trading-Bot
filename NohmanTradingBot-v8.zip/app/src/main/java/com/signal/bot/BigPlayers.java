package com.signal.bot;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Tracks the big players and notifies when they BUY or SELL (above the user's minimum, e.g. $50M):
 *  - Spot ETFs per issuer (BlackRock IBIT/ETHA, Fidelity, Grayscale ...) — Farside daily flows
 *  - Public companies & governments holding BTC / ETH — CoinGecko treasury (compared with last check)
 *  - Whale wallets (exchange cold wallets + any address the user adds) — balance compared with last check
 */
public final class BigPlayers {
    private BigPlayers() {}

    /** Well-known public cold wallets (labelled on mempool.space / Arkham). */
    public static final String[][] KNOWN = {
            {"Binance cold wallet", "34xp4vRoCGJym3xR7yCVPFHoCNxv4Twseo"},
            {"Bitfinex cold wallet", "bc1qgdjqv0av3q56jvd82tkdjpy7gdp9ut8tlqmgrpmv24sq90ecnvqqjwvw97"},
            {"World Liberty Financial (Trump)", Institutions.WLFI_WALLET},
    };

    public static final class Row {
        public String name, sub;
        public double value, change, usd;   // value = holdings / flow, change since last check
        public boolean flow;                 // true for ETF flow rows (US$m)
    }

    public static final class Report {
        public final List<Row> etfBtc = new ArrayList<>(), etfEth = new ArrayList<>(), etfSol = new ArrayList<>();
        public String etfBtcDate = "", etfEthDate = "", etfSolDate = "";
        public double etfBtcTotal = Double.NaN, etfEthTotal = Double.NaN, etfSolTotal = Double.NaN;
        public double etfBtcDay, etfEthDay, etfSolDay;
        public final List<Row> coBtc = new ArrayList<>(), coEth = new ArrayList<>(), gov = new ArrayList<>(), wallets = new ArrayList<>();
        public double coBtcTotal, coEthTotal, govTotal;
        public final List<String> events = new ArrayList<>();
    }

    public static Report fetch(Context c, boolean notify) {
        Report rep = new Report();
        JSONObject snap = Prefs.bigSnap(c);
        long min = Prefs.bigMinUsd(c);
        double btcPx = WalletTracker.price("BTC"), ethPx = WalletTracker.price("ETH");
        boolean first = snap.length() == 0;

        etf(c, rep, snap, "BTC", min, notify && !first);
        etf(c, rep, snap, "ETH", min, notify && !first);
        etf(c, rep, snap, "SOL", min, notify && !first);
        treasury(c, rep.coBtc, snap, "companies", "bitcoin", "BTC", btcPx, min, notify && !first, rep);
        treasury(c, rep.coEth, snap, "companies", "ethereum", "ETH", ethPx, min, notify && !first, rep);
        treasury(c, rep.gov, snap, "governments", "bitcoin", "BTC", btcPx, min, notify && !first, rep);
        for (Row r : rep.coBtc) rep.coBtcTotal += r.value;
        for (Row r : rep.coEth) rep.coEthTotal += r.value;
        for (Row r : rep.gov) rep.govTotal += r.value;

        List<String[]> ws = new ArrayList<>();
        for (String[] k : KNOWN) ws.add(k);
        JSONArray custom = Prefs.bigWallets(c);
        for (int i = 0; i < custom.length(); i++) {
            JSONObject o = custom.optJSONObject(i);
            if (o != null) ws.add(new String[]{o.optString("label"), o.optString("addr")});
        }
        for (String[] w : ws) {
            WalletTracker.Result r = WalletTracker.fetch(w[1]);
            if (r.error != null && r.holdings.isEmpty()) continue;
            Row row = new Row();
            row.name = w[0];
            row.sub = WalletTracker.shortAddr(w[1]) + " · " + WalletTracker.chainName(r.chain);
            row.usd = r.totalUsd;
            WalletTracker.Holding main = null;
            for (WalletTracker.Holding h : r.holdings) if (main == null || h.usd > main.usd) main = h;
            String k = "w_" + w[1];
            if (main != null) {
                row.value = main.amount;
                row.sub += " · " + main.asset;
            }
            double prevUsd = snap.optDouble(k, Double.NaN);
            if (!Double.isNaN(prevUsd)) {
                row.change = r.totalUsd - prevUsd;
                // wallet USD also moves with price; only count it when the coin amount changed
                double prevAmt = snap.optDouble(k + "_amt", Double.NaN);
                if (main != null && !Double.isNaN(prevAmt)) {
                    double dAmt = main.amount - prevAmt;
                    double usd = dAmt * (main.usd / Math.max(main.amount, 1e-18));
                    row.change = usd;
                    if (Math.abs(usd) >= min) event(c, rep, notify && !first, usd > 0,
                            String.format(Locale.US, "%s %s %s %s (%s)", w[0], usd > 0 ? "mein AAYE" : "se NIKLE",
                                    Fmt.num(Math.abs(dAmt)), main.asset, Fmt.usd(Math.abs(usd))));
                }
            }
            put(snap, k, r.totalUsd);
            if (main != null) put(snap, k + "_amt", main.amount);
            rep.wallets.add(row);
        }
        Prefs.saveBigSnap(c, snap);
        return rep;
    }

    private static void put(JSONObject o, String k, double v) {
        try { o.put(k, v); } catch (Exception ignored) { }
    }

    private static void event(Context c, Report rep, boolean notify, boolean buy, String text) {
        rep.events.add(text);
        Prefs.addBigMove(c, text, buy);
        if (notify) Notify.show(c, Prefs.N_BIG, 7000 + (text.hashCode() & 0xFFF), buy ? "🐋 Bada player KHAREED raha hai" : "🐋 Bada player BECH raha hai",
                text, buy ? 0xFF0ECB81 : 0xFFF6465D, MainActivity.TAB_BIG);
    }

    private static void etf(Context c, Report rep, JSONObject snap, String asset, long min, boolean notify) {
        EtfFlows.Result e = EtfFlows.fetch(asset);
        if (e == null || e.marketWide || e.dates.isEmpty()) return;
        List<Row> rows = asset.equals("BTC") ? rep.etfBtc : asset.equals("ETH") ? rep.etfEth : rep.etfSol;
        String date = e.dates.get(e.dates.size() - 1);
        double[] last = e.rows.get(e.rows.size() - 1);
        for (int i = 0; i < e.funds.size(); i++) {
            Row r = new Row();
            r.flow = true;
            r.name = EtfFlows.issuer(e.funds.get(i));
            r.sub = e.funds.get(i);
            r.change = i < last.length && !Double.isNaN(last[i]) ? last[i] : 0;
            r.value = e.fundTotal != null && i < e.fundTotal.length && !Double.isNaN(e.fundTotal[i]) ? e.fundTotal[i] : Double.NaN;
            rows.add(r);
        }
        rows.sort((a, b) -> Double.compare(Double.isNaN(b.value) ? -1e18 : b.value, Double.isNaN(a.value) ? -1e18 : a.value));
        if (asset.equals("BTC")) { rep.etfBtcDate = date; rep.etfBtcTotal = e.grandTotal; rep.etfBtcDay = e.last; }
        else if (asset.equals("ETH")) { rep.etfEthDate = date; rep.etfEthTotal = e.grandTotal; rep.etfEthDay = e.last; }
        else { rep.etfSolDate = date; rep.etfSolTotal = e.grandTotal; rep.etfSolDay = e.last; }

        String k = "etf_" + asset + "_date";
        if (!date.equals(snap.optString(k, ""))) {
            if (!snap.optString(k, "").isEmpty()) {
                for (int i = 0; i < e.funds.size(); i++) {
                    double v = i < last.length ? last[i] : Double.NaN;
                    if (Double.isNaN(v) || Math.abs(v) * 1e6 < min) continue;
                    event(c, rep, notify, v > 0, String.format(Locale.US, "%s (%s) ne %s ka %s %s (%s)", EtfFlows.issuer(e.funds.get(i)),
                            e.funds.get(i), m(v), asset, v > 0 ? "KHAREEDA (inflow)" : "BECHA (outflow)", date));
                }
                if (Math.abs(e.last) * 1e6 >= min)
                    event(c, rep, notify, e.last > 0, String.format(Locale.US, "Saare %s ETFs ka total: %s (%s)", asset, m(e.last), date));
            }
            try { snap.put(k, date); } catch (Exception ignored) { }
        }
    }

    private static void treasury(Context c, List<Row> rows, JSONObject snap, String entity, String coin, String sym,
                                 double px, long min, boolean notify, Report rep) {
        try {
            JSONObject o = new JSONObject(Scanner.getAbsolute("https://api.coingecko.com/api/v3/" + entity + "/public_treasury/" + coin));
            JSONArray list = o.optJSONArray(entity);
            if (list == null) list = o.optJSONArray("companies");
            if (list == null) return;
            for (int i = 0; i < list.length(); i++) {
                JSONObject x = list.getJSONObject(i);
                Row r = new Row();
                r.name = x.optString("name");
                r.sub = x.optString("country") + (x.optString("symbol").isEmpty() || x.optString("symbol").equals("null") ? "" : " · " + x.optString("symbol"));
                r.value = x.optDouble("total_holdings", 0);
                r.usd = r.value * px;
                String k = entity.charAt(0) + "_" + coin + "_" + r.name;
                double prev = snap.optDouble(k, Double.NaN);
                if (!Double.isNaN(prev)) {
                    r.change = r.value - prev;
                    double usd = r.change * px;
                    if (Math.abs(r.change) > 1e-9 && Math.abs(usd) >= min)
                        event(c, rep, notify, r.change > 0, String.format(Locale.US, "%s ne %s%s %s %s (%s)", r.name, r.change > 0 ? "+" : "−",
                                Fmt.num(Math.abs(r.change)), sym, r.change > 0 ? "KHAREEDE" : "BECHE", Fmt.usd(Math.abs(usd))));
                }
                put(snap, k, r.value);
                rows.add(r);
            }
        } catch (Exception ignored) {
        }
    }

    static String m(double millions) {
        double usd = millions * 1e6;
        return (usd >= 0 ? "+" : "−") + Fmt.usd(Math.abs(usd));
    }
}
