package com.signal.bot;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * Buyers vs sellers across MANY exchanges, not only Binance (all public APIs, no key):
 *  24h windows : Binance spot, Binance futures, OKX spot, OKX futures (taker buy/sell volume)
 *  live trades : Bybit futures, Coinbase, Kraken, KuCoin, Gate, Bitget (last ~1000 trades each)
 * "Taker buy" = someone paid the ask (aggressive buyer) -> money coming in.
 */
public final class CrossExchange {
    private CrossExchange() {}

    public static final class Venue {
        public final String name, window;
        public final double buyPct, buyUsd, sellUsd;   // usd < 0 = unknown units
        public final boolean day;

        Venue(String name, String window, double buy, double sell, boolean usdKnown, boolean day) {
            this.name = name;
            this.window = window;
            double t = buy + sell;
            this.buyPct = t > 0 ? buy / t * 100 : 50;
            this.buyUsd = usdKnown ? buy : -1;
            this.sellUsd = usdKnown ? sell : -1;
            this.day = day;
        }
    }

    public static final class Result {
        public final List<Venue> venues = new ArrayList<>();
        public double buyPct = 50;       // weighted across venues
        public int bull, bear;
        public double netUsd;            // known-USD venues only
        public int score;                // -100..100
    }

    private static final ExecutorService POOL = Executors.newFixedThreadPool(6);

    private static double d(String s) {
        try { return Double.parseDouble(s); } catch (Exception e) { return 0; }
    }

    private static String mins(long t0, long t1) {
        long m = Math.max(1, Math.abs(t1 - t0) / 60000);
        return m >= 120 ? (m / 60) + "h" : m + "m";
    }

    public static Result fetch(final String base) {
        final String sym = base + "USDT";
        List<Callable<Venue>> jobs = new ArrayList<>();
        jobs.add(() -> binance(sym, false));
        jobs.add(() -> binance(sym, true));
        jobs.add(() -> okx(base, "SPOT"));
        jobs.add(() -> okx(base, "CONTRACTS"));
        jobs.add(() -> bybit(sym));
        jobs.add(() -> coinbase(base));
        jobs.add(() -> kraken(base));
        jobs.add(() -> kucoin(base));
        jobs.add(() -> gate(base));
        jobs.add(() -> bitget(sym));
        Result r = new Result();
        try {
            List<Future<Venue>> fs = POOL.invokeAll(jobs, 20, TimeUnit.SECONDS);
            for (Future<Venue> f : fs) {
                try {
                    Venue v = f.get();
                    if (v != null) r.venues.add(v);
                } catch (Exception ignored) {
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        double sw = 0, s = 0;
        for (Venue v : r.venues) {
            double w = v.day ? 2 : 1;
            s += v.buyPct * w;
            sw += w;
            if (v.buyPct >= 52) r.bull++;
            else if (v.buyPct <= 48) r.bear++;
            if (v.buyUsd >= 0) r.netUsd += v.buyUsd - v.sellUsd;
        }
        if (sw > 0) r.buyPct = s / sw;
        int n = r.venues.size();
        if (n > 0) {
            double sc = Fmt.clamp((r.buyPct - 50) / 6.0, -1, 1) * 0.65 + Fmt.clamp((r.bull - r.bear) / (double) n, -1, 1) * 0.35;
            r.score = (int) Math.round(Fmt.clamp(sc, -1, 1) * 100);
        }
        return r;
    }

    // ---------------- 24h venues
    private static Venue binance(String sym, boolean fut) throws Exception {
        String url = fut ? "https://fapi.binance.com/fapi/v1/klines?symbol=" + sym + "&interval=1h&limit=25"
                : null;
        JSONArray a = new JSONArray(fut ? Scanner.getAbsolute(url) : Scanner.get("/api/v3/klines?symbol=" + sym + "&interval=1h&limit=25"));
        double q = 0, tb = 0;
        for (int i = 0; i < a.length() - 1; i++) {
            JSONArray k = a.getJSONArray(i);
            q += d(k.getString(7));
            tb += d(k.getString(10));
        }
        if (q <= 0) return null;
        return new Venue(fut ? "Binance Futures" : "Binance Spot", "24h", tb, q - tb, true, true);
    }

    private static Venue okx(String base, String type) throws Exception {
        JSONObject o = new JSONObject(Scanner.getAbsolute("https://www.okx.com/api/v5/rubik/stat/taker-volume?ccy=" + base
                + "&instType=" + type + "&period=1H"));
        JSONArray a = o.getJSONArray("data");
        double sell = 0, buy = 0;
        for (int i = 0; i < a.length() && i < 24; i++) {
            JSONArray r = a.getJSONArray(i);
            sell += d(r.getString(1));
            buy += d(r.getString(2));
        }
        if (buy + sell <= 0) return null;
        return new Venue(type.equals("SPOT") ? "OKX Spot" : "OKX Futures", "24h", buy, sell, false, true);
    }

    // ---------------- live-trade venues
    private static Venue bybit(String sym) throws Exception {
        JSONObject o = new JSONObject(Scanner.getAbsolute("https://api.bybit.com/v5/market/recent-trade?category=linear&symbol=" + sym + "&limit=1000"));
        JSONArray a = o.getJSONObject("result").getJSONArray("list");
        double b = 0, s = 0;
        long t0 = Long.MAX_VALUE, t1 = 0;
        for (int i = 0; i < a.length(); i++) {
            JSONObject t = a.getJSONObject(i);
            double usd = d(t.optString("price")) * d(t.optString("size"));
            if ("Buy".equalsIgnoreCase(t.optString("side"))) b += usd; else s += usd;
            long ts = (long) d(t.optString("time"));
            t0 = Math.min(t0, ts);
            t1 = Math.max(t1, ts);
        }
        if (b + s <= 0) return null;
        return new Venue("Bybit Futures", mins(t0, t1), b, s, true, false);
    }

    private static Venue coinbase(String base) throws Exception {
        String raw;
        try {
            raw = Scanner.getAbsolute("https://api.exchange.coinbase.com/products/" + base + "-USD/trades?limit=1000");
        } catch (Exception e) {
            raw = Scanner.getAbsolute("https://api.exchange.coinbase.com/products/" + base + "-USDT/trades?limit=1000");
        }
        JSONArray a = new JSONArray(raw);
        double b = 0, s = 0;
        for (int i = 0; i < a.length(); i++) {
            JSONObject t = a.getJSONObject(i);
            double usd = d(t.optString("price")) * d(t.optString("size"));
            // Coinbase "side" is the MAKER side: maker sell = taker BUY
            if ("sell".equals(t.optString("side"))) b += usd; else s += usd;
        }
        if (b + s <= 0) return null;
        String w = a.length() > 1 ? spanIso(a.getJSONObject(0).optString("time"), a.getJSONObject(a.length() - 1).optString("time")) : "-";
        return new Venue("Coinbase (USA)", w, b, s, true, false);
    }

    private static String spanIso(String a, String b) {
        try {
            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
            f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            return mins(f.parse(a.substring(0, 19)).getTime(), f.parse(b.substring(0, 19)).getTime());
        } catch (Exception e) {
            return "-";
        }
    }

    private static Venue kraken(String base) throws Exception {
        String k = base.equals("BTC") ? "XBT" : base.equals("DOGE") ? "XDG" : base;
        JSONObject o = new JSONObject(Scanner.getAbsolute("https://api.kraken.com/0/public/Trades?pair=" + k + "USD&count=1000"));
        JSONObject res = o.getJSONObject("result");
        JSONArray a = null;
        java.util.Iterator<String> it = res.keys();
        while (it.hasNext()) {
            String key = it.next();
            if (!key.equals("last")) { a = res.getJSONArray(key); break; }
        }
        if (a == null) return null;
        double b = 0, s = 0, t0 = Double.MAX_VALUE, t1 = 0;
        for (int i = 0; i < a.length(); i++) {
            JSONArray t = a.getJSONArray(i);
            double usd = d(t.getString(0)) * d(t.getString(1));
            if ("b".equals(t.getString(3))) b += usd; else s += usd;
            double ts = t.getDouble(2);
            t0 = Math.min(t0, ts);
            t1 = Math.max(t1, ts);
        }
        if (b + s <= 0) return null;
        return new Venue("Kraken (USA/EU)", mins((long) (t0 * 1000), (long) (t1 * 1000)), b, s, true, false);
    }

    private static Venue kucoin(String base) throws Exception {
        JSONObject o = new JSONObject(Scanner.getAbsolute("https://api.kucoin.com/api/v1/market/histories?symbol=" + base + "-USDT"));
        JSONArray a = o.getJSONArray("data");
        double b = 0, s = 0;
        long t0 = Long.MAX_VALUE, t1 = 0;
        for (int i = 0; i < a.length(); i++) {
            JSONObject t = a.getJSONObject(i);
            double usd = d(t.optString("price")) * d(t.optString("size"));
            if ("buy".equals(t.optString("side"))) b += usd; else s += usd;
            long ts = t.optLong("time") / 1_000_000L;
            t0 = Math.min(t0, ts);
            t1 = Math.max(t1, ts);
        }
        if (b + s <= 0) return null;
        return new Venue("KuCoin", mins(t0, t1), b, s, true, false);
    }

    private static Venue gate(String base) throws Exception {
        JSONArray a = new JSONArray(Scanner.getAbsolute("https://api.gateio.ws/api/v4/spot/trades?currency_pair=" + base + "_USDT&limit=1000"));
        double b = 0, s = 0, t0 = Double.MAX_VALUE, t1 = 0;
        for (int i = 0; i < a.length(); i++) {
            JSONObject t = a.getJSONObject(i);
            double usd = d(t.optString("price")) * d(t.optString("amount"));
            if ("buy".equals(t.optString("side"))) b += usd; else s += usd;
            double ts = d(t.optString("create_time_ms"));
            t0 = Math.min(t0, ts);
            t1 = Math.max(t1, ts);
        }
        if (b + s <= 0) return null;
        return new Venue("Gate.io", mins((long) t0, (long) t1), b, s, true, false);
    }

    private static Venue bitget(String sym) throws Exception {
        JSONObject o = new JSONObject(Scanner.getAbsolute("https://api.bitget.com/api/v2/spot/market/fills?symbol=" + sym + "&limit=500"));
        JSONArray a = o.getJSONArray("data");
        double b = 0, s = 0;
        long t0 = Long.MAX_VALUE, t1 = 0;
        for (int i = 0; i < a.length(); i++) {
            JSONObject t = a.getJSONObject(i);
            double usd = d(t.optString("price")) * d(t.optString("size"));
            if ("buy".equals(t.optString("side"))) b += usd; else s += usd;
            long ts = (long) d(t.optString("ts"));
            t0 = Math.min(t0, ts);
            t1 = Math.max(t1, ts);
        }
        if (b + s <= 0) return null;
        return new Venue("Bitget", mins(t0, t1), b, s, true, false);
    }
}
