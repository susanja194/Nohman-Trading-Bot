package com.signal.bot;

/** Two trading styles with their own timeframes, colours and risk rules. */
public final class Mode {
    private Mode() {}

    public static final int SCALP = 0, SPOT = 1;

    public static String label(int m) { return m == SCALP ? "⚡ SCALP" : "💎 SPOT"; }
    public static String desc(int m) {
        return m == SCALP ? "Jaldi trade · 1m / 5m / 15m charts · chhote target, tight stop"
                : "Lambi trade · 1h / 4h / 1d charts · bade target, wide stop";
    }

    /** Main accent colour. Scalp = electric violet, Spot = Binance gold. */
    public static int accent(int m) { return m == SCALP ? 0xFFA855F7 : 0xFFF0B90B; }
    /** Second accent. Scalp = neon cyan, Spot = emerald. */
    public static int accent2(int m) { return m == SCALP ? 0xFF22D3EE : 0xFF10B981; }
    public static int bgTop(int m) { return m == SCALP ? 0xFF0B0A1A : 0xFF0A0E14; }
    public static int bgBottom(int m) { return m == SCALP ? 0xFF140F2E : 0xFF0F1A16; }

    /** Timeframes used for the multi-timeframe technical score. */
    public static String[] tfs(int m) { return m == SCALP ? new String[]{"5m", "15m", "1h"} : new String[]{"1h", "4h", "1d"}; }
    public static int[] tfWeights(int m) { return m == SCALP ? new int[]{2, 3, 1} : new int[]{1, 3, 2}; }
    /** Timeframe for money flow and how many candles of it (= 4h scalp, 24h spot). */
    public static String flowTf(int m) { return m == SCALP ? "5m" : "1h"; }
    public static int flowCandles(int m) { return m == SCALP ? 48 : 24; }
    public static String flowSpan(int m) { return m == SCALP ? "4h" : "24h"; }
    /** Timeframe on which chart patterns / ATR / levels are measured. */
    public static String patternTf(int m) { return m == SCALP ? "15m" : "4h"; }
    public static double stopAtr(int m) { return m == SCALP ? 1.2 : 1.5; }
    /** Futures stats period. */
    public static String futPeriod(int m) { return m == SCALP ? "5m" : "1h"; }

    public static String[] chartTfs(int m) { return m == SCALP ? new String[]{"1m", "5m", "15m", "1h"} : new String[]{"1h", "4h", "1d", "1w"}; }
    public static String defaultChartTf(int m) { return m == SCALP ? "5m" : "4h"; }
    public static String[] scanTfs(int m) { return m == SCALP ? new String[]{"1m", "3m", "5m", "15m"} : new String[]{"30m", "1h", "4h", "1d"}; }
}
