package com.signal.bot;

import android.os.Handler;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Keeps a ChartView live with Binance WebSocket candles + whale trades (used inside the signal screen). */
public final class LiveChart {
    public interface OnPrice {
        void on(double price);
    }

    private final ChartView chart;
    private final Handler handler;
    private WsStream ws;
    private final Object lock = new Object();
    private double[] pk;
    private final List<double[]> trades = new ArrayList<>();
    private volatile boolean live;
    private double whaleThr = 50000;
    private OnPrice onPrice;
    private boolean running;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            apply();
            handler.postDelayed(this, 400);
        }
    };

    public LiveChart(ChartView chart, Handler handler) {
        this.chart = chart;
        this.handler = handler;
    }

    public void start(String sym, String tf, double whaleThr, OnPrice cb) {
        stop();
        this.whaleThr = whaleThr;
        this.onPrice = cb;
        running = true;
        String s = sym.toLowerCase(Locale.US);
        ws = new WsStream("/stream?streams=" + s + "@kline_" + tf + "/" + s + "@aggTrade", new WsStream.Callback() {
            @Override
            public void onText(String text) {
                try {
                    JSONObject o = new JSONObject(text);
                    JSONObject d = o.optJSONObject("data");
                    if (d == null) return;
                    if (o.optString("stream").contains("@kline")) {
                        JSONObject k = d.optJSONObject("k");
                        if (k == null) return;
                        double[] v = {k.optLong("t"), n(k, "o"), n(k, "h"), n(k, "l"), n(k, "c"), n(k, "v"), n(k, "q"), n(k, "V"), n(k, "Q"), k.optLong("n")};
                        synchronized (lock) { pk = v; }
                    } else {
                        double p = n(d, "p"), q = n(d, "q");
                        if (p * q >= LiveChart.this.whaleThr) {
                            synchronized (lock) {
                                if (trades.size() < 500) trades.add(new double[]{d.optLong("T"), p * q, d.optBoolean("m") ? 1 : 0});
                            }
                        }
                    }
                } catch (Exception ignored) {
                }
            }

            @Override
            public void onStatus(boolean l) { live = l; }
        }).start();
        handler.post(tick);
    }

    private static double n(JSONObject o, String k) {
        try { return Double.parseDouble(o.optString(k, "0")); } catch (Exception e) { return 0; }
    }

    private void apply() {
        double[] k;
        List<double[]> tr;
        synchronized (lock) {
            k = pk;
            pk = null;
            tr = new ArrayList<>(trades);
            trades.clear();
        }
        Candles cur = chart.getData();
        if (k != null && cur != null) {
            Candles nc = cur.live((long) k[0], k[1], k[2], k[3], k[4], k[5], k[6], k[7], k[8], k[9]);
            if (nc != null) chart.liveCandles(nc);
            if (onPrice != null) onPrice.on(k[4]);
        }
        for (double[] t : tr) chart.liveTrade((long) t[0], t[1], t[2] == 1);
        chart.setLiveText(live ? "● LIVE" : "○ connect ho raha hai...");
    }

    public void stop() {
        running = false;
        handler.removeCallbacks(tick);
        if (ws != null) ws.stop();
        ws = null;
    }
}
