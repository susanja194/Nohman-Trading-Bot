package com.signal.bot;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Scores BUY and SELL setups from closed candles. Pure Java.
 *
 * BUY  = trend + momentum + buyers' volume (volume aa raha).
 * SELL = money leaving the coin (volume nikal raha): sellers dominate volume / falling OBV,
 *        plus weakening trend.
 */
public final class Analyzer {

    public static final class Result {
        public int buyScore;
        public int sellScore;
        public boolean volumeOutflow;   // required for a SELL alert
        public double rsi;
        public double volRatio;
        public double buyRatio;         // share of last 3 candles' volume bought by takers (0..1)
        public double price;
        public double priceChange5;     // % change over last 5 closed candles
        public final List<String> buyReasons = new ArrayList<>();
        public final List<String> sellReasons = new ArrayList<>();
    }

    private Analyzer() {}

    /**
     * @param takerBuy taker-buy base volume per candle (Binance kline field 9)
     * @param volMult  how many times the 20-candle average volume counts as a "spike" (e.g. 2.0)
     * Arrays must contain only CLOSED candles, oldest first, at least 60 entries.
     */
    public static Result analyze(double[] open, double[] close, double[] vol, double[] takerBuy, double volMult) {
        Result r = new Result();
        int n = close.length;
        if (n < 60) return r;
        int i = n - 1;

        double[] e9 = Indicators.ema(close, 9);
        double[] e21 = Indicators.ema(close, 21);
        double[] e50 = Indicators.ema(close, 50);
        double[] rsi = Indicators.rsi(close, 14);
        double[] hist = Indicators.macdHist(close);
        double[] obv = Indicators.obv(close, vol);

        double volAvg = Indicators.mean(vol, i - 20, i);
        double volRatio = volAvg > 0 ? vol[i] / volAvg : 0;
        boolean green = close[i] > open[i];
        boolean red = close[i] < open[i];

        double tbLast = vol[i] > 0 ? takerBuy[i] / vol[i] : 0.5;
        double sv = 0, sb = 0;
        for (int j = i - 2; j <= i; j++) { sv += vol[j]; sb += takerBuy[j]; }
        double tb3 = sv > 0 ? sb / sv : 0.5;

        boolean crossUp = false, crossDown = false;
        for (int j = i; j >= i - 1; j--) {
            if (e9[j] > e21[j] && e9[j - 1] <= e21[j - 1]) crossUp = true;
            if (e9[j] < e21[j] && e9[j - 1] >= e21[j - 1]) crossDown = true;
        }

        r.rsi = rsi[i];
        r.volRatio = volRatio;
        r.buyRatio = tb3;
        r.price = close[i];
        r.priceChange5 = close[i - 5] > 0 ? (close[i] / close[i - 5] - 1) * 100 : 0;
        String rs = String.format(Locale.US, "%.0f", rsi[i]);
        String vr = String.format(Locale.US, "%.1fx", volRatio);
        String buyPct = String.format(Locale.US, "%.0f%%", tb3 * 100);
        String sellPct = String.format(Locale.US, "%.0f%%", (1 - tb3) * 100);

        // ---------- BUY (volume aa raha) ----------
        if (crossUp) { r.buyScore += 2; r.buyReasons.add("EMA 9/21 bullish crossover"); }
        if (close[i] > e50[i] && e21[i] > e50[i]) { r.buyScore += 1; r.buyReasons.add("Uptrend (price > EMA50)"); }
        if (rsi[i] >= 50 && rsi[i] <= 70) { r.buyScore += 1; r.buyReasons.add("RSI strong " + rs); }
        else if (rsi[i - 1] < 35 && rsi[i] > rsi[i - 1]) { r.buyScore += 2; r.buyReasons.add("RSI oversold bounce " + rs); }
        if (hist[i] > 0 && hist[i - 1] <= 0) { r.buyScore += 1; r.buyReasons.add("MACD bullish turn"); }
        if (volRatio >= volMult && green && tbLast >= 0.5) { r.buyScore += 2; r.buyReasons.add("Buy volume spike " + vr); }
        if (tb3 >= 0.58) { r.buyScore += 1; r.buyReasons.add("Buyers " + buyPct + " of volume (volume aa raha)"); }
        if (obv[i] > obv[i - 5] && close[i] > close[i - 5]) { r.buyScore += 1; r.buyReasons.add("OBV rising (paisa aa raha)"); }
        if (rsi[i] > 78) { r.buyScore -= 2; r.buyReasons.add("Warning: overbought RSI " + rs); }

        // ---------- SELL (volume nikal raha) ----------
        if (volRatio >= volMult && red) {
            r.sellScore += 2; r.volumeOutflow = true;
            r.sellReasons.add("Heavy SELL volume " + vr + " on red candle");
        }
        if (tb3 <= 0.42) {
            r.sellScore += 1; r.volumeOutflow = true;
            r.sellReasons.add("Sellers " + sellPct + " of volume (volume nikal raha)");
        }
        if (obv[i] < obv[i - 5] && close[i] < close[i - 5]) {
            r.sellScore += 1; r.volumeOutflow = true;
            r.sellReasons.add("OBV falling (paisa nikal raha)");
        }
        if (crossDown) { r.sellScore += 2; r.sellReasons.add("EMA 9/21 bearish crossover"); }
        if (rsi[i - 1] > 72 && rsi[i] < rsi[i - 1]) { r.sellScore += 1; r.sellReasons.add("RSI overbought reversing " + rs); }
        if (hist[i] < 0 && hist[i - 1] >= 0) { r.sellScore += 1; r.sellReasons.add("MACD bearish turn"); }
        if (close[i] < e50[i]) { r.sellScore += 1; r.sellReasons.add("Price below EMA50"); }

        return r;
    }

    /** True when the last closed close is above EMA50 (used for BTC market filter). */
    public static boolean isBullish(double[] close) {
        if (close.length < 50) return true;
        double[] e50 = Indicators.ema(close, 50);
        double[] e21 = Indicators.ema(close, 21);
        int i = close.length - 1;
        return close[i] > e50[i] || e21[i] > e50[i];
    }
}
