package com.signal.bot;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * WATCH-ONLY wallet tracker. Uses only the PUBLIC address and public block explorers:
 * nothing is signed, nothing is sent, no seed phrase / private key is ever needed or accepted.
 *   BTC: mempool.space · LTC/DOGE: Blockchair · ETH + tokens: Ethplorer · BNB Chain: public RPC (BNB + USDT)
 *   TRON: TronGrid (TRX + USDT TRC20) · Solana: public RPC (SOL + USDT/USDC)
 */
public final class WalletTracker {
    private WalletTracker() {}

    public static final String BTC = "BTC", EVM = "EVM", TRON = "TRON", SOL = "SOL", LTC = "LTC", DOGE = "DOGE";

    public static final class Holding {
        public final String asset, network;
        public final double amount, usd;

        Holding(String asset, String network, double amount, double usd) {
            this.asset = asset; this.network = network; this.amount = amount; this.usd = usd;
        }
    }

    public static final class Result {
        public String chain, address;
        public final List<Holding> holdings = new ArrayList<>();
        public final List<String> txs = new ArrayList<>();
        public double totalUsd;
        public String error;
        public String explorer;
    }

    private static final Pattern P_EVM = Pattern.compile("^0x[a-fA-F0-9]{40}$");
    private static final Pattern P_TRON = Pattern.compile("^T[1-9A-HJ-NP-Za-km-z]{33}$");
    private static final Pattern P_BTC = Pattern.compile("^([13][a-km-zA-HJ-NP-Z1-9]{25,34}|(bc1|BC1)[a-zA-Z0-9]{25,87})$");
    private static final Pattern P_LTC = Pattern.compile("^([LM][a-km-zA-HJ-NP-Z1-9]{26,33}|ltc1[a-z0-9]{25,87})$");
    private static final Pattern P_DOGE = Pattern.compile("^D[5-9A-HJ-NP-U][1-9A-HJ-NP-Za-km-z]{32}$");
    private static final Pattern P_SOL = Pattern.compile("^[1-9A-HJ-NP-Za-km-z]{32,44}$");

    /** Returns an error message if the text is a SECRET (seed phrase / private key) — such input is refused. */
    public static String securityCheck(String in) {
        String s = in == null ? "" : in.trim();
        if (s.split("\\s+").length >= 11) return "⛔ Yeh seed phrase (12/24 words) lagta hai! Isay KABHI kisi app mein na daalein. Sirf PUBLIC address chahiye.";
        if (s.matches("^(0x)?[a-fA-F0-9]{64}$")) return "⛔ Yeh PRIVATE KEY lagti hai! Isay kabhi share na karein. Sirf public address daalein.";
        if (s.startsWith("xprv") || s.startsWith("yprv") || s.startsWith("zprv")) return "⛔ Yeh private extended key hai — kabhi share na karein.";
        if (s.startsWith("xpub") || s.startsWith("ypub") || s.startsWith("zpub")) return "xpub abhi support nahi — wallet ka ek receive address daalein.";
        return null;
    }

    /** Detects the network from the address format, or null. */
    public static String detect(String a) {
        a = a.trim();
        if (P_EVM.matcher(a).matches()) return EVM;
        if (P_TRON.matcher(a).matches()) return TRON;
        if (P_BTC.matcher(a).matches()) return BTC;
        if (P_LTC.matcher(a).matches()) return LTC;
        if (P_DOGE.matcher(a).matches()) return DOGE;
        if (P_SOL.matcher(a).matches()) return SOL;
        return null;
    }

    public static String chainName(String c) {
        switch (c) {
            case BTC: return "Bitcoin";
            case EVM: return "Ethereum + BNB Chain";
            case TRON: return "TRON (TRC20)";
            case SOL: return "Solana";
            case LTC: return "Litecoin";
            case DOGE: return "Dogecoin";
            default: return c;
        }
    }

    // ---------------- prices (Binance)
    private static final Map<String, Object[]> PX = new HashMap<>();

    static double price(String asset) {
        String a = asset.toUpperCase(Locale.US);
        if (a.equals("USDT") || a.equals("USDC") || a.equals("BUSD") || a.equals("FDUSD") || a.equals("DAI")) return 1;
        if (a.equals("WETH")) a = "ETH";
        if (a.equals("WBTC") || a.equals("BTCB")) a = "BTC";
        if (a.equals("WBNB")) a = "BNB";
        synchronized (PX) {
            Object[] c = PX.get(a);
            if (c != null && System.currentTimeMillis() - (Long) c[0] < 60_000) return (Double) c[1];
        }
        try {
            double p = new JSONObject(Scanner.get("/api/v3/ticker/price?symbol=" + a + "USDT")).optDouble("price", 0);
            synchronized (PX) { PX.put(a, new Object[]{System.currentTimeMillis(), p}); }
            return p;
        } catch (Exception e) {
            return 0;
        }
    }

    public static Result fetch(String address) {
        Result r = new Result();
        r.address = address.trim();
        r.chain = detect(r.address);
        if (r.chain == null) {
            r.error = "Address pehchana nahi gaya";
            return r;
        }
        try {
            switch (r.chain) {
                case BTC: btc(r); break;
                case LTC: blockchair(r, "litecoin", "LTC"); break;
                case DOGE: blockchair(r, "dogecoin", "DOGE"); break;
                case EVM: evm(r); break;
                case TRON: tron(r); break;
                case SOL: sol(r); break;
                default: break;
            }
        } catch (Exception e) {
            r.error = e.getMessage();
        }
        for (Holding h : r.holdings) r.totalUsd += h.usd;
        return r;
    }

    private static void add(Result r, String asset, String net, double amt, double px) {
        if (amt <= 0) return;
        r.holdings.add(new Holding(asset, net, amt, amt * (px > 0 ? px : price(asset))));
    }

    // ---------------- Bitcoin
    private static void btc(Result r) throws Exception {
        String a = r.address;
        JSONObject o = new JSONObject(Scanner.getAbsolute("https://mempool.space/api/address/" + a));
        JSONObject cs = o.getJSONObject("chain_stats"), ms = o.optJSONObject("mempool_stats");
        long sats = cs.optLong("funded_txo_sum") - cs.optLong("spent_txo_sum");
        long pending = ms == null ? 0 : ms.optLong("funded_txo_sum") - ms.optLong("spent_txo_sum");
        add(r, "BTC", "Bitcoin", sats / 1e8, 0);
        if (pending != 0) r.txs.add(String.format(Locale.US, "⏳ Pending (unconfirmed): %+.8f BTC", pending / 1e8));
        r.explorer = "https://mempool.space/address/" + a;
        try {
            JSONArray txs = new JSONArray(Scanner.getAbsolute("https://mempool.space/api/address/" + a + "/txs"));
            SimpleDateFormat f = new SimpleDateFormat("dd MMM HH:mm", Locale.US);
            for (int i = 0; i < txs.length() && r.txs.size() < 8; i++) {
                JSONObject t = txs.getJSONObject(i);
                long net = 0;
                JSONArray vin = t.getJSONArray("vin"), vout = t.getJSONArray("vout");
                for (int k = 0; k < vout.length(); k++) {
                    JSONObject v = vout.getJSONObject(k);
                    if (a.equals(v.optString("scriptpubkey_address"))) net += v.optLong("value");
                }
                for (int k = 0; k < vin.length(); k++) {
                    JSONObject pv = vin.getJSONObject(k).optJSONObject("prevout");
                    if (pv != null && a.equals(pv.optString("scriptpubkey_address"))) net -= pv.optLong("value");
                }
                JSONObject st = t.optJSONObject("status");
                String when = st != null && st.optBoolean("confirmed") ? f.format(new Date(st.optLong("block_time") * 1000)) : "pending";
                r.txs.add(String.format(Locale.US, "%s  %s %.8f BTC", when, net >= 0 ? "🟢 aaya" : "🔴 gaya", Math.abs(net) / 1e8));
            }
        } catch (Exception ignored) {
        }
    }

    // ---------------- Litecoin / Dogecoin
    private static void blockchair(Result r, String chain, String sym) throws Exception {
        JSONObject o = new JSONObject(Scanner.getAbsolute("https://api.blockchair.com/" + chain + "/dashboards/address/" + r.address));
        JSONObject d = o.getJSONObject("data").getJSONObject(r.address).getJSONObject("address");
        add(r, sym, chainName(sym), d.optDouble("balance", 0) / 1e8, 0);
        r.txs.add("Kul transactions: " + d.optLong("transaction_count"));
        r.explorer = "https://blockchair.com/" + chain + "/address/" + r.address;
    }

    // ---------------- Ethereum (+ all ERC20 tokens) and BNB Chain
    private static void evm(Result r) throws Exception {
        String a = r.address;
        r.explorer = "https://etherscan.io/address/" + a;
        try {
            JSONObject o = new JSONObject(Scanner.getAbsolute("https://api.ethplorer.io/getAddressInfo/" + a + "?apiKey=freekey"));
            JSONObject eth = o.optJSONObject("ETH");
            if (eth != null) {
                JSONObject pr = eth.optJSONObject("price");
                add(r, "ETH", "Ethereum", eth.optDouble("balance", 0), pr != null ? pr.optDouble("rate", 0) : 0);
            }
            JSONArray tk = o.optJSONArray("tokens");
            if (tk != null) {
                for (int i = 0; i < tk.length(); i++) {
                    JSONObject t = tk.getJSONObject(i);
                    JSONObject ti = t.optJSONObject("tokenInfo");
                    if (ti == null) continue;
                    JSONObject pr = ti.optJSONObject("price");
                    if (pr == null) continue;   // skip unpriced / spam tokens
                    int dec = ti.optInt("decimals", 18);
                    String raw = t.optString("rawBalance", "");
                    double amt = raw.isEmpty() ? t.optDouble("balance", 0) / Math.pow(10, dec) : new BigDecimal(raw).movePointLeft(dec).doubleValue();
                    double rate = pr.optDouble("rate", 0);
                    if (amt * rate < 1) continue;
                    add(r, ti.optString("symbol"), "Ethereum", amt, rate);
                }
            }
        } catch (Exception e) {
            r.txs.add("Ethereum data abhi nahi mila (Ethplorer busy)");
        }
        // BNB Chain: native BNB + USDT (BEP20)
        try {
            String bal = rpc("https://bsc-dataseed.binance.org", "eth_getBalance", "[\"" + a + "\",\"latest\"]");
            add(r, "BNB", "BNB Chain", hexUnits(bal, 18), 0);
            String data = "0x70a08231000000000000000000000000" + a.substring(2).toLowerCase(Locale.US);
            String usdt = rpc("https://bsc-dataseed.binance.org", "eth_call",
                    "[{\"to\":\"0x55d398326f99059fF775485246999027B3197955\",\"data\":\"" + data + "\"},\"latest\"]");
            add(r, "USDT", "BNB Chain", hexUnits(usdt, 18), 1);
        } catch (Exception ignored) {
        }
        try {
            JSONObject h = new JSONObject(Scanner.getAbsolute("https://api.ethplorer.io/getAddressHistory/" + a + "?apiKey=freekey&type=transfer&limit=8"));
            JSONArray ops = h.getJSONArray("operations");
            SimpleDateFormat f = new SimpleDateFormat("dd MMM HH:mm", Locale.US);
            for (int i = 0; i < ops.length(); i++) {
                JSONObject op = ops.getJSONObject(i);
                JSONObject ti = op.optJSONObject("tokenInfo");
                if (ti == null || ti.optJSONObject("price") == null) continue;
                double amt = new BigDecimal(op.optString("value", "0")).movePointLeft(ti.optInt("decimals", 18)).doubleValue();
                boolean in = a.equalsIgnoreCase(op.optString("to"));
                r.txs.add(String.format(Locale.US, "%s  %s %s %s", f.format(new Date(op.optLong("timestamp") * 1000)),
                        in ? "🟢 aaya" : "🔴 gaya", Fmt.num(amt), ti.optString("symbol")));
            }
        } catch (Exception ignored) {
        }
    }

    // ---------------- TRON (TRX + USDT/USDC TRC20)
    private static void tron(Result r) throws Exception {
        r.explorer = "https://tronscan.org/#/address/" + r.address;
        JSONObject o = new JSONObject(Scanner.getAbsolute("https://api.trongrid.io/v1/accounts/" + r.address));
        JSONArray d = o.getJSONArray("data");
        if (d.length() == 0) {
            r.txs.add("Yeh address abhi active nahi (0 balance)");
            return;
        }
        JSONObject acc = d.getJSONObject(0);
        add(r, "TRX", "TRON", acc.optLong("balance") / 1e6, 0);
        JSONArray t20 = acc.optJSONArray("trc20");
        if (t20 != null) {
            for (int i = 0; i < t20.length(); i++) {
                JSONObject t = t20.getJSONObject(i);
                if (t.has("TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t")) add(r, "USDT", "TRON", d(t.optString("TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t")) / 1e6, 1);
                if (t.has("TEkxiTehnzSmSe2XqrBj4w32RUN966rdz8")) add(r, "USDC", "TRON", d(t.optString("TEkxiTehnzSmSe2XqrBj4w32RUN966rdz8")) / 1e6, 1);
            }
        }
    }

    // ---------------- Solana (SOL + USDC/USDT)
    private static void sol(Result r) throws Exception {
        String url = "https://api.mainnet-beta.solana.com";
        r.explorer = "https://solscan.io/account/" + r.address;
        JSONObject b = new JSONObject(post(url, "{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"getBalance\",\"params\":[\"" + r.address + "\"]}"));
        add(r, "SOL", "Solana", b.getJSONObject("result").optLong("value") / 1e9, 0);
        try {
            JSONObject t = new JSONObject(post(url, "{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"getTokenAccountsByOwner\",\"params\":[\""
                    + r.address + "\",{\"programId\":\"TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA\"},{\"encoding\":\"jsonParsed\"}]}"));
            JSONArray v = t.getJSONObject("result").getJSONArray("value");
            for (int i = 0; i < v.length(); i++) {
                JSONObject info = v.getJSONObject(i).getJSONObject("account").getJSONObject("data").getJSONObject("parsed").getJSONObject("info");
                String mint = info.optString("mint");
                double amt = info.getJSONObject("tokenAmount").optDouble("uiAmount", 0);
                if (mint.equals("EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v")) add(r, "USDC", "Solana", amt, 1);
                else if (mint.equals("Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB")) add(r, "USDT", "Solana", amt, 1);
            }
        } catch (Exception ignored) {
        }
    }

    // ---------------- helpers
    private static double d(String s) {
        try { return Double.parseDouble(s); } catch (Exception e) { return 0; }
    }

    static double hexUnits(String hex, int decimals) {
        if (hex == null || hex.length() <= 2) return 0;
        return new BigDecimal(new BigInteger(hex.substring(2), 16)).movePointLeft(decimals).doubleValue();
    }

    private static String rpc(String url, String method, String params) throws Exception {
        JSONObject o = new JSONObject(post(url, "{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"" + method + "\",\"params\":" + params + "}"));
        return o.optString("result", "0x0");
    }

    static String post(String url, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("User-Agent", "NohmanTradingBot/8.0");
            try (OutputStream os = c.getOutputStream()) {
                os.write(body.getBytes("UTF-8"));
            }
            if (c.getResponseCode() != 200) throw new Exception("HTTP " + c.getResponseCode());
            StringBuilder sb = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
                String l;
                while ((l = br.readLine()) != null) sb.append(l);
            }
            return sb.toString();
        } finally {
            c.disconnect();
        }
    }

    /** Short address for display: 0x5be9…7dBB */
    public static String shortAddr(String a) {
        return a.length() <= 14 ? a : a.substring(0, 6) + "…" + a.substring(a.length() - 4);
    }
}
