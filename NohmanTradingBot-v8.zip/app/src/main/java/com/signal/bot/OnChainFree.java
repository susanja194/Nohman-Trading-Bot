package com.signal.bot;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Free on-chain / money-flow data (no API keys):
 *  - DefiLlama: total stablecoin supply (new dollars entering crypto), chain TVL and chain stablecoins
 *  - Blockchain.com: Bitcoin on-chain transaction volume
 *  - Coinbase premium: price on Coinbase vs Binance (US buyer demand)
 *  - Coin Metrics community API: exchange inflow / outflow (when available for the coin)
 * Results are cached for 30 minutes.
 */
public final class OnChainFree {
    private OnChainFree() {}

    private static final Map<String, Object[]> CACHE = new HashMap<>();

    private static String get(String url) throws Exception {
        synchronized (CACHE) {
            Object[] c = CACHE.get(url);
            if (c != null && System.currentTimeMillis() - (Long) c[0] < 30 * 60_000L) return (String) c[1];
        }
        String s = Scanner.getAbsolute(url);
        synchronized (CACHE) {
            CACHE.put(url, new Object[]{System.currentTimeMillis(), s});
        }
        return s;
    }

    static final Map<String, String> CHAINS = new HashMap<>();
    static {
        String[][] m = {{"ETH", "Ethereum"}, {"SOL", "Solana"}, {"BNB", "BSC"}, {"AVAX", "Avalanche"}, {"SUI", "Sui"},
                {"APT", "Aptos"}, {"TRX", "Tron"}, {"ARB", "Arbitrum"}, {"OP", "OP Mainnet"}, {"POL", "Polygon"},
                {"MATIC", "Polygon"}, {"NEAR", "Near"}, {"TON", "TON"}, {"SEI", "Sei"}, {"INJ", "Injective"},
                {"ADA", "Cardano"}, {"HYPE", "Hyperliquid L1"}, {"S", "Sonic"}, {"BERA", "Berachain"}, {"MNT", "Mantle"},
                {"TIA", "Celestia"}, {"ALGO", "Algorand"}, {"FTM", "Fantom"}, {"CRO", "Cronos"}, {"KAS", "Kaspa"},
                {"XRP", "XRPL"}, {"HBAR", "Hedera"}, {"STX", "Stacks"}, {"ICP", "ICP"}, {"DOT", "Polkadot"}};
        for (String[] p : m) CHAINS.put(p[0], p[1]);
    }

    /** {latest, 7d %, 30d %} of all stablecoins (USD). */
    public static double[] stablecoins() {
        try {
            JSONArray a = new JSONArray(get("https://stablecoins.llama.fi/stablecoincharts/all"));
            return changes(a, "totalCirculatingUSD");
        } catch (Exception e) {
            return null;
        }
    }

    /** {latest, 7d %, 30d %} of stablecoins on one chain. */
    public static double[] chainStables(String chain) {
        try {
            JSONArray a = new JSONArray(get("https://stablecoins.llama.fi/stablecoincharts/" + chain.replace(" ", "%20")));
            return changes(a, "totalCirculatingUSD");
        } catch (Exception e) {
            return null;
        }
    }

    private static double[] changes(JSONArray a, String key) throws Exception {
        int n = a.length();
        if (n < 31) return null;
        double now = pegged(a.getJSONObject(n - 1), key), w = pegged(a.getJSONObject(n - 8), key), m = pegged(a.getJSONObject(n - 31), key);
        if (now <= 0 || w <= 0 || m <= 0) return null;
        return new double[]{now, (now / w - 1) * 100, (now / m - 1) * 100};
    }

    private static double pegged(JSONObject o, String key) {
        JSONObject t = o.optJSONObject(key);
        return t == null ? 0 : t.optDouble("peggedUSD", 0);
    }

    /** {latest TVL, 7d %, 30d %} */
    public static double[] chainTvl(String chain) {
        try {
            JSONArray a = new JSONArray(get("https://api.llama.fi/v2/historicalChainTvl/" + chain.replace(" ", "%20")));
            int n = a.length();
            if (n < 31) return null;
            double now = a.getJSONObject(n - 1).optDouble("tvl", 0), w = a.getJSONObject(n - 8).optDouble("tvl", 0),
                    m = a.getJSONObject(n - 31).optDouble("tvl", 0);
            if (now <= 0 || w <= 0 || m <= 0) return null;
            return new double[]{now, (now / w - 1) * 100, (now / m - 1) * 100};
        } catch (Exception e) {
            return null;
        }
    }

    /** Bitcoin on-chain USD volume: {last 7d avg, % vs previous 7d}. */
    public static double[] btcChainVolume() {
        try {
            JSONObject o = new JSONObject(get("https://api.blockchain.info/charts/estimated-transaction-volume-usd?timespan=15days&format=json"));
            JSONArray v = o.getJSONArray("values");
            int n = v.length();
            if (n < 14) return null;
            double a = 0, b = 0;
            for (int i = n - 7; i < n; i++) a += v.getJSONObject(i).optDouble("y", 0);
            for (int i = n - 14; i < n - 7; i++) b += v.getJSONObject(i).optDouble("y", 0);
            if (b <= 0) return null;
            return new double[]{a / 7, (a / b - 1) * 100};
        } catch (Exception e) {
            return null;
        }
    }

    /** Coinbase price premium vs Binance in % (positive = US buyers paying more). NaN if not listed. */
    public static double coinbasePremium(String base, double binancePrice) {
        if (binancePrice <= 0) return Double.NaN;
        try {
            JSONObject o = new JSONObject(Scanner.getAbsolute("https://api.exchange.coinbase.com/products/" + base + "-USD/ticker"));
            double p = o.optDouble("price", 0);
            if (p <= 0) return Double.NaN;
            return (p / binancePrice - 1) * 100;
        } catch (Exception e) {
            return Double.NaN;
        }
    }

    /** Exchange net flow in USD over 7 days from Coin Metrics community API: {netflow7d, inflow7d, outflow7d} or null. */
    public static double[] exchangeFlow(String base) {
        try {
            JSONObject o = new JSONObject(get("https://community-api.coinmetrics.io/v4/timeseries/asset-metrics?assets="
                    + base.toLowerCase(Locale.US) + "&metrics=FlowInExUSD,FlowOutExUSD&frequency=1d&page_size=7&paging_from=end"));
            JSONArray a = o.getJSONArray("data");
            if (a.length() == 0) return null;
            double in = 0, out = 0;
            for (int i = 0; i < a.length(); i++) {
                JSONObject r = a.getJSONObject(i);
                in += r.optDouble("FlowInExUSD", 0);
                out += r.optDouble("FlowOutExUSD", 0);
            }
            if (in <= 0 && out <= 0) return null;
            return new double[]{in - out, in, out};
        } catch (Exception e) {
            return null;
        }
    }
}
