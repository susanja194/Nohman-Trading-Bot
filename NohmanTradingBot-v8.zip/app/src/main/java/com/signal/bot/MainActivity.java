package com.signal.bot;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    static final int CARD = 0xFF141B2B, CHIP = 0xFF1C2638, STROKE = 0xFF263352,
            TEXT = 0xFFE8EAED, SOFT = 0xFFC9D1DC, MUTED = 0xFF8B95A7,
            GREEN = 0xFF0ECB81, RED = 0xFFF6465D, YELLOW = 0xFFFFC94D, INK = 0xFF0A0E17, CLAUDE = 0xFFD97757;

    private int uiMode;
    private int ACC, ACC2;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private final View[] pages = new View[7];
    private final TextView[] tabs = new TextView[7];
    static final int TAB_MARKET = 0, TAB_ANALYZE = 1, TAB_SIGNALS = 2, TAB_WALLET = 3, TAB_BIG = 4, TAB_LISTINGS = 5, TAB_SETTINGS = 6;

    // Wallet tracker
    private LinearLayout walletList;
    private TextView walletTotal, walletNet;
    private EditText walLabelEt, walAddrEt;
    private long walletsLoadedAt;

    // Big players
    private LinearLayout bigBox, bigMovesBox;
    private TextView bigStatus;
    private long bigLoadedAt;
    private final TextView[] bigMinChips = new TextView[5];
    private static final long[] BIG_MINS = {10_000_000L, 50_000_000L, 100_000_000L, 500_000_000L, 1_000_000_000L};

    // Settings extras
    private EditText minConfEt, quietFromEt, quietToEt;
    private CheckBox quietCb;

    // Listings
    private LinearLayout listingBox;
    private TextView listingStatus;
    private long listingsLoadedAt;

    // Signal screen (live chart for one signal)
    private LinearLayout sigOverlay;
    private LiveChart sigLive;
    private int currentTab = -1;
    private TextView liveDot;
    private FrameLayout rootFrame;
    private boolean resumed;

    // in-app update
    private LinearLayout updateBanner;
    private TextView updStatus;
    private EditText repoEt;
    private volatile boolean installing;

    // Market
    private GaugeView fgGauge;
    private TextView btcView, globalView, marketCount;
    private EditText marketSearch;
    private LinearLayout marketList;
    private final TextView[] modeChips = new TextView[5];
    private int marketMode = 0, marketLimit = 50;
    private final Map<String, double[]> mk = new HashMap<>();          // sym -> {last, open, quoteVol}
    private final Map<String, TextView[]> rowViews = new HashMap<>();  // sym -> {price, pct}
    private WsStream marketWs;
    private final Map<String, double[]> pendingMini = new HashMap<>();
    private long marketLoadedAt;

    // Analyze
    private EditText searchEt;
    private TextView starBtn, chartTitle, livePrice;
    private String[] chartTfs;
    private TextView[] tfChips;
    private String chartTf;
    private String currentSym = "BTCUSDT";
    private ChartView chart;
    private BookView book;
    private TapeView tape;
    private LinearLayout watchRow, resultBox, fsOverlay;
    private ViewGroup chartParent;
    private int chartIndex;
    private ViewGroup.LayoutParams chartLp;
    private static final String[] LAYERS = {"Fib", "Lines", "Zones", "VolProfile", "Whales", "RSI"};
    private final TextView[] layerChips = new TextView[LAYERS.length];
    private CoinReport lastReport;

    // live coin stream
    private WsStream coinWs;
    private final Object liveLock = new Object();
    private double[] pendingKline;
    private final List<double[]> pendingTrades = new ArrayList<>();
    private double[][] pendingBids, pendingAsks;
    private boolean candleClosed;
    private volatile boolean coinLive;
    private String liveSym = "", liveTf = "";
    private double chartWhaleThr = 50000;
    private double dayOpen;

    // Signals
    private TextView statusView, statsView;
    private Button scalpBtn, spotBtn;
    private LinearLayout signalList, alertList;
    private String signalKey = "";

    // Settings
    private final EditText[][] modeFields = new EditText[2][];
    private final Spinner[] tfSpinners = new Spinner[2];
    private CheckBox btcCb, smartCb, strongCb;
    private EditText whaleEt, glassEt, claudeEt;
    private Spinner modelSpinner;

    private final Runnable refresher = new Runnable() {
        @Override
        public void run() {
            refreshStatus();
            handler.postDelayed(this, 5000);
        }
    };

    private final Runnable liveTick = new Runnable() {
        @Override
        public void run() {
            applyLive();
            applyMarketLive();
            handler.postDelayed(this, 400);
        }
    };

    // ============================================================ lifecycle
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        uiMode = Prefs.uiMode(this);
        ACC = Mode.accent(uiMode);
        ACC2 = Mode.accent2(uiMode);
        chartTfs = Mode.chartTfs(uiMode);
        chartTf = Mode.defaultChartTf(uiMode);
        tfChips = new TextView[chartTfs.length];
        ScannerService.createChannels(this);
        getWindow().setStatusBarColor(Mode.bgTop(uiMode));
        getWindow().setNavigationBarColor(CARD);
        currentSym = Prefs.lastCoin(this);

        rootFrame = new FrameLayout(this);
        LinearLayout root = column();
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Mode.bgTop(uiMode), Mode.bgBottom(uiMode)}));
        root.addView(header());
        FrameLayout content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));
        buildMarket();
        buildAnalyze();
        buildSignals();
        buildWallet();
        buildBig();
        buildListings();
        buildSettings();
        for (View p : pages) content.addView(p, new FrameLayout.LayoutParams(-1, -1));
        root.addView(bottomNav());
        rootFrame.addView(root, new FrameLayout.LayoutParams(-1, -1));
        setContentView(rootFrame);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        int startTab = savedInstanceState != null ? savedInstanceState.getInt("tab", 0) : 0;
        if (!handleIntent(getIntent())) showTab(startTab);
        loadChart();
        if (System.currentTimeMillis() - Prefs.lastUpdateCheck(this) > 3 * 3600_000L) checkForUpdate(false);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt("tab", currentTab);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private boolean handleIntent(Intent i) {
        if (i == null) return false;
        int tabX = i.getIntExtra("tab", -1);
        if (tabX >= 0 && tabX < pages.length) {
            i.removeExtra("tab");
            showTab(tabX);
            return true;
        }
        if (i.getBooleanExtra("update", false)) {
            i.removeExtra("update");
            showTab(TAB_SETTINGS);
            checkForUpdate(true);
            return true;
        }
        String coin = i.getStringExtra("coin");
        if (coin == null || coin.isEmpty()) return false;
        i.removeExtra("coin");
        openAnalyze(coin);
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        handler.post(refresher);
        handler.post(liveTick);
        if (chart.getData() != null) startCoinFeed();
        if (currentTab == 0) startMarketFeed();
        if (sigOverlay != null && sigOverlay.getTag() instanceof JSONObject) openSignalView((JSONObject) sigOverlay.getTag());
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumed = false;
        handler.removeCallbacks(refresher);
        handler.removeCallbacks(liveTick);
        stopCoinFeed();
        stopMarketFeed();
        if (sigLive != null) sigLive.stop();
    }

    @Override
    protected void onDestroy() {
        stopCoinFeed();
        stopMarketFeed();
        pool.shutdownNow();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (sigOverlay != null) closeSignalView();
        else if (fsOverlay != null) closeFullscreen();
        else if (currentTab != 0) showTab(0);
        else super.onBackPressed();
    }

    private void switchMode(int m) {
        if (m == uiMode) return;
        Prefs.setUiMode(this, m);
        recreate();
    }

    // ============================================================ ui helpers
    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable round(int color, float radiusDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) g.setStroke(dp(1), strokeColor);
        return g;
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setPadding(0, dp(2), 0, dp(2));
        return t;
    }

    private TextView bold(String s, float sp, int color) {
        TextView t = text(s, sp, color);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private LinearLayout card(LinearLayout parent) {
        return card(parent, STROKE);
    }

    private LinearLayout card(LinearLayout parent, int border) {
        LinearLayout c = column();
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        c.setBackground(round(CARD, 18, border));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        parent.addView(c, lp);
        return c;
    }

    private LinearLayout pageColumn(int idx) {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout col = column();
        col.setPadding(dp(12), 0, dp(12), dp(28));
        sv.addView(col);
        pages[idx] = sv;
        return col;
    }

    private TextView chip(String s, boolean on) {
        TextView t = bold(s, 13, TEXT);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(13), dp(8), dp(13), dp(8));
        styleChip(t, on);
        return t;
    }

    private void styleChip(TextView t, boolean on) {
        t.setTextColor(on ? INK : TEXT);
        t.setBackground(round(on ? ACC : CHIP, 20, on ? ACC : STROKE));
    }

    private LinearLayout.LayoutParams chipLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dp(8);
        return lp;
    }

    private HorizontalScrollView hscroll(LinearLayout inner) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(inner);
        return hs;
    }

    private Button button(String s, int bg, int fg, int stroke) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(fg);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(round(bg, 14, stroke));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(50));
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    private View bar(double leftPct, int leftColor, int rightColor) {
        LinearLayout b = row();
        b.setBackground(round(rightColor, 6, 0));
        float l = (float) Math.max(0, Math.min(100, leftPct));
        View a = new View(this);
        a.setBackground(round(leftColor, 6, 0));
        b.addView(a, new LinearLayout.LayoutParams(0, -1, l));
        b.addView(new View(this), new LinearLayout.LayoutParams(0, -1, 100 - l));
        return b;
    }

    private View divider() {
        View d = new View(this);
        d.setBackgroundColor(STROKE);
        d.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1)));
        return d;
    }

    private EditText input(String hint, String value, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(MUTED);
        e.setTextColor(TEXT);
        e.setSingleLine(true);
        e.setInputType(type);
        e.setText(value);
        return e;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void openUrl(String url) {
        if (url == null || url.isEmpty()) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            toast("Link nahi khula");
        }
    }

    private static String base(String sym) {
        return sym.endsWith("USDT") ? sym.substring(0, sym.length() - 4) : sym;
    }

    private static double parse(EditText e, double def) {
        try {
            return Double.parseDouble(e.getText().toString().trim().replace(",", ""));
        } catch (Exception x) {
            return def;
        }
    }

    private static double num(JSONObject o, String k) {
        try {
            return Double.parseDouble(o.optString(k, "0"));
        } catch (Exception e) {
            return 0;
        }
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null && getCurrentFocus() != null) imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        } catch (Exception ignored) {
        }
    }

    // ============================================================ frame
    private View header() {
        LinearLayout h = row();
        h.setPadding(dp(16), dp(14), dp(16), dp(6));
        TextView a = bold("NOHMAN", 19, ACC);
        a.setLetterSpacing(0.08f);
        TextView b = bold(" TRADING BOT", 19, ACC2);
        b.setLetterSpacing(0.08f);
        h.addView(a);
        h.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
        TextView mode = bold(Mode.label(uiMode), 11, INK);
        mode.setPadding(dp(9), dp(4), dp(9), dp(4));
        mode.setBackground(round(ACC, 12, 0));
        mode.setOnClickListener(v -> switchMode(uiMode == Mode.SCALP ? Mode.SPOT : Mode.SCALP));
        h.addView(mode);
        liveDot = bold("○ OFF", 11, MUTED);
        liveDot.setPadding(dp(9), dp(4), dp(9), dp(4));
        liveDot.setBackground(round(CHIP, 12, STROKE));
        liveDot.setOnClickListener(v -> showTab(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = dp(6);
        h.addView(liveDot, lp);
        return h;
    }

    private View bottomNav() {
        LinearLayout nav = row();
        nav.setBackground(round(CARD, 0, STROKE));
        nav.setPadding(0, dp(6), 0, dp(6));
        String[] labels = {"📊\nMarket", "🔍\nAnalyze", "🔔\nSignals", "💼\nWallet", "🐋\nBade log", "🆕\nListing", "⚙️\nSettings"};
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            TextView t = text(labels[i], 10, MUTED);
            t.setGravity(Gravity.CENTER);
            t.setOnClickListener(v -> showTab(idx));
            tabs[i] = t;
            nav.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        }
        return nav;
    }

    private void showTab(int i) {
        currentTab = i;
        for (int k = 0; k < pages.length; k++) {
            pages[k].setVisibility(k == i ? View.VISIBLE : View.GONE);
            tabs[k].setTextColor(k == i ? ACC : MUTED);
            tabs[k].setTypeface(k == i ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        }
        if (i == 0) {
            if (mk.isEmpty() || System.currentTimeMillis() - marketLoadedAt > 10 * 60_000) loadMarket();
            if (resumed) startMarketFeed();
        } else {
            stopMarketFeed();
        }
        if (i == 2) {
            renderSignals(true);
            renderAlerts();
        }
        if (i == TAB_LISTINGS && System.currentTimeMillis() - listingsLoadedAt > 10 * 60_000L) loadListings();
        if (i == TAB_WALLET && System.currentTimeMillis() - walletsLoadedAt > 2 * 60_000L) loadWallets();
        if (i == TAB_BIG) {
            renderBigMoves();
            if (System.currentTimeMillis() - bigLoadedAt > 15 * 60_000L) loadBig();
        }
        refreshStatus();
    }

    // ============================================================ MARKET tab
    private void buildMarket() {
        LinearLayout col = pageColumn(0);
        updateBanner = card(col, GREEN);
        updateBanner.setVisibility(View.GONE);
        LinearLayout top = card(col);
        LinearLayout tr = row();
        tr.addView(bold("Market Overview", 18, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView rf = chip("↻ Refresh", false);
        rf.setOnClickListener(v -> loadMarket());
        tr.addView(rf);
        top.addView(tr);
        fgGauge = new GaugeView(this);
        fgGauge.set(-1, "Fear & Greed", "load ho raha hai...");
        top.addView(fgGauge, new LinearLayout.LayoutParams(-1, dp(170)));
        btcView = bold("BTC —", 16, TEXT);
        top.addView(btcView);
        globalView = text("", 13, MUTED);
        top.addView(globalView);

        LinearLayout lc = card(col);
        marketSearch = input("🔎 Coin search karein (jaise PEPE, SUI, WIF)", "",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        marketSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) {
                marketLimit = 50;
                renderMarket();
            }
        });
        lc.addView(marketSearch);
        LinearLayout modes = row();
        String[] names = {"🚀 Gainers", "📉 Losers", "🔥 Volume", "🔤 A–Z", "⭐ Watchlist"};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            modeChips[i] = chip(names[i], i == marketMode);
            modeChips[i].setOnClickListener(v -> {
                marketMode = idx;
                marketLimit = 50;
                for (int k = 0; k < names.length; k++) styleChip(modeChips[k], k == marketMode);
                renderMarket();
            });
            modes.addView(modeChips[i], chipLp());
        }
        lc.addView(hscroll(modes));
        marketCount = text("", 12, MUTED);
        lc.addView(marketCount);
        marketList = column();
        lc.addView(marketList);
    }

    private void loadMarket() {
        btcView.setText("Load ho raha hai...");
        btcView.setTextColor(TEXT);
        pool.execute(() -> {
            try {
                final JSONArray tick = new JSONArray(Scanner.get("/api/v3/ticker/24hr?type=MINI"));
                final String[] fg = SmartMoney.fearGreed();
                final JSONObject global = fetchGlobal();
                runOnUiThread(() -> {
                    mk.clear();
                    for (int i = 0; i < tick.length(); i++) {
                        JSONObject o = tick.optJSONObject(i);
                        if (o == null) continue;
                        String s = o.optString("symbol");
                        if (!Scanner.isTradable(s) || o.optDouble("lastPrice", 0) <= 0) continue;
                        mk.put(s, new double[]{o.optDouble("lastPrice", 0), o.optDouble("openPrice", 0), o.optDouble("quoteVolume", 0)});
                    }
                    marketLoadedAt = System.currentTimeMillis();
                    renderOverview(fg, global);
                    renderMarket();
                });
            } catch (Exception e) {
                final String msg = e.getMessage();
                runOnUiThread(() -> btcView.setText("Market load nahi hua: " + msg + "\nInternet check karke Refresh dabayen"));
            }
        });
    }

    private static JSONObject fetchGlobal() {
        try {
            return new JSONObject(Scanner.getAbsolute("https://api.coingecko.com/api/v3/global")).getJSONObject("data");
        } catch (Exception e) {
            return null;
        }
    }

    private static double change(double[] v) {
        return v[1] > 0 ? (v[0] / v[1] - 1) * 100 : 0;
    }

    private void renderOverview(String[] fg, JSONObject g) {
        if (fg != null) {
            int v = -1;
            try { v = Integer.parseInt(fg[0]); } catch (Exception ignored) { }
            fgGauge.set(v, fg[1], "Fear & Greed Index (poori market ka mood)");
        } else {
            fgGauge.set(-1, "Fear & Greed", "data nahi mila");
        }
        updateBtcLine();
        if (g != null) {
            StringBuilder s = new StringBuilder();
            JSONObject tm = g.optJSONObject("total_market_cap");
            if (tm != null) s.append("Total market cap: ").append(Fmt.usd(tm.optDouble("usd", 0)));
            s.append(String.format(Locale.US, " (%+.2f%% 24h)", g.optDouble("market_cap_change_percentage_24h_usd", 0)));
            JSONObject mcp = g.optJSONObject("market_cap_percentage");
            if (mcp != null) s.append(String.format(Locale.US, "\nBTC dominance: %.1f%% · ETH: %.1f%%",
                    mcp.optDouble("btc", 0), mcp.optDouble("eth", 0)));
            globalView.setText(s.toString());
        } else {
            globalView.setText("CoinGecko global data abhi nahi mila");
        }
    }

    private void updateBtcLine() {
        double[] btc = mk.get("BTCUSDT");
        if (btc == null) return;
        double ch = change(btc);
        btcView.setText("₿ BTC  $" + Fmt.price(btc[0]) + "   " + Fmt.pct(ch) + " (24h)  ● live");
        btcView.setTextColor(ch >= 0 ? GREEN : RED);
    }

    private void renderMarket() {
        marketList.removeAllViews();
        rowViews.clear();
        if (mk.isEmpty()) return;
        String q = marketSearch.getText().toString().trim().toUpperCase(Locale.US).replace("/", "").replace("USDT", "");
        List<String> list = new ArrayList<>();
        if (marketMode == 4) {
            for (String s : Prefs.watchlist(this)) if (mk.containsKey(s)) list.add(s);
        } else {
            for (Map.Entry<String, double[]> e : mk.entrySet()) {
                String s = e.getKey();
                if (!q.isEmpty()) {
                    if (!base(s).contains(q)) continue;
                } else if (marketMode != 3 && e.getValue()[2] < 1_000_000) continue;
                list.add(s);
            }
            if (marketMode == 0) Collections.sort(list, (a, b) -> Double.compare(change(mk.get(b)), change(mk.get(a))));
            else if (marketMode == 1) Collections.sort(list, (a, b) -> Double.compare(change(mk.get(a)), change(mk.get(b))));
            else if (marketMode == 2) Collections.sort(list, (a, b) -> Double.compare(mk.get(b)[2], mk.get(a)[2]));
            else Collections.sort(list);
            if (!q.isEmpty()) {
                // exact match first
                final String qq = q;
                Collections.sort(list, (a, b) -> Boolean.compare(!base(a).equals(qq), !base(b).equals(qq)));
            }
        }
        marketCount.setText(list.size() + " coins Binance par" + (q.isEmpty() ? "" : " · search: " + q)
                + " · prices live update hoti hain");
        if (list.isEmpty()) {
            marketList.addView(text(marketMode == 4 ? "Watchlist khali hai — Analyze tab mein ☆ dabayen" : "Koi coin nahi mila", 13, MUTED));
            return;
        }
        for (int i = 0; i < list.size() && i < marketLimit; i++) marketList.addView(coinRow(list.get(i), i + 1));
        if (list.size() > marketLimit) {
            TextView more = chip("⬇ Aur coins dikhayen (" + (list.size() - marketLimit) + " baqi)", false);
            more.setOnClickListener(v -> {
                marketLimit += 50;
                renderMarket();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(10);
            marketList.addView(more, lp);
        }
    }

    private View coinRow(final String sym, int rank) {
        double[] v = mk.get(sym);
        double ch = change(v);
        LinearLayout r = row();
        r.setPadding(0, dp(10), 0, dp(10));
        r.addView(text(String.valueOf(rank), 12, MUTED), new LinearLayout.LayoutParams(dp(30), -2));
        LinearLayout nm = column();
        nm.addView(bold(base(sym), 15, TEXT));
        nm.addView(text("Vol " + Fmt.usd(v[2]), 11, MUTED));
        r.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
        TextView pr = text("$" + Fmt.price(v[0]), 14, TEXT);
        pr.setPadding(dp(6), dp(3), dp(6), dp(3));
        r.addView(pr);
        TextView pc = bold(Fmt.pct(ch), 13, 0xFFFFFFFF);
        pc.setGravity(Gravity.CENTER);
        pc.setPadding(dp(6), dp(5), dp(6), dp(5));
        pc.setBackground(round(ch >= 0 ? GREEN : RED, 8, 0));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(dp(84), -2);
        plp.leftMargin = dp(4);
        r.addView(pc, plp);
        r.setOnClickListener(x -> openAnalyze(sym));
        rowViews.put(sym, new TextView[]{pr, pc});
        LinearLayout wrap = column();
        wrap.addView(r);
        wrap.addView(divider());
        return wrap;
    }

    private void startMarketFeed() {
        if (marketWs != null) return;
        marketWs = new WsStream("/ws/!miniTicker@arr", new WsStream.Callback() {
            @Override
            public void onText(String text) {
                try {
                    JSONArray a = new JSONArray(text);
                    synchronized (pendingMini) {
                        for (int i = 0; i < a.length(); i++) {
                            JSONObject o = a.getJSONObject(i);
                            String s = o.optString("s");
                            if (!s.endsWith("USDT")) continue;
                            pendingMini.put(s, new double[]{num(o, "c"), num(o, "o"), num(o, "q")});
                        }
                    }
                } catch (Exception ignored) {
                }
            }

            @Override
            public void onStatus(boolean live) { }
        }).start();
    }

    private void stopMarketFeed() {
        if (marketWs != null) marketWs.stop();
        marketWs = null;
    }

    /** Pushes live mini-ticker prices into the market list (flash green/red on change). */
    private void applyMarketLive() {
        Map<String, double[]> upd;
        synchronized (pendingMini) {
            if (pendingMini.isEmpty()) return;
            upd = new HashMap<>(pendingMini);
            pendingMini.clear();
        }
        for (Map.Entry<String, double[]> e : upd.entrySet()) {
            String s = e.getKey();
            double[] nv = e.getValue();
            double[] old = mk.get(s);
            if (old == null) {
                if (Scanner.isTradable(s) && nv[0] > 0) mk.put(s, nv);
                continue;
            }
            double prev = old[0];
            mk.put(s, nv);
            TextView[] tv = rowViews.get(s);
            if (tv != null && nv[0] != prev) {
                final TextView pr = tv[0];
                pr.setText("$" + Fmt.price(nv[0]));
                pr.setBackground(round(nv[0] > prev ? 0x550ECB81 : 0x55F6465D, 6, 0));
                handler.postDelayed(() -> pr.setBackground(null), 350);
                double ch = change(nv);
                tv[1].setText(Fmt.pct(ch));
                tv[1].setBackground(round(ch >= 0 ? GREEN : RED, 8, 0));
            }
        }
        updateBtcLine();
    }

    // ============================================================ ANALYZE tab
    private void buildAnalyze() {
        LinearLayout col = pageColumn(1);

        LinearLayout mc = card(col, ACC);
        LinearLayout mr = row();
        for (int m = 0; m < 2; m++) {
            final int mm = m;
            TextView t = chip(Mode.label(m), m == uiMode);
            if (m == uiMode) t.setBackground(round(Mode.accent(m), 20, Mode.accent(m)));
            t.setOnClickListener(v -> switchMode(mm));
            mr.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
            if (m == 0) mr.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        }
        mc.addView(mr);
        mc.addView(text(Mode.desc(uiMode), 12, ACC2));

        LinearLayout sc = card(col);
        sc.addView(bold("🔍 Apna coin analyze karein", 17, TEXT));
        LinearLayout sr = row();
        searchEt = input("SOL, PEPE, BTC...", base(currentSym), InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        sr.addView(searchEt, new LinearLayout.LayoutParams(0, -2, 1));
        TextView go = chip("Analyze", true);
        go.setOnClickListener(v -> {
            String s = searchEt.getText().toString().trim();
            if (s.isEmpty()) return;
            hideKeyboard();
            runAnalysis(CoinReport.normalize(s));
        });
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(-2, -2);
        glp.leftMargin = dp(8);
        sr.addView(go, glp);
        starBtn = chip("☆", false);
        starBtn.setOnClickListener(v -> {
            boolean on = Prefs.toggleWatch(this, currentSym);
            updateStar();
            renderWatchRow();
            toast(on ? "Watchlist mein add — bot isay hamesha scan karega" : "Watchlist se hata diya");
        });
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-2, -2);
        slp.leftMargin = dp(8);
        sr.addView(starBtn, slp);
        sc.addView(sr);
        sc.addView(text("⭐ Watchlist (tap = analysis):", 12, MUTED));
        watchRow = row();
        sc.addView(hscroll(watchRow));

        // ---- live chart card
        LinearLayout cc = card(col, ACC);
        LinearLayout th = row();
        chartTitle = bold(base(currentSym) + "/USDT", 16, TEXT);
        th.addView(chartTitle, new LinearLayout.LayoutParams(0, -2, 1));
        livePrice = bold("", 16, TEXT);
        th.addView(livePrice);
        cc.addView(th);
        LinearLayout tr = row();
        tr.setPadding(0, dp(6), 0, dp(4));
        for (int i = 0; i < chartTfs.length; i++) {
            final String tf = chartTfs[i];
            tfChips[i] = chip(tf, tf.equals(chartTf));
            tfChips[i].setOnClickListener(v -> selectTf(tf));
            tr.addView(tfChips[i], chipLp());
        }
        TextView fs = chip("⛶ Full", false);
        fs.setOnClickListener(v -> openFullscreen());
        TextView lv = chip("⏩ Live", false);
        lv.setOnClickListener(v -> chart.goLive());
        TextView zo = chip("−", false);
        zo.setOnClickListener(v -> chart.zoom(30));
        TextView zi = chip("+", false);
        zi.setOnClickListener(v -> chart.zoom(-30));
        tr.addView(fs, chipLp());
        tr.addView(lv, chipLp());
        tr.addView(zo, chipLp());
        tr.addView(zi, chipLp());
        cc.addView(hscroll(tr));
        LinearLayout lr = row();
        lr.setPadding(0, 0, 0, dp(6));
        for (int i = 0; i < LAYERS.length; i++) {
            final int idx = i;
            layerChips[i] = chip(LAYERS[i], Prefs.layer(this, LAYERS[i]));
            layerChips[i].setTextSize(11);
            layerChips[i].setOnClickListener(v -> {
                boolean on = !Prefs.layer(this, LAYERS[idx]);
                Prefs.setLayer(this, LAYERS[idx], on);
                styleChip(layerChips[idx], on);
                applyLayers();
            });
            lr.addView(layerChips[i], chipLp());
        }
        cc.addView(hscroll(lr));
        chart = new ChartView(this);
        chart.setAccent(ACC);
        applyLayers();
        cc.addView(chart, new LinearLayout.LayoutParams(-1, dp(480)));
        cc.addView(text("👆 Ungli se khiskayen = purane candles · 2 ungliyon se zoom · daba kar rakhen = candle detail · "
                + "🟢🔴 bubbles = whale orders (live) · W = whale candle · neeli/narangi bindi = retail crowd", 11, MUTED));

        // ---- live order flow card
        LinearLayout oc = card(col, ACC2);
        oc.addView(bold("⚡ Live order flow — whales vs retail", 16, TEXT));
        oc.addView(text("Har order usi waqt dikhta hai. 🐋 = whale, 🐬 = bada trader, 🐟 = retail. "
                + "Order book mein sunehri line = bada wall (🐋).", 12, MUTED));
        tape = new TapeView(this);
        oc.addView(tape, new LinearLayout.LayoutParams(-1, dp(250)));
        oc.addView(divider());
        book = new BookView(this);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, dp(240));
        blp.topMargin = dp(8);
        oc.addView(book, blp);

        resultBox = column();
        col.addView(resultBox);
        LinearLayout hint = card(resultBox);
        hint.addView(bold("Kya milega?", 15, TEXT));
        hint.addView(text("Coin likh kar Analyze dabayen. Bot sab mila kar hamesha ek saaf faisla deta hai — BUY ya SELL "
                + "(confidence % ke saath):\n"
                + "• Technical: " + String.join(", ", Mode.tfs(uiMode)) + "\n"
                + "• Chart patterns: triangle, wedge, channel, double top/bottom, breakout, Fibonacci, RSI divergence\n"
                + "• Paisa aa raha ya nikal raha: 10 exchanges ka volume + ETF inflow/outflow + on-chain\n"
                + "• Whales vs retail, order book walls\n"
                + "• Futures ke top traders, open interest, funding\n"
                + "• News, CoinGecko community, Fear & Greed\n"
                + "• 🤖 Claude AI se Roman Urdu mein trade plan aur sawal-jawab", 13, SOFT));
        updateStar();
        renderWatchRow();
    }

    private void selectTf(String tf) {
        chartTf = tf;
        for (int k = 0; k < chartTfs.length; k++) styleChip(tfChips[k], chartTfs[k].equals(chartTf));
        loadChart();
    }

    private void applyLayers() {
        chart.setLayers(Prefs.layer(this, "Fib"), Prefs.layer(this, "Lines"), Prefs.layer(this, "Zones"),
                Prefs.layer(this, "VolProfile"), Prefs.layer(this, "Whales"), Prefs.layer(this, "RSI"));
    }

    private void openFullscreen() {
        if (fsOverlay != null) return;
        chartParent = (ViewGroup) chart.getParent();
        chartIndex = chartParent.indexOfChild(chart);
        chartLp = chart.getLayoutParams();
        chartParent.removeView(chart);

        fsOverlay = column();
        fsOverlay.setBackgroundColor(Mode.bgTop(uiMode));
        fsOverlay.setPadding(dp(6), dp(6), dp(6), dp(6));
        LinearLayout bar = row();
        bar.addView(bold(base(currentSym) + "/USDT", 15, TEXT), new LinearLayout.LayoutParams(-2, -2));
        LinearLayout chips = row();
        chips.setPadding(dp(8), 0, 0, 0);
        for (String tf : chartTfs) {
            final String t = tf;
            TextView c = chip(tf, tf.equals(chartTf));
            c.setOnClickListener(v -> {
                selectTf(t);
                closeFullscreen();
                openFullscreen();
            });
            chips.addView(c, chipLp());
        }
        TextView lv = chip("⏩ Live", false);
        lv.setOnClickListener(v -> chart.goLive());
        TextView rot = chip("⟳ Ghumayen", false);
        rot.setOnClickListener(v -> setRequestedOrientation(
                getResources().getDisplayMetrics().widthPixels > getResources().getDisplayMetrics().heightPixels
                        ? ActivityInfo.SCREEN_ORIENTATION_PORTRAIT : ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE));
        TextView x = chip("✕", true);
        x.setOnClickListener(v -> closeFullscreen());
        chips.addView(lv, chipLp());
        chips.addView(rot, chipLp());
        chips.addView(x, chipLp());
        bar.addView(hscroll(chips), new LinearLayout.LayoutParams(0, -2, 1));
        fsOverlay.addView(bar);
        fsOverlay.addView(chart, new LinearLayout.LayoutParams(-1, 0, 1));
        rootFrame.addView(fsOverlay, new FrameLayout.LayoutParams(-1, -1));
    }

    private void closeFullscreen() {
        if (fsOverlay == null) return;
        fsOverlay.removeView(chart);
        rootFrame.removeView(fsOverlay);
        fsOverlay = null;
        chartParent.addView(chart, chartIndex, chartLp);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }

    private void updateStar() {
        boolean on = Prefs.inWatchlist(this, currentSym);
        starBtn.setText(on ? "★" : "☆");
        styleChip(starBtn, on);
    }

    private void renderWatchRow() {
        watchRow.removeAllViews();
        for (String s : Prefs.watchlist(this)) {
            final String sym = s;
            TextView c = chip(base(s), false);
            c.setOnClickListener(v -> openAnalyze(sym));
            watchRow.addView(c, chipLp());
        }
    }

    private void openAnalyze(String sym) {
        showTab(1);
        searchEt.setText(base(sym));
        pages[1].scrollTo(0, 0);
        runAnalysis(sym);
    }

    /** Loads candles + recent whale trades, runs the pattern engine, then switches the chart to LIVE. */
    private void loadChart() {
        final String sym = currentSym, tf = chartTf;
        final double whaleUsd = Prefs.whaleUsd(this);
        stopCoinFeed();
        chart.setMessage("Chart aur patterns load ho rahe hain...");
        chart.setPlan(false, true, 0, 0, 0, 0);
        tape.clear();
        book.set(new double[0][], new double[0][]);
        livePrice.setText("");
        pool.execute(() -> {
            try {
                final Candles c = Candles.fetch(sym, tf, 300, false);
                final PatternEngine.Result p = PatternEngine.analyze(c.closedOnly(), Math.min(150, c.n));
                final double[] wb = new double[c.n], ws = new double[c.n];
                final double thr = fillWhales(sym, c, wb, ws, whaleUsd, tf.endsWith("m") ? 3 : 1);
                double open24 = 0;
                try {
                    open24 = new JSONObject(Scanner.get("/api/v3/ticker/24hr?symbol=" + sym)).optDouble("openPrice", 0);
                } catch (Exception ignored) {
                }
                final double o24 = open24;
                runOnUiThread(() -> {
                    if (!sym.equals(currentSym) || !tf.equals(chartTf)) return;
                    chartWhaleThr = thr;
                    dayOpen = o24;
                    tape.setWhaleThreshold(thr);
                    chart.setData(c, p, wb, ws, tf, tf.endsWith("m"));
                    if (lastReport != null && lastReport.symbol.equals(sym)) applyPlan(lastReport);
                    if (resumed) startCoinFeed();
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> chart.setMessage("Chart nahi mila: " + m));
            }
        });
    }

    /** Puts big trades (>= threshold) from the latest aggTrades pages onto their candles. Returns the threshold. */
    private static double fillWhales(String sym, Candles c, double[] wb, double[] ws, double whaleUsd, int pages) {
        double qv = 0;
        for (int i = Math.max(0, c.n - 24); i < c.n; i++) qv += c.quoteVol[i];
        double thr = Math.min(whaleUsd, Math.max(5000, qv / Math.max(1, Math.min(24, c.n)) / 40));
        try {
            long fromId = -1;
            for (int pg = 0; pg < pages; pg++) {
                String q = "/api/v3/aggTrades?symbol=" + sym + "&limit=1000" + (fromId >= 0 ? "&fromId=" + fromId : "");
                JSONArray tr = new JSONArray(Scanner.get(q));
                if (tr.length() == 0) break;
                long firstId = Long.MAX_VALUE;
                for (int i = 0; i < tr.length(); i++) {
                    JSONObject o = tr.getJSONObject(i);
                    firstId = Math.min(firstId, o.optLong("a"));
                    double usd = Double.parseDouble(o.getString("p")) * Double.parseDouble(o.getString("q"));
                    if (usd < thr) continue;
                    int idx = c.indexOf(o.optLong("T"));
                    if (idx < 0) continue;
                    if (o.optBoolean("m")) ws[idx] += usd; else wb[idx] += usd;
                }
                fromId = firstId - 1000;
                if (fromId < 0) break;
            }
        } catch (Exception ignored) {
        }
        return thr;
    }

    // ------------------------------------------------------------ live coin stream
    private void startCoinFeed() {
        stopCoinFeed();
        final String sym = currentSym, tf = chartTf;
        liveSym = sym;
        liveTf = tf;
        synchronized (liveLock) {
            pendingKline = null;
            pendingTrades.clear();
            pendingBids = pendingAsks = null;
            candleClosed = false;
        }
        String s = sym.toLowerCase(Locale.US);
        coinWs = new WsStream("/stream?streams=" + s + "@kline_" + tf + "/" + s + "@aggTrade/" + s + "@depth20",
                new WsStream.Callback() {
                    @Override
                    public void onText(String text) { parseCoin(text); }

                    @Override
                    public void onStatus(boolean live) { coinLive = live; }
                }).start();
    }

    private void stopCoinFeed() {
        if (coinWs != null) coinWs.stop();
        coinWs = null;
        coinLive = false;
    }

    /** Runs on the WebSocket thread: just parse and park the data; the UI applies it every 400 ms. */
    private void parseCoin(String text) {
        try {
            JSONObject o = new JSONObject(text);
            String st = o.optString("stream");
            JSONObject d = o.optJSONObject("data");
            if (d == null) return;
            if (st.contains("@kline")) {
                JSONObject k = d.optJSONObject("k");
                if (k == null) return;
                double[] kl = {k.optLong("t"), num(k, "o"), num(k, "h"), num(k, "l"), num(k, "c"), num(k, "v"),
                        num(k, "q"), num(k, "V"), num(k, "Q"), k.optLong("n"), k.optBoolean("x") ? 1 : 0};
                synchronized (liveLock) {
                    pendingKline = kl;
                    if (kl[10] == 1) candleClosed = true;
                }
            } else if (st.contains("@aggTrade")) {
                double p = num(d, "p"), q = num(d, "q");
                synchronized (liveLock) {
                    if (pendingTrades.size() < 4000) pendingTrades.add(new double[]{d.optLong("T"), p, p * q, d.optBoolean("m") ? 1 : 0});
                }
            } else if (st.contains("@depth")) {
                JSONArray b = d.optJSONArray("bids"), a = d.optJSONArray("asks");
                if (b == null || a == null) return;
                double[][] bb = new double[b.length()][], aa = new double[a.length()][];
                for (int i = 0; i < b.length(); i++) {
                    JSONArray x = b.getJSONArray(i);
                    bb[i] = new double[]{Double.parseDouble(x.getString(0)), Double.parseDouble(x.getString(1))};
                }
                for (int i = 0; i < a.length(); i++) {
                    JSONArray x = a.getJSONArray(i);
                    aa[i] = new double[]{Double.parseDouble(x.getString(0)), Double.parseDouble(x.getString(1))};
                }
                synchronized (liveLock) {
                    pendingBids = bb;
                    pendingAsks = aa;
                }
            }
        } catch (Exception ignored) {
        }
    }

    /** UI thread, every 400 ms: move live candles / trades / order book onto the screen. */
    private void applyLive() {
        double[] kl;
        List<double[]> trs;
        double[][] b, a;
        boolean closed;
        synchronized (liveLock) {
            kl = pendingKline;
            pendingKline = null;
            trs = new ArrayList<>(pendingTrades);
            pendingTrades.clear();
            b = pendingBids;
            a = pendingAsks;
            pendingBids = pendingAsks = null;
            closed = candleClosed;
            candleClosed = false;
        }
        if (coinWs == null || !currentSym.equals(liveSym) || !chartTf.equals(liveTf)) return;
        Candles cur = chart.getData();
        if (kl != null && cur != null) {
            Candles nc = cur.live((long) kl[0], kl[1], kl[2], kl[3], kl[4], kl[5], kl[6], kl[7], kl[8], kl[9]);
            if (nc != null) chart.liveCandles(nc);
            double p = kl[4];
            String ch = dayOpen > 0 ? "  " + Fmt.pct((p / dayOpen - 1) * 100) : "";
            livePrice.setText("$" + Fmt.price(p) + ch);
            livePrice.setTextColor(dayOpen > 0 && p < dayOpen ? RED : GREEN);
        }
        for (double[] t : trs) {
            boolean sell = t[3] == 1;
            if (t[2] >= chartWhaleThr) chart.liveTrade((long) t[0], t[2], sell);
            tape.add(TapeView.trade((long) t[0], t[1], t[2], sell));
        }
        tape.invalidate();
        if (b != null) book.set(b, a);
        chart.setLiveText(coinLive ? "● LIVE" : "○ connect ho raha hai...");
        if (closed && chart.getData() != null) {
            final Candles snap = chart.getData().closedOnly();
            final String sym = currentSym, tf = chartTf;
            pool.execute(() -> {
                final PatternEngine.Result p = PatternEngine.analyze(snap, Math.min(150, snap.n));
                runOnUiThread(() -> {
                    if (sym.equals(currentSym) && tf.equals(chartTf)) chart.setPatterns(p);
                });
            });
        }
    }

    // ------------------------------------------------------------ full analysis
    private void runAnalysis(String sym) {
        boolean newCoin = !sym.equals(currentSym) || chart.getData() == null;
        currentSym = sym;
        lastReport = null;
        Prefs.setLastCoin(this, sym);
        updateStar();
        chartTitle.setText(base(sym) + "/USDT");
        if (newCoin) loadChart();
        else chart.setPlan(false, true, 0, 0, 0, 0);
        resultBox.removeAllViews();
        LinearLayout wait = card(resultBox, ACC);
        wait.addView(bold("⏳ " + base(sym) + " ka " + Mode.label(uiMode) + " analysis ho raha hai...", 15, ACC));
        wait.addView(text("Binance (" + String.join(", ", Mode.tfs(uiMode)) + "), 10 exchanges ka volume, ETF flows, on-chain, "
                + "chart patterns, whales, futures, news aur sentiment se data jama ho raha hai. 15–30 second lag sakte hain.", 13, MUTED));
        final String key = Prefs.glassKey(this);
        final double wu = Prefs.whaleUsd(this);
        final int mode = uiMode;
        pool.execute(() -> {
            try {
                final CoinReport r = CoinReport.build(sym, mode, key, wu, true);
                runOnUiThread(() -> {
                    if (sym.equals(currentSym)) showReport(r);
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> {
                    if (!sym.equals(currentSym)) return;
                    resultBox.removeAllViews();
                    LinearLayout c = card(resultBox, RED);
                    c.addView(bold("❌ Analysis nahi ho saka", 15, RED));
                    c.addView(text(m == null ? "Internet check karein" : m, 13, SOFT));
                    c.addView(text("Coin ka naam sahi likhein (jaise SOL, PEPE, WIF). Market tab mein search karke bhi dhoond sakte hain.", 12, MUTED));
                });
            }
        });
    }

    private String pctFrom(double v, double p) {
        return p > 0 ? String.format(Locale.US, "  (%+.1f%%)", (v / p - 1) * 100) : "";
    }

    private void applyPlan(CoinReport r) {
        boolean showPlan = r.isBuy || r.mode == Mode.SCALP;
        double entry = r.advice != null ? r.advice.entry : r.price;
        chart.setPlan(showPlan && r.atr > 0, r.isBuy, entry, r.stop, r.target1, r.target2);
        if (r.advice != null) chart.setZone(r.advice.zoneLo, r.advice.zoneHi, (r.isBuy ? "BUY ZONE" : "SELL ZONE"), r.isBuy ? GREEN : RED);
        else chart.setZone(0, 0, "", 0);
    }

    private void showReport(final CoinReport r) {
        lastReport = r;
        resultBox.removeAllViews();
        chartTitle.setText(r.name + " · " + r.base + "/USDT");
        boolean scalp = r.mode == Mode.SCALP;
        boolean showPlan = r.isBuy || scalp;
        applyPlan(r);
        int vc = r.isBuy ? GREEN : RED;

        LinearLayout h = card(resultBox, vc);
        LinearLayout hr = row();
        hr.addView(bold("🎯 Final signal", 16, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView mb = bold(Mode.label(r.mode), 11, INK);
        mb.setPadding(dp(8), dp(3), dp(8), dp(3));
        mb.setBackground(round(ACC, 10, 0));
        hr.addView(mb);
        h.addView(hr);
        TextView big = bold((r.isBuy ? "▲ " : "▼ ") + r.verdict, 30, vc);
        big.setGravity(Gravity.CENTER);
        big.setLetterSpacing(0.05f);
        h.addView(big);
        TextView conf = bold("Confidence " + r.confidence + "%  ·  Score " + r.total + "/100", 13, TEXT);
        conf.setGravity(Gravity.CENTER);
        h.addView(conf);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, dp(10));
        clp.topMargin = dp(6);
        clp.bottomMargin = dp(6);
        h.addView(bar(r.confidence, vc, 0xFF243049), clp);
        TextView vt = text(r.verdictText, 14, SOFT);
        vt.setGravity(Gravity.CENTER);
        h.addView(vt);
        GaugeView g = new GaugeView(this);
        g.set(r.total, r.isBuy ? "BUY side" : "SELL side", "0 = full sell · 100 = full buy");
        h.addView(g, new LinearLayout.LayoutParams(-1, dp(165)));
        TextView rf = chip("↻ Dobara analysis (taaza data)", false);
        rf.setOnClickListener(v -> runAnalysis(r.symbol));
        h.addView(rf);

        positionCard(r);
        flowCard(r);

        // ---- Claude AI
        aiCard(r);

        LinearLayout f = card(resultBox);
        f.addView(bold("💰 Paisa aa raha ya nikal raha? (" + Mode.flowSpan(r.mode) + ")", 16, TEXT));
        f.addView(bold(r.flowLabel, 17, r.flowSign > 0 ? GREEN : r.flowSign < 0 ? RED : YELLOW));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, dp(14));
        blp.topMargin = dp(8);
        f.addView(bar(r.buyPct, GREEN, RED), blp);
        LinearLayout lr = row();
        lr.addView(text(String.format(Locale.US, "Buyers %.0f%%", r.buyPct), 12, GREEN), new LinearLayout.LayoutParams(0, -2, 1));
        lr.addView(text(String.format(Locale.US, "Sellers %.0f%%", 100 - r.buyPct), 12, RED));
        f.addView(lr);
        f.addView(text("Live 60 second ka hisaab upar 'Live order flow' card mein har waqt update hota hai.", 12, MUTED));

        tradePlan(r, showPlan);

        for (CoinReport.Section s : r.sections) sectionCard(s);

        if (!r.news.isEmpty()) {
            LinearLayout n = card(resultBox);
            n.addView(bold("📰 Taaza khabrein — " + r.name, 16, TEXT));
            for (String[] it : r.news) {
                String tone = "+".equals(it[3]) ? "🟢 " : "-".equals(it[3]) ? "🔴 " : "⚪ ";
                TextView t = text(tone + it[0], 13, TEXT);
                t.setPadding(0, dp(6), 0, 0);
                final String link = it[1];
                t.setOnClickListener(v -> openUrl(link));
                n.addView(t);
                n.addView(text(it[2] + " · tap karke parhen", 11, MUTED));
            }
        }

        LinearLayout al = card(resultBox, ACC2);
        al.addView(bold("🔔 Price alert lagayen", 16, TEXT));
        al.addView(text("Price is level ko cross kare to notification aayegi (koi bhi bot ON hona chahiye).", 12, MUTED));
        LinearLayout ar = row();
        final EditText ap = input("Price", Fmt.price(r.isBuy ? r.target1 : r.stop), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        ar.addView(ap, new LinearLayout.LayoutParams(0, -2, 1));
        TextView ab = chip("Alert lagao", true);
        ab.setOnClickListener(v -> {
            double p = parse(ap, 0);
            if (p <= 0) { toast("Sahi price likhen"); return; }
            Prefs.addAlert(this, r.symbol, p, p > r.price);
            toast("Alert laga diya: " + r.base + (p > r.price ? " upar " : " neeche ") + "$" + Fmt.price(p));
            if (!Prefs.enabled(this)) toast("Yaad rahe: Signals tab se Scalp ya Spot bot ON karein");
        });
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-2, -2);
        alp.leftMargin = dp(8);
        ar.addView(ab, alp);
        al.addView(ar);

        LinearLayout act = card(resultBox);
        Button bin = button("🟡 Binance app mein " + r.base + " kholen (Spot)", 0xFFF0B90B, INK, 0);
        bin.setOnClickListener(v -> BinanceLink.open(this, r.base, false));
        act.addView(bin);
        Button binF = button("🟡 Binance Futures mein kholen", CHIP, 0xFFF0B90B, 0xFFF0B90B);
        binF.setOnClickListener(v -> BinanceLink.open(this, r.base, true));
        act.addView(binF);
        act.addView(text("⚠️ Yeh analysis maloomat ke liye hai, financial advice nahi. Chart patterns aur whale markers "
                + "computer ka andaza hain — 100% sahi nahi hote. Hamesha stop-loss lagayen aur utna hi lagayen jitna "
                + "khona bardasht ho.", 12, MUTED));
    }

    // ------------------------------------------------------------ Claude AI
    private String liveExtras() {
        StringBuilder sb = new StringBuilder("\n[LIVE ORDER FLOW right now]\n");
        double[] p = tape.pressure();
        sb.append("- Last 60s aggressive buy ").append(Fmt.usd(p[0])).append(" vs sell ").append(Fmt.usd(p[1])).append('\n');
        sb.append("- Last 5min whale buy ").append(Fmt.usd(p[4])).append(" vs whale sell ").append(Fmt.usd(p[5]))
                .append(" (whale = trade >= ").append(Fmt.usd(chartWhaleThr)).append(")\n");
        double[] s = book.sums();
        sb.append("- Order book top 10: bids ").append(Fmt.usd(s[0])).append(" vs asks ").append(Fmt.usd(s[1])).append('\n');
        Candles c = chart.getData();
        if (c != null && c.n > 0) sb.append("- Live price ").append(Fmt.price(c.close[c.n - 1])).append(" on ").append(chartTf).append(" chart\n");
        return sb.toString();
    }

    private void aiCard(final CoinReport r) {
        LinearLayout ai = card(resultBox, CLAUDE);
        LinearLayout hr = row();
        hr.addView(bold("🤖 Claude AI Analyst", 16, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView m = bold(Prefs.claudeModel(this).replace("claude-", ""), 10, INK);
        m.setPadding(dp(6), dp(2), dp(6), dp(2));
        m.setBackground(round(CLAUDE, 8, 0));
        hr.addView(m);
        ai.addView(hr);
        ai.addView(text("Claude upar ka saara live data parh kar Roman Urdu mein trade plan likhega. Aap apne sawal bhi pooch sakte hain.", 12, MUTED));
        final LinearLayout chat = column();
        ai.addView(chat);
        final List<String[]> history = new ArrayList<>();
        TextView full = chip("✨ Claude se poora analysis likhwayen", true);
        full.setBackground(round(CLAUDE, 20, CLAUDE));
        full.setOnClickListener(v -> askClaude(r, chat, history,
                "Is coin ka poora analysis karo: direction (BUY/SELL), entry, stop-loss, 2 targets, risk, aur kis cheez se idea ghalat sabit hoga.", true));
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(-1, -2);
        flp.topMargin = dp(8);
        ai.addView(full, flp);
        LinearLayout qr = row();
        final EditText q = input("Sawal likhen (jaise: kya abhi entry lun?)", "", InputType.TYPE_CLASS_TEXT);
        qr.addView(q, new LinearLayout.LayoutParams(0, -2, 1));
        TextView ask = chip("Poochen", false);
        ask.setOnClickListener(v -> {
            String s = q.getText().toString().trim();
            if (s.isEmpty()) return;
            q.setText("");
            hideKeyboard();
            askClaude(r, chat, history, s, history.isEmpty());
        });
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-2, -2);
        alp.leftMargin = dp(8);
        qr.addView(ask, alp);
        ai.addView(qr);
    }

    private TextView bubble(String s, boolean user) {
        TextView t = text(s, 13, user ? TEXT : SOFT);
        t.setPadding(dp(10), dp(8), dp(10), dp(8));
        t.setBackground(round(user ? 0xFF243049 : 0x22D97757, 12, user ? 0 : 0x66D97757));
        t.setTextIsSelectable(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(8);
        t.setLayoutParams(lp);
        return t;
    }

    private void askClaude(final CoinReport r, final LinearLayout chat, final List<String[]> history, String question, boolean withData) {
        final String key = Prefs.claudeKey(this);
        if (key.isEmpty()) {
            chat.addView(bubble("🔑 Pehle ⚙️ Settings mein apni Claude API key daalein.\nKey console.anthropic.com se milti hai "
                    + "(Anthropic ka developer account — is ka kharcha alag se lagta hai, har sawal par thore cents).", false));
            return;
        }
        String content = withData || history.isEmpty()
                ? "LIVE DATA REPORT:\n" + r.toText() + liveExtras() + "\n\nSAWAL: " + question
                : question;
        history.add(new String[]{"user", content});
        chat.addView(bubble("🙋 " + question, true));
        final TextView thinking = bubble("🤖 Claude soch raha hai...", false);
        chat.addView(thinking);
        final String model = Prefs.claudeModel(this);
        final List<String[]> snap = new ArrayList<>(history);
        pool.execute(() -> {
            try {
                final String ans = ClaudeAI.ask(key, model, snap);
                runOnUiThread(() -> {
                    history.add(new String[]{"assistant", ans});
                    thinking.setText("🤖 " + ans);
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> {
                    if (!history.isEmpty()) history.remove(history.size() - 1);
                    thinking.setText("❌ Claude se jawab nahi aaya: " + m);
                    thinking.setTextColor(RED);
                });
            }
        });
    }

    private void tradePlan(final CoinReport r, boolean showPlan) {
        boolean scalp = r.mode == Mode.SCALP;
        LinearLayout p = card(resultBox, ACC);
        p.addView(bold("🧭 Trade plan — " + (r.isBuy ? (scalp ? "LONG scalp" : "Spot BUY") : (scalp ? "SHORT scalp (futures)" : "Spot: bechne / exit ka waqt")), 16, TEXT));
        p.addView(text("Support: $" + Fmt.price(r.support) + "   ·   Resistance: $" + Fmt.price(r.resistance), 13, SOFT));
        if (r.patterns != null && r.patterns.keyLevel > 0)
            p.addView(text("📐 Key level: $" + Fmt.price(r.patterns.keyLevel) + " · pattern target: $" + Fmt.price(r.patterns.target), 13, SOFT));
        if (!showPlan || r.atr <= 0) {
            p.addView(text("Spot mein SELL ka matlab: naya na khareedain. Holding ho to $" + Fmt.price(r.support)
                    + " ke neeche stop rakhen ya profit bacha lein. Wapas BUY tab jab score 50+ ho jaye.", 13, YELLOW));
            return;
        }
        p.addView(text("Entry: ~$" + Fmt.price(r.price), 14, TEXT));
        p.addView(text("Stop-loss: $" + Fmt.price(r.stop) + pctFrom(r.stop, r.price), 14, RED));
        p.addView(text("Target 1: $" + Fmt.price(r.target1) + pctFrom(r.target1, r.price) + "  (1 : 1.5)", 14, GREEN));
        p.addView(text("Target 2: $" + Fmt.price(r.target2) + pctFrom(r.target2, r.price) + "  (1 : 3)", 14, GREEN));
        p.addView(text("TP1 par aadha profit lein aur stop ko entry par le aayen. Yeh lines chart par bhi bani hain.", 12, MUTED));

        p.addView(divider());
        p.addView(bold("🧮 Position size calculator", 15, ACC2));
        LinearLayout rr = row();
        final EditText bal = input("Balance USDT", String.valueOf(Prefs.balance(this)), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        final EditText rp = input("Risk %", String.valueOf(Prefs.riskPct(this)), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        LinearLayout c1 = column();
        c1.addView(text("Balance (USDT)", 11, MUTED));
        c1.addView(bal);
        LinearLayout c2 = column();
        c2.addView(text("Risk per trade %", 11, MUTED));
        c2.addView(rp);
        rr.addView(c1, new LinearLayout.LayoutParams(0, -2, 1));
        rr.addView(new View(this), new LinearLayout.LayoutParams(dp(10), 1));
        rr.addView(c2, new LinearLayout.LayoutParams(0, -2, 1));
        p.addView(rr);
        final TextView out = text("", 13, TEXT);
        Runnable calc = () -> {
            double b = parse(bal, 0), pct = parse(rp, 1);
            Prefs.saveRisk(this, (float) b, (float) pct);
            double riskUsd = b * pct / 100;
            double perUnit = Math.abs(r.price - r.stop);
            if (perUnit <= 0 || b <= 0) { out.setText("Balance likhen"); return; }
            double qty = riskUsd / perUnit;
            double pos = qty * r.price;
            String lev = pos > b ? String.format(Locale.US, "\n⚠️ Position balance se badi hai — %.1fx leverage chahiye. Risk kam karein.", pos / b) : "";
            out.setText(String.format(Locale.US, "Agar stop lage to nuksan: $%.2f (%.1f%%)\nKhareedain: %s %s  ≈  $%.2f\nTP1 par faida ≈ $%.2f · TP2 par ≈ $%.2f%s",
                    riskUsd, pct, qty >= 1 ? String.format(Locale.US, "%.2f", qty) : String.format(Locale.US, "%.6f", qty), r.base, pos,
                    qty * Math.abs(r.target1 - r.price), qty * Math.abs(r.target2 - r.price), lev));
        };
        TextView cb = chip("Calculate", true);
        cb.setOnClickListener(v -> { hideKeyboard(); calc.run(); });
        LinearLayout.LayoutParams cblp = new LinearLayout.LayoutParams(-2, -2);
        cblp.topMargin = dp(6);
        p.addView(cb, cblp);
        p.addView(out);
        calc.run();
    }

    private void sectionCard(CoinReport.Section s) {
        boolean pat = s.icon.equals("📐");
        LinearLayout c = card(resultBox, pat ? ACC2 : STROKE);
        LinearLayout hr = row();
        hr.addView(bold(s.icon + "  " + s.title, 15, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        int col = !s.available ? MUTED : s.score > 15 ? GREEN : s.score < -15 ? RED : YELLOW;
        hr.addView(bold(s.available ? String.format(Locale.US, "%+d", s.score) : "N/A", 14, col));
        c.addView(hr);
        if (s.available) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(6));
            lp.topMargin = dp(6);
            lp.bottomMargin = dp(4);
            c.addView(bar((s.score + 100) / 2.0, col, 0xFF243049), lp);
        }
        for (String l : s.lines) c.addView(text("• " + l, 13, SOFT));
        if (pat) c.addView(text("👆 Yeh sab upar chart par lines, zones aur 🎯 arrow ki shakal mein bana hai.", 12, ACC2));
    }

    // ============================================================ in-app update
    private void checkForUpdate(final boolean manual) {
        if (manual && updStatus != null) updStatus.setText("Check ho raha hai...");
        pool.execute(() -> {
            try {
                final UpdateManager.Info in = UpdateManager.check(this);
                runOnUiThread(() -> {
                    if (in != null) {
                        showUpdate(in);
                        if (updStatus != null) updStatus.setText("🆕 Naya version available: " + in.title);
                    } else {
                        updateBanner.setVisibility(View.GONE);
                        if (updStatus != null) updStatus.setText("✅ Aap ke paas latest version hai");
                        if (manual) toast("App up to date hai ✅");
                    }
                });
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> {
                    if (updStatus != null) updStatus.setText("Update check nahi hua: " + m + " (repo naam check karein)");
                });
            }
        });
    }

    private void showUpdate(final UpdateManager.Info in) {
        updateBanner.removeAllViews();
        updateBanner.setVisibility(View.VISIBLE);
        updateBanner.addView(bold("🆕 Naya update available!", 16, GREEN));
        String when = new SimpleDateFormat("dd MMM HH:mm", Locale.US).format(new Date(in.time));
        updateBanner.addView(text(in.title + " · " + when + " · " + Fmt.num(in.size / 1024.0) + " KB", 12, MUTED));
        final TextView prog = text("", 12, SOFT);
        updateBanner.addView(prog);
        Button b = button("⬇ Abhi install karein", GREEN, INK, 0);
        b.setOnClickListener(v -> startInstall(in, prog));
        updateBanner.addView(b);
        if (currentTab == TAB_SETTINGS) toast("🆕 Naya update — Market tab ke upar Install dabayen");
    }

    private void startInstall(final UpdateManager.Info in, final TextView prog) {
        if (installing) return;
        if (!UpdateManager.canInstall(this)) {
            prog.setText("Pehli dafa: agli screen par 'Allow from this source' ON karein, phir wapas aa kar dobara Install dabayen.");
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) {
            }
            return;
        }
        installing = true;
        prog.setText("Download ho raha hai... 0%");
        pool.execute(() -> {
            try {
                UpdateManager.install(this, in, pct -> runOnUiThread(() -> prog.setText("Download ho raha hai... " + pct + "%")));
                runOnUiThread(() -> prog.setText("✅ Download mukammal — ab Android ki screen par 'Update' dabayen"));
            } catch (Exception e) {
                final String m = e.getMessage();
                runOnUiThread(() -> prog.setText("❌ Update nahi hua: " + m));
            } finally {
                installing = false;
            }
        });
    }

    // ============================================================ position + volume windows (analysis)
    private void positionCard(final CoinReport r) {
        Position.Advice a = r.advice;
        if (a == null || r.atr <= 0) return;
        boolean spotSell = !r.isBuy && r.mode == Mode.SPOT;
        int col = a.buy ? GREEN : RED;
        LinearLayout c = card(resultBox, col);
        c.addView(bold("📍 Position — kahan aur kab " + (a.buy ? "BUY" : spotSell ? "SELL / EXIT" : "SELL"), 16, TEXT));
        TextView t = bold(a.title, 17, col);
        c.addView(t);
        c.addView(text(a.why, 13, SOFT));
        String kind = Position.NOW.equals(a.type) ? "Abhi entry — volume saath hai"
                : Position.RETEST.equals(a.type) ? "Retest ka intezar — chase na karein"
                : Position.BREAKOUT.equals(a.type) ? "Breakout/breakdown confirm hone ka intezar"
                : "Behtar qeemat ka intezar (zone mein limit order)";
        TextView k = bold("➡ " + kind, 13, YELLOW);
        k.setPadding(0, dp(6), 0, dp(4));
        c.addView(k);
        c.addView(text((a.buy ? "BUY" : "SELL") + " zone: $" + Fmt.price(a.zoneLo) + " – $" + Fmt.price(a.zoneHi)
                + "   (entry ~$" + Fmt.price(a.entry) + ")", 14, TEXT));
        c.addView(text("🛑 Stop-loss: $" + Fmt.price(a.sl) + pctFrom(a.sl, a.entry), 14, RED));
        c.addView(text("🎯 TP1: $" + Fmt.price(a.tp1) + pctFrom(a.tp1, a.entry) + "  ·  TP2: $" + Fmt.price(a.tp2) + pctFrom(a.tp2, a.entry), 14, GREEN));
        c.addView(text("Chart par zone, SL aur TP lines bani hain. Price zone mein aaye tab entry lein.", 12, MUTED));
        TextView bin = chip("🟡 Binance app mein kholen", true);
        bin.setBackground(round(0xFFF0B90B, 20, 0));
        bin.setOnClickListener(v -> BinanceLink.open(this, r.base, r.mode == Mode.SCALP && !r.isBuy));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = dp(8);
        c.addView(bin, lp);
    }

    private void flowCard(CoinReport r) {
        FlowWindows.Result f = r.flows;
        if (f == null || f.venues.isEmpty()) return;
        LinearLayout c = card(resultBox, ACC2);
        c.addView(bold("⏱️ Volume IN vs OUT — 1 · 5 · 15 minute", 16, TEXT));
        c.addView(text(f.venues.size() + " exchanges: " + String.join(", ", f.venues), 11, MUTED));
        String[] lbl = {"1 min", "5 min", "15 min"};
        for (int k = 0; k < 3; k++) {
            double net = f.net(k);
            LinearLayout rr = row();
            rr.setPadding(0, dp(6), 0, 0);
            rr.addView(bold(lbl[k], 13, TEXT), new LinearLayout.LayoutParams(dp(56), -2));
            rr.addView(text("IN " + Fmt.usd(f.in[k]), 12, GREEN), new LinearLayout.LayoutParams(0, -2, 1));
            rr.addView(text("OUT " + Fmt.usd(f.out[k]), 12, RED), new LinearLayout.LayoutParams(0, -2, 1));
            rr.addView(bold((net >= 0 ? "+" : "") + Fmt.usd(net), 13, net >= 0 ? GREEN : RED));
            c.addView(rr);
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, dp(8));
            bl.topMargin = dp(2);
            c.addView(bar(f.buyPct(k), GREEN, RED), bl);
        }
        double b5 = f.buyPct(1);
        c.addView(bold(b5 >= 55 ? "💰 Volume AA raha hai — upar ja sakta hai" : b5 <= 45 ? "🚨 Volume NIKAL raha hai — neeche ja sakta hai"
                : "⚖️ Barabar — abhi faisla nahi", 14, b5 >= 55 ? GREEN : b5 <= 45 ? RED : YELLOW));
        if (!f.partial.isEmpty()) c.addView(text("Note: " + String.join(", ", f.partial) + " ki taaza trades sirf chhote window cover karti hain.", 11, MUTED));
    }

    // ============================================================ WALLET tab (watch-only)
    private void buildWallet() {
        LinearLayout col = pageColumn(TAB_WALLET);
        LinearLayout sec = card(col, GREEN);
        sec.addView(bold("🔒 100% safe — sirf dekhne wala (watch-only) tracker", 15, GREEN));
        sec.addView(text("• Sirf PUBLIC address chahiye (jo aap paise mangwane ke liye dete hain)\n"
                + "• Seed phrase (12/24 words) ya private key KABHI na daalein — app khud inhein rok degi\n"
                + "• App aap ka wallet open nahi karti, kuch bhej ya sign nahi kar sakti — sirf blockchain se balance parhti hai\n"
                + "• Trust Wallet: coin kholen → Receive → address copy karein", 12, SOFT));

        LinearLayout add = card(col, ACC);
        add.addView(bold("➕ Wallet add karein", 16, TEXT));
        walLabelEt = input("Naam (jaise: Trust Wallet BTC)", "", InputType.TYPE_CLASS_TEXT);
        add.addView(walLabelEt);
        walAddrEt = input("Public address paste karein", "", InputType.TYPE_CLASS_TEXT);
        add.addView(walAddrEt);
        final TextView det = text("Supported: Bitcoin · Ethereum (+ ERC20 tokens) · BNB Chain (BNB, USDT) · TRON (TRX, USDT TRC20) · Solana (SOL, USDT/USDC) · Litecoin · Dogecoin", 11, MUTED);
        add.addView(det);
        walAddrEt.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence q, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence q, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) {
                String t = e.toString().trim();
                String bad = WalletTracker.securityCheck(t);
                if (bad != null) { det.setText(bad); det.setTextColor(RED); return; }
                String ch = t.isEmpty() ? null : WalletTracker.detect(t);
                det.setText(ch == null ? (t.isEmpty() ? "" : "Address pehchana nahi gaya") : "✅ Network: " + WalletTracker.chainName(ch));
                det.setTextColor(ch == null ? MUTED : GREEN);
            }
        });
        Button b = button("➕ Add karein", ACC, INK, 0);
        b.setOnClickListener(v -> addWallet());
        add.addView(b);

        LinearLayout tot = card(col, ACC2);
        LinearLayout tr = row();
        tr.addView(bold("💼 Kul portfolio", 16, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView rf = chip("↻ Refresh", false);
        rf.setOnClickListener(v -> loadWallets());
        tr.addView(rf);
        tot.addView(tr);
        walletTotal = bold("$0", 28, TEXT);
        tot.addView(walletTotal);
        walletNet = text("", 12, MUTED);
        tot.addView(walletNet);
        walletList = column();
        col.addView(walletList);
    }

    private void addWallet() {
        String a = walAddrEt.getText().toString().trim();
        String bad = WalletTracker.securityCheck(a);
        if (bad != null) {
            walAddrEt.setText("");
            toast("⛔ Secret data! Mita diya gaya. Sirf public address daalein.");
            return;
        }
        String ch = WalletTracker.detect(a);
        if (ch == null) { toast("Sahi public address daalein"); return; }
        JSONArray ws = Prefs.wallets(this);
        for (int i = 0; i < ws.length(); i++) {
            JSONObject o = ws.optJSONObject(i);
            if (o != null && a.equalsIgnoreCase(o.optString("addr"))) { toast("Yeh wallet pehle se hai"); return; }
        }
        try {
            JSONObject o = new JSONObject();
            String lbl = walLabelEt.getText().toString().trim();
            o.put("label", lbl.isEmpty() ? WalletTracker.chainName(ch) + " " + WalletTracker.shortAddr(a) : lbl);
            o.put("addr", a);
            o.put("chain", ch);
            ws.put(o);
            Prefs.saveWallets(this, ws);
        } catch (Exception ignored) {
        }
        walAddrEt.setText("");
        walLabelEt.setText("");
        hideKeyboard();
        toast("Wallet add ho gaya ✅ — balance badalne par notification aayegi");
        loadWallets();
    }

    private void loadWallets() {
        walletsLoadedAt = System.currentTimeMillis();
        walletList.removeAllViews();
        if (Prefs.wallets(this).length() == 0) {
            walletTotal.setText("$0");
            walletNet.setText("Abhi koi wallet nahi — upar address add karein");
            return;
        }
        walletNet.setText("Blockchain se balance parh raha hoon...");
        pool.execute(() -> {
            final List<WalletTracker.Result> rs = WalletWatch.check(this);
            runOnUiThread(() -> renderWallets(rs));
        });
    }

    private void renderWallets(List<WalletTracker.Result> rs) {
        walletList.removeAllViews();
        JSONArray ws = Prefs.wallets(this);
        double total = 0;
        for (int i = 0; i < rs.size(); i++) {
            final WalletTracker.Result r = rs.get(i);
            total += r.totalUsd;
            final int idx = i;
            JSONObject w = ws.optJSONObject(i);
            String label = w == null ? WalletTracker.shortAddr(r.address) : w.optString("label");
            LinearLayout c = card(walletList, r.error != null && r.holdings.isEmpty() ? RED : STROKE);
            LinearLayout hr = row();
            LinearLayout ht = column();
            ht.addView(bold(label, 15, TEXT));
            ht.addView(text(WalletTracker.chainName(r.chain == null ? "?" : r.chain) + " · " + WalletTracker.shortAddr(r.address), 11, MUTED));
            hr.addView(ht, new LinearLayout.LayoutParams(0, -2, 1));
            hr.addView(bold(Fmt.usd(r.totalUsd), 17, GREEN));
            c.addView(hr);
            if (r.holdings.isEmpty()) {
                c.addView(text(r.error != null ? "⚠️ " + r.error + " (thori der baad Refresh)" : "Balance 0", 12, r.error != null ? YELLOW : MUTED));
            }
            for (WalletTracker.Holding h : r.holdings) {
                LinearLayout hr2 = row();
                hr2.setPadding(0, dp(4), 0, dp(4));
                String amt = h.amount >= 1000 ? Fmt.num(h.amount) : String.format(Locale.US, h.amount >= 1 ? "%.4f" : "%.8f", h.amount);
                hr2.addView(bold(h.asset, 14, TEXT), new LinearLayout.LayoutParams(dp(70), -2));
                hr2.addView(text(amt + "  ·  " + h.network, 12, SOFT), new LinearLayout.LayoutParams(0, -2, 1));
                hr2.addView(text(Fmt.usd(h.usd), 13, TEXT));
                c.addView(hr2);
            }
            if (!r.txs.isEmpty()) {
                c.addView(divider());
                c.addView(text("Taaza len-den:", 11, MUTED));
                for (String t : r.txs) c.addView(text(t, 12, SOFT));
            }
            LinearLayout br = row();
            if (r.explorer != null) {
                TextView ex = chip("🔗 Explorer", false);
                ex.setOnClickListener(v -> openUrl(r.explorer));
                br.addView(ex, chipLp());
            }
            final TextView del = chip("🗑 Hatayen", false);
            final long[] armed = {0};
            del.setOnClickListener(v -> {
                long now = System.currentTimeMillis();
                if (now - armed[0] < 3000) {
                    JSONArray cur = Prefs.wallets(this), out = new JSONArray();
                    for (int k = 0; k < cur.length(); k++) if (k != idx) out.put(cur.opt(k));
                    Prefs.saveWallets(this, out);
                    loadWallets();
                } else {
                    armed[0] = now;
                    del.setText("Pakka? dobara");
                }
            });
            br.addView(del, chipLp());
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-2, -2);
            bl.topMargin = dp(6);
            c.addView(hscroll(br), bl);
        }
        walletTotal.setText(Fmt.usd(total));
        walletNet.setText(rs.size() + " wallets · " + new SimpleDateFormat("HH:mm", Locale.US).format(new Date())
                + " · har 15 min check (bot ON ho to) · paisa aaye/jaye to notification");
    }

    // ============================================================ BIG PLAYERS tab
    private void buildBig() {
        LinearLayout col = pageColumn(TAB_BIG);
        LinearLayout h = card(col, ACC);
        LinearLayout hr = row();
        hr.addView(bold("🐋 Bade log kya kar rahe hain", 17, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView rf = chip("↻ Refresh", false);
        rf.setOnClickListener(v -> loadBig());
        hr.addView(rf);
        h.addView(hr);
        h.addView(text("BlackRock, Fidelity, Grayscale (ETFs) · Strategy, Trump Media waghera (companies) · governments · "
                + "exchange aur Trump/WLFI wallets. Jab yeh khareedain ya bechain to notification.", 12, MUTED));
        toggle(h, "🔔 Khareed / farokht par notification", null, Prefs.notifOn(this, Prefs.N_BIG), (b, on) -> Prefs.setNotif(this, Prefs.N_BIG, on));
        h.addView(text("Kam az kam itne ki harkat par batao:", 12, SOFT));
        LinearLayout mr = row();
        String[] ml = {"$10M", "$50M", "$100M", "$500M", "$1B"};
        for (int i = 0; i < 5; i++) {
            final int idx = i;
            bigMinChips[i] = chip(ml[i], Prefs.bigMinUsd(this) == BIG_MINS[i]);
            bigMinChips[i].setOnClickListener(v -> {
                Prefs.setBigMinUsd(this, BIG_MINS[idx]);
                for (int k = 0; k < 5; k++) styleChip(bigMinChips[k], k == idx);
            });
            mr.addView(bigMinChips[i], chipLp());
        }
        h.addView(hscroll(mr));
        bigStatus = text("", 12, SOFT);
        h.addView(bigStatus);

        LinearLayout mv = card(col, ACC2);
        mv.addView(bold("⚡ Haal ki harkat (khareed / farokht)", 16, TEXT));
        bigMovesBox = column();
        mv.addView(bigMovesBox);

        bigBox = column();
        col.addView(bigBox);

        LinearLayout add = card(col);
        add.addView(bold("➕ Koi bhi bada wallet track karein", 15, TEXT));
        add.addView(text("Arkham / Etherscan se kisi whale, fund ya company ka public address le kar yahan daalein.", 12, MUTED));
        final EditText lbl = input("Naam (jaise: Whale #1)", "", InputType.TYPE_CLASS_TEXT);
        final EditText adr = input("Public address", "", InputType.TYPE_CLASS_TEXT);
        add.addView(lbl);
        add.addView(adr);
        Button ab = button("➕ Track karein", ACC, INK, 0);
        ab.setOnClickListener(v -> {
            String a = adr.getText().toString().trim();
            if (WalletTracker.securityCheck(a) != null || WalletTracker.detect(a) == null) { toast("Sahi public address daalein"); return; }
            try {
                JSONArray arr = Prefs.bigWallets(this);
                JSONObject o = new JSONObject();
                o.put("label", lbl.getText().toString().trim().isEmpty() ? WalletTracker.shortAddr(a) : lbl.getText().toString().trim());
                o.put("addr", a);
                arr.put(o);
                Prefs.saveBigWallets(this, arr);
            } catch (Exception ignored) {
            }
            adr.setText("");
            lbl.setText("");
            toast("Track ho raha hai ✅");
            loadBig();
        });
        add.addView(ab);
        TextView ark = chip("🔎 Arkham par bade wallets dhoondein", false);
        ark.setOnClickListener(v -> openUrl("https://intel.arkm.com/"));
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(-2, -2);
        al.topMargin = dp(6);
        add.addView(ark, al);
    }

    private void renderBigMoves() {
        bigMovesBox.removeAllViews();
        JSONArray a = Prefs.bigMoves(this);
        if (a.length() == 0) {
            bigMovesBox.addView(text("Abhi koi harkat record nahi hui. Pehli dafa data save hota hai — agli dafa se jo bhi khareede/beche woh yahan aur notification mein aayega.", 12, MUTED));
            return;
        }
        SimpleDateFormat f = new SimpleDateFormat("dd MMM HH:mm", Locale.US);
        for (int i = 0; i < a.length() && i < 25; i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            boolean buy = o.optBoolean("buy");
            bigMovesBox.addView(text((buy ? "🟢 " : "🔴 ") + o.optString("text"), 13, buy ? GREEN : RED));
            bigMovesBox.addView(text(f.format(new Date(o.optLong("t"))), 10, MUTED));
        }
    }

    private void loadBig() {
        bigLoadedAt = System.currentTimeMillis();
        bigStatus.setText("ETF, companies, governments aur wallets ka data aa raha hai...");
        pool.execute(() -> {
            final BigPlayers.Report r = BigPlayers.fetch(this, true);
            runOnUiThread(() -> renderBig(r));
        });
    }

    private String mUsd(double millions) {
        return BigPlayers.m(millions);
    }

    private void etfCard(String title, String date, double total, double day, List<BigPlayers.Row> rows) {
        if (rows.isEmpty()) return;
        LinearLayout c = card(bigBox, day >= 0 ? GREEN : RED);
        c.addView(bold(title, 16, TEXT));
        c.addView(text("Taaza din: " + date + " · sab ka total: " + mUsd(day)
                + (Double.isNaN(total) ? "" : " · launch se ab tak: " + mUsd(total)), 12, SOFT));
        LinearLayout hd = row();
        hd.addView(text("Fund", 11, MUTED), new LinearLayout.LayoutParams(0, -2, 1));
        hd.addView(text("Taaza din", 11, MUTED), new LinearLayout.LayoutParams(dp(90), -2));
        hd.addView(text("Launch se", 11, MUTED), new LinearLayout.LayoutParams(dp(90), -2));
        c.addView(hd);
        for (BigPlayers.Row r : rows) {
            LinearLayout rr = row();
            rr.setPadding(0, dp(4), 0, dp(4));
            LinearLayout nm = column();
            nm.addView(bold(r.name, 13, r.name.equals("BlackRock") ? 0xFFF0B90B : TEXT));
            nm.addView(text(r.sub, 10, MUTED));
            rr.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
            rr.addView(bold(r.change == 0 ? "—" : mUsd(r.change), 12, r.change > 0 ? GREEN : r.change < 0 ? RED : MUTED), new LinearLayout.LayoutParams(dp(90), -2));
            rr.addView(text(Double.isNaN(r.value) ? "—" : mUsd(r.value), 12, r.value >= 0 ? SOFT : RED), new LinearLayout.LayoutParams(dp(90), -2));
            c.addView(rr);
        }
    }

    private void holdersCard(String title, String sym, double total, List<BigPlayers.Row> rows, int max) {
        if (rows.isEmpty()) return;
        LinearLayout c = card(bigBox);
        c.addView(bold(title, 16, TEXT));
        c.addView(text("Kul: " + Fmt.num(total) + " " + sym + " · (+/−) = pichhli check se farq", 12, SOFT));
        for (int i = 0; i < rows.size() && i < max; i++) {
            BigPlayers.Row r = rows.get(i);
            LinearLayout rr = row();
            rr.setPadding(0, dp(4), 0, dp(4));
            LinearLayout nm = column();
            nm.addView(bold(r.name, 13, r.name.toLowerCase(Locale.US).contains("trump") ? 0xFFF0B90B : TEXT));
            nm.addView(text(r.sub, 10, MUTED));
            rr.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
            LinearLayout v = column();
            v.addView(text(Fmt.num(r.value) + " " + sym, 12, TEXT));
            v.addView(text(Fmt.usd(r.usd) + (r.change != 0 ? (r.change > 0 ? "  🟢 +" : "  🔴 −") + Fmt.num(Math.abs(r.change)) : ""), 10,
                    r.change > 0 ? GREEN : r.change < 0 ? RED : MUTED));
            rr.addView(v);
            c.addView(rr);
        }
    }

    private void renderBig(BigPlayers.Report r) {
        bigBox.removeAllViews();
        bigStatus.setText("Update: " + new SimpleDateFormat("HH:mm", Locale.US).format(new Date())
                + (r.events.isEmpty() ? " · koi nayi bari harkat nahi" : " · " + r.events.size() + " nayi harkat!"));
        renderBigMoves();
        etfCard("🏦 Bitcoin ETFs (BlackRock IBIT, Fidelity ...)", r.etfBtcDate, r.etfBtcTotal, r.etfBtcDay, r.etfBtc);
        etfCard("🏦 Ethereum ETFs (BlackRock ETHA ...)", r.etfEthDate, r.etfEthTotal, r.etfEthDay, r.etfEth);
        etfCard("🏦 Solana ETFs", r.etfSolDate, r.etfSolTotal, r.etfSolDay, r.etfSol);
        holdersCard("🏢 Companies ke paas BTC (Strategy, Trump Media ...)", "BTC", r.coBtcTotal, r.coBtc, 20);
        holdersCard("🏢 Companies ke paas ETH", "ETH", r.coEthTotal, r.coEth, 12);
        holdersCard("🏛️ Governments ke paas BTC", "BTC", r.govTotal, r.gov, 12);
        if (!r.wallets.isEmpty()) {
            LinearLayout c = card(bigBox, ACC2);
            c.addView(bold("🐋 Whale wallets (live blockchain)", 16, TEXT));
            for (BigPlayers.Row w : r.wallets) {
                LinearLayout rr = row();
                rr.setPadding(0, dp(4), 0, dp(4));
                LinearLayout nm = column();
                nm.addView(bold(w.name, 13, TEXT));
                nm.addView(text(w.sub, 10, MUTED));
                rr.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
                LinearLayout v = column();
                v.addView(text(Fmt.usd(w.usd), 13, TEXT));
                if (w.change != 0) v.addView(text((w.change > 0 ? "🟢 +" : "🔴 −") + Fmt.usd(Math.abs(w.change)), 10, w.change > 0 ? GREEN : RED));
                rr.addView(v);
                c.addView(rr);
            }
        }
        if (bigBox.getChildCount() == 0) {
            LinearLayout c = card(bigBox, RED);
            c.addView(text("Data nahi mila — internet check karke Refresh dabayen (CoinGecko kabhi busy hota hai).", 13, YELLOW));
        }
    }

    // ============================================================ LISTINGS tab
    private void buildListings() {
        LinearLayout col = pageColumn(TAB_LISTINGS);
        LinearLayout h = card(col, ACC);
        LinearLayout hr = row();
        hr.addView(bold("🆕 Nayi listings", 18, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView rf = chip("↻ Refresh", false);
        rf.setOnClickListener(v -> loadListings());
        hr.addView(rf);
        h.addView(hr);
        h.addView(text("Binance, Bybit, OKX aur KuCoin ke taaza listing announcements. Coin par tap karein: listing ka waqt, "
                + "listing se pehle ka volume, aur abhi kahan (DEX / doosre exchange) khareeda ja sakta hai.", 12, MUTED));
        listingStatus = text("", 12, SOFT);
        h.addView(listingStatus);
        listingBox = column();
        col.addView(listingBox);
        LinearLayout w = card(col);
        w.addView(text("⚠️ Nayi listing par price bahut tez upar neeche hoti hai. Listing se pehle DEX par khareedna khatarnak ho "
                + "sakta hai (nakli token, kam liquidity). Hamesha contract address exchange ke official announcement se milayen.", 12, MUTED));
    }

    private void loadListings() {
        listingStatus.setText("Load ho raha hai...");
        pool.execute(() -> {
            final List<Listings.Item> items = Listings.fetchAll();
            runOnUiThread(() -> renderListings(items));
        });
    }

    private static final int[] EX_COL = {0xFFF0B90B, 0xFFF7A600, 0xFFFFFFFF, 0xFF23AF91};

    private int exColor(String ex) {
        switch (ex) {
            case "Binance": return EX_COL[0];
            case "Bybit": return EX_COL[1];
            case "OKX": return EX_COL[2];
            default: return EX_COL[3];
        }
    }

    private void renderListings(List<Listings.Item> items) {
        listingsLoadedAt = System.currentTimeMillis();
        listingBox.removeAllViews();
        if (items.isEmpty()) {
            listingStatus.setText("Announcements nahi mile — internet check karke Refresh dabayen");
            return;
        }
        listingStatus.setText(items.size() + " announcements · " + new SimpleDateFormat("HH:mm", Locale.US).format(new Date()));
        SimpleDateFormat f = new SimpleDateFormat("dd MMM HH:mm", Locale.US);
        long now = System.currentTimeMillis();
        for (final Listings.Item it : items) {
            LinearLayout c = card(listingBox, exColor(it.exchange));
            LinearLayout hr = row();
            TextView ex = bold(it.exchange, 11, INK);
            ex.setPadding(dp(7), dp(2), dp(7), dp(2));
            ex.setBackground(round(exColor(it.exchange), 8, 0));
            hr.addView(ex);
            TextView coin = bold("  " + (it.coin.isEmpty() ? "" : it.coin), 17, TEXT);
            hr.addView(coin, new LinearLayout.LayoutParams(0, -2, 1));
            if (it.listTime > 0) {
                long left = it.listTime - now;
                String when = left > 0 ? "⏰ " + countdown(left) + " baad" : "✅ list ho chuka";
                hr.addView(bold(when, 12, left > 0 ? YELLOW : GREEN));
            }
            c.addView(hr);
            c.addView(text(it.title, 13, SOFT));
            String meta = "Announce: " + (it.announced > 0 ? f.format(new Date(it.announced)) : "?");
            if (it.listTime > 0) meta += " · Listing: " + f.format(new Date(it.listTime)) + " (aap ka waqt)";
            c.addView(text(meta, 11, MUTED));
            final LinearLayout detail = column();
            c.addView(detail);
            LinearLayout br = row();
            if (!it.coin.isEmpty()) {
                TextView d = chip("🔎 Kahan se khareedain / volume", true);
                d.setOnClickListener(v -> listingDetail(it, detail));
                br.addView(d, chipLp());
            }
            TextView an = chip("📄 Announcement", false);
            an.setOnClickListener(v -> openUrl(it.url));
            br.addView(an, chipLp());
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-2, -2);
            bl.topMargin = dp(6);
            c.addView(hscroll(br), bl);
        }
    }

    private static String countdown(long ms) {
        long m = ms / 60000;
        if (m >= 1440) return (m / 1440) + "d " + (m % 1440) / 60 + "h";
        if (m >= 60) return (m / 60) + "h " + (m % 60) + "m";
        return m + "m";
    }

    private void listingDetail(final Listings.Item it, final LinearLayout box) {
        box.removeAllViews();
        box.addView(text("⏳ " + it.coin + " ke markets dhoond raha hoon (DexScreener + CoinGecko)...", 12, MUTED));
        pool.execute(() -> {
            final List<Listings.Market> ms = Listings.markets(it.coin);
            boolean onBinance = false;
            try {
                Scanner.get("/api/v3/ticker/price?symbol=" + it.coin + "USDT");
                onBinance = true;
            } catch (Exception ignored) {
            }
            final boolean bn = onBinance;
            runOnUiThread(() -> {
                box.removeAllViews();
                double tot = 0, dexTot = 0;
                for (Listings.Market m : ms) {
                    tot += m.vol24;
                    if (m.dex) dexTot += m.vol24;
                }
                box.addView(bold(it.coin + " — abhi kahan trade ho raha hai", 14, TEXT));
                if (ms.isEmpty()) {
                    box.addView(text("Abhi kisi DEX ya exchange par nahi mila — shayad pehli dafa list ho raha hai.", 12, YELLOW));
                } else {
                    box.addView(text("24h total volume (listing se pehle/abhi): " + Fmt.usd(tot) + " · DEX par " + Fmt.usd(dexTot), 12, SOFT));
                }
                for (final Listings.Market m : ms) {
                    LinearLayout r = row();
                    r.setPadding(0, dp(6), 0, dp(6));
                    LinearLayout l = column();
                    l.addView(bold((m.dex ? "🦄 " : "🏦 ") + m.venue, 13, TEXT));
                    l.addView(text(m.pair + (m.liquidity > 0 ? " · liquidity " + Fmt.usd(m.liquidity) : ""), 11, MUTED));
                    r.addView(l, new LinearLayout.LayoutParams(0, -2, 1));
                    LinearLayout rt = column();
                    rt.addView(text(m.priceUsd > 0 ? "$" + Fmt.price(m.priceUsd) : "-", 12, TEXT));
                    rt.addView(text("vol " + Fmt.usd(m.vol24), 11, MUTED));
                    r.addView(rt);
                    if (m.url != null && !m.url.isEmpty()) r.setOnClickListener(v -> openUrl(m.url));
                    box.addView(r);
                    box.addView(divider());
                }
                if (bn) {
                    TextView a = chip("📈 " + it.coin + " ka live chart + analysis", true);
                    a.setOnClickListener(v -> openAnalyze(it.coin + "USDT"));
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
                    lp.topMargin = dp(6);
                    box.addView(a, lp);
                }
                TextView b = chip("🟡 Binance app mein kholen", false);
                b.setOnClickListener(v -> BinanceLink.open(this, it.coin, false));
                LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(-2, -2);
                lp2.topMargin = dp(6);
                box.addView(b, lp2);
                box.addView(text("Row par tap = us DEX / exchange ka page khulega.", 11, MUTED));
            });
        });
    }

    // ============================================================ SIGNAL screen (live chart for one signal)
    private void openSignalView(final JSONObject o) {
        closeSignalView();
        final String sym = o.optString("sym");
        final boolean buy = "BUY".equals(o.optString("side"));
        final int m = o.optInt("mode", Mode.SPOT);
        final String tf = o.optString("tf", m == Mode.SCALP ? "5m" : "4h");
        final double entry = o.optDouble("entry", o.optDouble("price", 0));
        final double sl = o.optDouble("sl", 0), tp1 = o.optDouble("tp", 0), tp2 = o.optDouble("tp2", 0);
        final double zlo = o.optDouble("zlo", 0), zhi = o.optDouble("zhi", 0);
        final int col = buy ? GREEN : RED;

        sigOverlay = column();
        sigOverlay.setTag(o);
        sigOverlay.setBackgroundColor(Mode.bgTop(uiMode));
        ScrollView sv = new ScrollView(this);
        LinearLayout c = column();
        c.setPadding(dp(12), dp(10), dp(12), dp(24));
        sv.addView(c);
        sigOverlay.addView(sv, new LinearLayout.LayoutParams(-1, -1));

        LinearLayout hr = row();
        hr.addView(bold((buy ? "🟢 BUY  " : "🔴 SELL  ") + base(sym) + "/USDT", 20, col), new LinearLayout.LayoutParams(0, -2, 1));
        TextView mb = bold(Mode.label(m) + " · " + tf, 11, INK);
        mb.setPadding(dp(7), dp(3), dp(7), dp(3));
        mb.setBackground(round(Mode.accent(m), 10, 0));
        hr.addView(mb);
        TextView x = chip("✕", true);
        x.setOnClickListener(v -> closeSignalView());
        LinearLayout.LayoutParams xl = new LinearLayout.LayoutParams(-2, -2);
        xl.leftMargin = dp(8);
        hr.addView(x, xl);
        c.addView(hr);

        final TextView livePx = bold("Live price load ho rahi hai...", 15, TEXT);
        c.addView(livePx);
        String adv = o.optString("adv", "");
        if (!adv.isEmpty()) {
            TextView at = bold(adv, 16, col);
            at.setPadding(0, dp(6), 0, 0);
            c.addView(at);
            String aw = o.optString("advWhy", "");
            if (!aw.isEmpty()) c.addView(text(aw, 13, SOFT));
        }
        LinearLayout lv = card(c, col);
        if (zhi > 0) lv.addView(text((buy ? "BUY" : "SELL") + " zone: $" + Fmt.price(zlo) + " – $" + Fmt.price(zhi), 14, TEXT));
        lv.addView(text("Entry: $" + Fmt.price(entry), 14, TEXT));
        if (sl > 0) lv.addView(text("🛑 SL: $" + Fmt.price(sl) + pctFrom(sl, entry), 14, RED));
        if (tp1 > 0) lv.addView(text("🎯 TP1: $" + Fmt.price(tp1) + pctFrom(tp1, entry), 14, GREEN));
        if (tp2 > 0) lv.addView(text("🎯 TP2: $" + Fmt.price(tp2) + pctFrom(tp2, entry), 14, GREEN));
        String st = o.optString("st", "open");
        lv.addView(bold(st.equals("win") ? "✅ Target hit ho chuka" : st.equals("loss") ? "❌ Stop-loss hit ho chuka"
                : st.equals("expired") ? "⌛ Waqt khatam" : "⏳ Signal abhi khula hai", 13, st.equals("win") ? GREEN : st.equals("loss") ? RED : YELLOW));

        final ChartView sc = new ChartView(this);
        sc.setAccent(Mode.accent(m));
        sc.setLayers(false, true, false, false, true, false);
        sc.setMessage("Live chart load ho raha hai...");
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, dp(430));
        cl.topMargin = dp(10);
        c.addView(sc, cl);
        c.addView(text("Sirf zaroori cheezein: " + (buy ? "BUY" : "SELL") + " zone, SL, TP1/TP2, trendlines aur pattern · "
                + "ungli se khiskayen / zoom · price patti par upar-neeche = scale · 2x tap = reset", 11, MUTED));

        Button an = button("📈 Poora analysis dekhen", Mode.accent(m), INK, 0);
        an.setOnClickListener(v -> {
            closeSignalView();
            openAnalyze(sym);
        });
        c.addView(an);
        Button bn = button("🟡 Binance app mein kholen", 0xFFF0B90B, INK, 0);
        bn.setOnClickListener(v -> BinanceLink.open(this, base(sym), m == Mode.SCALP && !buy));
        c.addView(bn);
        c.addView(text(o.optString("why"), 12, SOFT));

        rootFrame.addView(sigOverlay, new FrameLayout.LayoutParams(-1, -1));

        sigLive = new LiveChart(sc, handler);
        pool.execute(() -> {
            try {
                final Candles cd = Candles.fetch(sym, tf, 300, false);
                final PatternEngine.Result p = PatternEngine.analyze(cd.closedOnly(), Math.min(150, cd.n));
                runOnUiThread(() -> {
                    if (sigOverlay == null) return;
                    sc.setData(cd, p, new double[cd.n], new double[cd.n], tf, tf.endsWith("m"));
                    sc.setPlan(entry > 0, buy, entry, sl, tp1, tp2);
                    if (zhi > 0) sc.setZone(zlo, zhi, buy ? "BUY ZONE" : "SELL ZONE", col);
                    sigLive.start(sym, tf, Prefs.whaleUsd(this), price -> {
                        double pnl = entry > 0 ? (buy ? price / entry - 1 : 1 - price / entry) * 100 : 0;
                        livePx.setText(String.format(Locale.US, "Live $%s  ·  entry se %+.2f%%", Fmt.price(price), pnl));
                        livePx.setTextColor(pnl >= 0 ? GREEN : RED);
                    });
                });
            } catch (Exception e) {
                final String msg = e.getMessage();
                runOnUiThread(() -> sc.setMessage("Chart nahi mila: " + msg));
            }
        });
    }

    private void closeSignalView() {
        if (sigLive != null) sigLive.stop();
        sigLive = null;
        if (sigOverlay != null) rootFrame.removeView(sigOverlay);
        sigOverlay = null;
    }

    // ============================================================ SIGNALS tab
    private void buildSignals() {
        LinearLayout col = pageColumn(2);
        LinearLayout st = card(col, ACC);
        st.addView(bold("🤖 24/7 Signal Bots", 17, TEXT));
        st.addView(text("Scalp aur Spot bot alag alag ON/OFF karein. Dono saath bhi chal sakte hain.", 12, MUTED));
        scalpBtn = button("", Mode.accent(Mode.SCALP), INK, 0);
        scalpBtn.setOnClickListener(v -> toggleMode(Mode.SCALP));
        st.addView(scalpBtn);
        spotBtn = button("", Mode.accent(Mode.SPOT), INK, 0);
        spotBtn.setOnClickListener(v -> toggleMode(Mode.SPOT));
        st.addView(spotBtn);
        statusView = text("", 13, MUTED);
        st.addView(statusView);
        Button bat = button("🔋 Battery restriction hatayen (zaroori)", CARD, ACC, ACC);
        bat.setOnClickListener(v -> askBattery());
        st.addView(bat);

        LinearLayout ac = card(col, ACC2);
        ac.addView(bold("🔔 Price alerts", 16, TEXT));
        ac.addView(text("Analyze tab se alert lagayen · hatane ke liye alert par tap karein", 12, MUTED));
        alertList = column();
        ac.addView(alertList);

        LinearLayout sc = card(col);
        LinearLayout hr = row();
        hr.addView(bold("📡 Signals", 17, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        TextView clr = chip("Clear", false);
        clr.setOnClickListener(v -> {
            Prefs.clearSignals(this);
            renderSignals(true);
        });
        hr.addView(clr);
        sc.addView(hr);
        statsView = bold("", 13, ACC2);
        sc.addView(statsView);
        sc.addView(text("Har signal ka asal nateeja bot khud check karta hai: ✅ target hit · ❌ stop hit · ⌛ waqt khatam. "
                + "Signal par tap karein — us ka apna LIVE chart khulega: BUY/SELL zone, SL, TP aur trendline.", 12, MUTED));
        signalList = column();
        sc.addView(signalList);
    }

    private void toggleMode(int m) {
        boolean on = !Prefs.modeOn(this, m);
        Prefs.setModeOn(this, m, on);
        if (Prefs.enabled(this)) {
            startForegroundService(new Intent(this, ScannerService.class));
        } else {
            startService(new Intent(this, ScannerService.class).setAction(ScannerService.ACTION_STOP));
        }
        toast(Mode.label(m) + " bot " + (on ? "ON ✅" : "OFF"));
        handler.postDelayed(this::refreshStatus, 300);
    }

    private void renderAlerts() {
        alertList.removeAllViews();
        JSONArray a = Prefs.alerts(this);
        if (a.length() == 0) {
            alertList.addView(text("Koi alert nahi", 13, MUTED));
            return;
        }
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            final int idx = i;
            boolean above = o.optBoolean("above");
            TextView t = bold((above ? "⬆ " : "⬇ ") + base(o.optString("sym")) + "  " + (above ? "upar jaye " : "neeche aaye ")
                    + "$" + Fmt.price(o.optDouble("price")) + "   ✕", 14, above ? GREEN : RED);
            t.setPadding(0, dp(6), 0, dp(6));
            t.setOnClickListener(v -> {
                List<Integer> l = new ArrayList<>();
                l.add(idx);
                Prefs.removeAlerts(this, l);
                renderAlerts();
            });
            alertList.addView(t);
        }
    }

    private void renderSignals(boolean force) {
        JSONArray arr = Prefs.signals(this);
        JSONObject first = arr.optJSONObject(0);
        StringBuilder kb = new StringBuilder().append(arr.length()).append(':').append(first == null ? 0 : first.optLong("t"));
        int[] st = Scanner.signalStats(arr);
        kb.append(':').append(st[0]).append(st[1]).append(st[2]);
        String key = kb.toString();
        if (!force && key.equals(signalKey)) return;
        signalKey = key;
        int done = st[0] + st[1];
        statsView.setText(done > 0
                ? String.format(Locale.US, "🏆 Win rate %.0f%%  ·  ✅ %d  ❌ %d  ⌛ %d  ⏳ %d open", st[0] * 100.0 / done, st[0], st[1], st[2], st[3])
                : "🏆 Win rate: abhi koi signal mukammal nahi hua (" + st[3] + " open)");
        signalList.removeAllViews();
        if (arr.length() == 0) {
            signalList.addView(text("Abhi koi signal nahi. Upar se Scalp ya Spot bot ON karein — signal aate hi notification aa jayegi.", 13, MUTED));
            return;
        }
        SimpleDateFormat f = new SimpleDateFormat("dd MMM HH:mm", Locale.US);
        for (int i = 0; i < arr.length() && i < 60; i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            final boolean buy = "BUY".equals(o.optString("side"));
            final String sym = o.optString("sym");
            int m = o.optInt("mode", Mode.SPOT);
            LinearLayout item = column();
            item.setPadding(dp(12), dp(10), dp(12), dp(10));
            item.setBackground(round(buy ? 0x1A0ECB81 : 0x1AF6465D, 12, buy ? 0x550ECB81 : 0x55F6465D));
            LinearLayout hr = row();
            hr.addView(bold((buy ? "🟢 BUY  " : "🔴 SELL  ") + base(sym) + "/USDT", 15, buy ? GREEN : RED),
                    new LinearLayout.LayoutParams(0, -2, 1));
            String s = o.optString("st", "");
            String res = s.equals("win") ? String.format(Locale.US, "✅ WIN %+.1f%%", o.optDouble("pnl"))
                    : s.equals("loss") ? String.format(Locale.US, "❌ LOSS %+.1f%%", o.optDouble("pnl"))
                    : s.equals("expired") ? String.format(Locale.US, "⌛ %+.1f%%", o.optDouble("pnl"))
                    : s.equals("open") ? "⏳ open" : "";
            if (!res.isEmpty()) {
                TextView rv = bold(res, 11, s.equals("win") ? GREEN : s.equals("loss") ? RED : YELLOW);
                rv.setPadding(0, 0, dp(6), 0);
                hr.addView(rv);
            }
            TextView mb = bold(Mode.label(m), 10, INK);
            mb.setPadding(dp(6), dp(2), dp(6), dp(2));
            mb.setBackground(round(Mode.accent(m), 8, 0));
            hr.addView(mb);
            item.addView(hr);
            item.addView(text("$" + Fmt.price(o.optDouble("price")) + " · score " + o.optInt("score") + " · "
                    + f.format(new Date(o.optLong("t"))), 12, MUTED));
            String advT = o.optString("adv", "");
            if (!advT.isEmpty()) item.addView(bold(advT, 13, buy ? GREEN : RED));
            String whyT = o.optString("why");
            if (!advT.isEmpty() && whyT.startsWith(advT)) whyT = whyT.substring(advT.length()).trim();
            item.addView(text(whyT, 12, SOFT));
            final JSONObject sig = o;
            item.setOnClickListener(v -> openSignalView(sig));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(8);
            signalList.addView(item, lp);
        }
    }

    private void refreshStatus() {
        boolean sc = Prefs.modeOn(this, Mode.SCALP), sp = Prefs.modeOn(this, Mode.SPOT);
        boolean on = sc || sp;
        liveDot.setText(on ? "● LIVE" : "○ OFF");
        liveDot.setTextColor(on ? GREEN : MUTED);
        statusView.setText(on ? Prefs.status(this) : "Dono bots band hain");
        scalpBtn.setText(sc ? "⏹  ⚡ SCALP bot ON — band karein" : "▶  ⚡ SCALP bot start karein");
        scalpBtn.setBackground(round(sc ? Mode.accent(Mode.SCALP) : CHIP, 14, Mode.accent(Mode.SCALP)));
        scalpBtn.setTextColor(sc ? INK : Mode.accent(Mode.SCALP));
        spotBtn.setText(sp ? "⏹  💎 SPOT bot ON — band karein" : "▶  💎 SPOT bot start karein");
        spotBtn.setBackground(round(sp ? Mode.accent(Mode.SPOT) : CHIP, 14, Mode.accent(Mode.SPOT)));
        spotBtn.setTextColor(sp ? INK : Mode.accent(Mode.SPOT));
        if (currentTab == 2) renderSignals(false);
    }

    private void askBattery() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm.isIgnoringBatteryOptimizations(getPackageName())) {
                toast("Pehle se unrestricted hai ✅");
                return;
            }
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception ignored) {
            }
        }
    }

    // ============================================================ SETTINGS tab
    private EditText field(LinearLayout parent, String label, String value, int inputType) {
        parent.addView(text(label, 13, MUTED));
        EditText e = input("", value, inputType);
        parent.addView(e);
        return e;
    }

    private EditText numField(LinearLayout parent, String label, int value) {
        return field(parent, label, String.valueOf(value), InputType.TYPE_CLASS_NUMBER);
    }

    private CheckBox check(LinearLayout parent, String label, boolean on) {
        CheckBox cb = new CheckBox(this);
        cb.setText(label);
        cb.setTextColor(TEXT);
        cb.setChecked(on);
        parent.addView(cb);
        return cb;
    }

    // ------------------------------------------------------------ settings building blocks
    /** Collapsible settings section (tap the header to open / close). Returns the body. */
    private LinearLayout section(LinearLayout col, String title, String sub, int color, boolean open) {
        LinearLayout c = card(col, color);
        LinearLayout head = row();
        head.addView(bold(title, 16, TEXT), new LinearLayout.LayoutParams(0, -2, 1));
        final TextView arrow = bold(open ? "▾" : "▸", 20, color);
        head.addView(arrow);
        c.addView(head);
        if (sub != null) c.addView(text(sub, 12, MUTED));
        final LinearLayout body = column();
        body.setVisibility(open ? View.VISIBLE : View.GONE);
        c.addView(body);
        head.setOnClickListener(v -> {
            boolean o = body.getVisibility() != View.VISIBLE;
            body.setVisibility(o ? View.VISIBLE : View.GONE);
            arrow.setText(o ? "▾" : "▸");
        });
        return body;
    }

    /** A real-app style ON/OFF row that saves immediately. */
    private Switch toggle(LinearLayout parent, String label, String sub, boolean on, CompoundButton.OnCheckedChangeListener l) {
        LinearLayout r = row();
        r.setPadding(0, dp(8), 0, dp(8));
        LinearLayout t = column();
        t.addView(bold(label, 14, TEXT));
        if (sub != null) t.addView(text(sub, 11, MUTED));
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        Switch sw = new Switch(this);
        sw.setChecked(on);
        sw.setOnCheckedChangeListener(l);
        r.addView(sw);
        parent.addView(r);
        parent.addView(divider());
        return sw;
    }

    private void buildSettings() {
        LinearLayout col = pageColumn(TAB_SETTINGS);
        String ver = "?";
        try {
            ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
        }

        // ---- header / quick controls
        LinearLayout head = card(col, ACC);
        LinearLayout hr = row();
        TextView logo = bold("N", 26, INK);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(round(ACC, 14, 0));
        hr.addView(logo, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout ht = column();
        ht.setPadding(dp(12), 0, 0, 0);
        ht.addView(bold("Nohman Trading Bot", 17, TEXT));
        ht.addView(text("Version " + ver + " · " + Mode.label(uiMode) + " screen", 12, MUTED));
        hr.addView(ht, new LinearLayout.LayoutParams(0, -2, 1));
        head.addView(hr);
        toggle(head, "⚡ Scalp bot", "1m–15m signals, 24/7", Prefs.modeOn(this, Mode.SCALP), (b, on) -> {
            if (on != Prefs.modeOn(this, Mode.SCALP)) toggleMode(Mode.SCALP);
        });
        toggle(head, "💎 Spot bot", "1h–1d signals, 24/7", Prefs.modeOn(this, Mode.SPOT), (b, on) -> {
            if (on != Prefs.modeOn(this, Mode.SPOT)) toggleMode(Mode.SPOT);
        });
        LinearLayout mr = row();
        mr.setPadding(0, dp(8), 0, 0);
        mr.addView(text("App ka rang / screens:", 13, SOFT), new LinearLayout.LayoutParams(0, -2, 1));
        for (int m = 0; m < 2; m++) {
            final int mm = m;
            TextView c = chip(Mode.label(m), m == uiMode);
            c.setOnClickListener(v -> switchMode(mm));
            mr.addView(c, chipLp());
        }
        head.addView(mr);

        // ---- per-mode bot settings
        for (int m = 0; m < 2; m++) {
            LinearLayout b = section(col, Mode.label(m) + " bot settings", Mode.desc(m), Mode.accent(m), false);
            modeSettings(b, m);
        }

        // ---- notifications
        LinearLayout n = section(col, "🔔 Notifications", "Kaun si notification aaye, kab na aaye", ACC2, false);
        toggle(n, "📡 Buy / Sell signals", "Scalp aur Spot bots ke signals", Prefs.notifOn(this, Prefs.N_SIGNALS), (b, on) -> Prefs.setNotif(this, Prefs.N_SIGNALS, on));
        toggle(n, "🔔 Price alerts", "Aap ke lagaye hue price levels", Prefs.notifOn(this, Prefs.N_ALERTS), (b, on) -> Prefs.setNotif(this, Prefs.N_ALERTS, on));
        toggle(n, "💼 Mere wallets", "Balance badhe ya ghate", Prefs.notifOn(this, Prefs.N_WALLET), (b, on) -> Prefs.setNotif(this, Prefs.N_WALLET, on));
        toggle(n, "🐋 Bade log (ETF / companies / whales)", "Million/billion ki khareed-farokht", Prefs.notifOn(this, Prefs.N_BIG), (b, on) -> Prefs.setNotif(this, Prefs.N_BIG, on));
        toggle(n, "🔄 App updates", "Naya version aaye to batao", Prefs.notifOn(this, Prefs.N_UPDATE), (b, on) -> Prefs.setNotif(this, Prefs.N_UPDATE, on));
        minConfEt = numField(n, "Signal tabhi bhejo jab confidence kam az kam (%) ho — 0 = sab", Prefs.minConfidence(this));
        quietCb = check(n, "🌙 Quiet hours — is waqt koi notification nahi", Prefs.quietOn(this));
        LinearLayout qr = row();
        LinearLayout q1 = column(), q2 = column();
        q1.addView(text("Se (ghanta 0–23)", 11, MUTED));
        quietFromEt = input("", String.valueOf(Prefs.quietFrom(this)), InputType.TYPE_CLASS_NUMBER);
        q1.addView(quietFromEt);
        q2.addView(text("Tak (ghanta 0–23)", 11, MUTED));
        quietToEt = input("", String.valueOf(Prefs.quietTo(this)), InputType.TYPE_CLASS_NUMBER);
        q2.addView(quietToEt);
        qr.addView(q1, new LinearLayout.LayoutParams(0, -2, 1));
        qr.addView(new View(this), new LinearLayout.LayoutParams(dp(10), 1));
        qr.addView(q2, new LinearLayout.LayoutParams(0, -2, 1));
        n.addView(qr);
        TextView sys = chip("📱 Android notification settings (awaaz / vibration)", false);
        sys.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()));
            } catch (Exception e) {
                toast("Settings nahi khuli");
            }
        });
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-2, -2);
        sl.topMargin = dp(8);
        n.addView(sys, sl);

        // ---- signal engine
        LinearLayout e = section(col, "🎛️ Signal engine", "Signal kitne sakht hon, kaun se data use ho", ACC, false);
        btcCb = check(e, "BTC filter: jab BTC bearish ho to BUY signal na do", Prefs.btcFilter(this));
        smartCb = check(e, "🐋 Smart money: whale trades, top traders, open interest", Prefs.smartMoney(this));
        strongCb = check(e, "🎯 Strong signal: SAB sources (10 exchanges, ETF, on-chain, patterns) se confirm karo", Prefs.strongConfirm(this));
        whaleEt = numField(e, "Whale trade kitne USD se bada ho (e.g. 50000)", Prefs.whaleUsd(this));

        // ---- Claude AI
        LinearLayout ai = section(col, "🤖 Claude AI Analyst", "Roman Urdu mein trade plan aur sawal-jawab", CLAUDE, false);
        claudeEt = field(ai, "Claude API key (sk-ant-...)", Prefs.claudeKey(this),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        ai.addView(text("Model", 13, MUTED));
        modelSpinner = new Spinner(this);
        modelSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, ClaudeAI.MODELS));
        for (int i = 0; i < ClaudeAI.MODELS.length; i++) if (ClaudeAI.MODELS[i].equals(Prefs.claudeModel(this))) modelSpinner.setSelection(i);
        ai.addView(modelSpinner);
        ai.addView(text("Sonnet = behtareen balance · Opus = sab se gehri soch (mehenga) · Haiku = sab se tez aur sasta", 11, MUTED));
        TextView link = chip("🔑 Key kahan se milegi? (console.anthropic.com)", false);
        link.setOnClickListener(v -> openUrl("https://console.anthropic.com/settings/keys"));
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(-2, -2);
        llp.topMargin = dp(6);
        ai.addView(link, llp);

        // ---- API keys
        LinearLayout k = section(col, "🔑 API keys (optional)", "Paid data sources", STROKE, false);
        glassEt = field(k, "Glassnode API key (sirf paid plan par milti hai)", Prefs.glassKey(this),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        // ---- update
        LinearLayout up = section(col, "🔄 App update", "Aap ka version: " + ver, GREEN, false);
        up.addView(text("Naya version GitHub par banta hai to app khud bata deti hai — phir sirf 'Install' dabana hai.", 12, MUTED));
        repoEt = field(up, "GitHub repo (owner/naam)", Prefs.updateRepo(this), InputType.TYPE_CLASS_TEXT);
        updStatus = text("", 13, SOFT);
        up.addView(updStatus);
        Button chk = button("🔍 Update check karein", GREEN, INK, 0);
        chk.setOnClickListener(v -> {
            Prefs.setUpdateRepo(this, repoEt.getText().toString());
            checkForUpdate(true);
        });
        up.addView(chk);

        // ---- battery & background
        LinearLayout bt = section(col, "🔋 Battery & background", "Bot 24/7 chalne ke liye zaroori", YELLOW, false);
        bt.addView(text("Xiaomi, Oppo, Vivo, Infinix, Tecno, Samsung waghera mein: Battery = 'No restrictions' aur Autostart = ON karein.", 12, SOFT));
        Button bb = button("🔋 Battery restriction hatayen", CARD, YELLOW, YELLOW);
        bb.setOnClickListener(v -> askBattery());
        bt.addView(bb);
        Button ap = button("📱 App info kholen (Autostart / permissions)", CARD, TEXT, STROKE);
        ap.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:" + getPackageName())));
            } catch (Exception ex) {
                toast("Nahi khula");
            }
        });
        bt.addView(ap);

        // ---- data & privacy
        LinearLayout dpv = section(col, "🧹 Data & privacy", "Sab data sirf aap ke phone mein rehta hai", RED, false);
        dpv.addView(text("• Koi account / login nahi · koi data hamare server par nahi jata\n"
                + "• Wallet tracker sirf PUBLIC address dekhta hai — seed phrase / private key kabhi nahi maangta\n"
                + "• API keys sirf is phone mein save hoti hain", 12, SOFT));
        confirmButton(dpv, "🗑 Saare signals mitayen", () -> { Prefs.clearSignals(this); renderSignals(true); });
        confirmButton(dpv, "🗑 Bade log ki history mitayen", () -> { Prefs.saveBigSnap(this, new JSONObject()); });
        confirmButton(dpv, "🗑 Saare wallets hatayen", () -> { Prefs.saveWallets(this, new JSONArray()); loadWallets(); });
        confirmButton(dpv, "↺ Settings default par wapas", () -> { Prefs.resetSettings(this); recreate(); });

        // ---- about
        LinearLayout ab = section(col, "ℹ️ About & data sources", null, STROKE, false);
        ab.addView(text("• Binance WebSocket: live price, candles, har trade, order book\n"
                + "• 10 exchanges ka buy/sell volume: Binance, OKX, Bybit, Coinbase, Kraken, KuCoin, Gate, Bitget\n"
                + "• ETF flows (BlackRock, Fidelity ...): Farside Investors\n"
                + "• Companies / governments holdings: CoinGecko\n"
                + "• Wallets: mempool.space, Ethplorer, BNB Chain RPC, TronGrid, Solana RPC, Blockchair\n"
                + "• On-chain: DefiLlama, Blockchain.com, Coin Metrics, Coinbase premium\n"
                + "• Listings: Binance, Bybit, OKX, KuCoin announcements · DexScreener\n"
                + "• Futures: Binance open interest, top traders, funding · Fear & Greed · News", 12, SOFT));
        ab.addView(text("⚠️ Signals sirf maloomat ke liye hain, financial advice nahi. Bot khud koi trade nahi karta.", 12, MUTED));

        Button save = button("💾 Save all settings", ACC, INK, 0);
        save.setOnClickListener(v -> saveSettings());
        LinearLayout.LayoutParams svl = new LinearLayout.LayoutParams(-1, dp(54));
        svl.topMargin = dp(14);
        col.addView(save, svl);
    }

    /** Button that needs two taps (safety for destructive actions). */
    private void confirmButton(LinearLayout parent, String label, final Runnable action) {
        final Button b = button(label, CARD, RED, RED);
        final long[] armed = {0};
        b.setOnClickListener(v -> {
            long now = System.currentTimeMillis();
            if (now - armed[0] < 3000) {
                action.run();
                b.setText("✅ Ho gaya");
                armed[0] = 0;
            } else {
                armed[0] = now;
                b.setText("Pakka? Dobara dabayen");
                handler.postDelayed(() -> b.setText(label), 3000);
            }
        });
        parent.addView(b);
    }

    private void modeSettings(LinearLayout c, int m) {
        EditText[] f = new EditText[7];
        f[0] = numField(c, "Har kitne minute baad scan", Prefs.intervalMin(this, m));
        c.addView(text("Scan candle timeframe", 13, MUTED));
        String[] tfs = Mode.scanTfs(m);
        Spinner sp = new Spinner(this);
        sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, tfs));
        for (int i = 0; i < tfs.length; i++) if (tfs[i].equals(Prefs.timeframe(this, m))) sp.setSelection(i);
        c.addView(sp);
        tfSpinners[m] = sp;
        f[1] = numField(c, "Kitne top coins (volume ke hisaab se, max 400)", Prefs.topCoins(this, m));
        f[2] = numField(c, "Kam az kam 24h volume (million USDT)", Prefs.minVolMillion(this, m));
        f[3] = numField(c, "BUY score threshold (zyada = kam magar pakke)", Prefs.buyThreshold(this, m));
        f[4] = numField(c, "SELL score threshold", Prefs.sellThreshold(this, m));
        f[5] = field(c, "Volume spike = average ka kitna guna", String.valueOf(Prefs.volMult(this, m)),
                InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        f[6] = numField(c, "Ek coin ka dobara signal kitne minute baad", Prefs.cooldownMin(this, m));
        modeFields[m] = f;
        final int mm = m;
        TextView preset = chip("↺ Recommended " + (m == Mode.SCALP ? "scalp" : "spot") + " values", false);
        preset.setOnClickListener(v -> {
            int[] vals = mm == Mode.SCALP ? new int[]{1, 60, 10, 6, 4, 30} : new int[]{15, 150, 5, 7, 5, 240};
            modeFields[mm][0].setText(String.valueOf(vals[0]));
            modeFields[mm][1].setText(String.valueOf(vals[1]));
            modeFields[mm][2].setText(String.valueOf(vals[2]));
            modeFields[mm][3].setText(String.valueOf(vals[3]));
            modeFields[mm][4].setText(String.valueOf(vals[4]));
            modeFields[mm][5].setText(mm == Mode.SCALP ? "1.8" : "2.0");
            modeFields[mm][6].setText(String.valueOf(vals[5]));
            tfSpinners[mm].setSelection(2);
            toast("Recommended values bhar di — neeche Save dabayen");
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = dp(8);
        c.addView(preset, lp);
    }

    private int num(EditText e, int def) {
        try {
            return Integer.parseInt(e.getText().toString().trim());
        } catch (Exception x) {
            return def;
        }
    }

    private void saveSettings() {
        for (int m = 0; m < 2; m++) {
            EditText[] f = modeFields[m];
            float vm;
            try {
                vm = Float.parseFloat(f[5].getText().toString().trim());
            } catch (Exception x) {
                vm = 2.0f;
            }
            Prefs.saveMode(this, m, num(f[0], Prefs.intervalMin(this, m)), Mode.scanTfs(m)[tfSpinners[m].getSelectedItemPosition()],
                    num(f[1], 100), num(f[2], 5), num(f[3], 7), num(f[4], 5), vm, num(f[6], 120));
        }
        Prefs.saveCommon(this, btcCb.isChecked(), smartCb.isChecked(), strongCb.isChecked(),
                num(whaleEt, 50000), glassEt.getText().toString());
        Prefs.saveClaude(this, claudeEt.getText().toString(), ClaudeAI.MODELS[modelSpinner.getSelectedItemPosition()]);
        Prefs.setUpdateRepo(this, repoEt.getText().toString());
        Prefs.setMinConfidence(this, num(minConfEt, 0));
        Prefs.saveQuiet(this, quietCb.isChecked(), num(quietFromEt, 0), num(quietToEt, 7));
        toast("Saved ✅ — agla scan naye settings se hoga");
    }
}
