package com.signal.bot;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * LIVE trading chart. Candles update every second from the WebSocket, whale trades drop onto the
 * candle they happen in, and the analysis is drawn on top: Fibonacci, trendlines + pattern box +
 * projected arrow, S/R zones, volume profile, whale/retail markers, candle patterns, EMA20/50, VWAP,
 * entry/stop/target lines, buy/sell volume and an RSI panel with divergence.
 *
 * Gestures: drag = scroll back in time · pinch = zoom · press & hold = crosshair with candle details.
 */
public class ChartView extends View {
    private static final int UP = 0xFF0ECB81, DOWN = 0xFFF6465D, GRID = 0xFF1E2840, TXT = 0xFF8B95A7,
            EMA20 = 0xFF22D3EE, EMA50 = 0xFFA855F7, VWAP = 0xFFFF8A3D, WHITE = 0xFFE8EAED;
    private static final int[] FIB_COL = {0xFF9CA3AF, 0xFFF6465D, 0xFF9BE15D, 0xFF22C55E, 0xFF14B8A6, 0xFF3B82F6, 0xFF9CA3AF};
    private static final int FUTURE = 14;

    private Candles data;
    private PatternEngine.Result pat;
    private double[] ema20, ema50, vwap, wBuy, wSell;
    private String tf = "1h";
    private double visible = 90, offset = 0;
    private int touchIdx = -1, accent = 0xFFA855F7;
    private boolean fib = true, lines = true, zones = true, vp = true, whales = true, rsiOn = true, vwapOn;
    private boolean planOn, planBuy;
    private double pEntry, pSl, pTp1, pTp2;
    private double prevPrice;
    private long flashUntil;
    private int flashColor;
    private String message = "Chart load ho raha hai...";
    private String liveText = "";
    private final float d;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), stroke = new Paint(Paint.ANTI_ALIAS_FLAG),
            text = new Paint(Paint.ANTI_ALIAS_FLAG), dash = new Paint(Paint.ANTI_ALIAS_FLAG), grid = new Paint();

    public ChartView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        stroke.setStyle(Paint.Style.STROKE);
        dash.setStyle(Paint.Style.STROKE);
        dash.setPathEffect(new DashPathEffect(new float[]{6 * d, 4 * d}, 0));
        grid.setColor(GRID);
        grid.setStrokeWidth(1);
        text.setTextSize(10 * d);
    }

    // ------------------------------------------------------------ public API
    public void setMessage(String m) {
        message = m;
        data = null;
        invalidate();
    }

    public void setAccent(int c) { accent = c; invalidate(); }

    public void setLayers(boolean fib, boolean lines, boolean zones, boolean vp, boolean whales, boolean rsi) {
        this.fib = fib; this.lines = lines; this.zones = zones; this.vp = vp; this.whales = whales; this.rsiOn = rsi;
        invalidate();
    }

    public void zoom(int delta) {
        visible = Math.max(20, Math.min(280, visible + delta));
        invalidate();
    }

    /** Jump back to the newest candle. */
    public void goLive() {
        offset = 0;
        invalidate();
    }

    public boolean isLive() { return offset < 0.5; }

    public void setLiveText(String s) {
        liveText = s == null ? "" : s;
        invalidate();
    }

    public Candles getData() { return data; }

    public void setData(Candles c, PatternEngine.Result p, double[] whaleBuy, double[] whaleSell, String tf, boolean showVwap) {
        data = c;
        pat = p;
        wBuy = whaleBuy;
        wSell = whaleSell;
        this.tf = tf;
        vwapOn = showVwap;
        offset = 0;
        prevPrice = c.n > 0 ? c.close[c.n - 1] : 0;
        recalc();
        touchIdx = -1;
        invalidate();
    }

    public void setPatterns(PatternEngine.Result p) {
        pat = p;
        invalidate();
    }

    /** Applies updated/shifted candles from the live stream. */
    public void liveCandles(Candles c) {
        if (data == null || c == null) return;
        if (c != data) {
            // a new candle opened -> shift whale arrays and keep the view still if user scrolled back
            wBuy = shift(wBuy);
            wSell = shift(wSell);
            if (pat != null) pat = shiftPattern(pat);
            if (offset >= 0.5) offset += 1;
            data = c;
        }
        double last = data.close[data.n - 1];
        if (prevPrice > 0 && last != prevPrice) {
            flashColor = last > prevPrice ? UP : DOWN;
            flashUntil = System.currentTimeMillis() + 450;
        }
        prevPrice = last;
        recalc();
        invalidate();
    }

    /** A live trade: if it is a whale trade add it to the candle it belongs to. */
    public void liveTrade(long t, double usd, boolean sell) {
        if (data == null || wBuy == null) return;
        int idx = data.indexOf(t);
        if (idx < 0 || idx >= wBuy.length) return;
        if (sell) wSell[idx] += usd; else wBuy[idx] += usd;
    }

    // retest / entry zone shading
    private double zLo, zHi;
    private String zLabel = "";
    private int zColor;

    public void setZone(double lo, double hi, String label, int color) {
        zLo = Math.min(lo, hi);
        zHi = Math.max(lo, hi);
        zLabel = label == null ? "" : label;
        zColor = color;
        invalidate();
    }

    // TradingView-style manual price scale
    private boolean manualY;
    private double yMax, yMin;

    /** Back to automatic price scale and newest candles. */
    public void resetView() {
        manualY = false;
        offset = 0;
        invalidate();
    }

    public void setPlan(boolean on, boolean buy, double entry, double sl, double tp1, double tp2) {
        planOn = on; planBuy = buy; pEntry = entry; pSl = sl; pTp1 = tp1; pTp2 = tp2;
        invalidate();
    }

    private static double[] shift(double[] a) {
        if (a == null) return null;
        double[] b = new double[a.length];
        System.arraycopy(a, 1, b, 0, a.length - 1);
        return b;
    }

    /** Patterns are index based; after a shift the indices move left by one. */
    private static PatternEngine.Result shiftPattern(PatternEngine.Result p) {
        if (p.crowd != null && p.crowd.length > 1) {
            int[] c = new int[p.crowd.length];
            System.arraycopy(p.crowd, 1, c, 0, c.length - 1);
            p.crowd = c;
        }
        if (p.rsi != null && p.rsi.length > 1) {
            double[] r = new double[p.rsi.length];
            System.arraycopy(p.rsi, 1, r, 0, r.length - 1);
            r[r.length - 1] = r[r.length - 2];
            p.rsi = r;
        }
        p.shift++;
        return p;
    }

    private void recalc() {
        Candles c = data;
        ema20 = Indicators.ema(c.close, 20);
        ema50 = Indicators.ema(c.close, 50);
        vwap = new double[c.n];
        double pv = 0, vv = 0;
        long day = -1;
        for (int i = 0; i < c.n; i++) {
            long dd = c.time[i] / 86_400_000L;
            if (dd != day) { day = dd; pv = 0; vv = 0; }
            double tp = (c.high[i] + c.low[i] + c.close[i]) / 3;
            pv += tp * c.vol[i];
            vv += c.vol[i];
            vwap[i] = vv > 0 ? pv / vv : tp;
        }
    }

    // ------------------------------------------------------------ geometry
    private float top, priceBottom, volTop, volBottom, rsiTop, rsiBottom, plotW, cw;
    private int start, end, sh;
    private double max, min, range;

    private float rightPad() { return 60 * d; }
    private float x(double i) { return (float) ((i - start) * cw + cw / 2); }
    private float y(double v) { return (float) (top + (max - v) / range * (priceBottom - top)); }
    /** pattern index -> current data index */
    private int pi(int i) { return i - sh; }

    private void layout(float w, float h) {
        top = 20 * d;
        float axisH = 14 * d, gap = 6 * d;
        float rsiH = rsiOn ? h * 0.15f : 0;
        float volH = h * 0.11f;
        rsiBottom = h - axisH;
        rsiTop = rsiBottom - rsiH;
        volBottom = rsiOn ? rsiTop - gap : rsiBottom;
        volTop = volBottom - volH;
        priceBottom = volTop - gap;
        plotW = w - rightPad();
        int vis = (int) Math.min(Math.round(visible), data.n);
        offset = Math.max(0, Math.min(offset, data.n - Math.min(vis, data.n)));
        end = data.n - (int) Math.round(offset);
        start = Math.max(0, end - vis);
        boolean live = offset < 0.5;
        cw = plotW / (vis + (live ? FUTURE : 2));
        sh = pat == null ? 0 : pat.shift;
        max = -Double.MAX_VALUE;
        min = Double.MAX_VALUE;
        for (int i = start; i < end; i++) {
            max = Math.max(max, data.high[i]);
            min = Math.min(min, data.low[i]);
        }
        double r0 = Math.max(max - min, max * 0.002);
        if (live && pat != null && pat.target > 0 && lines) {
            if (pat.target > max && pat.target < max + r0 * 0.6) max = pat.target;
            if (pat.target < min && pat.target > min - r0 * 0.6) min = pat.target;
        }
        range = Math.max(max - min, max * 0.002);
        max += range * 0.05;
        min -= range * 0.05;
        range = max - min;
        if (manualY && yMax > yMin) {
            max = yMax;
            min = yMin;
            range = max - min;
        } else {
            yMax = max;
            yMin = min;
        }
    }

    private void paint(Paint p, int color, float width) {
        p.setColor(color);
        p.setStrokeWidth(width);
    }

    private void label(Canvas cv, String s, float x, float y, int color, float size, boolean bold) {
        text.setColor(color);
        text.setTextSize(size * d);
        text.setFakeBoldText(bold);
        cv.drawText(s, x, y, text);
        text.setFakeBoldText(false);
        text.setTextSize(10 * d);
    }

    private void tag(Canvas cv, String s, float x, float y, int bg, int fg) {
        text.setTextSize(9.5f * d);
        text.setFakeBoldText(true);
        float tw = text.measureText(s);
        fill.setColor(bg);
        cv.drawRoundRect(new RectF(x, y - 7 * d, x + tw + 6 * d, y + 7 * d), 3 * d, 3 * d, fill);
        text.setColor(fg);
        cv.drawText(s, x + 3 * d, y + 3.5f * d, text);
        text.setFakeBoldText(false);
        text.setTextSize(10 * d);
    }

    // ------------------------------------------------------------ draw
    @Override
    protected void onDraw(Canvas cv) {
        super.onDraw(cv);
        float w = getWidth(), h = getHeight();
        if (data == null || data.n < 2) {
            label(cv, message, 12 * d, h / 2, TXT, 12, false);
            return;
        }
        layout(w, h);
        boolean live = offset < 0.5;

        for (int g = 0; g <= 4; g++) {
            float yy = top + (priceBottom - top) * g / 4f;
            cv.drawLine(0, yy, plotW, yy, grid);
            label(cv, Fmt.price(max - range * g / 4.0), plotW + 4 * d, yy + 4 * d, TXT, 9.5f, false);
        }

        if (pat != null && zones) drawZones(cv);
        if (pat != null && vp) drawVolumeProfile(cv);
        if (pat != null && fib) drawFib(cv);
        if (zHi > 0) drawZone(cv);
        drawCandles(cv);
        drawSeries(cv, ema20, EMA20, 1.4f);
        drawSeries(cv, ema50, EMA50, 1.4f);
        if (vwapOn) drawSeries(cv, vwap, VWAP, 1.2f);
        if (pat != null && lines) drawPattern(cv, live);
        if (planOn) drawPlan(cv);
        if (whales) drawWhales(cv);
        if (pat != null) drawCandleMarks(cv);

        // live price line + flashing price tag
        double lp = data.close[data.n - 1];
        float ly = y(lp);
        if (ly >= top && ly <= priceBottom) {
            paint(dash, 0xAAF0B90B, 1);
            cv.drawLine(0, ly, plotW, ly, dash);
        }
        boolean upC = data.close[data.n - 1] >= data.open[data.n - 1];
        int tagCol = System.currentTimeMillis() < flashUntil ? flashColor : (upC ? UP : DOWN);
        float tagY = Math.max(top, Math.min(priceBottom, ly));
        tag(cv, Fmt.price(lp), plotW + 1 * d, tagY, tagCol, 0xFFFFFFFF);
        if (System.currentTimeMillis() < flashUntil) postInvalidateDelayed(120);

        // countdown to candle close
        long ms = tfMillis(tf);
        if (ms > 0 && live) {
            long left = data.time[data.n - 1] + ms - System.currentTimeMillis();
            if (left > 0) label(cv, countdown(left), plotW + 4 * d, tagY + 18 * d, TXT, 8.5f, false);
        }

        drawVolume(cv);
        if (rsiOn && pat != null && pat.rsi != null) drawRsi(cv);
        drawTimeAxis(cv, h);
        drawLegend(cv, live);
        if (manualY) label(cv, "↕ manual · 2x tap = auto", plotW + 2 * d, top - 6 * d, 0xFFFFC94D, 7.5f, true);
        if (touchIdx >= start && touchIdx < end) drawTouch(cv, w);
    }

    static long tfMillis(String tf) {
        try {
            long n = Long.parseLong(tf.substring(0, tf.length() - 1));
            char u = tf.charAt(tf.length() - 1);
            if (u == 'm') return n * 60_000L;
            if (u == 'h') return n * 3_600_000L;
            if (u == 'd') return n * 86_400_000L;
            if (u == 'w') return n * 7 * 86_400_000L;
        } catch (Exception ignored) {
        }
        return 0;
    }

    private static String countdown(long ms) {
        long s = ms / 1000;
        if (s >= 3600) return String.format(Locale.US, "%dh%02dm", s / 3600, (s % 3600) / 60);
        return String.format(Locale.US, "%02d:%02d", s / 60, s % 60);
    }

    private void drawZones(Canvas cv) {
        double hw = Math.max(pat.atr * 0.3, range * 0.006);
        for (PatternEngine.Zone z : pat.zones) {
            float y1 = y(z.price + hw), y2 = y(z.price - hw);
            if (y2 < top || y1 > priceBottom) continue;
            fill.setColor(z.support ? 0x2A0ECB81 : 0x2AF6465D);
            cv.drawRect(0, Math.max(top, y1), plotW, Math.min(priceBottom, y2), fill);
            tag(cv, (z.support ? "S " : "R ") + z.touches + "x  " + Fmt.price(z.price), 2 * d, (y1 + y2) / 2,
                    z.support ? 0xCC0B5E44 : 0xCC7A1F2B, 0xFFFFFFFF);
        }
    }

    private void drawVolumeProfile(Canvas cv) {
        if (pat.vpBuy == null) return;
        int bins = pat.vpBuy.length;
        double mx = 0;
        for (int b = 0; b < bins; b++) mx = Math.max(mx, pat.vpBuy[b] + pat.vpSell[b]);
        if (mx <= 0) return;
        float vpW = plotW * 0.22f;
        double step = (pat.vpHi - pat.vpLo) / bins;
        for (int b = 0; b < bins; b++) {
            float y1 = y(pat.vpLo + (b + 1) * step), y2 = y(pat.vpLo + b * step);
            if (y2 < top || y1 > priceBottom) continue;
            float lb = (float) (pat.vpBuy[b] / mx * vpW), ls = (float) (pat.vpSell[b] / mx * vpW);
            float yy1 = y1 + 0.6f * d, yy2 = Math.max(yy1 + 1, y2 - 0.6f * d);
            fill.setColor(b == pat.poc ? 0x9938BDF8 : 0x5538BDF8);
            cv.drawRect(plotW - lb, yy1, plotW, yy2, fill);
            fill.setColor(b == pat.poc ? 0x99F0B90B : 0x55F0B90B);
            cv.drawRect(plotW - lb - ls, yy1, plotW - lb, yy2, fill);
        }
        if (pat.poc >= 0) {
            double pp = pat.vpLo + (pat.poc + 0.5) * step;
            float yy = y(pp);
            if (yy >= top && yy <= priceBottom) {
                paint(dash, 0x99F0B90B, 1);
                cv.drawLine(0, yy, plotW, yy, dash);
                label(cv, "POC", plotW - vpW - 22 * d, yy - 2 * d, 0xFFF0B90B, 9, true);
            }
        }
    }

    private void drawFib(Canvas cv) {
        if (!pat.hasFib) return;
        double hi = pat.fibHi, lo = pat.fibLo, rng = hi - lo;
        int from = Math.max(start, pi(Math.min(pat.fibHiIdx, pat.fibLoIdx)));
        if (from >= end) return;
        float x0 = x(from);
        for (int k = 0; k < PatternEngine.FIB.length; k++) {
            double r = PatternEngine.FIB[k];
            double pr = pat.fibUp ? hi - rng * r : lo + rng * r;
            float yy = y(pr);
            if (yy < top || yy > priceBottom) continue;
            paint(stroke, (FIB_COL[k] & 0x00FFFFFF) | 0xAA000000, 1.1f * d);
            cv.drawLine(x0, yy, plotW, yy, stroke);
            label(cv, String.format(Locale.US, "%s(%s)", trimFib(r), Fmt.price(pr)), x0 + 2 * d, yy - 2 * d, FIB_COL[k], 9, false);
        }
        double a = pat.fibUp ? hi - rng * 0.5 : lo + rng * 0.5, b = pat.fibUp ? hi - rng * 0.618 : lo + rng * 0.618;
        fill.setColor(0x1A14B8A6);
        cv.drawRect(x0, Math.max(top, Math.min(y(a), y(b))), plotW, Math.min(priceBottom, Math.max(y(a), y(b))), fill);
    }

    private static String trimFib(double r) {
        if (r == 0) return "0";
        if (r == 1) return "1";
        String s = String.format(Locale.US, "%.3f", r);
        while (s.endsWith("0")) s = s.substring(0, s.length() - 1);
        return s;
    }

    private void drawCandles(Canvas cv) {
        float half = Math.max(1, cw * 0.36f);
        for (int i = start; i < end; i++) {
            float xx = x(i);
            boolean up = data.close[i] >= data.open[i];
            int col = up ? UP : DOWN;
            if (i == data.n - 1 && System.currentTimeMillis() < flashUntil) col = flashColor;
            fill.setColor(col);
            paint(stroke, col, Math.max(1, 1.1f * d));
            cv.drawLine(xx, y(data.high[i]), xx, y(data.low[i]), stroke);
            float yo = y(data.open[i]), yc = y(data.close[i]);
            float bt = Math.min(yo, yc), bb = Math.max(Math.max(yo, yc), bt + 1.2f * d);
            cv.drawRect(xx - half, bt, xx + half, bb, fill);
        }
    }

    private void drawSeries(Canvas cv, double[] e, int color, float width) {
        if (e == null) return;
        Path path = new Path();
        boolean first = true;
        for (int i = start; i < end && i < e.length; i++) {
            float yy = y(e[i]);
            if (yy < top || yy > priceBottom) { first = true; continue; }
            if (first) { path.moveTo(x(i), yy); first = false; } else path.lineTo(x(i), yy);
        }
        paint(stroke, color, width * d);
        cv.drawPath(path, stroke);
    }

    private void drawPattern(Canvas cv, boolean live) {
        int lastI = data.n - 1;
        float xEnd = live ? x(lastI + FUTURE - 1) : plotW;
        if (pat.res != null) drawTrend(cv, pat.res, 0xFFF6465D, xEnd);
        if (pat.sup != null) drawTrend(cv, pat.sup, 0xFF0ECB81, xEnd);

        if (pat.divType != 0 && pi(pat.divA) >= start && pi(pat.divB) < end) {
            boolean bull = pat.divType > 0;
            int a = pi(pat.divA), b = pi(pat.divB);
            double pa = bull ? data.low[a] : data.high[a], pb = bull ? data.low[b] : data.high[b];
            paint(stroke, bull ? 0xFF9BE15D : 0xFFFF8A3D, 1.6f * d);
            cv.drawLine(x(a), y(pa), x(b), y(pb), stroke);
        }

        int bias = pat.bias;
        int col = bias > 0 ? UP : DOWN;
        if (live && pat.target > 0 && bias != 0) {
            float x1 = x(lastI), y1 = y(data.close[lastI]);
            float x2 = x(lastI + FUTURE - 3), y2 = Math.max(top + 4 * d, Math.min(priceBottom - 4 * d, y(pat.target)));
            paint(dash, col, 2 * d);
            Path p = new Path();
            p.moveTo(x1, y1);
            p.lineTo(x2, y2);
            cv.drawPath(p, dash);
            paint(stroke, col, 2 * d);
            double ang = Math.atan2(y2 - y1, x2 - x1);
            float hl = 8 * d;
            cv.drawLine(x2, y2, (float) (x2 - hl * Math.cos(ang - 0.45)), (float) (y2 - hl * Math.sin(ang - 0.45)), stroke);
            cv.drawLine(x2, y2, (float) (x2 - hl * Math.cos(ang + 0.45)), (float) (y2 - hl * Math.sin(ang + 0.45)), stroke);
            tag(cv, "🎯 " + Fmt.price(pat.target), Math.min(x2 - 20 * d, plotW - 70 * d), y2 + (bias > 0 ? -11 : 11) * d, col, 0xFF0A0E17);
        }

        List<String> ls = new ArrayList<>();
        ls.add(pat.name);
        ls.addAll(wrap(pat.note, plotW * 0.62f));
        text.setTextSize(10 * d);
        float bw = 0;
        for (String s : ls) bw = Math.max(bw, text.measureText(s));
        bw += 12 * d;
        float bh = ls.size() * 13 * d + 8 * d;
        float bx = 6 * d, by = top + 18 * d;
        fill.setColor(0xE6141B2B);
        RectF box = new RectF(bx, by, bx + bw, by + bh);
        cv.drawRoundRect(box, 8 * d, 8 * d, fill);
        paint(stroke, col, 1.5f * d);
        cv.drawRoundRect(box, 8 * d, 8 * d, stroke);
        for (int i = 0; i < ls.size(); i++) {
            label(cv, ls.get(i), bx + 6 * d, by + 15 * d + i * 13 * d, i == 0 ? col : WHITE, i == 0 ? 11 : 9.5f, i == 0);
        }
    }

    private List<String> wrap(String s, float maxW) {
        List<String> out = new ArrayList<>();
        if (s == null || s.isEmpty()) return out;
        text.setTextSize(9.5f * d);
        StringBuilder line = new StringBuilder();
        for (String word : s.split(" ")) {
            String t = line.length() == 0 ? word : line + " " + word;
            if (text.measureText(t) > maxW && line.length() > 0) {
                out.add(line.toString());
                line = new StringBuilder(word);
                if (out.size() == 2) break;
            } else {
                line = new StringBuilder(t);
            }
        }
        if (out.size() < 3 && line.length() > 0) out.add(line.toString());
        text.setTextSize(10 * d);
        return out;
    }

    private void drawTrend(Canvas cv, PatternEngine.Line l, int color, float xEnd) {
        int i1 = pi(l.i1), i2 = pi(l.i2);
        int i0 = Math.max(start, i1);
        double endIdx = (xEnd - cw / 2) / cw + start;
        // line value at data index j = l.at(j + sh)
        float x1 = x(i0), y1 = y(l.at(i0 + sh)), x2 = xEnd, y2 = y(l.at(endIdx + sh));
        paint(stroke, color, 2 * d);
        cv.drawLine(x1, y1, x2, y2, stroke);
        fill.setColor(color);
        if (i1 >= start && i1 < end) cv.drawCircle(x(i1), y(l.p1), 3 * d, fill);
        if (i2 >= start && i2 < end) cv.drawCircle(x(i2), y(l.p2), 3 * d, fill);
    }

    private void drawZone(Canvas cv) {
        float y1 = y(zHi), y2 = y(zLo);
        if (y2 < top || y1 > priceBottom) return;
        y1 = Math.max(top, y1);
        y2 = Math.min(priceBottom, Math.max(y1 + 2 * d, y2));
        fill.setColor((zColor & 0x00FFFFFF) | 0x33000000);
        cv.drawRect(0, y1, plotW, y2, fill);
        paint(dash, zColor, 1.2f * d);
        cv.drawLine(0, y1, plotW, y1, dash);
        cv.drawLine(0, y2, plotW, y2, dash);
        if (!zLabel.isEmpty()) tag(cv, zLabel, plotW * 0.35f, (y1 + y2) / 2, (zColor & 0x00FFFFFF) | 0xDD000000, 0xFF0A0E17);
    }

    private void drawPlan(Canvas cv) {
        double[] v = {pEntry, pSl, pTp1, pTp2};
        String[] n = {planBuy ? "BUY" : "SELL", "SL", "TP1", "TP2"};
        int[] c = {accent, DOWN, UP, UP};
        float xs = Math.min(x(data.n - 1), plotW - 95 * d);
        for (int k = 0; k < 4; k++) {
            if (v[k] <= 0) continue;
            float yy = y(v[k]);
            if (yy < top || yy > priceBottom) continue;
            paint(dash, c[k], 1.4f * d);
            cv.drawLine(Math.max(0, xs - 40 * d), yy, plotW, yy, dash);
            tag(cv, n[k] + " " + Fmt.price(v[k]), plotW - 92 * d, yy, c[k], 0xFF0A0E17);
        }
    }

    private void drawWhales(Canvas cv) {
        double mx = 0;
        if (wBuy != null) for (int i = start; i < end && i < wBuy.length; i++) mx = Math.max(mx, Math.max(wBuy[i], wSell[i]));
        int bigI = -1;
        double big = 0;
        boolean bigBuy = true;
        for (int i = start; i < end; i++) {
            float xx = x(i);
            float yl = y(data.low[i]) + 7 * d, yh = y(data.high[i]) - 7 * d;
            int cr = pat != null && pat.crowd != null && i < pat.crowd.length ? pat.crowd[i] : 0;
            boolean exact = false;
            if (wBuy != null && i < wBuy.length && mx > 0) {
                if (wBuy[i] > 0) {
                    float r = (float) Math.max(2.5 * d, Math.sqrt(wBuy[i] / mx) * Math.max(cw, 6 * d) * 0.9);
                    fill.setColor(0xCC0ECB81);
                    cv.drawCircle(xx, yl + r, r, fill);
                    paint(stroke, 0xFFFFFFFF, 1);
                    cv.drawCircle(xx, yl + r, r, stroke);
                    exact = true;
                    if (wBuy[i] > big) { big = wBuy[i]; bigI = i; bigBuy = true; }
                }
                if (wSell[i] > 0) {
                    float r = (float) Math.max(2.5 * d, Math.sqrt(wSell[i] / mx) * Math.max(cw, 6 * d) * 0.9);
                    fill.setColor(0xCCF6465D);
                    cv.drawCircle(xx, yh - r, r, fill);
                    paint(stroke, 0xFFFFFFFF, 1);
                    cv.drawCircle(xx, yh - r, r, stroke);
                    exact = true;
                    if (wSell[i] > big) { big = wSell[i]; bigI = i; bigBuy = false; }
                }
            }
            if (!exact) {
                if (cr == 2) label(cv, "W", xx - 3 * d, yl + 7 * d, UP, 9, true);
                else if (cr == -2) label(cv, "W", xx - 3 * d, yh, DOWN, 9, true);
            }
            if (cr == 1) { fill.setColor(0xCC38BDF8); cv.drawCircle(xx, yl + (exact ? 14 : 3) * d, 1.8f * d, fill); }
            else if (cr == -1) { fill.setColor(0xCCFF8A3D); cv.drawCircle(xx, yh - (exact ? 14 : 3) * d, 1.8f * d, fill); }
        }
        if (bigI >= 0 && big > 0) {
            float yy = bigBuy ? y(data.low[bigI]) + 30 * d : y(data.high[bigI]) - 26 * d;
            tag(cv, "🐋 " + (bigBuy ? "BUY " : "SELL ") + Fmt.usd(big), Math.min(x(bigI) - 20 * d, plotW - 90 * d),
                    Math.max(top + 8 * d, Math.min(priceBottom - 8 * d, yy)), bigBuy ? 0xDD0B5E44 : 0xDD7A1F2B, 0xFFFFFFFF);
        }
    }

    private void drawCandleMarks(Canvas cv) {
        for (PatternEngine.Mark m : pat.marks) {
            int i = pi(m.idx);
            if (i < start || i >= end) continue;
            float xx = x(i);
            if (m.side > 0) label(cv, m.label, xx - 12 * d, y(data.low[i]) + 22 * d, 0xFF9BE15D, 8, true);
            else label(cv, m.label, xx - 12 * d, y(data.high[i]) - 16 * d, 0xFFFF8A3D, 8, true);
        }
    }

    private void drawVolume(Canvas cv) {
        double mv = 0;
        for (int i = start; i < end; i++) mv = Math.max(mv, data.vol[i]);
        cv.drawLine(0, volTop - 3 * d, plotW, volTop - 3 * d, grid);
        label(cv, "Volume: green = buyers · red = sellers", 3 * d, volTop + 8 * d, TXT, 8.5f, false);
        if (mv <= 0) return;
        float half = Math.max(1, cw * 0.36f), vh = volBottom - volTop;
        for (int i = start; i < end; i++) {
            float xx = x(i);
            float total = (float) (data.vol[i] / mv * vh);
            float buy = data.vol[i] > 0 ? (float) (data.takerBuy[i] / data.vol[i]) * total : 0;
            fill.setColor(0xAA0ECB81);
            cv.drawRect(xx - half, volBottom - buy, xx + half, volBottom, fill);
            fill.setColor(0xAAF6465D);
            cv.drawRect(xx - half, volBottom - total, xx + half, volBottom - buy, fill);
        }
    }

    private void drawRsi(Canvas cv) {
        float h = rsiBottom - rsiTop;
        cv.drawLine(0, rsiTop - 3 * d, plotW, rsiTop - 3 * d, grid);
        float y70 = rsiTop + h * 0.3f, y30 = rsiTop + h * 0.7f, y50 = rsiTop + h * 0.5f;
        paint(stroke, 0x55F6465D, 1);
        cv.drawLine(0, y70, plotW, y70, stroke);
        paint(stroke, 0x550ECB81, 1);
        cv.drawLine(0, y30, plotW, y30, stroke);
        paint(dash, 0x33FFFFFF, 1);
        cv.drawLine(0, y50, plotW, y50, dash);
        label(cv, "70", plotW + 4 * d, y70 + 3 * d, DOWN, 9, false);
        label(cv, "30", plotW + 4 * d, y30 + 3 * d, UP, 9, false);
        // live RSI from current candles
        double[] rsi = Indicators.rsi(data.close, 14);
        Path p = new Path();
        boolean first = true;
        for (int i = Math.max(start, 14); i < end; i++) {
            float yy = rsiTop + (float) ((100 - rsi[i]) / 100.0 * h);
            if (first) { p.moveTo(x(i), yy); first = false; } else p.lineTo(x(i), yy);
        }
        paint(stroke, accent, 1.5f * d);
        cv.drawPath(p, stroke);
        label(cv, String.format(Locale.US, "RSI %.0f", rsi[Math.max(0, end - 1)]), 3 * d, rsiTop + 9 * d, accent, 9, true);
        int a = pi(pat.divA), b = pi(pat.divB);
        if (pat.divType != 0 && a >= start && b < end && b >= 0) {
            boolean bull = pat.divType > 0;
            paint(stroke, bull ? 0xFF9BE15D : 0xFFFF8A3D, 1.8f * d);
            float ya = rsiTop + (float) ((100 - rsi[a]) / 100.0 * h), yb = rsiTop + (float) ((100 - rsi[b]) / 100.0 * h);
            cv.drawLine(x(a), ya, x(b), yb, stroke);
            label(cv, bull ? "Bull div" : "Bear div", x(b) + 4 * d, yb, bull ? 0xFF9BE15D : 0xFFFF8A3D, 9, true);
        }
    }

    private void drawTimeAxis(Canvas cv, float h) {
        boolean intraday = tf.endsWith("m") || tf.equals("1h");
        SimpleDateFormat f = new SimpleDateFormat(intraday ? "dd MMM HH:mm" : "dd MMM yy", Locale.US);
        int vis = end - start;
        for (int k = 0; k < 4; k++) {
            int i = start + (int) (vis * (k + 0.5) / 4);
            if (i >= end) continue;
            label(cv, f.format(new Date(data.time[i])), x(i) - 22 * d, h - 3 * d, TXT, 8.5f, false);
        }
    }

    private void drawLegend(Canvas cv, boolean live) {
        float xx = 4 * d, yy = 13 * d;
        String[] n = {"EMA20", "EMA50", vwapOn ? "VWAP" : null};
        int[] c = {EMA20, EMA50, VWAP};
        for (int k = 0; k < 3; k++) {
            if (n[k] == null) continue;
            label(cv, n[k], xx, yy, c[k], 9.5f, true);
            xx += 44 * d;
        }
        if (!live) label(cv, "⏪ purana data dekh rahe hain · ⏩ Live dabayen", xx, yy, 0xFFFFC94D, 9, true);
        else if (!liveText.isEmpty()) label(cv, liveText, xx, yy, liveText.startsWith("●") ? UP : 0xFFFFC94D, 9, true);
    }

    private void drawTouch(Canvas cv, float w) {
        int i = touchIdx;
        paint(stroke, 0x88FFFFFF, 1);
        cv.drawLine(x(i), top, x(i), rsiBottom, stroke);
        double chg = data.open[i] > 0 ? (data.close[i] / data.open[i] - 1) * 100 : 0;
        double bp = data.vol[i] > 0 ? data.takerBuy[i] / data.vol[i] * 100 : 50;
        String when = new SimpleDateFormat("dd MMM HH:mm", Locale.US).format(new Date(data.time[i]));
        StringBuilder s = new StringBuilder(when).append("  O ").append(Fmt.price(data.open[i]))
                .append(" H ").append(Fmt.price(data.high[i])).append(" L ").append(Fmt.price(data.low[i]))
                .append(" C ").append(Fmt.price(data.close[i]))
                .append(String.format(Locale.US, "  %+.2f%%  Buy %.0f%%", chg, bp));
        int cr = pat != null && pat.crowd != null && i < pat.crowd.length ? pat.crowd[i] : 0;
        String extra = "";
        if (wBuy != null && i < wBuy.length && (wBuy[i] > 0 || wSell[i] > 0))
            extra = "🐋 Whale buy " + Fmt.usd(wBuy[i]) + " · sell " + Fmt.usd(wSell[i]);
        else if (cr == 2) extra = "W: is candle mein bade (whale) buyers";
        else if (cr == -2) extra = "W: is candle mein bade (whale) sellers";
        else if (cr == 1) extra = "Retail crowd khareed raha tha";
        else if (cr == -1) extra = "Retail crowd bech raha tha";
        extra += (extra.isEmpty() ? "" : " · ") + "Volume " + Fmt.usd(data.quoteVol[i]) + " · " + (long) data.trades[i] + " trades";
        fill.setColor(0xF0141B2B);
        cv.drawRect(0, 0, w, 31 * d, fill);
        label(cv, s.toString(), 4 * d, 12.5f * d, WHITE, 9.5f, false);
        label(cv, extra, 4 * d, 26 * d, 0xFFF0B90B, 9.5f, true);
        float yy = y(data.close[i]);
        if (yy >= top && yy <= priceBottom) {
            paint(stroke, 0x55FFFFFF, 1);
            cv.drawLine(0, yy, plotW, yy, stroke);
        }
    }

    // ------------------------------------------------------------ gestures (TradingView / Binance style)
    // 1 finger drag left/right = scroll time · drag up/down = move price
    // drag on the right price scale = stretch / squeeze price · 2 fingers = zoom
    // press & hold = crosshair · double tap = reset to auto + live
    private static final int G_NONE = 0, G_PENDING = 1, G_PAN = 2, G_CROSS = 3, G_PINCH = 4, G_YSCALE = 5, G_YPAN = 6;
    private int gesture = G_NONE;
    private float downX, downY, lastX, lastY;
    private double pinchDx, pinchDy, pinchVisible, pinchMax, pinchMin;
    private long lastTap;
    private final Runnable crossOn = () -> {
        if (gesture == G_PENDING) {
            gesture = G_CROSS;
            touchIdx = idxAt(downX);
            invalidate();
        }
    };

    private int idxAt(float xPos) {
        if (cw <= 0) return -1;
        int idx = start + (int) (xPos / cw);
        return Math.max(start, Math.min(end - 1, idx));
    }

    private void startManualY() {
        if (!manualY) {
            manualY = true;
            yMax = max;
            yMin = min;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (data == null || data.n == 0 || cw <= 0) return false;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = lastX = e.getX();
                downY = lastY = e.getY();
                if (downX > plotW && downY < priceBottom) {
                    gesture = G_YSCALE;
                    startManualY();
                } else {
                    gesture = G_PENDING;
                    postDelayed(crossOn, 300);
                }
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                removeCallbacks(crossOn);
                if (e.getPointerCount() >= 2) {
                    gesture = G_PINCH;
                    pinchDx = Math.max(10, Math.abs(e.getX(0) - e.getX(1)));
                    pinchDy = Math.max(10, Math.abs(e.getY(0) - e.getY(1)));
                    pinchVisible = visible;
                    pinchMax = max;
                    pinchMin = min;
                    touchIdx = -1;
                }
                return true;
            case MotionEvent.ACTION_MOVE: {
                float x = e.getX(), y = e.getY();
                if (gesture == G_PINCH && e.getPointerCount() >= 2) {
                    double dx = Math.max(10, Math.abs(e.getX(0) - e.getX(1)));
                    double dy = Math.max(10, Math.abs(e.getY(0) - e.getY(1)));
                    visible = Math.max(15, Math.min(300, pinchVisible * pinchDx / dx));
                    if (Math.abs(dy - pinchDy) > 30 * d) {
                        // vertical pinch also stretches the price scale
                        startManualY();
                        double mid = (pinchMax + pinchMin) / 2, half = (pinchMax - pinchMin) / 2 * pinchDy / dy;
                        yMax = mid + half;
                        yMin = mid - half;
                    }
                    invalidate();
                } else if (gesture == G_YSCALE) {
                    double f = Math.exp((y - lastY) / (150 * d));
                    double mid = (yMax + yMin) / 2, half = (yMax - yMin) / 2 * f;
                    yMax = mid + half;
                    yMin = mid - half;
                    invalidate();
                } else if (gesture == G_PENDING) {
                    float adx = Math.abs(x - downX), ady = Math.abs(y - downY);
                    if (adx > 10 * d || ady > 10 * d) {
                        removeCallbacks(crossOn);
                        gesture = ady > adx * 1.3f ? G_YPAN : G_PAN;
                        if (gesture == G_YPAN) startManualY();
                    }
                } else if (gesture == G_CROSS) {
                    touchIdx = idxAt(x);
                    invalidate();
                }
                if (gesture == G_PAN) {
                    offset = Math.max(0, offset + (x - lastX) / cw);
                    invalidate();
                } else if (gesture == G_YPAN) {
                    double dp = (y - lastY) / Math.max(1, priceBottom - top) * (yMax - yMin);
                    yMax += dp;
                    yMin += dp;
                    invalidate();
                }
                lastX = x;
                lastY = y;
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                removeCallbacks(crossOn);
                if (gesture == G_PENDING) {
                    long now = System.currentTimeMillis();
                    if (now - lastTap < 320) {
                        resetView();
                        touchIdx = -1;
                        lastTap = 0;
                    } else {
                        lastTap = now;
                        touchIdx = idxAt(e.getX());
                        postDelayed(() -> { touchIdx = -1; invalidate(); }, 2500);
                    }
                } else {
                    touchIdx = -1;
                }
                gesture = G_NONE;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                invalidate();
                return true;
            default:
                return true;
        }
    }
}
