package com.signal.bot;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Network helpers + one full background scan of Binance spot USDT coins (public data, no API key). */
public final class Scanner {
    private Scanner() {}

    public static final String CH_SIGNALS = "signals";

    private static final String[] HOSTS = {
            "https://data-api.binance.vision",
            "https://api.binance.com",
            "https://api1.binance.com",
            "https://api2.binance.com",
            "https://api-gcp.binance.com"
    };
    private static volatile int hostIdx = 0;

    /** Errors that should not be retried on another host. */
    static final class HardFail extends IOException {
        HardFail(String m) { super(m); }
    }

    private static final Set<String> SKIP = new HashSet<>();
    static {
        String[] s = {"USDCUSDT", "FDUSDUSDT", "TUSDUSDT", "BUSDUSDT", "USDPUSDT", "DAIUSDT",
                "EURUSDT", "EURIUSDT", "AEURUSDT", "USDEUSDT", "XUSDUSDT", "PAXGUSDT", "BFUSDUSDT",
                "GBPUSDT", "TRYUSDT", "BRLUSDT", "USD1USDT", "RLUSDUSDT", "PYUSDUSDT"};
        Collections.addAll(SKIP, s);
    }

    static boolean isTradable(String s) {
        return s != null && s.endsWith("USDT") && s.length() > 4 && !SKIP.contains(s);
    }

    private static String read(HttpURLConnection conn) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    /** Fetch any full URL (futures, CoinGecko, news, Glassnode...). */
    static String getAbsolute(String url) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        try {
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) NohmanTradingBot/3.0");
            conn.setRequestProperty("Accept", "*/*");
            int code = conn.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code);
            return read(conn);
        } finally {
            conn.disconnect();
        }
    }

    /** Binance spot REST with automatic fallback between mirrors. */
    static String get(String path) throws IOException {
        IOException last = new IOException("Binance tak pohanch nahi ho rahi");
        for (int a = 0; a < HOSTS.length; a++) {
            int idx = (hostIdx + a) % HOSTS.length;
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(HOSTS[idx] + path).openConnection();
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(30000);
                conn.setRequestProperty("User-Agent", "NohmanTradingBot/3.0");
                int code = conn.getResponseCode();
                if (code == 200) {
                    String s = read(conn);
                    hostIdx = idx;
                    return s;
                }
                if (code == 429 || code == 418) throw new HardFail("Binance rate limit (" + code + "), thora wait");
                if (code == 400) throw new HardFail("Yeh coin Binance spot (USDT) par nahi mila");
                last = new IOException("HTTP " + code);
            } catch (HardFail e) {
                throw e;
            } catch (IOException e) {
                last = e;
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
        throw last;
    }

    /** Runs one scan. Returns a short status line. */
    public static String runOnce(Context ctx, int mode) throws Exception {
        String tf = Prefs.timeframe(ctx, mode);
        int top = Prefs.topCoins(ctx, mode);
        double minVol = Prefs.minVolMillion(ctx, mode) * 1_000_000.0;
        int buyTh = Prefs.buyThreshold(ctx, mode);
        int sellTh = Prefs.sellThreshold(ctx, mode);
        double volMult = Prefs.volMult(ctx, mode);
        boolean smart = Prefs.smartMoney(ctx);
        boolean strong = Prefs.strongConfirm(ctx);
        double whaleUsd = Prefs.whaleUsd(ctx);

        String[] fg = SmartMoney.fearGreed();
        int fgVal = -1;
        if (fg != null) {
            try { fgVal = Integer.parseInt(fg[0]); } catch (Exception ignored) { }
        }

        boolean btcBull = true;
        try {
            Candles b = Candles.fetch("BTCUSDT", "1h", 120, true);
            btcBull = Analyzer.isBullish(b.close);
        } catch (Exception ignored) {
        }

        JSONArray tick = new JSONArray(get("/api/v3/ticker/24hr?type=MINI"));
        List<JSONObject> coins = new ArrayList<>();
        Map<String, JSONObject> all = new HashMap<>();
        for (int i = 0; i < tick.length(); i++) {
            JSONObject t = tick.getJSONObject(i);
            String s = t.optString("symbol");
            if (!isTradable(s) || t.optDouble("lastPrice", 0) <= 0) continue;
            all.put(s, t);
            if (t.optDouble("quoteVolume", 0) < minVol) continue;
            coins.add(t);
        }
        Collections.sort(coins, (a, b2) -> Double.compare(b2.optDouble("quoteVolume", 0), a.optDouble("quoteVolume", 0)));
        if (coins.size() > top) coins = new ArrayList<>(coins.subList(0, top));
        Set<String> have = new HashSet<>();
        for (JSONObject t : coins) have.add(t.optString("symbol"));
        for (String w : Prefs.watchlist(ctx)) {
            if (!have.contains(w) && all.containsKey(w)) coins.add(all.get(w));
        }

        int scanned = 0, alerts = 0;
        for (JSONObject t : coins) {
            if (!ScannerService.running) break;
            String sym = t.optString("symbol");
            try {
                Candles k = Candles.fetch(sym, tf, 200, true);
                Analyzer.Result r = Analyzer.analyze(k.open, k.close, k.vol, k.takerBuy, volMult);
                scanned++;
                if (smart && (r.buyScore >= buyTh - 3 || r.sellScore >= sellTh - 3)) {
                    SmartMoney.enrich(sym, r, whaleUsd, true);
                }
                if (fgVal >= 80) {
                    r.buyScore -= 1;
                    r.buyReasons.add("Market Extreme Greed (" + fgVal + ") — ehtiyat");
                } else if (fgVal >= 0 && fgVal <= 20 && r.buyScore > 0) {
                    r.buyReasons.add("Market Extreme Fear (" + fgVal + ") — aksar achha entry time");
                }
                boolean buyCand = r.buyScore >= buyTh && (btcBull || !Prefs.btcFilter(ctx) || sym.equals("BTCUSDT"));
                boolean sellCand = !buyCand && r.sellScore >= sellTh && r.volumeOutflow;
                if (buyCand || sellCand) {
                    String side = buyCand ? "BUY" : "SELL";
                    if (Prefs.cooldownOk(ctx, mode, sym, side)) {
                        int score = buyCand ? r.buyScore : r.sellScore;
                        String why = join(buyCand ? r.buyReasons : r.sellReasons);
                        boolean confirmed = false, reject = false;
                        double atrK = Indicators.atr(k.high, k.low, k.close, 14);
                        double risk = Math.max(atrK * Mode.stopAtr(mode), r.price * 0.003);
                        double sl = buyCand ? r.price - risk : r.price + risk;
                        double tp = buyCand ? r.price + 1.5 * risk : r.price - 1.5 * risk;
                        Position.Advice adv = Position.compute(buyCand, r.price, atrK, Mode.stopAtr(mode), null, 0, 0,
                                r.buyRatio * 100, Double.NaN);
                        if (strong) {
                            try {
                                CoinReport rep = CoinReport.build(sym, mode, "", whaleUsd, false);
                                if (buyCand && rep.total < 62) reject = true;
                                if (sellCand && rep.total > 38) reject = true;
                                if (rep.confidence < Prefs.minConfidence(ctx)) reject = true;
                                if (!reject) {
                                    score = rep.total;
                                    if (rep.stop > 0 && rep.target1 > 0) {
                                        sl = rep.stop;
                                        tp = rep.target1;
                                    }
                                    if (rep.advice != null) adv = rep.advice;
                                    confirmed = true;
                                    why = "✅ Score " + rep.total + "/100 (" + rep.verdict + ", confidence " + rep.confidence + "%) · "
                                            + rep.flowLabel + "\n📐 " + rep.patterns.name + "\n" + why;
                                }
                            } catch (HardFail e) {
                                throw e;
                            } catch (Exception ignored) {
                                // all-source check failed -> fall back to the basic signal
                            }
                        }
                        if (!reject) {
                            Prefs.markCooldown(ctx, mode, sym, side);
                            JSONObject ex = new JSONObject();
                            try {
                                ex.put("tf", tf);
                                ex.put("adv", adv.title);
                                ex.put("advWhy", adv.why);
                                ex.put("type", adv.type);
                                ex.put("zlo", adv.zoneLo);
                                ex.put("zhi", adv.zoneHi);
                                ex.put("entry", adv.entry);
                                ex.put("tp2", adv.tp2);
                                if (adv.sl > 0) sl = adv.sl;
                                if (adv.tp1 > 0) tp = adv.tp1;
                            } catch (Exception ignored) {
                            }
                            alert(ctx, mode, side, sym, r.price, score, adv.title + "\n" + why, tf, confirmed, sl, tp, ex);
                            alerts++;
                        }
                    }
                }
            } catch (InterruptedException e) {
                throw e;
            } catch (HardFail e) {
                if (e.getMessage() != null && e.getMessage().startsWith("Binance rate limit")) Thread.sleep(60_000);
            } catch (Exception ignored) {
            }
            Thread.sleep(120);
        }

        String time = new SimpleDateFormat("HH:mm", Locale.US).format(new Date());
        return Mode.label(mode) + " · last scan " + time + " · " + scanned + " coins (" + tf + ") · " + alerts
                + " naye signal · BTC " + (btcBull ? "bullish ✅" : "bearish ⚠️")
                + (fg != null ? " · Fear&Greed " + fg[0] + " (" + fg[1] + ")" : "");
    }

    private static String join(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (String s : l) {
            if (sb.length() > 0) sb.append("\n");
            sb.append("• ").append(s);
        }
        return sb.toString();
    }

    static String fmtPrice(double p) {
        if (p >= 100) return String.format(Locale.US, "%.2f", p);
        if (p >= 1) return String.format(Locale.US, "%.4f", p);
        if (p >= 0.01) return String.format(Locale.US, "%.5f", p);
        return String.format(Locale.US, "%.8f", p);
    }

    private static void alert(Context ctx, int mode, String side, String sym, double price, int score, String why,
                              String tf, boolean strong, double sl, double tp, JSONObject extra) {
        why = why + "\n🎯 TP $" + fmtPrice(tp) + " · 🛑 SL $" + fmtPrice(sl);
        Prefs.addSignal(ctx, mode, side, sym, price, score, why, sl, tp, extra);
        String base = sym.substring(0, sym.length() - 4);

        Intent open = new Intent(ctx, MainActivity.class);
        open.putExtra("coin", sym);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(ctx, (sym + side).hashCode(), open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent web = BinanceLink.intent(ctx, base, mode == Mode.SCALP && "SELL".equals(side));
        PendingIntent wpi = PendingIntent.getActivity(ctx, (sym + "web").hashCode(), web,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        String title = (mode == Mode.SCALP ? "⚡ " : "💎 ");
        if ("BUY".equals(side)) title += (strong ? "STRONG BUY: " : "BUY: ") + base + "/USDT";
        else title += (strong ? "STRONG SELL: " : "SELL (paisa nikal raha): ") + base + "/USDT";
        String text = "Price " + fmtPrice(price) + " · Score " + score + (strong ? "/100" : "") + " · " + tf;
        if (!Notify.allowed(ctx, Prefs.N_SIGNALS)) return;   // saved in the Signals tab, but no notification

        Notification n = new Notification.Builder(ctx, CH_SIGNALS)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text + "\n" + why))
                .setContentIntent(pi)
                .addAction(new Notification.Action.Builder(null, "🟡 Binance app", wpi).build())
                .setColor("BUY".equals(side) ? 0xFF0ECB81 : 0xFFF6465D)
                .setAutoCancel(true)
                .build();
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify((sym + side + mode).hashCode(), n);
    }

    /**
     * Signal accuracy tracker: checks every open signal against the live price.
     * WIN = target hit first, LOSS = stop hit first, EXPIRED after 4h (scalp) / 48h (spot).
     */
    public static void trackSignals(Context ctx) {
        JSONArray arr = Prefs.signals(ctx);
        java.util.Set<String> syms = new java.util.LinkedHashSet<>();
        for (int i = 0; i < arr.length() && i < 100; i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o != null && "open".equals(o.optString("st", "")) && o.optDouble("tp", 0) > 0) syms.add(o.optString("sym"));
        }
        if (syms.isEmpty()) return;
        Map<String, Double> px = new HashMap<>();
        try {
            StringBuilder q = new StringBuilder("[");
            for (String s : syms) {
                if (q.length() > 1) q.append(',');
                q.append('"').append(s).append('"');
            }
            q.append(']');
            JSONArray pr = new JSONArray(get("/api/v3/ticker/price?symbols=" + java.net.URLEncoder.encode(q.toString(), "UTF-8")));
            for (int i = 0; i < pr.length(); i++) {
                JSONObject o = pr.getJSONObject(i);
                px.put(o.optString("symbol"), o.optDouble("price", 0));
            }
        } catch (Exception e) {
            return;
        }
        boolean changed = false;
        long now = System.currentTimeMillis();
        for (int i = 0; i < arr.length() && i < 100; i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null || !"open".equals(o.optString("st", ""))) continue;
            Double p = px.get(o.optString("sym"));
            if (p == null || p <= 0) continue;
            boolean buy = "BUY".equals(o.optString("side"));
            double entry = o.optDouble("price", 0), sl = o.optDouble("sl", 0), tp = o.optDouble("tp", 0);
            if (entry <= 0 || tp <= 0) continue;
            long maxAge = o.optInt("mode", Mode.SPOT) == Mode.SCALP ? 4 * 3600_000L : 48 * 3600_000L;
            String st = null;
            if (buy ? p >= tp : p <= tp) st = "win";
            else if (buy ? p <= sl : p >= sl) st = "loss";
            else if (now - o.optLong("t") > maxAge) st = "expired";
            if (st != null) {
                try {
                    o.put("st", st);
                    o.put("exit", p);
                    o.put("pnl", (buy ? p / entry - 1 : 1 - p / entry) * 100);
                    changed = true;
                } catch (Exception ignored) {
                }
            }
        }
        if (changed) Prefs.saveSignals(ctx, arr);
    }

    /** {wins, losses, expired, open} */
    public static int[] signalStats(JSONArray arr) {
        int[] s = new int[4];
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String st = o.optString("st", "");
            if (st.equals("win")) s[0]++;
            else if (st.equals("loss")) s[1]++;
            else if (st.equals("expired")) s[2]++;
            else if (st.equals("open")) s[3]++;
        }
        return s;
    }

    /** Checks the user's price alerts and notifies when one is crossed. */
    public static void checkAlerts(Context ctx) {
        JSONArray a = Prefs.alerts(ctx);
        if (a.length() == 0) return;
        List<Integer> done = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            String sym = o.optString("sym");
            double target = o.optDouble("price", 0);
            boolean above = o.optBoolean("above");
            try {
                double p = new JSONObject(get("/api/v3/ticker/price?symbol=" + sym)).optDouble("price", 0);
                if (p <= 0 || !(above ? p >= target : p <= target)) continue;
                done.add(i);
                if (!Notify.allowed(ctx, Prefs.N_ALERTS)) continue;
                String base = sym.substring(0, sym.length() - 4);
                Intent open = new Intent(ctx, MainActivity.class);
                open.putExtra("coin", sym);
                open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                PendingIntent pi = PendingIntent.getActivity(ctx, (sym + "alert" + i).hashCode(), open,
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
                Notification n = new Notification.Builder(ctx, CH_SIGNALS)
                        .setSmallIcon(R.drawable.ic_stat)
                        .setContentTitle("🔔 PRICE ALERT: " + base + " " + (above ? "upar gaya" : "neeche aaya") + " $" + fmtPrice(target))
                        .setContentText("Abhi price $" + fmtPrice(p) + " · tap karke analysis dekhen")
                        .setContentIntent(pi)
                        .setColor(0xFFF0B90B)
                        .setAutoCancel(true)
                        .build();
                NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
                nm.notify((sym + "alert" + target).hashCode(), n);
            } catch (Exception ignored) {
            }
        }
        if (!done.isEmpty()) Prefs.removeAlerts(ctx, done);
    }
}
