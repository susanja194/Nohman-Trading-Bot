package com.signal.bot;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

/** Checks the user's watch-only wallets and notifies when a balance goes up or down. */
public final class WalletWatch {
    private WalletWatch() {}

    static String key(WalletTracker.Holding h) { return h.asset + "@" + h.network; }

    /** Fetches every saved wallet; updates its snapshot; notifies on changes. Returns the results. */
    public static java.util.List<WalletTracker.Result> check(Context c) {
        java.util.List<WalletTracker.Result> out = new java.util.ArrayList<>();
        JSONArray ws = Prefs.wallets(c);
        boolean changed = false;
        for (int i = 0; i < ws.length(); i++) {
            JSONObject w = ws.optJSONObject(i);
            if (w == null) continue;
            WalletTracker.Result r = WalletTracker.fetch(w.optString("addr"));
            out.add(r);
            if (r.error != null && r.holdings.isEmpty()) continue;
            JSONObject snap = w.optJSONObject("snap");
            JSONObject now = new JSONObject();
            try {
                for (WalletTracker.Holding h : r.holdings) now.put(key(h), h.amount);
                if (snap != null) {
                    for (WalletTracker.Holding h : r.holdings) {
                        double before = snap.optDouble(key(h), 0);
                        diff(c, w, h.asset, h.network, h.amount - before, h.usd / Math.max(h.amount, 1e-18), i);
                    }
                    java.util.Iterator<String> it = snap.keys();
                    while (it.hasNext()) {
                        String k = it.next();
                        if (!now.has(k)) {
                            String[] p = k.split("@", 2);
                            diff(c, w, p[0], p.length > 1 ? p[1] : "", -snap.optDouble(k, 0), WalletTracker.price(p[0]), i);
                        }
                    }
                }
                w.put("snap", now);
                w.put("usd", r.totalUsd);
                w.put("checked", System.currentTimeMillis());
                changed = true;
            } catch (Exception ignored) {
            }
        }
        if (changed) Prefs.saveWallets(c, ws);
        return out;
    }

    private static void diff(Context c, JSONObject w, String asset, String net, double delta, double px, int idx) {
        double usd = Math.abs(delta) * px;
        if (Math.abs(delta) < 1e-9 || usd < 1) return;
        String label = w.optString("label", WalletTracker.shortAddr(w.optString("addr")));
        String amt = Math.abs(delta) >= 1 ? Fmt.num(Math.abs(delta)) : String.format(Locale.US, "%.8f", Math.abs(delta));
        String text = (delta > 0 ? "🟢 +" : "🔴 −") + amt + " " + asset + " (" + Fmt.usd(usd) + ") · " + net;
        Notify.show(c, Prefs.N_WALLET, 5000 + idx * 31 + asset.hashCode() % 30,
                "💼 " + label + ": " + (delta > 0 ? "paisa AAYA" : "paisa GAYA"), text, delta > 0 ? 0xFF0ECB81 : 0xFFF6465D,
                MainActivity.TAB_WALLET);
    }
}
