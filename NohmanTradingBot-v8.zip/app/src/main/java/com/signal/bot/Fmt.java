package com.signal.bot;

import java.util.Locale;

final class Fmt {
    private Fmt() {}

    static double clamp(double v, double lo, double hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    static String usd(double v) {
        double a = Math.abs(v);
        String s;
        if (a >= 1e9) s = String.format(Locale.US, "$%.2fB", a / 1e9);
        else if (a >= 1e6) s = String.format(Locale.US, "$%.2fM", a / 1e6);
        else if (a >= 1e3) s = String.format(Locale.US, "$%.1fK", a / 1e3);
        else s = String.format(Locale.US, "$%.0f", a);
        return (v < 0 ? "-" : "") + s;
    }

    static String pct(double v) {
        return String.format(Locale.US, "%+.2f%%", v);
    }

    static String num(double v) {
        return String.format(Locale.US, "%,.0f", v);
    }

    static String price(double p) {
        return Scanner.fmtPrice(p);
    }
}
