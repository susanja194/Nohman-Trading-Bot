package com.signal.bot;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

/** Opens the coin in the Binance APP if installed (falls back to the website). */
public final class BinanceLink {
    private BinanceLink() {}

    public static final String PKG = "com.binance.dev";

    static String web(String base, boolean futures) {
        return futures ? "https://www.binance.com/en/futures/" + base + "USDT"
                : "https://www.binance.com/en/trade/" + base + "_USDT?type=spot";
    }

    /** Best intent: Binance app on the coin's page -> Binance app home -> browser. */
    public static Intent intent(Context c, String base, boolean futures) {
        Uri u = Uri.parse(web(base, futures));
        Intent app = new Intent(Intent.ACTION_VIEW, u).setPackage(PKG);
        app.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            if (app.resolveActivity(c.getPackageManager()) != null) return app;
        } catch (Exception ignored) {
        }
        Intent launch = null;
        try {
            launch = c.getPackageManager().getLaunchIntentForPackage(PKG);
        } catch (Exception ignored) {
        }
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            return launch;
        }
        Intent w = new Intent(Intent.ACTION_VIEW, u);
        w.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return w;
    }

    public static boolean installed(Context c) {
        try {
            return c.getPackageManager().getLaunchIntentForPackage(PKG) != null;
        } catch (Exception e) {
            return false;
        }
    }

    /** Opens Binance; also copies the coin name so the user can paste it in Binance search. */
    public static void open(Context c, String base, boolean futures) {
        try {
            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("coin", base + "USDT"));
        } catch (Exception ignored) {
        }
        try {
            c.startActivity(intent(c, base, futures));
            if (installed(c)) Toast.makeText(c, "Binance app khul raha hai · " + base + "USDT copy ho gaya (search mein paste karein)", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(c, "Binance nahi khula", Toast.LENGTH_SHORT).show();
        }
    }
}
