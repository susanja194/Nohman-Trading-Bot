package com.signal.bot;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Network helpers + one full background scan of Binance spot USDT coins (public data, no API key). */
public final class Scanner {
    private Scanner() {}

    public static final String CH_SIGNALS = "signals";

    private static final String[] HOSTS = {
            "https://data-api.binance.vision",
            "https://api.binance.com",
            "https://api1.binance.com",
            "https://api2.binance.com",
            "https://api-gcp.binance.com"
    };
    private static volatile int hostIdx = 0;
    /** Binance request weight used in the current minute (from the X-MBX-USED-WEIGHT-1M header) + ban window after a 429 / 418. */
    static volatile int usedWeight;
    static volatile long weightAt, banUntil;

    /** True when Binance is close to its per-minute limit: low-priority jobs (hunter) should wait so the SIGNAL scan keeps working. */
    /** Binance weight is high (and Binance is still answering) — when it is banned / blocked, the MEXC backup is used instead. */
    public static boolean weightHigh(int limit) {
        long now = System.currentTimeMillis();
        return now >= banUntil && now >= binanceDownUntil && now - weightAt < 60_000L && usedWeight > limit;
    }

    public static boolean busyBinance(int limit) {
        if (System.currentTimeMillis() < banUntil) return true;
        return System.currentTimeMillis() - weightAt < 60_000L && usedWeight > limit;
    }

    /** Errors that should not be retried on another host. */
    static final class HardFail extends IOException {
        HardFail(String m) { super(m); }
    }

    private static final Set<String> SKIP = new HashSet<>();
    static {
        String[] s = {"USDCUSDT", "FDUSDUSDT", "TUSDUSDT", "BUSDUSDT", "USDPUSDT", "DAIUSDT",
                "EURUSDT", "EURIUSDT", "AEURUSDT", "USDEUSDT", "XUSDUSDT", "PAXGUSDT", "BFUSDUSDT",
                "GBPUSDT", "TRYUSDT", "BRLUSDT", "USD1USDT", "RLUSDUSDT", "PYUSDUSDT"};
        Collections.addAll(SKIP, s);
    }

    /** Binance leveraged tokens (BTCUP, BTCDOWN, ETHBULL...) are not real coins — hidden everywhere. */
    static final java.util.Set<String> LEVERAGED = new java.util.HashSet<>();
    static {
        for (String b : new String[]{"BTC", "ETH", "BNB", "XRP", "ADA", "DOT", "LINK", "LTC", "TRX", "XLM", "EOS", "FIL", "SXP", "UNI", "SUSHI", "AAVE",
                "YFI", "1INCH", "BCH", "XTZ", "EOS"})
            for (String suf : new String[]{"UP", "DOWN", "BULL", "BEAR"}) LEVERAGED.add(b + suf + "USDT");
    }

    static boolean isTradable(String s) {
        return s != null && s.endsWith("USDT") && s.length() > 4 && !SKIP.contains(s) && !LEVERAGED.contains(s);
    }

    private static String read(HttpURLConnection conn) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    /** Fetch any full URL (futures, CoinGecko, news, Glassnode...). */
    static String getAbsolute(String url) throws IOException {
        if (System.currentTimeMillis() < binanceDownUntil && url.contains("binance.com") && !url.contains("binance.com/bapi"))
            throw new IOException("Binance abhi pohanch se bahar (network) — backup data use ho raha hai");
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        try {
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(30000);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) ParaDox/38.0");
            conn.setRequestProperty("Accept", "*/*");
            int code = conn.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code);
            return read(conn);
        } finally {
            conn.disconnect();
        }
    }

    /** Binance spot REST with automatic fallback between mirrors. */
    /** Which exchange answered the last market-data call ("Binance" or the backup "MEXC"). */
    public static volatile String lastSource = "Binance";
    public static volatile long mexcSince;

    /**
     * v33: Binance first; if Binance is blocked / rate-limited / unreachable, the SAME request goes to MEXC
     * (its spot API uses the same paths and formats), so scans, charts and signals keep working.
     */
    /** v34: Binance REST unreachable (blocked network / timeouts): skip it for a few minutes and use MEXC straight away. */
    public static volatile long binanceDownUntil;

    static String get(String path) throws IOException {
        if (System.currentTimeMillis() < binanceDownUntil && mexcPath(path) != null) {
            try {
                String s = getAbsolute("https://api.mexc.com" + mexcPath(path));
                lastSource = "MEXC";
                return s;
            } catch (IOException e) {
                binanceDownUntil = 0;   // MEXC failed too — try Binance again below
            }
        }
        try {
            String s = getBinance(path);
            lastSource = "Binance";
            return s;
        } catch (IOException e) {
            if (e instanceof HardFail && e.getMessage() != null && e.getMessage().contains("nahi mila")) throw e;   // coin not on Binance
            String m = mexcPath(path);
            if (m == null) throw e;
            try {
                String s = getAbsolute("https://api.mexc.com" + m);
                if (!"MEXC".equals(lastSource)) mexcSince = System.currentTimeMillis();
                lastSource = "MEXC";
                return s;
            } catch (IOException e2) {
                throw e;
            }
        }
    }

    /** Binance path -> MEXC path (null when MEXC has no such endpoint). */
    static String mexcPath(String path) {
        if (path.startsWith("/api/v3/ticker?")) return null;              // rolling windows: Binance only
        String p = path.replace("type=MINI&", "").replace("?type=MINI", "").replace("&type=MINI", "");
        if (p.startsWith("/api/v3/ticker/price?symbols=")) return "/api/v3/ticker/price";   // all prices (callers pick theirs)
        if (p.startsWith("/api/v3/klines")) {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("interval=([0-9a-zA-Z]+)").matcher(p);
            if (m.find()) {
                String iv = m.group(1), mx;
                switch (iv) {
                    case "1h": mx = "60m"; break;
                    case "2h": case "4h": mx = "4h"; break;
                    case "3m": mx = "5m"; break;
                    case "6h": case "8h": case "12h": mx = "4h"; break;
                    case "3d": mx = "1d"; break;
                    case "1w": mx = "1W"; break;
                    default: mx = iv;
                }
                p = p.replace("interval=" + iv, "interval=" + mx);
            }
            p = p.replaceAll("limit=(\\d{4,})", "limit=1000");
        }
        return p;
    }

    static String getBinance(String path) throws IOException {
        long now0 = System.currentTimeMillis();
        long wait = banUntil - now0;
        if (wait > 0) throw new HardFail("Binance rate limit, " + (wait / 1000 + 1) + " sec baad");
        IOException last = new IOException("Binance tak pohanch nahi ho rahi");
        boolean anyTried = false;
        long soonest = Long.MAX_VALUE;
        for (int a = 0; a < HOSTS.length; a++) {
            int idx = (hostIdx + a) % HOSTS.length;
            // v31: a 429 / 418 on one host only parks THAT host (data-api.binance.vision has its own limits) — the next host is tried
            if (HOST_BAN[idx] > now0) { soonest = Math.min(soonest, HOST_BAN[idx]); continue; }
            anyTried = true;
            if (HOST_DOWN[idx] > now0) continue;   // v34: this mirror timed out recently
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(HOSTS[idx] + path).openConnection();
                conn.setConnectTimeout(6000);   // v34: a blocked network used to hang 15 s × 5 mirrors per request
                conn.setReadTimeout(20000);
                conn.setRequestProperty("User-Agent", "ParaDox/38.0");
                int code = conn.getResponseCode();
                try {
                    String w = conn.getHeaderField("X-MBX-USED-WEIGHT-1M");
                    if (w != null) { usedWeight = Integer.parseInt(w.trim()); weightAt = System.currentTimeMillis(); }
                } catch (Exception ignored) {
                }
                if (code == 200) {
                    String s = read(conn);
                    hostIdx = idx;
                    return s;
                }
                if (code == 429 || code == 418) {
                    long ra = 60;
                    try { ra = Long.parseLong(conn.getHeaderField("Retry-After").trim()); } catch (Exception ignored) { }
                    HOST_BAN[idx] = System.currentTimeMillis() + Math.max(30, Math.min(ra, 3600)) * 1000L;
                    soonest = Math.min(soonest, HOST_BAN[idx]);
                    last = new HardFail("Binance rate limit (" + code + "), thora wait");
                    continue;
                }
                if (code == 400) throw new HardFail("Yeh coin Binance spot (USDT) par nahi mila");
                last = new IOException("HTTP " + code);
            } catch (HardFail e) {
                throw e;
            } catch (IOException e) {
                last = e;
                HOST_DOWN[idx] = System.currentTimeMillis() + 5 * 60_000L;   // timeout / blocked / DNS: park this mirror 5 min
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
        boolean allDown = true;
        for (long b : HOST_DOWN) if (b <= System.currentTimeMillis()) { allDown = false; break; }
        if (allDown) binanceDownUntil = System.currentTimeMillis() + 5 * 60_000L;   // every mirror unreachable -> MEXC for 5 min
        boolean allBanned = true;
        for (long b : HOST_BAN) if (b <= System.currentTimeMillis()) { allBanned = false; break; }
        if (allBanned && soonest != Long.MAX_VALUE) {   // every host is parked: everyone waits until the first one is free again
            banUntil = soonest;
            throw new HardFail("Binance rate limit — sab servers ne roka, " + ((soonest - System.currentTimeMillis()) / 1000 + 1) + " sec baad");
        }
        if (!anyTried) throw new HardFail("Binance rate limit, thora wait");
        throw last;
    }

    private static final long[] HOST_BAN = new long[HOSTS.length], HOST_DOWN = new long[HOSTS.length];

    /** Runs one scan. Returns a short status line. */
    public static String runOnce(Context ctx, int mode) throws Exception {
        String tf = Prefs.timeframe(ctx, mode);
        int top = Prefs.topCoins(ctx, mode);
        double minVol = Prefs.minVolMillion(ctx, mode) * 1_000_000.0;
        int buyTh = Prefs.buyThreshold(ctx, mode);
        int sellTh = Prefs.sellThreshold(ctx, mode);
        double volMult = Prefs.volMult(ctx, mode);
        boolean smart = Prefs.smartMoney(ctx);
        boolean accuracy = Prefs.accuracyMode(ctx);
        int minWr = Prefs.minWinRate(ctx);
        boolean strong = Prefs.strongConfirm(ctx) || accuracy;
        double whaleUsd = Prefs.whaleUsd(ctx);

        String[] fg = SmartMoney.fearGreed();
        int fgVal = -1;
        if (fg != null) {
            try { fgVal = Integer.parseInt(fg[0]); } catch (Exception ignored) { }
        }

        boolean btcBull = true;
        try {
            Candles b = Candles.fetch("BTCUSDT", "1h", 120, true);
            btcBull = Analyzer.isBullish(b.close);
        } catch (Exception ignored) {
        }

        JSONArray tick = new JSONArray(get("/api/v3/ticker/24hr?type=MINI"));
        List<JSONObject> coins = new ArrayList<>();
        Map<String, JSONObject> all = new HashMap<>();
        for (int i = 0; i < tick.length(); i++) {
            JSONObject t = tick.getJSONObject(i);
            String s = t.optString("symbol");
            if (!isTradable(s) || t.optDouble("lastPrice", 0) <= 0) continue;
            all.put(s, t);
            NewsEngine.KNOWN.add(s.substring(0, s.length() - 4));
            if (t.optDouble("quoteVolume", 0) < minVol) continue;
            coins.add(t);
        }
        Collections.sort(coins, (a, b2) -> Double.compare(b2.optDouble("quoteVolume", 0), a.optDouble("quoteVolume", 0)));
        if (coins.size() > top) coins = new ArrayList<>(coins.subList(0, top));
        Set<String> have = new HashSet<>();
        for (JSONObject t : coins) have.add(t.optString("symbol"));
        for (String w : Prefs.watchlist(ctx)) {
            if (!have.contains(w) && all.containsKey(w)) coins.add(all.get(w));
        }
        // 🎯 focus mode: scan ONLY the user's chosen coins (always the full analysis pipeline)
        final boolean focus = Prefs.focusOn(ctx);
        if (focus) {
            coins = new ArrayList<>();
            for (String f : Prefs.focusCrypto(ctx, mode)) if (all.containsKey(f)) coins.add(all.get(f));
            strong = true;
        }

        NewsEngine.fetch(ctx, 10 * 60_000L);   // coin news for confirmation (cached)
        CatalystEngine.fetch(ctx, 30 * 60_000L);   // upcoming unlocks / listings / delistings (cached)
        ChinaPulse.fetch(30 * 60_000L);            // China demand (cached)
        boolean newsNear = false;
        if (Prefs.newsPause(ctx)) {
            try {
                newsNear = MacroEngine.highImpactNear(ctx, 30);
            } catch (Exception ignored) {
            }
        }
        // v32: FASTER — download every coin's candles in parallel first (6 at a time), then analyse from memory
        final Map<String, Candles> preK = new java.util.concurrent.ConcurrentHashMap<>();
        {
            java.util.concurrent.ExecutorService ex6 = java.util.concurrent.Executors.newFixedThreadPool(6);
            List<java.util.concurrent.Callable<Void>> jobs = new ArrayList<>();
            final String ftf = tf;
            for (JSONObject t : coins) {
                final String sy = t.optString("symbol");
                jobs.add(() -> {
                    if (busyBinance(4800)) return null;   // near the limit: the loop fetches the rest one by one
                    try { preK.put(sy, Candles.fetch(sy, ftf, 200, true)); } catch (Exception ignored) { }
                    return null;
                });
            }
            try { ex6.invokeAll(jobs, 90, java.util.concurrent.TimeUnit.SECONDS); } catch (InterruptedException e) { ex6.shutdownNow(); throw e; }
            ex6.shutdownNow();
        }
        int scanned = 0, alerts = 0;
        final Map<String, Integer> rej = new java.util.LinkedHashMap<>();   // why candidates did NOT become signals (shown in the Signals tab)
        int cands = 0;
        boolean limited = false;
        for (JSONObject t : coins) {
            if (!ScannerService.running) break;
            String sym = t.optString("symbol");
            try {
                Candles k = preK.get(sym);
                if (k == null) k = Candles.fetch(sym, tf, 200, true);
                Analyzer.Result r = Analyzer.analyze(k.open, k.close, k.vol, k.takerBuy, volMult);
                scanned++;
                if (smart && (r.buyScore >= buyTh - 3 || r.sellScore >= sellTh - 3)) {
                    SmartMoney.enrich(sym, r, whaleUsd, true);
                }
                if (fgVal >= 80) {
                    r.buyScore -= 1;
                    r.buyReasons.add("Market Extreme Greed (" + fgVal + ") — ehtiyat");
                } else if (fgVal >= 0 && fgVal <= 20 && r.buyScore > 0) {
                    r.buyReasons.add("Market Extreme Fear (" + fgVal + ") — aksar achha entry time");
                }
                // v38 fix: a weak BTC used to BLOCK every BUY (no signals for days in a falling market). Now it only raises the bar by
                // one point — the later checks (all-source report, structure, confirmation) still decide.
                boolean btcOk = btcBull || !Prefs.btcFilter(ctx) || sym.equals("BTCUSDT");
                boolean buyCand = r.buyScore >= (btcOk ? buyTh : buyTh + 1);
                if (newsNear) {
                    Thread.sleep(120);
                    continue;   // high-impact US news within ±30 min: no new signals (fake moves likely)
                }
                boolean sellCand = !buyCand && r.sellScore >= sellTh && r.volumeOutflow;
                if (focus) {   // chosen coins: looser first filter — every later check (flow, MA, backtest, news, catalysts) still decides
                    if (!buyCand && !sellCand) {
                        if (r.buyScore >= Math.max(1, buyTh - 3) && r.buyScore >= r.sellScore) buyCand = true;
                        else if (r.sellScore >= Math.max(1, sellTh - 3)) sellCand = true;
                    }
                }
                // ---- money flow: Binance exact (+ all exchanges for spot)
                HeavyFlow.Result hf = null;
                MarketFlow.Result mf = null;
                double sellUsd = Prefs.spotSellUsd(ctx) * 1_000_000.0;
                double heavyThr = 0, enoughThr = 0;
                boolean fastTrack = false;
                if (mode == Mode.SPOT) {
                    // spot: BUY only on a good entry; SELL only when HEAVY selling ($5M+ / hour, ALL exchanges) puts holders at risk.
                    // A pullback in an uptrend is a good spot entry even without a volume spike -> looser first filter,
                    // the strict multi-timeframe SpotPlan below decides.
                    if (!buyCand && r.buyScore >= (btcOk ? buyTh - 2 : buyTh - 1) && Analyzer.isBullish(k.close)) buyCand = true;
                    if (buyCand || r.sellScore >= 2 || r.volumeOutflow) {
                        try { hf = HeavyFlow.fetch(sym); } catch (HardFail e) { throw e; } catch (Exception ignored) { }
                    }
                    // only ask every exchange when Binance already shows something worth checking
                    if (hf != null && (buyCand || hf.net1h() <= -sellUsd * 0.4 || hf.net4h() <= -sellUsd * 0.8))
                        mf = MarketFlow.fetch(sym.substring(0, sym.length() - 4), hf);
                    double n1 = mf != null ? mf.net1h() : hf != null ? hf.net1h() : 0, n4 = mf != null ? mf.net4h() : hf != null ? hf.net4h() : 0;
                    sellCand = !buyCand && hf != null && hf.net1h() < 0 && (n1 <= -sellUsd || n4 <= -2 * sellUsd);
                    if (buyCand && n4 <= -sellUsd) buyCand = false;
                } else {
                    // scalp: heavy buying -> BUY fast, heavy selling -> SELL fast; smaller flows also count when they are
                    // big enough to move THIS coin's price (learned price-impact model)
                    double qn = HeavyFlow.quickNet(k, 15 * 60_000L), qg = HeavyFlow.quickGross(k, 15 * 60_000L);
                    boolean pre = buyCand || sellCand || (qg > 0 && Math.abs(qn) >= 0.12 * qg);
                    if (pre) {
                        try { hf = HeavyFlow.fetch(sym); } catch (HardFail e) { throw e; } catch (Exception ignored) { }
                    }
                    if (hf == null) { buyCand = false; sellCand = false; }
                    else {
                        heavyThr = HeavyFlow.scalpThreshold(Prefs.scalpHeavyUsd(ctx) * 1000.0, hf.gross[0]);
                        enoughThr = HeavyFlow.scalpEnough(hf, heavyThr);
                        double n15 = hf.net15();
                        boolean imb = hf.gross[0] > 0 && Math.abs(n15) >= 0.08 * hf.gross[0];
                        boolean heavyBuy = n15 >= heavyThr && hf.move15Pct > 0;
                        boolean heavySell = n15 <= -heavyThr && hf.move15Pct < 0;
                        boolean b2 = heavyBuy || (buyCand && n15 >= enoughThr && imb && hf.move15Pct >= 0);
                        boolean s2 = !b2 && (heavySell || (sellCand && n15 <= -enoughThr && imb && hf.move15Pct <= 0));
                        if (b2 && !(btcBull || !Prefs.btcFilter(ctx) || sym.equals("BTCUSDT")) && !heavyBuy) b2 = false;
                        buyCand = b2;
                        sellCand = s2;
                        fastTrack = heavyBuy || heavySell;
                    }
                }
                if (buyCand || sellCand) {
                    cands++;
                    String side = buyCand ? "BUY" : "SELL";
                    if (!Prefs.cooldownOk(ctx, mode, sym, side)) bump(rej, "⏸️ cooldown (haal hi mein signal diya)");
                    if (Prefs.cooldownOk(ctx, mode, sym, side)) {
                        int score = buyCand ? r.buyScore : r.sellScore;
                        String why = join(buyCand ? r.buyReasons : r.sellReasons);
                        boolean confirmed = false, reject = false;
                        double atrK = Indicators.atr(k.high, k.low, k.close, 14);
                        double risk = Math.max(atrK * Mode.stopAtr(mode), r.price * 0.003);
                        double sl = buyCand ? r.price - risk : r.price + risk;
                        double tp = buyCand ? r.price + 1.5 * risk : r.price - 1.5 * risk;
                        Position.Advice adv = Position.compute(buyCand, r.price, atrK, Mode.stopAtr(mode), null, 0, 0,
                                r.buyRatio * 100, Double.NaN);
                        CoinReport rep = null;
                        if (fastTrack) {   // heavy scalp flow: send at once (only the news safety checks)
                            String bs = sym.substring(0, sym.length() - 4);
                            if (buyCand && (NewsEngine.criticalBearish(bs, 2 * 3600_000L) != null || NewsEngine.marketRisk(90 * 60_000L) != null)) reject = true;
                            confirmed = true;
                            score = buyCand ? Math.max(score, 70) : Math.max(score, 70);
                            why = "⚡ FAST: heavy " + (buyCand ? "buying" : "selling") + " — 15 min mein net " + (hf.net15() >= 0 ? "+" : "−")
                                    + Fmt.usd(Math.abs(hf.net15())) + String.format(Locale.US, " · price %+.2f%%", hf.move15Pct) + "\n" + why;
                        } else if (strong) {
                            try {
                                rep = CoinReport.build(sym, mode, "", whaleUsd, false);
                                if (buyCand && rep.total < 60) { reject = true; bump(rej, "📉 all-source score 60 se kam"); }
                                if (sellCand && rep.total > (mode == Mode.SPOT ? 45 : 38)) { reject = true; bump(rej, "📈 all-source score SELL ke liye zyada"); }
                                if (!reject && rep.confidence < Prefs.minConfidence(ctx) && !(mode == Mode.SPOT && sellCand)) { reject = true; bump(rej, "🤔 confidence kam"); }
                                if (accuracy && !reject && !(mode == Mode.SPOT && sellCand)) {
                                    reject = !accuracyOk(rep, buyCand, minWr);
                                    if (reject) bump(rej, "🎯 accuracy: 7 mein se 4 confluence nahi (MA, timeframes, rule, backtest " + minWr + "%, 12 indicators, ADX, golden/death cross)");
                                }
                                if (!reject && buyCand && NewsEngine.criticalBearish(sym.substring(0, sym.length() - 4), 2 * 3600_000L) != null) { reject = true; bump(rej, "📰 buri khabar"); }
                                if (!reject && buyCand && CatalystEngine.buyBlocker(sym.substring(0, sym.length() - 4)) != null) { reject = true; bump(rej, "📆 unlock / delisting aage"); }   // big unlock / delisting ahead
                                if (!reject && buyCand && accuracy && NewsEngine.marketRisk(90 * 60_000L) != null) { reject = true; bump(rej, "⚠️ market risk news"); }   // e.g. big exchange hack / depeg
                                if (!reject) {
                                    score = rep.total;
                                    if (rep.stop > 0 && rep.target1 > 0) {
                                        sl = rep.stop;
                                        tp = rep.target1;
                                    }
                                    if (rep.advice != null) adv = rep.advice;
                                    confirmed = true;
                                    why = "✅ Score " + rep.total + "/100 (" + rep.verdict + ", confidence " + rep.confidence + "%) · "
                                            + rep.flowLabel + "\n📐 " + rep.patterns.name + "\n" + why;
                                }
                            } catch (HardFail e) {
                                throw e;
                            } catch (Exception ignored) {
                                // all-source check failed -> fall back to the basic signal (not in accuracy mode)
                                if (accuracy) { reject = true; bump(rej, "🌐 all-source data load nahi hua"); }
                            }
                        }
                        SpotPlan.Plan se = null;
                        if (!reject && mode == Mode.SPOT && buyCand) {
                            try {
                                se = SpotPlan.build(sym, r.price, mf, sellUsd);
                                if (!se.ok) { reject = true; bump(rej, "💎 spot entry abhi achhi nahi (1h/4h/1d/1w plan)"); }
                            } catch (HardFail e) {
                                throw e;
                            } catch (Exception e) {
                                reject = true;
                                bump(rej, "💎 spot plan data load nahi hua");
                            }
                        }
                        // ---- one coin, one open signal: a 2nd signal only on HEAVY buying (BUY) / HEAVY selling (SELL)
                        String repeatNote = null;
                        if (!reject) {
                            JSONObject openSig = openSignal(ctx, sym);
                            if (openSig != null) {
                                if (hf == null) {
                                    try { hf = HeavyFlow.fetch(sym); } catch (HardFail e) { throw e; } catch (Exception ignored) { }
                                }
                                String heavy = heavyFor(ctx, hf, mf, buyCand);
                                if (heavy == null) { reject = true; bump(rej, "🔒 pehle se open signal (2nd sirf heavy flow par)"); }   // normal flow -> the existing open signal is enough
                                else {
                                    boolean same = side.equals(openSig.optString("side"));
                                    repeatNote = (same ? "🔁 DOBARA " + side + " — " : "🔄 PALTA: pehle " + openSig.optString("side") + " tha, ab " + side + " — ") + heavy;
                                    if (!same) closeSignal(ctx, openSig, r.price);   // opposite heavy flow: close the old idea
                                }
                            }
                        }
                        // ---- v29: structure — WIN only after the next resistance (BUY) / support (SELL) breaks, stop beyond support / resistance
                        Levels.Structure stc = null;
                        if (!reject) {
                            try {
                                String htf = tf.endsWith("m") ? "1h" : tf.equals("1h") ? "4h" : "1d";
                                Candles hk = null;
                                try { hk = Candles.fetch(sym, htf, 200, true); } catch (HardFail e) { throw e; } catch (Exception ignored) { }
                                stc = Levels.plan(k, hk, r.price, buyCand, 1.3);
                                if (!stc.ok) { reject = true; bump(rej, "🧱 " + (buyCand ? "resistance" : "support") + " bahut qareeb (reward < 1.3× risk)"); }
                            } catch (HardFail e) {
                                throw e;
                            } catch (Exception e) {
                                stc = null;
                            }
                        }
                        // ---- v29: one STRONG signal — the setup must still be there on a later scan (10+ min, 4+ min for heavy scalp flow)
                        if (!reject && !confirmPending(ctx, mode, sym, side, r.price, stc != null ? stc.atr : r.price * 0.01,
                                (fastTrack ? 3 : 5) * 60_000L, Math.max(75, 3 * Prefs.intervalMin(ctx, mode)) * 60_000L, rej)) reject = true;
                        if (!reject) {
                            Prefs.markCooldown(ctx, mode, sym, side);
                            JSONObject ex = new JSONObject();
                            try {
                                ex.put("tf", tf);
                                ex.put("adv", adv.title);
                                ex.put("advWhy", adv.why);
                                ex.put("type", adv.type);
                                ex.put("zlo", adv.zoneLo);
                                ex.put("zhi", adv.zoneHi);
                                ex.put("entry", adv.entry);
                                ex.put("tp2", adv.tp2);
                                if (adv.sl > 0) sl = adv.sl;
                                if (adv.tp1 > 0) tp = adv.tp1;
                                ex.put("mkt", Assets.CRYPTO);
                                ex.put("acc", accuracy);
                                if (rep != null) putLearning(ex, rep, buyCand, r);
                                else ex.put("checks", basicChecks(r, buyCand));
                                JSONArray ck = ex.optJSONArray("checks");
                                if (ck == null) { ck = new JSONArray(); ex.put("checks", ck); }
                                if (mf != null) {
                                    ck.put("🌐 Sab exchanges ka paisa (IN / OUT):");
                                    for (String l : mf.lines()) ck.put("   " + l);
                                } else if (hf != null) {
                                    ck.put("💵 Asal paisa (Binance spot + futures, aggressive buy − sell):");
                                    for (String l : hf.lines()) ck.put("   " + l);
                                }
                                if (mode == Mode.SCALP && hf != null) {
                                    ck.put((fastTrack ? "⚡ HEAVY " : "✅ ") + (buyCand ? "BUYING: 15 min net +" : "SELLING: 15 min net −") + Fmt.usd(Math.abs(hf.net15()))
                                            + " · is coin ko hilane ke liye kaafi: " + Fmt.usd(enoughThr) + " · heavy had: " + Fmt.usd(heavyThr));
                                    ck.put(String.format(Locale.US, "📏 Price impact: $1M net ≈ %.2f%% move (pichle 24h ka hisaab) · 5m ATR %.2f%%", hf.impactPerM, hf.atr5Pct));
                                }
                                if (se != null) {
                                    ck.put("📅 Spot plan (1h · 4h · 1d · 1w):");
                                    for (String l : se.checks) ck.put("   " + l);
                                    sl = se.sl;
                                    tp = se.tp[0];
                                    ex.put("tp2", se.tp[1]);
                                    ex.put("tp3", se.tp[2]);
                                    ex.put("tp4", se.tp[3]);
                                    JSONArray tl = new JSONArray();
                                    for (String l : se.tpLbl) tl.put(l);
                                    ex.put("tpl", tl);
                                    ex.put("maxAge", se.maxAgeMs);
                                    ex.put("zlo", se.zoneLo);
                                    ex.put("zhi", se.zoneHi);
                                    ex.put("entry", r.price);
                                    ex.put("type", Position.NOW);
                                    ex.put("horizon", se.horizon);
                                    ex.put("adv", "✅ SPOT BUY — achhi entry ABHI (" + se.horizon + ")");
                                    ex.put("advWhy", se.why + ". 4 targets waqt ke hisaab se: " + se.tpLbl[0] + " · " + se.tpLbl[1] + " · " + se.tpLbl[2] + " · " + se.tpLbl[3]
                                            + ". Har TP par thora profit lein aur stop upar le aayen.");
                                    ex.put("ntitle", "💎 SPOT BUY (" + se.horizon + "): " + sym.substring(0, sym.length() - 4));
                                }
                                if (mode == Mode.SPOT && sellCand && hf != null) {
                                    double n1 = mf != null ? mf.net1h() : hf.net1h(), n4 = mf != null ? mf.net4h() : hf.net4h();
                                    String out1 = Fmt.usd(Math.abs(Math.min(n1, 0))), out4 = Fmt.usd(Math.abs(Math.min(n4, 0)));
                                    ex.put("adv", "🚨 HEAVY SELLING — " + (mf != null ? mf.venues.size() + " exchanges par " : "") + "1 ghante mein " + out1 + " · 4 ghante mein " + out4 + " net nikle");
                                    ex.put("advWhy", "Bade players bech rahe hain — spot holders ke liye zyada nuksan ka khatra. Profit bacha lein ya stop tight karein; "
                                            + "naya BUY tab tak nahi jab tak selling ruk na jaye aur price support par sambhal na jaye.");
                                    ex.put("ntitle", "🚨 SPOT SELL: " + sym.substring(0, sym.length() - 4) + " — heavy selling " + out1 + "/1h");
                                    ex.put("type", "HEAVY_SELL");
                                }
                                if (repeatNote != null) {
                                    ex.put("repeat", repeatNote);
                                    JSONArray ck2 = ex.optJSONArray("checks");
                                    if (ck2 != null) ck2.put(repeatNote);
                                }
                                if (mode == Mode.SCALP && hf != null)
                                    ex.put("ntitle", "⚡ " + (fastTrack ? "FAST " : "") + (buyCand ? "SCALP BUY: " : "SCALP SELL: ") + sym.substring(0, sym.length() - 4)
                                            + " — " + (fastTrack ? "heavy " : "") + (buyCand ? "buying +" : "selling −") + Fmt.usd(Math.abs(hf.net15())) + "/15m");
                            } catch (Exception ignored) {
                            }
                            if (repeatNote != null) {
                                try { ex.put("ntitle", (repeatNote.startsWith("🔁") ? "🔁 " : "🔄 ") + ex.optString("ntitle", side + ": " + sym.substring(0, sym.length() - 4))); } catch (Exception ignored) { }
                            }
                            if (stc != null) {
                                // structure levels decide win / loss (spot ladder keeps its bigger targets above TP1)
                                if (buyCand) {
                                    if (se == null || sl >= stc.support) sl = stc.sl;
                                    tp = Math.max(tp, stc.tp1);
                                } else {
                                    if (sl <= stc.resistance || sl <= 0) sl = stc.sl;
                                    tp = tp > 0 ? Math.min(tp, stc.tp1) : stc.tp1;
                                }
                                try {
                                    if (ex.has("tp2")) {
                                        double t2 = ex.optDouble("tp2", 0);
                                        if (buyCand ? t2 <= tp : t2 >= tp) ex.put("tp2", buyCand ? Math.max(tp, stc.tp2) : Math.min(tp, stc.tp2));
                                    } else ex.put("tp2", stc.tp2);
                                    for (String tk : new String[]{"tp3", "tp4"}) if (ex.has(tk)) {
                                        double tv = ex.optDouble(tk, 0);
                                        if (buyCand ? tv <= tp : tv >= tp) ex.put(tk, tk.equals("tp3") ? stc.tp3 : (buyCand ? stc.tp3 + (stc.tp3 - stc.tp2) : stc.tp3 - (stc.tp2 - stc.tp3)));
                                    }
                                    JSONArray ck3 = ex.optJSONArray("checks");
                                    if (ck3 != null) ck3.put("🧱 " + stc.why + String.format(Locale.US, " · reward %.1fx risk", stc.rr));
                                    ex.put("struct", stc.why);
                                } catch (Exception ignored) {
                                }
                            }
                            alert(ctx, mode, side, sym, r.price, score, (repeatNote != null ? repeatNote + "\n" : "") + ex.optString("adv", adv.title) + "\n" + why, tf, confirmed, sl, tp, ex);
                            alerts++;
                        }
                    }
                }
            } catch (InterruptedException e) {
                throw e;
            } catch (HardFail e) {
                if (e.getMessage() != null && e.getMessage().startsWith("Binance rate limit")) { limited = true; break; }   // stop now, retry next cycle
            } catch (Exception ignored) {
            }
            Thread.sleep(preK.containsKey(sym) ? 15 : 100);
        }
        if (newsNear) bump(rej, "📅 bada US news ±30 min — signals ruke");
        StringBuilder dg = new StringBuilder();
        dg.append(new SimpleDateFormat("dd MMM HH:mm", Locale.US).format(new Date())).append(" · ").append(scanned).append(" coins jaanche · ")
                .append(cands).append(" candidate · ").append(alerts).append(" signal");
        if (limited) dg.append("\n⛔ Binance ne thori der ke liye rok diya (rate limit) — agle scan mein dobara");
        if ("MEXC".equals(lastSource)) dg.append("\n🔁 Binance ne roka / nahi mila — data MEXC (backup exchange) se liya gaya");
        if (!btcBull && Prefs.btcFilter(ctx)) dg.append("\n🟠 BTC 1h bearish — BUY ke liye 1 point zyada chahiye (pehle poora block tha)");
        if (cands == 0 && !limited) dg.append("\nℹ️ Kisi coin ne pehla filter (score " + buyTh + "+ BUY / " + sellTh + "+ SELL" + (mode == Mode.SPOT ? ", ya $" + Prefs.spotSellUsd(ctx) + "M+ heavy selling" : "") + ") paas nahi kiya — market thanda hai");
        for (Map.Entry<String, Integer> e : rej.entrySet()) dg.append("\n• ").append(e.getValue()).append("× ").append(e.getKey());
        Prefs.putStr(ctx, "diag" + mode, dg.toString());

        String time = new SimpleDateFormat("HH:mm", Locale.US).format(new Date());
        return (limited ? "⛔ Binance rate limit — agle scan mein dobara · " : "") + (newsNear ? "📅 Bada US news qareeb — signals ruke hue · " : "") + Mode.label(mode) + " · last scan " + time + " · " + scanned + " coins (" + tf + ") · " + alerts
                + " naye signal · BTC " + (btcBull ? "bullish ✅" : "bearish ⚠️")
                + (fg != null ? " · Fear&Greed " + fg[0] + " (" + fg[1] + ")" : "");
    }

    /**
     * A candidate becomes a signal only if it is seen again after `minAge` (and before `maxAge`) and the price did not turn
     * against it by more than 0.6 ATR in between. First sighting just starts the clock.
     */
    static boolean confirmPending(Context ctx, int mode, String sym, String side, double price, double atr, long minAge, long maxAge, Map<String, Integer> rej) {
        String key = "pend" + mode + "_" + sym + "_" + side;
        String v = Prefs.getStr(ctx, key, "");
        long now = System.currentTimeMillis();
        long t0 = 0;
        double p0 = 0;
        try { String[] a = v.split(","); t0 = Long.parseLong(a[0]); p0 = Double.parseDouble(a[1]); } catch (Exception ignored) { }
        boolean buy = "BUY".equals(side);
        if (t0 == 0 || now - t0 > maxAge) {
            Prefs.putStr(ctx, key, now + "," + price);
            bump(rej, "⏳ pehli dafa dekha — " + (minAge / 60_000) + "+ min baad dobara confirm hoga");
            return false;
        }
        if (buy ? price < p0 - 0.6 * atr : price > p0 + 0.6 * atr) {
            Prefs.putStr(ctx, key, now + "," + price);
            bump(rej, "↩️ confirm se pehle price ulti chali — dobara shuru");
            return false;
        }
        if (now - t0 < minAge) { bump(rej, "⏳ confirm hone ka intezar (" + ((minAge - (now - t0)) / 60_000 + 1) + " min)"); return false; }
        Prefs.putStr(ctx, key, "");
        return true;
    }

    static void bump(Map<String, Integer> m, String k) { Integer v = m.get(k); m.put(k, v == null ? 1 : v + 1); }

    /** The newest still-OPEN crypto signal for this coin (any mode), or null. */
    static JSONObject openSignal(Context ctx, String sym) {
        JSONArray a = Prefs.signals(ctx);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && sym.equals(o.optString("sym")) && "open".equals(o.optString("st"))
                    && Assets.CRYPTO.equals(o.optString("mkt", Assets.CRYPTO))) return o;
        }
        return null;
    }

    /**
     * Text if the flow is HEAVY in the signal's direction, else null.
     * Heavy = 15-min net flow beyond the coin's own heavy threshold (relative to its volume),
     * or 1-hour net beyond the spot "heavy" size from Settings (all exchanges when known).
     */
    static String heavyFor(Context ctx, HeavyFlow.Result hf, MarketFlow.Result mf, boolean buy) {
        if (hf == null) return null;
        double thr15 = HeavyFlow.scalpThreshold(Prefs.scalpHeavyUsd(ctx) * 1000.0, hf.gross[0]);
        double n15 = hf.net15(), n1 = mf != null ? mf.net1h() : hf.net1h();
        double big = Prefs.spotSellUsd(ctx) * 1_000_000.0;
        boolean h15 = buy ? n15 >= thr15 && hf.move15Pct >= 0 : n15 <= -thr15 && hf.move15Pct <= 0;
        boolean h1 = buy ? n1 >= big : n1 <= -big;
        if (!h15 && !h1) return null;
        return (buy ? "HEAVY BUYING: " : "HEAVY SELLING: ") + (h15 ? "15 min net " + (n15 >= 0 ? "+" : "−") + Fmt.usd(Math.abs(n15)) : "")
                + (h15 && h1 ? " · " : "") + (h1 ? "1 ghanta net " + (n1 >= 0 ? "+" : "−") + Fmt.usd(Math.abs(n1)) : "");
    }

    /** Closes an open signal at the current price (used when heavy flow flips the direction). */
    static void closeSignal(Context ctx, JSONObject sig, double price) {
        JSONArray a = Prefs.signals(ctx);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null || o.optLong("t") != sig.optLong("t") || !o.optString("sym").equals(sig.optString("sym"))) continue;
            try {
                double entry = o.optDouble("price", 0);
                boolean buy = "BUY".equals(o.optString("side"));
                o.put("st", "expired");
                o.put("exit", price);
                o.put("pnl", entry > 0 ? (buy ? price / entry - 1 : 1 - price / entry) * 100 : 0);
                o.put("closedBy", "Ulti heavy flow — naya signal");
            } catch (Exception ignored) {
            }
        }
        Prefs.saveSignals(ctx, a);
    }

    /** Accuracy-mode gate: MA trend, timeframes and the rule's own backtest must all agree. */
    static boolean accuracyOk(CoinReport rep, boolean buy, int minWr) {
        // v30: confluence POINTS instead of "every single check must pass" (that blocked almost every signal).
        // Hard rules: the full report agrees on the side, and the rule's own backtest is not clearly bad.
        if (rep.ma == null || rep.bt == null || rep.isBuy != buy) return false;
        if (rep.bt.enough() && rep.bt.winRate < minWr - 8) return false;
        int pts = 0;
        if (buy ? rep.ma.score >= 15 : rep.ma.score <= -15) pts++;                         // moving-average trend
        if (buy ? rep.mtfAgree > 0 : rep.mtfAgree < 0) pts++;                              // higher timeframes agree
        if (rep.ruleSide == (buy ? 1 : -1)) pts++;                                         // ParaDox rule fired this way
        if (rep.bt.enough() && rep.bt.winRate >= minWr) pts++;                             // backtest win rate
        if (rep.ind != null && rep.ind.total > 0 && rep.ind.agreement(buy) >= 55) pts++;   // 12-indicator majority
        if (rep.ind != null && rep.ind.adx >= 18) pts++;                                   // a real trend, not chop
        int g = rep.ma.lastGoldenAgo, dc = rep.ma.lastDeathAgo;                            // golden / death cross regime
        boolean goldenNow = g >= 0 && (dc < 0 || g < dc), deathNow = dc >= 0 && (g < 0 || dc < g);
        if (buy ? !deathNow : !goldenNow) pts++;
        if (buy && deathNow && rep.ma.lastDeathAgo <= 30) return false;                    // fresh death cross: no BUY
        if (!buy && goldenNow && rep.ma.lastGoldenAgo <= 30) return false;                 // fresh golden cross: no SELL
        return pts >= 4;   // v31: 4 of 7 (with the hard rules above + structure + confirmation still applied)
    }

    /** Saves "how this signal was built" so the Signals tab can teach it step by step. */
    static void putLearning(JSONObject ex, CoinReport rep, boolean buy, Analyzer.Result r) throws Exception {
        JSONArray checks = new JSONArray();
        checks.put((buy ? rep.total >= 62 : rep.total <= 38) ? "✅ All-source score " + rep.total + "/100 (" + rep.verdict + ")"
                : "❌ All-source score " + rep.total + "/100");
        checks.put("✅ Confidence " + rep.confidence + "%");
        for (CoinReport.Section sec : rep.sections) {
            if (!sec.available) continue;
            boolean agree = buy ? sec.score > 0 : sec.score < 0;
            checks.put((sec.score == 0 ? "➖ " : agree ? "✅ " : "❌ ") + sec.icon + " " + sec.title + " — score " + (sec.score > 0 ? "+" : "") + sec.score
                    + " (weight " + sec.weight + ")");
        }
        if (rep.ma != null) checks.put("〰️ " + rep.ma.trend);
        for (String c : rep.ruleChecks) checks.put("   " + c);
        if (rep.bt != null && rep.bt.trades > 0)
            checks.put(String.format(Locale.US, "%s Backtest: %d trades, win rate %.0f%% (1R target), avg %.2fR",
                    rep.bt.winRate >= 55 ? "✅" : "⚠️", rep.bt.trades, rep.bt.winRate, rep.bt.avgR));
        checks.put((buy ? rep.mtfAgree > 0 : rep.mtfAgree < 0) ? "✅ Timeframes agree (" + rep.mtfAgree + ")" : "⚠️ Timeframes mixed (" + rep.mtfAgree + ")");
        if (rep.cross != null) checks.put("🌐 " + rep.flowLabel);
        if (rep.ind != null && rep.ind.total > 0)
            checks.put(String.format(Locale.US, "%s 12 indicators: %.0f%% %s ke haq mein · ADX %.0f", rep.ind.agreement(buy) >= 55 ? "✅" : "⚠️",
                    rep.ind.agreement(buy), buy ? "BUY" : "SELL", rep.ind.adx));
        if (rep.patterns != null) checks.put("📐 Pattern: " + rep.patterns.name);
        for (CatalystEngine.Event ce : CatalystEngine.forCoin(rep.base, 7L * 86_400_000L))
            checks.put("📆 " + ce.icon() + " " + CatalystEngine.label(ce) + " · " + MacroEngine.pkt(ce.time) + (ce.estimated ? " (andaza)" : "") + ": " + ce.title);
        NewsEngine.Item mr = NewsEngine.marketRisk(3 * 3600_000L);
        if (mr != null) checks.put("🚨 Market risk news: " + mr.title);
        for (NewsEngine.Item nw : NewsEngine.about(rep.base, 12 * 3600_000L, 3))
            checks.put("📰 " + NewsEngine.dirLabel(nw) + " " + nw.category + ": " + nw.title + " (" + nw.source + ")");
        for (int i = 0; i < rep.news.size() && i < 3; i++) {
            String[] nw = rep.news.get(i);
            checks.put("📰 " + ("+".equals(nw[3]) ? "🟢 " : "-".equals(nw[3]) ? "🔴 " : "⚪ ") + nw[0] + " (" + nw[2] + ")");
        }
        ex.put("checks", checks);
        if (rep.bt != null) {
            ex.put("wr", Math.round(rep.bt.winRate));
            ex.put("bt", rep.bt.trades);
        }
        JSONArray secs = new JSONArray();
        for (CoinReport.Section sec : rep.sections) {
            if (!sec.available) continue;
            JSONObject o = new JSONObject();
            o.put("i", sec.icon);
            o.put("t", sec.title);
            o.put("s", sec.score);
            o.put("w", sec.weight);
            secs.put(o);
        }
        ex.put("secs", secs);
    }

    static JSONArray basicChecks(Analyzer.Result r, boolean buy) {
        JSONArray a = new JSONArray();
        a.put("ℹ️ Basic scan signal (all-source check off)");
        for (String s : buy ? r.buyReasons : r.sellReasons) a.put("✅ " + s);
        a.put(String.format(Locale.US, "RSI %.0f · volume %.1fx · buyers %.0f%%", r.rsi, r.volRatio, r.buyRatio * 100));
        return a;
    }

    private static String join(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (String s : l) {
            if (sb.length() > 0) sb.append("\n");
            sb.append("• ").append(s);
        }
        return sb.toString();
    }

    static String fmtPrice(double p) {
        if (p >= 100) return String.format(Locale.US, "%.2f", p);
        if (p >= 1) return String.format(Locale.US, "%.4f", p);
        if (p >= 0.01) return String.format(Locale.US, "%.5f", p);
        return String.format(Locale.US, "%.8f", p);
    }

    static void alert(Context ctx, int mode, String side, String sym, double price, int score, String why,
                              String tf, boolean strong, double sl, double tp, JSONObject extra) {
        why = why + "\n🎯 TP $" + fmtPrice(tp) + " · 🛑 SL $" + fmtPrice(sl);
        Prefs.addSignal(ctx, mode, side, sym, price, score, why, sl, tp, extra);
        String base = sym.substring(0, sym.length() - 4);

        Intent open = new Intent(ctx, MainActivity.class);
        open.putExtra("coin", sym);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(ctx, (sym + side).hashCode(), open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent web = BinanceLink.intent(ctx, base, mode == Mode.SCALP && "SELL".equals(side));
        PendingIntent wpi = PendingIntent.getActivity(ctx, (sym + "web").hashCode(), web,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        String title = (mode == Mode.SCALP ? "⚡ " : "💎 ");
        if ("BUY".equals(side)) title += (strong ? "STRONG BUY: " : "BUY: ") + base + "/USDT";
        else title += (strong ? "STRONG SELL: " : "SELL (paisa nikal raha): ") + base + "/USDT";
        String nt = extra != null ? extra.optString("ntitle", "") : "";
        if (!nt.isEmpty()) title = nt;
        String text = "🕒 " + new SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.US).format(new Date()) + " · Price " + fmtPrice(price) + " · Score " + score + (strong ? "/100" : "") + " · " + tf;
        if (!Notify.allowed(ctx, Prefs.N_SIGNALS)) return;   // saved in the Signals tab, but no notification

        Notification n = new Notification.Builder(ctx, CH_SIGNALS)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text + "\n" + why))
                .setContentIntent(pi)
                .addAction(new Notification.Action.Builder(null, "🟡 Binance app", wpi).build())
                .setColor("BUY".equals(side) ? 0xFF0ECB81 : 0xFFF6465D)
                .setAutoCancel(true)
                .build();
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify((sym + side + mode).hashCode(), n);
    }

    /**
     * Signal accuracy tracker: checks every open signal against the live price.
     * WIN = target hit first, LOSS = stop hit first, EXPIRED after 4h (scalp) / 48h (spot).
     */
    public static void trackSignals(Context ctx) {
        JSONArray arr = Prefs.signals(ctx);
        java.util.Set<String> syms = new java.util.LinkedHashSet<>();
        for (int i = 0; i < arr.length() && i < 100; i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null || o.optDouble("tp", 0) <= 0 || !Assets.CRYPTO.equals(o.optString("mkt", Assets.CRYPTO))) continue;
            boolean open = "open".equals(o.optString("st", ""));
            boolean ladder = "win".equals(o.optString("st", "")) && o.has("tp4") && o.optInt("hit", 1) < 4
                    && System.currentTimeMillis() - o.optLong("t") < o.optLong("maxAge", 0);
            if (open || ladder) syms.add(o.optString("sym"));
        }
        if (syms.isEmpty()) return;
        Map<String, Double> px = new HashMap<>();
        try {
            StringBuilder q = new StringBuilder("[");
            for (String s : syms) {
                if (q.length() > 1) q.append(',');
                q.append('"').append(s).append('"');
            }
            q.append(']');
            JSONArray pr = new JSONArray(get("/api/v3/ticker/price?symbols=" + java.net.URLEncoder.encode(q.toString(), "UTF-8")));
            for (int i = 0; i < pr.length(); i++) {
                JSONObject o = pr.getJSONObject(i);
                px.put(o.optString("symbol"), o.optDouble("price", 0));
            }
        } catch (Exception e) {
            return;
        }
        boolean changed = false;
        long now = System.currentTimeMillis();
        for (int i = 0; i < arr.length() && i < 100; i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null || !Assets.CRYPTO.equals(o.optString("mkt", Assets.CRYPTO))) continue;
            Double p = px.get(o.optString("sym"));
            if (p == null || p <= 0) continue;
            boolean buy = "BUY".equals(o.optString("side"));
            // multi-target spot signals: keep counting TP2..TP4 after TP1 was hit
            if (o.has("tp4") && ("open".equals(o.optString("st", "")) || "win".equals(o.optString("st", "")))) {
                int hit = o.optInt("hit", 0);
                double[] tps = {o.optDouble("tp", 0), o.optDouble("tp2", 0), o.optDouble("tp3", 0), o.optDouble("tp4", 0)};
                int nh = hit;
                for (int q = hit; q < 4; q++) if (tps[q] > 0 && (buy ? p >= tps[q] : p <= tps[q])) nh = q + 1;
                if (nh > hit) {
                    try {
                        o.put("hit", nh);
                        changed = true;
                    } catch (Exception ignored) {
                    }
                }
            }
            if (!"open".equals(o.optString("st", ""))) continue;
            double entry = o.optDouble("price", 0), sl = o.optDouble("sl", 0), tp = o.optDouble("tp", 0);
            if (entry <= 0 || tp <= 0) continue;
            // v38 fix: SMC Pro signals are LIMIT entries — they are only "in the trade" after the price reaches the entry.
            // Before the fill nothing is counted as win / loss; no fill in time (or the move left without us) = expired, 0%.
            if (o.optBoolean("smc") && !o.optBoolean("filled")) {
                try {
                    if (buy ? p <= entry * 1.0005 : p >= entry * 0.9995) { o.put("filled", true); o.put("fillT", now); changed = true; }
                    else if ((buy ? p >= tp : p <= tp) || now > o.optLong("fillBy", o.optLong("t") + 6 * 3600_000L)) {
                        o.put("st", "expired");
                        o.put("exit", p);
                        o.put("pnl", 0);
                        o.put("note", "Entry fill nahi hui — trade nahi liya gaya");
                        changed = true;
                    }
                } catch (Exception ignored) {
                }
                continue;
            }
            long maxAge = o.optLong("maxAge", o.optInt("mode", Mode.SPOT) == Mode.SCALP ? 4 * 3600_000L : 48 * 3600_000L);
            String st = null;
            if (buy ? p >= tp : p <= tp) st = "win";
            else if (buy ? p <= sl : p >= sl) st = "loss";
            else if (now - o.optLong("t") > maxAge) st = "expired";
            if (st != null) {
                try {
                    o.put("st", st);
                    o.put("exit", p);
                    o.put("pnl", (buy ? p / entry - 1 : 1 - p / entry) * 100);
                    changed = true;
                } catch (Exception ignored) {
                }
            }
        }
        if (changed) Prefs.saveSignals(ctx, arr);
    }

    /** {wins, losses, expired, open} */
    public static int[] signalStats(JSONArray arr) {
        int[] s = new int[4];
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String st = o.optString("st", "");
            if (st.equals("win")) s[0]++;
            else if (st.equals("loss")) s[1]++;
            else if (st.equals("expired")) s[2]++;
            else if (st.equals("open")) s[3]++;
        }
        return s;
    }

    /** Checks the user's price alerts and notifies when one is crossed. */
    public static void checkAlerts(Context ctx) {
        JSONArray a = Prefs.alerts(ctx);
        if (a.length() == 0) return;
        List<Integer> done = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            String sym = o.optString("sym");
            double target = o.optDouble("price", 0);
            boolean above = o.optBoolean("above");
            try {
                double p = new JSONObject(get("/api/v3/ticker/price?symbol=" + sym)).optDouble("price", 0);
                if (p <= 0 || !(above ? p >= target : p <= target)) continue;
                done.add(i);
                if (!Notify.allowed(ctx, Prefs.N_ALERTS)) continue;
                String base = sym.substring(0, sym.length() - 4);
                Intent open = new Intent(ctx, MainActivity.class);
                open.putExtra("coin", sym);
                open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                PendingIntent pi = PendingIntent.getActivity(ctx, (sym + "alert" + i).hashCode(), open,
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
                Notification n = new Notification.Builder(ctx, CH_SIGNALS)
                        .setSmallIcon(R.drawable.ic_stat)
                        .setContentTitle("🔔 PRICE ALERT: " + base + " " + (above ? "upar gaya" : "neeche aaya") + " $" + fmtPrice(target))
                        .setContentText("Abhi price $" + fmtPrice(p) + " · tap karke analysis dekhen")
                        .setContentIntent(pi)
                        .setColor(0xFFF0B90B)
                        .setAutoCancel(true)
                        .build();
                NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
                nm.notify((sym + "alert" + target).hashCode(), n);
            } catch (Exception ignored) {
            }
        }
        if (!done.isEmpty()) Prefs.removeAlerts(ctx, done);
    }
}
