package com.signal.bot;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Fib Retrace on pivots (the TradingView "Fib Retrace — Pivot High / Low 20 10" idea) + RSI 14 with its moving average.
 *  • Pivot high / low: a candle that is the highest / lowest of 20 candles to its left and 10 to its right (confirmed, no repaint)
 *  • Levels are measured from the pivot LOW up to the pivot HIGH: 0.236 · 0.382 · 0.5 · 0.618 · 0.786
 *  • Which pivot is newer tells the impulse: low → high = up-impulse (pullbacks are BUY zones),
 *    high → low = down-impulse (bounces are SELL zones)
 *  • RSI 14 against its 14-period average confirms the turn (RSI above its average / turning up from oversold / divergence)
 * Output: a score (−100 … +100), a clear action (BUY / SELL / WAIT) and an entry zone, stop and targets on the fib levels.
 */
public final class FibRetrace {
    private FibRetrace() {}

    public static final double[] RATIOS = {0.236, 0.382, 0.5, 0.618, 0.786};
    public static final int LEFT = 20, RIGHT = 10;

    public static final class Result {
        public boolean ok, upImpulse, bullDiv, bearDiv, rsiUp, rsiDown;
        public double hi, lo, price, rsi, rsiMa, rsiPrev, depth, atr;
        public int hiIdx = -1, loIdx = -1, score;
        public final double[] levels = new double[5];   // prices of 0.236 … 0.786 (from the low)
        public String action = "WAIT", zone = "", headline = "";
        public double entryLo, entryHi, sl, tp1, tp2, tp3;
        public final List<String> lines = new ArrayList<>();

        /** Position of the price between pivot low (0) and pivot high (1). */
        public double pos() { return hi > lo ? (price - lo) / (hi - lo) : 0.5; }
    }

    /** Extension targets (1.272 … 3.618 of the range) that lie BEYOND the current price. */
    static void ext(Result r, boolean up) {
        double rng = r.hi - r.lo;
        double[] e = {0.272, 0.618, 1.0, 1.618, 2.618};
        List<Double> t = new ArrayList<>();
        for (double k : e) {
            double v = up ? r.hi + rng * k : r.lo - rng * k;
            if (up ? v > r.price + 0.5 * r.atr : v < r.price - 0.5 * r.atr && v > 0) t.add(v);
        }
        while (t.size() < 3) t.add(up ? (t.isEmpty() ? r.price : t.get(t.size() - 1)) + 1.5 * r.atr : Math.max((t.isEmpty() ? r.price : t.get(t.size() - 1)) - 1.5 * r.atr, r.price * 0.2));
        r.tp1 = t.get(0); r.tp2 = t.get(1); r.tp3 = t.get(2);
    }

    static double[] sma(double[] v, int p) {
        double[] o = new double[v.length];
        double s = 0;
        for (int i = 0; i < v.length; i++) {
            s += v[i];
            if (i >= p) s -= v[i - p];
            o[i] = s / Math.min(i + 1, p);
        }
        return o;
    }

    public static Result analyze(Candles c) {
        Result r = new Result();
        int n = c.n;
        if (n < LEFT + RIGHT + 30) return r;
        // ---- all confirmed pivots (20 left, 10 right), oldest first
        List<Integer> phs = new ArrayList<>(), pls = new ArrayList<>();
        for (int i = Math.max(LEFT, n - 600); i <= n - 1 - RIGHT; i++) {
            boolean ph = true, pl = true;
            for (int j = i - LEFT; j <= i + RIGHT && (ph || pl); j++) {
                if (j == i) continue;
                if (c.high[j] > c.high[i]) ph = false;
                if (c.low[j] < c.low[i]) pl = false;
            }
            if (ph) phs.add(i);
            if (pl) pls.add(i);
        }
        double px = c.close[n - 1];
        // latest pivots; if the price is already beyond one, step back to the nearest older pivot that still contains the price
        int hk = phs.size() - 1, lk = pls.size() - 1;
        while (hk > 0 && c.high[phs.get(hk)] < px) hk--;
        while (lk > 0 && c.low[pls.get(lk)] > px) lk--;
        if (hk >= 0) r.hiIdx = phs.get(hk);
        if (lk >= 0) r.loIdx = pls.get(lk);
        // the impulse leg: from the older pivot to the most extreme opposite pivot after it
        if (r.hiIdx >= 0 && r.loIdx >= 0) {
            if (r.loIdx < r.hiIdx) { for (int i : phs) if (i > r.loIdx && c.high[i] > c.high[r.hiIdx]) r.hiIdx = i; }
            else { for (int i : pls) if (i > r.hiIdx && c.low[i] < c.low[r.loIdx]) r.loIdx = i; }
        }
        if (r.hiIdx < 0 || r.loIdx < 0) {   // quiet chart: fall back to the extremes of the last 120 candles
            int from = Math.max(0, n - 120);
            int hi = from, lo = from;
            for (int i = from; i < n; i++) { if (c.high[i] > c.high[hi]) hi = i; if (c.low[i] < c.low[lo]) lo = i; }
            if (r.hiIdx < 0) r.hiIdx = hi;
            if (r.loIdx < 0) r.loIdx = lo;
        }
        r.hi = c.high[r.hiIdx];
        r.lo = c.low[r.loIdx];
        if (r.hi <= r.lo) return r;
        r.ok = true;
        r.price = c.close[n - 1];
        r.upImpulse = r.loIdx < r.hiIdx;
        double rng = r.hi - r.lo;
        for (int i = 0; i < 5; i++) r.levels[i] = r.lo + rng * RATIOS[i];
        r.atr = Indicators.atr(c.high, c.low, c.close, 14);
        if (r.atr <= 0) r.atr = r.price * 0.01;
        // ---- RSI 14 + its 14 SMA
        double[] rsi = Indicators.rsi(c.close, 14), ma = sma(rsi, 14);
        r.rsi = rsi[n - 1];
        r.rsiPrev = rsi[n - 2];
        r.rsiMa = ma[n - 1];
        r.rsiUp = r.rsi > r.rsiMa || (r.rsi < 35 && r.rsi > r.rsiPrev) || (rsi[n - 2] <= ma[n - 2] && r.rsi > r.rsiMa);
        r.rsiDown = r.rsi < r.rsiMa || (r.rsi > 65 && r.rsi < r.rsiPrev);
        // ---- RSI divergence on the last two small swings (5 / 3), inside the last 60 candles
        int[] lows = new int[2], highs = new int[2];
        int nl = 0, nh = 0;
        for (int i = n - 4; i >= Math.max(5, n - 60) && (nl < 2 || nh < 2); i--) {
            boolean pl = true, ph = true;
            for (int j = i - 5; j <= i + 3; j++) {
                if (j == i) continue;
                if (c.low[j] < c.low[i]) pl = false;
                if (c.high[j] > c.high[i]) ph = false;
            }
            if (pl && nl < 2) lows[nl++] = i;
            if (ph && nh < 2) highs[nh++] = i;
        }
        if (nl == 2 && c.low[lows[0]] < c.low[lows[1]] && rsi[lows[0]] > rsi[lows[1]] + 2) r.bullDiv = true;
        if (nh == 2 && c.high[highs[0]] > c.high[highs[1]] && rsi[highs[0]] < rsi[highs[1]] - 2) r.bearDiv = true;

        double p = r.price, atr = r.atr;
        double pos = r.pos();
        String[] names = {"Pivot Low", "0.236", "0.382", "0.5", "0.618", "0.786", "Pivot High"};
        double[] all = {r.lo, r.levels[0], r.levels[1], r.levels[2], r.levels[3], r.levels[4], r.hi};
        int below = -1;
        for (int i = 0; i < all.length; i++) if (all[i] <= p) below = i;
        r.zone = below < 0 ? "Pivot Low ke NEECHE" : below >= all.length - 1 ? "Pivot High ke UPAR" : names[below] + " – " + names[below + 1];

        r.lines.add(String.format(Locale.US, "Pivot High $%s (%d candles pehle) · Pivot Low $%s (%d candles pehle)", Fmt.price(r.hi), n - 1 - r.hiIdx, Fmt.price(r.lo), n - 1 - r.loIdx));
        r.lines.add(String.format(Locale.US, "0.786 $%s · 0.618 $%s · 0.5 $%s · 0.382 $%s · 0.236 $%s", Fmt.price(r.levels[4]), Fmt.price(r.levels[3]), Fmt.price(r.levels[2]),
                Fmt.price(r.levels[1]), Fmt.price(r.levels[0])));
        r.lines.add("Price abhi: " + r.zone + String.format(Locale.US, " (range ka %.0f%%)", pos * 100));
        r.lines.add(String.format(Locale.US, "RSI %.1f · RSI average %.1f → %s%s%s", r.rsi, r.rsiMa, r.rsi > r.rsiMa ? "RSI average ke UPAR (taqat aa rahi)" : "RSI average ke NEECHE (kamzor)",
                r.bullDiv ? " · 🟢 bullish divergence" : "", r.bearDiv ? " · 🔴 bearish divergence" : ""));

        if (r.upImpulse) {
            // ---- up-impulse (low → high): pullbacks are buy zones; depth = how much of the move was given back
            r.depth = (r.hi - p) / rng;
            r.lines.add(String.format(Locale.US, "Impulse: UPAR (low → high). Pullback %.0f%% wapas aaya.", Math.max(0, r.depth) * 100));
            boolean conf = r.rsiUp || r.bullDiv;
            if (p > r.hi) {
                r.score = conf ? 65 : 45;
                r.action = conf ? "BUY" : "WAIT";
                r.headline = "Pivot High toot gaya — upar ka trend jaari";
                r.entryLo = Math.max(r.hi, p - 0.6 * atr); r.entryHi = Math.max(p, r.hi + 0.3 * atr);
                r.sl = Math.max(r.levels[4], p - 3 * atr) - 0.3 * atr;
                ext(r, true);
            } else if (p < r.lo) {
                r.score = -60;
                r.action = "SELL";
                r.headline = "Pivot Low toot gaya — up-move khatam, structure bearish";
                r.entryLo = p; r.entryHi = Math.min(r.lo, p + 0.6 * atr);
                r.sl = Math.min(r.levels[0], p + 3 * atr) + 0.3 * atr;
                ext(r, false);
            } else {
                if (r.depth < 0.236) { r.score = 30; r.action = "WAIT"; r.headline = "High ke qareeb — halka pullback. Dip (0.618 / 0.5) ya Pivot High ke break ka wait"; }
                else if (r.depth < 0.5) { r.score = conf ? 50 : 28; r.action = conf ? "BUY" : "WAIT"; r.headline = "Sehatmand pullback (0.5–0.786 zone)" + (conf ? " + RSI confirm" : " — RSI confirm baqi"); }
                else if (r.depth <= 0.786) { r.score = conf ? 60 : 22; r.action = conf ? "BUY" : "WAIT"; r.headline = "Golden zone (0.236–0.5): gehra pullback" + (conf ? " + RSI palat raha" : " — RSI abhi kamzor, palatne ka wait"); }
                else { r.score = conf ? 20 : -20; r.action = conf ? "BUY" : "WAIT"; r.headline = "Aakhri difa: Pivot Low ke bilkul upar" + (conf ? " — RSI palat raha (tight stop)" : " — toota to bearish"); }
                // entry = the fib band the price is in; stop below the next level down; targets = next levels up
                double zl = below >= 0 ? all[below] : r.lo, zh = below + 1 < all.length ? all[below + 1] : r.hi;
                r.entryLo = Math.max(zl, p - 0.5 * atr);
                r.entryHi = Math.min(zh, p + 0.1 * atr);
                r.sl = (below >= 1 ? all[below - 1] : r.lo) - 0.3 * atr;
                if (r.depth > 0.5) r.sl = r.lo - 0.3 * atr;
                List<Double> t = new ArrayList<>();
                for (double v : all) if (v > p + 0.4 * atr) t.add(v);
                t.add(r.hi + rng * 0.272);
                t.add(r.hi + rng * 0.618);
                r.tp1 = t.get(0); r.tp2 = t.get(Math.min(1, t.size() - 1)); r.tp3 = t.get(Math.min(2, t.size() - 1));
            }
        } else {
            // ---- down-impulse (high → low): bounces are sell zones; depth = how much of the fall was recovered
            r.depth = (p - r.lo) / rng;
            r.lines.add(String.format(Locale.US, "Impulse: NEECHE (high → low). Bounce %.0f%% wapas chadha.", Math.max(0, r.depth) * 100));
            boolean conf = r.rsiDown || r.bearDiv;
            if (p < r.lo) {
                r.score = conf ? -65 : -45;
                r.action = conf ? "SELL" : "WAIT";
                r.headline = "Pivot Low toot gaya — neeche ka trend jaari";
                r.entryLo = p; r.entryHi = Math.min(r.lo, p + 0.6 * atr);
                r.sl = Math.min(r.levels[0], p + 3 * atr) + 0.3 * atr;
                ext(r, false);
            } else if (p > r.hi) {
                r.score = 60;
                r.action = "BUY";
                r.headline = "Pivot High toot gaya — down-move khatam, structure bullish";
                r.entryLo = Math.max(r.hi, p - 0.6 * atr); r.entryHi = p;
                r.sl = Math.max(r.levels[4], p - 3 * atr) - 0.3 * atr;
                ext(r, true);
            } else {
                boolean turnUp = r.bullDiv || (r.rsi < 35 && r.rsi > r.rsiPrev) || (r.rsi > r.rsiMa && r.depth < 0.3);
                if (r.depth < 0.236) {
                    if (turnUp) { r.score = 25; r.action = "BUY"; r.headline = "Low ke qareeb + RSI palat raha — bounce ka imkaan (counter-trend, chhota target)"; }
                    else { r.score = -30; r.action = "WAIT"; r.headline = "Low ke qareeb — bounce (0.382 / 0.5) par SELL ya Pivot Low tootne ka wait"; }
                } else if (r.depth < 0.5) { r.score = conf ? -50 : -28; r.action = conf ? "SELL" : "WAIT"; r.headline = "Bounce 0.236–0.5 mein" + (conf ? " + RSI kamzor — sell zone" : " — RSI abhi mazboot"); }
                else if (r.depth <= 0.786) { r.score = conf ? -60 : -22; r.action = conf ? "SELL" : "WAIT"; r.headline = "Golden sell zone (0.5–0.786)" + (conf ? " + RSI palat raha" : " — RSI ke palatne ka wait"); }
                else { r.score = conf ? -20 : 20; r.action = conf ? "SELL" : "WAIT"; r.headline = "Pivot High ke bilkul neeche" + (conf ? " — RSI palat raha (tight stop)" : " — toota to bullish"); }
                double zl = below >= 0 ? all[below] : r.lo, zh = below + 1 < all.length ? all[below + 1] : r.hi;
                if (r.action.equals("BUY")) {
                    r.entryLo = Math.max(zl, p - 0.5 * atr); r.entryHi = p;
                    r.sl = r.lo - 0.3 * atr;
                    r.tp1 = r.levels[1]; r.tp2 = r.levels[2]; r.tp3 = r.levels[3];
                } else {
                    r.entryLo = Math.max(zl, p - 0.1 * atr);
                    r.entryHi = Math.min(zh, p + 0.5 * atr);
                    r.sl = (below + 2 < all.length ? all[below + 2] : r.hi) + 0.3 * atr;
                    if (r.depth > 0.5) r.sl = r.hi + 0.3 * atr;
                    List<Double> t = new ArrayList<>();
                    for (int i = all.length - 1; i >= 0; i--) if (all[i] < p - 0.4 * atr) t.add(all[i]);
                    t.add(r.lo - rng * 0.272);
                    t.add(r.lo - rng * 0.618);
                    r.tp1 = t.get(0); r.tp2 = t.get(Math.min(1, t.size() - 1)); r.tp3 = t.get(Math.min(2, t.size() - 1));
                }
            }
        }
        r.lines.add((r.action.equals("BUY") ? "🟢 " : r.action.equals("SELL") ? "🔴 " : "⏳ ") + r.headline);
        if (!r.action.equals("WAIT"))
            r.lines.add(String.format(Locale.US, "%s zone $%s – $%s · stop $%s · targets $%s / $%s / $%s", r.action, Fmt.price(r.entryLo), Fmt.price(r.entryHi), Fmt.price(r.sl),
                    Fmt.price(r.tp1), Fmt.price(r.tp2), Fmt.price(r.tp3)));
        return r;
    }
}
