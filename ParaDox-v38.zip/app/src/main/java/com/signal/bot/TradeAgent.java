package com.signal.bot;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Trade Agent — turns the whole analysis into ONE clear instruction with exact prices:
 *   "ABHI BUY $x–$y" · "BUY LIMIT $x–$y par" · "ABHI SELL / EXIT" · "SELL LIMIT" · "ABHI TRADE NAHI (buy sirf $a ke upar, sell $b ke neeche)".
 * Seven independent judges vote (overall report, Fib Retrace + RSI, Smart Money structure, live order flow, 12 indicators,
 * moving averages, multi-timeframe). A trade is called only when at least 4 agree and at most 1 disagrees — otherwise NO TRADE
 * with the exact trigger levels. Every answer carries its stop (the price that proves the idea wrong).
 * Deterministic: works without any AI key. The optional AI chat only explains this verdict and may not change the numbers.
 */
public final class TradeAgent {
    private TradeAgent() {}

    public static final String BUY_NOW = "BUY_NOW", BUY_LIMIT = "BUY_LIMIT", SELL_NOW = "SELL_NOW", SELL_LIMIT = "SELL_LIMIT", NO_TRADE = "NO_TRADE";

    public static final class Verdict {
        public String action = NO_TRADE, headline = "", sub = "";
        public double entryLo, entryHi, sl, tp1, tp2, tp3, buyTrigger, sellTrigger;
        public int buy, sell;
        public final List<String> votes = new ArrayList<>();

        public boolean isBuy() { return action.startsWith("BUY"); }
        public boolean isTrade() { return !action.equals(NO_TRADE); }
    }

    static void vote(Verdict v, String name, int side, String detail) {
        if (side > 0) v.buy++; else if (side < 0) v.sell++;
        v.votes.add((side > 0 ? "🟢 " : side < 0 ? "🔴 " : "⚪ ") + name + ": " + detail);
    }

    public static Verdict decide(CoinReport r) {
        Verdict v = new Verdict();
        double p = r.price, atr = r.atr > 0 ? r.atr : p * 0.01;
        // ---- the seven judges
        vote(v, "Poora analysis", r.total >= 57 ? 1 : r.total <= 43 ? -1 : 0, "score " + r.total + "/100");
        if (r.fib != null && r.fib.ok)
            vote(v, "Fib Retrace + RSI", r.fib.action.equals("BUY") ? 1 : r.fib.action.equals("SELL") ? -1 : 0, r.fib.headline);
        else vote(v, "Fib Retrace + RSI", 0, "pivot nahi mile");
        if (r.smc != null) vote(v, "Smart Money structure", r.smcScore >= 30 ? 1 : r.smcScore <= -30 ? -1 : 0,
                (r.smc.trend > 0 ? "bullish" : r.smc.trend < 0 ? "bearish" : "saaf nahi") + " (score " + r.smcScore + ")");
        else vote(v, "Smart Money structure", 0, "data kam");
        vote(v, "Order flow (volume)", r.buyPct >= 55 ? 1 : r.buyPct <= 45 ? -1 : 0, String.format(Locale.US, "buyers %.0f%% · sellers %.0f%%", r.buyPct, 100 - r.buyPct));
        if (r.ind != null && r.ind.total > 0) {
            double ab = r.ind.agreement(true), as = r.ind.agreement(false);
            vote(v, "12 indicators", ab >= 60 ? 1 : as >= 60 ? -1 : 0, String.format(Locale.US, "%.0f%% buy · %.0f%% sell", ab, as));
        } else vote(v, "12 indicators", 0, "—");
        if (r.ma != null) vote(v, "Moving averages", r.ma.score >= 20 ? 1 : r.ma.score <= -20 ? -1 : 0, "score " + r.ma.score);
        else vote(v, "Moving averages", 0, "—");
        vote(v, "Multi-timeframe", r.mtfAgree > 0 ? 1 : r.mtfAgree < 0 ? -1 : 0, r.mtfAgree > 0 ? "timeframes upar" : r.mtfAgree < 0 ? "timeframes neeche" : "mile jule");

        // ---- trigger levels (always given)
        double res = r.resistance > p ? r.resistance : 0, sup = r.support > 0 && r.support < p ? r.support : 0;
        if (r.fib != null && r.fib.ok) {
            if (res == 0 || (r.fib.hi > p && r.fib.hi < res)) res = r.fib.hi > p ? r.fib.hi : res;
            if (sup == 0 || (r.fib.lo < p && r.fib.lo > sup)) sup = r.fib.lo < p ? r.fib.lo : sup;
        }
        v.buyTrigger = res > 0 ? res : p + 1.5 * atr;
        v.sellTrigger = sup > 0 ? sup : p - 1.5 * atr;

        boolean wantBuy = v.buy >= 4 && v.sell <= 1, wantSell = v.sell >= 4 && v.buy <= 1;
        Position.Advice a = r.advice;
        if (wantBuy) {
            boolean fibOk = r.fib != null && r.fib.ok && r.fib.action.equals("BUY");
            // entry zone: the fib buy band when it agrees, else the advice zone
            if (fibOk) { v.entryLo = r.fib.entryLo; v.entryHi = r.fib.entryHi; }
            else if (a != null && a.buy && a.zoneLo > 0) { v.entryLo = a.zoneLo; v.entryHi = a.zoneHi; }
            else { v.entryLo = p - 0.6 * atr; v.entryHi = p; }
            boolean inside = p >= v.entryLo - 0.1 * atr && p <= v.entryHi + 0.25 * atr;
            v.action = inside ? BUY_NOW : BUY_LIMIT;
            if (v.action.equals(BUY_NOW)) v.entryHi = Math.max(v.entryHi, p);
            v.sl = pickStop(true, v.entryLo, atr, r.stop, fibOk ? r.fib.sl : 0);
            targets(v, r, true);
        } else if (wantSell) {
            boolean fibOk = r.fib != null && r.fib.ok && r.fib.action.equals("SELL");
            if (fibOk) { v.entryLo = r.fib.entryLo; v.entryHi = r.fib.entryHi; }
            else if (a != null && !a.buy && a.zoneHi > 0) { v.entryLo = a.zoneLo; v.entryHi = a.zoneHi; }
            else { v.entryLo = p; v.entryHi = p + 0.6 * atr; }
            boolean inside = p >= v.entryLo - 0.25 * atr && p <= v.entryHi + 0.1 * atr;
            v.action = inside ? SELL_NOW : SELL_LIMIT;
            if (v.action.equals(SELL_NOW)) v.entryLo = Math.min(v.entryLo, p);
            v.sl = pickStop(false, v.entryHi, atr, r.stop, fibOk ? r.fib.sl : 0);
            targets(v, r, false);
        }
        // a plan that pays less than the risk is not a trade
        boolean rrMoved = false, rrBad = false;
        if (v.isTrade()) {
            boolean b = v.isBuy();
            double e = b ? v.entryHi : v.entryLo, risk = Math.abs(e - v.sl);
            if (risk <= 0 || Math.abs(v.tp1 - e) < 0.8 * risk) {
                // at this price the first target pays less than the risk: move the order to where reward ≥ risk, never chase
                double fair = (v.tp1 + v.sl) / 2;
                if (b ? fair > v.sl + 0.5 * atr && fair < p : fair < v.sl - 0.5 * atr && fair > p) {
                    if (b) { v.entryHi = fair; v.entryLo = Math.max(v.sl + 0.4 * atr, fair - 0.6 * atr); v.action = BUY_LIMIT; }
                    else { v.entryLo = fair; v.entryHi = Math.min(v.sl - 0.4 * atr, fair + 0.6 * atr); v.action = SELL_LIMIT; }
                    rrMoved = true;
                    v.votes.add("⚠️ Abhi ki price par pehla target stop se chhota tha — order behtar price par rakha (reward ≥ risk)");
                } else {
                    rrBad = true;
                    v.votes.add("⚠️ Pehla target stop ke faasle se chhota — is price par trade ka faida nahi");
                    v.action = NO_TRADE;
                }
            }
        }
        boolean spot = r.mode == Mode.SPOT;
        switch (v.action) {
            case BUY_NOW:
                v.headline = "✅ ABHI BUY — $" + Fmt.price(v.entryLo) + " – $" + Fmt.price(v.entryHi);
                v.sub = v.buy + " / 7 judges BUY ke haq mein, " + v.sell + " khilaf. Abhi isi zone mein khareed lein." + (v.buy == 4 ? " (4 / 7 — position aadhi rakhein.)" : "");
                break;
            case BUY_LIMIT:
                v.headline = "🟢 BUY LIMIT lagayen — $" + Fmt.price(v.entryLo) + " – $" + Fmt.price(v.entryHi);
                v.sub = v.buy + " / 7 judges BUY ke haq mein. " + (rrMoved ? "Abhi ki price par target chhota aur stop door hai — is sasti price par order rakhein, peecha na karein."
                        : "Price abhi zone se bahar hai — peecha na karein, order isi zone mein rakhein.");
                break;
            case SELL_NOW:
                v.headline = (spot ? "🔴 ABHI SELL / EXIT — $" : "🔴 ABHI SELL (short) — $") + Fmt.price(v.entryLo) + " – $" + Fmt.price(v.entryHi);
                v.sub = v.sell + " / 7 judges SELL ke haq mein, " + v.buy + " khilaf." + (spot ? " Holding ho to yahin bech dein." : "") + (v.sell == 4 ? " (4 / 7 — position aadhi rakhein.)" : "");
                break;
            case SELL_LIMIT:
                v.headline = (spot ? "🟠 SELL / EXIT order — $" : "🟠 SELL LIMIT (short) — $") + Fmt.price(v.entryLo) + " – $" + Fmt.price(v.entryHi);
                v.sub = v.sell + " / 7 judges SELL ke haq mein. " + (rrMoved ? "Abhi ki price par target chhota hai — price is zone tak upar aaye to bechein." : "Price zone tak aaye to bechein.");
                break;
            default:
                v.headline = "⛔ ABHI TRADE NAHI";
                v.sub = String.format(Locale.US, (rrBad ? "Rukh saaf hai (BUY %d · SELL %d) magar is price par target stop se chhota hai — faida nahi. " : "Judges bate hue hain (BUY %d · SELL %d). ") + "BUY sirf tab: candle $%s ke UPAR band ho. SELL / exit tab: candle $%s ke NEECHE band ho. Beech mein kuch na karein.",
                        v.buy, v.sell, Fmt.price(v.buyTrigger), Fmt.price(v.sellTrigger));
        }
        return v;
    }

    /**
     * Stop beyond the zone edge `ref`: the FARTHEST candidate that is still within 4 ATR (protected by both structure and fib),
     * never closer than 0.5 ATR; 1.2 ATR when there is no usable candidate.
     */
    static double pickStop(boolean buy, double ref, double atr, double... cands) {
        double best = 0;
        for (double c : cands) {
            if (c <= 0) continue;
            double d = buy ? ref - c : c - ref;
            if (d < 0.5 * atr || d > 4 * atr) continue;
            if (best == 0 || (buy ? c < best : c > best)) best = c;
        }
        return best != 0 ? best : buy ? ref - 1.2 * atr : ref + 1.2 * atr;
    }

    static void targets(Verdict v, CoinReport r, boolean buy) {
        double e = buy ? v.entryHi : v.entryLo, risk = Math.abs(e - v.sl);
        List<Double> t = new ArrayList<>();
        double[] cand = r.fib != null && r.fib.ok && r.fib.action.equals(buy ? "BUY" : "SELL")
                ? new double[]{r.fib.tp1, r.fib.tp2, r.fib.tp3, r.target1, r.target2, r.target3}
                : new double[]{r.target1, r.target2, r.target3};
        for (double c : cand) if (c > 0 && (buy ? c > e + 0.5 * risk : c < e - 0.5 * risk)) t.add(c);
        t.sort((x, y) -> buy ? Double.compare(x, y) : Double.compare(y, x));
        List<Double> u = new ArrayList<>();
        for (double c : t) if (u.isEmpty() || Math.abs(c - u.get(u.size() - 1)) > 0.4 * risk) u.add(c);
        while (u.size() < 3) {
            double last = u.isEmpty() ? e : u.get(u.size() - 1);
            u.add(buy ? last + 1.5 * risk : last - 1.5 * risk);
        }
        v.tp1 = u.get(0); v.tp2 = u.get(1); v.tp3 = u.get(2);
    }

    /** The verdict as plain text (shown in the chat and sent to the AI as the only allowed numbers). */
    public static String text(CoinReport r, Verdict v) {
        StringBuilder sb = new StringBuilder();
        sb.append(v.headline).append('\n').append(v.sub).append('\n');
        if (v.isTrade()) {
            double e = v.isBuy() ? v.entryHi : v.entryLo, risk = Math.abs(e - v.sl);
            sb.append(String.format(Locale.US, "🛑 Stop-loss: $%s (%.1f%%) — yahan pohanchi to idea ghalat, nikal jayen\n", Fmt.price(v.sl), risk / e * 100));
            sb.append(String.format(Locale.US, "🎯 %s: TP1 $%s (%.1fR) · TP2 $%s (%.1fR) · TP3 $%s (%.1fR)\n", v.isBuy() ? "Yahan becho" : "Yahan cover karo", Fmt.price(v.tp1),
                    Math.abs(v.tp1 - e) / risk, Fmt.price(v.tp2), Math.abs(v.tp2 - e) / risk, Fmt.price(v.tp3), Math.abs(v.tp3 - e) / risk));
            sb.append("📋 TP1 par 1/3 bech kar stop entry par le aayen · TP2 par 1/3 · TP3 par baqi\n");
        }
        for (String s : v.votes) sb.append(s).append('\n');
        return sb.toString().trim();
    }

    /** Instruction that keeps the AI on the verdict: decisive wording, no new numbers. */
    public static String aiRules() {
        return "Tum ParaDox ke 'Trade Agent' ho. Neeche 'FAISLA' deterministic engine ka final faisla hai — tum usay badal nahi sakte aur koi nayi price nahi bana sakte; "
                + "sirf isi data ke numbers use karo. Jawab Roman Urdu mein, 4–7 chhoti lines, seedha hukm ki zabaan mein: 'Yahan buy karo: $..', 'Stop: $..', "
                + "'Yahan becho: $..'. 'Shayad', 'ho sakta hai', 'mumkin hai' jaise lafz mat likho. Agar faisla NO TRADE hai to saaf kaho 'abhi trade nahi' aur trigger prices do. "
                + "User ke sawal ka jawab isi faisle ki roshni mein do. Aakhri line hamesha: 'Stop zaroor lagayen — stop lagne ka matlab idea ghalat tha, guarantee kisi trade ki nahi hoti.'";
    }
}
