# Changelog

## v38.0 — Fib Retrace, Smart Money on the chart, Trade Agent
- New: Fib Retrace on pivots (pivot high / low, 20 left · 10 right) with levels 0.236–0.786 measured from the pivot low,
  plus RSI 14 against its 14-period average and RSI divergence. It is a scored section in the crypto, gold and forex
  analysis, and a chart layer ("FibTMF") with coloured bands and price labels.
- New: Smart Money section in the analysis (BOS / CHoCH / MSS, sweeps, demand / supply zones, liquidity above and below)
  and a chart layer ("SMC") with order-block / FVG boxes and structure labels.
- New: RSI panel draws the RSI average (yellow line).
- New: Trade Agent card directly under the chart. Seven judges vote (report, Fib + RSI, Smart Money, order flow,
  12 indicators, moving averages, multi-timeframe). A trade is called only with at least 4 for and at most 1 against;
  otherwise NO TRADE with the exact trigger prices. Built-in chat answers from the verdict without any key; with a
  free Gemini / Groq key the AI explains the same verdict and may not change the numbers.
- Fix: a bearish BTC used to block every BUY candidate. It now raises the required score by one point.
- Fix: SMC Pro signals are limit entries. The Signals tab no longer counts them as win / loss before the entry fills;
  an unfilled entry expires with 0%.
- Fix: SMC Pro signals in the Signals tab now use the same holding window as the paper trader (they expired after 4 h).
- Fix: back from an event report returns to the screen it was opened from.
- Fix: the home news ticker stops animating while the home screen is hidden.
- Fix: gold / forex search shows a message when nothing matches.
- Tests: 17 unit checks (Fib levels, Fib + weak RSI = WAIT, Trade Agent stop / target sanity, NO TRADE triggers added).

## v37.0 — SMC Pro
- New: Smart Money Concepts engine: BOS, CHoCH, MSS, HH/HL/LH/LL, BSL/SSL, EQH/EQL, sweeps, premium/discount,
  order blocks with validation and mitigation, FVG, IFVG, breaker and rejection blocks, displacement.
- New: multi-timeframe signal engine. Bias comes from 4h + 1D (or 1h + 4h); entry is confirmed on 1h (or 15m).
  It returns NO TRADE when conditions conflict.
- New: weighted confidence score (8 parts). Minimum reward:risk check. Every signal carries full fields and an explanation.
- New: risk manager: risk %, position size, max open positions, daily loss limit, consecutive-loss pause, duplicate block,
  expiry, partial exits, break-even and trailing stop.
- New: historical backtest on real candles, run on the phone. Includes fees, slippage, funding, the conservative
  same-candle rule and reports by coin, timeframe and regime.
- New: walk-forward: 60/20/20 split, 4 anchored folds and an out-of-sample total.
- New: live forward test (paper only) with immutable history, NO TRADE log and a live-vs-backtest comparison.
- New: AI review (Gemini / Groq) that explains a setup and cannot change it.
- New: market narrative card (BTC dominance, total market cap, alt share, AI/RWA/DePIN/DeFi/Gaming sectors) and an
  MTF structure table (5m → 1W).
- Tests: 13 unit checks (JUnit), run in CI as a non-blocking step.

## v36.0
- Gate and HTX liquidations added. Each exchange shown separately.
