package com.signal.bot;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Settings (separate for Scalp and Spot), watchlist, alerts and saved signals. */
public final class Prefs {
    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("signalbot", Context.MODE_PRIVATE);
    }

    private static String k(int m, String key) { return "m" + m + "_" + key; }

    // defaults per mode: {SCALP, SPOT}
    private static final int[] D_INTERVAL = {1, 15}, D_TOP = {60, 150}, D_MINVOL = {10, 5},
            D_BUY = {6, 7}, D_SELL = {4, 5}, D_COOL = {30, 240};
    private static final String[] D_TF = {"5m", "4h"};
    private static final float[] D_VOLM = {1.8f, 2.0f};

    /** Scalp bot and Spot bot are switched ON/OFF separately. */
    public static boolean modeOn(Context c, int m) { return sp(c).getBoolean("on_" + m, false); }
    public static void setModeOn(Context c, int m, boolean v) { sp(c).edit().putBoolean("on_" + m, v).apply(); }
    /** True when at least one bot is ON. */
    public static boolean enabled(Context c) { return modeOn(c, Mode.SCALP) || modeOn(c, Mode.SPOT); }
    public static void setEnabled(Context c, boolean v) {
        if (!v) sp(c).edit().putBoolean("on_0", false).putBoolean("on_1", false).apply();
    }

    // ---------------- Claude AI
    public static String claudeKey(Context c) { return sp(c).getString("claudekey", ""); }
    public static String claudeModel(Context c) { return sp(c).getString("claudemodel", "claude-sonnet-5-5"); }
    public static void saveClaude(Context c, String key, String model) {
        sp(c).edit().putString("claudekey", key == null ? "" : key.trim()).putString("claudemodel", model).apply();
    }

    /** Which mode the app screens show. */
    public static int uiMode(Context c) { return sp(c).getInt("uimode", Mode.SCALP); }
    public static void setUiMode(Context c, int m) { sp(c).edit().putInt("uimode", m).apply(); }

    public static int intervalMin(Context c, int m) { return sp(c).getInt(k(m, "interval"), D_INTERVAL[m]); }
    public static String timeframe(Context c, int m) { return sp(c).getString(k(m, "tf"), D_TF[m]); }
    public static int topCoins(Context c, int m) { return sp(c).getInt(k(m, "top"), D_TOP[m]); }
    public static int minVolMillion(Context c, int m) { return sp(c).getInt(k(m, "minvol"), D_MINVOL[m]); }
    public static int buyThreshold(Context c, int m) { return sp(c).getInt(k(m, "buyth"), D_BUY[m]); }
    public static int sellThreshold(Context c, int m) { return sp(c).getInt(k(m, "sellth"), D_SELL[m]); }
    public static float volMult(Context c, int m) { return sp(c).getFloat(k(m, "volmult"), D_VOLM[m]); }
    public static int cooldownMin(Context c, int m) { return sp(c).getInt(k(m, "cooldown"), D_COOL[m]); }

    public static void saveMode(Context c, int m, int interval, String tf, int top, int minVol,
                                int buyTh, int sellTh, float volMult, int cooldown) {
        sp(c).edit()
                .putInt(k(m, "interval"), Math.max(1, interval))
                .putString(k(m, "tf"), tf)
                .putInt(k(m, "top"), Math.max(5, Math.min(400, top)))
                .putInt(k(m, "minvol"), Math.max(0, minVol))
                .putInt(k(m, "buyth"), Math.max(1, buyTh))
                .putInt(k(m, "sellth"), Math.max(1, sellTh))
                .putFloat(k(m, "volmult"), Math.max(1.1f, volMult))
                .putInt(k(m, "cooldown"), Math.max(0, cooldown))
                .apply();
    }

    public static boolean btcFilter(Context c) { return sp(c).getBoolean("btcfilter", true); }
    public static boolean smartMoney(Context c) { return sp(c).getBoolean("smart", true); }
    public static boolean strongConfirm(Context c) { return sp(c).getBoolean("strong", true); }
    public static int whaleUsd(Context c) { return sp(c).getInt("whaleusd", 50000); }
    public static String glassKey(Context c) { return sp(c).getString("glass", ""); }

    public static void saveCommon(Context c, boolean btc, boolean smart, boolean strong, int whaleUsd, String glass) {
        sp(c).edit().putBoolean("btcfilter", btc).putBoolean("smart", smart).putBoolean("strong", strong)
                .putInt("whaleusd", Math.max(1000, whaleUsd)).putString("glass", glass == null ? "" : glass.trim()).apply();
    }

    public static String lastCoin(Context c) { return sp(c).getString("lastcoin", "BTCUSDT"); }
    public static void setLastCoin(Context c, String s) { sp(c).edit().putString("lastcoin", s).apply(); }

    // ---------------- chart layers + risk calculator
    public static boolean layer(Context c, String name) { return sp(c).getBoolean("layer_" + name, true); }
    public static void setLayer(Context c, String name, boolean on) { sp(c).edit().putBoolean("layer_" + name, on).apply(); }
    public static float balance(Context c) { return sp(c).getFloat("balance", 100f); }
    public static float riskPct(Context c) { return sp(c).getFloat("riskpct", 1f); }
    public static void saveRisk(Context c, float bal, float pct) {
        sp(c).edit().putFloat("balance", Math.max(0, bal)).putFloat("riskpct", Math.max(0.1f, Math.min(20, pct))).apply();
    }

    // ---------------- watchlist
    public static List<String> watchlist(Context c) {
        List<String> out = new ArrayList<>();
        for (String s : sp(c).getString("watch", "BTCUSDT,ETHUSDT,SOLUSDT").split(",")) {
            s = s.trim();
            if (!s.isEmpty() && !out.contains(s)) out.add(s);
        }
        return out;
    }

    public static boolean inWatchlist(Context c, String sym) { return watchlist(c).contains(sym); }

    public static boolean toggleWatch(Context c, String sym) {
        List<String> l = watchlist(c);
        boolean now;
        if (l.contains(sym)) { l.remove(sym); now = false; } else { l.add(0, sym); now = true; }
        StringBuilder sb = new StringBuilder();
        for (String s : l) { if (sb.length() > 0) sb.append(','); sb.append(s); }
        sp(c).edit().putString("watch", sb.toString()).apply();
        return now;
    }

    // ---------------- price alerts
    public static synchronized JSONArray alerts(Context c) {
        try { return new JSONArray(sp(c).getString("alerts", "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    public static synchronized void addAlert(Context c, String sym, double price, boolean above) {
        try {
            JSONArray a = alerts(c);
            JSONObject o = new JSONObject();
            o.put("sym", sym);
            o.put("price", price);
            o.put("above", above);
            a.put(o);
            sp(c).edit().putString("alerts", a.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    /** Removes the alerts at the given indexes. */
    public static synchronized void removeAlerts(Context c, List<Integer> idx) {
        JSONArray a = alerts(c), out = new JSONArray();
        for (int i = 0; i < a.length(); i++) {
            if (idx.contains(i)) continue;
            try { out.put(a.get(i)); } catch (Exception ignored) { }
        }
        sp(c).edit().putString("alerts", out.toString()).apply();
    }

    // ---------------- status + cooldown
    public static String status(Context c) { return sp(c).getString("status", "Bot abhi band hai"); }
    public static void setStatus(Context c, String s) { sp(c).edit().putString("status", s).apply(); }

    public static boolean cooldownOk(Context c, int m, String symbol, String side) {
        long last = sp(c).getLong("cd" + m + "_" + symbol + "_" + side, 0);
        return System.currentTimeMillis() - last >= cooldownMin(c, m) * 60_000L;
    }

    public static void markCooldown(Context c, int m, String symbol, String side) {
        sp(c).edit().putLong("cd" + m + "_" + symbol + "_" + side, System.currentTimeMillis()).apply();
    }

    // ---------------- signals
    public static synchronized void addSignal(Context c, int mode, String side, String symbol, double price,
                                              int score, String reasons, double sl, double tp) {
        try {
            JSONArray old = new JSONArray(sp(c).getString("signals", "[]"));
            JSONArray arr = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("t", System.currentTimeMillis());
            o.put("mode", mode);
            o.put("side", side);
            o.put("sym", symbol);
            o.put("price", price);
            o.put("score", score);
            o.put("why", reasons);
            o.put("sl", sl);
            o.put("tp", tp);
            o.put("st", "open");
            arr.put(o);
            for (int i = 0; i < old.length() && i < 199; i++) arr.put(old.get(i));
            sp(c).edit().putString("signals", arr.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    public static JSONArray signals(Context c) {
        try {
            return new JSONArray(sp(c).getString("signals", "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    public static synchronized void saveSignals(Context c, JSONArray arr) {
        sp(c).edit().putString("signals", arr.toString()).apply();
    }

    public static void clearSignals(Context c) { sp(c).edit().putString("signals", "[]").apply(); }
}
